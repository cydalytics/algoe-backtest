"""Data access: the historical panel, the live panel, splits, and a synthetic world."""
