"""Two-level statistical turnover model from Raw_Data, on CPU, numpy only.

    turnover(selection, T) = match total(T) x share of the selection(T)

Level 1, match total per 5-minute bucket: a Tweedie GLM with log link (power
1.5 handles many zeros plus a long right tail). Smooth effects of minutes to
kick-off and match minute are piecewise-linear splines with a ridge penalty,
i.e. a small GAM. Autoregressive terms are the match's own totals in the last
three buckets. Goals and red cards enter as decaying pulses.

Random effects, by empirical Bayes shrinkage on top of the GLM:
    league   multiplier fitted on the training days, shrunk toward 1
    match    multiplier updated every bucket from that match's own buckets
             earlier the same day, shrunk toward 1; no refit needed

Level 2, how the match's money splits: a log-linear share model, fitted as a
Poisson GLM with log(match total) as offset, normalised within the match
bucket at prediction time. Pool, main line, favourite, HKJC vs market price,
recent price moves and recent shares are the drivers.

Every price is the one known at the START of the bucket.

Walk-forward: day N is predicted by fits on days before N only. The first
``--warmup-days`` days write last 5 min. Last 5 min is blended in with a
weight picked on the latest unseen days by Poisson deviance (the mean, which
is what expected margin needs), not by per-selection WAPE (the median, which
rewards predicting zero).

Output lands where the backtest reads it:

    Backtest_Data/Features_glm2/YYYY-MM-DD.parquet      features, reused next run
    Backtest_Data/Turnover/<name>/YYYY-MM-DD.parquet   "value", in the backtest's row order
    Backtest_Data/Turnover/<name>/_report.json         per day: WAPE, WAPE per match, bias, deviance

    python -m src.backtest.parquet.glm_turnover train --data-dir "S:\\Users\\Yeung\\20260520 Algo E\\Raw_Data"
    python -m src.backtest.parquet.glm_turnover selftest
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .cache import day_list
from .config import Config
from .loader import load_static, load_window
from .panel import GOAL_IN, MonthCache, build_day, start_odds
from .raw_turnover import (
    HK_HOLIDAYS, KEY, STEP, _int_keys, _lagged_money, _line_vs_theta, _num, _write,
    align_day, backtest_root, wape,
)

RED_IN = 57
POWER = 1.5
ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)
KO_KNOTS = (0.0, 5.0, 10.0, 15.0, 30.0, 45.0, 60.0, 90.0, 120.0, 180.0, 240.0, 360.0)
MIN_KNOTS = (5.0, 15.0, 30.0, 40.0, 45.0, 50.0, 60.0, 70.0, 80.0, 88.0, 95.0)
LEAGUE_PRIOR = 50.0      # match-buckets of evidence before a league moves halfway
MATCH_PRIOR = 4.0        # buckets of evidence before a match moves halfway
MATCH_PRIOR_NEW = 1.5    # a league never seen in training: trust the match's own buckets sooner
POOL_PRIOR = 300.0       # selection-buckets of evidence before a pool moves halfway

# Bet types are described by what they are, so a pool never seen in training
# still gets the effect of its family. Its own effect is then learned from data.
FAMILIES = ("goal_total", "goal_hdc", "goal_1x2", "corner_total", "corner_hdc", "sga", "other")

MATCH_FEATURES = [
    "m_log_l1", "m_log_l2", "m_log_l3", "m_any_l1", "m_log_today",
    "inplay", "halftime", "pre_ko_clip", "minute_clip",
    *["ko_h{}".format(i) for i in range(len(KO_KNOTS))],
    *["min_h{}".format(i) for i in range(len(MIN_KNOTS))],
    "goal_p3", "goal_p10", "red_p10", "goals_so_far",
    "n_live", "log_board_l1", "match_share_board_l1",
    "weekend", "holiday", "hour_s1", "hour_c1", "hour_s2", "hour_c2", "dow_s", "dow_c",
    "tg", "abs_sup", "n_pools_open", "n_lines_open",
]
SHARE_FEATURES = [
    # the selection's own money, and the money of whatever sat in its position
    "s_share_l1", "s_share_l2", "s_share_l3", "s_share_ewma", "s_log_l1", "s_any_l1",
    "pos_share_l1", "pos_share_l2", "best_moved", "line_age",
    "rank_0", "rank_1", "rank_2", "rank_3p", "n_lines",
    # price
    "imp", "log_odds", "true_imp", "hk_vs_mkt", "has_mkt", "odds_move_5", "odds_move_15",
    "near_main", "abs_line_gap",
    # what kind of bet
    *["fam_{}".format(k) for k in FAMILIES], "first_half",
    *["fam_{}_ip".format(k) for k in FAMILIES],
]


def family(pool: str) -> str:
    p = str(pool).upper()
    if p == "SGA":
        return "sga"
    corner = p.startswith(("C", "FC", "ETC"))
    if "HDC" in p or p.endswith("DC"):
        return "corner_hdc" if corner else "goal_hdc"
    if "LO" in p:
        return "corner_total" if corner else "goal_total"
    if "HAD" in p:
        return "goal_1x2"
    return "other"


# ------------------------------------------------------------- raw inputs
def _market_start(market: pd.DataFrame) -> pd.DataFrame:
    """Median across bookmakers of the last market odds per 5-minute bucket."""
    need = ["match_id", "pool_id", "line_id", "combination_id", "odds", "effective_datetime"]
    if market is None or market.empty or any(c not in market.columns for c in need):
        return pd.DataFrame(columns=["pool_id", "line_id", "combination_id", "_at", "mkt_odds"])
    m = market.dropna(subset=["odds", "effective_datetime"]).copy()
    m = _int_keys(m)
    m = m[m["odds"] > 1.0]
    m["_at"] = m["effective_datetime"].dt.floor("5min")
    book = "bookmaker" if "bookmaker" in m.columns else None
    by = ["pool_id", "line_id", "combination_id", "_at"] + ([book] if book else [])
    last = m.sort_values("effective_datetime").groupby(by, observed=True)["odds"].last().reset_index()
    out = last.groupby(["pool_id", "line_id", "combination_id", "_at"], observed=True)["odds"] \
        .median().rename("mkt_odds").reset_index()
    out["_at"] = pd.to_datetime(out["_at"]).astype("datetime64[ns]")
    return out


def _asof_before(f: pd.DataFrame, right: pd.DataFrame, value: str, by: List[str],
                 lag: pd.Timedelta = pd.Timedelta(0)) -> np.ndarray:
    """``value`` from the last ``right`` bucket strictly before (bucket - lag)."""
    out = np.full(len(f), np.nan)
    if right is None or right.empty:
        return out
    left = f[by + ["bucket"]].copy()
    left["_row"] = np.arange(len(f))
    left["_at"] = (left["bucket"] - lag).astype("datetime64[ns]")
    left = left.sort_values("_at")
    r = right.sort_values("_at")
    m = pd.merge_asof(left, r[by + ["_at", value]], on="_at", by=by,
                      direction="backward", allow_exact_matches=False)
    out[m["_row"].to_numpy()] = m[value].to_numpy(dtype="float64")
    return out


def _pulses(f: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    """Decaying goal / red-card pulses and goals so far, per match-bucket."""
    mb = f[["match_id", "bucket"]].drop_duplicates().reset_index(drop=True)
    for c in ("goal_p3", "goal_p10", "red_p10", "goals_so_far"):
        mb[c] = 0.0
    if events is None or events.empty or "incident_type" not in events.columns:
        return mb
    ev = events.dropna(subset=["match_id", "incident_datetime", "incident_type"]).copy()
    if "provider_id" in ev.columns and (ev["provider_id"] == 1).any():
        ev = ev[ev["provider_id"] == 1]
    ev["match_id"] = pd.to_numeric(ev["match_id"], errors="coerce").fillna(-1).astype("int64")
    ev["incident_type"] = pd.to_numeric(ev["incident_type"], errors="coerce")
    ev["t"] = pd.to_datetime(ev["incident_datetime"]).astype("datetime64[ns]")
    goals = {m: np.sort(g["t"].to_numpy()) for m, g in ev[ev["incident_type"] == GOAL_IN].groupby("match_id")}
    reds = {m: np.sort(g["t"].to_numpy()) for m, g in ev[ev["incident_type"] == RED_IN].groupby("match_id")}
    mids = mb["match_id"].to_numpy()
    buckets = mb["bucket"].to_numpy(dtype="datetime64[ns]")
    gp3 = np.zeros(len(mb))
    gp10 = np.zeros(len(mb))
    rp10 = np.zeros(len(mb))
    gsf = np.zeros(len(mb))
    for i in range(len(mb)):
        t = goals.get(mids[i])
        if t is not None and len(t):
            past = t[t < buckets[i]]
            if len(past):
                age = (buckets[i] - past).astype("timedelta64[s]").astype("float64") / 60.0
                gp3[i] = np.exp(-age / 3.0).sum()
                gp10[i] = np.exp(-age / 10.0).sum()
                gsf[i] = len(past)
        r = reds.get(mids[i])
        if r is not None and len(r):
            past = r[r < buckets[i]]
            if len(past):
                age = (buckets[i] - past).astype("timedelta64[s]").astype("float64") / 60.0
                rp10[i] = np.exp(-age / 10.0).sum()
    mb["goal_p3"], mb["goal_p10"], mb["red_p10"], mb["goals_so_far"] = gp3, gp10, rp10, gsf
    return mb


def _hinges(x: np.ndarray, knots: Sequence[float], prefix: str) -> Dict[str, np.ndarray]:
    return {"{}{}".format(prefix, i): np.maximum(x - k, 0.0) for i, k in enumerate(knots)}


# ---------------------------------------------------------------- features
def _match_money(agg: pd.DataFrame, pool_match: pd.DataFrame) -> pd.DataFrame:
    """Every selection's money summed to (match, bucket), from Match_Investments."""
    money = _int_keys(agg[["pool_id", "bucket", "turnover"]].copy())
    money["bucket"] = pd.to_datetime(money["bucket"]).astype("datetime64[ns]")
    money = money.merge(pool_match, on="pool_id", how="inner")
    return money.groupby(["match_id", "bucket"], observed=True, as_index=False)["turnover"].sum()


def _shifted(frame: pd.DataFrame, keys: List[str], value: str, k: int, name: str) -> pd.DataFrame:
    out = frame[keys + ["bucket", value]].rename(columns={value: name})
    return out.assign(bucket=out["bucket"] + k * STEP)


def build_day_features(cfg: Config, day: pd.Timestamp, mc: MonthCache, pools_df: pd.DataFrame,
                       matches_df: pd.DataFrame, market: pd.DataFrame,
                       prev: Optional[pd.DataFrame], base: Optional[pd.DataFrame] = None):
    """Selection rows and match-bucket rows for one day. Returns (sel, match, tail).

    ``base`` is the day's panel with start-of-bucket odds already applied, when
    the caller has built it; otherwise it is built here.

    Every feature of bucket T uses only what was known at the start of T:
    money and prices from earlier buckets, prices posted before T, TG/SUP and
    incidents time-stamped before T. The label is the money in T.

    ``modelled`` marks the rows the model forecasts: inside the pre-match
    window (or in play), and priced before T. A line whose first price came
    inside T was not on the board at T; its money still counts in the match
    total and is spread over the lines that were. Rows outside the window are
    only in the panel because they took money, so their presence is the label;
    they keep last 5 min.
    """
    if base is None:
        base = build_day(cfg, day, mc, pools_df, matches_df, prices=False)
        if base is None or base.empty:
            return pd.DataFrame(), pd.DataFrame(), None
        base = start_odds(cfg, base, prev)
    if base.empty:
        return pd.DataFrame(), pd.DataFrame(), None
    tail_cols = [c for c in ("pool_id", "line_id", "combination_id", "bucket", "odds", "true_odds")
                 if c in base.columns]
    tail = base.loc[pd.to_datetime(base["bucket"]) >= pd.Timestamp(day) + pd.Timedelta(hours=18), tail_cols]

    f = _int_keys(base.copy())
    f["bucket"] = pd.to_datetime(f["bucket"]).astype("datetime64[ns]")
    f = f.drop_duplicates(KEY + ["bucket"]).reset_index(drop=True)
    f = _lagged_money(f, mc.agg)
    for k in (1, 2, 3):
        f["tv{}".format(k)] = np.clip(f["tv{}".format(k)].to_numpy(dtype="float64"), 0, None)
    f["y"] = np.clip(_num(f, "turnover", 0.0), 0, None)

    inplay_row = f["is_inplay"].fillna(False).astype(bool).to_numpy() if "is_inplay" in f.columns \
        else np.zeros(len(f), dtype=bool)
    mins_ko = _num(f, "mins_to_ko")
    in_window = inplay_row | (np.isfinite(mins_ko) & (mins_ko <= cfg.prematch_window_min))
    priced = f["priced_before"].fillna(False).astype(bool).to_numpy() if "priced_before" in f.columns \
        else np.ones(len(f), dtype=bool)
    f["modelled"] = in_window & priced
    f["_win"] = in_window

    by = ["pool_id", "line_id", "combination_id"]
    ob = _int_keys(mc.odds_bucket[by + ["bucket", "odds"]].dropna().copy())
    ob["_at"] = pd.to_datetime(ob["bucket"]).astype("datetime64[ns]")
    od = _num(f, "odds")
    od = np.where(np.isfinite(od) & (od > 1), od, 2.0)
    od5 = _asof_before(f, ob, "odds", by, lag=STEP)
    od15 = _asof_before(f, ob, "odds", by, lag=3 * STEP)
    od5 = np.where(np.isfinite(od5) & (od5 > 1), od5, od)
    od15 = np.where(np.isfinite(od15) & (od15 > 1), od15, od5)
    mkt = _asof_before(f, _market_start(market), "mkt_odds", by)
    first_price = ob.groupby(by, observed=True)["_at"].min().rename("_first").reset_index()
    f = f.merge(first_price, on=by, how="left")
    age = (f["bucket"] - (f["_first"] + STEP)).dt.total_seconds().to_numpy() / 60.0
    line_age = np.where(np.isfinite(age), np.clip(age, 0, 600), 0.0) / 600.0

    # ---------------- match table: in-window match-buckets only
    mkey = ["match_id", "bucket"]
    pool_match = f[["pool_id", "match_id"]].drop_duplicates("pool_id")
    mm = _match_money(mc.agg, pool_match)
    win = f[f["_win"]]
    m = win.groupby(mkey, observed=True).agg(y=("y", "sum")).reset_index()
    first = win.groupby(mkey, observed=True).first().reset_index()
    for c in ("league_code", "is_inplay", "match_minute", "mins_to_ko", "tg", "sup"):
        m[c] = first[c].to_numpy() if c in first.columns else np.nan
    for k, name in ((1, "l1"), (2, "l2"), (3, "l3")):
        m = m.merge(_shifted(mm, ["match_id"], "turnover", k, name), on=mkey, how="left")
        m[name] = m[name].fillna(0.0)
    # money the match took today, up to the end of the previous bucket
    day0 = pd.Timestamp(day)
    mm_day = mm[(mm["bucket"] >= day0) & (mm["bucket"] < day0 + pd.Timedelta(days=1))].sort_values(mkey)
    mm_day = mm_day.assign(today=mm_day.groupby("match_id", observed=True)["turnover"].cumsum())
    m = m.merge(_shifted(mm_day, ["match_id"], "today", 1, "today"), on=mkey, how="left")
    m = m.sort_values(mkey).reset_index(drop=True)
    m["today"] = m.groupby("match_id", observed=True)["today"].ffill().fillna(0.0)
    m = m.merge(_pulses(f, mc.events), on=mkey, how="left")
    board_all = mm.groupby("bucket", observed=True)["turnover"].sum()
    board = m["bucket"].map(board_all.rename(lambda b: b + STEP)).fillna(0.0).to_numpy(dtype="float64")
    n_live = m.groupby("bucket", observed=True)["match_id"].transform("nunique").to_numpy(dtype="float64")
    live_rows = f[f["modelled"]]
    pools_open = live_rows.groupby(mkey, observed=True).agg(
        n_pools_open=("pool_id", "nunique"), n_lines_open=("line_id", "nunique")).reset_index()
    m = m.merge(pools_open, on=mkey, how="left")

    inplay = m["is_inplay"].fillna(False).astype(float).to_numpy()
    minute = np.nan_to_num(pd.to_numeric(m["match_minute"], errors="coerce").to_numpy(dtype="float64"), nan=0.0)
    pre = np.clip(np.nan_to_num(pd.to_numeric(m["mins_to_ko"], errors="coerce").to_numpy(dtype="float64"),
                                nan=360.0), 0, 360)
    b = pd.to_datetime(m["bucket"])
    hour = (b.dt.hour + b.dt.minute / 60.0).to_numpy()
    dow = b.dt.dayofweek.to_numpy()
    l1 = m["l1"].to_numpy(dtype="float64")
    cols = {
        "m_log_l1": np.log1p(l1),
        "m_log_l2": np.log1p(m["l2"].to_numpy(dtype="float64")),
        "m_log_l3": np.log1p(m["l3"].to_numpy(dtype="float64")),
        "m_any_l1": (l1 > 0).astype(float),
        "m_log_today": np.log1p(m["today"].to_numpy(dtype="float64")),
        "inplay": inplay,
        "halftime": ((inplay > 0) & (minute >= 45) & (minute < 46)).astype(float),
        "pre_ko_clip": (1 - inplay) * pre / 360.0,
        "minute_clip": inplay * np.clip(minute, 0, 120) / 90.0,
        "goal_p3": m["goal_p3"].fillna(0.0).to_numpy(dtype="float64"),
        "goal_p10": m["goal_p10"].fillna(0.0).to_numpy(dtype="float64"),
        "red_p10": m["red_p10"].fillna(0.0).to_numpy(dtype="float64"),
        "goals_so_far": m["goals_so_far"].fillna(0.0).to_numpy(dtype="float64"),
        "n_live": n_live / 50.0,
        "log_board_l1": np.log1p(board),
        "match_share_board_l1": np.where(board > 0, l1 / np.maximum(board, 1e-9), 0.0),
        "weekend": (dow >= 5).astype(float),
        "holiday": b.dt.date.map(lambda d: 1.0 if d in HK_HOLIDAYS else 0.0).to_numpy(),
        "hour_s1": np.sin(2 * np.pi * hour / 24), "hour_c1": np.cos(2 * np.pi * hour / 24),
        "hour_s2": np.sin(4 * np.pi * hour / 24), "hour_c2": np.cos(4 * np.pi * hour / 24),
        "dow_s": np.sin(2 * np.pi * dow / 7), "dow_c": np.cos(2 * np.pi * dow / 7),
        "tg": np.nan_to_num(pd.to_numeric(m["tg"], errors="coerce").to_numpy(dtype="float64"), nan=2.6),
        "abs_sup": np.abs(np.nan_to_num(pd.to_numeric(m["sup"], errors="coerce").to_numpy(dtype="float64"), nan=0.0)),
        "n_pools_open": np.log1p(m["n_pools_open"].fillna(0).to_numpy(dtype="float64")),
        "n_lines_open": np.log1p(m["n_lines_open"].fillna(0).to_numpy(dtype="float64")),
    }
    cols.update({k: (1 - inplay) * v for k, v in _hinges(pre, KO_KNOTS, "ko_h").items()})
    cols.update({k: inplay * v for k, v in _hinges(minute, MIN_KNOTS, "min_h").items()})
    match = pd.concat([m[mkey + ["y", "league_code"]].reset_index(drop=True),
                       pd.DataFrame(cols)[MATCH_FEATURES].astype("float32")], axis=1)
    match["l1"] = l1.astype("float32")
    match["league_code"] = match["league_code"].astype("string").fillna("unknown")

    # ---------------- selection table
    tot = {}
    for k, name in ((1, "l1"), (2, "l2"), (3, "l3")):
        t = _shifted(mm, ["match_id"], "turnover", k, name)
        tot[k] = f[mkey].merge(t, on=mkey, how="left")[name].fillna(0.0).to_numpy(dtype="float64")
    share = {k: np.where(tot[k] > 0, f["tv{}".format(k)].to_numpy(dtype="float64") / np.maximum(tot[k], 1e-9),
                         np.nan) for k in (1, 2, 3)}
    n_mod = f.groupby(mkey, observed=True)["modelled"].transform("sum").to_numpy(dtype="float64")
    flat = 1.0 / np.maximum(n_mod, 1.0)
    wsum = 0.6 * np.isfinite(share[1]) + 0.25 * np.isfinite(share[2]) + 0.15 * np.isfinite(share[3])
    ewma = (0.6 * np.nan_to_num(share[1]) + 0.25 * np.nan_to_num(share[2]) + 0.15 * np.nan_to_num(share[3]))
    ewma = np.where(wsum > 0, ewma / np.maximum(wsum, 1e-9), flat)

    # line position among lines on the board at T: 0 = best (sides closest)
    pkey = ["match_id", "pool_name", "bucket"]
    lkey = ["match_id", "pool_name", "line_id", "bucket"]
    imp = 1.0 / od
    f["_imp"] = imp
    live = f["modelled"].to_numpy()
    g = f.loc[live].groupby(lkey, observed=True)["_imp"]
    gap = (g.max() - g.min()).rename("_gap").reset_index()
    gap["rank"] = gap.groupby(pkey, observed=True)["_gap"].rank(method="first").astype(int) - 1
    f = f.merge(gap[lkey + ["rank"]], on=lkey, how="left")
    f["rank"] = f["rank"].fillna(-1).astype(int)
    n_lines = f.loc[f["modelled"]].groupby(pkey, observed=True)["line_id"].nunique().rename("_nl").reset_index()
    f = f.merge(n_lines, on=pkey, how="left")

    # money that sat in the same position (pool, rank, side) one and two buckets
    # earlier, whichever line it was: money follows the main line when it moves
    pos_keys = ["match_id", "pool_name", "rank", "combination_id"]
    pos = f.loc[f["modelled"], pos_keys + ["bucket", "y"]]
    pos = pos.groupby(pos_keys + ["bucket"], observed=True, as_index=False)["y"].sum()
    for k, name in ((1, "_pos1"), (2, "_pos2")):
        f = f.merge(_shifted(pos, pos_keys, "y", k, name), on=pos_keys + ["bucket"], how="left")
    pos1 = np.where(tot[1] > 0, f["_pos1"].fillna(0.0).to_numpy(dtype="float64") / np.maximum(tot[1], 1e-9), np.nan)
    pos2 = np.where(tot[2] > 0, f["_pos2"].fillna(0.0).to_numpy(dtype="float64") / np.maximum(tot[2], 1e-9), np.nan)
    best = f.loc[f["rank"] == 0, pkey + ["line_id"]].drop_duplicates(pkey).rename(columns={"line_id": "_best"})
    prev_best = _shifted(best, ["match_id", "pool_name"], "_best", 1, "_best_prev")
    f = f.merge(best, on=pkey, how="left").merge(prev_best, on=pkey, how="left")
    moved = (f["_best"].notna() & f["_best_prev"].notna() & (f["_best"] != f["_best_prev"])).to_numpy()

    true = _num(f, "true_odds")
    lv, corner, handicap = _line_vs_theta(f)
    rank = f["rank"].to_numpy()
    pool_s = f["pool_name"].astype(str)
    pool = pool_s.to_numpy()
    fam = pool_s.map({p: family(p) for p in pool_s.unique()}).to_numpy()
    inplay_s = f["is_inplay"].fillna(False).astype(float).to_numpy() if "is_inplay" in f.columns else np.zeros(len(f))
    lsum = f.groupby(lkey, observed=True)["_imp"].transform("sum").to_numpy(dtype="float64")
    s = {
        "s_share_l1": np.nan_to_num(share[1], nan=flat), "s_share_l2": np.nan_to_num(share[2], nan=flat),
        "s_share_l3": np.nan_to_num(share[3], nan=flat), "s_share_ewma": ewma,
        "s_log_l1": np.log1p(f["tv1"].to_numpy(dtype="float64")),
        "s_any_l1": (f["tv1"].to_numpy() > 0).astype(float),
        "pos_share_l1": np.nan_to_num(pos1, nan=flat), "pos_share_l2": np.nan_to_num(pos2, nan=flat),
        "best_moved": moved.astype(float), "line_age": line_age,
        "rank_0": (rank == 0).astype(float), "rank_1": (rank == 1).astype(float),
        "rank_2": (rank == 2).astype(float), "rank_3p": (rank >= 3).astype(float),
        "n_lines": np.log1p(f["_nl"].fillna(0).to_numpy(dtype="float64")),
        "imp": imp, "log_odds": np.log(od),
        "true_imp": np.where(np.isfinite(true) & (true > 1), 1.0 / np.where(true > 1, true, 2.0),
                             imp / np.maximum(lsum, 1e-9)),
        "hk_vs_mkt": np.where(np.isfinite(mkt) & (mkt > 1), 1.0 / od - 1.0 / np.where(mkt > 1, mkt, 2.0), 0.0),
        "has_mkt": (np.isfinite(mkt) & (mkt > 1)).astype(float),
        "odds_move_5": np.log(od) - np.log(od5), "odds_move_15": np.log(od) - np.log(od15),
        "near_main": (np.abs(lv) < 0.5).astype(float), "abs_line_gap": np.minimum(np.abs(lv), 4.0),
        "first_half": pool_s.str.upper().str.startswith(("FH", "FC")).to_numpy(dtype=float),
    }
    for k in FAMILIES:
        s["fam_{}".format(k)] = (fam == k).astype(float)
        s["fam_{}_ip".format(k)] = ((fam == k) & (inplay_s > 0)).astype(float)
    sel = pd.concat([f[KEY + ["bucket"]].reset_index(drop=True),
                     pd.DataFrame(s)[SHARE_FEATURES].astype("float32")], axis=1)
    sel["y"] = f["y"].to_numpy(dtype="float32")
    sel["last5"] = f["tv1"].to_numpy(dtype="float32")
    sel["modelled"] = f["modelled"].to_numpy()
    sel["pool_key"] = pd.Series(pool).str.upper() + np.where(inplay_s > 0, "|ip", "|pre")
    sel = sel.replace([np.inf, -np.inf], 0.0)
    match = match.replace([np.inf, -np.inf], 0.0)
    return sel, match, tail


# ------------------------------------------------------------------- GLM
def glm_fit(x: np.ndarray, y: np.ndarray, offset: Optional[np.ndarray] = None,
            power: float = POWER, lam: float = 1e-3, iters: int = 25) -> dict:
    """Tweedie (power 1..2) or Poisson (power 1) GLM, log link, ridge, by IRLS."""
    x = np.asarray(x, dtype="float64")
    y = np.clip(np.asarray(y, dtype="float64"), 0, None)
    off = np.zeros(len(y)) if offset is None else np.asarray(offset, dtype="float64")
    mean = x.mean(axis=0)
    std = x.std(axis=0)
    std[std < 1e-8] = 1.0
    z = np.column_stack([np.ones(len(x)), (x - mean) / std])
    beta = np.zeros(z.shape[1])
    ybar = max(float(np.mean(y)), 1e-6)
    beta[0] = np.log(ybar) - float(np.mean(off))
    pen = np.eye(z.shape[1])
    pen[0, 0] = 0.0
    null_dev = tweedie_dev(y, np.full(len(y), ybar) * np.exp(off - np.mean(off)), power)
    trace = []
    for it in range(iters):
        eta = np.clip(z @ beta + off, -30, 25)
        mu = np.exp(eta)
        trace.append({"iter": it, "deviance": tweedie_dev(y, mu, power)})
        w = mu ** (2.0 - power)
        work = eta - off + (y - mu) / np.maximum(mu, 1e-12)
        zw = z * w[:, None]
        a = z.T @ zw
        scale = float(np.trace(a)) / a.shape[0]
        new = np.linalg.solve(a + lam * scale * pen, zw.T @ work)
        step = float(np.max(np.abs(new - beta)))
        trace[-1]["step"] = step
        beta = new
        if step < 1e-7:
            break
    mu = np.exp(np.clip(z @ beta + off, -30, 25))
    dev = tweedie_dev(y, mu, power)
    return {"beta": beta, "mean": mean, "std": std, "trace": trace, "power": power,
            "rows": int(len(y)), "deviance": dev, "null_deviance": null_dev,
            "explained": 1.0 - dev / null_dev if null_dev > 0 else None}


def tweedie_dev(y, mu, power: float) -> float:
    """Mean unit deviance. power 1 is Poisson."""
    y = np.asarray(y, dtype="float64")
    mu = np.maximum(np.asarray(mu, dtype="float64"), 1e-9)
    if abs(power - 1.0) < 1e-9:
        d = 2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))
    else:
        p = power
        d = 2.0 * (np.power(y, 2 - p) / ((1 - p) * (2 - p)) - y * np.power(mu, 1 - p) / (1 - p)
                   + np.power(mu, 2 - p) / (2 - p))
    return float(np.mean(d))


def glm_eta(model: dict, x: np.ndarray) -> np.ndarray:
    z = np.column_stack([np.ones(len(x)), (np.asarray(x, dtype="float64") - model["mean"]) / model["std"]])
    return np.clip(z @ model["beta"], -30, 25)


def poisson_dev(y, mu) -> float:
    y = np.asarray(y, dtype="float64")
    mu = np.maximum(np.asarray(mu, dtype="float64"), 1.0)
    return float(np.mean(2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))))


class TwoLevel:
    def __init__(self):
        self.match_glm = None
        self.share_glm = None
        self.league: Dict[str, float] = {}
        self.pool: Dict[str, float] = {}
        self.alpha = 0.0

    def fit(self, match: pd.DataFrame, sel: pd.DataFrame) -> None:
        xm = match[MATCH_FEATURES].to_numpy(dtype="float64")
        ym = match["y"].to_numpy(dtype="float64")
        self.match_glm = glm_fit(xm, ym, power=POWER)
        mu = np.exp(glm_eta(self.match_glm, xm))
        # league random intercept, shrunk toward 1
        g = pd.DataFrame({"lg": match["league_code"].astype(str).to_numpy(), "y": ym, "mu": mu}) \
            .groupby("lg")[["y", "mu"]].sum()
        prior = LEAGUE_PRIOR * float(np.mean(mu))
        self.league = ((g["y"] + prior) / (g["mu"] + prior)).clip(0.2, 5.0).to_dict()

        # shares: Poisson with the match's actual total as offset, on the rows
        # that were on the board at T. Money on lines that opened inside T is
        # in the offset, so it is spread over the lines that existed.
        tot = sel["m_y"].to_numpy(dtype="float64")
        keep = (tot > 0) & sel["modelled"].to_numpy(dtype=bool)
        xs = sel.loc[keep, SHARE_FEATURES].to_numpy(dtype="float64")
        self.share_glm = glm_fit(xs, sel.loc[keep, "y"].to_numpy(dtype="float64"),
                                 offset=np.log(tot[keep]), power=1.0)
        # pool (and in-play vs pre-match) random effect, shrunk toward the
        # family the GLM already knows. A pool never seen stays at 1.
        self.pool = {}
        fitted = self.selection(sel, np.nan_to_num(tot, nan=0.0))
        mod = sel["modelled"].to_numpy(dtype=bool)
        pg = pd.DataFrame({"k": sel.loc[mod, "pool_key"].astype(str).to_numpy(),
                           "y": sel.loc[mod, "y"].to_numpy(dtype="float64"),
                           "p": fitted[mod]}).groupby("k")[["y", "p"]].sum()
        pprior = POOL_PRIOR * float(np.mean(fitted[mod])) if mod.any() else 1.0
        self.pool = ((pg["y"] + pprior) / (pg["p"] + pprior)).clip(0.2, 5.0).to_dict()

    def match_total(self, match: pd.DataFrame) -> np.ndarray:
        """Fixed effects x league x this match's own shrunk residual so far today.

        The match effect for bucket T uses the match's money in buckets before
        T only, which is already settled at T.
        """
        xm = match[MATCH_FEATURES].to_numpy(dtype="float64")
        mu = np.exp(glm_eta(self.match_glm, xm))
        lg = match["league_code"].astype(str)
        seen = lg.isin(list(self.league)).to_numpy()
        u = lg.map(self.league).fillna(1.0).to_numpy(dtype="float64")
        mu = mu * u
        frame = pd.DataFrame({"match_id": match["match_id"].to_numpy(), "bucket": match["bucket"].to_numpy(),
                              "y": match["y"].to_numpy(dtype="float64"), "mu": mu,
                              "k": np.where(seen, MATCH_PRIOR, MATCH_PRIOR_NEW)})
        frame = frame.reset_index().sort_values(["match_id", "bucket"])
        grp = frame.groupby("match_id", observed=True)
        cy = grp["y"].cumsum() - frame["y"]
        cm = grp["mu"].cumsum() - frame["mu"]
        prior = frame["k"] * frame["mu"].clip(lower=1.0)
        frame["u"] = ((cy + prior) / (cm + prior)).clip(0.2, 5.0)
        frame = frame.sort_values("index")
        return frame["mu"].to_numpy() * frame["u"].to_numpy()

    def selection(self, sel: pd.DataFrame, total: np.ndarray) -> np.ndarray:
        """Split each match total over the selections on the board at T.

        ``sel`` must hold every selection of each match-bucket it contains.
        Rows not on the board at T get 0 from here.
        """
        eta = glm_eta(self.share_glm, sel[SHARE_FEATURES].to_numpy(dtype="float64"))
        w = np.exp(eta - eta.max())
        if self.pool:
            w = w * sel["pool_key"].astype(str).map(self.pool).fillna(1.0).to_numpy(dtype="float64")
        w = np.where(sel["modelled"].to_numpy(dtype=bool), w, 0.0)
        den = pd.Series(w).groupby([sel["match_id"].to_numpy(), sel["bucket"].to_numpy()]) \
            .transform("sum").to_numpy()
        return np.where(den > 0, total * w / np.maximum(den, 1e-300), 0.0)

    def level(self, sel: pd.DataFrame, match: pd.DataFrame) -> np.ndarray:
        tot = pd.Series(self.match_total(match),
                        index=pd.MultiIndex.from_frame(match[["match_id", "bucket"]]))
        t = pd.MultiIndex.from_frame(sel[["match_id", "bucket"]]).map(tot).to_numpy(dtype="float64")
        return np.clip(self.selection(sel, np.nan_to_num(t, nan=0.0)), 0, None)

    def predict(self, sel, match) -> np.ndarray:
        """Model on rows on the board at T, last 5 min everywhere else."""
        lag = np.clip(sel["last5"].to_numpy(dtype="float64"), 0, None)
        if self.match_glm is None or self.alpha <= 0:
            return lag
        mod = sel["modelled"].to_numpy(dtype=bool)
        return np.where(mod, self.alpha * self.level(sel, match) + (1 - self.alpha) * lag, lag)

    def pick_alpha(self, sel, match) -> Dict[str, float]:
        mod = sel["modelled"].to_numpy(dtype=bool)
        y = sel["y"].to_numpy(dtype="float64")[mod]
        lag = np.clip(sel["last5"].to_numpy(dtype="float64"), 0, None)[mod]
        lev = self.level(sel, match)[mod]
        scores = {str(a): poisson_dev(y, a * lev + (1 - a) * lag) for a in ALPHAS}
        best = min(ALPHAS, key=lambda a: scores[str(a)])
        self.alpha = float(best) if scores[str(best)] < scores["0.0"] * (1 - 1e-6) else 0.0
        return scores


def _sample_groups(sel: pd.DataFrame, cap: int, rng) -> pd.DataFrame:
    """Whole match-buckets, never part of one, so shares still sum to one."""
    if len(sel) <= cap:
        return sel
    keys = sel[["match_id", "bucket"]].drop_duplicates()
    frac = cap / len(sel)
    keep = keys.iloc[np.flatnonzero(rng.random(len(keys)) < frac)]
    return sel.merge(keep, on=["match_id", "bucket"], how="inner")


def _with_match_y(sel: pd.DataFrame, match: pd.DataFrame) -> pd.DataFrame:
    t = pd.Series(match["y"].to_numpy(dtype="float64"),
                  index=pd.MultiIndex.from_frame(match[["match_id", "bucket"]]))
    sel = sel.copy()
    sel["m_y"] = pd.MultiIndex.from_frame(sel[["match_id", "bucket"]]).map(t).to_numpy(dtype="float64")
    return sel


def _scores(y, pred, last5, sel) -> dict:
    out = {"wape_sel_last5": wape(y, last5), "wape_sel_model": wape(y, pred),
           "dev_last5": poisson_dev(y, last5), "dev_model": poisson_dev(y, pred),
           "sum_y": float(np.sum(y)), "sum_last5": float(np.sum(last5)), "sum_model": float(np.sum(pred))}
    g = pd.DataFrame({"m": sel["match_id"].to_numpy(), "b": sel["bucket"].to_numpy(),
                      "y": y, "p": pred, "l": last5}).groupby(["m", "b"])[["y", "p", "l"]].sum()
    out["wape_match_last5"] = wape(g["y"], g["l"])
    out["wape_match_model"] = wape(g["y"], g["p"])
    return out


# -------------------------------------------------------------------- run
def train(cfg: Config, name: str = "glm", warmup_days: int = 14, inner_days: int = 7,
          refit_every: int = 7, per_day: int = 60000, refresh: bool = False, seed: int = 7) -> dict:
    root = backtest_root(cfg)
    feat_dir = root / "Features_glm2"
    days = day_list(cfg.start_date, cfg.end_date)
    rng = np.random.default_rng(seed)
    model: Optional[TwoLevel] = None
    store: List[dict] = []
    since = 0
    daily = []
    tot = {k: 0.0 for k in ("y", "sel_l", "sel_m", "match_l", "match_m", "p_l", "p_m", "dev_l", "dev_m", "n")}
    started = time.time()
    static = None
    prev_tail = None
    by_month: Dict[pd.Timestamp, List[pd.Timestamp]] = {}
    for d in days:
        by_month.setdefault(d.to_period("M").start_time, []).append(d)

    for m_start, want in by_month.items():
        mc = None
        market = None
        for day in want:
            key = "{:%Y-%m-%d}".format(day)
            sp, mp = feat_dir / "{}.sel.parquet".format(key), feat_dir / "{}.match.parquet".format(key)
            if sp.exists() and mp.exists() and not refresh:
                sel, match = pd.read_parquet(sp), pd.read_parquet(mp)
                src = "features"
            else:
                if static is None:
                    print("[raw] loading Pool_Details and Match_Information", flush=True)
                    static = load_static(cfg.data_dir, days[0], days[-1] + pd.Timedelta(days=1))
                if mc is None:
                    print("[raw] reading Raw_Data for {:%Y-%m}".format(m_start), flush=True)
                    m_end = m_start + pd.offsets.MonthBegin(1)
                    mc = MonthCache(cfg, min(want), m_end)
                    try:
                        market = load_window(cfg.data_dir, "market",
                                             min(want) - pd.Timedelta(days=cfg.lookback_days), m_end)
                    except Exception as exc:                        # noqa: BLE001
                        print("[raw] Market_Odds not read ({}); HKJC-vs-market is 0".format(exc), flush=True)
                        market = pd.DataFrame()
                sel, match, prev_tail = build_day_features(cfg, day, mc, static[0], static[1],
                                                           market, prev_tail)
                if not sel.empty:
                    _write(sp, sel)
                    _write(mp, match)
                src = "raw"
            if sel.empty:
                print("[skip] {} no rows".format(key), flush=True)
                continue
            y = sel["y"].to_numpy(dtype="float64")
            last5 = sel["last5"].to_numpy(dtype="float64")
            pred = model.predict(sel, match) if model is not None else np.clip(last5, 0, None)
            keyed = sel[KEY + ["bucket"]].copy()
            keyed["value"] = pred.astype("float32")
            _write(root / "Turnover" / name / "_keyed" / "{}.parquet".format(key), keyed)
            aligned = align_day(root, name, key)
            sc = _scores(y, pred, last5, sel)
            row = {"day": key, "rows": int(len(sel)), "source": src, "scored": model is not None, **sc}
            if aligned is not None:
                row["backtest_rows"], row["backtest_matched"] = aligned["rows"], aligned["matched"]
            daily.append(row)
            if model is not None:
                tot["y"] += sc["sum_y"]
                tot["p_l"] += sc["sum_last5"]
                tot["p_m"] += sc["sum_model"]
                tot["sel_l"] += float(np.abs(y - last5).sum())
                tot["sel_m"] += float(np.abs(y - pred).sum())
                tot["match_l"] += sc["wape_match_last5"] * sc["sum_y"]
                tot["match_m"] += sc["wape_match_model"] * sc["sum_y"]
                tot["dev_l"] += sc["dev_last5"] * len(y)
                tot["dev_m"] += sc["dev_model"] * len(y)
                tot["n"] += len(y)
            print("[{}] {} rows={:,}  per match: last5 {:.1%} {} {:.1%}  deviance: last5 {:,.0f} {} {:,.0f}"
                  "  bias {} {:+.1%}{} ({:.0f}s)".format(
                      "score" if model is not None else "warmup", key, len(sel),
                      sc["wape_match_last5"], name, sc["wape_match_model"],
                      sc["dev_last5"], name, sc["dev_model"], name,
                      (sc["sum_model"] / sc["sum_y"] - 1) if sc["sum_y"] else 0.0,
                      "" if aligned is None else "  -> backtest {:,}/{:,}".format(aligned["matched"], aligned["rows"]),
                      time.time() - started), flush=True)

            store.append({"sel": _with_match_y(_sample_groups(sel, per_day, rng), match),
                          "match": match})
            since += 1
            if len(store) >= warmup_days and (model is None or since >= refit_every):
                model = _refit(store, inner_days)
                since = 0
        mc = None
        market = None

    rep = {"name": name, "model": "tweedie GLM x share GLM, league + match random effects",
           "alpha": None if model is None else model.alpha, "days": len(daily),
           "warmup_days": warmup_days, "seconds": round(time.time() - started, 1),
           "match_features": MATCH_FEATURES, "share_features": SHARE_FEATURES, "daily": daily}
    if tot["y"]:
        rep.update({
            "wape_sel_last5": tot["sel_l"] / tot["y"], "wape_sel_model": tot["sel_m"] / tot["y"],
            "wape_match_last5": tot["match_l"] / tot["y"], "wape_match_model": tot["match_m"] / tot["y"],
            "bias_last5": tot["p_l"] / tot["y"] - 1, "bias_model": tot["p_m"] / tot["y"] - 1,
            "dev_last5": tot["dev_l"] / tot["n"], "dev_model": tot["dev_m"] / tot["n"],
        })
    if model is not None and model.match_glm is not None:
        rep["match_coef"] = dict(zip(["intercept"] + MATCH_FEATURES,
                                     np.round(model.match_glm["beta"], 4).tolist()))
        rep["share_coef"] = dict(zip(["intercept"] + SHARE_FEATURES,
                                     np.round(model.share_glm["beta"], 4).tolist()))
        rep["league_effect"] = {k: round(v, 3) for k, v in sorted(model.league.items(), key=lambda kv: -kv[1])}
    out = root / "Turnover" / name / "_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rep, indent=2, default=str), encoding="utf-8")
    if "wape_match_model" in rep:
        print("\n[result] scored days")
        print("   WAPE per match   last5 {:.1%}   {} {:.1%}".format(rep["wape_match_last5"], name, rep["wape_match_model"]))
        print("   WAPE per sel     last5 {:.1%}   {} {:.1%}".format(rep["wape_sel_last5"], name, rep["wape_sel_model"]))
        print("   Poisson dev      last5 {:,.0f}   {} {:,.0f}".format(rep["dev_last5"], name, rep["dev_model"]))
        print("   bias             last5 {:+.1%}   {} {:+.1%}".format(rep["bias_last5"], name, rep["bias_model"]))
        print("   blend weight on the model: {}".format(rep["alpha"]))
    else:
        print("[result] no day scored yet ({} day(s), warm-up {})".format(len(daily), warmup_days))
    if any("backtest_rows" not in r for r in daily):
        print('[note] some days have no Backtest_Data/index yet. After Open cached, run:\n'
              '       python -m src.backtest.parquet.raw_turnover align --name {}'.format(name))
    print("[out] {}".format(out.parent))
    print("[next] Backtest -> Run -> Open cached. '{}' appears next to Last 5 min.".format(name))
    return rep


def _refit(store: List[dict], inner_days: int) -> TwoLevel:
    inner_n = min(inner_days, max(len(store) - 1, 0))
    fit = store[:len(store) - inner_n] or store
    inner = store[len(store) - inner_n:] if inner_n else []
    m = TwoLevel()
    m.fit(pd.concat([d["match"] for d in fit], ignore_index=True),
          pd.concat([d["sel"] for d in fit], ignore_index=True))
    scores = {}
    if inner:
        # alpha is picked on full match tables so the match random effect sees
        # every earlier bucket, and on the sampled selections
        m.alpha = 1.0
        s = pd.concat([d["sel"] for d in inner], ignore_index=True)
        mm = pd.concat([d["match"] for d in inner], ignore_index=True)
        scores = m.pick_alpha(s, mm)
    print("[fit] {} day(s); blend weight on model {}; inner Poisson deviance {}".format(
        len(fit), m.alpha, {k: round(v) for k, v in scores.items()}), flush=True)
    return m


# --------------------------------------------------------------- selftest
def _fail(msg: str) -> None:
    raise SystemExit("[glm_turnover selftest] FAIL: " + msg)


def _features_for(cfg: Config, day: pd.Timestamp):
    static = load_static(cfg.data_dir, day, day + pd.Timedelta(days=1))
    mc = MonthCache(cfg, day, day.to_period("M").start_time + pd.offsets.MonthBegin(1))
    market = load_window(cfg.data_dir, "market", day - pd.Timedelta(days=cfg.lookback_days),
                         day + pd.Timedelta(days=1))
    sel, match, _ = build_day_features(cfg, day, mc, static[0], static[1], market, None)
    return sel, match


def _col(df: pd.DataFrame, names) -> Optional[str]:
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def _tamper(raw: Path, t0: pd.Timestamp) -> dict:
    """Change everything that happens inside [t0, t0+5min) in the raw folders."""
    t1 = t0 + STEP
    done = {}
    for sub, tcol, changes in (
        ("Match_Investments", ["start_sell_time"], {"turnover": 7.0}),
        ("HKJC_Odds", ["effective_datetime"], {"odds": 1.37, "true_odds": 1.37}),
        ("Market_Odds", ["effective_datetime"], {"odds": 1.4}),
        ("HKJC_Parameters", ["EventTime", "event_time"], {"Goal90CurrentTG": 1.3, "Corner90CurrentTG": 1.3}),
    ):
        for path in (raw / sub).glob("*.parquet"):
            df = pd.read_parquet(path)
            tc = _col(df, tcol)
            if tc is None:
                continue
            inside = (pd.to_datetime(df[tc]) >= t0) & (pd.to_datetime(df[tc]) < t1)
            for c, k in changes.items():
                cc = _col(df, [c])
                if cc is not None:
                    df.loc[inside, cc] = df.loc[inside, cc] * k
            done[sub] = done.get(sub, 0) + int(inside.sum())
            df.to_parquet(path, index=False)
    # a market quote inside the bucket for every selection the market prices
    for path in (raw / "Market_Odds").glob("*.parquet"):
        df = pd.read_parquet(path)
        tc, oc = _col(df, ["effective_datetime"]), _col(df, ["odds"])
        if tc is None or oc is None or df.empty:
            continue
        extra = df.copy()
        extra[tc] = t0
        extra[oc] = extra[oc] * 1.4
        df = pd.concat([df, extra], ignore_index=True)
        done["Market_Odds"] = done.get("Market_Odds", 0) + len(extra)
        df.to_parquet(path, index=False)
    # a brand-new line on every pool, first priced inside the bucket
    for path in (raw / "HKJC_Odds").glob("*.parquet"):
        df = pd.read_parquet(path)
        tc, lc = _col(df, ["effective_datetime"]), _col(df, ["line_id"])
        if tc is None or lc is None or df.empty:
            continue
        pc = _col(df, ["pool_id"])
        extra = df.sort_values(tc).drop_duplicates([pc, _col(df, ["combination_id"])]).copy()
        extra[lc] = extra[lc] + 900
        extra[tc] = t0 + pd.Timedelta(seconds=30)
        df = pd.concat([df, extra], ignore_index=True)
        done["new_lines"] = len(extra)
        df.to_parquet(path, index=False)
    # a goal inside the bucket for every match with an incident feed
    for path in (raw / "Match_Events").glob("*.parquet"):
        df = pd.read_parquet(path)
        tc = _col(df, ["incident_datetime"])
        ty = _col(df, ["incident_type"])
        if tc is None or ty is None or df.empty:
            continue
        extra = df.drop_duplicates(_col(df, ["match_id", "event_id"]) or tc).copy()
        # at the very start of the bucket: the hardest case for "known at T"
        extra[tc] = t0
        extra[ty] = GOAL_IN
        df = pd.concat([df, extra], ignore_index=True)
        done["Match_Events"] = len(extra)
        df.to_parquet(path, index=False)
    return done


def leak_check(raw: Path, cfg: Config, day: pd.Timestamp) -> dict:
    """Features at or before T must not move when anything inside T changes."""
    import shutil
    import tempfile
    sel0, match0 = _features_for(cfg, day)
    counts = sel0[sel0["modelled"]].groupby("bucket").size()
    t0 = pd.Timestamp(counts.idxmax())
    tmp = Path(tempfile.mkdtemp(prefix="algoe_leak_"))
    try:
        raw2 = tmp / "Raw_Data"
        shutil.copytree(raw, raw2)
        changed = _tamper(raw2, t0)
        cfg2 = Config(**{**cfg.__dict__, "data_dir": raw2})
        sel1, match1 = _features_for(cfg2, day)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    keys = KEY + ["bucket"]
    a = sel0[sel0["bucket"] <= t0].merge(sel1[sel1["bucket"] <= t0], on=keys, suffixes=("", "_2"))
    moved = [c for c in SHARE_FEATURES + ["last5"]
             if not np.allclose(a[c].to_numpy(dtype="float64"), a[c + "_2"].to_numpy(dtype="float64"),
                                atol=1e-6, equal_nan=True)]
    if not np.array_equal(a["modelled"].to_numpy(), a["modelled_2"].to_numpy()):
        moved.append("modelled")
    mk = ["match_id", "bucket"]
    b = match0[match0["bucket"] <= t0].merge(match1[match1["bucket"] <= t0], on=mk, suffixes=("", "_2"))
    moved += [c for c in MATCH_FEATURES
              if not np.allclose(b[c].to_numpy(dtype="float64"), b[c + "_2"].to_numpy(dtype="float64"),
                                 atol=1e-6, equal_nan=True)]
    at = a[a["bucket"] == t0]
    label_moved = not np.allclose(at["y"].to_numpy(dtype="float64"), at["y_2"].to_numpy(dtype="float64"))
    # the lines that opened inside T exist in the tampered run only, and must
    # not be forecast at T
    new = sel1[(sel1["bucket"] == t0) & (sel1["line_id"] >= 900)]
    return {"bucket": str(t0), "changed_raw_rows": changed, "rows_compared": int(len(a)),
            "match_rows_compared": int(len(b)), "features_moved": moved, "label_moved": label_moved,
            "new_line_rows": int(len(new)), "new_line_modelled": int(new["modelled"].sum())}


def selftest() -> None:
    import shutil
    import tempfile
    from .book import load_compare
    from .cache import PanelCache
    from .selftest import make_fixture

    # GLM recovers known coefficients
    rng = np.random.default_rng(1)
    x = rng.normal(size=(20000, 3))
    mu = np.exp(1.0 + 0.8 * x[:, 0] - 0.5 * x[:, 1])
    yy = rng.poisson(mu)
    fit = glm_fit(x, yy, power=1.0, lam=1e-8)
    coef = fit["beta"][1:] / fit["std"]
    if not (abs(coef[0] - 0.8) < 0.05 and abs(coef[1] + 0.5) < 0.05 and abs(coef[2]) < 0.05):
        _fail("GLM did not recover coefficients: {}".format(coef))

    tmp = Path(tempfile.mkdtemp(prefix="algoe_glm_"))
    try:
        raw = tmp / "Raw_Data"
        make_fixture(raw, days=6, matches_per_day=5, start="2026-07-01")
        cfg = Config(data_dir=raw, out_dir=tmp / "out", cache_dir=tmp / "cache",
                     start_date="2026-07-01", end_date="2026-07-06",
                     pools=["HILO", "HDC", "CHLO"], prematch_window_min=180)
        # 1. nothing from inside the bucket reaches that bucket's features
        leak = leak_check(raw, cfg, pd.Timestamp("2026-07-02"))
        print("[leak] bucket {}  raw rows changed {}  compared {:,} selection rows, {:,} match rows".format(
            leak["bucket"], leak["changed_raw_rows"], leak["rows_compared"], leak["match_rows_compared"]))
        if leak["features_moved"]:
            _fail("future information reached features: {}".format(leak["features_moved"]))
        if not leak["label_moved"]:
            _fail("tampering did not change the label, so the leak check proved nothing")
        if leak["rows_compared"] == 0 or leak["match_rows_compared"] == 0:
            _fail("leak check compared no rows")
        if leak["new_line_rows"] == 0:
            _fail("the new-line case was not exercised")
        if leak["new_line_modelled"]:
            _fail("{} line(s) first priced inside T were forecast at T".format(leak["new_line_modelled"]))
        print("[leak] PASS  {} new-line row(s) at T, none forecast".format(leak["new_line_rows"]))

        # 2. unseen bet types fall back to their family; the unknown one to 'other'
        if family("ETHILO") != "goal_total" or family("FCHDC") != "corner_hdc" or family("XYZ") != "other":
            _fail("bet-type family mapping")

        cache = PanelCache(cfg, tmp / "cache")
        cache.build(day_list(cfg.start_date, cfg.end_date))
        load_compare(cache, cfg.start_date, cfg.end_date, ("raw",))
        rep = train(cfg, name="glm", warmup_days=3, inner_days=1, refit_every=2, per_day=20000)
        if "wape_match_model" not in rep:
            _fail("nothing scored")
        facts, _ = load_compare(cache, cfg.start_date, cfg.end_date, ("raw",))
        if "t_hat__glm" not in facts.columns:
            _fail("backtest did not pick up Turnover/glm")
        if not np.isfinite(pd.to_numeric(facts["t_hat__glm"], errors="coerce")).all():
            _fail("backtest column has gaps")
        if sum(r.get("backtest_matched", 0) for r in rep["daily"]) == 0:
            _fail("no row matched the backtest")
        sel = pd.read_parquet(sorted((backtest_root(cfg) / "Features_glm2").glob("*.sel.parquet"))[0])
        if sel["has_mkt"].sum() == 0:
            _fail("Market_Odds never joined")
        print("[glm_turnover selftest] PASS  match WAPE last5 {:.1%} glm {:.1%}  bias glm {:+.1%}".format(
            rep["wape_match_last5"], rep["wape_match_model"], rep["bias_model"]), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["train", "selftest"])
    p.add_argument("--data-dir", default=r"S:\Users\Yeung\20260520 Algo E\Raw_Data")
    p.add_argument("--start", default="2026-07-01")
    p.add_argument("--end", default="2026-09-15")
    p.add_argument("--name", default="glm")
    p.add_argument("--warmup-days", type=int, default=14)
    p.add_argument("--inner-days", type=int, default=7)
    p.add_argument("--refit-every", type=int, default=7)
    p.add_argument("--per-day", type=int, default=60000)
    p.add_argument("--refresh-features", action="store_true")
    a = p.parse_args(argv)
    if a.command == "selftest":
        selftest()
        return
    cfg = Config(data_dir=Path(a.data_dir), start_date=a.start, end_date=a.end, pools=[])
    train(cfg, a.name, a.warmup_days, a.inner_days, a.refit_every, a.per_day, a.refresh_features)


if __name__ == "__main__":
    main()
