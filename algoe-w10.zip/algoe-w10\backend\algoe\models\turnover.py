"""
Turnover Forecaster

One class that owns every way Algo E forecasts next-bucket turnover.

RESPONSE VARIABLES. Money for a selection in bucket T is decomposed into
three quantities that behave very differently, and each is modelled on its
own:

    match_total          M   money the whole match takes in T            (volume)
    pool_share           pi  share of M that goes to each pool           (mix across markets)
    selection_share      s   share of the pool's money on each line/side (mix within a market;
                                                                           where price elasticity lives)
    selection_turnover   y   the selection's money directly              (single-stage alternative)

    three_stage:  y_hat = M_hat x pi_hat x s_hat     (shares normalised inside their group)
    direct:       y_hat = f(selection, pool and match features)

The split is also what the optimiser needs: repricing moves money WITHIN a
pool (s depends on price), while the match's volume is an anchor that price
does not change in the short run (project.md section 5, step 3).

METHOD NAMES are systematic, one per (algorithm, response):

    train_<algo>_<response>(data)     algo in glm | gam | gbm | nn
    predict_<response>(day, algo)     predict_selection_turnover(day, pipeline) composes them
    evaluate_<response>(algo, days)   evaluate_selection_turnover(pipeline, days)
    predict_remaining_bucket(...)     intra-bucket nowcast for the live loop
    train_all(days)                   every enabled combination, champion chosen on validation days

SPLITS. Coefficients are fitted on train days; the blend weight toward
last-5-minutes and the champion are chosen on validation days; test days
are scored once, at the end, for the leaderboard. A pipeline that does not
beat last 5 minutes on validation is blended to weight 0, i.e. it IS last 5
minutes: the deployed forecast can never be worse than the baseline on the
days it was chosen on.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Feature version on every bundle; refit_for_serving; prepare_training_data can reuse a split
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.exceptions import EstimatorUnavailable, ModelError
from ..core.io import write_parquet
from ..core.logging import get_logger, log_step
from ..data.panel import KEY
from ..data.splits import DaySplit, walk_forward
from ..evaluation.metrics import ScoreAccumulator, diebold_mariano, poisson_deviance
from ..features.engineer import MKEY, PKEY, DayData, FeatureEngineer, FeatureSet
from ..features.store import FEATURE_VERSION, FeatureStore
from ..realtime.nowcast import BucketNowcaster
from ..registry.model_store import ModelStore
from .estimators import Estimator, available_algorithms, load_estimator, make_estimator

logger = get_logger(__name__)

ALGORITHMS = ("glm", "gam", "gbm", "nn")
NAIVE = ("last5", "ma3", "ema", "profile")


@dataclass(frozen=True)
class ResponseSpec:
    name: str
    builder: str
    family: str
    uses_exposure: bool
    normalise: Optional[str]         # None | "match" | "pool"
    smooth: Tuple[str, ...]


RESPONSES: Dict[str, ResponseSpec] = {
    "match_total": ResponseSpec("match_total", "features_for_turnover_match_total", "tweedie", False, None,
                                ("pre_ko_min", "minute", "m_log_l1", "m_log_ewma", "m_log_today",
                                 "log_board_l1", "tg_full", "n_live")),
    "pool_share": ResponseSpec("pool_share", "features_for_turnover_pool_share", "poisson", True, "match",
                               ("minute", "pre_ko_min", "p_share_l1", "p_share_ewma")),
    "selection_share": ResponseSpec("selection_share", "features_for_turnover_selection_share", "poisson", True,
                                    "pool", ("s_share_pool_l1", "s_share_pool_ewma", "line_offset", "imp",
                                             "value_true", "log_odds_age")),
    "selection_turnover": ResponseSpec("selection_turnover", "features_for_turnover_selection", "tweedie", False,
                                       None, ("s_log_l1", "s_log_ewma_fast", "m_log_l1", "pre_ko_min", "minute",
                                              "line_offset", "imp")),
}
# which feature kinds each algorithm is handed (catalog.py)
KINDS_FOR = {"glm": ("raw", "basis", "flag", "encoded"), "gam": ("raw", "flag", "encoded"),
             "gbm": ("raw", "flag", "encoded"), "nn": ("raw", "basis", "flag", "encoded")}


@dataclass
class TrainingData:
    split: DaySplit
    train: Dict[str, FeatureSet] = field(default_factory=dict)
    val: Dict[str, FeatureSet] = field(default_factory=dict)


class TurnoverForecaster:
    def __init__(self, settings, engineer: Optional[FeatureEngineer] = None,
                 store: Optional[FeatureStore] = None, model_store: Optional[ModelStore] = None):
        self.settings = settings
        self.engineer = engineer or FeatureEngineer(settings)
        self.store = store
        self.model_store = model_store or ModelStore(settings.paths.models, "turnover", FEATURE_VERSION)
        self.models: Dict[Tuple[str, str], Estimator] = {}
        self.blend: Dict[str, float] = {}
        self.profile: Dict[str, float] = {}
        self.champion: str = "last5"
        self.leaderboard: List[dict] = []
        self.nowcaster = BucketNowcaster(settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes)
        self.version: Optional[str] = None
        self.metadata: dict = {}

    # ===================================================== train (systematic)
    def train_glm_match_total(self, data: TrainingData) -> Estimator:
        return self._train("glm", "match_total", data)

    def train_gam_match_total(self, data: TrainingData) -> Estimator:
        return self._train("gam", "match_total", data)

    def train_gbm_match_total(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "match_total", data)

    def train_nn_match_total(self, data: TrainingData) -> Estimator:
        return self._train("nn", "match_total", data)

    def train_glm_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("glm", "pool_share", data)

    def train_gam_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("gam", "pool_share", data)

    def train_gbm_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "pool_share", data)

    def train_nn_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("nn", "pool_share", data)

    def train_glm_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("glm", "selection_share", data)

    def train_gam_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("gam", "selection_share", data)

    def train_gbm_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "selection_share", data)

    def train_nn_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("nn", "selection_share", data)

    def train_glm_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("glm", "selection_turnover", data)

    def train_gam_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("gam", "selection_turnover", data)

    def train_gbm_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "selection_turnover", data)

    def train_nn_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("nn", "selection_turnover", data)

    def train_naive_profile(self, data: TrainingData) -> Dict[str, float]:
        """Gametime profile baseline: mean selection money by (clock bin, family) on train days."""
        fs = data.train.get("selection_turnover") or data.train.get("selection_share")
        if fs is None or not len(fs):
            self.profile = {}
            return self.profile
        key = np.char.add(np.char.add(labels(fs.cuts["clock_bin"]).astype(str), "|"),
                          labels(fs.cuts["family"]).astype(str))
        self.profile = pd.Series(fs.y).groupby(key).mean().to_dict()
        self.profile["_global"] = float(np.mean(fs.y))
        logger.info("naive profile: %d (clock, family) cells", len(self.profile) - 1)
        return self.profile

    def _train(self, algo: str, response: str, data: TrainingData) -> Estimator:
        spec = RESPONSES[response]
        tr, va = data.train.get(response), data.val.get(response)
        if tr is None or not len(tr):
            raise ModelError("no training rows for {}".format(response))
        feats = tr.columns_for(KINDS_FOR[algo])
        est = make_estimator(algo, spec.family, self.settings.turnover.tweedie_power, self.settings, feats)
        if algo == "gam":
            est.smooth_req = [c for c in spec.smooth if c in feats]
        exp_tr = tr.exposure if spec.uses_exposure else None
        exp_va = (va.exposure if spec.uses_exposure else None) if va is not None else None
        with log_step(logger, "T", "train {} {}".format(algo, response),
                      "{:,} train rows, {:,} val rows, {} features".format(
                          len(tr), 0 if va is None else len(va), len(feats))) as step:
            est.fit(tr.X, tr.y, exposure=exp_tr, weight=tr.weight,
                    X_val=None if va is None else va.X, y_val=None if va is None else va.y,
                    exposure_val=exp_va, weight_val=None if va is None else va.weight)
            step["result"] = "train dev {:.4g} val dev {}".format(
                est.info.get("train_deviance", float("nan")),
                "{:.4g}".format(est.info["val_deviance"]) if "val_deviance" in est.info else "n/a")
        self.models[(algo, response)] = est
        return est

    # ============================================================ data
    def prepare_training_data(self, days: Sequence, store: Optional[FeatureStore] = None,
                              split: Optional[DaySplit] = None) -> TrainingData:
        """Build train / val FeatureSets for every response; fit encoders on train days only.

        ``split`` reuses a model's own split (the backtest's ablation must refit on the days the
        model was fitted on, or the comparison - and the shared encoders - would change)."""
        store = store or self.store
        if store is None:
            raise ModelError("prepare_training_data needs a FeatureStore")
        t = self.settings.turnover
        rng = np.random.default_rng(t.seed)
        # a cached day has rows (empty days are never written), so only uncached days are opened
        usable = [pd.Timestamp(d).normalize() for d in days if store.has(d) or not store.get(d).empty]
        w = self.settings.window
        if split is not None:
            ok = set(usable)
            split = DaySplit(*(tuple(d for d in part if pd.Timestamp(d).normalize() in ok)
                               for part in (split.train, split.val, split.test)))
        else:
            split = DaySplit.for_window(usable, w)
        logger.info("turnover split: %s", split.describe())
        with log_step(logger, "F1", "fit encoders on train days", split.describe()) as step:
            self.engineer.fit_encoders_from(store, split.train)
            step["result"] = "leagues {} pools {}".format(
                len((self.engineer.encoders.league.tables.get("league_code", {}) if self.engineer.encoders.league else {})),
                len((self.engineer.encoders.pool.tables.get("pool_key", {}) if self.engineer.encoders.pool else {})))
        data = TrainingData(split=split)
        parts: Dict[str, Dict[str, List[FeatureSet]]] = {"train": {}, "val": {}}
        with log_step(logger, "F2", "build training feature sets") as step:
            for role, role_days in (("train", split.train), ("val", split.val)):
                for d in role_days:
                    dd = store.get(d)
                    for name, spec in RESPONSES.items():
                        fs = getattr(self.engineer, spec.builder)(dd)
                        if not len(fs):
                            continue
                        fs = _sample_groups(fs, _day_cap(t, name, len(role_days)), rng)
                        parts[role].setdefault(name, []).append(fs)
            for role in ("train", "val"):
                for name, lst in parts[role].items():
                    getattr(data, role)[name] = FeatureSet.concat(lst)
            step["result"] = ", ".join("{} {:,}/{:,}".format(k, len(data.train.get(k, [])) if k in data.train else 0,
                                                            len(data.val[k]) if k in data.val else 0)
                                       for k in RESPONSES)
        return data

    # ========================================================= train all
    def train_all(self, days: Sequence, store: Optional[FeatureStore] = None) -> dict:
        store = store or self.store
        self.store = store
        t = self.settings.turnover
        avail = available_algorithms()
        data = self.prepare_training_data(days, store)
        self.train_naive_profile(data)
        skipped = {}
        for response in t.responses:
            if response not in RESPONSES:
                logger.warning("unknown response %r in settings.turnover.responses; skipped", response)
                continue
            for algo in t.algorithms:
                if algo == "naive":
                    continue
                if not avail.get(algo, False):
                    skipped["{}_{}".format(algo, response)] = "backend not installed"
                    continue
                if algo not in self._algos_needed(response):
                    continue
                try:
                    getattr(self, "train_{}_{}".format(algo, response))(data)
                except (EstimatorUnavailable, ModelError, np.linalg.LinAlgError, ValueError) as exc:
                    skipped["{}_{}".format(algo, response)] = str(exc)
                    logger.warning("train_%s_%s skipped: %s", algo, response, exc)
        pipelines = self._runnable_pipelines()
        with log_step(logger, "V", "choose blend and champion on validation days",
                      ", ".join(pipelines)) as step:
            val_scores = self._score_days(data.split.val, pipelines, choose_blend=True)
            self.champion = self._pick_champion(val_scores)
            step["result"] = "champion {} (blend {:.2f})".format(self.champion, self.blend.get(self.champion, 0.0))
        with log_step(logger, "E", "score every pipeline on test days", data.split.describe()) as step:
            test_scores = self._score_days(data.split.test, pipelines, choose_blend=False, cuts=True)
            self.leaderboard = self._leaderboard(val_scores, test_scores)
            champ = next((r for r in self.leaderboard if r["pipeline"] == self.champion), {})
            base = next((r for r in self.leaderboard if r["pipeline"] == "last5"), {})
            step["result"] = "test deviance {} vs last5 {}; WAPE {} vs {}".format(
                _fmt(champ.get("test_deviance")), _fmt(base.get("test_deviance")),
                _pct(champ.get("test_wape")), _pct(base.get("test_wape")))
        self.metadata = {
            "window": {"start": str(pd.Timestamp(days[0]).date()), "end": str(pd.Timestamp(days[-1]).date())},
            "split": data.split.to_dict(), "champion_pipeline": self.champion, "blend": self.blend,
            "leaderboard": self.leaderboard, "skipped": skipped,
            "features": {r: data.train[r].feature_names for r in data.train},
            "models": {"{}|{}".format(a, r): m.summary() for (a, r), m in self.models.items()},
            "selection": {"metric": "deviance", "days": data.split.to_dict()["val"],
                          "deviance": next((r["val_deviance"] for r in self.leaderboard if r["pipeline"] == self.champion), None)},
            "test_cuts": test_scores.get("_cuts", {}), "dm_test": test_scores.get("_dm", {}),
            "settings": self.settings.to_dict()["turnover"],
            "feature_reference": {r: _reference(data.train[r].X) for r in data.train},
            # a model trained without HKJC true odds must be served without them (see LiveEngine)
            "true_odds_coverage": true_odds_coverage(store, data.split.train),
        }
        return self.metadata

    def _algos_needed(self, response: str) -> set:
        need = set()
        for p in self.settings.turnover.pipelines:
            kind, algos = _parse_pipeline(p)
            if kind == "direct" and response == "selection_turnover":
                need.add(algos[0])
            if kind == "three_stage":
                for a, r in zip(algos, ("match_total", "pool_share", "selection_share")):
                    if r == response:
                        need.add(a)
        return need

    def _runnable_pipelines(self) -> List[str]:
        out = []
        for p in self.settings.turnover.pipelines:
            kind, algos = _parse_pipeline(p)
            if kind == "naive":
                if p != "profile" or self.profile:
                    out.append(p)
            elif kind == "direct" and (algos[0], "selection_turnover") in self.models:
                out.append(p)
            elif kind == "three_stage" and all((a, r) in self.models for a, r in
                                               zip(algos, ("match_total", "pool_share", "selection_share"))):
                out.append(p)
            else:
                logger.info("pipeline %s not runnable (a component was not trained)", p)
        if "last5" not in out:
            out.insert(0, "last5")
        return out

    # =========================================================== predict
    def predict_match_total(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fm = self.engineer.features_for_turnover_match_total(day)
        mu = self._model(algo, "match_total").predict(fm.X)
        mu = self._match_effect(day.match, mu)
        out = fm.keys.copy()
        out["forecast"], out["actual"], out["last5"] = mu, fm.y, fm.last5
        return out

    def predict_pool_share(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fp = self.engineer.features_for_turnover_pool_share(day)
        raw = self._model(algo, "pool_share").predict(fp.X, exposure=np.ones(len(fp)))
        out = fp.keys.copy()
        out["share"] = _normalise(raw, fp.group)
        out["actual_share"] = np.where(fp.exposure > 0, fp.y / np.maximum(fp.exposure, 1e-12), np.nan)
        return out

    def predict_selection_share(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fs = self.engineer.features_for_turnover_selection_share(day)
        raw = self._model(algo, "selection_share").predict(fs.X, exposure=np.ones(len(fs)))
        out = fs.keys.copy()
        out["share"] = _normalise(raw, fs.group)
        out["actual_share"] = np.where(fs.exposure > 0, fs.y / np.maximum(fs.exposure, 1e-12), np.nan)
        return out

    def predict_selection_turnover(self, day: DayData, pipeline: Optional[str] = None,
                                   blend: Optional[float] = None) -> pd.DataFrame:
        """Next-bucket money for every row of the day (forecastable rows modelled, others last 5 min)."""
        pipeline = pipeline or self.champion
        sel = day.sel
        f = sel["forecastable"].to_numpy(dtype=bool)
        model_pred = self._pipeline_raw(day, pipeline)
        a = self.blend.get(pipeline, 1.0) if blend is None else blend
        last5 = sel["tv1"].to_numpy(dtype="float64")
        pred = last5.copy()
        if model_pred is not None:
            pred[f] = a * model_pred + (1.0 - a) * last5[f]
        out = sel[KEY + ["match_id", "pool_name", "bucket"]].copy()
        out["forecast"], out["last5"], out["actual"] = pred, last5, sel["y"].to_numpy(dtype="float64")
        out["forecastable"] = f
        return out

    def predict_remaining_bucket(self, bucket_forecast, observed_so_far, elapsed_minutes: float,
                                 match_key=None, next_forecast=None):
        """Rest-of-bucket money given what has already arrived (see realtime/nowcast.py)."""
        return self.nowcaster.update(bucket_forecast, observed_so_far, elapsed_minutes, match_key, next_forecast)

    def _model(self, algo: str, response: str) -> Estimator:
        m = self.models.get((algo, response))
        if m is None:
            raise ModelError("no trained {} model for {}".format(algo, response))
        return m

    def _pipeline_raw(self, day: DayData, pipeline: str) -> Optional[np.ndarray]:
        """Unblended model forecast aligned to day.sel[forecastable] rows."""
        kind, algos = _parse_pipeline(pipeline)
        s = day.sel[day.sel["forecastable"]]
        if kind == "naive":
            tv = [s["tv{}".format(k)].to_numpy(dtype="float64") for k in (1, 2, 3)]
            if pipeline == "last5":
                return tv[0]
            if pipeline == "ma3":
                return (tv[0] + tv[1] + tv[2]) / 3.0
            if pipeline == "ema":
                return 0.5 * tv[0] + 0.3 * tv[1] + 0.2 * tv[2]
            if pipeline == "profile":
                g = self.profile.get("_global", 0.0)
                if "clock_bin" not in s.columns:
                    return np.full(len(s), g)
                key = np.char.add(np.char.add(labels(s["clock_bin"]).astype(str), "|"), labels(s["family"]).astype(str))
                return pd.Series(key).map(self.profile).fillna(g).to_numpy(dtype="float64")
            raise ModelError("unknown naive pipeline {}".format(pipeline))
        if kind == "direct":
            fd = self.engineer.features_for_turnover_selection(day)
            return self._model(algos[0], "selection_turnover").predict(fd.X)
        if kind == "three_stage":
            a_m, a_p, a_s = algos
            fm = self.engineer.features_for_turnover_match_total(day)
            M = self._match_effect(day.match, self._model(a_m, "match_total").predict(fm.X))
            fp = self.engineer.features_for_turnover_pool_share(day)
            pi = _normalise(self._model(a_p, "pool_share").predict(fp.X, exposure=np.ones(len(fp))), fp.group)
            m_idx = pd.MultiIndex.from_frame(fm.keys[MKEY])
            P = pd.Series(M, index=m_idx).reindex(pd.MultiIndex.from_frame(fp.keys[MKEY])).to_numpy() * pi
            fs = self.engineer.features_for_turnover_selection_share(day)
            sh = _normalise(self._model(a_s, "selection_share").predict(fs.X, exposure=np.ones(len(fs))), fs.group)
            p_idx = pd.MultiIndex.from_frame(fp.keys[PKEY])
            Ps = pd.Series(P, index=p_idx).reindex(pd.MultiIndex.from_frame(fs.keys[PKEY])).to_numpy()
            return np.nan_to_num(Ps, nan=0.0) * sh
        raise ModelError("unknown pipeline {!r}".format(pipeline))

    def _match_effect(self, match: pd.DataFrame, mu: np.ndarray) -> np.ndarray:
        """In-day match random effect: scale by (money so far + prior) / (forecast so far + prior).

        Uses only buckets of the same match earlier the same day, which are
        settled at T. A league never seen in training trusts the match's own
        buckets sooner (settings.features.match_prior_new_league).
        """
        fs = self.settings.features
        if match is None or match.empty or len(mu) != len(match):
            return mu
        known = np.ones(len(match))
        if self.engineer.encoders.league is not None and "league_code" in match.columns:
            _, known = self.engineer.encoders.league.transform(match)
        k = np.where(known > 0, fs.match_prior, fs.match_prior_new_league)
        f = pd.DataFrame({"m": match["match_id"].to_numpy(), "b": match["bucket"].to_numpy(),
                          "y": match["y"].to_numpy(dtype="float64"), "mu": np.asarray(mu, dtype="float64"),
                          "k": k, "pos": np.arange(len(match))}).sort_values(["m", "b"])
        g = f.groupby("m", sort=False)
        cy = g["y"].cumsum() - f["y"]
        cm = g["mu"].cumsum() - f["mu"]
        prior = f["k"] * f["mu"].clip(lower=1.0)
        u = ((cy + prior) / (cm + prior)).clip(0.2, 5.0)
        out = np.empty(len(match))
        out[f["pos"].to_numpy()] = (f["mu"] * u).to_numpy()
        return out

    # ========================================================== evaluate
    def evaluate_match_total(self, algo: str, days: Sequence) -> dict:
        acc = ScoreAccumulator()
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            p = self.predict_match_total(dd, algo)
            key = p["match_id"].astype(str) + "|" + p["bucket"].astype(str)
            acc.add(algo, p["actual"], p["forecast"], p["last5"], key)
            acc.add("last5", p["actual"], p["last5"], p["last5"], key)
        return {"model": acc.result(algo), "last5": acc.result("last5")}

    def evaluate_pool_share(self, algo: str, days: Sequence) -> dict:
        return self._share_eval(days, lambda dd: self.predict_pool_share(dd, algo), "pool")

    def evaluate_selection_share(self, algo: str, days: Sequence) -> dict:
        return self._share_eval(days, lambda dd: self.predict_selection_share(dd, algo), "selection")

    def _share_eval(self, days, fn, level) -> dict:
        ce, ce_flat, n = 0.0, 0.0, 0.0
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            p = fn(dd)
            a = p["actual_share"].to_numpy(dtype="float64")
            ok = np.isfinite(a)
            key = p.loc[ok, MKEY].astype(str).agg("|".join, axis=1) if level == "pool" else \
                p.loc[ok, PKEY].astype(str).agg("|".join, axis=1)
            flat = 1.0 / key.map(key.value_counts()).to_numpy(dtype="float64")
            ce += float(-np.sum(a[ok] * np.log(np.clip(p["share"].to_numpy(dtype="float64")[ok], 1e-6, 1))))
            ce_flat += float(-np.sum(a[ok] * np.log(np.clip(flat, 1e-6, 1))))
            n += float(key.nunique())
        return {"cross_entropy": ce / max(n, 1), "cross_entropy_flat": ce_flat / max(n, 1), "groups": int(n)}

    def evaluate_selection_turnover(self, pipeline: str, days: Sequence) -> dict:
        s = self._score_days(days, [pipeline, "last5"] if pipeline != "last5" else ["last5"], choose_blend=False)
        return {"model": s.get(pipeline, {}).get("all"), "last5": s.get("last5", {}).get("all")}

    def _score_days(self, days: Sequence, pipelines: Sequence[str], choose_blend: bool,
                    cuts: bool = False) -> dict:
        """Stream days; accumulate scores per pipeline (and per blend weight when choosing)."""
        alphas = list(self.settings.turnover.blend_alphas) if choose_blend else None
        acc = {p: ScoreAccumulator() for p in pipelines}
        daily = {p: [] for p in pipelines}
        cut_acc: Dict[str, ScoreAccumulator] = {}
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            sel = dd.sel
            f = sel["forecastable"].to_numpy(dtype=bool)
            y = sel["y"].to_numpy(dtype="float64")
            l5 = sel["tv1"].to_numpy(dtype="float64")
            mkey = (sel["match_id"].astype(str) + "|" + sel["bucket"].astype(str)).to_numpy()
            for p in pipelines:
                try:
                    raw = self._pipeline_raw(dd, p)
                except ModelError as exc:
                    logger.warning("pipeline %s skipped on %s: %s", p, pd.Timestamp(d).date(), exc)
                    continue
                grid = alphas if (choose_blend and p not in NAIVE) else [self.blend.get(p, 1.0)]
                for a in grid:
                    pred = l5.copy()
                    pred[f] = a * raw + (1 - a) * l5[f]
                    acc[p].add(str(a), y, pred, l5, mkey)
                if not choose_blend:
                    daily[p].append(poisson_deviance(y, pred))
                    if cuts and p in (self.champion, "last5"):
                        for dim in ("phase", "family", "clock_bin", "event_window", "league_code"):
                            if dim not in sel.columns:
                                continue
                            vals = labels(sel[dim])
                            for v in np.unique(vals):
                                m = vals == v
                                cut_acc.setdefault("{}|{}={}".format(p, dim, v), ScoreAccumulator()).add(
                                    "x", y[m], pred[m], l5[m], mkey[m])
        out = {}
        for p in pipelines:
            names = acc[p].names()
            if not names:
                continue
            if choose_blend and p not in NAIVE:
                best = min(names, key=lambda a: acc[p].result(a)["deviance"])
                base = acc[p].result("0.0") if "0.0" in names else None
                a = float(best)
                if base is not None and acc[p].result(best)["deviance"] >= base["deviance"] * (1 - 1e-6):
                    a = 0.0
                self.blend[p] = a
                out[p] = {"all": acc[p].result(str(a)) if str(a) in names else acc[p].result(best),
                          "by_alpha": {n: acc[p].result(n)["deviance"] for n in names}}
            else:
                if p in NAIVE:
                    self.blend.setdefault(p, 1.0)
                out[p] = {"all": acc[p].result(names[0])}
            out[p]["daily_deviance"] = daily[p]
        if cuts:
            out["_cuts"] = {k: v.result("x") for k, v in cut_acc.items()}
            base = daily.get("last5") or []
            out["_dm"] = {p: diebold_mariano(daily[p], base) for p in pipelines if p != "last5" and daily[p]}
        return out

    def _pick_champion(self, val_scores: dict) -> str:
        best, best_dev = "last5", (val_scores.get("last5", {}).get("all") or {}).get("deviance", np.inf)
        for p, s in val_scores.items():
            if p.startswith("_"):
                continue
            dev = (s.get("all") or {}).get("deviance")
            if dev is not None and dev < best_dev * (1 - 1e-6):
                best, best_dev = p, dev
        return best

    def _leaderboard(self, val: dict, test: dict) -> List[dict]:
        rows = []
        for p in val:
            if p.startswith("_"):
                continue
            v, t = (val[p].get("all") or {}), ((test.get(p) or {}).get("all") or {})
            dm = (test.get("_dm") or {}).get(p) or {}
            rows.append({"pipeline": p, "blend": self.blend.get(p, 1.0), "champion": p == self.champion,
                         "val_deviance": v.get("deviance"), "val_wape": v.get("wape"),
                         "test_deviance": t.get("deviance"), "test_wape": t.get("wape"),
                         "test_active_wape": t.get("active_wape"), "test_match_wape": t.get("match_wape"),
                         "test_bias": t.get("bias"), "dm_stat_vs_last5": dm.get("stat"),
                         "dm_p_vs_last5": dm.get("p_value"), "days_better": dm.get("days_a_better"),
                         "days_worse": dm.get("days_b_better")})
        rows.sort(key=lambda r: (r["test_deviance"] is None, r["test_deviance"] or 0))
        return rows

    # =================================================== walk-forward series
    def write_backtest_series(self, days: Sequence, pipeline: Optional[str] = None,
                              name: Optional[str] = None) -> dict:
        """Honest day-by-day series for the W06 workbench: day N from a fit on days before N.

        Writes Backtest_Data/Turnover/<name>/_keyed/<day>.parquet and aligns it
        to Backtest_Data/index when that exists (the workbench's row order).
        """
        from src.backtest.parquet.raw_turnover import align_day
        pipeline = pipeline or self.champion
        name = name or "algoe_" + pipeline.replace(":", "_").replace("+", "_")
        w = self.settings.window
        root = self.settings.paths.backtest_data
        kind, algos = _parse_pipeline(pipeline)
        needed = {}
        if kind == "direct":
            needed = {"selection_turnover": algos[0]}
        elif kind == "three_stage":
            needed = dict(zip(("match_total", "pool_share", "selection_share"), algos))
        frozen = dict(self.models), dict(self.blend), self.engineer.encoders
        report = {"pipeline": pipeline, "name": name, "days": []}
        try:
            for day, fit_days, choose_days, refit in walk_forward(days, w.walk_forward_warmup_days,
                                                                   w.walk_forward_refit_days, min(3, w.val_days)):
                dd = self.store.get(day)
                if dd.empty:
                    continue
                if fit_days and refit and needed:
                    self._refit_components(fit_days, choose_days, needed, pipeline)
                use = pipeline if (fit_days and (needed or kind == "naive")) else "last5"
                pred = self.predict_selection_turnover(dd, use)
                keyed = pred[["match_id", "pool_name", "line_id", "combination_id", "bucket"]].copy()
                keyed["value"] = pred["forecast"].astype("float32")
                stamp = "{:%Y-%m-%d}".format(pd.Timestamp(day))
                write_parquet(keyed, root / "Turnover" / name / "_keyed" / "{}.parquet".format(stamp))
                aligned = align_day(root, name, stamp)
                row = {"day": stamp, "pipeline_used": use, "refit": bool(refit and fit_days),
                       "deviance_model": poisson_deviance(pred["actual"], pred["forecast"]),
                       "deviance_last5": poisson_deviance(pred["actual"], pred["last5"])}
                if aligned:
                    row.update(aligned)
                report["days"].append(row)
                logger.info("walk-forward %s %s: deviance %s vs last5 %s%s", name, stamp,
                            _fmt(row["deviance_model"]), _fmt(row["deviance_last5"]),
                            "" if aligned else " (no Backtest_Data/index yet; keyed file written)")
        finally:
            self.models, self.blend, self.engineer.encoders = frozen[0], frozen[1], frozen[2]
        return report

    def refit_for_serving(self, days: Sequence) -> dict:
        """Refit the champion pipeline on the newest days for serving.

        train_all chooses and scores honestly, so the model it leaves behind has
        never seen the last val + test days - three weeks by default, which is
        stale at the start of a season. This refits only the champion's
        components on every day but the last val_days, re-chooses the blend
        toward last 5 minutes on those, and drops the other pipelines (their
        models were fitted with the old encoders). The leaderboard keeps the
        honest numbers; the Backtester must not be run on a refitted bundle,
        because its test days are now in the fit.
        """
        kind, algos = _parse_pipeline(self.champion)
        if kind == "direct":
            needed = {"selection_turnover": algos[0]}
        elif kind == "three_stage":
            needed = dict(zip(("match_total", "pool_share", "selection_share"), algos))
        else:
            return {"refit": False, "reason": "{} has no fitted component".format(self.champion)}
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        v = max(1, min(self.settings.window.val_days, len(usable) // 4))
        fit_days, blend_days = usable[:-v], usable[-v:]
        detail = "fit {}..{} ({} days), blend on {}..{}".format(
            fit_days[0].date(), fit_days[-1].date(), len(fit_days), blend_days[0].date(), blend_days[-1].date())
        with log_step(logger, "R", "refit {} for serving".format(self.champion), detail) as step:
            self._refit_components(fit_days, blend_days, needed, self.champion)
            keep = {(a, r) for r, a in needed.items()}
            self.models = {k: m for k, m in self.models.items() if k in keep}
            info = {"refit": True, "fit": [str(fit_days[0].date()), str(fit_days[-1].date()), len(fit_days)],
                    "blend_days": [str(d.date()) for d in blend_days],
                    "blend": float(self.blend.get(self.champion, 1.0))}
            self.metadata["serving_fit"] = info
            step["result"] = "blend {:.2f}; {} component(s) kept".format(info["blend"], len(self.models))
        return info

    def _refit_components(self, fit_days, choose_days, needed: Dict[str, str], pipeline: str) -> None:
        t = self.settings.turnover
        rng = np.random.default_rng(t.seed)
        self.engineer.fit_encoders_from(self.store, fit_days)
        data = TrainingData(split=DaySplit(tuple(fit_days), tuple(choose_days), tuple()))
        for role, role_days in (("train", fit_days), ("val", choose_days)):
            for r in needed:
                lst = []
                for d in role_days:
                    fs = getattr(self.engineer, RESPONSES[r].builder)(self.store.get(d))
                    if len(fs):
                        lst.append(_sample_groups(fs, _day_cap(t, r, len(role_days)), rng))
                if lst:
                    getattr(data, role)[r] = FeatureSet.concat(lst)
        for r, a in needed.items():
            self._train(a, r, data)
        if choose_days:
            self._score_days(choose_days, [pipeline], choose_blend=True)

    # ========================================================= persistence
    def to_bundle(self) -> dict:
        return {"models": {"{}|{}".format(a, r): m.to_state() for (a, r), m in self.models.items()},
                "encoders": self.engineer.encoders.to_state(), "blend": dict(self.blend),
                "profile": dict(self.profile), "champion": self.champion,
                "nowcast_prior_minutes": self.nowcaster.m0}

    def save(self, promote: bool = True) -> str:
        version = self.model_store.new_version(self.champion.replace(":", "-").replace("+", "_"))
        self.model_store.save(version, self.to_bundle(), self.metadata)
        self.version = version
        if promote:
            lb = {r["pipeline"]: r for r in self.leaderboard}
            champ = lb.get(self.champion, {})
            base = lb.get("last5", {})
            if self.champion == "last5":
                if self.model_store.champion() is None:
                    self.model_store.promote(version, "no model beat last 5 minutes on validation days; "
                                                      "serving the baseline")
                else:
                    logger.warning("no model beat last 5 minutes; the existing champion %s is kept",
                                   self.model_store.champion())
            elif champ.get("test_deviance") is not None and base.get("test_deviance") is not None:
                vs = self.metadata.get("versus_champion")
                self.model_store.promote_if_better(
                    version, "deviance", champ["val_deviance"] or np.inf, base["val_deviance"] or np.inf,
                    versus=(vs["challenger"], vs["champion_score"]) if vs else None)
                if champ["test_deviance"] >= base["test_deviance"]:
                    logger.warning("champion %s did not beat last 5 minutes on TEST days (%.4g vs %.4g); "
                                   "it was chosen on validation days - check the leaderboard before using it",
                                   self.champion, champ["test_deviance"], base["test_deviance"])
        return version

    @classmethod
    def load(cls, settings, version: Optional[str] = None, engineer: Optional[FeatureEngineer] = None,
             store: Optional[FeatureStore] = None) -> "TurnoverForecaster":
        from ..features.encoders import EncoderState
        ms = ModelStore(settings.paths.models, "turnover", FEATURE_VERSION)
        bundle, meta = ms.load(version)
        eng = engineer or FeatureEngineer(settings)
        eng.encoders = EncoderState.from_state(bundle.get("encoders"))
        f = cls(settings, eng, store, ms)
        f.models = {tuple(k.split("|", 1)): load_estimator(v) for k, v in bundle["models"].items()}
        f.blend = dict(bundle.get("blend") or {})
        f.profile = dict(bundle.get("profile") or {})
        f.champion = bundle.get("champion", "last5")
        f.nowcaster.m0 = float(bundle.get("nowcast_prior_minutes", f.nowcaster.m0))
        f.version, f.metadata = meta.get("version"), meta
        f.leaderboard = meta.get("leaderboard") or []
        logger.info("loaded turnover %s: champion %s, %d model(s)", f.version, f.champion, len(f.models))
        return f


# --------------------------------------------------------------- helpers
def _parse_pipeline(p: str) -> Tuple[str, Tuple[str, ...]]:
    p = str(p).strip()
    if p in NAIVE:
        return "naive", (p,)
    if ":" not in p:
        raise ModelError("pipeline {!r} must be naive (last5|ma3|ema|profile), direct:<algo> or "
                         "three_stage:<algo>+<algo>+<algo>".format(p))
    kind, rest = p.split(":", 1)
    algos = tuple(rest.split("+"))
    if kind == "direct" and len(algos) == 1:
        return kind, algos
    if kind == "three_stage" and len(algos) == 3:
        return kind, algos
    raise ModelError("pipeline {!r} is not understood".format(p))


def _reference(X: pd.DataFrame) -> dict:
    from ..monitoring.monitor import Monitor
    return Monitor.feature_reference(X)


def labels(series: pd.Series) -> np.ndarray:
    """Text labels with missing values as 'unknown' (pandas 3 keeps NaN through astype(str))."""
    return series.astype("string").fillna("unknown").to_numpy(dtype=object)


def _normalise(raw: np.ndarray, group: np.ndarray) -> np.ndarray:
    raw = np.clip(np.nan_to_num(np.asarray(raw, dtype="float64"), nan=0.0), 0, None)
    den = pd.Series(raw).groupby(np.asarray(group)).transform("sum").to_numpy()
    n = pd.Series(raw).groupby(np.asarray(group)).transform("size").to_numpy()
    return np.where(den > 0, raw / np.maximum(den, 1e-300), 1.0 / np.maximum(n, 1))


def true_odds_coverage(store, days, sample: int = 15) -> float:
    """Share of forecastable rows with an HKJC true price, over up to ``sample`` of ``days``."""
    days = list(days)
    if not days:
        return float("nan")
    n = hit = 0
    for i in sorted({int(x) for x in np.linspace(0, len(days) - 1, min(sample, len(days)))}):
        s = store.get(days[i]).sel
        if s.empty or "p_hkjc_true" not in s.columns:
            continue
        f = s["forecastable"].to_numpy(dtype=bool)
        n += int(f.sum())
        hit += int(np.isfinite(s.loc[f, "p_hkjc_true"].to_numpy(dtype="float64")).sum())
    return hit / n if n else float("nan")


def _day_cap(t, response: str, n_days: int) -> int:
    """Rows to keep from one day: the per-day cap, shrunk so n_days fit in max_fit_rows."""
    per_day = t.fit_rows_per_day if response != "match_total" else 10 ** 9
    return int(max(500, min(per_day, t.max_fit_rows // max(n_days, 1))))


def _sample_groups(fs: FeatureSet, cap: int, rng) -> FeatureSet:
    """Keep whole normalisation groups so sampled shares still sum to one."""
    if len(fs) <= cap:
        return fs
    groups = np.unique(fs.group)
    frac = cap / len(fs)
    keep = set(groups[rng.random(len(groups)) < frac].tolist())
    return fs.subset(np.isin(fs.group, list(keep)))


def _fmt(x) -> str:
    return "n/a" if x is None else "{:,.1f}".format(x)


def _pct(x) -> str:
    return "n/a" if x is None else "{:.1%}".format(x)
