@echo off
REM Step 3: the real run, 2026-07-01 to 2026-09-15, with the optimizer stage.
setlocal
cd /d "%~dp0"
set "DATA=%~1"
if not defined DATA set "DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m backtest.run run --data-dir "%DATA%" --out-dir "out" ^
    --start 2026-07-01 --end 2026-09-15 --optimize
echo.
echo Open out\report.html
pause
