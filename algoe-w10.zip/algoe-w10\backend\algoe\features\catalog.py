"""
Feature Catalog

Every feature is declared once, here, with the hypothesis it tests. The
engineer builds exactly these columns; the validator fills and clips them
from this table; the backtest's group ablation drops one group at a time
and reports what it was worth. A feature that cannot be tied to a
hypothesis does not go in.

Kinds tell each estimator what it may use:

    raw       continuous value                  GLM, GAM (smooth), GBM, NN
    basis     hinge max(x - knot, 0) of a raw   GLM, NN   (GAM builds its own splines,
                                                          GBM does not need them)
    flag      0 / 1                             all
    encoded   target encoding, shrunk           all

Hypotheses (H#) are written as the direction we expect; the ablation and the
fitted coefficients either back them or reject them.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

HYPOTHESES: Dict[str, str] = {
    "H1": "Match money is autocorrelated: recent match totals predict the next bucket (+).",
    "H2": "Pre-match money ramps up towards kick-off (hyperbolic in minutes to KO).",
    "H3": "In-play money follows the clock: rises through the match, dips at half time.",
    "H4": "Goals and red cards cause a demand spike that decays over ~5-15 minutes (+).",
    "H5": "Some leagues / matches draw far more money; a shrunk league level and the match's "
          "own running level carry it (+).",
    "H6": "Concurrent matches split attention: more live matches -> less per match (-).",
    "H7": "Weekend, evening and holiday buckets take more money (+).",
    "H8": "Close, high-scoring games take more in-play money; a settled blowout takes less.",
    "H9": "More pools / lines open -> more money on the match (+).",
    "H11": "Pool shares depend on phase (FH pools die at half time, totals gain late).",
    "H12": "Recent pool shares persist (+).",
    "H14": "The main (most balanced) line takes most of a pool; share decays with distance (-).",
    "H15": "Within a line the side whose price is more generous (vs HKJC's own true odds or the "
           "market) takes more money (+): this is the price elasticity the optimiser uses.",
    "H16": "Punters prefer some sides (overs, favourites) independent of price.",
    "H17": "A price that has just shortened signals money that keeps coming (herding).",
    "H18": "A selection's recent share of its pool persists (+).",
    "H19": "When the main line moves, the money follows the position, not the old line id.",
    "H20": "Stale prices (no update for a long time) take little money (-).",
}


@dataclass(frozen=True)
class FeatureSpec:
    name: str
    group: str
    kind: str
    hypothesis: str
    fill: float = 0.0
    lo: Optional[float] = None
    hi: Optional[float] = None
    description: str = ""


def _hinges(prefix: str, knots: Sequence[float], group: str, hyp: str) -> List[FeatureSpec]:
    return [FeatureSpec("{}{}".format(prefix, i), group, "basis", hyp, 0.0, 0.0, None,
                        "max(x - {:g}, 0)".format(k)) for i, k in enumerate(knots)]


def match_specs(ko_knots: Sequence[float], minute_knots: Sequence[float]) -> List[FeatureSpec]:
    s = [
        # H1 memory
        FeatureSpec("m_log_l1", "memory_match", "raw", "H1", 0, 0, 20, "log1p match money T-1"),
        FeatureSpec("m_log_l2", "memory_match", "raw", "H1", 0, 0, 20),
        FeatureSpec("m_log_l3", "memory_match", "raw", "H1", 0, 0, 20),
        FeatureSpec("m_log_ewma", "memory_match", "raw", "H1", 0, 0, 20, "log1p EWMA of 6 lags"),
        FeatureSpec("m_any_l1", "memory_match", "flag", "H1"),
        FeatureSpec("m_trend", "memory_match", "raw", "H1", 0, -15, 15, "log1p l1 - log1p l2"),
        FeatureSpec("m_log_today", "memory_match", "raw", "H1", 0, 0, 25, "log1p money so far today"),
        # H2 / H3 lifecycle
        FeatureSpec("inplay", "lifecycle", "flag", "H3"),
        FeatureSpec("halftime", "lifecycle", "flag", "H3"),
        FeatureSpec("stoppage", "lifecycle", "flag", "H3", description="minute > 90"),
        FeatureSpec("pre_ko_min", "lifecycle", "raw", "H2", 360, 0, 720, "minutes to KO, pre-match"),
        FeatureSpec("minute", "lifecycle", "raw", "H3", 0, 0, 130, "match minute in play"),
    ]
    s += _hinges("ko_h", ko_knots, "lifecycle", "H2")
    s += _hinges("min_h", minute_knots, "lifecycle", "H3")
    s += [
        # H4 events
        FeatureSpec("goal_p3", "events", "raw", "H4", 0, 0, 5, "sum exp(-age/3) over goals"),
        FeatureSpec("goal_p10", "events", "raw", "H4", 0, 0, 5),
        FeatureSpec("red_p10", "events", "raw", "H4", 0, 0, 3),
        FeatureSpec("goals_so_far", "events", "raw", "H8", 0, 0, 12),
        FeatureSpec("abs_score_diff", "events", "raw", "H8", 0, 0, 10),
        FeatureSpec("since_goal", "events", "raw", "H4", 1, 0, 1, "min(minutes since goal, 120)/120"),
        # H5 popularity
        FeatureSpec("league_level", "popularity", "encoded", "H5", 0, -10, 10,
                    "shrunk league log-money level vs global"),
        FeatureSpec("league_known", "popularity", "flag", "H5"),
        # H6 concurrency
        FeatureSpec("n_live", "concurrency", "raw", "H6", 0, 0, 200, "matches in play now"),
        FeatureSpec("n_board", "concurrency", "raw", "H6", 0, 0, 500, "matches on the board now"),
        FeatureSpec("log_board_l1", "concurrency", "raw", "H6", 0, 0, 25),
        FeatureSpec("match_share_board_l1", "concurrency", "raw", "H6", 0, 0, 1),
        FeatureSpec("match_rank_l1", "concurrency", "raw", "H6", 0.5, 0, 1, "rank by money / n_board"),
        # H7 calendar
        FeatureSpec("weekend", "calendar", "flag", "H7"),
        FeatureSpec("holiday", "calendar", "flag", "H7"),
        FeatureSpec("evening", "calendar", "flag", "H7", description="HK 19:00-23:59"),
        FeatureSpec("hour_s1", "calendar", "raw", "H7"), FeatureSpec("hour_c1", "calendar", "raw", "H7"),
        FeatureSpec("hour_s2", "calendar", "raw", "H7"), FeatureSpec("hour_c2", "calendar", "raw", "H7"),
        FeatureSpec("dow_s", "calendar", "raw", "H7"), FeatureSpec("dow_c", "calendar", "raw", "H7"),
        # H8 competitiveness
        FeatureSpec("tg_full", "competitiveness", "raw", "H8", 2.6, 0, 12,
                    "expected full-match goals: scored + still to come"),
        FeatureSpec("abs_sup", "competitiveness", "raw", "H8", 0, 0, 6),
        FeatureSpec("balance", "competitiveness", "raw", "H8", 0, 0, 1, "|sup| / tg"),
        # H9 breadth
        FeatureSpec("log_n_pools", "breadth", "raw", "H9", 0, 0, 5),
        FeatureSpec("log_n_lines", "breadth", "raw", "H9", 0, 0, 7),
    ]
    return s


FAMILIES = ("goal_total", "goal_hdc", "goal_1x2", "goal_exact", "goal_other",
            "corner_total", "corner_hdc", "corner_other", "all_up", "other")


def pool_specs() -> List[FeatureSpec]:
    s = [
        FeatureSpec("p_share_l1", "memory_pool", "raw", "H12", 0, 0, 1),
        FeatureSpec("p_share_l2", "memory_pool", "raw", "H12", 0, 0, 1),
        FeatureSpec("p_share_ewma", "memory_pool", "raw", "H12", 0, 0, 1),
        FeatureSpec("p_any_l1", "memory_pool", "flag", "H12"),
        FeatureSpec("p_log_l1", "memory_pool", "raw", "H12", 0, 0, 20),
        FeatureSpec("p_n_lines", "breadth", "raw", "H9", 0, 0, 5, "log1p lines open in the pool"),
        FeatureSpec("p_balance", "line_position", "raw", "H14", 0.5, 0, 1,
                    "min |pH - pA| over the pool's lines"),
        FeatureSpec("p_margin", "price", "raw", "H15", 0.08, -0.2, 0.6, "book margin of the main line"),
        FeatureSpec("pool_level", "popularity", "encoded", "H11", 0, -10, 10,
                    "shrunk log share of this pool (by phase), parent = family"),
        FeatureSpec("first_half", "bet_type", "flag", "H11"),
        FeatureSpec("extra_time", "bet_type", "flag", "H11"),
        FeatureSpec("fh_to_ht", "lifecycle", "raw", "H11", 1, 0, 1, "first-half pool: share of FH left"),
        FeatureSpec("inplay", "lifecycle", "flag", "H11"),
        FeatureSpec("minute", "lifecycle", "raw", "H11", 0, 0, 130),
        FeatureSpec("pre_ko_min", "lifecycle", "raw", "H11", 360, 0, 720),
    ]
    for f in FAMILIES:
        s.append(FeatureSpec("fam_" + f, "bet_type", "flag", "H11"))
        s.append(FeatureSpec("fam_{}_ip".format(f), "bet_type", "flag", "H11"))
    return s


def selection_specs() -> List[FeatureSpec]:
    s = [
        # H18 memory
        FeatureSpec("s_log_l1", "memory_selection", "raw", "H18", 0, 0, 20),
        FeatureSpec("s_log_l2", "memory_selection", "raw", "H18", 0, 0, 20),
        FeatureSpec("s_log_l3", "memory_selection", "raw", "H18", 0, 0, 20),
        FeatureSpec("s_log_ewma_fast", "memory_selection", "raw", "H18", 0, 0, 20),
        FeatureSpec("s_log_ewma_slow", "memory_selection", "raw", "H18", 0, 0, 20),
        FeatureSpec("s_any_l1", "memory_selection", "flag", "H18"),
        FeatureSpec("s_any_l6", "memory_selection", "flag", "H18"),
        FeatureSpec("s_share_pool_l1", "memory_selection", "raw", "H18", 0, 0, 1),
        FeatureSpec("s_share_pool_l2", "memory_selection", "raw", "H18", 0, 0, 1),
        FeatureSpec("s_share_pool_ewma", "memory_selection", "raw", "H18", 0, 0, 1),
        FeatureSpec("s_share_line_l1", "memory_selection", "raw", "H18", 0.5, 0, 1),
        FeatureSpec("pos_share_l1", "memory_selection", "raw", "H19", 0, 0, 1,
                    "money in the same (pool, rank, side) position at T-1 / pool money T-1"),
        FeatureSpec("s_log_tickets_l1", "memory_selection", "raw", "H18", 0, 0, 12),
        FeatureSpec("s_log_avg_stake_l1", "memory_selection", "raw", "H18", 0, 0, 15),
        # H15 / H17 price
        FeatureSpec("imp", "price", "raw", "H15", 0.5, 0, 1, "1 / odds"),
        FeatureSpec("log_odds", "price", "raw", "H15", 0.7, 0, 7),
        FeatureSpec("value_true", "price", "raw", "H15", -0.07, -1, 2,
                    "odds x p(HKJC true) - 1: punter value on HKJC's own belief"),
        FeatureSpec("value_mkt", "price", "raw", "H15", 0, -1, 2, "odds x p(market) - 1"),
        FeatureSpec("hk_vs_mkt", "price", "raw", "H15", 0, -0.5, 0.5, "odds / market odds - 1"),
        FeatureSpec("has_mkt", "price", "flag", "H15"),
        FeatureSpec("odds_move_5", "price", "raw", "H17", 0, -1, 1, "log odds now - 5 min ago"),
        FeatureSpec("odds_move_15", "price", "raw", "H17", 0, -1, 1),
        FeatureSpec("log_odds_age", "price", "raw", "H20", 0, 0, 7, "log1p minutes since price update"),
        # H14 / H19 line position
        FeatureSpec("rank_0", "line_position", "flag", "H14", description="main line"),
        FeatureSpec("rank_1", "line_position", "flag", "H14"),
        FeatureSpec("rank_2p", "line_position", "flag", "H14"),
        FeatureSpec("line_offset", "line_position", "raw", "H14", 0, -8, 8, "line - main line"),
        FeatureSpec("abs_line_offset", "line_position", "raw", "H14", 0, 0, 8),
        FeatureSpec("line_balance", "line_position", "raw", "H14", 0, 0, 1, "|pH - pA| on this line"),
        FeatureSpec("main_moved", "line_position", "flag", "H19"),
        FeatureSpec("line_age", "line_position", "raw", "H19", 1, 0, 1, "min(minutes priced, 600)/600"),
        FeatureSpec("n_lines_pool", "line_position", "raw", "H14", 0, 0, 5, "log1p lines in pool"),
        # H16 side preference
        FeatureSpec("side_home_over", "bet_type", "flag", "H16"),
        FeatureSpec("side_draw", "bet_type", "flag", "H16"),
        FeatureSpec("is_fav", "bet_type", "flag", "H16", description="shorter-priced side of its line"),
        FeatureSpec("first_half", "bet_type", "flag", "H11"),
        FeatureSpec("inplay", "lifecycle", "flag", "H3"),
        FeatureSpec("minute", "lifecycle", "raw", "H3", 0, 0, 130),
        FeatureSpec("since_goal", "events", "raw", "H4", 1, 0, 1),
    ]
    for f in FAMILIES:
        s.append(FeatureSpec("fam_" + f, "bet_type", "flag", "H16"))
    s.append(FeatureSpec("pool_level", "popularity", "encoded", "H11", 0, -10, 10))
    return s


# Columns the price response of the optimiser recomputes at a candidate price.
PRICE_FEATURES = ("imp", "log_odds", "value_true", "value_mkt", "hk_vs_mkt")


def by_name(specs: Sequence[FeatureSpec]) -> Dict[str, FeatureSpec]:
    out: Dict[str, FeatureSpec] = {}
    for s in specs:
        out.setdefault(s.name, s)
    return out


def catalog_table(ko_knots, minute_knots) -> List[dict]:
    """Every feature with its level and hypothesis - what docs/FEATURES is built from."""
    rows = []
    for level, specs in (("match", match_specs(ko_knots, minute_knots)), ("pool", pool_specs()),
                         ("selection", selection_specs())):
        for s in specs:
            rows.append({"level": level, "name": s.name, "group": s.group, "kind": s.kind,
                         "hypothesis": s.hypothesis, "statement": HYPOTHESES.get(s.hypothesis, ""),
                         "fill": s.fill, "lo": s.lo, "hi": s.hi, "description": s.description})
    return rows
