"""
Mock Pricing Engine

Answers a params message the way HKJC's pricing engine (E-HV11-01) does, in
its exact reply format, priced by our own pricer:

    every selection of the match Algo E can price (the rows of its last refresh)
    at the published TG / SUP, read back into our terms by the mapping
    the first half from the full match, as hkjc_theta derives it
    the draw factor from the message
    TrueOdds = 1 / p at what was published
    sell = HKJC's posted price x p(HKJC's theta) / p(published) x weight (the engine makes
           the board, so HKJC's own theta gives the board back); fair / (1 + pool margin)
           x weight where there is no posted price; to 3 decimals (the engine's own price
           ladder is not known, and a coarse one would move every price off the board)
    Weight echoes what was sent, 0.0 where nothing was

The dry run, the tests and selftest S13 run the whole loop on it. The real
engine's own rules are NOT in it: where the engine differs (spec section 4:
corners wider than Poisson, TG decayed by the clock in play) the replication
gap at the office shows it. ``corner_dispersion`` plays an engine whose
corners are negative binomial.

Change Log:
-----------
2026-10-29      Initialize
"""

from __future__ import annotations

import json
from typing import Callable, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from src.hkjc.kafka_messages import Mapping, draw_factor_from_engine, encode, theta_from_engine

from ..core.taxonomy import PRICEABLE
from ..pricing.pricer import (DOMAIN_DIMS, BookPricer, BookRows, Conventions, MatchState, repair_theta,
                              theta_from_params)


class MockEngine:
    def __init__(self, settings, mapping: Mapping, lookup: Callable[[int], Optional[Tuple[pd.DataFrame, dict]]],
                 server_app_id: str = "ALGOE-MOCK", corner_dispersion: float = 1.0, clock=None):
        self.settings = settings
        self.mapping = mapping
        self.lookup = lookup
        self.server_app_id = server_app_id
        self.corner_dispersion = float(corner_dispersion)
        self.clock = clock or pd.Timestamp.now
        self.pools = {int(v["code"]): k for k, v in mapping.pool_types.items() if v.get("code") is not None}
        self.labels = {pool: {int(sid): label for label, sid in table.items()}
                       for pool, table in mapping.selections.items()}
        self.states = {int(v["code"]): k for k, v in mapping.game_states.items() if v.get("code") is not None}
        self.answered = 0

    def _weights(self, message: dict) -> Dict[tuple, float]:
        out = {}
        for pw in message.get("PoolWeightings") or []:
            pool = self.pools.get(int(pw["PoolType"]))
            if pool is None:
                continue
            for s in pw.get("Selections") or []:
                label = self.labels.get(pool, {}).get(int(s["SelectionId"]))
                if label is not None:
                    out[(pool, round(float(pw["LineValue"]), 2), label)] = float(s["Weight"])
        return out

    def reply(self, message) -> Optional[str]:
        """The reply's wire text, or None for a match the lookup does not know."""
        msg = json.loads(message) if isinstance(message, (str, bytes)) else message
        got = self.lookup(int(msg["EventId"]))
        if got is None or got[0] is None or len(got[0]) == 0:
            return None
        rows, header = got
        header = header or {}
        minute = float(header.get("minute") or 0.0)
        in_play = bool(header.get("in_play"))
        score, corners = header.get("score") or [0, 0], header.get("corners") or [0, 0]
        state = MatchState(home_goals=int(score[0]), away_goals=int(score[1]), home_corners=int(corners[0]),
                           away_corners=int(corners[1]), minute=minute, phase=str(header.get("phase") or "prematch"))
        ft = theta_from_engine(msg["TgsupParameters"], minute, in_play, self.mapping)
        splits = header.get("splits") or {}
        theta = theta_from_params(ft["goal_tg"], ft["goal_sup"], ft["corner_tg"], ft["corner_sup"],
                                  splits.get("goal") or 0.45, splits.get("corner") or 0.47, state)
        o = self.settings.optimizer
        pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap,
                                        draw_factor=draw_factor_from_engine(msg["TgsupParameters"]["DrawFactor"],
                                                                            self.mapping),
                                        corner_dispersion=self.corner_dispersion))
        r = rows[rows["theta_domain"].isin(list(DOMAIN_DIMS)) & rows["market"].isin(list(PRICEABLE))].copy()
        if r.empty:
            return None
        br = BookRows(r["theta_domain"].to_numpy(), r["market"].to_numpy(), r["line"].to_numpy(dtype="float64"),
                      r["side"].to_numpy())
        p, _ = pricer.probabilities(br, theta, state)
        r["_p"] = p
        # The real engine makes HKJC's board: at HKJC's own theta its prices are the board. So the posted price
        # moves by the model's relative change, as the optimiser's delta mode assumes; a row with no posted
        # price takes fair / (1 + margin).
        r["_p0"] = np.nan
        if header.get("theta_now") and "odds" in r.columns:
            r["_p0"], _ = pricer.probabilities(br, repair_theta(header["theta_now"]), state)
        r = r[np.isfinite(r["_p"]) & (r["_p"] > 1e-9)]
        sent = self._weights(msg)
        pools = []
        for pid, g in r.sort_values(["pool_id", "line_id", "combination_id"]).groupby("pool_id", sort=False):
            name = str(g["pool_name"].iloc[0]).upper()
            margin = self.settings.margin_for(name)
            lines = []
            for lid, h in g.groupby("line_id", sort=False):
                value = float(h["line"].iloc[0]) if np.isfinite(h["line"].iloc[0]) else 0.0
                combos = []
                for _, x in h.iterrows():
                    label = str(x["combination_string"] or "").strip()
                    w = sent.get((name, round(value, 2), label))
                    fair = 1.0 / float(x["_p"])
                    posted = float(x["odds"]) if "odds" in x.index and pd.notna(x["odds"]) else np.nan
                    if np.isfinite(posted) and posted > 1.0 and np.isfinite(x["_p0"]) and x["_p0"] > 0:
                        sell = posted * float(x["_p0"]) / float(x["_p"])
                    else:
                        sell = fair / (1.0 + margin)
                    combos.append({"CombinationID": int(x["combination_id"]), "CombinationLabel": label,
                                   "TrueOdds": round(fair, 5),
                                   "CalcCurrentPrice": max(round(sell * (w if w else 1.0), 3), 1.0),
                                   "Weight": w if w else 0.0})
                lines.append({"LineId": int(lid), "LineLabel": "" if pd.isna(h["line_label"].iloc[0])
                              else str(h["line_label"].iloc[0]), "LineValues": value, "Combinations": combos,
                              "Margin": round(sum(1.0 / c["CalcCurrentPrice"] for c in combos), 5)})
            pools.append({"PoolId": int(pid), "PoolType": name, "InstanceNo": 0, "Lines": lines})
        text = header.get("game_state") or self.states.get(int(msg.get("GameState", -1)), "")
        now = pd.Timestamp(self.clock()) - pd.Timedelta(hours=self.mapping.reply_utc_offset_hours)
        desc = "|".join("{}={}".format(pl["PoolType"], ",".join("{:g}".format(ln["LineValues"]) for ln in pl["Lines"]))
                        for pl in pools)
        self.answered += 1
        return encode({
            "ServerAppID": self.server_app_id, "EventId": int(msg["EventId"]),
            "MapResult": {"EventID": int(msg["EventId"]), "GameState": text, "GameStageReference": text + "90",
                          "CalculationID": 0,
                          "GameClock": {"TimeInSecond": int(round(minute * 60)), "Minutes": int(minute),
                                        "Seconds": int(round(minute * 60)) % 60, "IsClockSet": in_play},
                          "EventTime": now.strftime("%Y-%m-%dT%H:%M:%S.") + "{:03d}Z".format(now.microsecond // 1000),
                          "PoolLinesShortDesc": desc + "|", "Pools": pools}})
