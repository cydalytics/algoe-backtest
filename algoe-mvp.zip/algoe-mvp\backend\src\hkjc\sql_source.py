"""
Live SQL Source

Runs the notebook's seven queries against the HKJC SQL Servers over pyodbc
and returns a Snapshot. This is the production path inside the offline
environment; pyodbc is imported lazily so the rest of the stack still runs
on a machine that has never had a SQL driver installed.

Change Log:
-----------
2026-08-30      Initialize
2026-10-01      Active pools carry close_datetime when readable; every parameter row kept as params_history
2026-10-26      read(): one query on a named connection, for the live money probe; clone() for the
                live engine's focus thread
2026-11-19      intent per connection (ALGOE_SQL_INTENT_<KEY>): readonly by default, readwrite on request
2026-11-20      fetch(since=): only the odds, market odds and money rows from that moment (incremental reads)
2026-11-21      since= per table (each one's own watermark)
"""

from datetime import datetime

import pandas as pd

from src.core import config
from src.core.exceptions import ExtractionError
from src.core.logging import get_logger
from src.hkjc import queries
from src.hkjc.snapshot import Snapshot, empty_snapshot

log = get_logger(__name__)

# The params database is renamed when HKJC refreshes it. The login that
# worked yesterday is rejected on the old name (ODBC 4068).
_BIS_DATABASES = ("bis1_fbuser_db", "bis2_fbuser_db")


INTENTS = ("readonly", "readwrite")


def readonly_dsn(dsn: str) -> str:
    """The same connection string, asking an availability group for a readable secondary.

    Already present is left as written. The old {SQL Server} driver rejects the keyword; the caller
    connects without it then."""
    parts = [p for p in str(dsn or "").split(";") if p]
    if any(p.upper().startswith("APPLICATIONINTENT=") for p in parts):
        return ";".join(parts)
    parts.append("ApplicationIntent=ReadOnly")
    return ";".join(parts)


def with_intent(dsn: str, intent: str = "readonly") -> str:
    """The connection string for an intent. readonly keeps an ApplicationIntent already written (a DSN set
    by hand wins over the default); readwrite replaces it, because the defaults ask for ReadOnly."""
    intent = (intent or "readonly").strip().lower()
    if intent not in INTENTS:
        raise ValueError("SQL intent must be {}; got {!r}".format(" or ".join(INTENTS), intent))
    if intent == "readonly":
        return readonly_dsn(dsn)
    parts = [p for p in str(dsn or "").split(";") if p and not p.upper().startswith("APPLICATIONINTENT=")]
    parts.append("ApplicationIntent=ReadWrite")
    return ";".join(parts)


def _intent_rejected(exc: BaseException) -> bool:
    text = str(exc).lower()
    return "applicationintent" in text or "invalid connection string attribute" in text


def _database_name(dsn: str) -> str:
    for part in dsn.split(";"):
        if part.upper().startswith("DATABASE="):
            return part.split("=", 1)[1]
    return ""


def _with_database(dsn: str, database: str) -> str:
    parts = []
    replaced = False
    for part in dsn.split(";"):
        if part.upper().startswith("DATABASE="):
            parts.append("DATABASE={}".format(database))
            replaced = True
        elif part:
            parts.append(part)
    if not replaced:
        parts.append("DATABASE={}".format(database))
    return ";".join(parts)


def bis_candidates(dsn: str) -> list:
    """Configured BIS database first, then the other fbuser name."""
    current = _database_name(dsn)
    names = [current] if current else []
    for name in _BIS_DATABASES:
        if name not in names:
            names.append(name)
    out = []
    for name in names:
        alt = _with_database(dsn, name) if name else dsn
        if alt not in out:
            out.append(alt)
    return out


def _database_unavailable(exc: BaseException) -> bool:
    text = str(exc).lower()
    return "cannot open database" in text or "4068" in text


class SqlSource:
    """The HKJC SQL Servers, read exactly the way the notebook reads them."""

    name = "sql"

    def __init__(self, conn_qfm=None, conn_bis=None, conn_bis2=None, intent=None):
        self._dsn = {
            "qfm": conn_qfm or config.SQL_CONN_QFM,
            "bis": conn_bis or config.SQL_CONN_BIS,
            "bis2": conn_bis2 or config.SQL_CONN_BIS2,
        }
        self.intent = dict(config.SQL_INTENT)
        self.intent.update(intent or {})
        for key, value in self.intent.items():
            if value not in INTENTS:
                raise ExtractionError("ALGOE_SQL_INTENT_{} must be {}; got {!r}".format(
                    key.upper(), " or ".join(INTENTS), value))
        self._conn = {}
        self._close_column = True       # pool_h.close_datetime readable; off after one failure

    def describe(self) -> str:
        return "HKJC SQL Server ({})".format(
            self._dsn["qfm"].split("SERVER=")[-1].split(";")[0]
        )

    def clone(self) -> "SqlSource":
        """The same servers on new connections: a pyodbc connection belongs to one thread."""
        return SqlSource(self._dsn["qfm"], self._dsn["bis"], self._dsn["bis2"], intent=self.intent)

    def dsn_for(self, key: str, dsn: str = None) -> str:
        """The connection string ``key`` connects with: its DSN at its intent."""
        return with_intent(dsn if dsn is not None else self._dsn[key], self.intent.get(key, "readonly"))

    # -- connection ----------------------------------------------------------

    def _connect(self, key):
        if key in self._conn:
            return self._conn[key]
        try:
            import pyodbc
        except ImportError as exc:
            raise ExtractionError(
                "pyodbc is not installed - the sql source only runs inside "
                "the HKJC environment. Use ALGOE_SOURCE=sim or =capture here."
            ) from exc
        candidates = bis_candidates(self._dsn[key]) if key == "bis" else [self._dsn[key]]
        errors = []
        for dsn in candidates:
            try:
                conn = pyodbc.connect(self.dsn_for(key, dsn))
            except Exception as exc:
                if _intent_rejected(exc):
                    log.warning("this ODBC driver does not accept ApplicationIntent (%s); connecting "
                                "without it. ODBC Driver 17 for SQL Server honours it.", exc)
                    try:
                        conn = pyodbc.connect(dsn)
                    except Exception as exc2:
                        exc = exc2
                        conn = None
                else:
                    conn = None
            if conn is None:
                errors.append((dsn, exc))
                if key == "bis" and _database_unavailable(exc) and dsn != candidates[-1]:
                    log.warning("BIS database unavailable (%s); trying the other name", exc)
                    continue
                break
            self._conn[key] = conn
            self._dsn[key] = dsn
            if len(candidates) > 1 and dsn != candidates[0]:
                log.warning("using BIS database %s", _database_name(dsn))
            return conn
        tried = "; ".join("{}: {}".format(_database_name(dsn) or dsn, exc) for dsn, exc in errors)
        raise ExtractionError("cannot reach {} ({})".format(key, tried)) from errors[-1][1]

    def _read(self, key, sql, parse_dates=None) -> pd.DataFrame:
        try:
            return pd.read_sql(sql, self._connect(key), parse_dates=parse_dates)
        except ExtractionError:
            raise
        except Exception as exc:
            raise ExtractionError("query against {} failed: {}".format(key, exc)) from exc

    def read(self, key, sql, parse_dates=None) -> pd.DataFrame:
        """One read-only query on a named connection: qfm | bis | bis2."""
        return self._read(key, sql, parse_dates=parse_dates)

    def _active_pools(self) -> pd.DataFrame:
        """Every pool that has started selling, with its close time when the server has one."""
        if self._close_column:
            try:
                return self._read("qfm", queries.ACTIVE_POOLS_WITH_CLOSE, parse_dates=["close_time"])
            except ExtractionError as exc:
                self._close_column = False
                log.warning("pool_h.close_datetime could not be read (%s); closed pools stay listed until "
                            "their full-time result is published", exc)
        return self._read("qfm", queries.ACTIVE_POOLS)

    def close(self):
        for conn in self._conn.values():
            try:
                conn.close()
            except Exception:
                pass
        self._conn.clear()

    # -- extraction ----------------------------------------------------------

    def fetch(self, as_of: datetime = None, match_ids=None, since=None) -> Snapshot:
        """Pull one tick. ``as_of`` only stamps the snapshot; SQL reads now. ``since`` reads only the odds, market
        odds and money rows from that moment on (src.hkjc.incremental merges them into what it read before): one
        moment, or one per table ("odds", "market", "investments"; None reads that table whole)."""
        as_of = as_of or datetime.now()
        since = since if isinstance(since, dict) else {t: since for t in ("odds", "market", "investments")}

        active = self._active_pools()
        active["match_id"] = (
            pd.to_numeric(active["match_id"], errors="coerce").fillna(0).astype(int)
        )
        if match_ids:
            active = active[active["match_id"].isin([int(i) for i in match_ids])]

        ids = sorted(active["match_id"].unique().tolist())
        if not ids:
            log.warning("no active pools at %s", as_of)
            return empty_snapshot(as_of, self.name).conform()

        match_info = self._read(
            "qfm", queries.match_info(ids), parse_dates=["KOTime"]
        ).rename(columns={"MatchId": "match_id"})

        raw_params = self._read(
            "bis", queries.algo_params(ids), parse_dates=["EventTime", "CreateTime"]
        )
        # Keep the newest parameter row per match, as the notebook does.
        params = (
            raw_params.sort_values("EventTime")
            .groupby("EventLevel2ID", as_index=False)
            .last()
            .rename(columns={"EventLevel2ID": "match_id"})
        )

        events = self._read(
            "qfm",
            queries.incidents(ids),
            parse_dates=["incident_datetime", "last_modified_datetime"],
        ).rename(columns={"event_id": "match_id"})

        odds = self._read(
            "qfm", queries.hkjc_odds(ids, since.get("odds")), parse_dates=["effective_datetime"]
        ).rename(columns={"EnumString": "pool_name"})
        odds = odds[~odds["odds"].isna()]

        market = self._read(
            "qfm", queries.market_odds(ids, since.get("market")), parse_dates=["effective_datetime"]
        ).rename(columns={"bet_type_code_str": "pool_name"})
        market = market[~market["odds"].isna()]

        investments = self._read(
            "bis2", queries.investments(ids, since.get("investments")), parse_dates=["start_sell_time"]
        )

        snap = Snapshot(
            as_of=as_of,
            source=self.name,
            active_pools=active,
            match_info=match_info,
            params=params,
            events=events,
            odds=odds,
            market=market,
            investments=investments,
            params_history=raw_params.rename(columns={"EventLevel2ID": "match_id"}),
        ).conform()
        log.info("sql snapshot %s: %s", as_of, snap.summary())
        return snap
