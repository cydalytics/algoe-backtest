"""
Logging

Three sinks, set up once per process by ``setup_logging``:

    console   human-readable, INFO and up
    <run>.log the same lines, DEBUG and up, one file per run
    <run>.jsonl  one JSON object per record - what the monitor and any later
              tooling parse, so a number never has to be scraped out of prose

``log_step`` wraps one numbered stage of a script. It prints the same boxed
header the W02 pipeline uses, times the stage, and marks it PASS or FAIL.
A FAIL re-raises: a stage that broke must stop the run, not be summarised
as a warning further down.

``log_frame`` states the shape and the missing-value picture of a frame,
which is the first thing to look at when a number downstream is wrong.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import contextlib
import json
import logging
import sys
import time
from pathlib import Path
from typing import Iterator, Optional

ROOT = "algoe"
TEXT_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
BOX_WIDTH = 96

_configured = False


class _JsonLines(logging.Handler):
    """One JSON object per record. ``extra={"data": {...}}`` rides along."""

    def __init__(self, path: Path):
        super().__init__(level=logging.DEBUG)
        self._fh = open(path, "a", encoding="utf-8")

    def emit(self, record: logging.LogRecord) -> None:
        try:
            payload = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(record.created)),
                "level": record.levelname,
                "logger": record.name,
                "msg": record.getMessage(),
            }
            data = getattr(record, "data", None)
            if data is not None:
                payload["data"] = data
            if record.exc_info:
                payload["exc"] = logging.Formatter().formatException(record.exc_info)
            self._fh.write(json.dumps(payload, default=str) + "\n")
            self._fh.flush()
        except Exception:                                   # noqa: BLE001
            self.handleError(record)

    def close(self) -> None:
        try:
            self._fh.close()
        finally:
            super().close()


def setup_logging(level: str = "INFO", log_dir: Optional[str] = None,
                  run_name: str = "algoe") -> Optional[Path]:
    """Configure the ``algoe`` logger tree. Safe to call more than once.

    Returns the text log path when a log directory is given.
    """
    global _configured
    root = logging.getLogger(ROOT)
    for h in list(root.handlers):
        root.removeHandler(h)
        h.close()
    root.setLevel(logging.DEBUG)
    root.propagate = False

    console = logging.StreamHandler(stream=sys.stdout)
    console.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    console.setFormatter(logging.Formatter(TEXT_FORMAT, datefmt="%H:%M:%S"))
    root.addHandler(console)

    text_path = None
    if log_dir:
        folder = Path(log_dir)
        folder.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        text_path = folder / "{}-{}.log".format(run_name, stamp)
        fh = logging.FileHandler(text_path, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(TEXT_FORMAT))
        root.addHandler(fh)
        root.addHandler(_JsonLines(folder / "{}-{}.jsonl".format(run_name, stamp)))
    _configured = True
    return text_path


def get_logger(name: str) -> logging.Logger:
    """Module logger under the ``algoe`` tree (pass ``__name__``)."""
    if not _configured and not logging.getLogger(ROOT).handlers:
        setup_logging()
    if not name.startswith(ROOT):
        name = "{}.{}".format(ROOT, name)
    return logging.getLogger(name)


def _box(lines) -> str:
    top = "\u250c" + "\u2500" * (BOX_WIDTH - 2) + "\u2510"
    body = ["\u2502 {:<{}} \u2502".format(str(line)[:BOX_WIDTH - 4], BOX_WIDTH - 4) for line in lines]
    bottom = "\u2514" + "\u2500" * (BOX_WIDTH - 2) + "\u2518"
    return "\n".join([top] + body + [bottom])


@contextlib.contextmanager
def log_step(logger: logging.Logger, step: str, title: str, detail: str = "") -> Iterator[dict]:
    """Time one stage; PASS on normal exit, FAIL (and re-raise) on error.

    The yielded dict is where the stage leaves its one-line result::

        with log_step(log, "04", "Train turnover") as step:
            ...
            step["result"] = "12 models, champion glm three_stage"
    """
    logger.info("\n" + _box(["STEP {}  {}".format(step, title), detail]))
    started = time.perf_counter()
    info: dict = {"result": ""}
    try:
        yield info
    except Exception as exc:
        seconds = time.perf_counter() - started
        logger.error("[FAIL] step %s %s after %.1fs: %s", step, title, seconds, exc,
                     extra={"data": {"step": step, "status": "fail", "seconds": seconds}})
        raise
    seconds = time.perf_counter() - started
    logger.info("[PASS] step %s %s (%.1fs) %s", step, title, seconds, info.get("result", ""),
                extra={"data": {"step": step, "status": "pass", "seconds": seconds,
                                "result": info.get("result", "")}})


def log_frame(logger: logging.Logger, name: str, frame, columns=None, level: int = logging.INFO) -> None:
    """Rows, columns and the worst missing-value columns of a DataFrame."""
    if frame is None:
        logger.log(level, "%s: None", name)
        return
    rows, cols = frame.shape
    look = list(columns) if columns else list(frame.columns)
    look = [c for c in look if c in frame.columns]
    missing = {}
    if rows and look:
        na = frame[look].isna().mean()
        missing = {c: round(float(v), 4) for c, v in na.sort_values(ascending=False).head(8).items() if v > 0}
    logger.log(level, "%s: %s rows x %s cols; most missing: %s", name, f"{rows:,}", cols,
               missing or "none",
               extra={"data": {"frame": name, "rows": rows, "cols": cols, "missing": missing}})
