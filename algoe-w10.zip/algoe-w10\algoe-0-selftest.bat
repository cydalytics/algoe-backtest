@echo off
REM Algo E - selftest. Run this first on a new machine and after every update.
REM The whole chain on a generated world whose answers are known: no Raw_Data, no SQL.
REM You want "11 PASS, 0 WARN, 0 FAIL" (a WARN on probability is acceptable).
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
python -m algoe selftest %*
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Selftest passed.) else (echo Selftest FAILED with exit code %CODE%. Read the FAIL lines above; the log is in backend\.selftest_data\logs.)
pause
exit /b %CODE%
