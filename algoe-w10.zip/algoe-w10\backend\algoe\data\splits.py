"""
Day Splits

Which days a model may learn from, which days choose between models, and
which days report the result. Always by calendar day, never by row: two
rows of the same match share one outcome and one crowd, so a random split
leaks the answer into training.

    |------------- train -------------|-- val --|------ test ------|
    fit coefficients                   choose     reported once
                                       model /
                                       blend

Walk-forward (the series the workbench reads) instead refits every
``refit_days`` on an expanding window of days strictly before the day being
predicted; the first ``warmup_days`` days are predicted by last-5-minutes so
no day drops out of a comparison.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      DaySplit.from_dict; from_dates / for_window (split by window.val_start / test_start)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator, List, Sequence, Tuple

import pandas as pd

from ..core.exceptions import ConfigError


@dataclass(frozen=True)
class DaySplit:
    train: Tuple[pd.Timestamp, ...]
    val: Tuple[pd.Timestamp, ...]
    test: Tuple[pd.Timestamp, ...]

    @classmethod
    def from_days(cls, days: Sequence, val_days: int, test_days: int,
                  min_train_days: int = 7) -> "DaySplit":
        d = sorted(pd.Timestamp(x).normalize() for x in days)
        need = val_days + test_days + min_train_days
        if len(d) < need:
            raise ConfigError(
                "window has {} day(s) with data; train/val/test needs at least {} "
                "({} train + {} val + {} test). Widen window.start/end or shrink "
                "window.val_days / window.test_days.".format(len(d), need, min_train_days,
                                                           val_days, test_days))
        test = tuple(d[-test_days:])
        val = tuple(d[-(test_days + val_days):-test_days])
        train = tuple(d[:-(test_days + val_days)])
        return cls(train=train, val=val, test=test)

    @classmethod
    def from_dates(cls, days: Sequence, val_start, test_start) -> "DaySplit":
        """train < val_start <= val < test_start <= test, on the days that have data."""
        d = sorted(pd.Timestamp(x).normalize() for x in days)
        v, t = pd.Timestamp(val_start).normalize(), pd.Timestamp(test_start).normalize()
        split = cls(train=tuple(x for x in d if x < v), val=tuple(x for x in d if v <= x < t),
                    test=tuple(x for x in d if x >= t))
        empty = [k for k in ("train", "val", "test") if not getattr(split, k)]
        if empty:
            raise ConfigError("no day with data in {} for window.val_start {} / test_start {} ({} day(s) "
                              "with data from {} to {})".format(empty, v.date(), t.date(), len(d),
                                                                d[0].date() if d else "-",
                                                                d[-1].date() if d else "-"))
        return split

    @classmethod
    def for_window(cls, days: Sequence, window) -> "DaySplit":
        """The split the window settings ask for: by dates when both are set, else by counts."""
        if getattr(window, "val_start", "") and getattr(window, "test_start", ""):
            return cls.from_dates(days, window.val_start, window.test_start)
        n = len(list(days))
        return cls.from_days(days, window.val_days, window.test_days,
                             min(window.min_train_days, max(n - window.val_days - window.test_days, 1)))

    def role(self, day) -> str:
        day = pd.Timestamp(day).normalize()
        if day in self.test:
            return "test"
        if day in self.val:
            return "val"
        if day in self.train:
            return "train"
        return "none"

    def describe(self) -> str:
        def span(x):
            return "{}..{} ({}d)".format(x[0].date(), x[-1].date(), len(x)) if x else "-"
        return "train {} | val {} | test {}".format(span(self.train), span(self.val), span(self.test))

    def to_dict(self) -> dict:
        return {k: [str(x.date()) for x in getattr(self, k)] for k in ("train", "val", "test")}

    @classmethod
    def from_dict(cls, d: dict) -> "DaySplit":
        """The inverse of to_dict: a model's stored split, to refit or re-score on the same days."""
        return cls(*(tuple(pd.Timestamp(x).normalize() for x in (d or {}).get(k) or ())
                     for k in ("train", "val", "test")))


def walk_forward(days: Sequence, warmup_days: int, refit_days: int,
                 val_days: int = 3) -> Iterator[Tuple[pd.Timestamp, List[pd.Timestamp], List[pd.Timestamp], bool]]:
    """Yield (day, fit_days, choose_days, refit) for every day in order.

    ``fit_days`` and ``choose_days`` are strictly before ``day``. ``refit`` is
    True on the days a new model should be trained. Before ``warmup_days``
    days have passed, fit_days is empty and the caller predicts last 5 min.
    """
    d = sorted(pd.Timestamp(x).normalize() for x in days)
    since = None
    for i, day in enumerate(d):
        history = d[:i]
        if len(history) < warmup_days:
            yield day, [], [], False
            continue
        refit = since is None or since >= refit_days
        n_val = min(val_days, max(len(history) - 1, 0))
        fit = history[:len(history) - n_val] if n_val else history
        choose = history[len(history) - n_val:] if n_val else []
        yield day, fit, choose, refit
        since = 1 if refit else since + 1
