"""
Command line

One entry point for every stage, so a scheduled task, a .bat on the office
box and a developer at a prompt all run exactly the same code:

    python -m algoe <command> [options]        (or: python scripts\\sNN_<command>.py)

    selftest            the whole chain on a generated world with known truth
    check-data          what is in Raw_Data: tables, columns, coverage, pool codes, leagues, each investment day
    build-panel         per-day panel cache for the window (the W06 engine's cache)
    build-features      per-day feature cache for the window
    train-turnover      every turnover pipeline: fit / choose on val / report on test / save
    train-probability   every calibration: fit / choose on val / report on test / save
    backtest            every comparison on the held-out days -> report.html
    parity              training vs serving inputs at a moment (train/serve skew and leak test)
    probe-live          one match's live money rows: spacing, duplicates, running totals, first-half split
    bench-live          the fast lane's cycle times on a card (p50 / p95, the SQL read, behind, data age)
    fit-far-prematch    the far pre-match curve: money days before kick-off, outside the model window
    kafka-check         Kafka on the TEST topics: brokers, login, one message and the pricing engine's reply
    live                the live engine: sweep each bucket + focus refresh
    monitor             forecasts vs what arrived, feature drift, unseen leagues / pool codes
    models              list versions and champions, promote or roll back
    update-data         Raw_Data up to now with the notebook's queries, each investment day checked; the days
                        read again rebuilt; --days FROM:TO extracts only those days
    score-days          walk-forward: each new day scored for the champion that served it (reports/daily)
    nightly             new days in -> scored walk-forward -> health -> refit on the rolling window -> promote

Every command takes:

    --settings PATH     JSON settings file (default: env ALGOE_SETTINGS)
    --set S.K=V         override one setting, repeatable: --set optimizer.prob_band=0.03
    --data-dir PATH     Raw_Data (default: env ALGOE_DATA_DIR, else the S:\\ path)
    --work-dir PATH     models / features / reports / logs (default: beside Raw_Data)
    --start / --end     the window, YYYY-MM-DD
    --log-level LEVEL   DEBUG | INFO | WARNING | ERROR

Every run writes <work>/runs/<stamp>_<command>/ with settings.json (the
resolved settings) and summary.json, and a log under <work>/logs, so every
number in every report traces back to the code, window and settings behind it.

Exit codes: 0 ok, 1 failed, 2 finished with alerts (monitor / nightly).

Change Log:
-----------
2026-10-01      Initialize
2026-10-26      probe-live; backtest --only replication without a model (the first-half split check);
                update-data, the nightly's first step
2026-10-29      kafka-check
2026-11-19      probe-live --intent; fit-far-prematch
2026-11-20      update-data checks each investment day (--days, --force); check-data gives each day a verdict;
                score-days (walk-forward) in the nightly before the refit, which records its run; the report
                window and backtest take a serving refit for the days after its fit
2026-11-21      score-days revisits days scored while provisional; --days FROM:TO checked (order, dates)
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .core.exceptions import AlgoEError, ConfigError
from .core.io import read_json, write_json
from .core.logging import get_logger, setup_logging
from .settings import Settings, describe

logger = get_logger("algoe.cli")

EXIT_OK, EXIT_FAIL, EXIT_ALERT = 0, 1, 2


# ================================================================ plumbing
class Run:
    """One invocation: its resolved settings, its folder, its summary.json."""

    def __init__(self, command: str, settings: Settings, folder: Optional[Path] = None):
        self.command = command
        self.started = time.time()
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.folder = Path(folder or Path(settings.paths.work) / "runs") / "{}_{}".format(stamp, command)
        self.folder.mkdir(parents=True, exist_ok=True)
        settings.save(self.folder / "settings.json")
        self.summary: Dict = {"command": command, "argv": sys.argv[1:],
                              "started": time.strftime("%Y-%m-%dT%H:%M:%S"), "settings": describe(settings)}

    def finish(self, code: int) -> int:
        self.summary.update(exit_code=code, seconds=round(time.time() - self.started, 1),
                            finished=time.strftime("%Y-%m-%dT%H:%M:%S"))
        write_json(self.summary, self.folder / "summary.json")
        (logger.info if code == EXIT_OK else logger.warning)(
            "%s finished, exit code %d, %.1fs - run folder %s", self.command, code, self.summary["seconds"],
            self.folder)
        return code


class Components:
    """The library objects a command needs, built once and in dependency order."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._panel = self._engineer = self._store = None

    @property
    def panel(self):
        if self._panel is None:
            from .data.panel import HistoricalPanel
            self._panel = HistoricalPanel(self.settings)
        return self._panel

    @property
    def engineer(self):
        if self._engineer is None:
            from .features.engineer import FeatureEngineer
            self._engineer = FeatureEngineer(self.settings)
        return self._engineer

    @property
    def store(self):
        if self._store is None:
            from .features.store import FeatureStore
            self._store = FeatureStore(self.settings, self.panel, self.engineer)
        return self._store

    def days(self) -> List[pd.Timestamp]:
        days = self.panel.days()
        if not days:
            raise ConfigError("the window {}..{} has no days".format(self.settings.window.start,
                                                                     self.settings.window.end))
        return days

    def forecaster(self, version: Optional[str] = None, required: bool = True):
        from .models.turnover import TurnoverForecaster
        try:
            return TurnoverForecaster.load(self.settings, version, engineer=self.engineer, store=self.store)
        except AlgoEError as exc:
            if required:
                raise
            logger.warning("no usable turnover model (%s)", exc)
            return None

    def calibrator(self, version: Optional[str] = None, required: bool = True):
        from .models.probability import ProbabilityCalibrator
        try:
            return ProbabilityCalibrator.load(self.settings, version, engineer=self.engineer, store=self.store)
        except AlgoEError as exc:
            if required:
                raise
            logger.warning("no usable probability model (%s)", exc)
            return None


def _utf8_console() -> None:
    """A cp1252 / cp950 console must not turn a log line into a crash."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass


def _settings_from(args) -> Settings:
    overrides = list(args.overrides or [])
    if args.data_dir:
        overrides.append("paths.data_dir={}".format(json.dumps(str(args.data_dir))))
    if args.work_dir:
        overrides.append("paths.work_dir={}".format(json.dumps(str(args.work_dir))))
    if getattr(args, "start", None):
        overrides.append('window.start="{}"'.format(pd.Timestamp(args.start).date()))
    if getattr(args, "end", None):
        overrides.append('window.end="{}"'.format(pd.Timestamp(args.end).date()))
    if getattr(args, "workers", None) is not None:
        overrides.append("panel.workers={}".format(int(args.workers)))
    s = Settings.load(args.settings, overrides)
    if args.log_level:
        s.log_level = args.log_level
    return s


def _table(frame: pd.DataFrame, cols: List[str]) -> str:
    cols = [c for c in cols if c in frame.columns]
    out = frame[cols].copy()
    for c in cols:
        if pd.api.types.is_float_dtype(out[c]):
            out[c] = out[c].map(lambda v: "" if pd.isna(v) else ("{:.4g}".format(v) if abs(v) >= 1e-3 or v == 0
                                                                 else "{:.2e}".format(v)))
    return out.to_string(index=False)


# ================================================================ commands
def cmd_selftest(args, s: Settings, run: Run) -> int:
    from .selftest import run_selftest
    ck, _ = run_selftest(args.out, days=args.days, matches_per_day=args.matches, seed=args.seed,
                         fresh=args.fresh)
    text = ck.table()
    print(text, flush=True)
    (run.folder / "selftest.txt").write_text(text, encoding="utf-8")
    run.summary["checks"] = ck.rows
    return EXIT_FAIL if ck.failed else EXIT_OK


def cmd_check_data(args, s: Settings, run: Run) -> int:
    from src.backtest.parquet.probe import probe, render_text
    logger.info("check-data 1/4: tables, columns and time coverage (parquet metadata)")
    rep = probe(s.legacy_config())
    logger.info("check-data 2/4: pool codes and leagues in %s..%s", s.window.start, s.window.end)
    audit = _static_audit(s)
    logger.info("check-data 3/4: rows by month over every file")
    coverage = _coverage(s)
    audit["coverage"] = coverage["months"]
    logger.info("check-data 4/4: every Match_Investments day against the days before it")
    days = _investment_days(s)
    audit["investment_days"] = days["days"]
    audit["checks"] = coverage["checks"] + _window_end_check(rep, s) + days["checks"] + audit["checks"]
    text = render_text(rep) + "\n\n" + _render_coverage(coverage) + "\n\n" + _render_days(days) + "\n\n" + \
        _render_audit(audit)
    print(text, flush=True)
    (run.folder / "check_data.txt").write_text(text, encoding="utf-8")
    write_json({**rep, "audit": audit}, run.folder / "check_data.json")
    checks = rep["checks"] + audit["checks"]
    fails = [c for c in checks if c["level"] == "FAIL"]
    run.summary.update(fail=len(fails), warn=sum(c["level"] == "WARN" for c in checks),
                       report=str(run.folder / "check_data.txt"))
    return EXIT_FAIL if fails else EXIT_OK


# matches are counted from their kick-off times, not the file's metadata (one file may span years)
CORE_TABLES = ("odds", "investments", "pools", "match_count", "params")
# Small tables whose row groups straddle months (a pool starts selling days before its kick-off): read
# the time column itself instead of trusting each row group's earliest time.
EXACT_TABLES = ("pools",)


def _window_end_check(rep: dict, s: Settings) -> List[dict]:
    """A day needs its prices, its money and its TG / SUP: the usable data ends where the first of
    odds, investments and params ends (that table's last day is partial, so the day before)."""
    ends = {n: pd.Timestamp((rep["tables"].get(n) or {}).get("max_time"))
            for n in ("odds", "investments", "params") if (rep["tables"].get(n) or {}).get("max_time")}
    if not ends:
        return []
    table, last = min(ends.items(), key=lambda kv: kv[1])
    full = (last.normalize() - pd.Timedelta(days=1)).date()
    seen = ", ".join("{} {:%Y-%m-%d %H:%M}".format(n, t) for n, t in sorted(ends.items(), key=lambda kv: kv[1]))
    if pd.Timestamp(s.window.end).date() > full:
        return [{"level": "WARN", "check": "window end",
                 "detail": "last rows: {}. {} ends first, so days after {} are incomplete (a day needs prices, "
                           "money and TG / SUP): use --end {} or earlier".format(seen, table, full, full)}]
    return [{"level": "PASS", "check": "window end", "detail": "last rows: {}; the window ends {}".format(
        seen, s.window.end)}]


def _rows_by_month(path: Path, raw_time: Optional[str], exact: bool = False) -> Optional[Dict[str, int]]:
    """Rows per month from the parquet footer alone: each row group counted in the month of its earliest
    time. Nothing is read from the data pages, so it costs the same on a file server for any table size.
    ``exact`` reads the time column and counts every row in its own month (small tables only)."""
    import pyarrow.parquet as pq
    md = pq.ParquetFile(path).metadata
    j = next((i for i, n in enumerate(md.schema.names) if n == raw_time), None) if raw_time else None
    if j is None:
        return None
    if exact:
        t = pd.to_datetime(pq.read_table(path, columns=[raw_time]).column(0).to_pandas(), errors="coerce").dropna()
        return {str(m): int(n) for m, n in t.dt.to_period("M").astype(str).value_counts().items()}
    out: Dict[str, int] = {}
    for rg in range(md.num_row_groups):
        group = md.row_group(rg)
        st = group.column(j).statistics
        if st is None or not st.has_min_max:
            return None
        m = pd.Timestamp(st.min).strftime("%Y-%m")
        out[m] = out.get(m, 0) + group.num_rows
    return out


def _coverage(s: Settings) -> dict:
    """Rows per calendar month of every Raw_Data table over ALL files (not just the window), from parquet
    metadata only, plus matches and match days per month, so how far back the data is complete can be
    read off one table."""
    from src.backtest.parquet.config import SUBDIRS, TIME_COL
    from src.backtest.parquet.loader import _resolve, _schema_names, files_for, load_window
    months: Dict[str, Dict[str, int]] = {}
    unread = []
    for name in SUBDIRS:
        paths = files_for(Path(s.paths.data_dir), name)
        if not paths:
            continue
        logger.info("coverage: %s, %d file(s), from parquet metadata", name, len(paths))
        raw_time = next((r for r, c in _resolve(name, _schema_names(paths[0])).items() if c == TIME_COL[name]), None)
        for p in paths:
            try:
                per_month = _rows_by_month(p, raw_time, exact=name in EXACT_TABLES)
            except Exception as exc:                                    # noqa: BLE001
                per_month = None
                logger.warning("coverage: %s unreadable (%s)", p.name, exc)
            if per_month is None:
                unread.append("{}/{}".format(name, p.name))
                continue
            for m, n in per_month.items():
                months.setdefault(m, {})[name] = months.get(m, {}).get(name, 0) + n
    try:
        ko = pd.to_datetime(load_window(Path(s.paths.data_dir), "matches")["ko_time"], errors="coerce").dropna()
        for m, g in ko.groupby(ko.dt.to_period("M").astype(str)):
            months.setdefault(m, {}).update(match_count=int(len(g)), match_days=int(g.dt.normalize().nunique()))
    except Exception as exc:                                            # noqa: BLE001
        logger.warning("coverage: match days not counted (%s)", exc)
    ordered = sorted(months)
    complete = [m for m in ordered if all(months[m].get(t, 0) > 0 for t in CORE_TABLES)]
    checks: List[dict] = []
    if complete:
        # the first month from which every later month has every core table
        start = next((m for m in complete if all(x in complete for x in ordered[ordered.index(m):])), None)
        gaps = [m for m in ordered[ordered.index(complete[0]):] if m not in complete]
        if start:
            checks.append({"level": "PASS", "check": "data complete from",
                           "detail": "{} to {}: odds, investments, pools, matches and params in every month"
                           .format(start, ordered[-1])})
        if gaps:
            checks.append({"level": "WARN", "check": "months missing a core table",
                           "detail": ", ".join("{} (no {})".format(m, ", ".join(
                               {"match_count": "matches"}.get(t, t) for t in CORE_TABLES if not months[m].get(t)))
                                               for m in gaps)})
        early = [m for m in ordered if m < complete[0] and months[m].get("odds")]
        if early:
            checks.append({"level": "WARN", "check": "odds before the parameters",
                           "detail": "{}..{} have odds but not every core table (TG / SUP from HKJC_Parameters "
                                     "first appear in {}): train from {} or later".format(
                                         early[0], early[-1], complete[0], complete[0])})
    else:
        checks.append({"level": "FAIL", "check": "data complete", "detail": "no month has every core table"})
    if unread:
        checks.append({"level": "WARN", "check": "files without time statistics",
                       "detail": "{} file(s) not counted by month: {}".format(len(unread), ", ".join(unread[:8]))})
    return {"months": {m: months[m] for m in ordered}, "checks": checks}


def _investment_days(s: Settings) -> dict:
    """Every Match_Investments day on disk judged (src.backtest.parquet.quality) and the verdicts saved, so
    panels, fits and scores leave the suspect ones out."""
    from src.backtest.parquet.quality import check_days
    try:
        recs = check_days(s.paths.data_dir)
    except OSError as exc:
        return {"days": [], "checks": [{"level": "WARN", "check": "investment days",
                                        "detail": "not checked: {}".format(exc)}]}
    if not recs:
        return {"days": [], "checks": [{"level": "WARN", "check": "investment days",
                                        "detail": "no Match_Investments day file"}]}
    bad = [r for r in recs if r["verdict"] == "suspect"]
    if bad:
        detail = "{} day(s) left out of panels, fits and scores until algoe-update-data.bat --days FROM:TO " \
                 "extracts them again: {}".format(len(bad), "; ".join(
                     "{} ({})".format(r["day"], ", ".join(r["reasons"])) for r in bad[:10]))
        return {"days": recs, "checks": [{"level": "WARN", "check": "suspect investment days", "detail": detail}]}
    return {"days": recs, "checks": [{"level": "PASS", "check": "investment days", "detail": "{} day(s), none "
                                      "suspect ({} provisional)".format(
                                          len(recs), sum(r["verdict"] == "provisional" for r in recs))}]}


def _render_days(days: dict) -> str:
    recs = days["days"]
    lines = ["Match_Investments days: money, rows and pools against the 28 days before of the same kind",
             "  month       ok  provisional  suspect"]
    months: Dict[str, Dict[str, int]] = {}
    for r in recs:
        c = months.setdefault(r["day"][:7], {"ok": 0, "provisional": 0, "suspect": 0})
        c[r["verdict"]] = c.get(r["verdict"], 0) + 1
    for m, c in sorted(months.items()):
        lines.append("  {}   {:>4}  {:>11}  {:>7}".format(m, c["ok"], c["provisional"], c["suspect"]))
    odd = [r for r in recs if r["verdict"] != "ok"]
    if odd:
        lines.append("  day          verdict            money       rows    pools  why")
        for r in odd:
            pools = "{}/{}".format(r["pools"], r["pools_expected"]) if r.get("pools_expected") else str(r["pools"])
            lines.append("  {}   {:<11} {:>13} {:>10} {:>8}  {}".format(
                r["day"], r["verdict"], "{:,.0f}".format(r["money"]), "{:,}".format(r["rows"]), pools,
                "; ".join(r["reasons"]) or "-"))
    return "\n".join(lines)


def _render_coverage(cov: dict) -> str:
    def k(n):
        if not n:
            return "-"
        return "{:.1f}M".format(n / 1e6) if n >= 1e6 else ("{:.0f}K".format(n / 1e3) if n >= 1e3 else str(n))
    cols = ["match_count", "match_days", "odds", "investments", "params", "events", "market", "pools"]
    heads = {"match_count": "matches", "match_days": "match days"}
    counts = ("match_count", "match_days")
    lines = ["coverage by month (rows in every file, not just the window)", "-" * 112,
             "{:<8}".format("month") + "".join("{:>13}".format(heads.get(c, c)) for c in cols)]
    for m, row in cov["months"].items():
        lines.append("{:<8}".format(m) + "".join(
            "{:>13}".format((row.get(c, 0) or "-") if c in counts else k(row.get(c, 0))) for c in cols))
    for c in cov["checks"]:
        lines.append("[{:<4}] {}\n        {}".format(c["level"], c["check"], c["detail"]))
    return "\n".join(lines)


def _static_audit(s: Settings) -> dict:
    """Pool codes and leagues in the window, and how the library will treat each of them."""
    from src.backtest.parquet.loader import load_static
    from .core.taxonomy import default_taxonomy
    start, end = pd.Timestamp(s.window.start), pd.Timestamp(s.window.end) + pd.Timedelta(days=1)
    checks: List[dict] = []
    try:
        pools, matches = load_static(Path(s.paths.data_dir), start, end)
    except Exception as exc:                                            # noqa: BLE001
        return {"pools": [], "leagues": [], "checks": [{"level": "FAIL", "check": "static tables",
                                                        "detail": str(exc)}]}
    from .core.taxonomy import resolve_pools
    tax = default_taxonomy(str(s.paths.pools_file))
    pool_rows = []
    if not pools.empty and "pool_name" in pools.columns:
        names = pools["pool_name"].astype("string").fillna("UNKNOWN").str.upper()
        in_panel = set(resolve_pools(s.panel.pools, names.unique(), tax))
        for code, n in names.value_counts().items():
            spec = tax.resolve(code)
            pool_rows.append({"pool": code, "pools": int(n), "family": spec.family, "segment": spec.segment,
                              "market": spec.market, "priceable": spec.priceable,
                              "known": code not in tax.inferred_codes(), "in_panel": code in in_panel})
        inferred = sorted(tax.inferred_codes())
        if inferred:
            placed = [c for c in inferred if c in in_panel]
            checks.append({"level": "WARN" if placed else "PASS", "check": "pool codes placed by rule",
                           "detail": "{} - {}. Confirm or correct them in {}".format(
                               inferred, "in the panel: {}".format(placed) if placed else
                               "none of them is in the panel (panel.pools {})".format(s.panel.pools),
                               s.paths.pools_file)})
        from .core.taxonomy import ASIAN
        skipped = [r["pool"] for r in pool_rows if not r["in_panel"] and r["market"] in ASIAN]
        if skipped:
            checks.append({"level": "WARN", "check": "line markets left out of the panel",
                           "detail": "{} are not selected by panel.pools {}".format(skipped, s.panel.pools)})
        checks.append({"level": "PASS", "check": "panel pools",
                       "detail": "{} of {} pool codes: {}".format(len(in_panel), names.nunique(),
                                                                 ", ".join(sorted(in_panel)))})
    else:
        checks.append({"level": "FAIL", "check": "pools in window", "detail": "Pool_Details has no pool_name rows"})
    league_rows = []
    if not matches.empty:
        ko = pd.to_datetime(matches.get("ko_time"), errors="coerce")
        m = matches[(ko >= start) & (ko < end)] if ko.notna().any() else matches
        lg = m["league_code"].astype("string").fillna("unknown") if "league_code" in m.columns \
            else pd.Series("unknown", index=m.index)
        for code, n in lg.value_counts().items():
            league_rows.append({"league": code, "matches": int(n)})
        share_unknown = float((lg == "unknown").mean()) if len(lg) else 0.0
        if share_unknown > 0.05:
            checks.append({"level": "WARN", "check": "league code missing",
                           "detail": "{:.1%} of matches have no league code; they encode at the global level"
                           .format(share_unknown)})
        if ko.isna().mean() > 0.01:
            checks.append({"level": "WARN", "check": "kick-off time missing",
                           "detail": "{:.1%} of matches have no ko_time; their pre-match window is unknown"
                           .format(float(ko.isna().mean()))})
        checks.append({"level": "PASS", "check": "leagues in window",
                       "detail": "{} league(s), {} match(es)".format(len(league_rows), len(m))})
    else:
        checks.append({"level": "FAIL", "check": "matches in window", "detail": "Match_Information is empty"})
    return {"pools": pool_rows, "leagues": league_rows, "checks": checks}


def _render_audit(audit: dict) -> str:
    lines = ["pool codes (how the taxonomy places each one)", "-" * 78]
    if audit["pools"]:
        lines.append(pd.DataFrame(audit["pools"]).to_string(index=False))
    lines += ["", "leagues", "-" * 78]
    if audit["leagues"]:
        lines.append(pd.DataFrame(audit["leagues"]).head(40).to_string(index=False))
    lines += ["", "audit checks", "-" * 78]
    for c in audit["checks"]:
        lines.append("[{:<4}] {}\n        {}".format(c["level"], c["check"], c["detail"]))
    return "\n".join(lines)


def cmd_build_panel(args, s: Settings, run: Run) -> int:
    c = Components(s)
    days = c.days()
    res = c.panel.ensure(days)
    run.summary.update(days=len(days), built=res.get("built", 0), rows=res.get("rows"))
    print("panel: {} day(s) in the window, {} built now, cache {}".format(len(days), res.get("built", 0),
                                                                        c.panel.cache.root), flush=True)
    return EXIT_OK


def cmd_build_features(args, s: Settings, run: Run) -> int:
    c = Components(s)
    days = c.days()
    c.panel.ensure(days)
    rows = c.store.build(days, workers=s.panel.workers)
    frame = pd.DataFrame(rows)
    frame.to_csv(run.folder / "features.csv", index=False)
    print(frame.to_string(index=False), flush=True)
    empty = frame.loc[frame["selection_rows"] == 0, "day"].tolist()
    if empty:
        logger.warning("no feature rows for %s (no data, or every row outside the window)", empty)
    run.summary.update(days=len(rows), empty_days=empty, store=str(c.store.root))
    return EXIT_OK


def cmd_train_turnover(args, s: Settings, run: Run) -> int:
    from .models.turnover import TurnoverForecaster
    c = Components(s)
    days = c.days()
    c.panel.ensure(days)
    tf = TurnoverForecaster(s, c.engineer, c.store)
    meta = tf.train_all(days)
    lb = pd.DataFrame(meta["leaderboard"])
    lb.to_csv(run.folder / "leaderboard.csv", index=False)
    print(_table(lb, ["pipeline", "blend", "champion", "val_deviance", "test_deviance", "test_wape",
                      "test_match_wape", "test_bias", "test_top1_bias", "dm_stat_vs_last5", "days_better",
                      "days_worse"]), flush=True)
    if meta.get("skipped"):
        print("skipped:", meta["skipped"])
    if args.series:
        rep = tf.write_backtest_series(days, name=args.series_name)
        write_json(rep, run.folder / "series.json")
    if args.serving_refit:
        tf.refit_for_serving(days)
    version = tf.save(promote=not args.no_promote)
    champion = tf.model_store.champion()
    run.summary.update(version=version, pipeline=tf.champion, promoted=champion == version, champion=champion,
                       split=meta["split"], skipped=meta.get("skipped"), serving_fit=meta.get("serving_fit"))
    print("saved {} ({}); champion is {}".format(version, tf.champion, champion), flush=True)
    return EXIT_OK


def cmd_train_probability(args, s: Settings, run: Run) -> int:
    from .models.probability import ProbabilityCalibrator
    c = Components(s)
    days = c.days()
    c.panel.ensure(days)
    pc = ProbabilityCalibrator(s, c.engineer, c.store)
    pc.train_all(days)
    lb = pd.DataFrame(pc.leaderboard)
    lb.to_csv(run.folder / "leaderboard.csv", index=False)
    print(_table(lb, ["method", "champion", "val_log_loss", "test_log_loss", "test_brier", "test_ece",
                      "test_slope", "test_expected_margin", "test_realised_margin"]), flush=True)
    if args.serving_refit:
        pc.refit_for_serving(days)
    version = pc.save(promote=not args.no_promote)
    champion = pc.model_store.champion()
    run.summary.update(version=version, method=pc.champion, promoted=champion == version, champion=champion)
    print("saved {} ({}); champion is {}".format(version, pc.champion, champion), flush=True)
    return EXIT_OK


MODEL_FREE_SECTIONS = frozenset({"replication"})


def _backtest_needs_models(only) -> bool:
    """Every backtest section scores a model except the pricer replication (HKJC's theta vs its own board)."""
    return not only or bool(set(only) - MODEL_FREE_SECTIONS)


def _day_range(text: str, latest: Optional[pd.Timestamp] = None) -> Tuple[pd.Timestamp, pd.Timestamp]:
    """--days FROM:TO (or one day) as two dates: FROM not after TO, nor after ``latest``."""
    lo, _, hi = str(text).partition(":")
    try:
        a, b = pd.Timestamp(lo).normalize(), pd.Timestamp(hi or lo).normalize()
    except ValueError:
        a = b = pd.NaT
    if pd.isna(a) or pd.isna(b):
        raise ConfigError("--days takes FROM:TO dates, e.g. 2026-09-27:2026-09-28; got {}".format(text))
    if b < a:
        raise ConfigError("--days {}: FROM is after TO".format(text))
    if latest is not None and a > latest:
        raise ConfigError("--days {}: no day on or before {} in it".format(text, latest.date()))
    return a, b


def cmd_backtest(args, s: Settings, run: Run) -> int:
    from .backtest.backtester import Backtester
    c = Components(s)
    only = [x.strip() for x in (args.only or "").split(",") if x.strip()] or None
    if only and set(only) - set(Backtester.SECTIONS):
        raise AlgoEError("--only takes {}; got {}".format(", ".join(Backtester.SECTIONS), args.only))
    # --start / --end only set the window the models were trained on; the days scored are the
    # models' own held-out test days unless --days names others explicitly
    days = None
    if args.days:
        days = list(pd.date_range(*_day_range(args.days)))
    tf = pc = None
    if _backtest_needs_models(only):
        from .evaluation.walkforward import first_unseen
        tf = c.forecaster(args.turnover_version, required=False)
        pc = c.calibrator(args.probability_version, required=False)
        if tf is None and pc is None:
            raise AlgoEError("nothing to backtest: train a turnover or probability model first")
        for m in (tf, pc):
            if m is not None and (m.metadata or {}).get("serving_fit"):
                first = first_unseen([m])
                if days is None or first is None or min(days) < first:
                    raise AlgoEError("{} {} was refitted for serving, so its test days are inside the fit: "
                                     "backtest days after its fit ({}) with --days FROM:TO, or the version "
                                     "train-* saved without --serving-refit".format(
                                         type(m).__name__, m.version,
                                         "from {}".format(first.date()) if first is not None else "not recorded"))
    elif not args.days:
        raise ConfigError("--only {} scores no model, so it has no test days of its own: pass --days FROM:TO"
                          .format(",".join(only)))
    bt = Backtester(s, c.store, tf, pc)
    out = Path(s.paths.reports) / "backtest_{}".format(time.strftime("%Y%m%d-%H%M%S"))
    rep = bt.run_all(out, days=days, optimizer_every=args.optimizer_every, feature_groups=not args.no_feature_groups,
                     sections=only)
    run.summary.update(report=str(out / "report.html"), turnover_model=getattr(tf, "version", None),
                       probability_model=getattr(pc, "version", None), seconds_inside=rep["meta"]["seconds"])
    t = rep.get("turnover") or {}
    for r in (t.get("leaderboard") or [])[:5]:
        print("turnover  {:<28} deviance {:>10}  WAPE {:>7}".format(
            r["pipeline"], _fmt(r["deviance"]), _pct(r["wape"])))
    op = rep.get("optimizer") or {}
    if op:
        print("optimizer (demand {}) lift {} on {} buckets - TG/SUP {}, weightings {} (churn {}); days better/worse "
              "{}/{}".format(op.get("demand"), _pct(op.get("lift_pct")), op.get("buckets"),
                             _pct(op.get("lift_stage1_pct")), _pct(op.get("lift_stage2_pct")),
                             _fmt((op.get("weightings") or {}).get("churn_mean")), op.get("days_better"),
                             op.get("days_worse")))
    print("report:", out / "report.html", flush=True)
    return EXIT_OK


def cmd_parity(args, s: Settings, run: Run) -> int:
    from .evaluation.parity import busiest_bucket, train_serve_parity
    c = Components(s)
    if c.forecaster(required=False) is None:
        days = c.days()[:7]
        c.panel.ensure(days)
        c.engineer.fit_encoders([c.store.get(d) for d in days])
    moments = [pd.Timestamp(a) for a in (args.at or [])]
    if not moments:
        last = c.days()[-1]
        c.panel.ensure([last])
        moments = [busiest_bucket(c.store.get(last))]
    c.panel.ensure(sorted({m.normalize() for m in moments}))
    reports, ok = [], True
    for at in moments:
        rep = train_serve_parity(s, c.store, c.engineer, at)
        reports.append(rep)
        ok &= rep["ok"]
        print("{} {}".format(rep["bucket"], "OK" if rep["ok"] else "DIFFERENT " + rep.get("note", "")))
        for level, r in rep["levels"].items():
            print("   {:<16} train {:>6} serve {:>6} matched {:>6}  only-train {:>4} only-serve {:>4}  {}".format(
                level, r["rows_train"], r["rows_serve"], r["matched"], r["only_train"], r["only_serve"],
                ", ".join("{} ({} rows)".format(d["feature"], d["rows"]) for d in r["diffs"][:6])))
    write_json(reports, run.folder / "parity.json")
    run.summary.update(ok=bool(ok), moments=[str(m) for m in moments])
    return EXIT_OK if ok else EXIT_FAIL


def cmd_kafka_check(args, s: Settings, run: Run) -> int:
    """The office's first Kafka step, on the TEST topics only: the brokers answer and the login works; with
    --send, one params message for --event-id and the engine's reply printed as read. Secrets are shown as
    set or not set, never their value."""
    from src.hkjc import kafka_messages as km
    from src.hkjc import kafka_transport as kt
    cfg = kt.kafka_config_from_env()
    print("Kafka settings (environment; deploy/kafka.example.cmd lists them):")
    for name, value in cfg.describe().items():
        print("  {:<32} {}".format(name, value))
    missing = cfg.missing(["test"])
    if missing:
        print("missing: {}".format(", ".join(missing)))
        return EXIT_FAIL
    same = cfg.overlap()
    if same:
        print("{} is both a test topic and a production topic: this check would write to production. Fix "
              "ALGOE_KAFKA_TEST_TOPIC_*.".format(", ".join(same)))
        return EXIT_FAIL
    mapping = km.load_mapping(work_dir=s.paths.work)
    print("mapping: {}".format(mapping.source))
    params_topic, prices_topic = cfg.topics("test")
    # its own consumer group: in the desk's, it would take partitions (and replies) from the running desk
    cfg.values["group"] = args.group or "{}-check".format(cfg.get("group") or "algoe-prices")
    print("consumer group: {}".format(cfg.values["group"]))
    t = kt.KafkaTransport(cfg, reply_topics=[prices_topic], commit=False)
    try:
        md = t.metadata(timeout=args.timeout)
    except kt.TransportError as exc:
        print(exc)
        return EXIT_FAIL
    except Exception as exc:                                            # noqa: BLE001
        print("brokers / login: FAILED - {}: {}".format(type(exc).__name__, exc))
        return EXIT_FAIL
    print("brokers / login: OK, {} broker(s), {} topic(s) visible".format(len(md.brokers), len(md.topics)))
    # clients reach each broker at the address it gives, not the one dialled: a broker giving localhost
    # answers the bootstrap from here and then takes every message to this box's own port
    local = {"localhost", "127.0.0.1", "0.0.0.0", "::1"}
    dialled = {h.strip().rsplit(":", 1)[0].lower() for h in (cfg.get("bootstrap") or "").split(",") if h.strip()}
    loopback = False
    for bid, b in sorted(md.brokers.items(), key=lambda kv: str(kv[0])):
        host, port = getattr(b, "host", None), getattr(b, "port", None)
        print("  broker {} at {}".format(bid, "{}:{}".format(host, port) if host is not None else b))
        if host is not None and str(host).lower() in local and not dialled <= local:
            loopback = True
            print("    WARNING: it gives its address as {0}:{1}, which from this box is this box. Its owner sets "
                  "advertised.listeners=PLAINTEXT://<its host name>:{1} in server.properties and restarts "
                  "it.".format(host, port))
    found = True
    for topic in (params_topic, prices_topic):
        here = topic in md.topics
        found &= here
        print("  {:<48} {}".format(topic, "found" if here else "NOT FOUND (or no permission to see it)"))
    run.summary.update(brokers=len(md.brokers), topics_found=found, broker_gives_localhost=loopback)
    if not args.send:
        print("connection checked. --send --event-id <id> sends one message to {} and waits for the reply."
              .format(params_topic))
        t.close()
        return EXIT_OK if found and not loopback else EXIT_ALERT
    if not found or loopback:
        print("not sending: {}".format(
            "the broker gives its address as localhost (above)" if loopback else
            "a test topic is not visible; a broker that makes topics on first use would create an empty one"))
        t.close()
        return EXIT_FAIL
    if not args.event_id:
        raise ConfigError("kafka-check --send needs --event-id <id>: a match the engine knows")
    if not t.wait_assigned(args.timeout):
        print("the reply consumer got no partition of {} within {:.0f}s".format(prices_topic, args.timeout))
        t.close()
        return EXIT_FAIL
    event = int(args.event_id)
    # the topic carries the engine's recalculations of every match: what is there before our message is not
    # its answer, but its EventTime says how new an answer has to be (the engine's clock against itself)
    before = None
    for r in t.drain_early() + t.poll(1.0):
        try:
            seen = km.parse_prices_message(r.value, mapping)
        except km.MessageError:
            continue
        if seen.event_id == event and seen.event_time is not None:
            before = seen.event_time if before is None else max(before, seen.event_time)
    if before is not None:
        print("this match's newest reply before our message was computed at {} (EventTime)".format(before))
    theta = {"goal_tg": args.goal_tg, "goal_sup": args.goal_sup, "corner_tg": args.corner_tg,
             "corner_sup": args.corner_sup}
    now = pd.Timestamp.now().floor("s")
    seq = max(int(now.strftime("%H%M%S")), 1)          # a probe, not the publisher's daily counter
    msg = km.build_snapshot_message(
        args.event_id, km.snapshot_msg_id(now, seq), now, now, 5, "inplay" if args.minute > 0 else "sweep",
        {"phase": args.game_state, "seconds": int(round(args.minute * 60.0))}, theta, args.draw_factor, [])
    text = km.encode(msg)
    print("sending to {}:\n  {}".format(params_topic, text))
    started, sent_at = time.time(), pd.Timestamp.now()
    slack = pd.Timedelta(seconds=float(s.publish.reply_order_slack_seconds))
    t.send(params_topic, args.event_id, text, tag=str(msg["msg_id"]))
    t.flush(args.timeout)
    for d in t.deliveries():
        print("delivery: {} ({:.2f}s){}".format("OK" if d.ok else "FAILED", d.seconds,
                                              "" if d.ok else " - {}".format(d.error)))
        if not d.ok:
            t.close()
            return EXIT_FAIL
    unreadable = 0
    while time.time() - started < args.wait:
        for r in t.poll(1.0):
            try:
                reply = km.parse_prices_message(r.value, mapping)
            except km.MessageError as exc:
                unreadable += 1
                if unreadable <= 3:
                    print("a message that cannot be read as a reply: {}\n  {}".format(exc, r.value[:300]))
                continue
            if reply.event_id != event:
                continue
            et = reply.event_time
            if et is not None and before is not None and et <= before:
                print("a reply computed at {}, no newer than this match's reply before we sent: not the answer"
                      .format(et))
                continue
            if et is not None and et < sent_at - slack:
                print("a reply computed {:.1f}s before we sent, by its clock against this box's: not taken as "
                      "the answer".format((sent_at - et).total_seconds()))
                continue
            f = reply.frame()
            print("reply after {:.2f}s from {}: EventId {}, GameState {}, clock {}s, EventTime {} ({})".format(
                time.time() - started, reply.server_app_id, reply.event_id, reply.game_state, reply.clock_seconds,
                et, "no EventTime" if et is None else "{:+.1f}s from our send, its clock against this box's".format(
                    (et - sent_at).total_seconds())))
            print("  computed after our message; that the engine used our numbers shows in test mode, where the "
                  "weights sent come back on each selection (RUNBOOK section 9)")
            for pool, g in f.groupby("pool_type", sort=False):
                first = g[g["line_id"] == g["line_id"].iloc[0]]
                print("  {:<6} {:>2} line(s) {:>3} selection(s) {:>3} offered | {}".format(
                    pool, g["line_id"].nunique(), len(g), int(g["offered"].sum()),
                    "  ".join("{} {:.3f}/{:.3f}".format(lab, tr, se) for lab, tr, se in
                              zip(first["label"], first["true_odds"], first["sell_odds"]))))
            run.summary.update(reply_seconds=round(time.time() - started, 3), pools=int(f["pool_id"].nunique()))
            t.close()
            return EXIT_OK
    print("no reply for EventId {} computed after our message within {:.0f}s on {}{}".format(
        args.event_id, args.wait, prices_topic,
        "; {} message(s) there could not be read as replies".format(unreadable) if unreadable else ""))
    t.close()
    return EXIT_ALERT


def cmd_fit_far_prematch(args, s: Settings, run: Run) -> int:
    """The far pre-match curve on Raw_Data; kept only when it beats last 5 minutes on the held-out days."""
    from src.backtest.parquet.raw_update import suspect_days
    from .models.far_prematch import FarCurve, fit_far_curve, read_history
    data_dir = Path(s.paths.data_dir)
    if not data_dir.exists():
        raise ConfigError("Raw_Data not found at {}: pass --data-dir or set ALGOE_DATA_DIR".format(data_dir))
    inv, ko = read_history(data_dir, days=args.days, end=args.end, skip=suspect_days(data_dir))
    if inv.empty:
        raise AlgoEError("no Match_Investments day files to fit on in {}".format(data_dir))
    curve = fit_far_curve(inv, ko, edge_minutes=float(s.panel.prematch_window_min),
                          bucket_minutes=float(s.panel.bucket_minutes), holdout_days=args.holdout_days)
    m = curve.metrics
    print("far pre-match curve on {} match(es), scored on {} held-out match(es), {} far bucket(s)".format(
        m.get("fit_matches"), m.get("test_matches"), m.get("buckets")), flush=True)
    print("  g(h): " + "  ".join("{:g}h {:.3f}".format(h, r) for h, r in zip(curve.hours, curve.ratio)), flush=True)
    print("  match WAPE {:.1%} against last 5 minutes {:.1%}; credibility k = {:g} tickets; {} league anchor(s)"
          .format(m.get("wape", float("nan")), m.get("wape_last5", float("nan")), curve.k, len(curve.anchors)),
          flush=True)
    path = FarCurve.default_path(s)
    run.summary.update(metrics=m, k=curve.k, anchors=len(curve.anchors), path=str(path))
    if not (m.get("wape", np.inf) <= m.get("wape_last5", -np.inf)) and not args.force:
        logger.warning("the fitted curve does not beat last 5 minutes on the held-out far buckets: not saved "
                       "(--force saves it anyway); the desk keeps %s", "the file already there" if path.exists()
                       else "the default curve")
        return EXIT_ALERT
    curve.save(path)
    print("saved", path, "- restart the desk to use it", flush=True)
    return EXIT_OK


def cmd_probe_live(args, s: Settings, run: Run) -> int:
    from .evaluation.live_probe import run_probe
    if not args.match:
        raise ConfigError("probe-live needs --match <event id> (the number in the desk's /match/<id> address)")
    s.live.source = args.source or "sql"
    if args.tickets and s.live.source != "sql":
        raise ConfigError("--tickets reads the bet tables on the SQL server: use it with --source sql")
    if args.intent and s.live.source != "sql":
        raise ConfigError("--intent picks a SQL replica: use it with --source sql")
    intents = None
    if args.intent == "both":
        from src.hkjc.sql_source import SqlSource
        intents = {name: SqlSource(intent={"bis2": name}) for name in ("readonly", "readwrite")}
        source = intents["readonly"]
    elif args.intent:
        from src.hkjc.sql_source import SqlSource
        source = SqlSource(intent={"bis2": args.intent})
    elif s.live.source == "replay":
        from .data.replay import ReplaySource
        if not args.at:
            raise ConfigError("--source replay needs --at \"YYYY-MM-DD HH:MM\"")
        source = ReplaySource(s)
    else:
        from src.hkjc.source import get_source
        source = get_source(s.live.source, **({"path": args.capture} if s.live.source == "capture" and args.capture
                                               else {}))
    as_of = pd.Timestamp(args.at) if args.at else pd.Timestamp.now()
    rep = run_probe(s, source, args.match, as_of=as_of, minutes=args.minutes, tickets=args.tickets,
                    as_db=args.as_db, cs_db=args.cs_db, intents=intents)
    print("\n".join(rep["text"]), flush=True)
    print("written to", rep["folder"], flush=True)
    status = {check: st for st, check, _ in rep["verdict"]}
    write_json({k: v for k, v in rep.items() if k != "text"}, run.folder / "probe.json")
    run.summary.update(match=int(args.match), source=s.live.source, folder=rep["folder"], verdict=status)
    if "FAIL" in status.values():
        return EXIT_FAIL
    return EXIT_ALERT if "WARN" in status.values() else EXIT_OK


def cmd_live(args, s: Settings, run: Run) -> int:
    from .monitoring.monitor import Monitor
    from .realtime.live_engine import LiveEngine
    if args.source:
        s.live.source = args.source
    c = Components(s)
    tf = c.forecaster(required=False)
    pc = c.calibrator(required=False)
    if tf is None:
        logger.warning("serving WITHOUT a turnover model: next 5 minutes = last 5 minutes (the W06 MVP)")
    if pc is None:
        logger.warning("serving WITHOUT a probability model: belief = 1 / HKJC true odds (the W06 MVP)")
    source, clock = _live_source(args, s)
    eng = LiveEngine(s, source, tf, pc, Monitor(s), clock=clock)
    for mid in args.focus or []:
        eng.focus_on(mid, ttl=10 ** 9)
    run.summary.update(source=s.live.source, turnover_model=getattr(tf, "version", None),
                       probability_model=getattr(pc, "version", None))
    if args.once:
        eng.run_sweep()
        for mid in args.focus or []:
            eng.run_focus(mid)
            write_json(eng.match_view(mid), run.folder / "match_{}.json".format(mid))
        board = eng.board()
        print(_board_text(board), flush=True)
        write_json(board, run.folder / "board.json")
        return EXIT_OK
    eng.start(poll_seconds=args.poll)
    deadline = time.time() + 60.0 * args.minutes if args.minutes else None
    shown = None
    try:
        while deadline is None or time.time() < deadline:
            time.sleep(1.0)
            bucket = (eng.last_sweep or {}).get("bucket")
            if bucket and bucket != shown:
                shown = bucket
                print(_board_text(eng.board()), flush=True)
    except KeyboardInterrupt:
        logger.info("stopping (Ctrl+C)")
    finally:
        eng.stop()
    write_json(eng.board(), run.folder / "board.json")
    return EXIT_OK


def _live_source(args, s: Settings):
    if s.live.source == "replay":
        from .data.replay import ReplaySource
        if not args.at:
            raise ConfigError("--source replay needs --at \"YYYY-MM-DD HH:MM\", the moment to replay from")
        t0, wall0, speed = pd.Timestamp(args.at), time.time(), float(args.speed)
        return ReplaySource(s), (lambda: t0 + pd.Timedelta(seconds=(time.time() - wall0) * speed))
    from src.hkjc.source import get_source
    kwargs = {"path": args.capture} if s.live.source == "capture" and args.capture else {}
    return get_source(s.live.source, **kwargs), None


def _board_text(board: dict) -> str:
    ls = board.get("last_sweep") or {}
    sec = (ls.get("seconds") or {}).get("total")
    lines = ["", "sweep {} | {} match(es), {} solved | E[GM] lift {} on {} expected | {}s | focus {}".format(
        ls.get("bucket", ls.get("as_of")), ls.get("matches", 0), ls.get("solved", 0), _fmt(ls.get("lift")),
        _fmt(ls.get("turnover")), sec, board.get("focused") or "-"),
        "{:>10} {:>6} {:>12} {:>9} {:>7} {:>7} {:>7}  {}".format(
            "match", "mode", "turnover", "lift", "dTG", "dSUP", "hot", "binding / triggers")]
    for r in board.get("matches", [])[:30]:
        tn, ts = r.get("theta_now") or {}, r.get("theta_star") or {}
        d = {k: ts.get(k, np.nan) - tn.get(k, np.nan) for k in ("goal_tg", "goal_sup")}
        lines.append("{:>10} {:>6} {:>12} {:>9} {:>+7.3f} {:>+7.3f} {:>7.2f}  {}".format(
            r["match_id"], r.get("mode", ""), _fmt(r.get("turnover")), _fmt(r.get("lift")),
            d["goal_tg"], d["goal_sup"], r.get("hot", 1.0),
            ", ".join((r.get("binding") or []) + (r.get("triggers") or []))[:60]))
    return "\n".join(lines)


def cmd_monitor(args, s: Settings, run: Run) -> int:
    from .models.turnover import RESPONSES
    from .monitoring.monitor import Monitor
    c = Components(s)
    tf = c.forecaster(required=True)
    mon = Monitor(s)
    days = c.days()[-args.days:] if args.days else c.days()
    c.panel.ensure(days)
    frames, sources = {}, {}
    for d in days:
        joined = None if args.offline else mon.join_realised(d, c.store)
        if joined is None:
            dd = c.store.get(d)
            if dd.empty:
                continue
            joined = tf.predict_selection_turnover(dd).rename(columns={"actual": "y", "last5": "tv1"})
            sources[str(d.date())] = "replayed"
        else:
            sources[str(d.date())] = "published"
        frames[d] = joined
    health = mon.health_from_frames(frames)
    # inputs of the responses the champion actually uses, pooled over the days, each feature once
    eng = c.engineer
    group_of = {sp.name: sp.group for sp in eng.match_specs + eng.pool_specs + eng.sel_specs}
    skip = {n for n, g in group_of.items() if g in set(s.monitor.drift_skip_groups)}
    refs = (tf.metadata or {}).get("feature_reference") or {}
    used = [r for r in RESPONSES if r in refs and any(a == r for _, a in tf.models)] or list(refs)
    drift = {}
    for response in used:
        if response not in RESPONSES:
            continue
        parts = [getattr(eng, RESPONSES[response].builder)(c.store.get(d)) for d in days]
        X = pd.concat([p.X for p in parts if len(p)], ignore_index=True) if any(len(p) for p in parts) else None
        if X is not None:
            drift[response] = mon.drift(refs[response], X, skip)
            skip |= set(refs[response])
    newest = c.store.get(days[-1])
    novelty = mon.novelty(newest, eng.encoders, eng.taxonomy)
    payload = {"generated": time.strftime("%Y-%m-%dT%H:%M:%S"), "turnover_model": tf.version,
               "days": sources, "health": health, "drift": drift, "novelty": novelty}
    mon.write_health(payload)
    write_json(payload, run.folder / "health.json")
    alerts = health["alerts"] + [a for d in drift.values() for a in d["alerts"]] + novelty["alerts"]
    print(pd.DataFrame(health["daily"]).to_string(index=False) if health["daily"] else "no scored days")
    for a in alerts:
        print("ALERT [{}] {}".format(a["kind"], a["message"]))
    print("{} alert(s); health written to {}".format(len(alerts), Path(s.paths.monitor) / "health.json"), flush=True)
    run.summary.update(alerts=len(alerts), days=sources)
    return EXIT_ALERT if alerts else EXIT_OK


def cmd_models(args, s: Settings, run: Run) -> int:
    from .registry.model_store import ModelStore
    kinds = [args.kind] if args.kind else ["turnover", "probability"]
    for kind in kinds:
        ms = ModelStore(s.paths.models, kind)
        if args.action == "promote":
            if not args.version:
                raise ConfigError("models promote needs --version")
            ms.promote(args.version, args.reason or "promoted by hand from the command line")
            print("{} champion is now {}".format(kind, args.version))
            continue
        if args.action == "history":
            path = ms.root / "history.jsonl"
            print("== {} promotions ==".format(kind))
            print(path.read_text(encoding="utf-8") if path.exists() else "(none)")
            continue
        champ = ms.champion()
        rows = ms.list()
        print("== {} ({} version(s), champion {}) ==".format(kind, len(rows), champ))
        for r in rows:
            meta = read_json(ms.root / r["version"] / "metadata.json") or {}
            sel = r.get("selection") or {}
            print("{} {:<48} saved {}  features v{}  {} {}{}".format(
                "*" if r["version"] == champ else " ", r["version"], r.get("saved_at"), meta.get("feature_version"),
                sel.get("metric"), _fmt(sel.get(sel.get("metric")) if sel.get("metric") else None),
                "  (refit for serving)" if meta.get("serving_fit") else ""))
    return EXIT_OK


def cmd_update_data(args, s: Settings, run: Run) -> int:
    """Raw_Data up to now with the notebook's queries, each Match_Investments day checked before it is
    written, the cached days it read again dropped, then those days built (and, with --report, the W10
    report refreshed through yesterday). --days extracts only those investment days."""
    from src.backtest.parquet import raw_update as U
    from src.backtest.parquet.cache import drop_days as drop_panel_list
    from src.backtest.parquet.cache import drop_days_from as drop_panel_days
    from .features.store import drop_days as drop_feature_list
    from .features.store import drop_days_from as drop_feature_days
    data_dir = Path(s.paths.data_dir)
    if not data_dir.exists():
        raise ConfigError("Raw_Data not found at {}: pass --data-dir or set ALGOE_DATA_DIR".format(data_dir))
    named = _day_range(args.days, latest=pd.Timestamp.now().normalize()) if args.days else None
    try:
        p = U.plan(data_dir, start=args.from_day, days=named)
    except ValueError as exc:
        raise ConfigError(str(exc))
    for line in p.describe():
        print(line, flush=True)
    run.summary.update(restart=str(p.restart.date()), files=len(p.jobs), foreign=p.foreign)
    if args.dry_run:
        return EXIT_OK
    try:
        p.check_foreign(allow=args.allow_foreign)
    except U.ForeignFiles as exc:
        raise ConfigError(str(exc))

    def progress(k, n, rec):
        note = "" if rec["ok"] else "  " + rec["error"]
        if rec.get("kept_old"):
            note += "  kept the file on disk (more money)"
        if rec.get("verdict") in ("suspect", "provisional"):
            note += "  " + rec["verdict"]
        print("[{:>3}/{}] {:<58} {:>10} {:>6.1f}s{}".format(
            k, n, rec["file"], "{:,} rows".format(rec["rows"]) if rec["ok"] else "FAILED", rec["seconds"], note),
            flush=True)
    yesterday = pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
    common = _common_argv(args)
    try:
        # one lock for the files, the caches, the rebuild and the report: a second run would drop the
        # days this one is building
        with U.Lock(data_dir, wait_seconds=60.0 * float(args.wait or 0)):
            U.write_status(data_dir, dict(U.read_status(data_dir) or {}, running=True, ok=False,
                                          started=str(pd.Timestamp.now())))
            status = U.run(p, U.SqlReader(), progress, write=False, force=args.force)
            written = sorted({pd.Timestamp(r["day"]) for r in status["files"] if r.get("day") and r["rows"]})
            caches = {"panel": 0, "features": 0, "kept": []}
            if status["files_written"]:
                # every day from the restart on, and each day extracted again on its own before it
                alone = written if p.named else [d for d in written if d < p.restart]
                panel = [drop_panel_list(s.paths.panel_cache, alone, report=True)]
                feats = [drop_feature_list(s.paths.features, alone, report=True)]
                if not p.named:
                    panel.append(drop_panel_days(s.paths.panel_cache, p.restart, report=True))
                    feats.append(drop_feature_days(s.paths.features, p.restart, report=True))
                caches = {"panel": sum(d["dropped"] for d in panel), "features": sum(d["dropped"] for d in feats),
                          "kept": [f for d in panel + feats for f in d["kept"]]}
            first = min([p.restart] + written) if written else p.restart
            last = min(max(written), yesterday) if p.named and written else yesterday
            built = True
            if status["files_written"] and not args.no_build and last >= first:
                window = ["--start", str(first.date()), "--end", str(last.date())]
                built = all(main([step] + window + common, _nested=True) != EXIT_FAIL
                            for step in ("build-panel", "build-features"))
            q = status.get("quality") or {}
            print("quality: {} ok, {} provisional, {} suspect{}{}".format(
                q.get("ok", 0), q.get("provisional", 0), q.get("suspect", 0),
                " ({}; left out of panels, fits and scores, extracted again next run)".format(
                    ", ".join(status["suspect"])) if status.get("suspect") else "",
                "; the file on disk kept, the new extract had less money: {}".format(", ".join(status["kept_old"]))
                if status.get("kept_old") else ""), flush=True)
            run.summary.update(quality=q, suspect=status.get("suspect"), kept_old=status.get("kept_old"))
            ok = status["ok"] and not caches["kept"] and built
            U.write_status(data_dir, dict(status, caches=caches, built=built, running=False, ok=ok,
                                          finished=str(pd.Timestamp.now())))
            which = "the days named" if p.named else "from {}{}".format(
                p.restart.date(), " and {} day(s) before it".format(sum(d < p.restart for d in written))
                if any(d < p.restart for d in written) else "")
            print("written {} file(s), {} failed; newest day {}; cached days dropped ({}): {} panel, {} features"
                  "{}".format(status["files_written"], status["files_failed"], status["newest_day"], which,
                              caches["panel"], caches["features"],
                              "; {} cached file(s) in use could not be deleted - run again".format(len(caches["kept"]))
                              if caches["kept"] else ""), flush=True)
            run.summary.update(written=status["files_written"], failed=status["files_failed"],
                               newest_day=status["newest_day"], caches=caches, built=built)
            code = EXIT_OK if ok else EXIT_FAIL
            if args.report:
                if not status["ok"]:
                    logger.warning("report not refreshed: %d file(s) failed, the data is part new and part old",
                                   status["files_failed"])
                    return EXIT_FAIL
                c = Components(s)
                start, end, why = _report_window([c.forecaster(required=False), c.calibrator(required=False)],
                                                 yesterday)
                if start is None:
                    logger.warning("report not refreshed: %s", why)
                    return code if code == EXIT_FAIL else EXIT_ALERT
                if main(["backtest", "--days", "{}:{}".format(start.date(), end.date())] + common,
                        _nested=True) == EXIT_FAIL:
                    return EXIT_FAIL
            return code
    except U.UpdateLocked as exc:
        logger.warning("%s", exc)
        return EXIT_ALERT


def _report_window(models, yesterday):
    """The days a refreshed report may score, to yesterday: after every day any champion saw (a serving
    refit's fit window, else its training and validation days) and from the first test day of a champion
    that has them. (None, None, why) when there are none."""
    from .evaluation.walkforward import first_unseen
    models = [m for m in models if m is not None]
    if not models:
        return None, None, "no champion to score yet (algoe-2-train.bat)"
    start = first_unseen(models)
    if start is None:
        if any((m.metadata or {}).get("serving_fit") for m in models):
            return None, None, ("a champion is a serving refit that does not record its fit window, so it may "
                                "have seen any day: backtest the honest version")
        return None, None, "the champions do not record the days they were fitted on"
    tests = [pd.Timestamp(d) for m in models if not (m.metadata or {}).get("serving_fit")
             for d in ((m.metadata or {}).get("split") or {}).get("test") or []]
    if tests:
        start = max(start, min(tests))
    end = pd.Timestamp(yesterday).normalize()
    if start > end:
        return None, None, "no day after the champions' fits yet"
    return start.normalize(), end, None


def cmd_bench_live(args, s: Settings, run: Run) -> int:
    """The live engine on a card with publishing off: the sweep, then --cycles fast-lane cycles back to back
    (on the source's own clock for the simulator and a replay, in real time on SQL). Prints p50 / p95 cycle
    seconds, the SQL read, behind, how old the data was when a cycle ended, and the reads (incremental or
    full)."""
    from .realtime.live_engine import LiveEngine
    if args.source:
        s.live.source = args.source
    s.publish.mode = "off"
    sql = s.live.source in ("sql", "hkjc", "live")
    at = pd.Timestamp(args.at) if args.at else pd.Timestamp.now().floor("s")
    eng = LiveEngine(s)
    try:
        sweep = eng.run_sweep(None if sql else at)
        print("sweep: {} match(es), {} with a book, {:.1f}s".format(
            sweep.get("listed", sweep.get("matches", 0)), sweep.get("matches", 0),
            (sweep.get("seconds") or {}).get("total", 0.0)), flush=True)
        for k in range(int(args.cycles)):
            when = None if sql else at + pd.Timedelta(seconds=(k + 1) * float(s.live.fast_seconds))
            c = eng.run_fast_cycle(when)
            print("cycle {:>2}: {} match(es), {} behind, {:.1f}s (read {:.1f}s)".format(
                k + 1, c.get("matches", 0), len(c.get("behind") or []), (c.get("seconds") or {}).get("total", 0.0),
                (c.get("seconds") or {}).get("fetch", 0.0)), flush=True)
        m = eng.metrics()
    finally:
        eng.stop()
    f = m["fast"]
    print("fast lane: {} cycle(s), p50 {}s, p95 {}s, read p50 {}s, most behind {}, data {}s old at p50 ({}s p95); "
          "reads {}".format(f["cycles"], f["p50_s"], f["p95_s"], f["read_p50_s"], f["behind_max"], f["age_p50_s"],
                            f["age_p95_s"], m["reads"].get("mode")), flush=True)
    run.summary.update(source=s.live.source, metrics=m, sweep_seconds=(sweep.get("seconds") or {}).get("total"))
    return EXIT_OK if f["p95_s"] is None or f["p95_s"] <= float(s.live.fast_seconds) else EXIT_ALERT


def cmd_score_days(args, s: Settings, run: Run) -> int:
    """Walk-forward: every day after the serving turnover champion's fit, not suspect and not scored yet, scored
    for it against last 5 minutes (reports/daily/<day>.json) - the nightly runs it before it refits."""
    from src.backtest.parquet.quality import read_quality
    from .evaluation import walkforward as W
    c = Components(s)
    tf = c.forecaster(required=False)
    if tf is None:
        logger.warning("score-days: no turnover champion to score yet (algoe-2-train.bat)")
        return EXIT_ALERT
    first = W.first_unseen([tf])
    if first is None:
        logger.warning("score-days: %s does not record the days it was fitted on: nothing scored", tf.version)
        return EXIT_ALERT
    end = pd.Timestamp(args.end).normalize() if args.end else pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
    start = max(first, end - pd.Timedelta(days=int(args.days) - 1))
    folder = W.daily_dir(s)
    quality = read_quality(s.paths.data_dir).get("days") or {}
    todo = W.to_score(folder, start, end, quality) if start <= end else []
    if todo:
        c.panel.ensure(todo)
    n = wins = 0
    for d in todo:
        doc = W.score_day(tf, c.store, d)
        if doc is None:
            logger.info("score-days: %s has no rows to score", d.date())
            continue
        doc.update(scored_at=str(pd.Timestamp.now().floor("s")), turnover_model=tf.version, pipeline=tf.champion,
                   fit_end=str(W.fit_end(tf).date()), verdict=(quality.get(doc["day"]) or {}).get("verdict"))
        W.write_json_atomic(doc, folder / "{}.json".format(doc["day"]))
        n += 1
        wins += bool(W.better(doc))
    again = _revisit_days(c, s, tf, folder, quality)
    print("score-days: {} day(s) scored for {} in {}..{}{}{}".format(
        n, tf.version, start.date(), end.date(),
        ", the model better than last 5 minutes on {}".format(wins) if n else "",
        "; settled since their score: {}".format(", ".join("{} {}".format(d, w) for d, w in sorted(again.items())))
        if again else ""), flush=True)
    run.summary.update(scored=n, better=wins, model=tf.version, window=[str(start.date()), str(end.date())],
                       revisited=again)
    return EXIT_OK


def _revisit_days(c: "Components", s: Settings, tf, folder: Path, quality: dict) -> Dict[str, str]:
    """Provisional days scored before whose verdict has settled (walkforward.revisit): marked, or scored again
    by the version that scored them, loaded on its own feature engineer (loading one into the shared engineer
    would swap the champion's encoders)."""
    import json
    from .evaluation import walkforward as W
    from .models.turnover import TurnoverForecaster
    done: Dict[str, str] = {}
    for day, what in W.revisit(folder, quality).items():
        path = folder / "{}.json".format(day)
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if what == "rescore":
            ver = doc.get("turnover_model")
            try:
                model = tf if ver == tf.version else TurnoverForecaster.load(s, ver, store=c.store)
            except AlgoEError as exc:
                logger.warning("score-days: %s changed after its score and %s cannot score it again (%s): it "
                               "stays marked", day, ver, exc)
                continue
            c.panel.ensure([pd.Timestamp(day)])
            new = W.score_day(model, c.store, pd.Timestamp(day))
            if new is None:
                continue
            # rounded up: never before the file it scored was written, or the day would read as changed again
            doc.update(new, rescored_at=str(pd.Timestamp.now().ceil("s")))
            doc["scored_at"] = doc["rescored_at"]
        doc["verdict"] = (quality.get(day) or {}).get("verdict")
        W.write_json_atomic(doc, path)
        done[day] = what
    return done


NIGHTLY_STOP_ON_FAIL = frozenset({"build-panel", "build-features"})


def _nightly_steps(args) -> List[List[str]]:
    """The new data first; a failed update leaves the data as it was and the rest still runs. The new days are
    scored for the champions that served them before the refit replaces them."""
    return [["update-data", "--no-build", "--unattended", "--wait", "120"], ["build-panel"], ["build-features"],
            ["score-days"], ["monitor", "--days", "7"],
            ["train-turnover"] + ([] if args.no_refit else ["--serving-refit"]),
            ["train-probability"] + ([] if args.no_refit else ["--serving-refit"])]


def cmd_nightly(args, s: Settings, run: Run) -> int:
    """Rolling refresh for Task Scheduler: each step is its own run folder and log. reports/daily/_nightly.json
    keeps the last run for the desk."""
    from .evaluation.walkforward import NIGHTLY, daily_dir, write_json_atomic
    end = pd.Timestamp(args.end) if args.end else pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
    start = end - pd.Timedelta(days=int(args.window_days) - 1)
    common = _common_argv(args) + ["--start", str(start.date()), "--end", str(end.date())]
    began = pd.Timestamp.now().floor("s")
    results = []
    worst = EXIT_OK
    for step in _nightly_steps(args):
        logger.info("nightly: %s (%s..%s)", step[0], start.date(), end.date())
        code = main(step + common, _nested=True)
        results.append({"step": step[0], "exit_code": code})
        if code == EXIT_FAIL:
            worst = EXIT_FAIL
            if step[0] in NIGHTLY_STOP_ON_FAIL:
                logger.error("nightly: %s failed; later steps need its output, stopping", step[0])
                break
        elif code == EXIT_ALERT and worst == EXIT_OK:
            worst = EXIT_ALERT
    run.summary.update(window=[str(start.date()), str(end.date())], steps=results)
    write_json_atomic({"started": str(began), "finished": str(pd.Timestamp.now().floor("s")), "exit_code": worst,
                       "window": [str(start.date()), str(end.date())], "steps": results},
                      daily_dir(s) / NIGHTLY)
    for r in results:
        print("{:<18} exit {}".format(r["step"], r["exit_code"]))
    return worst


def _common_argv(args) -> List[str]:
    out: List[str] = []
    if args.settings:
        out += ["--settings", args.settings]
    for o in args.overrides or []:
        out += ["--set", o]
    if args.data_dir:
        out += ["--data-dir", str(args.data_dir)]
    if args.work_dir:
        out += ["--work-dir", str(args.work_dir)]
    if args.log_level:
        out += ["--log-level", args.log_level]
    return out


def _fmt(v) -> str:
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return "n/a"
    return "{:,.0f}".format(v) if abs(v) >= 100 else "{:.4g}".format(v)


def _pct(v) -> str:
    return "n/a" if v is None or not np.isfinite(v) else "{:.1%}".format(v)


# ================================================================== parser
def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    g = common.add_argument_group("common")
    g.add_argument("--settings", help="JSON settings file (default: env ALGOE_SETTINGS)")
    g.add_argument("--set", dest="overrides", action="append", default=[], metavar="SECTION.KEY=VALUE",
                   help="override one setting; repeatable")
    g.add_argument("--data-dir", help="the Raw_Data folder")
    g.add_argument("--work-dir", help="where models, features, reports and logs go")
    g.add_argument("--start", help="first day of the window, YYYY-MM-DD")
    g.add_argument("--end", help="last day of the window, YYYY-MM-DD")
    g.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    g.add_argument("--workers", type=int, help="build-panel / build-features: months in parallel (panel.workers; "
                                               "0 = automatic). Each worker holds a month of raw data in memory")

    p = argparse.ArgumentParser(prog="python -m algoe", description=__doc__.split("\n\n")[1].strip(),
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", metavar="<command>")

    def add(name, func, help_text):
        sp = sub.add_parser(name, parents=[common], help=help_text, description=help_text)
        sp.set_defaults(func=func)
        return sp

    sp = add("selftest", cmd_selftest, "the whole chain on a generated world with known truth")
    sp.add_argument("--out", help="folder for the generated world (default backend/.selftest_data)")
    sp.add_argument("--days", type=int, default=10)
    sp.add_argument("--matches", type=int, default=5, help="matches per day")
    sp.add_argument("--seed", type=int, default=7)
    sp.add_argument("--fresh", action="store_true", help="regenerate the world")

    add("check-data", cmd_check_data, "what is in Raw_Data and how each pool code / league will be treated")
    add("build-panel", cmd_build_panel, "build the per-day panel cache for the window")
    add("build-features", cmd_build_features, "build the per-day feature cache for the window")

    sp = add("train-turnover", cmd_train_turnover, "fit, choose and save the turnover forecaster")
    sp.add_argument("--no-promote", action="store_true", help="save the version but leave the champion alone")
    sp.add_argument("--series", action="store_true",
                    help="also write the walk-forward series to Backtest_Data/Turnover for the workbench")
    sp.add_argument("--series-name", help="folder name under Backtest_Data/Turnover")
    sp.add_argument("--serving-refit", action="store_true",
                    help="after choosing honestly, refit the champion on the newest days for serving")

    sp = add("train-probability", cmd_train_probability, "fit, choose and save the probability calibrator")
    sp.add_argument("--no-promote", action="store_true")
    sp.add_argument("--serving-refit", action="store_true")

    sp = add("backtest", cmd_backtest, "every comparison on held-out days -> report.html")
    sp.add_argument("--turnover-version")
    sp.add_argument("--probability-version")
    sp.add_argument("--optimizer-every", type=int, default=6, help="optimise every Nth bucket (cost control)")
    sp.add_argument("--no-feature-groups", action="store_true", help="skip the feature-group ablation")
    sp.add_argument("--only", metavar="SECTIONS",
                    help="run only these, comma-separated: turnover, groups, trueprob, gm, replication, optimizer, "
                         "drift, events (= mix: proportions, events before / after and inside the bucket, the "
                         "fitted event shift), elasticity (e.g. --only optimizer after an optimiser change). "
                         "--only replication needs no model, only --days")
    sp.add_argument("--days", metavar="FROM:TO", help="score these days instead of the models' test days "
                                                     "(only honest if the models never trained on them)")

    sp = add("parity", cmd_parity, "training vs serving model inputs at one or more moments")
    sp.add_argument("--at", action="append", help="YYYY-MM-DD HH:MM; repeatable (default: busiest bucket)")

    sp = add("probe-live", cmd_probe_live, "one match's live money rows checked against what training read")
    sp.add_argument("--match", type=int, help="the event id (the number in the desk's /match/<id> address)")
    sp.add_argument("--minutes", type=float, default=60.0, help="how far back to read the money rows")
    sp.add_argument("--source", choices=["sql", "capture", "sim", "replay"], help="default sql")
    sp.add_argument("--at", help="the moment to read as of (default now; replay needs it)")
    sp.add_argument("--capture", help="capture: the captured snapshot folder")
    sp.add_argument("--tickets", action="store_true",
                    help="also sum the same minutes from the bet tables 1 Data Extraction.ipynb reads")
    sp.add_argument("--as-db", default="fbis1_fo_as_db", help="--tickets: the account bet database")
    sp.add_argument("--cs-db", default="fbis1_fo_cs_db", help="--tickets: the cash bet database")
    sp.add_argument("--intent", choices=["readonly", "readwrite", "both"],
                    help="sql: the replica the money is read from (default ALGOE_SQL_INTENT_BIS2, readonly); both "
                         "reads it on each and compares")

    sp = add("fit-far-prematch", cmd_fit_far_prematch, "the far pre-match curve on Raw_Data: money per bucket days "
                                                       "before kick-off, for the matches outside the model window")
    sp.add_argument("--days", type=int, default=42, help="the last N Match_Investments days (ending --end)")
    sp.add_argument("--holdout-days", type=int, default=7, help="the last N days of kick-offs score the fit")
    sp.add_argument("--force", action="store_true", help="save even when it does not beat last 5 minutes")

    sp = add("kafka-check", cmd_kafka_check, "Kafka on the TEST topics: brokers and login; --send one message and "
                                             "print the pricing engine's reply")
    sp.add_argument("--send", action="store_true", help="send one params message to the test topic")
    sp.add_argument("--event-id", type=int, help="--send: a match the pricing engine knows")
    sp.add_argument("--goal-tg", type=float, default=1.5)
    sp.add_argument("--goal-sup", type=float, default=0.13)
    sp.add_argument("--corner-tg", type=float, default=8.0)
    sp.add_argument("--corner-sup", type=float, default=0.3)
    sp.add_argument("--draw-factor", type=float, default=1.07, help="on the feed's scale (Goal90DrawFactor)")
    sp.add_argument("--game-state", default="Prematch", help="the feed's GameState text")
    sp.add_argument("--minute", type=float, default=0.0)
    sp.add_argument("--timeout", type=float, default=15.0, help="seconds for the brokers and the consumer group")
    sp.add_argument("--wait", type=float, default=30.0, help="seconds to wait for the reply")
    sp.add_argument("--group", help="the consumer group for the reply (default: ALGOE_KAFKA_GROUP + '-check')")

    sp = add("live", cmd_live, "the live engine")
    sp.add_argument("--source", choices=["sim", "capture", "sql", "replay"])
    sp.add_argument("--at", help="replay: the moment to start from")
    sp.add_argument("--speed", type=float, default=1.0, help="replay: clock speed-up")
    sp.add_argument("--capture", help="capture: the captured snapshot folder")
    sp.add_argument("--focus", type=int, action="append", help="match id to keep in focus; repeatable")
    sp.add_argument("--once", action="store_true", help="one sweep (and focus refresh), print, exit")
    sp.add_argument("--minutes", type=float, help="stop after this many minutes")
    sp.add_argument("--poll", type=float, default=1.0, help="scheduler tick, seconds")

    sp = add("bench-live", cmd_bench_live, "the live engine's fast lane on a card, publishing off: p50 / p95 cycle "
                                           "seconds, the SQL read, behind, data age (exit 2 when p95 > fast_seconds)")
    sp.add_argument("--source", choices=["sim", "sql", "replay"], help="the live source (default: live.source)")
    sp.add_argument("--cycles", type=int, default=10, help="fast-lane cycles after the sweep")
    sp.add_argument("--at", help="sim / replay: the moment the sweep reads (default now)")

    sp = add("score-days", cmd_score_days, "walk-forward: each new day after the serving champion's fit scored "
                                           "against last 5 minutes (reports/daily), before the nightly refits it")
    sp.add_argument("--days", type=int, default=14, help="look this many days back (ending --end) for days not "
                                                         "scored yet")

    sp = add("monitor", cmd_monitor, "forecast accuracy vs last 5, feature drift, novelty")
    sp.add_argument("--days", type=int, default=7, help="the last N days of the window")
    sp.add_argument("--offline", action="store_true",
                    help="score the champion on the days even where the engine published forecasts")

    sp = add("models", cmd_models, "list, promote or show the promotion history")
    sp.add_argument("action", choices=["list", "promote", "history"], nargs="?", default="list")
    sp.add_argument("--kind", choices=["turnover", "probability"])
    sp.add_argument("--version")
    sp.add_argument("--reason")

    sp = add("update-data", cmd_update_data, "Raw_Data up to now with the notebook's queries; the cached days "
                                               "it read again dropped and built")
    sp.add_argument("--from", dest="from_day", metavar="YYYY-MM-DD",
                    help="extract again from this day (default: the day before the newest day every table has)")
    sp.add_argument("--dry-run", action="store_true", help="print the plan and stop")
    sp.add_argument("--no-build", action="store_true", help="leave the dropped days to the next build")
    sp.add_argument("--report", action="store_true",
                    help="then refresh the W10 backtest report on the champions' unseen days through yesterday")
    sp.add_argument("--unattended", action="store_true",
                    help="Task Scheduler / start.bat: the .bat does not pause at the end")
    sp.add_argument("--wait", type=float, default=0.0, metavar="MINUTES",
                    help="wait this long for an update that is already running (the nightly waits 120)")
    sp.add_argument("--allow-foreign", action="store_true",
                    help="run although Raw_Data holds files that may overlap these (their rows are read twice)")
    sp.add_argument("--days", metavar="FROM:TO",
                    help="extract only these Match_Investments days again (e.g. 2026-09-27:2026-09-28)")
    sp.add_argument("--force", action="store_true",
                    help="replace a day file even when the new extract has under 95%% of its money")
    sp = add("nightly", cmd_nightly, "new data -> new days -> scored walk-forward -> monitor -> refit on the rolling "
                                     "window -> promote")
    sp.add_argument("--window-days", type=int, default=75, help="rolling window length ending --end")
    sp.add_argument("--no-refit", action="store_true", help="keep the honest fit instead of refitting for serving")
    return p


def main(argv: Optional[List[str]] = None, _nested: bool = False) -> int:
    _utf8_console()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return EXIT_FAIL
    try:
        if args.command == "selftest":
            from .selftest import selftest_settings
            root = Path(args.out) if args.out else Path(__file__).resolve().parents[1] / ".selftest_data"
            settings = selftest_settings(root, args.days)
            folder, log_dir = root / "runs", root / "logs"
        else:
            settings = _settings_from(args)
            folder, log_dir = None, settings.paths.logs
    except AlgoEError as exc:
        print("settings: {}".format(exc), file=sys.stderr)
        return EXIT_FAIL
    if not _nested:
        setup_logging(args.log_level or settings.log_level, str(log_dir), args.command)
    run = Run(args.command, settings, folder)
    logger.info("%s | %s", args.command, describe(settings))
    try:
        code = args.func(args, settings, run)
    except AlgoEError as exc:
        logger.error("%s failed: %s", args.command, exc)
        run.summary["error"] = str(exc)
        code = EXIT_FAIL
    except KeyboardInterrupt:
        logger.warning("%s interrupted", args.command)
        code = EXIT_FAIL
    except Exception as exc:                                            # noqa: BLE001
        logger.exception("%s failed", args.command)
        run.summary["error"] = "{}: {}".format(type(exc).__name__, exc)
        code = EXIT_FAIL
    return run.finish(code)


if __name__ == "__main__":
    sys.exit(main())
