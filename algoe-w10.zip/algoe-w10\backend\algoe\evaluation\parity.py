"""
Train / serve parity

A model is only as good in production as the match between the inputs it was
trained on and the inputs it is served. This check builds the SAME bucket
twice and compares every model input, row by row:

    training path   HistoricalPanel -> FeatureStore -> DayData (the whole day)
    serving path    ReplaySource cut at the bucket start -> LivePanelBuilder -> DayData

The replay source drops everything at or after the bucket start, so the
serving path cannot see anything inside the bucket being forecast. A feature
that differs between the two paths is therefore either a train/serve skew or
a leak in the training path, and the model must not ship until it is fixed.
(The first run of this found both: odds age measured at the end of the bucket,
and closed first-half pools kept alive in play.)

    train_serve_parity(settings, store, engineer, at)   -> report dict
    busiest_bucket(day_data)                            -> a demanding bucket to test

Run on synthetic data by the selftest, and on the office Raw_Data with
``python -m algoe parity --at "2026-09-10 21:30"``.

Change Log:
-----------
2026-10-01      Initialize
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import KEY, LivePanelBuilder

logger = get_logger(__name__)

# level -> (FeatureEngineer method, row key)
LEVELS = {
    "match_total": ("features_for_turnover_match_total", ["match_id", "bucket"]),
    "pool_share": ("features_for_turnover_pool_share", ["match_id", "pool_name", "bucket"]),
    "selection_share": ("features_for_turnover_selection_share", KEY + ["bucket"]),
    "selection": ("features_for_turnover_selection", KEY + ["bucket"]),
}


def busiest_bucket(day_data, inplay: bool = True) -> Optional[pd.Timestamp]:
    """The bucket with the most forecastable rows (in play when there are any)."""
    s = day_data.sel
    s = s[s["forecastable"]]
    if s.empty:
        return None
    if inplay and "inplay" in s.columns and (s["inplay"] > 0).any():
        s = s[s["inplay"] > 0]
    return pd.Timestamp(s.groupby("bucket").size().idxmax())


def train_serve_parity(settings, store, engineer, at, source=None, atol: float = 1e-5) -> dict:
    """Compare every model input of one bucket between the training and serving paths."""
    from ..data.replay import ReplaySource
    at = pd.Timestamp(at)
    T = at.floor("{}min".format(settings.panel.bucket_minutes))
    if at != T:
        logger.info("parity: %s is inside a bucket; testing its start %s", at, T)
    hist = store.get(T.normalize())
    snap = (source or ReplaySource(settings)).fetch(T)
    panel, extra = LivePanelBuilder(settings).build(snap, T)
    live = engineer.prepare_live(panel, extra)
    report = {"bucket": str(T), "levels": {}, "ok": True}
    if hist.empty or live.empty:
        report.update(ok=False, note="no rows: training path {} / serving path {}".format(
            0 if hist.empty else len(hist.sel), 0 if live.empty else len(live.sel)))
        logger.error("parity %s: %s", T, report["note"])
        return report
    for level, (method, key) in LEVELS.items():
        fn = getattr(engineer, method)
        report["levels"][level] = _compare(fn(hist), fn(live), key, T, atol)
    report["levels"]["probability"] = _compare(
        engineer.features_for_probability(hist, require_outcome=False),
        engineer.features_for_probability(live, require_outcome=False), KEY + ["bucket"], T, atol)
    report["ok"] = all(r["ok"] for r in report["levels"].values())
    for level, r in report["levels"].items():
        msg = "parity %s %-15s train %5d serve %5d matched %5d only-train %d only-serve %d, %d feature(s) differ"
        args = (T.strftime("%Y-%m-%d %H:%M"), level, r["rows_train"], r["rows_serve"], r["matched"],
                r["only_train"], r["only_serve"], len(r["diffs"]))
        (logger.info if r["ok"] else logger.error)(msg, *args)
        for d in r["diffs"][:10]:
            logger.error("    %-22s %d/%d rows differ, e.g. train %s serve %s", d["feature"], d["rows"], d["of"],
                         d.get("train"), d.get("serve"))
    return report


def _frame(fs, key, T) -> pd.DataFrame:
    k = fs.keys.reset_index(drop=True)
    at = (pd.to_datetime(k["bucket"]) == T).to_numpy() if len(k) else np.zeros(0, dtype=bool)
    out = pd.concat([k.loc[at, key].reset_index(drop=True), fs.X.loc[at].reset_index(drop=True)], axis=1)
    for c in key:
        if c == "bucket":
            out[c] = pd.to_datetime(out[c]).astype("datetime64[ns]")
        elif c == "pool_name":
            out[c] = out[c].astype(str)
        else:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype("int64")
    return out


def _compare(a, b, key, T, atol) -> dict:
    A, B = _frame(a, key, T), _frame(b, key, T)
    j = A.merge(B, on=key, how="outer", suffixes=("_t", "_s"), indicator=True)
    both = j[j["_merge"] == "both"]
    diffs = []
    for c in a.feature_names:
        if c + "_s" not in both.columns:
            diffs.append({"feature": c, "rows": int(len(both)), "of": int(len(both)), "note": "not built live"})
            continue
        x = both[c + "_t"].to_numpy(dtype="float64")
        y = both[c + "_s"].to_numpy(dtype="float64")
        bad = ~np.isclose(x, y, atol=atol, rtol=1e-6, equal_nan=True)
        if bad.any():
            diffs.append({"feature": c, "rows": int(bad.sum()), "of": int(len(both)),
                          "train": np.round(x[bad][:3], 5).tolist(), "serve": np.round(y[bad][:3], 5).tolist()})
    only_t = int((j["_merge"] == "left_only").sum())
    only_s = int((j["_merge"] == "right_only").sum())
    return {"rows_train": int(len(A)), "rows_serve": int(len(B)), "matched": int(len(both)),
            "only_train": only_t, "only_serve": only_s, "diffs": diffs,
            # nothing on the board in either path is agreement; a row on one side only never is
            "ok": bool(only_t == 0 and only_s == 0 and not diffs)}
