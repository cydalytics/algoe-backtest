"""
Live Routes (the W10 engine)

The Algo E live engine behind the desk: the trained turnover forecaster, the
calibrated belief and the theta optimizer, refreshed every bucket for the
whole card and every ~15 s for the matches a trader has open.

The desk (board and cockpit) reads these:

    GET    /api/live/desk                   the board: one row per match on the panel
    GET    /api/live/desk/{id}?open=1       one match in full; every call is a focus heartbeat,
                                            open=1 (the desk has just opened it) refreshes it now
    POST   /api/live/desk/{id}/price        what-if: the match's last book at another theta
    GET    /api/live/desk/{id}/curves       E[GM] along each theta dimension
    DELETE /api/live/focus/{id}             the desk left the match: stop refreshing it

and the engine's own:

    GET    /api/live/status           engine, source, models in use, last sweep and its timings
    GET    /api/live/board            every match: expected turnover, E[GM] lift, theta moves, triggers
    GET    /api/live/match/{id}       one match as the engine holds it; each call is also a focus heartbeat
    POST   /api/live/focus/{id}       keep a match in focus for ttl seconds and refresh it now
    POST   /api/live/start            run the background loop
    POST   /api/live/stop             pause it

The engine is built on first use (or at startup with ALGOE_LIVE=1) from the
settings the command line uses (ALGOE_SETTINGS / ALGOE_DATA_DIR /
ALGOE_WORK_DIR). The source follows ALGOE_SOURCE like the rest of the desk.
Without a trained champion it serves the W06 MVP (last 5 minutes, 1/true
odds) and the payloads say so.

Change Log:
-----------
2026-10-01      Initialize
2026-10-26      /api/live/desk*: the board and the cockpit on the engine (src/api/live_payload.py)
"""

import math
import os
import threading
from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

router = APIRouter()

_lock = threading.Lock()
_engine = None
_info: dict = {}


class WhatIfRequest(BaseModel):
    """A what-if on the live book: this theta (any subset of the eight dimensions), these pools."""

    theta: Dict[str, float] = Field(default_factory=dict)
    pools: Optional[List[str]] = None


def _plain(obj):
    """JSON a browser can parse: numpy / pandas scalars to Python, NaN and inf to null."""
    if isinstance(obj, dict):
        return {str(k): _plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_plain(v) for v in obj]
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        try:
            obj = obj.item()
        except (ValueError, AttributeError):
            pass
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, (int, str, bool)) or obj is None:
        return obj
    return str(obj)


def get_engine(start: bool = True):
    """The one engine for this process, built on first use."""
    global _engine
    with _lock:
        if _engine is None:
            from algoe.cli import Components
            from algoe.monitoring.monitor import Monitor
            from algoe.realtime.live_engine import LiveEngine
            from algoe.settings import Settings

            s = Settings.load()
            if os.environ.get("ALGOE_SOURCE"):
                s.live.source = os.environ["ALGOE_SOURCE"]
            if s.live.source == "replay":
                raise HTTPException(400, "the replay source needs a clock; use `python -m algoe live "
                                         "--source replay --at ...` instead of the API")
            c = Components(s)
            tf = c.forecaster(required=False)
            pc = c.calibrator(required=False)
            _engine = LiveEngine(s, None, tf, pc, Monitor(s))
            _info.update(
                source=s.live.source,
                turnover_model=getattr(tf, "version", None) or "none - last 5 minutes (W06 MVP)",
                turnover_pipeline=getattr(tf, "champion", None),
                probability_model=getattr(pc, "version", None) or "none - 1 / HKJC true odds (W06 MVP)",
                probability_method=getattr(pc, "champion", None),
                work=str(s.paths.work))
        eng = _engine
    if start and not eng.running:
        eng.start()
    return eng


# ------------------------------------------------------------------ the desk
@router.get("/live/desk")
def desk():
    from src.api import live_payload
    return _plain(live_payload.board(get_engine()))


@router.get("/live/desk/{match_id}")
def desk_match(match_id: int, open: bool = Query(False, description="the desk has just opened the match: "
                                                                    "refresh it now")):
    from src.api import live_payload
    eng = get_engine()
    if open:
        eng.request_focus(match_id, "opened on the desk")
    elif int(match_id) in eng.matches:
        eng.focus_on(match_id)
    out = live_payload.cockpit(eng, match_id)
    if out is None:
        raise HTTPException(404, "match {} is not on the live engine's board".format(match_id))
    return _plain(out)


@router.post("/live/desk/{match_id}/price")
def desk_price(match_id: int, request: WhatIfRequest):
    from src.api import live_payload
    from src.pricing import book as book_lib
    unknown = set(request.theta) - set(book_lib.DIMS)
    if unknown:
        raise HTTPException(422, "unknown theta dimensions: {}".format(", ".join(sorted(unknown))))
    out = live_payload.what_if(get_engine(), match_id, request.theta, request.pools)
    if out is None:
        raise HTTPException(404, "match {} has no book to price yet".format(match_id))
    return _plain(out)


@router.get("/live/desk/{match_id}/curves")
def desk_curves(match_id: int):
    from src.api import live_payload
    out = live_payload.curves(get_engine(), match_id)
    if out is None:
        raise HTTPException(404, "match {} has no book to price yet".format(match_id))
    return _plain(out)


# ---------------------------------------------------------------- the engine
@router.get("/live/status")
def status():
    eng = get_engine(start=False)
    return _plain({**_info, "running": eng.running, "focused": eng.focused(), "last_sweep": eng.last_sweep,
                   "models": eng.models()})


@router.get("/live/board")
def board():
    return _plain(get_engine().board())


@router.get("/live/match/{match_id}")
def match(match_id: int, heartbeat: bool = Query(True, description="keep the match in focus")):
    eng = get_engine()
    if heartbeat:
        eng.focus_on(match_id)
    view = eng.match_view(match_id)
    if view.get("status") == "unknown":
        raise HTTPException(404, "match {} has not been seen by the live engine yet".format(match_id))
    return _plain(view)


@router.post("/live/focus/{match_id}")
def focus(match_id: int, ttl: Optional[float] = Query(None, description="seconds; default live.focus_ttl_seconds")):
    eng = get_engine()
    eng.request_focus(match_id, "opened on the desk", ttl)
    return {"focused": eng.focused()}


@router.delete("/live/focus/{match_id}")
def unfocus(match_id: int):
    eng = get_engine(start=False)
    eng.focus_off(match_id)
    return {"focused": eng.focused()}


@router.post("/live/start")
def start():
    get_engine(start=True)
    return status()


@router.post("/live/stop")
def stop():
    eng = get_engine(start=False)
    eng.stop()
    return status()
