@echo off
REM Algo E - every comparison on the champions' held-out test days -> report.html
REM (turnover pipelines vs last 5 min, feature-group ablation, beliefs, expected vs realised
REM margin, in-play settlement replication, theta* vs HKJC's theta).
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
set "ARGS=%*"
if not "%~1"=="" if exist "%~1\" (set "ALGOE_DATA_DIR=%~1" & set "ARGS=")
python -m algoe backtest %ARGS%
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Open the report.html printed above.) else (echo Backtest failed with exit code %CODE%.)
pause
exit /b %CODE%
