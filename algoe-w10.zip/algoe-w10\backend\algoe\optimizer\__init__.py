"""Theta search: maximise expected gross margin under price-elastic demand."""
