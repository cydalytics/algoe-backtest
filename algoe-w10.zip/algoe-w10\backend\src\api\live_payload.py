"""
Live API Payloads (the W10 engine)

The live engine's state in the shapes the desk already draws, so the board and the cockpit read
one engine - the trained turnover forecast, the calibrated belief and the theta optimizer - on
the board as it stood at the last refresh:

    board(engine)                 one row per match on the panel
    cockpit(engine, match_id)     one match in full: header, theta, the book, the decision, the
                                  bucket's money, quotes, incidents, price history - plus how
                                  fresh it is and which models are serving
    what_if(engine, id, theta)    the match's last book at another theta
    curves(engine, id)            E[GM] along each dimension, the others at theta*

A selection keeps the field names the desk components read (hkjc_odds, true_prob, t_hat,
sell_odds_star ...) and adds the engine's own: forecast (this bucket), observed (so far),
remaining, next_bucket, last_bucket (the naive baseline: last bucket's money), belief, in_book.
Pools the engine does not model are listed under "HKJC only" with HKJC's prices alone. What the
engine did not compute is null, never a default.

Change Log:
-----------
2026-10-26      Initialize
"""

import math
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from src.api.payload import _num, _text, _theta
from src.core import config
from src.pricing import book as book_lib
from src.pricing import pools as pool_defs

KEY = ("pool_id", "line_id", "combination_id")
OTHER_FAMILY = "HKJC only"
FAMILY_ORDER = tuple(pool_defs.FAMILY_ORDER) + (OTHER_FAMILY,)
POOL_ORDER = ("HAD", "FHAD", "HHAD", "HDC", "FHDC", "HILO", "FHLO", "OOE", "TTG", "CRS", "FCRS", "HFT",
              "CHLO", "CHDC", "FCHLO", "FCHDC")
SIDE_ORDER = {"H": 0, "D": 1, "A": 2, "O": 0, "L": 1}
INCIDENTS = {
    config.INCIDENT_GOAL: "goal", config.INCIDENT_GOAL_CANCEL: "goal cancelled",
    config.INCIDENT_CORNER: "corner", config.INCIDENT_CORNER_CANCEL: "corner cancelled",
    config.INCIDENT_PENALTY: "penalty", config.INCIDENT_PENALTY_CANCEL: "penalty cancelled",
    config.INCIDENT_RED: "red card", config.INCIDENT_RED_CANCEL: "red card cancelled",
    config.INCIDENT_YELLOW_RED: "second yellow", config.INCIDENT_YELLOW_RED_CANCEL: "second yellow cancelled",
    config.INCIDENT_YELLOW: "yellow card", config.INCIDENT_YELLOW_CANCEL: "yellow card cancelled",
}
# what a W10 market is called in the desk's vocabulary
KIND_OF_MARKET = {"total": "asian_total", "home_total": "asian_total", "away_total": "asian_total",
                  "handicap": "asian_hcp"}
FAMILY_OF_MARKET = {"three_way": "Result", "handicap_3w": "Result", "handicap": "Handicap", "total": "Totals",
                    "home_total": "Totals", "away_total": "Totals", "odd_even": "Totals", "exact_total": "Totals",
                    "correct_score": "Score", "half_full": "Score"}
SELECTION_KEYS = (
    "key", "pool_id", "pool_code", "pool_name", "family", "seg", "domain", "kind", "optimized", "line_id",
    "line_label", "line_value", "comb_id", "selection", "sel_label", "is_main_line",
    "hkjc_odds", "hkjc_odds_prev", "hkjc_true_odds", "odds_age_sec",
    "mkt_min", "mkt_avg", "mkt_max", "mkt_n", "mkt_age_sec",
    "true_prob", "true_prob_src", "book_sum", "model_prob", "fair_odds", "sell_odds", "status", "edge_hkjc",
    "edge_mkt", "exp_gm_unit", "t5m", "tickets5m", "avg_stake", "t_hat", "t_hat_src", "t_share", "t_trend",
    "invested", "tickets_today", "model_prob_star", "fair_odds_star", "sell_odds_star", "status_star",
    "exp_gm_unit_star", "odds_delta",
    "forecast", "observed", "remaining", "next_bucket", "last_bucket", "belief", "in_book", "modelled",
    "odds_star", "demand", "demand_star", "weighting",
)


# ---------------------------------------------------------------------------
# Primitives
# ---------------------------------------------------------------------------

def _iso(value) -> Optional[str]:
    if value is None or value == "None":
        return None
    try:
        t = pd.Timestamp(value)
    except (TypeError, ValueError):
        return None
    return None if pd.isna(t) else t.isoformat()


def _key(row) -> tuple:
    return tuple(int(row[k]) for k in KEY)


def _ratio(a, b) -> Optional[float]:
    a, b = _num(a), _num(b)
    return a / b - 1.0 if a and b else None


def _describe(source) -> str:
    try:
        return source.describe()
    except Exception:                                                   # noqa: BLE001
        return getattr(source, "name", type(source).__name__)


def _taxonomy():
    from algoe.core.taxonomy import default_taxonomy
    return default_taxonomy()


def _pool(code: str):
    """(desk pool definition or None, family, segment, domain, kind, display name) for a pool code."""
    p = pool_defs.resolve(code)
    if p is not None:
        return p, p.family, p.seg, p.domain, p.kind, p.name
    spec = _taxonomy().resolve(code)
    domain = "corner" if spec.domain == "corner" else "goal"
    family = "Corners" if domain == "corner" else FAMILY_OF_MARKET.get(spec.market, "Specials")
    return None, family, "HT" if spec.segment == "FH" else "FT", domain, \
        KIND_OF_MARKET.get(spec.market, spec.market), code


SIDES = ("Home", "Away")


def _label(pool, kind: str, comb, home: str = SIDES[0], away: str = SIDES[1]):
    """The canonical selection key and the words the book shows for it: the sides are Home / Away, and
    only the match header names the teams."""
    if pool is not None:
        sel = pool_defs.normalize_selection(pool, comb)
        if sel is not None:
            return sel, pool_defs.selection_label(pool, sel, home, away)
    from algoe.core.taxonomy import side_of
    side = side_of(comb)
    if kind == "asian_total" and side in ("H", "A"):
        return ("H", "High") if side == "H" else ("L", "Low")
    if side == "H":
        return "H", home
    if side == "A":
        return "A", away
    if side == "D":
        return "D", "Draw"
    text = _text(comb) or "?"
    return text, text


# ---------------------------------------------------------------------------
# Rules, models, freshness
# ---------------------------------------------------------------------------

def rules(engine, models: Optional[dict] = None, pools=()) -> dict:
    """What the numbers on screen are made of: the serving models, or the MVP rule where there is none."""
    m = models or engine.models()
    tf, pc = m.get("turnover"), m.get("probability")
    return {
        "true_prob": {
            "id": m.get("probability_method") or "hkjc_true",
            "label": "Belief = {} (W10)".format(m.get("probability_method")) if pc
            else "Belief = 1 / HKJC true odds (no W10 model)",
            "note": "calibrated on settled selections, model {}".format(pc) if pc
            else "no probability model in AlgoE_Work/models",
        },
        "turnover": {
            "id": m.get("turnover_pipeline") or "last5",
            "label": "Turnover = {} (W10)".format(m.get("turnover_pipeline")) if tf
            else "Turnover = last 5 min (no W10 model)",
            "note": "bucket forecast; the rest of the bucket nowcast from the money already in"
                    + (", model {}".format(tf) if tf else ""),
        },
        "theta_semantics": config.THETA_SEMANTICS,
        "theta_layer": "Current",
        "bucket_minutes": int(engine.settings.panel.bucket_minutes),
        "optimizer": "W10 ThetaOptimizer ({} pricing; trust band, max step, probability band, market cap)".format(
            engine.settings.optimizer.price_mode),
        "optimized_pools": sorted(set(pools)),
    }


def _freshness(engine, v: dict) -> dict:
    lv = engine.settings.live
    req = v.get("requested_at")
    return {
        "mode": v.get("mode"),
        "bucket": _iso(v.get("bucket")),
        "board_at": _iso(v.get("board_at")),
        "params_at": _iso(v.get("params_at")),
        "refreshed_at": _iso(v.get("refreshed_at")),
        "requested_at": _iso(pd.Timestamp.fromtimestamp(req)) if req else None,
        "refreshing": bool(v.get("refreshing")),
        "focused": int(v["match_id"]) in engine.focused(),
        "focus_interval_seconds": float(lv.focus_interval_seconds),
        "ttl_seconds": float(lv.focus_ttl_seconds),
        "server_time": pd.Timestamp.now().isoformat(timespec="seconds"),
        "error": v.get("error"),
        "running": engine.running,
    }


# ---------------------------------------------------------------------------
# Selections and the book
# ---------------------------------------------------------------------------

def _blank() -> dict:
    return dict.fromkeys(SELECTION_KEYS)


def _selection(r: dict, mid: int, quotes: Dict[tuple, dict], total: float,
               fallback_turnover: bool, fallback_belief: bool) -> dict:
    code = (_text(r.get("pool_name")) or "UNKNOWN").upper()
    pool, family, seg, domain, kind, name = _pool(code)
    sel, label = _label(pool, kind, r.get("combination_string"))
    key = _key(r)
    odds, true, belief = _num(r.get("odds"), 4), _num(r.get("true_odds"), 4), _num(r.get("belief"), 6)
    in_book = bool(r.get("in_book"))
    star = _num(r.get("odds_star_ladder"), 4) if in_book else None
    q = quotes.get(key) or {}
    mkt = q.get("avg") if q else _num(r.get("mkt_odds"), 4)
    offer = star or odds
    F, obs, rem = _num(r.get("forecast"), 2), _num(r.get("observed"), 2), _num(r.get("remaining"), 2)
    last, tickets = _num(r.get("last_bucket"), 2), _num(r.get("tickets_last_bucket"), 0)
    status = "open" if r.get("forecastable") else "closed"
    age = _num(r.get("odds_age_min"))
    out = _blank()
    out.update(
        key=pool_defs.selection_key(mid, code, key[1], key[2]), pool_id=key[0], pool_code=code, pool_name=name,
        family=family, seg=seg, domain=domain, kind=kind, optimized=in_book, line_id=key[1],
        line_label=_text(r.get("line_label")), line_value=_num(r.get("line"), 3), comb_id=key[2], selection=sel,
        sel_label=label, is_main_line=bool(r.get("is_main")),
        hkjc_odds=odds, hkjc_true_odds=true, odds_age_sec=_num(age * 60.0, 0) if age is not None else None,
        mkt_min=q.get("min"), mkt_avg=mkt, mkt_max=q.get("max"), mkt_n=q.get("n"), mkt_age_sec=q.get("age"),
        true_prob=belief, true_prob_src="hkjc_true" if fallback_belief else "w10",
        model_prob=_num(r.get("model_prob"), 6), fair_odds=_num(1.0 / belief, 4) if belief else None,
        sell_odds=odds, status=status, edge_hkjc=_ratio(offer, odds), edge_mkt=_ratio(offer, mkt),
        exp_gm_unit=_num(1.0 - odds * belief, 5) if odds and belief is not None else None,
        t5m=last, tickets5m=tickets, avg_stake=_num(last / tickets, 2) if last is not None and tickets else None,
        t_hat=F, t_hat_src="last5" if fallback_turnover else "w10",
        t_share=_num(F / total, 5) if F is not None and total else None,
        t_trend=_num(((obs or 0.0) + (rem or 0.0)) / F, 3) if F else None,
        sell_odds_star=star, status_star=status if star is not None else None,
        exp_gm_unit_star=_num(1.0 - star * belief, 5) if star and belief is not None else None,
        odds_delta=_num(star - odds, 4) if star and odds else None,
        forecast=F, observed=obs, remaining=rem, next_bucket=_num(r.get("next_bucket"), 2), last_bucket=last,
        belief=belief, in_book=in_book, modelled=True, odds_star=_num(r.get("odds_star"), 4),
        demand=_num(r.get("demand"), 2), demand_star=_num(r.get("demand_star"), 2),
        weighting=_num(r.get("weighting"), 5))
    return out


def _other(r: dict, mid: int) -> dict:
    """A pool the engine does not forecast or optimise: HKJC's price, nothing of ours."""
    code = (_text(r.get("pool_name")) or "UNKNOWN").upper()
    pool, _, seg, domain, kind, name = _pool(code)
    sel, label = _label(pool, kind, r.get("combination_string"))
    key = _key(r)
    out = _blank()
    out.update(key=pool_defs.selection_key(mid, code, key[1], key[2]), pool_id=key[0], pool_code=code,
               pool_name=name, family=OTHER_FAMILY, seg=seg, domain=domain, kind=kind, optimized=False,
               line_id=key[1], line_label=_text(r.get("line_label")),
               line_value=_num(pool_defs.parse_line(r.get("line_label")), 3), comb_id=key[2], selection=sel,
               sel_label=label, is_main_line=False, hkjc_odds=_num(r.get("odds"), 4),
               hkjc_true_odds=_num(r.get("true_odds"), 4), sell_odds=_num(r.get("odds"), 4), status="open",
               in_book=False, modelled=False)
    return out


def _sel_order(s: dict):
    key = s.get("selection") or ""
    if key in SIDE_ORDER:
        return (0, SIDE_ORDER[key], 0, 0)
    if ":" in key:
        h, _, a = key.partition(":")
        try:
            h, a = int(h), int(a)
            return (1, (0 if h > a else 1 if h == a else 2), h, a)
        except ValueError:
            pass
    return (2, 0, 0, 0)


def _book(sels: List[dict], margin_for) -> dict:
    """Selections grouped the way the cockpit's tree draws them: family -> pool -> line."""
    families = []
    known = list(FAMILY_ORDER) + sorted({s["family"] for s in sels} - set(FAMILY_ORDER))
    for family in known:
        mine = [s for s in sels if s["family"] == family]
        if not mine:
            continue
        pools = []
        codes = sorted({s["pool_code"] for s in mine},
                       key=lambda c: (POOL_ORDER.index(c) if c in POOL_ORDER else len(POOL_ORDER), c))
        for code in codes:
            ps = [s for s in mine if s["pool_code"] == code]
            lines = []
            for line_id in sorted({s["line_id"] for s in ps}):
                ls = sorted([s for s in ps if s["line_id"] == line_id], key=_sel_order)
                trues = [s["hkjc_true_odds"] for s in ls]
                lines.append({
                    "line_id": int(line_id), "line_label": ls[0]["line_label"], "line_value": ls[0]["line_value"],
                    "is_main_line": any(s["is_main_line"] for s in ls),
                    "book_sum": _num(sum(1.0 / t for t in trues), 4) if trues and all(t and t > 1 for t in trues)
                    else None,
                    "turnover": _num(sum(s["t_hat"] or 0.0 for s in ls), 2) if any(s["modelled"] for s in ls) else None,
                    "selections": ls})
            lines.sort(key=lambda l: (not l["is_main_line"], l["line_value"] if l["line_value"] is not None else 0.0))
            first = ps[0]
            modelled = any(s["modelled"] for s in ps)
            pools.append({
                "pool_code": code, "pool_name": first["pool_name"], "domain": first["domain"], "seg": first["seg"],
                "kind": first["kind"], "optimized": any(s["in_book"] for s in ps),
                "margin": _num(margin_for(code), 4) if modelled else None,
                "turnover": _num(sum(s["t_hat"] or 0.0 for s in ps), 2) if modelled else None,
                "open": sum(1 for s in ps if s["status"] == "open"), "lines": lines})
        families.append({"family": family, "pools": pools,
                         "turnover": _num(sum(s["t_hat"] or 0.0 for s in mine), 2)
                         if any(s["modelled"] for s in mine) else None})
    modelled = [s for s in sels if s["modelled"]]
    return {"families": families,
            "totals": {"selections": len(sels), "open": sum(1 for s in sels if s["status"] == "open"),
                       "turnover": _num(sum(s["t_hat"] or 0.0 for s in modelled), 2)}}


def _quote_stats(extras: dict) -> Dict[tuple, dict]:
    out: Dict[tuple, dict] = {}
    rows = extras.get("quotes") or []
    by: Dict[tuple, list] = {}
    for q in rows:
        odds = _num(q.get("odds"))
        if odds and odds > 1.0:
            by.setdefault(_key(q), []).append((odds, _num(q.get("age_sec"))))
    for k, xs in by.items():
        prices = [x for x, _ in xs]
        ages = [a for _, a in xs if a is not None]
        out[k] = {"min": _num(min(prices), 4), "avg": _num(sum(prices) / len(prices), 4), "max": _num(max(prices), 4),
                  "n": len(prices), "age": _num(min(ages), 0) if ages else None}
    return out


def _quotes(extras: dict, label_of: Dict[tuple, tuple]) -> dict:
    rows = []
    for q in extras.get("quotes") or []:
        ident = label_of.get(_key(q))
        if ident is None:
            continue
        rows.append({"key": ident[0], "label": ident[1],
                     "bookmaker": _text(q.get("bookmaker_str")) or _text(q.get("bookmaker")),
                     "odds": _num(q.get("odds"), 3), "age_sec": int(_num(q.get("age_sec")) or 0)})
    return {"books": sorted({r["bookmaker"] for r in rows if r["bookmaker"]}), "rows": rows}


def _events(extras: dict) -> list:
    out = []
    for e in extras.get("incidents") or []:
        code = _num(e.get("incident_type"))
        side = _num(e.get("home_or_away"))
        out.append({"at": _iso(e.get("incident_datetime")),
                    "type": INCIDENTS.get(int(code), "incident {}".format(int(code))) if code is not None else "incident",
                    "side": "home" if side == 1 else "away" if side == 2 else "",
                    "detail": "", "provider_id": int(_num(e.get("provider_id"))) if _num(e.get("provider_id")) else None})
    return out


def _history(extras: dict, label_of: Dict[tuple, tuple]) -> dict:
    out: Dict[str, list] = {}
    for h in extras.get("history") or []:
        ident = label_of.get(_key(h))
        if ident is None:
            continue
        out.setdefault(ident[0], []).append({"at": _iso(h.get("effective_datetime")), "odds": _num(h.get("odds"), 3),
                                             "true_odds": _num(h.get("true_odds"), 3)})
    return out


# ---------------------------------------------------------------------------
# Theta and the decision
# ---------------------------------------------------------------------------

def _moves(theta_now: dict, theta_star: dict, binding) -> list:
    out = []
    for dim in book_lib.DIMS:
        now, star = _num((theta_now or {}).get(dim)), _num((theta_star or {}).get(dim))
        if now is None or star is None or abs(star - now) < 1e-4:
            continue
        out.append({"dim": dim, "label": book_lib.DIM_LABELS.get(dim, dim), "now": _num(now, 4), "star": _num(star, 4),
                    "delta": _num(star - now, 4),
                    # the solver wanted to go further: the trust band around HKJC's theta stopped it
                    "at_limit": any(str(b).startswith(dim + "@") for b in (binding or []))})
    return sorted(out, key=lambda m: -abs(m["delta"] or 0.0))


def _theta_block(engine, v: dict, header: dict) -> dict:
    band = engine.settings.optimizer.theta_band
    hkjc = v.get("theta_hkjc") or v.get("theta_now") or {}
    dims = []
    for dim in book_lib.DIMS:
        now, b = _num(hkjc.get(dim)), float(band.get(dim, config.THETA_MAX_MOVE.get(dim, 0.0)))
        bounds = [max(now - b, 0.0) if dim.endswith("_tg") else now - b, now + b] if now is not None \
            else list(config.THETA_BOUNDS[dim])
        dims.append({"dim": dim, "label": book_lib.DIM_LABELS[dim], "bounds": [_num(x, 4) for x in bounds],
                     "max_move": b, "domain": "corner" if dim.startswith("corner") else "goal"})
    splits = header.get("splits") or {}
    return {"layers": {"Current": _theta(hkjc)}, "layer": "Current", "age_min": _num(v.get("theta_age_min"), 1),
            "splits": {k: _num(splits.get(k), 4) for k in ("goal", "corner")}, "semantics": config.THETA_SEMANTICS,
            "dims": dims, "params_at": _iso(v.get("params_at")), "board_at": _iso(v.get("board_at"))}


def _optimizer(v: dict, sels: List[dict]) -> Optional[dict]:
    if not v.get("theta_star") or v.get("status") in ("pending", "no book"):
        return None
    book = [s for s in sels if s["in_book"]]
    gm_now, gm_star, turnover = _num(v.get("gm_now")), _num(v.get("gm_star")), _num(v.get("turnover"))
    demand_star = sum(s["demand_star"] or 0.0 for s in book)
    family_of = {s["pool_code"]: s["family"] for s in book}
    legs_of: Dict[str, int] = {}
    for s in book:
        legs_of[s["pool_code"]] = legs_of.get(s["pool_code"], 0) + 1
    return {
        "theta_now": _theta(v.get("theta_now") or {}), "theta_star": _theta(v.get("theta_star") or {}),
        "turnover": _num(turnover, 2),
        "payout_now": _num(turnover - gm_now, 2) if turnover is not None and gm_now is not None else None,
        "payout_star": _num(demand_star - gm_star, 2) if gm_star is not None else None,
        "gm_now": _num(gm_now, 2), "gm_star": _num(gm_star, 2), "uplift": _num(v.get("lift"), 2),
        "uplift_bps": _num(v.get("lift_bps"), 1), "legs": len(book), "skipped": 0, "seconds": None,
        "moves": _moves(v.get("theta_now"), v.get("theta_star"), v.get("binding")),
        "repaired": [], "blocks": [],
        "per_pool": [{"pool_code": p.get("pool"), "family": family_of.get(p.get("pool")),
                      "turnover": _num(p.get("turnover"), 2), "payout_now": None, "payout_star": None,
                      "legs": legs_of.get(p.get("pool"), 0), "gm_now": _num(p.get("egm_board"), 2),
                      "gm_star": _num(p.get("egm_star"), 2), "uplift": _num(p.get("lift"), 2)}
                     for p in v.get("per_pool") or []],
        "curves": {}, "status": v.get("status"), "binding": list(v.get("binding") or []), "mode": v.get("mode"),
    }


def _match(header: dict, mid: int) -> dict:
    phase = header.get("phase") or "prematch"
    return {"match_id": int(mid), "home": header.get("home") or "", "away": header.get("away") or "",
            "league": header.get("league") or "", "league_code": header.get("league_code") or "",
            "kickoff": _iso(header.get("kickoff")), "frontend_id": None, "phase": phase, "game_state": phase,
            "minute": _num(header.get("minute"), 1), "in_play": bool(header.get("in_play")),
            "ht_done": phase in ("half_time", "second_half", "extra_time"),
            "score": list(header.get("score") or [0, 0]), "ht_score": [None, None],
            "corners": list(header.get("corners") or [0, 0]), "ht_corners": [None, None],
            "reds": list(header.get("reds") or [0, 0])}


# ---------------------------------------------------------------------------
# The four payloads
# ---------------------------------------------------------------------------

def cockpit(engine, match_id: int) -> Optional[dict]:
    """One match in full, as the engine holds it after its last refresh."""
    v = engine.match_view(int(match_id))
    if v.get("status") == "unknown":
        return None
    mid = int(match_id)
    header, models = v.get("header") or {}, v.get("models") or engine.models()
    extras = v.get("extras") or {}
    rows = v.get("rows") or []
    stats = _quote_stats(extras)
    total = sum(_num(r.get("forecast")) or 0.0 for r in rows)
    fb_t, fb_p = models.get("turnover") is None, models.get("probability") is None
    sels = [_selection(r, mid, stats, total, fb_t, fb_p) for r in rows]
    have = {_key(r) for r in rows}
    sels += [_other(r, mid) for r in extras.get("latest") or [] if _key(r) not in have]
    label_of = {(s["pool_id"], s["line_id"], s["comb_id"]): (s["key"], " ".join(
        x for x in (s["pool_code"], s["line_label"], s["sel_label"]) if x)) for s in sels}
    bucket = pd.Timestamp(v["bucket"]) if v.get("bucket") not in (None, "None") else None
    return {
        "run_id": "live-{}-{}".format(bucket.strftime("%Y%m%d-%H%M") if bucket is not None else "pending",
                                      v.get("mode")),
        "as_of": _iso(v.get("board_at")),
        "source": _describe(engine.source),
        "pending": v.get("status") == "pending",
        "solving": bool(v.get("refreshing")),
        "rules": rules(engine, models, {s["pool_code"] for s in sels if s["in_book"]}),
        "match": _match(header, mid),
        "theta": _theta_block(engine, v, header),
        "optimizer": _optimizer(v, sels),
        "book": _book(sels, engine.settings.margin_for),
        "events": _events(extras),
        "quotes": _quotes(extras, label_of),
        "history": _history(extras, label_of),
        "freshness": _freshness(engine, v),
        "models": models,
        "flow": {"expected": _num(v.get("expected"), 2), "observed": _num(v.get("observed_in_bucket"), 2),
                 "remaining": _num(v.get("remaining_in_bucket"), 2),
                 "next_bucket": _num(sum(_num(r.get("next_bucket")) or 0.0 for r in rows), 2),
                 "last_bucket": _num(v.get("last_bucket"), 2), "hot": _num(v.get("hot"), 3),
                 "event": v.get("event_in_bucket")},
    }


def _alerts(s: dict) -> list:
    out = []
    if s.get("error"):
        out.append({"level": "bad", "text": "refresh failed: {}".format(str(s["error"])[:80])})
    status = s.get("status") or ""
    if status == "no book":
        out.append({"level": "warn", "text": "no book: no HKJC TG/SUP or no live line market"})
    elif status.startswith("skipped") or status.startswith("kept"):
        out.append({"level": "warn", "text": status})
    age = _num(s.get("theta_age_min"))
    if age is not None and age >= 10:
        out.append({"level": "warn", "text": "TG/SUP {:.0f} min old".format(age)})
    if s.get("triggers"):
        out.append({"level": "warn", "text": "trigger: {}".format(s["triggers"][-1])})
    if status.startswith("solved") and (_num(s.get("lift_bps")) or 0.0) >= 50:
        out.append({"level": "good", "text": "{:.0f} bps on the table".format(s["lift_bps"])})
    return out


def _board_row(s: dict, focused=frozenset()) -> dict:
    status = s.get("status") or "pending"
    decided = bool(s.get("theta_star"))
    phase = s.get("phase") or "prematch"
    return {
        "match_id": int(s["match_id"]), "home": s.get("home") or "", "away": s.get("away") or "",
        "league": s.get("league") or "", "league_code": s.get("league_code") or "", "kickoff": _iso(s.get("kickoff")),
        "phase": phase, "game_state": phase, "minute": _num(s.get("minute"), 1), "in_play": bool(s.get("in_play")),
        "score": list(s.get("score") or [0, 0]), "ht_score": [None, None], "corners": list(s.get("corners") or [0, 0]),
        "theta_age_min": _num(s.get("theta_age_min"), 1), "theta_now": _theta(s.get("theta_now") or {}),
        "theta_star": _theta(s["theta_star"]) if decided else None,
        "pools": int(s.get("pools") or 0), "selections": int(s.get("selections") or 0), "open": int(s.get("open") or 0),
        "turnover_5m": _num(s.get("last_bucket"), 2), "tickets_5m": int(s.get("tickets_last_bucket") or 0),
        "turnover": _num(s.get("expected"), 2),
        "gm_now": _num(s.get("gm_now"), 2), "gm_star": _num(s.get("gm_star"), 2),
        "uplift": _num(s.get("lift"), 2) if decided else None,
        "uplift_bps": _num(s.get("lift_bps"), 1) if decided else None,
        "legs": int(s.get("in_book") or 0), "skipped": 0, "solved": status.startswith("solved"),
        "pending": status == "pending", "seconds": None,
        "moves": _moves(s.get("theta_now"), s.get("theta_star"), s.get("binding")), "alerts": _alerts(s),
        "expected": _num(s.get("expected"), 2), "last_bucket": _num(s.get("last_bucket"), 2),
        "observed": _num(s.get("observed_in_bucket"), 2), "remaining": _num(s.get("remaining_in_bucket"), 2),
        "mode": s.get("mode"), "board_at": _iso(s.get("board_at")), "refreshed_at": _iso(s.get("refreshed_at")),
        "status": status, "triggers": list(s.get("triggers") or []), "binding": list(s.get("binding") or []),
        "focused": int(s["match_id"]) in focused,
    }


def board(engine) -> dict:
    """One row per match on the panel as the bucket's sweep priced it, the richest recommendation first;
    ``focused`` marks the matches a desk has open (their cockpit has the newer read)."""
    b = engine.board()
    models = engine.models()
    ls = b.get("last_sweep") or {}
    focused = frozenset(int(m) for m in b.get("focused") or [])
    rows = [_board_row(s, focused) for s in b.get("matches") or []]
    rows.sort(key=lambda r: (-(r["uplift"] or 0.0), -(r["expected"] or 0.0), r["match_id"]))
    decided = [r for r in rows if r["theta_star"] is not None]
    gm_now = sum(r["gm_now"] or 0.0 for r in decided)
    gm_star = sum(r["gm_star"] or 0.0 for r in decided)
    expected = sum(r["expected"] or 0.0 for r in rows)
    warnings = ["no W10 model: {}".format(f) for f in models.get("fallback") or []]
    if not ls:
        warnings.append("the first sweep of the card is still running")
    elif ls.get("note"):
        warnings.append(str(ls["note"]))
    bucket = ls.get("bucket")
    return {
        "run_id": "live-{}".format(pd.Timestamp(bucket).strftime("%Y%m%d-%H%M") if bucket else "pending"),
        "as_of": _iso(ls.get("as_of")), "source": _describe(engine.source),
        "totals": {"turnover": _num(expected, 2), "payout_now": None, "gm_now": _num(gm_now, 2),
                   "margin_now": _num(gm_now / expected, 5) if expected else None,
                   "legs": sum(r["legs"] for r in rows), "matches": len(rows),
                   "selections": sum(r["selections"] for r in rows),
                   "opt_turnover": _num(sum(r["expected"] or 0.0 for r in decided), 2),
                   "opt_gm_now": _num(gm_now, 2), "gm_star": _num(gm_star, 2), "uplift": _num(gm_star - gm_now, 2),
                   "uplift_bps": _num(1e4 * (gm_star - gm_now) / expected, 1) if expected else None},
        "warnings": warnings, "timings": dict(ls.get("seconds") or {}), "rules": rules(engine, models),
        "progress": {"solved": sum(1 for r in rows if r["solved"]), "total": len(rows), "solving": not ls},
        "matches": rows, "models": models, "focused": list(b.get("focused") or []),
    }


def what_if(engine, match_id: int, theta: Dict[str, float], pools: Optional[List[str]] = None) -> Optional[dict]:
    """The match's last book at another theta: what the cockpit lays over the live book."""
    from algoe.optimizer.theta_optimizer import publish_odds
    r = engine.price_at(int(match_id), theta)
    if r is None:
        return None
    v = engine.match_view(int(match_id))
    rows = {_key(x): x for x in v.get("rows") or []}
    wanted = {p.upper() for p in pools} if pools else None
    ladder = publish_odds(r["odds"])
    sels = []
    for i, k in enumerate(r["keys"].astype("int64").itertuples(index=False, name=None)):
        row = rows.get(tuple(k)) or {}
        code = (_text(row.get("pool_name")) or "UNKNOWN").upper()
        if wanted is not None and code not in wanted:
            continue
        pool, _, _, _, kind, _ = _pool(code)
        _, label = _label(pool, kind, row.get("combination_string"))
        odds, belief = float(r["odds"][i]), float(r["belief"][i])
        sels.append({"key": pool_defs.selection_key(int(match_id), code, k[1], k[2]), "pool_code": code,
                     "line_label": _text(row.get("line_label")), "sel_label": label,
                     "hkjc_odds": _num(r["odds_now"][i], 4), "sell_odds": _num(r["odds_now"][i], 4),
                     "sell_odds_what": _num(ladder[i], 4), "model_prob_what": _num(r["model_prob"][i], 6),
                     "status_what": "open", "exp_gm_unit_what": _num(1.0 - odds * belief, 5),
                     "t_hat": _num(r["demand"][i], 2)})

    def expected(turnover, gm):
        return {"turnover": _num(turnover, 2), "payout": _num(turnover - gm, 2), "gm": _num(gm, 2),
                "margin_pct": _num(gm / turnover, 5) if turnover else None, "legs": int(r["legs"])}
    return {"match_id": int(match_id), "theta": _theta(r["theta"]), "expected": expected(r["turnover"], r["gm"]),
            "baseline": expected(r["turnover_board"], r["gm_board"]), "selections": sels}


def curves(engine, match_id: int) -> Optional[dict]:
    c = engine.curves(int(match_id))
    if c is None:
        return None
    return {"match_id": int(match_id), "turnover": _num(c["turnover"], 2),
            "curves": {dim: {"x": [_num(x, 4) for x in cv["x"]], "gm": [_num(g, 2) for g in cv["gm"]],
                             "now": _num(cv["now"], 4), "star": _num(cv["star"], 4)}
                       for dim, cv in c["curves"].items() if dim in book_lib.DIMS}}
