"""Self-contained HTML reports: inline SVG, no CDN, opens on the air-gapped box."""
