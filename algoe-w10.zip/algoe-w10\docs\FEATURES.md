# Features and the hypotheses they test

Generated from `backend/algoe/features/catalog.py` (feature version 9) and the backtest's
feature-group ablation on the synthetic world (`compare_feature_groups`: drop the group,
refit the GLM, compare validation deviance - positive = the group helps). Re-generate after
the first real-data backtest; the synthetic verdicts only show the machinery works.

## Hypotheses

| id | hypothesis | groups | ablation (synthetic) |
|----|------------|--------|---------|
| H1 | Match money is autocorrelated: recent match totals predict the next bucket (+). | memory_match | match_total +3.6% (supported) |
| H2 | Pre-match money ramps up towards kick-off (hyperbolic in minutes to KO). | lifecycle | match_total -66.2% (hurts); selection_share +0.1% (no effect) |
| H3 | In-play money follows the clock: rises through the match, dips at half time. | lifecycle | match_total -66.2% (hurts); selection_share +0.1% (no effect) |
| H4 | Goals and red cards cause a demand spike that decays over ~5-15 minutes (+). | events | match_total +9.3% (supported); selection_share -0.0% (no effect) |
| H5 | Some leagues / matches draw far more money; a shrunk league level and the match's own running level carry it (+). | popularity | match_total +6.5% (supported); selection_share +0.2% (no effect) |
| H6 | Concurrent matches split attention: more live matches -> less per match (-). | concurrency | match_total +7.8% (supported) |
| H7 | Weekend, evening and holiday buckets take more money (+). | calendar | match_total +6.7% (supported) |
| H8 | Close, high-scoring games take more in-play money; a settled blowout takes less. | competitiveness, events | match_total +9.3% (supported); match_total -7.6% (hurts); selection_share +0.2% (supported); selection_share -0.0% (no effect) |
| H9 | More pools / lines open -> more money on the match (+). |  | - |
| H11 | Pool shares depend on phase (FH pools die at half time, totals gain late). | bet_type, lifecycle, popularity | match_total +6.5% (supported); match_total -66.2% (hurts); selection_share +0.1% (no effect); selection_share +0.2% (no effect) |
| H12 | Recent pool shares persist (+). | memory_pool | - |
| H14 | The main (most balanced) line takes most of a pool; share decays with distance (-). | line_position | selection_share +1.8% (supported) |
| H15 | Within a line the side whose price is more generous (vs HKJC's own true odds or the market) takes more money (+): this is the price elasticity the optimiser uses. | price | match_total -0.0% (no effect); selection_share +4.6% (supported) |
| H16 | Punters prefer some sides (overs, favourites) independent of price. | bet_type | selection_share +0.2% (no effect) |
| H17 | A price that has just shortened signals money that keeps coming (herding). | price | match_total -0.0% (no effect); selection_share +4.6% (supported) |
| H18 | A selection's recent share of its pool persists (+). | memory_selection | selection_share +5.6% (supported) |
| H19 | When the main line moves, the money follows the position, not the old line id. | line_position, memory_selection | selection_share +1.8% (supported); selection_share +5.6% (supported) |
| H20 | Stale prices (no update for a long time) take little money (-). | price | match_total -0.0% (no effect); selection_share +4.6% (supported) |
| H21 | A dearer match (a higher book margin on its best lines) takes less money (-): punters bet less, not only elsewhere. | price | match_total -0.0% (no effect); selection_share +4.6% (supported) |
| H22 | Matches compete for the same money: a match takes less while a bigger one is on, and its share of the board follows its share of the board's expected popularity (cross-match). | concurrency | match_total +7.8% (supported) |
| H23 | Teams draw money beyond their league (big clubs): a team level shrunk to its league (+). | popularity | match_total +6.5% (supported); selection_share +0.2% (no effect) |
| H24 | The score relative to the favourite moves money between bet types and sides: the favourite in front, the underdog in front and a red card for either each shift totals, handicaps and overs differently, and by how far HKJC's expectation has moved since kick-off. | bet_type, competitiveness, events, game_state | match_total +2.0% (supported); match_total +9.3% (supported); match_total -7.6% (hurts); selection_share +0.2% (no effect); selection_share +0.2% (supported); selection_share -0.0% (no effect); selection_share -0.2% (hurts) |
| H25 | Corners and cards drive the corner and card markets (+). | game_state | match_total +2.0% (supported); selection_share -0.2% (hurts) |
| H26 | A price better than the market's (or than the selection's own earlier prices) takes more money (+). | price | match_total -0.0% (no effect); selection_share +4.6% (supported) |
| H27 | Breadth and margins count against a normal board (trailing 28-day references): more pools, lines or matches than usual, or a margin above the bet type's usual, read the same whatever HKJC lists or charges in a given year. | breadth, line_position, popularity, price | match_total +6.5% (supported); match_total -0.0% (no effect); match_total -39.2% (hurts); selection_share +0.2% (no effect); selection_share +1.8% (supported); selection_share +4.6% (supported) |

## Expected signs (GLM coefficients, synthetic)

| feature | hypothesis | expected | coefficient | agrees |
|---|---|---|---|---|
| goal_p3 | H4 | + | +0.6711 | yes |
| m_log_l1 | H1 | + | -0.0386 | **no** |
| weekend | H7 | + | -0.0446 | **no** |
| league_level | H5 | + | -1.0484 | **no** |
| value_true | H15 | + | +0.0802 | yes |
| value_mkt | H15 | + | -0.4661 | **no** |
| rank_0 | H14 | + | +0.0242 | yes |
| abs_line_offset | H14 | - | +0.0010 | **no** |
| log_odds_age | H20 | - | -0.7239 | yes |

Where a sign disagrees, the feature is usually collinear with a sibling (for example
`m_log_l1` with the match EWMA) or, in the synthetic world, shifted by the new pool code
launched mid-window (the breadth group: pool and line counts jump for every match, and a
linear model extrapolates; the GBM champion does not). These are the checks to read first
on real data.

## Match level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `m_log_l1` | memory_match | raw | H1 | 0 | [0, 20] | log1p match money T-1 |
| `m_log_l2` | memory_match | raw | H1 | 0 | [0, 20] |  |
| `m_log_l3` | memory_match | raw | H1 | 0 | [0, 20] |  |
| `m_log_ewma` | memory_match | raw | H1 | 0 | [0, 20] | log1p EWMA of 6 lags |
| `m_any_l1` | memory_match | flag | H1 | 0.0 |  |  |
| `m_trend` | memory_match | raw | H1 | 0 | [-15, 15] | log1p l1 - log1p l2 |
| `m_log_today` | memory_match | raw | H1 | 0 | [0, 25] | log1p money so far today |
| `inplay` | lifecycle | flag | H3 | 0.0 |  |  |
| `halftime` | lifecycle | flag | H3 | 0.0 |  |  |
| `stoppage` | lifecycle | flag | H3 | 0.0 |  | minute > 90 |
| `pre_ko_min` | lifecycle | raw | H2 | 360 | [0, 720] | minutes to KO, pre-match |
| `minute` | lifecycle | raw | H3 | 0 | [0, 130] | match minute in play |
| `ko_h0` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 0, 0) |
| `ko_h1` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 5, 0) |
| `ko_h2` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 10, 0) |
| `ko_h3` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 15, 0) |
| `ko_h4` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 30, 0) |
| `ko_h5` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 45, 0) |
| `ko_h6` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 60, 0) |
| `ko_h7` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 90, 0) |
| `ko_h8` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 120, 0) |
| `ko_h9` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 180, 0) |
| `ko_h10` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 240, 0) |
| `ko_h11` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 360, 0) |
| `min_h0` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 5, 0) |
| `min_h1` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 15, 0) |
| `min_h2` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 30, 0) |
| `min_h3` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 40, 0) |
| `min_h4` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 45, 0) |
| `min_h5` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 50, 0) |
| `min_h6` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 60, 0) |
| `min_h7` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 70, 0) |
| `min_h8` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 80, 0) |
| `min_h9` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 88, 0) |
| `min_h10` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 95, 0) |
| `goal_p3` | events | raw | H4 | 0 | [0, 5] | sum exp(-age/3) over goals |
| `goal_p10` | events | raw | H4 | 0 | [0, 5] |  |
| `red_p10` | events | raw | H4 | 0 | [0, 3] |  |
| `goals_so_far` | events | raw | H8 | 0 | [0, 12] |  |
| `abs_score_diff` | events | raw | H8 | 0 | [0, 10] |  |
| `since_goal` | events | raw | H4 | 1 | [0, 1] | min(minutes since goal, 120)/120 |
| `fav_lead` | game_state | raw | H24 | 0 | [-3, 3] | goals of the kick-off favourite minus the underdog's (0 when neither was favoured) |
| `dog_leading` | game_state | flag | H24 | 0.0 |  | the kick-off underdog is in front |
| `fav_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the favourite |
| `dog_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the underdog |
| `goal_p10_fav` | game_state | raw | H24 | 0 | [0, 5] | sum exp(-age/10) over the favourite's goals |
| `goal_p10_dog` | game_state | raw | H24 | 0 | [0, 5] | the same for the underdog's goals |
| `tg_shift` | game_state | raw | H24 | 0 | [-6, 8] | expected full-match goals now minus at kick-off: how far the game has run from script |
| `corners_so_far` | game_state | raw | H25 | 0 | [0, 30] |  |
| `corner_diff_fav` | game_state | raw | H25 | 0 | [-15, 15] | corners of the favourite minus the underdog's |
| `corner_p5` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/5) over corners |
| `yellow_p10` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/10) over yellow cards |
| `league_level` | popularity | encoded | H5 | 0 | [-10, 10] | shrunk league log-money level vs global |
| `league_known` | popularity | flag | H5 | 0.0 |  |  |
| `team_hi` | popularity | encoded | H23 | 0 | [-10, 10] | the bigger of the two teams' levels (shrunk to their league), vs global |
| `team_lo` | popularity | encoded | H23 | 0 | [-10, 10] | the smaller team's level |
| `team_known` | popularity | flag | H23 | 0.0 |  | both teams have their own level |
| `live_rel` | concurrency | raw | H6 | 0 | [0, 10] | matches in play now / a normal board's size (trailing reference) |
| `board_rel` | concurrency | raw | H6 | 1 | [0, 10] | matches on the board now / a normal board's size |
| `log_board_l1` | concurrency | raw | H6 | 0 | [0, 25] |  |
| `match_share_board_l1` | concurrency | raw | H6 | 0 | [0, 1] |  |
| `match_rank_l1` | concurrency | raw | H6 | 0.5 | [0, 1] | rank by money / n_board |
| `pop_board_share` | concurrency | encoded | H22 | 0 | [0, 1] | this match's share of the board's expected popularity (league and team levels) |
| `pop_gap_top` | concurrency | encoded | H22 | 0 | [0, 15] | how far (log) the board's most popular other match is above this one; 0 if this one leads |
| `live_pop_share` | concurrency | encoded | H22 | 0 | [0, 1] | share of the board's expected popularity in play now |
| `weekend` | calendar | flag | H7 | 0.0 |  |  |
| `holiday` | calendar | flag | H7 | 0.0 |  |  |
| `evening` | calendar | flag | H7 | 0.0 |  | HK 19:00-23:59 |
| `hour_s1` | calendar | raw | H7 | 0.0 |  |  |
| `hour_c1` | calendar | raw | H7 | 0.0 |  |  |
| `hour_s2` | calendar | raw | H7 | 0.0 |  |  |
| `hour_c2` | calendar | raw | H7 | 0.0 |  |  |
| `dow_s` | calendar | raw | H7 | 0.0 |  |  |
| `dow_c` | calendar | raw | H7 | 0.0 |  |  |
| `tg_full` | competitiveness | raw | H8 | 2.6 | [0, 12] | expected full-match goals: scored + still to come |
| `abs_sup` | competitiveness | raw | H8 | 0 | [0, 6] |  |
| `balance` | competitiveness | raw | H8 | 0 | [0, 1] | /sup/ / tg |
| `pools_rel` | breadth | raw | H27 | 0 | [-4, 4] | log(pools open / a normal match's pools, trailing reference) |
| `lines_rel` | breadth | raw | H27 | 0 | [-4, 4] | log(lines open / a normal match's lines) |
| `m_margin` | price | raw | H21 | 0.08 | [-0.2, 0.6] | book margin of the match's best lines, weighted by where its money goes |
| `m_margin_rel` | price | raw | H27 | 0 | [-0.3, 0.3] | m_margin minus the money-weighted usual margin of the bet types (trailing reference) |

## Pool level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `p_share_l1` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_share_l2` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_share_ewma` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_any_l1` | memory_pool | flag | H12 | 0.0 |  |  |
| `p_log_l1` | memory_pool | raw | H12 | 0 | [0, 20] |  |
| `p_lines_rel` | breadth | raw | H27 | 0 | [-4, 4] | log(lines open in the pool / a normal pool's lines, trailing reference) |
| `p_balance` | line_position | raw | H14 | 0.5 | [0, 1] | min /pH - pA/ over the pool's lines |
| `p_margin` | price | raw | H15 | 0.08 | [-0.2, 0.6] | book margin of the main line |
| `p_margin_rel` | price | raw | H27 | 0 | [-0.3, 0.3] | p_margin minus the usual margin of its bet type and phase (trailing reference) |
| `p_ref_share` | popularity | raw | H27 | -5 | [-10, 0] | log of the bet type's usual share of the market's money (trailing reference) |
| `pool_level` | popularity | encoded | H11 | 0 | [-10, 10] | shrunk log share of this pool (by phase), parent = family |
| `team_hi` | popularity | encoded | H23 | 0 | [-10, 10] |  |
| `first_half` | bet_type | flag | H11 | 0.0 |  |  |
| `extra_time` | bet_type | flag | H11 | 0.0 |  |  |
| `fh_to_ht` | lifecycle | raw | H11 | 1 | [0, 1] | first-half pool: share of FH left |
| `inplay` | lifecycle | flag | H11 | 0.0 |  |  |
| `minute` | lifecycle | raw | H11 | 0 | [0, 130] |  |
| `pre_ko_min` | lifecycle | raw | H11 | 360 | [0, 720] |  |
| `goals_so_far` | events | raw | H24 | 0 | [0, 12] |  |
| `abs_score_diff` | events | raw | H24 | 0 | [0, 10] |  |
| `goal_p10` | events | raw | H24 | 0 | [0, 5] |  |
| `red_p10` | events | raw | H24 | 0 | [0, 3] |  |
| `since_goal` | events | raw | H24 | 1 | [0, 1] |  |
| `tg_full` | competitiveness | raw | H24 | 2.6 | [0, 12] |  |
| `abs_sup` | competitiveness | raw | H24 | 0 | [0, 6] |  |
| `fav_lead` | game_state | raw | H24 | 0 | [-3, 3] | goals of the kick-off favourite minus the underdog's (0 when neither was favoured) |
| `dog_leading` | game_state | flag | H24 | 0.0 |  | the kick-off underdog is in front |
| `fav_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the favourite |
| `dog_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the underdog |
| `goal_p10_fav` | game_state | raw | H24 | 0 | [0, 5] | sum exp(-age/10) over the favourite's goals |
| `goal_p10_dog` | game_state | raw | H24 | 0 | [0, 5] | the same for the underdog's goals |
| `tg_shift` | game_state | raw | H24 | 0 | [-6, 8] | expected full-match goals now minus at kick-off: how far the game has run from script |
| `corners_so_far` | game_state | raw | H25 | 0 | [0, 30] |  |
| `corner_diff_fav` | game_state | raw | H25 | 0 | [-15, 15] | corners of the favourite minus the underdog's |
| `corner_p5` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/5) over corners |
| `yellow_p10` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/10) over yellow cards |
| `fam_goal_total` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_total_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_hdc` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_hdc_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_1x2` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_1x2_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_exact` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_exact_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_other_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_total` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_total_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_hdc` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_hdc_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_other_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_all_up` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_all_up_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_other_ip` | bet_type | flag | H11 | 0.0 |  |  |

## Selection level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `s_log_l1` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_l2` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_l3` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_ewma_fast` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_ewma_slow` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_any_l1` | memory_selection | flag | H18 | 0.0 |  |  |
| `s_any_l6` | memory_selection | flag | H18 | 0.0 |  |  |
| `s_share_pool_l1` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_pool_l2` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_pool_ewma` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_line_l1` | memory_selection | raw | H18 | 0.5 | [0, 1] |  |
| `pos_share_l1` | memory_selection | raw | H19 | 0 | [0, 1] | money in the same slot (offset from the best line, side) at T-1 / pool money T-1 |
| `pos_share_l2` | memory_selection | raw | H19 | 0 | [0, 1] |  |
| `pos_log_l1` | memory_selection | raw | H19 | 0 | [0, 20] | log1p money in the same slot at T-1, market-index units |
| `line_new` | memory_selection | flag | H19 | 0.0 |  | the line was not on the board a bucket ago; if it took nothing of its own yet, its memory is its slot's |
| `s_log_tickets_l1` | memory_selection | raw | H18 | 0 | [0, 12] |  |
| `s_rel_stake_l1` | memory_selection | raw | H18 | 0 | [-4, 4] | log of the selection's average ticket over its pool's, last bucket |
| `imp` | price | raw | H15 | 0.5 | [0, 1] | 1 / odds |
| `log_odds` | price | raw | H15 | 0.7 | [0, 7] |  |
| `value_true` | price | raw | H15 | -0.07 | [-1, 2] | odds x p(HKJC true) - 1: punter value on HKJC's own belief |
| `value_mkt` | price | raw | H15 | 0 | [-1, 2] | odds x p(market) - 1 |
| `hk_vs_mkt` | price | raw | H15 | 0 | [-0.5, 0.5] | odds / market odds - 1 |
| `has_mkt` | price | flag | H15 | 0.0 |  |  |
| `hk_vs_best` | price | raw | H26 | 0 | [-0.5, 0.5] | odds / the best bookmaker's odds - 1 (above 0: HKJC is the best price in the market) |
| `hk_pos` | price | raw | H26 | 0.5 | [0, 1] | where HKJC's odds sit between the market's worst (0) and best (1) price |
| `odds_move_5` | price | raw | H17 | 0 | [-1, 1] | log odds now - 5 min ago |
| `odds_move_15` | price | raw | H17 | 0 | [-1, 1] |  |
| `odds_vs_first` | price | raw | H26 | 0 | [-2, 2] | log odds now - its first price of the day |
| `odds_pos_60` | price | raw | H26 | 0.5 | [0, 1] | where the price sits between its lowest (0) and highest (1) of the last hour |
| `log_odds_age` | price | raw | H20 | 0 | [0, 7] | log1p minutes since price update |
| `rank_0` | line_position | flag | H14 | 0.0 |  | main line |
| `rank_1` | line_position | flag | H14 | 0.0 |  |  |
| `rank_2p` | line_position | flag | H14 | 0.0 |  |  |
| `line_offset` | line_position | raw | H14 | 0 | [-8, 8] | line - main line |
| `abs_line_offset` | line_position | raw | H14 | 0 | [0, 8] |  |
| `line_balance` | line_position | raw | H14 | 0 | [0, 1] | /pH - pA/ on this line |
| `main_moved` | line_position | flag | H19 | 0.0 |  |  |
| `line_age` | line_position | raw | H19 | 1 | [0, 1] | min(minutes priced, 600)/600 |
| `lines_pool_rel` | line_position | raw | H27 | 0 | [-4, 4] | log(lines in pool / a normal pool's lines, trailing reference) |
| `side_home_over` | bet_type | flag | H16 | 0.0 |  |  |
| `side_draw` | bet_type | flag | H16 | 0.0 |  |  |
| `is_fav` | bet_type | flag | H16 | 0.0 |  | shorter-priced side of its line |
| `side_fav_team` | bet_type | flag | H24 | 0.0 |  | handicap / 1X2 side of the kick-off favourite team |
| `first_half` | bet_type | flag | H11 | 0.0 |  |  |
| `inplay` | lifecycle | flag | H3 | 0.0 |  |  |
| `minute` | lifecycle | raw | H3 | 0 | [0, 130] |  |
| `since_goal` | events | raw | H4 | 1 | [0, 1] |  |
| `goals_so_far` | events | raw | H24 | 0 | [0, 12] |  |
| `red_p10` | events | raw | H24 | 0 | [0, 3] |  |
| `tg_full` | competitiveness | raw | H24 | 2.6 | [0, 12] |  |
| `abs_sup` | competitiveness | raw | H24 | 0 | [0, 6] |  |
| `fav_lead` | game_state | raw | H24 | 0 | [-3, 3] | goals of the kick-off favourite minus the underdog's (0 when neither was favoured) |
| `dog_leading` | game_state | flag | H24 | 0.0 |  | the kick-off underdog is in front |
| `fav_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the favourite |
| `dog_reds` | game_state | raw | H24 | 0 | [0, 3] | red cards shown to the underdog |
| `goal_p10_fav` | game_state | raw | H24 | 0 | [0, 5] | sum exp(-age/10) over the favourite's goals |
| `goal_p10_dog` | game_state | raw | H24 | 0 | [0, 5] | the same for the underdog's goals |
| `tg_shift` | game_state | raw | H24 | 0 | [-6, 8] | expected full-match goals now minus at kick-off: how far the game has run from script |
| `corners_so_far` | game_state | raw | H25 | 0 | [0, 30] |  |
| `corner_diff_fav` | game_state | raw | H25 | 0 | [-15, 15] | corners of the favourite minus the underdog's |
| `corner_p5` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/5) over corners |
| `yellow_p10` | game_state | raw | H25 | 0 | [0, 6] | sum exp(-age/10) over yellow cards |
| `fam_goal_total` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_hdc` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_1x2` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_exact` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_other` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_total` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_hdc` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_other` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_all_up` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_other` | bet_type | flag | H16 | 0.0 |  |  |
| `pool_level` | popularity | encoded | H11 | 0 | [-10, 10] |  |

Kinds: `raw` numeric (clipped to its range, missing -> fill); `basis` hinge / spline terms of a
clock; `flag` 0/1; `encoded` empirical-Bayes level of a category shrunk to its parent (an
unseen value gets its parent's level). Every value is finite by construction: missing,
infinite or out-of-range inputs become the fill or the bound, never NaN.

## Belief model inputs, by layer

`models/probability.py`, `stack:*` rows of the probability leaderboard. Each layer is a
binomial GLM fitted on settled selections with the layer below as its offset, so its
coefficients are what it adds on top.

| layer | input | what it is |
|---|---|---|
| trader | `logit_hkjc_true`, `logit_poisson`, `logit_demargin` (+ `has_*`) | HKJC's own beliefs: 1 / true odds, its TG / SUP through our pricer (score applied in play), its price de-margined |
| trader | `inplay`, `minute`, `pre_ko`, `rank_0`, `log_odds_age`, `book_margin`, `side_home_over` | when and on what the belief is quoted |
| trader | `z_x_inplay`, `z_x_abs`, `z_x_<family>` (+ `fam_<family>`) | the slope of the best HKJC logit by phase, price level (favourite-longshot) and bet type |
| market | `gap` (+ `has_market`) | logit of the bookmakers' de-margined median minus the trader layer's logit: its coefficient is how far to move toward the market |
| market | `gap_x_inplay`, `gap_x_age`, `gap_x_pre_ko`, `gap_x_<family>` | when to trust the market more: in play, when HKJC's quote is stale, near kick-off, by bet type |
| customer | `wom_l1`, `wom_l6` | weight of money: logit of a side's share of its line's money (last bucket / last 30 min, shrunk toward its price) minus logit of its price-implied share |
| customer | `rel_stake` | log of the side's average ticket over its pool's (big tickets) |
| customer | `liquidity`, `wom6_x_liquidity` | how much money the line took in the last 30 min (market-index units), and weight of money where there is money |
| customer | `odds_move_5`, `odds_move_15`, `wom6_x_inplay`, `wom1_x_inplay` | where the price has been going (steam) and weight of money in play |
