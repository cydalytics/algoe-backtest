@echo off
REM Step 2: two days only, to confirm the run works end to end.
setlocal
cd /d "%~dp0"
set "DATA=%~1"
if not defined DATA set "DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m backtest.run run --data-dir "%DATA%" --out-dir "out-smoke" ^
    --max-days 2 --optimize --optimize-every 12 --optimize-max-buckets 300
echo.
echo Open out-smoke\report.html
pause
