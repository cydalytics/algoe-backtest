@echo off
REM Algo E - run algoe-update-data.bat every day at 06:00 (or the time given), for this Windows user.
REM No admin rights: the task runs while you are logged on, so the S: drive is mapped. 06:00 is before
REM the nightly's 06:30; the nightly waits for an update that is still running anyway.
REM     algoe-schedule-update.bat           every day at 06:00
REM     algoe-schedule-update.bat 07:15     every day at 07:15
REM It shows in Task Scheduler as "AlgoE data update". Remove it with:
REM     schtasks /Delete /TN "AlgoE data update" /F
setlocal
set "AT=%~1"
if "%AT%"=="" set "AT=06:00"
schtasks /Create /F /SC DAILY /ST %AT% /TN "AlgoE data update" /TR "\"%~dp0algoe-update-data.bat\" --unattended"
if errorlevel 1 (
    echo.
    echo Windows refused the task, see above. Run algoe-update-data.bat by hand instead;
    echo start.bat also starts it when the data is older than yesterday.
    pause
    exit /b 1
)
echo.
schtasks /Query /TN "AlgoE data update" /FO LIST
echo.
echo Registered: algoe-update-data.bat runs every day at %AT% while you are logged on.
pause
