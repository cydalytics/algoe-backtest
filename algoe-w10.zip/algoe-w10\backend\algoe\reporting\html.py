"""
HTML Report

One file, no external resources: the office box has no internet, so there
is no CDN, no font download and no JavaScript library. Charts are inline SVG.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import html
from typing import Iterable, List, Optional, Sequence

CSS = """
body{font:14px/1.45 'Segoe UI',Arial,sans-serif;margin:24px 32px;color:#1c2330;background:#fafbfc}
h1{font-size:22px;margin:0 0 4px} h2{font-size:17px;margin:28px 0 8px;border-bottom:2px solid #d8dee8;padding-bottom:4px}
h3{font-size:14px;margin:16px 0 6px;color:#3a4658} .muted{color:#6b778a}
table{border-collapse:collapse;margin:6px 0 14px;background:#fff} th,td{border:1px solid #e1e6ee;padding:4px 8px;text-align:right}
th{background:#eef2f7;font-weight:600} td:first-child,th:first-child{text-align:left}
tr.hi td{background:#eaf7ee;font-weight:600} .good{color:#16813a} .bad{color:#b3261e} .warn{color:#a15c00}
.verdict{background:#fff;border-left:4px solid #3a78c2;padding:6px 12px;margin:6px 0}
.verdict.good{border-color:#16813a} .verdict.bad{border-color:#b3261e} .verdict.warn{border-color:#d08a00}
svg{background:#fff;border:1px solid #e1e6ee;margin:4px 0}
"""


def esc(x) -> str:
    return html.escape("" if x is None else str(x))


def fmt(v, kind: str = "num") -> str:
    if v is None:
        return "n/a"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return esc(v)
    if f != f:
        return "n/a"
    if kind == "pct":
        return "{:.1%}".format(f)
    if kind == "pct2":
        return "{:.2%}".format(f)
    if kind == "int":
        return "{:,.0f}".format(f)
    if kind == "p":
        return "{:.4f}".format(f)
    if abs(f) >= 1000:
        return "{:,.0f}".format(f)
    return "{:.4g}".format(f)


def table(rows: Sequence[dict], cols: Sequence[tuple], highlight=None) -> str:
    """cols: (key, header, kind)."""
    head = "".join("<th>{}</th>".format(esc(h)) for _, h, _ in cols)
    body = []
    for r in rows:
        cls = ' class="hi"' if highlight and highlight(r) else ""
        body.append("<tr{}>{}</tr>".format(cls, "".join(
            "<td>{}</td>".format(fmt(r.get(k), kind) if kind != "text" else esc(r.get(k))) for k, _, kind in cols)))
    return "<table><tr>{}</tr>{}</table>".format(head, "".join(body))


def verdict(text: str, level: str = "info") -> str:
    return '<div class="verdict {}">{}</div>'.format(esc(level), text)


def bars(items: Sequence[tuple], width: int = 640, title: str = "", kind: str = "num") -> str:
    """Horizontal bars: (label, value). Negative values drawn to the left of zero."""
    items = [(str(a), float(b)) for a, b in items if b is not None and b == b]
    if not items:
        return ""
    h = 22 * len(items) + 30
    lo, hi = min(0.0, min(v for _, v in items)), max(0.0, max(v for _, v in items))
    span = (hi - lo) or 1.0
    x0 = 200 + (0 - lo) / span * (width - 290)
    out = ['<svg width="{}" height="{}"><text x="8" y="16" font-size="12" fill="#3a4658">{}</text>'.format(
        width, h, esc(title))]
    for i, (lab, v) in enumerate(items):
        y = 26 + i * 22
        x = 200 + (min(v, 0) - lo) / span * (width - 290)
        w = abs(v) / span * (width - 290)
        col = "#16813a" if v >= 0 else "#b3261e"
        out.append('<text x="8" y="{}" font-size="12">{}</text>'.format(y + 12, esc(lab[:30])))
        out.append('<rect x="{:.1f}" y="{}" width="{:.1f}" height="14" fill="{}" opacity="0.8"/>'.format(x, y, max(w, 1), col))
        out.append('<text x="{:.1f}" y="{}" font-size="11">{}</text>'.format(x + max(w, 1) + 4, y + 12, fmt(v, kind)))
    out.append('<line x1="{0:.1f}" y1="22" x2="{0:.1f}" y2="{1}" stroke="#888"/></svg>'.format(x0, h - 4))
    return "".join(out)


def reliability(curves: dict, size: int = 300, title: str = "Calibration") -> str:
    """Predicted (x) vs realised (y) per method; the diagonal is perfect calibration."""
    colors = ["#3a78c2", "#d08a00", "#16813a", "#8e44ad", "#b3261e"]
    pad = 36
    out = ['<svg width="{0}" height="{0}"><text x="8" y="16" font-size="12">{1}</text>'.format(size + pad, esc(title)),
           '<line x1="{0}" y1="{1}" x2="{1}" y2="{0}" stroke="#bbb" stroke-dasharray="4"/>'.format(pad, size)]
    for i, (name, bins) in enumerate(curves.items()):
        if not bins:
            continue
        pts = " ".join("{:.1f},{:.1f}".format(pad + b["p_mean"] * (size - pad), size - b["y_mean"] * (size - pad))
                       for b in bins)
        c = colors[i % len(colors)]
        out.append('<polyline points="{}" fill="none" stroke="{}" stroke-width="2"/>'.format(pts, c))
        out.append('<text x="{}" y="{}" font-size="11" fill="{}">{}</text>'.format(pad + 4, 30 + 14 * i, c, esc(name)))
    out.append("</svg>")
    return "".join(out)


def page(title: str, subtitle: str, sections: Iterable[str]) -> str:
    return ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>{t}</title><style>{c}</style></head>"
            "<body><h1>{t}</h1><div class='muted'>{s}</div>{b}</body></html>").format(
        t=esc(title), s=esc(subtitle), c=CSS, b="".join(sections))
