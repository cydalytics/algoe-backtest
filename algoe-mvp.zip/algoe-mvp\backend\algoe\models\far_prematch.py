"""
Far pre-match turnover

The turnover models learned the last panel.prematch_window_min (6 h) before kick-off. A match is on sale
long before that, so the live engine forecasts those buckets here, one match at a time:

    F_match   = Z x own + (1 - Z) x anchor(league) x g(h)
    own       the match's money over the last ``window_minutes`` (60), per bucket
    Z         tickets / (tickets + k): one big ticket is not a rate
    anchor    the league's typical money per bucket in the hour before the model window (6-7 h out)
    g(h)      money per bucket h hours before kick-off over money at that edge (g = 1 at 6 h)

The match total is split across its selections by the day's own money (credibility-weighted by the
match's tickets today) and, for the rest, a prior: each bet-type family's share of pre-match money (the
panel's trailing references, or FAMILY_PRIOR), within a pool by implied probability with the main line
weighted up.

``fit-far-prematch`` fits g, the league anchors and k on Match_Investments (FAR_PREMATCH.json beside the
turnover models) and scores the fit on held-out days against last 5 minutes. Without that file a default
curve serves - g = 6 h / h, no anchor, so a far match is forecast from its own money alone - and the desk
says so.

Change Log:
-----------
2026-11-19      Initialize
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger

logger = get_logger(__name__)

KNOTS_HOURS = (6.0, 8.0, 12.0, 18.0, 24.0, 36.0, 48.0, 72.0, 96.0, 120.0, 168.0)
# pre-match money by bet-type family, for a match with no money of its own and no panel references
FAMILY_PRIOR = {"goal_1x2": 0.30, "goal_total": 0.25, "goal_hdc": 0.22, "corner_total": 0.08, "corner_hdc": 0.04,
                "goal_other": 0.05, "goal_exact": 0.03, "corner_other": 0.01, "other": 0.01, "all_up": 0.01}
MAIN_LINE_WEIGHT = 3.0
SHARE_TICKETS_K = 20.0


@dataclass
class FarCurve:
    edge_minutes: float = 360.0
    window_minutes: float = 60.0
    bucket_minutes: float = 5.0
    hours: List[float] = field(default_factory=lambda: list(KNOTS_HOURS))
    ratio: List[float] = field(default_factory=lambda: [KNOTS_HOURS[0] / h for h in KNOTS_HOURS])
    anchors: Dict[str, float] = field(default_factory=dict)
    anchor_default: float = 0.0
    k: float = 3.0
    source: str = "default"
    fitted: Optional[str] = None
    metrics: Dict[str, float] = field(default_factory=dict)

    # ------------------------------------------------------------ curve
    def g(self, hours) -> np.ndarray:
        h = np.asarray(hours, dtype="float64")
        return np.interp(h, self.hours, self.ratio, left=self.ratio[0], right=self.ratio[-1])

    def anchor(self, league) -> float:
        if league is not None and str(league) in self.anchors:
            return float(self.anchors[str(league)])
        return float(self.anchor_default)

    def match_total(self, hours: float, league, money: float, tickets: float) -> float:
        """Expected money for the next bucket of one match ``hours`` before kick-off, from its last
        window_minutes of ``money`` and ``tickets``."""
        own = max(float(money), 0.0) * self.bucket_minutes / max(self.window_minutes, 1e-9)
        prior = self.anchor(league) * float(self.g(hours))
        if prior <= 0:
            return own
        t = max(float(tickets), 0.0)
        z = t / (t + self.k) if self.k > 0 else float(t > 0)
        return z * own + (1.0 - z) * prior

    # ------------------------------------------------------------ files
    @staticmethod
    def default_path(settings) -> Path:
        return Path(settings.paths.models) / "turnover" / "FAR_PREMATCH.json"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "FarCurve":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in payload.items() if k in known})

    def save(self, path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        os.replace(tmp, path)
        return path

    @classmethod
    def load(cls, path) -> Optional["FarCurve"]:
        try:
            return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
        except (OSError, ValueError, TypeError) as exc:
            if Path(path).exists():
                logger.warning("far pre-match curve %s unreadable (%s); the default curve serves", path, exc)
            return None


# ================================================================ serving
def window_money(investments: Optional[pd.DataFrame], match_ids: Iterable[int], as_of,
                 minutes: float) -> Dict[int, tuple]:
    """{match: (money, tickets)} over [as_of - minutes, as_of) from canonical live money rows."""
    out = {int(m): (0.0, 0.0) for m in match_ids}
    if investments is None or investments.empty or not out:
        return out
    t = pd.to_datetime(investments["start_sell_time"], errors="coerce")
    as_of = pd.Timestamp(as_of)
    inv = investments[(t >= as_of - pd.Timedelta(minutes=float(minutes))) & (t < as_of)]
    if inv.empty:
        return out
    mid = pd.to_numeric(inv["match_id"], errors="coerce")
    inv = inv[mid.isin(list(out))]
    if inv.empty:
        return out
    tickets = inv["tickets"] if "tickets" in inv.columns else (
        inv["ticket_count"] if "ticket_count" in inv.columns else pd.Series(0.0, index=inv.index))
    g = pd.DataFrame({"m": pd.to_numeric(inv["match_id"], errors="coerce").astype("int64"),
                      "y": pd.to_numeric(inv["turnover"], errors="coerce").fillna(0.0),
                      "t": pd.to_numeric(tickets, errors="coerce").fillna(0.0)}).groupby("m")[["y", "t"]].sum()
    for m, row in g.iterrows():
        out[int(m)] = (float(row["y"]), float(row["t"]))
    return out


def far_shares(rows: pd.DataFrame, today_money: np.ndarray, match_tickets: Dict[int, float],
               references: Optional[dict] = None) -> np.ndarray:
    """Each row's share of its match's money: the day's own split, credibility-weighted by the match's
    tickets today, the rest by the family / implied-probability prior. Sums to 1 within each match."""
    n = len(rows)
    if n == 0:
        return np.zeros(0)
    mids = pd.to_numeric(rows["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()
    odds = pd.to_numeric(rows["odds"], errors="coerce").to_numpy(dtype="float64")
    imp = np.where(np.isfinite(odds) & (odds > 1.0), 1.0 / np.where(odds > 1.0, odds, 2.0), 0.0)
    main = pd.to_numeric(rows.get("rank_0", pd.Series(0.0, index=rows.index)), errors="coerce").fillna(0.0) \
        .to_numpy(dtype="float64") > 0
    w = imp * np.where(main, MAIN_LINE_WEIGHT, 1.0)
    fam = rows["family"].astype("string").fillna("other").to_numpy(dtype=object) if "family" in rows.columns \
        else np.full(n, "other", dtype=object)
    pool = pd.to_numeric(rows["pool_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()
    ref = (references or {}).get("share") or {}
    fam_w = np.array([float(ref.get("{}|prematch".format(f), FAMILY_PRIOR.get(str(f), 0.01))) for f in fam])
    frame = pd.DataFrame({"m": mids, "p": pool, "f": fam, "w": w, "fw": fam_w})
    in_pool = frame.groupby(["m", "p"])["w"].transform("sum").to_numpy(dtype="float64")
    pools_of_fam = frame.groupby(["m", "f"])["p"].transform("nunique").to_numpy(dtype="float64")
    prior = np.where(in_pool > 0, w / np.maximum(in_pool, 1e-12), 0.0) * frame["fw"].to_numpy() / \
        np.maximum(pools_of_fam, 1.0)
    prior_tot = pd.Series(prior).groupby(mids).transform("sum").to_numpy(dtype="float64")
    prior = np.where(prior_tot > 0, prior / np.maximum(prior_tot, 1e-12), 1.0 / np.maximum(
        pd.Series(np.ones(n)).groupby(mids).transform("sum").to_numpy(dtype="float64"), 1.0))
    own = np.clip(np.nan_to_num(np.asarray(today_money, dtype="float64")), 0, None)
    own_tot = pd.Series(own).groupby(mids).transform("sum").to_numpy(dtype="float64")
    own_share = np.where(own_tot > 0, own / np.maximum(own_tot, 1e-12), 0.0)
    t = np.array([float(match_tickets.get(int(m), 0.0)) for m in mids])
    z = np.where(own_tot > 0, t / (t + SHARE_TICKETS_K), 0.0)
    return z * own_share + (1.0 - z) * prior


def far_forecast(curve: FarCurve, rows: pd.DataFrame, today_money: np.ndarray, match_tickets: Dict[int, float],
                 money: Dict[int, tuple], references: Optional[dict] = None) -> np.ndarray:
    """Next-bucket money per far row: its match's total (curve) times its share."""
    if rows.empty:
        return np.zeros(0)
    mids = pd.to_numeric(rows["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()
    mins = pd.to_numeric(rows["mins_to_ko"], errors="coerce").to_numpy(dtype="float64")
    league = rows["league_code"].astype("string").to_numpy(dtype=object) if "league_code" in rows.columns \
        else np.full(len(rows), None, dtype=object)
    totals: Dict[int, float] = {}
    for m in np.unique(mids):
        i = int(np.flatnonzero(mids == m)[0])
        hours = mins[i] / 60.0 if np.isfinite(mins[i]) else curve.edge_minutes / 60.0
        y, t = money.get(int(m), (0.0, 0.0))
        totals[int(m)] = curve.match_total(max(hours, curve.edge_minutes / 60.0), league[i], y, t)
    share = far_shares(rows, today_money, match_tickets, references)
    return share * np.array([totals[int(m)] for m in mids])


# ================================================================ fitting
_DAY_FILE = re.compile(r"^match_investments_(\d{4}-\d{2}-\d{2})_\d{4}-\d{2}-\d{2}\.parquet$")
_HISTORY_COLS = ("match_id", "start_sell_time", "turnover", "ticket_count", "kickoff_date")


def read_history(data_dir, days: int = 42, end=None, skip: Iterable = ()) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """The last ``days`` Match_Investments day files up to ``end`` (money and tickets per match and minute)
    and each match's kick-off and league (Match_Information, else the pools' kick-off). ``skip``: days whose
    file is known to be incomplete."""
    from src.backtest.parquet import loader as L
    data_dir = Path(data_dir)
    skip = {pd.Timestamp(d).normalize() for d in skip}
    dated = []
    for path in L.files_for(data_dir, "investments"):
        m = _DAY_FILE.match(path.name)
        if m:
            day = pd.Timestamp(m.group(1))
            if (end is None or day <= pd.Timestamp(end)) and day not in skip:
                dated.append((day, path))
    dated = sorted(dated)[-int(days):] if days else sorted(dated)
    parts = []
    for _, path in dated:
        ren = {raw: canon for raw, canon in L._resolve("investments", L._schema_names(path)).items()
               if canon in _HISTORY_COLS}
        f = L.normalise("investments", pd.read_parquet(path, columns=list(ren)).rename(columns=ren))
        if f.empty or "start_sell_time" not in f.columns:
            continue
        if "ticket_count" not in f.columns:
            f["ticket_count"] = 0
        f["start_sell_time"] = pd.to_datetime(f["start_sell_time"], errors="coerce").dt.floor("min")
        f["ticket_count"] = pd.to_numeric(f["ticket_count"], errors="coerce").fillna(0).astype("float64")
        agg = {"turnover": ("turnover", "sum"), "ticket_count": ("ticket_count", "sum")}
        if "kickoff_date" in f.columns:
            agg["kickoff_date"] = ("kickoff_date", "min")
        parts.append(f.groupby(["match_id", "start_sell_time"], as_index=False).agg(**agg))
    if not parts:
        return pd.DataFrame(columns=["match_id", "start_sell_time", "turnover", "ticket_count"]), \
            pd.DataFrame(columns=["match_id", "ko_time", "league_code"])
    inv = pd.concat(parts, ignore_index=True)
    agg = {"turnover": ("turnover", "sum"), "ticket_count": ("ticket_count", "sum")}
    if "kickoff_date" in inv.columns:
        agg["kickoff_date"] = ("kickoff_date", "min")
    inv = inv.groupby(["match_id", "start_sell_time"], as_index=False).agg(**agg)
    ko = pd.DataFrame({"match_id": inv["match_id"].unique()})
    if "kickoff_date" in inv.columns:
        ko = ko.merge(inv.groupby("match_id", as_index=False)["kickoff_date"].min()
                      .rename(columns={"kickoff_date": "ko_time"}), on="match_id", how="left")
    info = []
    for path in L.files_for(data_dir, "matches"):
        ren = {raw: canon for raw, canon in L._resolve("matches", L._schema_names(path)).items()
               if canon in ("match_id", "ko_time", "league_code")}
        if "match_id" in ren.values():
            info.append(L.normalise("matches", pd.read_parquet(path, columns=list(ren)).rename(columns=ren)))
    if info:
        mi = pd.concat(info, ignore_index=True).drop_duplicates("match_id", keep="last")
        ko = ko.merge(mi, on="match_id", how="left", suffixes=("_pools", ""))
        if "ko_time_pools" in ko.columns:
            ko["ko_time"] = ko["ko_time"].fillna(ko.pop("ko_time_pools")) if "ko_time" in ko.columns \
                else ko.pop("ko_time_pools")
    return inv.drop(columns=[c for c in ("kickoff_date",) if c in inv.columns]), ko


def match_buckets(investments: pd.DataFrame, kickoffs: pd.DataFrame, bucket_minutes: float = 5.0) -> pd.DataFrame:
    """Money and tickets per match and bucket with the bucket's minutes to kick-off (pre-match only).
    ``investments``: match_id, start_sell_time, turnover[, ticket_count]; ``kickoffs``: match_id, ko_time
    [, league_code]."""
    inv = investments.copy()
    inv["match_id"] = pd.to_numeric(inv["match_id"], errors="coerce")
    inv = inv.dropna(subset=["match_id"])
    inv["match_id"] = inv["match_id"].astype("int64")
    inv["t"] = pd.to_datetime(inv["start_sell_time"], errors="coerce")
    inv["y"] = pd.to_numeric(inv["turnover"], errors="coerce").fillna(0.0)
    tk = inv["ticket_count"] if "ticket_count" in inv.columns else inv.get("tickets", pd.Series(0.0, index=inv.index))
    inv["k"] = pd.to_numeric(tk, errors="coerce").fillna(0.0)
    inv["bucket"] = inv["t"].dt.floor("{}min".format(int(bucket_minutes)))
    b = inv.groupby(["match_id", "bucket"], as_index=False)[["y", "k"]].sum()
    ko = kickoffs.copy()
    ko["match_id"] = pd.to_numeric(ko["match_id"], errors="coerce")
    ko = ko.dropna(subset=["match_id"]).drop_duplicates("match_id")
    ko["match_id"] = ko["match_id"].astype("int64")
    ko["ko_time"] = pd.to_datetime(ko["ko_time"], errors="coerce")
    cols = ["match_id", "ko_time"] + (["league_code"] if "league_code" in ko.columns else [])
    b = b.merge(ko[cols], on="match_id", how="inner")
    b["mins_to_ko"] = (b["ko_time"] - b["bucket"]).dt.total_seconds() / 60.0
    return b[b["mins_to_ko"] > 0].reset_index(drop=True)


def _anchor_per_match(b: pd.DataFrame, edge: float, bucket_minutes: float) -> pd.Series:
    """Money per bucket in the hour before the model window (edge .. edge + 60 min before kick-off)."""
    near = b[(b["mins_to_ko"] > edge) & (b["mins_to_ko"] <= edge + 60.0)]
    per = near.groupby("match_id")["y"].sum() / (60.0 / bucket_minutes)
    return per.reindex(b["match_id"].unique()).fillna(0.0)


def fit_far_curve(investments: pd.DataFrame, kickoffs: pd.DataFrame, edge_minutes: float = 360.0,
                  window_minutes: float = 60.0, bucket_minutes: float = 5.0, holdout_days: int = 7,
                  knots: Iterable[float] = KNOTS_HOURS, league_prior: float = 5.0,
                  k_grid: Iterable[float] = (0.5, 1.0, 2.0, 3.0, 5.0, 10.0, 20.0, 50.0)) -> FarCurve:
    """g, the league anchors and the credibility k from history before the last ``holdout_days`` days of
    kick-offs; those days only score it (match WAPE on far buckets) against last 5 minutes."""
    b = match_buckets(investments, kickoffs, bucket_minutes)
    if b.empty:
        raise ValueError("no pre-match money with a kick-off time to fit on")
    days = b["ko_time"].dt.normalize()
    cut = days.max() - pd.Timedelta(days=int(holdout_days) - 1) if holdout_days > 0 else days.max() + pd.Timedelta(days=1)
    fit, test = b[days < cut], b[days >= cut]
    if fit.empty:
        fit, test = b, b.iloc[0:0]
    knots = sorted(float(k) for k in knots)
    anchor = _anchor_per_match(fit, edge_minutes, bucket_minutes)
    fit = fit.assign(_a=fit["match_id"].map(anchor).fillna(0.0).to_numpy())
    # every bucket of a match counts, money or not: the denominators below need the zero buckets too
    grid = _full_grid(fit, edge_minutes, bucket_minutes)
    grid = grid.assign(_a=grid["match_id"].map(anchor).fillna(0.0).to_numpy(), _h=grid["mins_to_ko"] / 60.0)
    ratio = []
    for i, h in enumerate(knots):
        lo = (knots[i - 1] + h) / 2.0 if i > 0 else h
        hi = (h + knots[i + 1]) / 2.0 if i + 1 < len(knots) else h * 1.5
        cell = grid[(grid["_h"] >= lo) & (grid["_h"] < hi)]
        den = float(cell["_a"].sum())
        ratio.append(float(cell["y"].sum()) / den if den > 0 else np.nan)
    ratio = _fill_ratio(np.array(ratio, dtype="float64"), knots)
    ratio[0] = 1.0
    leagues = {}
    if "league_code" in fit.columns:
        per = fit.drop_duplicates("match_id").assign(_a=lambda f: f["match_id"].map(anchor))
        glob = float(per["_a"].median()) if len(per) else 0.0
        for lg, grp in per.groupby("league_code"):
            n = len(grp)
            leagues[str(lg)] = float((n * grp["_a"].median() + league_prior * glob) / (n + league_prior))
    else:
        glob = float(anchor.median()) if len(anchor) else 0.0
    curve = FarCurve(edge_minutes=edge_minutes, window_minutes=window_minutes, bucket_minutes=bucket_minutes,
                     hours=knots, ratio=[float(r) for r in ratio], anchors=leagues, anchor_default=glob,
                     source="fitted", fitted=str(pd.Timestamp.now().floor("s")))
    # k is chosen on the fit window, so the held-out score (and fit-far-prematch's save gate on it) is honest
    on_fit = _score_inputs(curve, fit, bucket_minutes)
    best_k, best = curve.k, None
    for k in k_grid:
        dev = _metrics(on_fit, _blend(on_fit, float(k)))["deviance"]
        if np.isfinite(dev) and (best is None or dev < best):
            best_k, best = float(k), dev
    curve.k = best_k
    on_test = _score_inputs(curve, test, bucket_minutes) if not test.empty else on_fit
    curve.metrics = _metrics(on_test, _blend(on_test, curve.k))
    curve.metrics.update(fit_matches=int(fit["match_id"].nunique()), test_matches=int(test["match_id"].nunique()),
                         holdout_days=int(holdout_days), scored_on="holdout" if not test.empty else "fit")
    return curve


def _full_grid(b: pd.DataFrame, edge: float, bucket_minutes: float, max_hours: float = 252.0) -> pd.DataFrame:
    """Every far bucket of every match from its first money to the model window, money or not."""
    far = b[(b["mins_to_ko"] > edge) & (b["mins_to_ko"] <= max_hours * 60.0)]
    if far.empty:
        return far.assign(y=pd.Series(dtype="float64"))
    step = pd.Timedelta(minutes=int(bucket_minutes))
    parts = []
    for m, g in far.groupby("match_id"):
        ko = g["ko_time"].iloc[0]
        start, end = g["bucket"].min(), ko - pd.Timedelta(minutes=edge) - step
        if end < start:
            continue
        idx = pd.date_range(start, end, freq=step)
        y = g.set_index("bucket")["y"].reindex(idx).fillna(0.0).to_numpy()
        parts.append(pd.DataFrame({"match_id": m, "bucket": idx, "y": y,
                                   "mins_to_ko": (ko - idx).total_seconds() / 60.0}))
    return pd.concat(parts, ignore_index=True) if parts else far.iloc[0:0]


def _fill_ratio(r: np.ndarray, knots: List[float]) -> np.ndarray:
    """Knots without data take their neighbours' value; nothing at all leaves the default 6 h / h."""
    ok = np.isfinite(r) & (r >= 0)
    if not ok.any():
        return np.array([knots[0] / h for h in knots])
    return np.interp(np.arange(len(r)), np.flatnonzero(ok), r[ok])


def _score(curve: FarCurve, b: pd.DataFrame, bucket_minutes: float) -> dict:
    """Match WAPE and Poisson deviance on far buckets: the curve's forecast from the previous hour against
    last 5 minutes (the previous bucket)."""
    a = _score_inputs(curve, b, bucket_minutes)
    return _metrics(a, _blend(a, curve.k))


def _score_inputs(curve: FarCurve, b: pd.DataFrame, bucket_minutes: float) -> np.ndarray:
    """Per far bucket: actual, last 5 minutes, the match's own rate from the previous hour, the curve's prior
    (anchor x g) and the hour's tickets - everything but the credibility k, so k is a vector blend."""
    edge = curve.edge_minutes
    rows = []
    step = pd.Timedelta(minutes=int(bucket_minutes))
    win = int(round(curve.window_minutes / bucket_minutes))
    per = curve.bucket_minutes / max(curve.window_minutes, 1e-9)
    for m, g in b.groupby("match_id"):
        g = g.sort_values("bucket")
        ko = g["ko_time"].iloc[0]
        lg = g["league_code"].iloc[0] if "league_code" in g.columns else None
        far = g[g["mins_to_ko"] > edge]
        if far.empty:
            continue
        idx = pd.date_range(far["bucket"].min(), ko - pd.Timedelta(minutes=edge) - step, freq=step)
        if len(idx) < 2:
            continue
        y = g.set_index("bucket")["y"].reindex(idx).fillna(0.0).to_numpy()
        k = g.set_index("bucket")["k"].reindex(idx).fillna(0.0).to_numpy()
        cy, ck = np.concatenate([[0.0], np.cumsum(y)]), np.concatenate([[0.0], np.cumsum(k)])
        j = np.arange(1, len(idx))
        lo = np.maximum(0, j - win)
        money, tickets = cy[j] - cy[lo], ck[j] - ck[lo]
        own = np.maximum(money * win / np.maximum(j - lo, 1), 0.0) * per
        hours = (ko - idx[j]).total_seconds().to_numpy() / 3600.0
        prior = curve.anchor(lg) * curve.g(hours)
        rows.append(np.column_stack([y[j], y[j - 1], own, prior, np.maximum(tickets, 0.0)]))
    return np.vstack(rows) if rows else np.zeros((0, 5))


def _blend(a: np.ndarray, k: float) -> np.ndarray:
    """FarCurve.match_total on every row of _score_inputs at credibility k."""
    own, prior, t = a[:, 2], a[:, 3], a[:, 4]
    z = t / (t + k) if k > 0 else (t > 0).astype("float64")
    return np.where(prior > 0, z * own + (1.0 - z) * prior, own)


def _metrics(a: np.ndarray, f: np.ndarray) -> dict:
    if not len(a):
        return {"buckets": 0, "wape": float("nan"), "wape_last5": float("nan"), "deviance": float("nan")}
    y, last5 = a[:, 0], a[:, 1]
    tot = max(float(y.sum()), 1e-9)
    mu = np.maximum(f, 1.0)
    dev = float(np.mean(2 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))))
    return {"buckets": int(len(y)), "wape": float(np.abs(f - y).sum() / tot),
            "wape_last5": float(np.abs(last5 - y).sum() / tot), "deviance": dev}
