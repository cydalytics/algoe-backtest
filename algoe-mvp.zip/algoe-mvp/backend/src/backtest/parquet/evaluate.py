"""Streaming evaluation of the panel.

Every statistic is stored as an additive sum keyed by (subset, model, slice), so
a day of facts can be folded in and thrown away. Nothing needs the whole panel
in memory at once; only the scatter/histogram samples are capped.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List

import numpy as np
import pandas as pd

TURNOVER_MODELS = {
    "persist": "f_persist",     # the assumption under test: next 5min = last 5min
    "ma3": "f_ma3",
    "ema": "f_ema",
    "zero": "f_zero",
}
BELIEF_MODELS = {
    "p_true": "p_true",         # the assumption under test: 1 / true odds
    "p_sell": "p_sell_norm",    # public odds, normalised - the thing to beat
}
SLICE_DIMS = ["pool_name", "clock_bin", "odds_bin", "league_code", "p_source"]
CAL_BINS = np.linspace(0.0, 1.0, 21)
BOOK_BINS = np.linspace(0.90, 1.20, 31)
EPS = 1e-6


class Accumulator:
    def __init__(self, sample_rows: int = 6000, seed: int = 7):
        self.rng = np.random.default_rng(seed)
        self.sample_rows = sample_rows
        self.turnover: Dict[tuple, np.ndarray] = defaultdict(lambda: np.zeros(6))
        self.slices: Dict[tuple, np.ndarray] = defaultdict(lambda: np.zeros(6))
        self.belief: Dict[tuple, np.ndarray] = defaultdict(lambda: np.zeros(8))
        self.cal: Dict[tuple, np.ndarray] = defaultdict(lambda: np.zeros(5))
        self.gm: Dict[tuple, np.ndarray] = defaultdict(lambda: np.zeros(6))
        self.book_hist = np.zeros(len(BOOK_BINS) - 1)
        self.resid: Dict[str, np.ndarray] = defaultdict(
            lambda: np.zeros(len(RESID_BINS) - 1))
        self.daily: List[dict] = []
        self.bucket_level: Dict[str, np.ndarray] = defaultdict(lambda: np.zeros(4))
        self.scatter: List[pd.DataFrame] = []
        self.cal_scatter: List[pd.DataFrame] = []
        self.coverage = {
            "rows": 0, "days": 0, "matches": set(), "pools": set(),
            "turnover": 0.0, "money_rows": 0, "settled_rows": 0,
            # every bucket of one selection shares a single outcome, so the
            # independent sample size for calibration is the selection count
            "settled_keys": set(),
        }

    # ------------------------------------------------------------------ fold
    def update(self, day: pd.Timestamp, f: pd.DataFrame) -> None:
        if f is None or f.empty:
            return
        self.coverage["rows"] += len(f)
        self.coverage["days"] += 1
        self.coverage["matches"].update(f["match_id"].dropna().unique().tolist())
        self.coverage["pools"].update(f["pool_name"].dropna().unique().tolist())
        self.coverage["turnover"] += float(f["turnover"].sum())
        self.coverage["money_rows"] += int((f["turnover"] > 0).sum())

        f = f.copy()
        f["p_sell_norm"] = np.where(f["sell_book_sum"] > 0,
                                    f["p_sell"] / f["sell_book_sum"], np.nan)
        subsets = {
            "all": pd.Series(True, index=f.index),
            "active": (f["turnover"] > 0) | (f["lag1"] > 0),
            "money": f["turnover"] > 0,
        }
        y = f["turnover"].to_numpy(dtype="float64")

        for sname, mask in subsets.items():
            m = mask.to_numpy()
            if not m.any():
                continue
            yy = y[m]
            for model, col in TURNOVER_MODELS.items():
                ff = f[col].to_numpy(dtype="float64")[m]
                self.turnover[(sname, model)] += _err_stats(yy, ff)
            if sname == "active":
                for dim in SLICE_DIMS:
                    if dim not in f.columns:
                        continue
                    labels = f[dim].astype("string").fillna("unknown").to_numpy()[m]
                    for model, col in TURNOVER_MODELS.items():
                        if model not in ("persist", "ema"):
                            continue
                        ff = f[col].to_numpy(dtype="float64")[m]
                        for lab, st in _grouped_err(labels, yy, ff).items():
                            self.slices[(dim, lab, model)] += st

        # residual histogram + scatter sample, on the active subset
        act = subsets["active"].to_numpy()
        if act.any():
            for model, col in TURNOVER_MODELS.items():
                if model == "zero":
                    continue
                e = f[col].to_numpy(dtype="float64")[act] - y[act]
                self.resid[model] += np.histogram(e, bins=RESID_BINS)[0]
            self._sample(f.loc[act, ["turnover", "f_persist", "f_ema", "pool_name",
                                     "clock_bin", "bucket"]], self.scatter)

        # ---- belief -------------------------------------------------------
        ok = f["settled"].fillna(False).to_numpy() & f["y_frac"].notna().to_numpy()
        if ok.any():
            self.coverage["settled_rows"] += int(ok.sum())
            sk = f.loc[ok, ["pool_id", "line_id", "combination_id"]].astype("int64")
            self.coverage["settled_keys"].update(
                (sk["pool_id"] * 1_000_000 + sk["line_id"] * 1_000
                 + sk["combination_id"]).unique().tolist())
            yf = f["y_frac"].to_numpy(dtype="float64")[ok]
            w = np.maximum(y[ok], 0.0)
            for model, col in BELIEF_MODELS.items():
                p = f[col].to_numpy(dtype="float64")[ok]
                good = np.isfinite(p) & (p > 0) & (p < 1)
                if not good.any():
                    continue
                self.belief[("all", model)] += _belief_stats(p[good], yf[good], w[good])
                idx = np.digitize(p[good], CAL_BINS) - 1
                idx = np.clip(idx, 0, len(CAL_BINS) - 2)
                for b in np.unique(idx):
                    s = idx == b
                    self.cal[(model, int(b))] += np.array([
                        s.sum(), p[good][s].sum(), yf[good][s].sum(),
                        w[good][s].sum(), (w[good][s] * yf[good][s]).sum()])
            self._sample(f.loc[ok, ["p_true", "p_sell_norm", "y_frac", "turnover",
                                    "pool_name", "clock_bin"]], self.cal_scatter)

        bs = f["book_sum"].to_numpy(dtype="float64")
        bs = bs[np.isfinite(bs)]
        if bs.size:
            self.book_hist += np.histogram(bs, bins=BOOK_BINS)[0]

        # ---- GM -----------------------------------------------------------
        gm_ok = f["turnover"] > 0
        if gm_ok.any():
            g = f[gm_ok]
            self.gm[("overall", "all")] += _gm_stats(g)
            for dim in ("pool_name", "clock_bin", "odds_bin"):
                if dim not in g.columns:
                    continue
                for lab, sub in g.groupby(g[dim].astype("string").fillna("unknown"),
                                          observed=True):
                    self.gm[(dim, str(lab))] += _gm_stats(sub)

        # ---- bucket-level totals (what the optimiser really needs) --------
        tot = f.groupby("bucket", observed=True).agg(
            y=("turnover", "sum"), p=("f_persist", "sum"), e=("f_ema", "sum"))
        for model, col in (("persist", "p"), ("ema", "e")):
            self.bucket_level[model] += np.array([
                len(tot), float(np.abs(tot[col] - tot["y"]).sum()),
                float(tot["y"].sum()), float(tot[col].sum())])

        # ---- daily series -------------------------------------------------
        self.daily.append({
            "day": str(pd.Timestamp(day).date()),
            "rows": int(len(f)),
            "matches": int(f["match_id"].nunique()),
            "turnover": float(f["turnover"].sum()),
            "forecast_persist": float(f["f_persist"].sum()),
            "realized_gm": float(f["realized_gm"].sum()),
            "expected_gm": float(f["expected_gm"].sum()),
            "settled_turnover": float(f.loc[ok, "turnover"].sum()) if ok.any() else 0.0,
        })

    def _sample(self, df: pd.DataFrame, store: List[pd.DataFrame]) -> None:
        have = sum(len(d) for d in store)
        if have >= self.sample_rows or df.empty:
            return
        take = min(len(df), self.sample_rows - have)
        if take < len(df):
            df = df.iloc[self.rng.choice(len(df), take, replace=False)]
        store.append(df.copy())

    # -------------------------------------------------------------- finalize
    def finalize(self) -> dict:
        out: dict = {}
        cov = dict(self.coverage)
        cov["matches"] = len(self.coverage["matches"])
        cov["pools"] = sorted(self.coverage["pools"])
        cov["settled_selections"] = len(self.coverage.pop("settled_keys"))
        out["coverage"] = cov

        out["turnover"] = {
            "models": {f"{s}|{m}": _err_report(v) for (s, m), v in self.turnover.items()},
            "by_slice": [dict(dim=d, value=l, model=m, **_err_report(v))
                         for (d, l, m), v in sorted(self.slices.items())],
            "resid_hist": {m: {"edges": RESID_BINS.tolist(), "counts": v.tolist()}
                           for m, v in self.resid.items()},
            "bucket_level": {m: {"n": int(v[0]),
                                 "mae": _safe(v[1], v[0]),
                                 "wape": _safe(v[1], v[2]),
                                 "bias_pct": _safe(v[3] - v[2], v[2])}
                             for m, v in self.bucket_level.items()},
            "scatter": _pack(self.scatter),
        }
        out["belief"] = {
            "models": {m: _belief_report(v) for (_, m), v in self.belief.items()},
            "calibration": _cal_report(self.cal),
            "book_sum_hist": {"edges": BOOK_BINS.tolist(), "counts": self.book_hist.tolist()},
            "scatter": _pack(self.cal_scatter),
        }
        out["gm"] = {
            "overall": _gm_report(self.gm.get(("overall", "all"), np.zeros(6))),
            "by_slice": [dict(dim=d, value=l, **_gm_report(v))
                         for (d, l), v in sorted(self.gm.items()) if d != "overall"],
        }
        out["daily"] = self.daily
        out["verdict"] = _verdict(out)
        return out


RESID_BINS = np.concatenate([
    -np.geomspace(1e6, 1.0, 25), [0.0], np.geomspace(1.0, 1e6, 25)])


# ------------------------------------------------------------------ statistics
def _err_stats(y: np.ndarray, f: np.ndarray) -> np.ndarray:
    e = f - y
    return np.array([len(y), np.abs(e).sum(), e.sum(), (e ** 2).sum(),
                     y.sum(), f.sum()])


def _grouped_err(labels, y, f) -> Dict[str, np.ndarray]:
    out = {}
    for lab in pd.unique(labels):
        m = labels == lab
        out[str(lab)] = _err_stats(y[m], f[m])
    return out


def _err_report(v: np.ndarray) -> dict:
    n, sae, se, sse, sy, sf = v
    return {
        "n": int(n),
        "mae": _safe(sae, n),
        "rmse": float(np.sqrt(sse / n)) if n else None,
        "wape": _safe(sae, sy),
        "bias": _safe(se, n),
        "bias_pct": _safe(sf - sy, sy),
        "sum_actual": float(sy),
        "sum_forecast": float(sf),
    }


def _belief_stats(p, y, w) -> np.ndarray:
    p = np.clip(p, EPS, 1 - EPS)
    ll = -(y * np.log(p) + (1 - y) * np.log(1 - p))
    br = (p - y) ** 2
    return np.array([len(p), ll.sum(), br.sum(), (p - y).sum(),
                     w.sum(), (w * ll).sum(), (w * br).sum(), (w * (p - y)).sum()])


def _belief_report(v: np.ndarray) -> dict:
    n, sll, sbr, sd, sw, swll, swbr, swd = v
    return {
        "n": int(n),
        "log_loss": _safe(sll, n),
        "brier": _safe(sbr, n),
        "mean_signed_err": _safe(sd, n),
        "money_log_loss": _safe(swll, sw),
        "money_brier": _safe(swbr, sw),
        "money_signed_err": _safe(swd, sw),
        "weight": float(sw),
    }


def _cal_report(cal: Dict[tuple, np.ndarray]) -> dict:
    out: Dict[str, list] = defaultdict(list)
    for (model, b), v in sorted(cal.items()):
        n, sp, sy, sw, swy = v
        if n <= 0:
            continue
        out[model].append({
            "bin": int(b),
            "lo": float(CAL_BINS[b]), "hi": float(CAL_BINS[b + 1]),
            "n": int(n),
            "p_mean": _safe(sp, n),
            "y_mean": _safe(sy, n),
            "weight": float(sw),
            "y_mean_money": _safe(swy, sw),
        })
    res = {}
    for model, rows in out.items():
        n_tot = sum(r["n"] for r in rows)
        w_tot = sum(r["weight"] for r in rows)
        ece = sum(r["n"] * abs(r["p_mean"] - r["y_mean"]) for r in rows) / n_tot if n_tot else None
        mece = (sum(r["weight"] * abs(r["p_mean"] - r["y_mean_money"]) for r in rows) / w_tot
                if w_tot else None)
        res[model] = {"bins": rows, "ece": ece, "money_ece": mece}
    return res


def _gm_stats(g: pd.DataFrame) -> np.ndarray:
    return np.array([
        len(g),
        float(g["turnover"].sum()),
        float(g["dividend"].sum()),
        float(g["realized_gm"].sum()),
        float(g["expected_gm"].sum()),
        float(g.loc[g["settled"].fillna(False), "turnover"].sum()),
    ])


def _gm_report(v: np.ndarray) -> dict:
    n, to, div, rgm, egm, settled_to = v
    return {
        "n": int(n),
        "turnover": float(to),
        "dividend": float(div),
        "realized_gm": float(rgm),
        "expected_gm": float(egm),
        "realized_margin": _safe(rgm, to),
        "expected_margin": _safe(egm, to),
        "margin_gap": (_safe(rgm, to) - _safe(egm, to)
                       if to else None),
        "settled_turnover": float(settled_to),
    }


def _safe(a, b):
    a, b = float(a), float(b)
    return a / b if b not in (0.0,) else None


def _pack(frames: List[pd.DataFrame]) -> list:
    if not frames:
        return []
    df = pd.concat(frames, ignore_index=True)
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].astype(str)
    return df.where(pd.notna(df), None).to_dict(orient="records")


def _verdict(out: dict) -> List[dict]:
    """Plain-language read of whether the two assumptions hold.

    Belief and margin tolerances scale with the number of settled selections,
    not the number of rows: one selection contributes one independent outcome
    however many buckets it was priced in. Without that, a short window would
    always look mis-calibrated purely from sampling noise.
    """
    v = []
    n_sel = int(out["coverage"].get("settled_selections") or 0)
    sigma = 0.5 / np.sqrt(n_sel) if n_sel else None
    ece_tol = max(0.03, 2 * sigma) if sigma else 0.03
    gm_tol = max(0.01, 2.0 / np.sqrt(n_sel)) if n_sel else 0.01
    t = out["turnover"]["models"].get("active|persist")
    tz = out["turnover"]["models"].get("active|zero")
    te = out["turnover"]["models"].get("active|ema")
    if t:
        beats_zero = (tz and tz["mae"] and t["mae"] and t["mae"] < tz["mae"])
        v.append({
            "topic": "next 5min = last 5min",
            "verdict": "usable" if beats_zero else "no better than forecasting zero",
            "detail": (f"WAPE {_pct(t['wape'])} of turnover, MAE {t['mae']:,.0f} per "
                       f"selection-bucket over {t['n']:,} active buckets; "
                       f"bias {_pct(t['bias_pct'])}. "
                       + (f"EMA(3) WAPE {_pct(te['wape'])}." if te else "")
                       + (f" Forecast-zero WAPE {_pct(tz['wape'])}." if tz else "")),
        })
    bl = out["turnover"]["bucket_level"].get("persist")
    if bl:
        v.append({
            "topic": "market-wide money per bucket",
            "verdict": "good" if (bl["wape"] or 1) < 0.25 else "weak",
            "detail": (f"summed across all live selections, persistence is off by "
                       f"{_pct(bl['wape'])} of the money in a 5-min bucket "
                       f"(bias {_pct(bl['bias_pct'])})."),
        })
    b = out["belief"]["models"].get("p_true")
    s = out["belief"]["models"].get("p_sell")
    cal = out["belief"]["calibration"].get("p_true", {})
    if b:
        gap = (None if not s or s["money_log_loss"] is None or b["money_log_loss"] is None
               else s["money_log_loss"] - b["money_log_loss"])
        cmp_word = ("no comparison" if gap is None else
                    "indistinguishable" if abs(gap) < 1e-4 else
                    "better" if gap > 0 else "worse")
        v.append({
            "topic": "true prob = 1 / true odds",
            "verdict": "calibrated" if (cal.get("money_ece") or 1) < ece_tol
                       else "mis-calibrated",
            "detail": (f"money-weighted log-loss {b['money_log_loss']:.4f}, "
                       f"ECE {_pct(cal.get('money_ece'))}, signed error "
                       f"{_pct(b['money_signed_err'])} on {b['n']:,} settled rows "
                       f"covering {n_sel:,} independent selections, so the noise floor "
                       f"on ECE is about {_pct(ece_tol)}."
                       + (f" Against public odds ({s['money_log_loss']:.4f}) it is "
                          f"{cmp_word}." if s else "")),
        })
    g = out["gm"]["overall"]
    if g and g["turnover"]:
        v.append({
            "topic": "gross margin",
            "verdict": "consistent" if (g["margin_gap"] is not None
                                        and abs(g["margin_gap"]) < gm_tol) else "diverges",
            "detail": (f"realised {_pct(g['realized_margin'])} vs expected "
                       f"{_pct(g['expected_margin'])} on turnover "
                       f"{g['turnover']:,.0f}; gap {_pct(g['margin_gap'])} against a "
                       f"noise floor of {_pct(gm_tol)}."),
        })
    return v


def _pct(x) -> str:
    return "n/a" if x is None else f"{100 * float(x):.2f}%"
