"""
Publisher

Turns the live engine's decisions into params messages for HKJC's pricing
engine (E-HV11-01) and keeps what happened to each one
(docs/specs/kafka-publish.spec.md):

    consider(candidate)   one match: mode, kill switch, scope and the guards; theta* and the
                          weightings at the engine's precision (ThetaOptimizer.quantize); the
                          message, the send and the audit row
    poll()                replies parsed and matched to the message they answer; deliveries;
                          messages left unanswered too long
    stop() / resume()     the kill switch, a file flag that holds across a restart; resume goes
                          back to the configured mode, never above it
    status()              what /api/live/publish/status and the desk show

MODES

    off       nothing is built or sent (create_publisher returns None)
    dry_run   theta* to a file sink (AlgoE_Work/publish/out), answered by the mock engine
    test      theta* to the test topics
    shadow    HKJC's own theta as read, rounded, no weightings, to the production topics (prices
              unchanged), from a read no older than publish.shadow_max_board_age_seconds; theta* to
              the test topics (publish.shadow_test_copy)
    live      theta* to the production topics

shadow and live write to production: they need ALGOE_PUBLISH set to that mode on
the box and AlgoE_Work/publish/CONFIRM-PRODUCTION.txt holding "allow: <mode>",
and every mapping entry their messages use must be confirmed.

WHAT IS SENT. Before the first message for a match, a decision that keeps the
board sends nothing; after it, every decision is sent, HKJC's theta included -
the only way the engine learns that we went back. A (pool, line) once weighted
is sent at 1.0 when it no longer moves, in case an omitted weight keeps its last
value. A decision on an older board than the last message's, or on a board read
too long ago, is never sent; at most one message per match per
publish.min_interval_seconds.

Change Log:
-----------
2026-10-29      Initialize
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import threading
from collections import Counter, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from src.hkjc import kafka_messages as km
from src.hkjc.kafka_transport import (FileTransport, KafkaTransport, Received, TransportError,
                                      kafka_config_from_env)

from ..core.logging import get_logger

logger = get_logger(__name__)

KEY = ["pool_id", "line_id", "combination_id"]
FT = ("goal_tg", "goal_sup", "corner_tg", "corner_sup")
PRODUCTION = ("shadow", "live")
CONFIRM = "CONFIRM-PRODUCTION.txt"
STOPPED = "STOPPED"
FINISHED = ("finished", "full_time")
TARGETS = {"off": [], "dry_run": [("file", "star")], "test": [("test", "star")], "live": [("production", "star")]}
WORST_FIRST = ("send failed", "no response", "unsent", "awaiting", "not ours", "received", "idle")
# replies that read the engine's clock against ours, how many before it is used, and the percentile of their
# delays taken as the offset (a low one, not the minimum: one odd stamp must not set it)
LAG_WINDOW, LAG_MIN, LAG_PERCENTILE = 200, 20, 10.0


@dataclass
class Candidate:
    """One match as the live engine hands it to the publisher."""
    match_id: int
    decision: object                   # MatchDecision
    book: object                       # MatchBook
    rows: pd.DataFrame                 # KEY + pool_name, combination_string, line: the labels the engine reads
    header: dict                       # league_code, phase, minute, in_play, game_state
    board_at: Optional[pd.Timestamp]   # when the prices and TG / SUP in use were read
    draw_factor: float                 # the feed's Goal90DrawFactor
    as_of: pd.Timestamp                # the decision's time: the message's Timestamp


@dataclass
class MatchPublish:
    """What the publisher keeps per match."""
    started: bool = False
    last: Optional[dict] = None                              # the last decision record, sent or not
    sent: Optional[dict] = None                              # the last messages: at, board_at, per target
    weighted: set = field(default_factory=set)               # (pool, line value) ever sent with a weight
    pending: Dict[str, dict] = field(default_factory=dict)   # target -> {msg_id, at}, until its reply
    recent: Dict[str, deque] = field(default_factory=dict)   # target -> its last messages, what a reply can answer
    replies: Dict[str, dict] = field(default_factory=dict)   # target -> the last reply's summary
    answered: Dict[str, pd.Timestamp] = field(default_factory=dict)   # target -> EventTime of the last answer
    states: Dict[str, str] = field(default_factory=dict)     # target -> awaiting | received | no response | ...
    state: str = "idle"                                      # the worst of states
    revert_until: Optional[pd.Timestamp] = None
    hand_back: Optional[dict] = None                         # {theta, minute}: Current at the last read not ours
    star_sent: Optional[dict] = None                         # {theta, minute}: our last theta* to production

    def set_state(self, target: str, value: str) -> None:
        self.states[target] = value
        self.state = min(self.states.values(), key=WORST_FIRST.index)

    def withdraw(self, target: str, msg_id, state: str) -> None:
        """A message that never reached the engine: no reply may be taken for its answer."""
        want = str(msg_id)
        if str((self.pending.get(target) or {}).get("msg_id")) == want:
            self.pending.pop(target, None)
        if target in self.recent:
            self.recent[target] = deque((r for r in self.recent[target] if str(r["msg_id"]) != want), maxlen=4)
        self.set_state(target, state)


# ================================================================ policy
def effective_mode(configured: str, env, work) -> Tuple[str, Optional[str]]:
    """The mode publishing may run in, and why a production mode was refused."""
    if configured not in PRODUCTION:
        return configured, None
    if str(env.get("ALGOE_PUBLISH") or "").strip().lower() != configured:
        return "off", "{0} writes to production: set ALGOE_PUBLISH={0} on this box".format(configured)
    f = Path(work) / "publish" / CONFIRM
    lines = set()
    if f.exists():
        lines = {ln.strip().lower().replace(" ", "") for ln in f.read_text(encoding="utf-8", errors="replace")
                 .splitlines()}
    if "allow:" + configured not in lines:
        return "off", "{0} writes to production: {1} must hold the line 'allow: {0}'".format(configured, f)
    return configured, None


class PublishPolicy:
    def __init__(self, settings, work, env=None):
        self.p = settings.publish
        self.configured = self.p.mode
        self.mode, self.refused = effective_mode(self.configured, os.environ if env is None else env, work)

    def targets(self) -> List[Tuple[str, str]]:
        """(target, what) per message of a decision: what is 'star' (theta*) or 'board' (HKJC's theta)."""
        if self.mode == "shadow":
            return [("production", "board")] + ([("test", "star")] if self.p.shadow_test_copy else [])
        return list(TARGETS[self.mode])

    def in_scope(self, match_id, league) -> bool:
        p = self.p
        if p.scope_matches:
            if int(match_id) in {int(x) for x in p.scope_matches}:
                return True
            if not p.scope_leagues:
                return False
        if p.scope_leagues and str(league or "").upper() not in {str(x).upper() for x in p.scope_leagues}:
            return False
        if p.scope_percent >= 100.0:
            return True
        h = int(hashlib.sha256("{}:{}".format(p.scope_salt, int(match_id)).encode("utf-8")).hexdigest()[:8], 16)
        return (h % 10000) < float(p.scope_percent) * 100.0

    def describe(self) -> dict:
        p = self.p
        return {"leagues": list(p.scope_leagues), "matches": list(p.scope_matches), "percent": p.scope_percent}


# ============================================================ bookkeeping
def _atomic_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=1, default=str), encoding="utf-8")
    os.replace(tmp, path)


def read_stop(root) -> Optional[dict]:
    """The kill switch: who stopped publishing and why, or None."""
    f = Path(root) / STOPPED
    if not f.exists():
        return None
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except ValueError:
        return {"by": "?", "reason": "unreadable {}".format(f)}


def write_stop(root, by: str, reason: str, at) -> dict:
    Path(root).mkdir(parents=True, exist_ok=True)
    info = {"at": str(pd.Timestamp(at)), "by": by, "reason": reason}
    _atomic_json(Path(root) / STOPPED, info)
    return info


def clear_stop(root) -> None:
    f = Path(root) / STOPPED
    if f.exists():
        f.unlink()


class MsgIds:
    """The day's message sequence. Reserved in blocks in state.json before use, so a restart continues and
    never repeats one. The wire id is yyyymmdd plus six digits (kafka_messages.snapshot_msg_id)."""

    def __init__(self, path: Path, block: int = 100):
        self.path, self.block = Path(path), int(block)
        self._lock = threading.Lock()
        data = {}
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
            except ValueError as exc:
                raise RuntimeError("{} is not readable ({}): fix or delete it only after checking the last MsgId "
                                   "sent in publish/audit".format(self.path, exc))
        self._day = str(data.get("day") or "")
        self._next = int(data.get("next", 1))
        self._reserved = self._next

    def next(self, when) -> int:
        day = pd.Timestamp(when).strftime("%Y%m%d")
        with self._lock:
            if self._day != day:
                self._day, self._next, self._reserved = day, 1, 1
            if self._next > 999999:
                raise RuntimeError("message sequence for {} is past 999999".format(day))
            if self._next >= self._reserved:
                self._reserved = self._next + self.block
                _atomic_json(self.path, {"day": day, "next": self._reserved, "updated": str(pd.Timestamp(when))})
            n = self._next
            self._next += 1
            return km.snapshot_msg_id(when, n)


class AuditLog:
    """One gzip file per hour, AlgoE_Work/publish/audit/<YYYYMMDD-HH>.jsonl.gz, one row per decision, message
    out, reply in, delivery failure and timeout; files older than ``days`` are deleted."""

    def __init__(self, root: Path, days: int, clock):
        self.root, self.days, self.clock = Path(root), int(days), clock
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._pruned: Optional[str] = None
        self.prune()

    def prune(self) -> int:
        cut = (pd.Timestamp(self.clock()) - pd.Timedelta(days=self.days)).strftime("%Y%m%d-%H")
        gone = 0
        for f in self.root.glob("*.jsonl.gz"):
            if f.name[:11] < cut:
                try:
                    f.unlink()
                    gone += 1
                except OSError as exc:
                    logger.warning("cannot delete old audit file %s: %s", f, exc)
        self._pruned = pd.Timestamp(self.clock()).strftime("%Y%m%d-%H")
        return gone

    def write(self, row: dict) -> None:
        now = pd.Timestamp(self.clock())
        hour = now.strftime("%Y%m%d-%H")
        line = json.dumps(_plain(row), default=str, ensure_ascii=False) + "\n"
        with self._lock:
            if hour != self._pruned:
                self.prune()
            with gzip.open(self.root / "{}.jsonl.gz".format(hour), "at", encoding="utf-8") as fh:
                fh.write(line)


def _plain(obj):
    if isinstance(obj, dict):
        return {str(k): _plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_plain(v) for v in obj]
    if isinstance(obj, (np.floating, float)):
        return float(obj) if np.isfinite(obj) else None
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, (pd.Timestamp,)):
        return str(obj)
    return obj


def _line_key(line) -> float:
    try:
        v = float(line)
    except (TypeError, ValueError):
        return 0.0
    return round(v, 2) + 0.0 if np.isfinite(v) else 0.0


def _carried(read: Optional[dict], minute: float, in_play: bool) -> Optional[Dict[str, float]]:
    """A theta read at read["minute"], carried to ``minute``: in play scaled to the clock like the first_seen
    anchor."""
    if not read:
        return None
    scale = max(90.0 - minute, 0.0) / max(90.0 - float(read["minute"]), 1.0) if in_play else 1.0
    return {k: float(v) * scale for k, v in read["theta"].items()}


# ============================================================== publisher
class Publisher:
    def __init__(self, settings, mapping: km.Mapping, transport, optimizer, topics: Dict[str, Tuple[str, str]],
                 clock=None, env=None, work_dir=None):
        self.settings = settings
        self.p = settings.publish
        self.mapping = mapping
        self.transport = transport
        self.optimizer = optimizer
        self.topics = dict(topics)
        self.clock = clock or pd.Timestamp.now
        work = Path(work_dir or settings.paths.work)
        self.root = work / "publish"
        self.root.mkdir(parents=True, exist_ok=True)
        self.policy = PublishPolicy(settings, work, env)
        self.ids = MsgIds(self.root / "state.json")
        self.audit = AuditLog(self.root / "audit", self.p.audit_days, lambda: self.clock())
        self.matches: Dict[int, MatchPublish] = {}
        self.counts: Counter = Counter()
        self.latencies: deque = deque(maxlen=500)
        self._lags: deque = deque(maxlen=LAG_WINDOW)      # seconds from a reply's EventTime to its arrival, our clock
        self.last_sent: Optional[dict] = None
        self._by_tag: Dict[str, int] = {}
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._halt = threading.Event()
        if self.policy.refused:
            logger.warning("publishing refused: %s", self.policy.refused)
        logger.info("publishing: mode %s (configured %s), targets %s, mapping %s", self.mode, self.policy.configured,
                    [t for t, _ in self.policy.targets()], mapping.source)

    @property
    def mode(self) -> str:
        return self.policy.mode

    @property
    def refused(self) -> Optional[str]:
        return self.policy.refused

    # ------------------------------------------------------------ kill switch
    def stopped(self) -> Optional[dict]:
        return read_stop(self.root)

    def stop(self, by: str = "desk", reason: str = "") -> dict:
        info = write_stop(self.root, by, reason, self.clock())
        self.audit.write(dict(info, kind="stop"))
        logger.warning("publishing STOPPED by %s: %s", by, reason)
        return self.status()

    def resume(self, by: str = "desk") -> dict:
        clear_stop(self.root)
        self.audit.write({"kind": "resume", "at": str(pd.Timestamp(self.clock())), "by": by, "mode": self.mode})
        logger.warning("publishing resumed by %s in mode %s", by, self.mode)
        return self.status()

    def flag_revert(self, match_id: int, minutes: float, why: str) -> None:
        """The revert guard fired: the match's next messages carry HKJC's theta for ``minutes``."""
        now = pd.Timestamp(self.clock())
        with self._lock:
            mp = self.matches.setdefault(int(match_id), MatchPublish())
            mp.revert_until = now + pd.Timedelta(minutes=float(minutes))
            self.counts["reverts"] += 1
            self.audit.write({"kind": "revert", "at": str(now), "match_id": int(match_id), "until": str(mp.revert_until),
                              "why": why})

    # ------------------------------------------------------------- deciding
    def consider(self, c: Candidate, reason: str) -> dict:
        """Send this decision, or say why not. Returns the decision record (also audited).

        The messages are built and recorded under the lock and sent after it: a transport may call back
        into the engine (the dry run's mock engine reads the match), and the desk reads both."""
        now = pd.Timestamp(self.clock())
        outbox: List[tuple] = []
        with self._lock:
            mp = self.matches.setdefault(int(c.match_id), MatchPublish())
            rec = self._decide(c, mp, now, reason, outbox)
            mp.last = rec
            self.counts[rec["action"]] += 1
            self.audit.write(dict(rec, kind="decision"))
        for target, topic, key, value, tag in outbox:
            if self.stopped():                     # the kill switch was pressed after the message was built
                with self._lock:
                    mp.withdraw(target, tag, "unsent")
                    self.counts["unsent"] += 1
                    self.audit.write({"kind": "unsent", "at": str(now), "match_id": int(c.match_id), "msg_id": tag,
                                      "why": "stopped before sending"})
                continue
            self.transport.send(topic, key, value, tag=tag)
        return rec

    def _decide(self, c: Candidate, mp: MatchPublish, now: pd.Timestamp, reason: str, outbox: List[tuple]) -> dict:
        mid = int(c.match_id)
        base = {"at": str(now), "match_id": mid, "reason": reason, "mode": self.mode}

        def no(action: str, why: str) -> dict:
            return dict(base, action=action, why=why)
        if self.mode == "off":
            return no("skipped", "publishing is off" + (": " + self.refused if self.refused else ""))
        st = self.stopped()
        if st:
            return no("skipped", "stopped by {} ({})".format(st.get("by"), st.get("reason") or "no reason given"))
        if not getattr(self.transport, "listening", True):
            return no("skipped", "the reply consumer has not joined its group yet: nothing goes out before its "
                                 "answer can be heard")
        d, bk, h = c.decision, c.book, c.header or {}
        if d is None or bk is None:
            return no("skipped", "no book")
        if not self.policy.in_scope(mid, h.get("league_code")):
            return no("skipped", "out of scope")
        if str(h.get("phase") or "") in FINISHED:
            return no("skipped", "match finished")
        age = (now - pd.Timestamp(c.board_at)).total_seconds() if c.board_at is not None else float("inf")
        limit = self.p.max_board_age_seconds if h.get("in_play") else self.p.max_board_age_prematch_seconds
        if age > limit:
            return no("refused", "stale board: read {:.0f}s ago".format(age))
        if mp.sent is not None:
            if (now - mp.sent["at"]).total_seconds() < self.p.min_interval_seconds:
                return no("skipped", "too soon")
            if pd.Timestamp(c.board_at) < mp.sent["board_at"]:
                return no("refused", "older board than message {} ({} < {})".format(
                    mp.sent["msg_ids"][-1], c.board_at, mp.sent["board_at"]))
        revert = mp.revert_until is not None and now < mp.revert_until
        kept = str(d.status).startswith(("kept", "skipped"))
        if kept and not mp.started and not revert:
            return no("skipped", "kept board: nothing sent for this match yet")
        minute, in_play = float(h.get("minute") or 0.0), bool(h.get("in_play"))
        th_now = {k: float(d.theta_now[k]) for k in FT}
        follows = self._follows(mp, th_now)
        if follows:
            self.counts["current_follows"] += 1
        else:
            mp.hand_back = {"theta": th_now, "minute": minute if in_play else 0.0}
        r = self.mapping.rounding
        q_star = self.optimizer.quantize(bk, d, r["theta"], r["weight"], self.p.weight_overround_tolerance)
        q_board = self.optimizer.quantize_board(bk, r["theta"],
                                                hold=_carried(mp.hand_back, minute, in_play) if follows else None)
        if not mp.started and not revert and q_star.chosen == "theta*" and q_star.egm < d.egm_board - 1e-9:
            # nothing sent yet: the trader's exact theta stays on the board, and it earns more
            return no("skipped", "rounding to the engine's precision loses the gain: E[GM] {:.0f} < {:.0f} on the "
                                 "board; nothing sent for this match yet".format(q_star.egm, d.egm_board))
        built, notes = [], []
        for target, what in self.policy.targets():
            if what == "board" and age > self.p.shadow_max_board_age_seconds:
                # a trader may have moved Current since this read: HKJC's theta from it could undo that
                notes.append("{}: HKJC's theta read {:.0f}s ago, older than publish.shadow_max_board_age_seconds "
                             "({:.0f}s): not sent there".format(target, age, self.p.shadow_max_board_age_seconds))
                continue
            q = q_board if (what == "board" or revert or q_star.chosen == "board") else q_star
            board_only = what == "board" or revert or q.chosen == "board"
            try:
                msg = self._snapshot(c, q, mp, board_only, now, update="inplay" if reason == "inplay" else "sweep",
                                     source="hkjc" if board_only else "optimized")
            except (km.MessageError, km.MappingError) as exc:
                return no("refused", str(exc))
            built.append((target, what, q, msg, self._weight_rows(c, q, mp, board_only=board_only)))
        if not built:
            return no("skipped", "; ".join(notes))
        sent_targets, ids = {}, []
        for target, what, q, msg, rows in built:
            msg["msg_id"] = self.ids.next(now)
            topic = self.topics[target][0]
            outbox.append((target, topic, mid, km.encode(msg), str(msg["msg_id"])))
            self._by_tag[str(msg["msg_id"])] = (mid, target)
            ids.append(msg["msg_id"])
            mp.pending[target] = {"msg_id": msg["msg_id"], "at": now}
            weights = {(p, lv, lab): w for p, lv, lab, w, ok in rows if ok}
            chosen = "revert" if revert else q.chosen
            # what a reply to it is read against: the board and the belief this message was decided on
            sent_targets[target] = {"msg_id": msg["msg_id"], "at": now, "what": what, "chosen": chosen,
                                    "theta": dict(q.theta),
                                    "engine": {"GoalTg": round(float(q.theta["goal_tg"]), 2),
                                               "GoalSup": round(float(q.theta["goal_sup"]), 2),
                                               "CornerTg": round(float(q.theta["corner_tg"]), 2),
                                               "CornerSup": round(float(q.theta["corner_sup"]), 2),
                                               **({"DrawFactor": km.engine_draw_factor(c.draw_factor, self.mapping)}
                                                  if km._finite(c.draw_factor) else {})},
                                    "weights": weights, "egm": q.egm, "egm_board": q.egm_board,
                                    "book": bk, "rows": c.rows, "header": h, "decision": d}
            mp.recent.setdefault(target, deque(maxlen=4)).append(sent_targets[target])
            mp.set_state(target, "awaiting")
            mp.weighted |= {(p, lv) for (p, lv, _), w in weights.items() if abs(w - 1.0) > 1e-9}
            if target == "production" and chosen == "theta*":
                mp.star_sent = {"theta": {k: q.theta[k] for k in FT}, "minute": minute}
            self.audit.write({"kind": "out", "at": str(now), "match_id": mid, "msg_id": msg["msg_id"], "target": target,
                              "topic": topic, "mode": self.mode, "what": what, "message": msg,
                              "theta_sent": {k: q.theta[k] for k in FT}})
        main = next((v for v in sent_targets.values() if v["what"] == "star"), next(iter(sent_targets.values())))
        mp.sent = {"at": now, "board_at": pd.Timestamp(c.board_at), "msg_ids": ids, "targets": sent_targets,
                   "minute": minute, "phase": h.get("phase")}
        mp.started = True
        self.last_sent = {"at": str(now), "match_id": mid, "msg_ids": ids}
        return dict(base, action="sent", why=None, msg_ids=ids, targets=list(sent_targets), chosen=main["chosen"],
                    theta_now=th_now, theta_star={k: d.theta_star[k] for k in FT},
                    theta_sent={k: main["theta"][k] for k in FT}, engine_params=main["engine"],
                    weights=sum(1 for w in main["weights"].values() if abs(w - 1.0) > 1e-9),
                    reset_lines=list(q_star.reset_lines), gm_board=d.egm_board, gm_star=d.egm_star,
                    gm_sent=main["egm"], gm_board_sent=main["egm_board"], current_follows=follows, notes=notes)

    def _follows(self, mp: MatchPublish, th_now: Dict[str, float]) -> bool:
        """Current reads our last theta* to production rather than HKJC's own: the engine took our message as
        Current. Not decidable while the two are the same at the engine's precision."""
        ours, back = mp.star_sent, mp.hand_back
        if not ours or not back:
            return False
        half = 0.5 * 10.0 ** -int(self.mapping.rounding["theta"]) + 1e-9
        if all(abs(ours["theta"][k] - back["theta"][k]) <= half for k in FT):
            return False
        return all(abs(th_now[k] - ours["theta"][k]) <= half for k in FT)

    def _snapshot(self, c: Candidate, q, mp: MatchPublish, board_only: bool, now, update: str, source: str) -> dict:
        """The wire message: one snapshot with parameters, every selection's weight, turnover and probability."""
        h = c.header or {}
        minute = float(h.get("minute") or 0.0)
        weighted = {} if board_only else {(p, lv, lab): w for p, lv, lab, w, ok in
                                           self._weight_rows(c, q, mp, board_only=False) if ok}
        rows = c.rows if c.rows is not None else pd.DataFrame()
        selections = []
        for _, r in rows.iterrows():
            pool = str(r.get("pool_name") or "").upper()
            line = r.get("line")
            lv = _line_key(line) if line is not None and np.isfinite(pd.to_numeric(line, errors="coerce")) else 0.0
            label = r.get("combination_string")
            label = "" if label is None or (isinstance(label, float) and np.isnan(label)) else str(label).strip()
            domain = str(r.get("theta_domain") or "")
            domain = "goal" if domain.startswith("goal") else "corner" if domain.startswith("corner") else None
            selections.append({
                "pool_id": int(r["pool_id"]), "line_id": int(r["line_id"]),
                "combination_id": int(r["combination_id"]), "pool": pool,
                "segment": None if r.get("segment") is None or (isinstance(r.get("segment"), float)
                                                                and np.isnan(r.get("segment"))) else r.get("segment"),
                "domain": domain, "market": None if not r.get("market") else str(r.get("market")),
                "line": None if not np.isfinite(pd.to_numeric(line, errors="coerce")) else float(line),
                "line_label": None if r.get("line_label") is None or (isinstance(r.get("line_label"), float)
                                                                      and np.isnan(r.get("line_label")))
                else str(r.get("line_label")),
                "selection": label, "weight": weighted.get((pool, lv, label)),
                "actual": r.get("observed"), "remaining": r.get("remaining"), "probability": r.get("belief")})
        return km.build_snapshot_message(
            int(c.match_id), 0, now, c.board_at or c.as_of, self.settings.panel.bucket_minutes, update,
            {"league": h.get("league_code"), "home": h.get("home") or h.get("home_name"),
             "away": h.get("away") or h.get("away_name"), "phase": h.get("phase") or "prematch",
             "seconds": int(round(minute * 60.0)), "score": h.get("score") or [0, 0],
             "corners": h.get("corners") or [0, 0]},
            q.theta, c.draw_factor, selections, parameter_source=source)

    def _weight_rows(self, c: Candidate, q, mp: MatchPublish, board_only: bool) -> List[tuple]:
        """(pool, line value, label, weight, mapped) for every selection of a line that is weighted now or
        was weighted in an earlier message; at 1.0 when only HKJC's theta goes out. After half time the first
        half is settled and is left out."""
        keys = c.book.keys
        if keys is None or c.rows is None or c.rows.empty:
            return []
        settled = np.char.endswith(np.asarray(c.book.rows.theta_domain, dtype=str), "_fh") & bool(c.book.state.ht_done)
        k = keys[KEY].astype("int64").assign(_w=np.asarray(q.weights, dtype="float64"), _settled=settled)
        lab = c.rows[[x for x in KEY + ["pool_name", "combination_string", "line"] if x in c.rows.columns]].copy()
        for col in KEY:
            lab[col] = pd.to_numeric(lab[col], errors="coerce").astype("int64")
        frame = k.merge(lab.drop_duplicates(KEY), on=KEY, how="left")
        lines: Dict[tuple, List[tuple]] = {}
        for pool, line, label, w, gone in zip(frame["pool_name"], frame["line"], frame["combination_string"],
                                              frame["_w"], frame["_settled"]):
            if gone or pool is None or (isinstance(pool, float) and np.isnan(pool)):
                continue
            pool = str(pool).upper()
            lv = _line_key(line)
            label = "" if label is None or (isinstance(label, float) and np.isnan(label)) else str(label).strip()
            mapped = self.mapping.pool_code(pool) is not None and self.mapping.selection_id(pool, label) is not None
            lines.setdefault((pool, lv), []).append((pool, float(line) if np.isfinite(line) else float("nan"),
                                                     label, 1.0 if board_only else float(w), mapped))
        out = []
        for key, rows in lines.items():
            moved = any(abs(r[3] - 1.0) > 1e-9 for r in rows)
            if moved or key in mp.weighted:
                out += [(p, ln, lab, w, ok) for p, ln, lab, w, ok in rows]
        return [(p, ln, lab, w, ok) for p, ln, lab, w, ok in out]

    # --------------------------------------------------------------- replies
    def _target_of(self, topic: str) -> str:
        for target, (_, prices) in self.topics.items():
            if prices == topic and target in {t for t, _ in self.policy.targets()}:
                return target
        targets = self.policy.targets()
        return targets[0][0] if targets else "file"

    def _sent_to(self, event_id, target: str) -> bool:
        mp = self.matches.get(event_id) if isinstance(event_id, int) and not isinstance(event_id, bool) else None
        return mp is not None and bool(mp.recent.get(target))

    def _throttled(self, key: str, text: str, *args) -> None:
        """A warning the first 10 times, then every 1000th: a shared topic may carry these all evening."""
        n = self.counts[key]
        if n <= 10 or n % 1000 == 0:
            logger.warning(text + "%s", *args, " (from here on every 1000th is logged; all are in the audit)"
                           if n == 10 else "")

    def on_reply(self, received: Received) -> Optional[Tuple[km.PricesReply, dict]]:
        target = self._target_of(received.topic)
        try:
            raw = json.loads(received.value)
        except ValueError:
            raw = received.value
        eid = raw.get("EventId") if isinstance(raw, dict) else None
        with self._lock:
            if eid is not None and not self._sent_to(eid, target):
                # the engine answers every match on the same topic: counted, not read
                self.counts["other_events"] += 1
                return None
        try:
            reply = km.parse_prices_message(raw, self.mapping)
        except km.MessageError as exc:
            with self._lock:
                self.counts["bad_replies"] += 1
                self.audit.write({"kind": "bad_reply", "at": str(pd.Timestamp(self.clock())), "error": str(exc),
                                  "topic": received.topic, "head": received.value[:300]})
                self._throttled("bad_replies", "unreadable reply #%d on %s: %s", self.counts["bad_replies"],
                                received.topic, exc)
            return None
        now = pd.Timestamp(self.clock())
        if target == "production" and self.p.server_app_ids and reply.server_app_id not in self.p.server_app_ids:
            with self._lock:
                self.counts["other_server"] += 1
                self.audit.write({"kind": "other_server", "at": str(now), "match_id": reply.event_id,
                                  "server": reply.server_app_id, "topic": received.topic})
                self._throttled("other_server", "reply #%d for match %s from %s dropped: not in "
                                "publish.server_app_ids %s", self.counts["other_server"], reply.event_id,
                                reply.server_app_id, self.p.server_app_ids)
            return None
        info = {"target": target, "ours": False, "late": False, "msg_id": None, "latency": None, "at": now,
                "sent": None}
        with self._lock:
            mp = self.matches[reply.event_id]
            computed, calibrated = None, len(self._lags) >= LAG_MIN
            if reply.event_time is not None:
                self._lags.append((now - reply.event_time).total_seconds())
                if len(self._lags) >= LAG_MIN:
                    calibrated = True
                    computed = reply.event_time + pd.Timedelta(seconds=float(np.percentile(self._lags,
                                                                                            LAG_PERCENTILE)))
            answered = mp.answered.get(target)
            if answered is not None and reply.event_time is not None and reply.event_time < answered:
                self.counts["stale_replies"] += 1
                return None
            history = list(mp.recent.get(target) or [])
            slack = pd.Timedelta(seconds=float(self.p.reply_order_slack_seconds))

            def before(r) -> bool:                          # computed before that message went: cannot answer it
                return computed is not None and computed < r["at"] - slack
            if calibrated and computed is None:
                pass                                        # no EventTime once the clock is read: cannot place it
            elif history and before(history[-1]):
                earlier = next((r for r in reversed(history[:-1]) if not before(r)), None)
                if earlier is not None:
                    info.update(ours=True, late=True, msg_id=earlier["msg_id"], sent=earlier)
            else:
                pending = mp.pending.pop(target, None)
                last = history[-1] if history else None
                if pending is not None:
                    info.update(ours=True, msg_id=pending["msg_id"], latency=(now - pending["at"]).total_seconds(),
                                sent=last)
                    self.latencies.append(info["latency"])
                elif last is not None and (now - last["at"]).total_seconds() <= 3 * self.p.reply_timeout_seconds:
                    info.update(ours=True, msg_id=last["msg_id"], repeat=True, sent=last)
            mp.replies[target] = {"at": now, "event_time": reply.event_time, "msg_id": info["msg_id"],
                                  "ours": info["ours"], "latency": info["latency"], "server": reply.server_app_id,
                                  "game_state": reply.game_state, "clock_seconds": reply.clock_seconds}
            if info["ours"] and not info["late"]:
                mp.set_state(target, "received")
                if reply.event_time is not None:
                    mp.answered[target] = reply.event_time
            elif not info["ours"] and target not in mp.pending:
                mp.set_state(target, "not ours")
            self.counts["replies"] += 1
            if not info["ours"]:
                self.counts["not_ours"] += 1
            frame = reply.frame()
            self.audit.write({"kind": "in", "at": str(now), "match_id": reply.event_id, "target": target,
                              "topic": received.topic, "ours": info["ours"], "late": info["late"],
                              "msg_id": info["msg_id"], "latency": info["latency"], "server": reply.server_app_id,
                              "game_state": reply.game_state, "clock_seconds": reply.clock_seconds,
                              "event_time": reply.event_time, "pools": int(frame["pool_id"].nunique()),
                              "selections": len(frame), "offered": int(frame["offered"].sum())})
            if self.p.audit_raw:
                self.audit.write({"kind": "raw", "at": str(now), "match_id": reply.event_id, "value": received.value})
        return reply, info

    def record_feedback(self, match_id: int, row: dict) -> None:
        """A reply as the live engine read it on the book (gm_engine, gap, echo, revert), for the audit."""
        self.audit.write(dict(row, kind="feedback", at=str(pd.Timestamp(self.clock())), match_id=int(match_id)))

    def _delivered(self, dlv) -> None:
        with self._lock:
            if dlv.ok:
                self.counts["delivered"] += 1
                return
            self.counts["failed"] += 1
            mid, target = self._by_tag.get(dlv.tag, (None, None))
            if mid is not None and mid in self.matches:
                self.matches[mid].withdraw(target, dlv.tag, "send failed")
            self.audit.write({"kind": "delivery", "at": str(pd.Timestamp(self.clock())), "msg_id": dlv.tag,
                              "match_id": mid, "topic": dlv.topic, "ok": False, "error": dlv.error})
        logger.warning("message %s to %s failed: %s", dlv.tag, dlv.topic, dlv.error)

    def check_timeouts(self) -> List[int]:
        now = pd.Timestamp(self.clock())
        late = []
        with self._lock:
            for mid, mp in self.matches.items():
                for target, p in list(mp.pending.items()):
                    if (now - p["at"]).total_seconds() > self.p.reply_timeout_seconds:
                        mp.pending.pop(target, None)
                        mp.set_state(target, "no response")
                        self.counts["no_response"] += 1
                        late.append(mid)
                        self.audit.write({"kind": "timeout", "at": str(now), "match_id": mid, "target": target,
                                          "msg_id": p["msg_id"]})
        return late

    def poll(self, timeout: float = 0.0) -> List[Tuple[km.PricesReply, dict]]:
        """Replies since the last poll, each with what it answers; deliveries and timeouts on the way."""
        out = []
        for r in self.transport.poll(timeout):
            got = self.on_reply(r)
            if got is not None:
                out.append(got)
        for dlv in self.transport.deliveries():
            self._delivered(dlv)
        self.check_timeouts()
        return out

    # ---------------------------------------------------------------- thread
    def start(self, handler: Callable[[km.PricesReply, dict], None], every: float = 0.25) -> None:
        """The response consumer on its own thread: every reply goes to ``handler`` (the live engine)."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._halt.clear()
        blocking = isinstance(self.transport, KafkaTransport)

        def loop():
            tries = 0
            while blocking and not self._halt.is_set() and not self.transport.listening:
                try:
                    if not self.transport.wait_assigned(5.0) and tries % 12 == 0:
                        logger.warning("the reply consumer holds no partition of %s yet: nothing is sent until "
                                       "it does", self.transport.reply_topics)
                except Exception as exc:                                   # noqa: BLE001
                    if tries % 12 == 0:
                        logger.warning("the reply consumer cannot join its group: %s", exc)
                    self._halt.wait(5.0)
                tries += 1
            while not self._halt.is_set():
                try:
                    for reply, info in self.poll(timeout=every if blocking else 0.0):
                        handler(reply, info)
                except Exception as exc:                                   # noqa: BLE001
                    logger.exception("reply consumer: %s", exc)
                if not blocking:
                    self._halt.wait(every)
        self._thread = threading.Thread(target=loop, name="algoe-kafka-in", daemon=True)
        self._thread.start()

    def shutdown(self) -> None:
        self._halt.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
        try:
            self.transport.close()
        except Exception as exc:                                           # noqa: BLE001
            logger.warning("closing the transport: %s", exc)

    # ---------------------------------------------------------------- read
    def match_brief(self, match_id: int) -> dict:
        """The board row's publish badge: the last decision and the reply state."""
        with self._lock:
            mp = self.matches.get(int(match_id))
            if mp is None:
                return {"state": "idle", "msg_id": None, "sent_at": None, "action": None, "why": None}
            last = mp.last or {}
            sent = mp.sent or {}
            return _plain({"state": mp.state, "msg_id": (sent.get("msg_ids") or [None])[-1], "sent_at": sent.get("at"),
                           "action": last.get("action"), "why": last.get("why"),
                           "revert": mp.revert_until is not None and pd.Timestamp(self.clock()) < mp.revert_until})

    def match_view(self, match_id: int) -> dict:
        with self._lock:
            mp = self.matches.get(int(match_id))
            if mp is None:
                return {"mode": self.mode, "state": "idle", "started": False}
            sent = mp.sent or {}
            main = next((v for v in (sent.get("targets") or {}).values() if v["what"] == "star"),
                        next(iter((sent.get("targets") or {}).values()), None))
            return _plain({"mode": self.mode, "state": mp.state, "started": mp.started, "last": mp.last,
                           "msg_id": main["msg_id"] if main else None, "sent_at": sent.get("at"),
                           "chosen": main["chosen"] if main else None,
                           "theta_sent": main["theta"] if main else None, "engine_params": main["engine"] if main else None,
                           "replies": mp.replies, "awaiting": sorted(mp.pending), "states": dict(mp.states),
                           "revert_until": mp.revert_until, "stopped": self.stopped() is not None})

    def status(self) -> dict:
        with self._lock:
            lat = sorted(self.latencies)
            return _plain({
                "mode": self.mode, "configured": self.policy.configured, "refused": self.refused,
                "stopped": self.stopped(), "targets": [t for t, _ in self.policy.targets()],
                "transport": type(self.transport).__name__, "mapping": self.mapping.summary(),
                "scope": self.policy.describe(), "counts": dict(self.counts),
                "matches": sum(1 for m in self.matches.values() if m.started),
                "awaiting": sum(1 for m in self.matches.values() if m.pending),
                "no_response": sorted(mid for mid, m in self.matches.items() if m.state == "no response"),
                "last_sent": self.last_sent,
                "latency_seconds": {"median": lat[len(lat) // 2], "p95": lat[min(len(lat) - 1, int(len(lat) * 0.95))],
                                    "n": len(lat)} if lat else None})


# ================================================================ building
def build_transport(settings, mapping: km.Mapping, mode: str, work, lookup, env=None,
                    clock=None) -> Tuple[object, Dict[str, tuple]]:
    """The transport and topics for ``mode``: the file sink and mock engine for dry_run (its replies stamped by
    ``clock``), Kafka otherwise."""
    if mode == "dry_run":
        from .mock_engine import MockEngine
        mock = MockEngine(settings, mapping, lookup, corner_dispersion=settings.publish.mock_corner_dispersion,
                          clock=clock)
        return FileTransport(Path(work) / "publish", responder=mock.reply), {"file": ("params", "prices")}
    cfg = kafka_config_from_env(env)
    same = cfg.overlap()
    if same:
        raise TransportError("{} is both a test topic and a production topic: a test message would reach "
                             "production. Fix ALGOE_KAFKA_TEST_TOPIC_* (deploy/kafka.example.cmd)".format(", ".join(same)))
    needed = {"test": ["test"], "live": ["production"],
              "shadow": ["production"] + (["test"] if settings.publish.shadow_test_copy else [])}[mode]
    missing = cfg.missing(needed)
    if missing:
        raise TransportError("publish mode {} needs {} set on this box (deploy/kafka.example.cmd)".format(
            mode, ", ".join(missing)))
    topics = {t: cfg.topics(t) for t in needed}
    return KafkaTransport(cfg, reply_topics=[topics[t][1] for t in needed]), topics


def create_publisher(settings, optimizer, lookup, clock=None, env=None) -> Tuple[Optional[Publisher], Optional[str]]:
    """(publisher, why there is none). Mode off builds nothing; a refused production mode or a transport
    that cannot be built says why."""
    work = Path(settings.paths.work)
    mode, refused = effective_mode(settings.publish.mode, os.environ if env is None else env, work)
    if mode == "off":
        return None, refused
    mapping = km.load_mapping(work_dir=work)
    owner: List[Publisher] = []

    def now():                       # the mock engine's clock is the publisher's, whatever it is set to later
        return owner[0].clock() if owner else (clock or pd.Timestamp.now)()
    try:
        transport, topics = build_transport(settings, mapping, mode, work, lookup, env=env, clock=now)
    except TransportError as exc:
        logger.error("publishing not started: %s", exc)
        return None, str(exc)
    owner.append(Publisher(settings, mapping, transport, optimizer, topics, clock=clock, env=env, work_dir=work))
    return owner[0], None
