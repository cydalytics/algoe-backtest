globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/p7C71PXRW-1YdlY5o4qMt/_buildManifest.js",
    "static/p7C71PXRW-1YdlY5o4qMt/_ssgManifest.js",
    "static/p7C71PXRW-1YdlY5o4qMt/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2tswzwt7g9k6a.js",
    "static/chunks/02fh7_m5mrih8.js",
    "static/chunks/2a2r6ih4qqdp9.js",
    "static/chunks/turbopack-1ghne-gwqwval.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
