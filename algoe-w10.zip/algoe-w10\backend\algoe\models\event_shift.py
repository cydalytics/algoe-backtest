"""
Event Shift

What a goal, a red card or a corner does to the money in the minutes after it, as a multiplier on
the forecast made before it, for each bet type and side:

    goal_total / corner_total       over, under
    goal_hdc / corner_hdc           favourite, underdog   (no favourite at kick-off: home, away)
    goal_1x2                        favourite, draw, underdog
    any other bet type              all

    M[side group | event, clock, who, favourite strength, score state after]

It is fitted on buckets with an event inside them. The bucket's forecast F was made at its start,
before the event, which came k minutes in; with w = k / 5 of the bucket gone before it,

    money in the bucket = F x (w + (1 - w) x M)

so M is the money after the event against what the forecast expected for those minutes. The broadest
cell (side group x event) is pulled toward 1 by ``prior_events`` pseudo-events; each narrower cell
(clock -> who -> strength -> state) multiplies its parent by its own ratio to the parent's raw one,
pulled toward 1 the same way. A cell holding exactly its parent's events adds nothing, so one red card
is not counted once per level; a red card at 80' with a strong favourite borrows from every red card,
and a cell with few events cannot invent an effect.

Money on a line opened after the event is not in it: that line was not on the board when the
bucket's forecast was made, here or live.

The backtest fits it on validation days and scores it on test days (backtest/mixstudy.py), then
writes models/turnover/EVENT_SHIFT.json; the live engine applies it to a match's forecast for the
rest of the bucket as soon as the event arrives (realtime/live_engine.py).

Change Log:
-----------
2026-10-11      Initialize
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger

logger = get_logger(__name__)

# incident codes: adds and their cancellations (VAR)
EVENT_CODES = {"goal": (27,), "red": (57, 79), "corner": (13,)}
CANCEL_CODES = {"goal": (6,), "red": (8, 10), "corner": (5,)}
PRIORITY = ("red", "goal", "corner")            # one label per bucket: the rarer event wins
CLOCK = ((0, 15, "0-15'"), (15, 30, "15-30'"), (30, 45, "30-45'"), (45, 60, "45-60'"), (60, 75, "60-75'"),
         (75, 200, "75'+"))
LEVELS = ("event", "clock", "who", "strength", "state")
STRONG = 0.75
TOTAL_FAMILIES = ("goal_total", "corner_total")
TEAM_FAMILIES = ("goal_hdc", "goal_1x2", "corner_hdc")
NO_FAV, SLIGHT, STRONG_LABEL = "no favourite", "slight favourite", "strong favourite (|SUP| >= 0.75)"


# ------------------------------------------------------------------ labels
def side_groups(family, side, fav_sign) -> np.ndarray:
    """Bet type x side, the side read against the kick-off favourite (home / away when there is none)."""
    fam = pd.Series(np.asarray(family, dtype=object)).astype("string").fillna("other")
    sd = pd.Series(np.asarray(side, dtype=object)).astype("string").fillna("?").to_numpy(dtype=object)
    sgn = np.nan_to_num(np.asarray(fav_sign, dtype="float64"))
    f = fam.to_numpy(dtype=object)
    out = (fam + ":all").to_numpy(dtype=object)
    tot = np.isin(f, TOTAL_FAMILIES)
    team = np.isin(f, TEAM_FAMILIES)
    h, a, d = sd == "H", sd == "A", sd == "D"
    for mask, tag in ((tot & h, ":over"), (tot & a, ":under"),
                      (team & ((h & (sgn > 0)) | (a & (sgn < 0))), ":favourite"),
                      (team & ((h & (sgn < 0)) | (a & (sgn > 0))), ":underdog"),
                      (team & (sgn == 0) & h, ":home"), (team & (sgn == 0) & a, ":away"),
                      (team & d, ":draw")):
        if mask.any():
            out[mask] = (fam[mask] + tag).to_numpy(dtype=object)
    return out


def clock_label(minute) -> np.ndarray:
    m = np.nan_to_num(np.asarray(minute, dtype="float64"))
    out = np.full(len(m), CLOCK[-1][2], dtype=object)
    for lo, hi, lab in reversed(CLOCK):
        out[(m >= lo) & (m < hi)] = lab
    out[m < 0] = CLOCK[0][2]
    return out


def strength_label(fav_sign, sup_ko) -> np.ndarray:
    """From the favourite the features use (fav_sign): no favourite there is no favourite here."""
    sgn = np.nan_to_num(np.asarray(fav_sign, dtype="float64"))
    a = np.abs(np.nan_to_num(np.asarray(sup_ko, dtype="float64")))
    return np.where(sgn == 0, NO_FAV, np.where(a >= STRONG, STRONG_LABEL, SLIGHT)).astype(object)


def who_label(fav_sign, home, away) -> np.ndarray:
    """Whose event it was: the kick-off favourite's or the underdog's (a corner for, a red card against)."""
    sgn = np.nan_to_num(np.asarray(fav_sign, dtype="float64"))
    h, a = np.asarray(home, dtype=bool), np.asarray(away, dtype=bool)
    fav = (h & ~a & (sgn > 0)) | (a & ~h & (sgn < 0))
    dog = (h & ~a & (sgn < 0)) | (a & ~h & (sgn > 0))
    return np.where(sgn == 0, NO_FAV, np.where(fav, "favourite", np.where(dog, "underdog", "both"))).astype(object)


def state_label(fav_sign, home_goals, away_goals) -> np.ndarray:
    """The score after the event, against the kick-off favourite."""
    sgn = np.nan_to_num(np.asarray(fav_sign, dtype="float64"))
    diff = np.nan_to_num(np.asarray(home_goals, dtype="float64")) - np.nan_to_num(np.asarray(away_goals, dtype="float64"))
    lead = diff * sgn
    return np.where(diff == 0, "level", np.where(sgn == 0, "one side ahead",
                                                 np.where(lead > 0, "favourite ahead", "underdog ahead"))).astype(object)


# ------------------------------------------------------------------ model
@dataclass
class EventShift:
    prior_events: float = 30.0
    floor: float = 0.05
    cap: float = 20.0
    cells: Dict[str, Tuple[float, int]] = field(default_factory=dict)    # key -> (multiplier, events)
    meta: dict = field(default_factory=dict)

    @staticmethod
    def key(group: str, labels: Sequence[str]) -> str:
        return "|".join([str(group)] + [str(x) for x in labels])

    def fit(self, rows: pd.DataFrame) -> "EventShift":
        """``rows``: one per (event bucket, side group) - event_id, group, the LEVELS labels, y (money in
        the bucket), f (its forecast) and w (share of the bucket before the event)."""
        r = rows[["event_id", "group", *LEVELS, "y", "f", "w"]].copy()
        r["post"] = np.clip(r["y"].to_numpy(dtype="float64") - r["w"].to_numpy(dtype="float64") *
                            r["f"].to_numpy(dtype="float64"), 0, None)
        r["expo"] = (1.0 - r["w"].to_numpy(dtype="float64")) * r["f"].to_numpy(dtype="float64")
        r = r[np.isfinite(r["expo"]) & (r["expo"] > 0)]
        lam = float(self.prior_events)
        cells: Dict[str, Tuple[float, int]] = {}
        parent: Dict[str, Tuple[float, float]] = {}          # key -> (shrunk, raw)
        for depth in range(1, len(LEVELS) + 1):
            cols = ["group", *LEVELS[:depth]]
            g = r.groupby(cols, sort=False, observed=True).agg(post=("post", "sum"), expo=("expo", "sum"),
                                                               n=("event_id", "nunique")).reset_index()
            nxt: Dict[str, Tuple[float, float]] = {}
            for row in g.itertuples(index=False):
                vals = list(row[:len(cols)])
                raw = float(row.post) / float(row.expo)
                up_m, up_raw = (1.0, 1.0) if depth == 1 else parent.get(self.key(vals[0], vals[1:-1]), (1.0, 1.0))
                rel = float(np.clip(raw / up_raw, self.floor, self.cap)) if up_raw > 0 else 1.0
                m = float(np.clip(up_m * (row.n * rel + lam) / (row.n + lam), self.floor, self.cap))
                k = self.key(vals[0], vals[1:])
                cells[k] = (m, int(row.n))
                nxt[k] = (m, raw)
            parent = nxt
        self.cells = cells
        self.meta.update({"events": int(r["event_id"].nunique()), "rows": int(len(r)),
                          "fitted": time.strftime("%Y-%m-%d %H:%M")})
        return self

    def lookup(self, group: str, labels: Dict[str, str]) -> float:
        """The deepest fitted cell for one side group under one event; 1 where nothing was fitted."""
        for depth in range(len(LEVELS), 0, -1):
            hit = self.cells.get(self.key(group, [labels.get(l, "") for l in LEVELS[:depth]]))
            if hit is not None:
                return float(hit[0])
        return 1.0

    def multipliers(self, groups: np.ndarray, labels: Dict[str, str]) -> np.ndarray:
        groups = np.asarray(groups, dtype=object)
        out = np.ones(len(groups))
        for g in pd.unique(groups):
            out[groups == g] = self.lookup(g, labels)
        return out

    # ---------------------------------------------------------- persistence
    def to_dict(self) -> dict:
        return {"version": 1, "prior_events": self.prior_events, "floor": self.floor, "cap": self.cap,
                "levels": list(LEVELS), "meta": self.meta,
                "cells": {k: [round(m, 6), n] for k, (m, n) in sorted(self.cells.items())}}

    @classmethod
    def from_dict(cls, d: dict) -> "EventShift":
        s = cls(float(d.get("prior_events", 30.0)), float(d.get("floor", 0.05)), float(d.get("cap", 20.0)))
        s.cells = {k: (float(v[0]), int(v[1])) for k, v in (d.get("cells") or {}).items()}
        s.meta = dict(d.get("meta") or {})
        return s

    @staticmethod
    def default_path(settings) -> Path:
        return Path(settings.paths.models) / "turnover" / "EVENT_SHIFT.json"

    def save(self, path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=1, sort_keys=True), encoding="utf-8")
        tmp.replace(path)
        return path

    @classmethod
    def load(cls, path) -> Optional["EventShift"]:
        path = Path(path)
        if not path.exists():
            return None
        try:
            return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning("event shift %s not read: %s", path, exc)
            return None


# ------------------------------------------------------------- incidents
def incident_table(events: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Goals, red cards and corners (and their cancellations) as (match_id, time, kind, sign, side,
    provider): sign +1 an event, -1 its cancellation; side 1 home / 2 away."""
    cols = ["match_id", "t", "kind", "sign", "side", "provider"]
    if events is None or events.empty or "incident_type" not in events.columns:
        return pd.DataFrame(columns=cols)
    e = events.dropna(subset=["match_id", "incident_datetime", "incident_type"])
    if "is_deleted" in e.columns:
        e = e[~e["is_deleted"].fillna(False).astype(bool)]
    code = pd.to_numeric(e["incident_type"], errors="coerce").to_numpy()
    kind = np.full(len(e), "", dtype=object)
    sign = np.zeros(len(e))
    for k in PRIORITY:
        add, cancel = np.isin(code, EVENT_CODES[k]), np.isin(code, CANCEL_CODES[k])
        kind[add | cancel] = k
        sign[add], sign[cancel] = 1.0, -1.0
    keep = sign != 0
    out = pd.DataFrame({
        "match_id": pd.to_numeric(e["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()[keep],
        "t": pd.to_datetime(e["incident_datetime"]).astype("datetime64[ns]").to_numpy()[keep],
        "kind": kind[keep], "sign": sign[keep],
        "side": (pd.to_numeric(e["home_or_away"], errors="coerce").to_numpy()[keep]
                 if "home_or_away" in e.columns else np.full(int(keep.sum()), np.nan)),
        "provider": (pd.to_numeric(e["provider_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()[keep]
                     if "provider_id" in e.columns else np.ones(int(keep.sum()), dtype="int64"))})
    return out.sort_values(["match_id", "t"]).reset_index(drop=True)


def main_provider(inc: pd.DataFrame) -> pd.DataFrame:
    """Each match's incidents from the provider that reported the most of them."""
    if inc.empty:
        return inc
    best = inc.groupby(["match_id", "provider"]).size().reset_index(name="n")
    best = best.sort_values(["match_id", "n", "provider"], ascending=[True, False, True]).drop_duplicates("match_id")
    return inc.merge(best[["match_id", "provider"]], on=["match_id", "provider"], how="inner")
