@echo off
REM Algo E - train / serve parity on the real data: one bucket built the way training reads it
REM and the way the live engine serves it, every model input compared. Run after any change to
REM the data feed, the panel or the features, before trusting a model live.
REM     algoe-parity.bat --at "2026-09-10 21:30" --at "2026-09-11 00:05"
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe parity %*
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Identical.) else (echo DIFFERENT - do not serve until the listed features are fixed.)
pause
exit /b %CODE%
