"""
W16 desk tests - the live money feed check, every match on sale solved, the fast lane, the bucket money,
stage 2 on the desk

    python tests/test_w16_desk.py              plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_w16_desk.py

On the frozen simulator of test_algoe.py, without trained models (forecast = last bucket, belief = HKJC).

Change Log:
-----------
2026-11-19      Initialize
"""

import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from test_algoe import _FrozenSim  # noqa: E402

T0 = pd.Timestamp("2026-10-26 15:47:00")


def _engine(tmp, src, publish="off", workers=1, sets=()):
    from algoe.realtime.live_engine import LiveEngine
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
    s.set("optimizer.workers={}".format(workers))
    for assignment in sets:
        s.set(assignment)
    s.publish.mode = publish
    return LiveEngine(s, source=src)


# ------------------------------------------------------------------ live money feed
def test_sql_intent_readwrite_replaces_the_default_readonly():
    from src.core.exceptions import ExtractionError
    from src.hkjc.sql_source import SqlSource, with_intent
    base = "DRIVER={SQL Server};SERVER=X,1;DATABASE=QFM;ApplicationIntent=ReadOnly"
    rw = with_intent(base, "readwrite")
    assert rw.endswith("ApplicationIntent=ReadWrite") and rw.lower().count("applicationintent=") == 1
    assert with_intent(base, "readonly") == base
    assert with_intent("DRIVER={x};SERVER=y", "readonly").endswith("ApplicationIntent=ReadOnly")
    src = SqlSource(conn_qfm=base, conn_bis2=base, intent={"bis2": "readwrite"})
    assert src.dsn_for("bis2").endswith("ReadWrite") and src.dsn_for("qfm").endswith("ReadOnly")
    assert src.clone().intent["bis2"] == "readwrite"
    try:
        SqlSource(intent={"bis2": "primary"})
    except ExtractionError as exc:
        assert "ALGOE_SQL_INTENT_BIS2" in str(exc)
    else:
        raise AssertionError("an unknown intent was accepted")


class _MoneySource:
    """The live money query on one connection: a frame, or an error."""

    def __init__(self, frame, fail=None):
        self.frame, self.fail = frame, fail

    def read(self, key, sql, parse_dates=None):
        assert key == "bis2" and "ticket_bets_dtl_agg_mem" in sql
        if self.fail:
            raise RuntimeError(self.fail)
        return self.frame


def test_the_probe_compares_the_live_money_on_both_intents():
    from algoe.evaluation.live_probe import compare_intents, intent_verdict
    at = pd.Timestamp("2026-11-19 11:47:30")
    rows = pd.DataFrame({"start_sell_time": [at.floor("min") - pd.Timedelta(minutes=k) for k in range(8)],
                         "turnover": [100.0] * 8})
    empty = rows.iloc[0:0]
    got = compare_intents({"readonly": _MoneySource(empty), "readwrite": _MoneySource(rows)}, 5, at)
    status, check, msg = intent_verdict(got)
    assert (status, check) == ("FAIL", "intent") and "ALGOE_SQL_INTENT_BIS2=readwrite" in msg, msg
    rw = got["readwrite"]
    assert rw["rows"] == 8 and rw["money"] == 800.0
    assert rw["this_bucket"] == 300.0 and rw["last_bucket"] == 500.0       # 11:45-11:47 in, 11:40-11:44 before
    same = compare_intents({"readonly": _MoneySource(rows), "readwrite": _MoneySource(rows)}, 5, at)
    assert intent_verdict(same)[0] == "PASS"
    none = compare_intents({"readonly": _MoneySource(empty), "readwrite": _MoneySource(empty)}, 5, at)
    assert intent_verdict(none)[0] == "WARN"
    denied = compare_intents({"readonly": _MoneySource(rows), "readwrite": _MoneySource(rows, fail="login denied")},
                             5, at)
    assert intent_verdict(denied)[0] == "WARN" and "login denied" in intent_verdict(denied)[2]


def test_an_empty_money_feed_is_flagged_after_three_reads():
    from src.api import live_payload
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, _FrozenSim(T0, n_matches=2))
        for k in range(2):
            eng._money_check("sweep", 50000.0, 0.0, 3, T0 + pd.Timedelta(minutes=5 * k))
        assert eng.health()["money_feed"]["status"] != "empty"
        eng._money_check("scan", 50000.0, 0.0, 3, T0 + pd.Timedelta(minutes=11))
        h = eng.health()["money_feed"]
        assert h["status"] == "empty" and h["since"] == str(T0 + pd.Timedelta(minutes=11)), h
        b = live_payload.board(eng)
        assert b["health"]["money_feed"]["status"] == "empty"
        assert b["warnings"][0].startswith("live money feed empty"), b["warnings"]
        eng._money_check("scan", 50000.0, 120.0, 3, T0 + pd.Timedelta(minutes=12))
        assert eng.health()["money_feed"]["status"] == "ok"
        for k in range(5):                          # too little expected money never strikes
            eng._money_check("sweep", 100.0, 0.0, 1, T0 + pd.Timedelta(minutes=20 + k))
        assert eng.health()["money_feed"]["strikes"] == 0


def test_the_sweep_feeds_the_money_check():
    src = _FrozenSim(T0, n_matches=6)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        h = eng.health()["money_feed"]
        assert h["read"] == "sweep" and h["seen"] > 0 and h["status"] == "ok", h


# ------------------------------------------------------------------ every match on sale solved
def _far_sim(n_matches=6, days=2):
    """The frozen card with its first pre-match match moved ``days`` out: outside the 6-hour model window."""
    src = _FrozenSim(T0, n_matches=n_matches)
    p = src.snap.params
    mid = int(p[p["GameState"].astype(str).str.lower().str.contains("pre")]["match_id"].iloc[0])
    mi = src.snap.match_info
    mi.loc[mi["match_id"] == mid, "KOTime"] = T0 + pd.Timedelta(days=days)
    return src, mid


def test_a_far_match_on_sale_is_solved():
    src, far = _far_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        live = eng.matches[far]
        s = live.summary()
        assert live.decision is not None and s["status"] != "on sale", s["status"]
        assert s["far"] is True and s["theta_star"] and s["in_book"] > 0
        assert np.isfinite(live.rows["forecast"].to_numpy(dtype="float64")).all()
        others = [m for m, lv in eng.matches.items() if m != far and lv.rows is not None and lv.rows["forecastable"].any()]
        assert others and all(eng.matches[m].decision is not None for m in others)
        assert not any(eng.matches[m].summary()["far"] for m in others)


def test_far_forecast_blends_own_money_with_the_curve():
    from algoe.models.far_prematch import FarCurve
    c = FarCurve(anchors={"EPL": 1200.0}, anchor_default=300.0, k=3.0)
    assert abs(float(c.g(6.0)) - 1.0) < 1e-12 and float(c.g(48.0)) < float(c.g(12.0)) < 1.0
    prior = c.match_total(24.0, "EPL", 0.0, 0.0)
    assert abs(prior - 1200.0 * float(c.g(24.0))) < 1e-9
    many = c.match_total(24.0, "EPL", 12 * 500.0, 1000.0)          # HK$500 a bucket on a thousand tickets
    assert abs(many - 500.0) < 5.0
    one = c.match_total(24.0, "EPL", 1_000_000.0, 1.0)              # one HK$1M ticket: a quarter of its rate
    assert abs(one - (0.25 * 1_000_000.0 / 12 + 0.75 * prior)) < 1e-6
    assert FarCurve().match_total(24.0, None, 600.0, 2.0) == 50.0   # no anchor: the match's own money alone


def test_far_shares_follow_the_days_money_and_sum_to_one():
    from algoe.models.far_prematch import far_shares
    rows = pd.DataFrame({"match_id": [1, 1, 1, 1, 2, 2], "pool_id": [10, 10, 11, 11, 20, 20],
                         "family": ["goal_total", "goal_total", "goal_1x2", "goal_1x2", "goal_total", "goal_total"],
                         "odds": [1.9, 1.9, 2.0, 3.6, 1.8, 2.0], "rank_0": [1, 1, 1, 1, 1, 1]})
    flat = far_shares(rows, np.zeros(6), {})
    assert abs(flat[:4].sum() - 1.0) < 1e-9 and abs(flat[4:].sum() - 1.0) < 1e-9
    busy = far_shares(rows, np.array([9000.0, 1000.0, 0, 0, 0, 0]), {1: 10_000.0})
    assert busy[0] > 0.8 and busy[0] > 5 * busy[1]                # thousands of tickets: the day's own split


def test_fit_far_curve_recovers_a_known_decay():
    from algoe.models.far_prematch import fit_far_curve
    rng = np.random.default_rng(5)
    inv, ko = [], []
    for m in range(60):
        k = pd.Timestamp("2026-10-01 20:00") + pd.Timedelta(days=m // 3)
        lg, base = ("A", 4000.0) if m % 2 else ("B", 1000.0)
        ko.append({"match_id": m, "ko_time": k, "league_code": lg})
        for b in pd.date_range(k - pd.Timedelta(hours=72), k - pd.Timedelta(minutes=5), freq="5min"):
            h = (k - b).total_seconds() / 3600.0
            mu = base * (6.0 / max(h, 6.0)) ** 1.3 if h > 6 else base * 1.5
            y = rng.poisson(mu / 50.0) * 50.0
            if y > 0:
                inv.append({"match_id": m, "start_sell_time": b + pd.Timedelta(minutes=1), "turnover": y,
                            "ticket_count": max(1, int(y // 200))})
    curve = fit_far_curve(pd.DataFrame(inv), pd.DataFrame(ko), holdout_days=4)
    assert curve.source == "fitted" and curve.metrics["buckets"] > 0
    for h in (12.0, 24.0, 48.0):
        want = (6.0 / h) ** 1.3
        assert abs(float(curve.g(h)) - want) / want < 0.25, (h, float(curve.g(h)), want)
    assert curve.anchors["A"] > 2.5 * curve.anchors["B"]
    assert curve.metrics["wape"] < curve.metrics["wape_last5"]


def _priced_book():
    from algoe.pricing.pricer import BookPricer, BookRows, theta_from_params
    rows = BookRows(["goal"] * 9 + ["corner"] * 4,
                    ["three_way"] * 3 + ["total"] * 4 + ["handicap"] * 2 + ["total"] * 2 + ["handicap"] * 2,
                    [np.nan] * 3 + [2.5, 2.5, 3.5, 3.5, -0.5, -0.5, 9.5, 9.5, -1.5, -1.5],
                    ["H", "D", "A", "H", "L", "H", "L", "H", "A", "H", "L", "H", "A"])
    p, _ = BookPricer().probabilities(rows, theta_from_params(2.85, 0.45, 10.2, 1.1))
    return rows, 1.0 / (p * 1.06)                                       # a 6% margin on every price


def test_implied_theta_recovers_tg_and_sup():
    from algoe.pricing.implied_theta import implied_theta
    from algoe.pricing.pricer import BookRows
    rows, odds = _priced_book()
    tg, sup, rmse = implied_theta(rows, odds, "goal")
    assert abs(tg - 2.85) < 0.03 and abs(sup - 0.45) < 0.03 and rmse < 0.01, (tg, sup, rmse)
    ctg, csup, _ = implied_theta(rows, odds, "corner")
    assert abs(ctg - 10.2) < 0.1 and abs(csup - 1.1) < 0.1, (ctg, csup)
    assert implied_theta(BookRows(["goal"], ["total"], [2.5], ["H"]), np.array([1.9]), "goal") is None


def test_a_match_without_hkjc_tgsup_is_priced_at_implied_theta_and_never_published():
    import json
    src = _FrozenSim(T0, n_matches=6)
    p = src.snap.params
    mid = int(p[p["GameState"].astype(str).str.lower().str.contains("pre")]["match_id"].iloc[0])
    src.snap.params = p[p["match_id"] != mid].reset_index(drop=True)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=5)
        eng.run_sweep(T0)
        live = eng.matches[mid]
        assert live.decision is not None, live.summary()["status"]
        assert set(live.book.theta_source.values()) == {"implied"}
        assert live.summary()["theta_source"] == "implied"
        out = Path(tmp) / "publish" / "out"
        sent = [json.loads(line) for f in out.glob("*.jsonl") for line in f.read_text(encoding="utf-8").splitlines()]
        assert mid not in {m["event_id"] for m in sent}
        assert "implied" in (eng.publisher.matches[mid].last or {}).get("why", "")


def test_prematch_lines_with_old_odds_stay_in_the_live_book():
    src = _FrozenSim(T0, n_matches=6)
    p = src.snap.params
    mid = int(p[p["GameState"].astype(str).str.lower().str.contains("pre")]["match_id"].iloc[-1])
    o = src.snap.odds
    mine = pd.to_numeric(o["match_id"], errors="coerce") == mid
    o.loc[mine, "effective_datetime"] = pd.to_datetime(o.loc[mine, "effective_datetime"]) - pd.Timedelta(hours=3)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        assert eng.matches[mid].decision is not None and int(eng.matches[mid].rows["in_book"].sum()) > 0


def test_a_match_with_little_money_is_solved_and_held():
    src = _FrozenSim(T0, n_matches=6)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, sets=("optimizer.min_match_turnover=1e12",))
        eng.run_sweep(T0)
        decided = [lv.decision for lv in eng.matches.values() if lv.decision is not None]
        assert decided and not any(d.status.startswith("skipped") for d in decided)
        assert all(d.status.startswith(("solved", "kept board")) for d in decided)


def test_the_sweep_keeps_half_the_pool_free():
    import threading
    from concurrent.futures import Future
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    from test_algoe import _stress_book

    class Counted(Future):
        def __init__(self, pool):
            super().__init__()
            self.pool, self.taken = pool, False

        def result(self, timeout=None):
            if not self.taken:
                self.taken = True
                with self.pool.lock:
                    self.pool.live -= 1
            return super().result(timeout)

    class Pool:
        """Runs each task at once; a task counts as in flight until its result is collected."""
        def __init__(self):
            self.live, self.peak, self.lock = 0, 0, threading.Lock()

        def submit(self, fn, *args):
            with self.lock:
                self.live += 1
                self.peak = max(self.peak, self.live)
            f = Counted(self)
            f.set_result(fn(*args))
            return f

    books = []
    for i in range(6):
        b = _stress_book()
        b.match_id = 1000 + i
        books.append(b)
    pool = Pool()
    out = ThetaOptimizer(Settings()).optimize_card(books, mode="sweep", executor=pool, workers=4, max_in_flight=2)
    assert len(out) == 6 and pool.peak <= 2, pool.peak


def test_the_theta_age_alert_is_for_matches_in_play():
    from src.api.live_payload import _alerts
    pre = {"status": "solved", "theta_age_min": 7868.0, "in_play": False}
    assert not any("TG/SUP" in a["text"] for a in _alerts(pre))
    ip = {"status": "solved", "theta_age_min": 3.0, "in_play": True}
    assert any("TG/SUP" in a["text"] for a in _alerts(ip))


# ------------------------------------------------------------------ the fast lane
def _near_sim(n_matches=6, minutes=40):
    """The frozen card with its last pre-match match kicking off ``minutes`` after T0: inside the fast lane."""
    src = _FrozenSim(T0, n_matches=n_matches)
    p = src.snap.params
    pre = p[p["GameState"].astype(str).str.lower().str.contains("pre")]["match_id"].unique()
    near, other = int(pre[-1]), int(pre[0])
    mi = src.snap.match_info
    mi.loc[mi["match_id"] == near, "KOTime"] = T0 + pd.Timedelta(minutes=minutes)
    return src, near, other


def test_the_fast_lane_covers_in_play_and_the_last_90_minutes():
    src, near, other = _near_sim()
    at = T0 + pd.Timedelta(seconds=30)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        assert eng.lane(eng.matches[near], at) == "fast" and eng.lane(eng.matches[other], at) == "sweep"
        cyc = eng.run_fast_cycle(at)
        assert cyc["prematch"] == 1 and cyc["in_play"] >= 3 and not cyc["behind"], cyc
        assert eng.matches[near].refreshed_at == at and eng.matches[near].board_row["refreshed_at"] == str(at)
        assert eng.matches[other].refreshed_at == T0                   # 2 h out: the sweep's read stays


def test_the_fast_lane_runs_with_publishing_off():
    import time
    src, _, _ = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        assert not eng.publishing and eng.fast_source is not None
        calls = {"fast": 0}

        def fast(as_of=None):
            calls["fast"] += 1
            return {}
        eng.run_fast_cycle = fast
        eng.run_sweep = lambda as_of=None: {}
        eng.check_triggers = lambda as_of=None: []
        eng._focus_step = lambda as_of=None: []
        eng.last_sweep = {"bucket": "started"}
        eng.settings.live.fast_seconds = 0.05
        eng.start(poll_seconds=0.05)
        try:
            time.sleep(0.6)
            assert eng.fast_running and calls["fast"] >= 2, calls
        finally:
            eng.stop()


def test_a_fast_lane_match_before_kick_off_is_published_as_refresh():
    import json
    src, near, _ = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=5)
        eng.run_sweep(T0)
        out = Path(tmp) / "publish" / "out"

        def sent():
            return [json.loads(line) for f in sorted(out.glob("*.jsonl")) for line in f.read_text(encoding="utf-8").splitlines()]
        n0 = len(sent())
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=50)
        cyc = eng.run_fast_cycle(T0 + pd.Timedelta(seconds=45))
        later = sent()[n0:]
        assert cyc["published"] == len(later) and later, cyc
        updates = {m["event_id"]: m["update"] for m in later}
        assert all(u == ("refresh" if mid == near else "inplay") for mid, u in updates.items()), updates


def test_a_match_off_the_fast_lane_is_read_once_when_opened():
    src, near, other = _near_sim()
    at = T0 + pd.Timedelta(minutes=1)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        eng.request_focus(other)
        eng.request_focus(near)
        assert sorted(eng._focus_step(at)) == sorted([other, near])
        later = at + pd.Timedelta(seconds=eng.settings.live.focus_interval_seconds + 1)
        assert eng._focus_step(later) == [near]          # without the fast-lane thread the focus loop keeps it fresh


# ------------------------------------------------------------------ the bucket's money
def test_the_cockpit_shows_the_buckets_money():
    from src.api import live_payload
    src, near, _ = _near_sim()
    at = T0 + pd.Timedelta(minutes=1)                                   # 15:48, three minutes into 15:45
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        eng.request_focus(near)
        eng.run_focus(near, at)
        ck = live_payload.cockpit(eng, near)
    b = ck["bucket"]
    assert b["start"].startswith("2026-10-26T15:45") and b["end"].startswith("2026-10-26T15:50") and b["minutes"] == 5
    assert abs(b["elapsed_s"] - 180.0) < 1e-6 and b["horizon"] == "rest_and_next"
    assert abs(b["expected_total"] - (b["received"] + b["remaining"])) < 0.02
    assert abs(b["horizon_money"] - eng.matches[near].decision.turnover) < 0.02
    sels = [s for f in ck["book"]["families"] for p in f["pools"] for ln in p["lines"] for s in ln["selections"]
            if s["modelled"]]
    assert sels and all(abs(s["expected_total"] - ((s["observed"] or 0) + (s["remaining"] or 0))) < 0.02 for s in sels)


def test_the_scan_moves_the_money_of_matches_off_the_fast_lane():
    src, _, other = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        live = eng.matches[other]
        decision, before = live.decision, float(live.observed)
        inv = src.snap.investments
        row = inv[pd.to_numeric(inv["match_id"], errors="coerce") == other].iloc[-1].to_dict()
        col = next(c for c in ("start_sell_time", "IntervalTimeStart") if c in row)
        row[col] = T0 - pd.Timedelta(seconds=40)                      # 15:46:20, inside the 15:45 bucket
        money_col = next(c for c in ("turnover", "TotalInvestment") if c in row)
        row[money_col] = 25000.0
        src.add("investments", [row])
        eng.check_triggers(T0 + pd.Timedelta(seconds=10))
        assert live.observed >= before + 25000.0 - 1e-6 and live.money_at == T0 + pd.Timedelta(seconds=10)
        assert live.decision is decision                                # money only: no re-solve
        assert abs(live.board_row["observed_in_bucket"] - live.observed) < 1e-6


def test_the_liability_term_shortens_the_side_already_heavy():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    from test_algoe import _stress_book
    bk = _stress_book()
    bk.received = np.zeros(bk.n)
    bk.received[2] = 200_000.0                                           # Over 2.5 already took a lot
    s = Settings()
    plain = ThetaOptimizer(s)._stage2(bk, bk.odds_now.copy(), "sweep", [])
    s.optimizer.liability_lambda = 5.0
    risk = ThetaOptimizer(s)._stage2(bk, bk.odds_now.copy(), "sweep", [])
    assert risk[2] < plain[2] - 1e-4, (risk[2], plain[2])
    s.optimizer.liability_lambda = 0.0
    assert np.allclose(ThetaOptimizer(s)._stage2(bk, bk.odds_now.copy(), "sweep", []), plain)


# ------------------------------------------------------------------ stage 2: damped, guarded, shown
def _stage2(bk, sets=(), mode="sweep"):
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    for assignment in sets:
        s.set(assignment)
    opt = ThetaOptimizer(s)
    return opt, opt._stage2(bk, bk.odds_now.copy(), mode, [])


def _line_sums(bk, w):
    from algoe.optimizer.theta_optimizer import _line_groups
    lg = _line_groups(bk)
    u = 1.0 / (bk.odds_now * w)
    return {int(g): float(u[lg == g].sum()) for g in np.unique(lg) if (lg == g).sum() >= 2}


def _moving_book():
    """A book whose stage 2 moves some weighting well past 2 points when nothing holds it back."""
    from test_algoe import _stress_book
    for spike in (30.0, 100.0, 300.0, 1000.0):
        bk = _stress_book(spike=spike)
        _, w = _stage2(bk, ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.1"))
        if np.max(np.abs(w - 1.0)) > 0.03:
            return bk
    raise AssertionError("no stress book moves stage 2")


def test_stage2_steps_at_most_the_sweep_cap_from_the_last_weights():
    bk = _moving_book()
    free = ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.1", "optimizer.weighting_adjust=1")
    _, w_free = _stage2(bk, free)
    bk.w_prev = np.ones(bk.n)
    _, w_cap = _stage2(bk, free + ("optimizer.weighting_max_step_sweep=0.02",))
    assert np.max(np.abs(w_free - 1.0)) > 0.03 and np.max(np.abs(w_cap - 1.0)) <= 0.02 + 1e-9


def test_partial_adjustment_moves_halfway_and_keeps_each_lines_overround():
    bk = _moving_book()
    bk.w_prev = np.ones(bk.n)
    base = ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.1", "optimizer.weighting_max_step_sweep=1")
    _, full = _stage2(bk, base + ("optimizer.weighting_adjust=1",))
    _, half = _stage2(bk, base + ("optimizer.weighting_adjust=0.5",))
    u0, uf, uh = 1.0 / bk.odds_now, 1.0 / (bk.odds_now * full), 1.0 / (bk.odds_now * half)
    moved = np.abs(uf - u0) > 1e-6
    assert moved.any() and np.allclose((uh - u0)[moved], 0.5 * (uf - u0)[moved], atol=1e-6)
    want = _line_sums(bk, np.ones(bk.n))
    for w in (full, half):
        got = _line_sums(bk, w)
        assert all(abs(got[g] - want[g]) < 1e-6 for g in want), (got, want)


def test_a_deadband_keeps_the_last_weights():
    bk = _moving_book()
    bk.w_prev = np.ones(bk.n)
    bk.w_prev[0] = 1.01
    _, w = _stage2(bk, ("optimizer.weighting_min_gain_bps=1e9",))
    assert abs(w[0] / w[1] - 1.01) < 1e-9                              # HILO 2.25: the tilt kept, refitted
    assert np.allclose(np.delete(w, [0, 1]), 1.0)
    want, got = _line_sums(bk, np.ones(bk.n)), _line_sums(bk, w)
    assert all(abs(got[g] - want[g]) < 1e-9 for g in want)


def test_one_big_ticket_moves_the_rest_of_the_bucket_less_with_ticket_credibility():
    from algoe.realtime.nowcast import BucketNowcaster
    F, x, tk = np.array([1000.0, 1000.0]), np.array([100_000.0, 0.0]), np.array([1.0, 0.0])
    plain = BucketNowcaster(prior_minutes=2.0, max_hot=1000.0).update(F, x, 1.0)
    cred = BucketNowcaster(prior_minutes=2.0, max_hot=1000.0, ticket_k=3.0).update(F, x, 1.0, tickets=tk)
    many = BucketNowcaster(prior_minutes=2.0, max_hot=1000.0, ticket_k=3.0).update(
        F, x, 1.0, tickets=np.array([400.0, 0.0]))
    assert cred.remaining[0] < 0.5 * plain.remaining[0]                # one ticket: a quarter of its weight
    assert many.remaining[0] > 0.95 * plain.remaining[0]               # four hundred tickets: a rate


def test_the_weighting_market_guard_covers_every_line():
    from test_algoe import _stress_book
    bk = _stress_book()
    j = int(np.flatnonzero(~np.isin(np.arange(bk.n), [0, 1]))[0])
    bk.is_main = np.zeros(bk.n, dtype=bool)
    bk.odds_mkt = np.full(bk.n, np.nan)
    bk.odds_mkt[j] = bk.odds_now[j]
    odds = bk.odds_now.copy()
    odds[j] *= 1.05                                                     # beats the market on a side line
    opt_all, _ = _stage2(bk, ("optimizer.weighting_market_lines=all",))
    opt_main, _ = _stage2(bk, ("optimizer.weighting_market_lines=main",))
    assert opt_all._market_guard(bk, odds, bk.odds_now) > 0 and opt_main._market_guard(bk, odds, bk.odds_now) == 0
    assert opt_all._market_guard(bk, bk.odds_now, bk.odds_now) == 0    # the stage-1 prices never violate it


def test_weight_churn_is_the_mean_change_of_shared_weightings():
    from algoe.optimizer.theta_optimizer import weight_churn
    assert np.isnan(weight_churn(None, {(1, 1, 1): 1.02}))
    prev = {(1, 1, 1): 1.00, (1, 1, 2): 1.00, (1, 2, 1): 1.01}
    now = {(1, 1, 1): 1.02, (1, 1, 2): 0.98, (9, 9, 9): 1.03}
    assert abs(weight_churn(prev, now) - 0.02) < 1e-12


def test_the_cockpit_shows_each_selections_weighting():
    from algoe.optimizer.theta_optimizer import _line_groups
    from src.api import live_payload
    src, near, _ = _near_sim()
    at = T0 + pd.Timedelta(minutes=1)
    with tempfile.TemporaryDirectory() as tmp:
        # the deadband keeps the last weightings, so the tilt set below is what the refresh carries
        eng = _engine(tmp, src, sets=("optimizer.weighting_min_gain_bps=1e9", "optimizer.weighting_market_lines=main"))
        eng.run_sweep(T0)
        live = eng.matches[near]
        bk = live.book
        # a goal line off the main one, a tenth of a point each way: the goal block is clear of the probability
        # band (a tilt there would break it and reset the pool, as it should)
        assert not any(x.startswith("goal:prob_band") for x in live.decision.binding), live.decision.binding
        lg = _line_groups(bk)
        dom = np.asarray(bk.rows.theta_domain).astype(str)
        goal = [g for g in np.unique(lg) if (lg == g).sum() == 2 and (dom[lg == g] == "goal").all()]
        a, b = np.flatnonzero(lg == ([g for g in goal if not bk.is_main[lg == g].any()] or goal)[0])
        keys = [(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"])) for _, k in bk.keys.iterrows()]
        live.weights = {k: (1.001 if i == a else 0.999 if i == b else 1.0) for i, k in enumerate(keys)}
        eng.request_focus(near)
        eng.run_focus(near, at)
        ck = live_payload.cockpit(eng, near)
        bk, dec = live.book, live.decision
        stage1_kept = dec.status.startswith("kept") or dec.status == "solved (weightings only)"
        odds1 = bk.odds_now if stage1_kept else eng.optimizer.prices(bk, dec.theta_star)[0]
    row = {(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"])): i for i, k in bk.keys.iterrows()}
    lines = [ln for f in ck["book"]["families"] for p in f["pools"] for ln in p["lines"]
             if any(s["in_book"] for s in ln["selections"])]
    assert lines
    moved = 0
    for ln in lines:
        sels = [s for s in ln["selections"] if s["in_book"]]
        for s in sels:
            i = row[(int(s["pool_id"]), int(s["line_id"]), int(s["comb_id"]))]
            assert abs(s["weighting"] - dec.weights[i]) < 1e-5
            assert abs(s["implied_now"] - 1.0 / bk.odds_now[i]) < 1e-5
            assert abs(s["implied_stage1"] - 1.0 / odds1[i]) < 1e-5
            assert abs(s["implied_star"] - 1.0 / (odds1[i] * dec.weights[i])) < 1e-5
            moved += abs(s["weighting"] - 1.0) > 1e-4
        if len(sels) >= 2:
            assert abs(sum(s["implied_star"] for s in sels) - sum(s["implied_stage1"] for s in sels)) < 1e-5
    assert moved >= 2, "no weighting moved: the checks above prove nothing"


# ------------------------------------------------------------------ W16 review: failure paths
class _Alive:
    """A fast-lane thread that is running."""

    def is_alive(self):
        return True

    def join(self, timeout=None):
        return None


def test_a_broken_pool_finishes_the_card_here():
    from concurrent.futures import Future
    from concurrent.futures.process import BrokenProcessPool
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    from test_algoe import _stress_book

    class Breaks:
        """Solves the first match; then a worker dies and every later submit raises."""
        _max_workers = 4

        def __init__(self):
            self.n = 0

        def submit(self, fn, *args):
            self.n += 1
            if self.n > 1:
                raise BrokenProcessPool("a child process terminated abruptly")
            f = Future()
            f.set_result(fn(*args))
            return f

    class DiesMidTask(Breaks):
        def submit(self, fn, *args):
            f = Future()
            f.set_exception(BrokenProcessPool("a child process terminated abruptly"))
            return f

    books = []
    for i in range(5):
        b = _stress_book()
        b.match_id = 2000 + i
        books.append(b)
    for pool in (Breaks(), DiesMidTask()):
        out = ThetaOptimizer(Settings()).optimize_card(books, mode="sweep", executor=pool, workers=4, max_in_flight=1)
        assert sorted(out) == [2000, 2001, 2002, 2003, 2004], (type(pool).__name__, sorted(out))


def test_the_engine_replaces_a_broken_pool():
    import algoe.realtime.live_engine as le

    class Dead:
        _broken = "A child process terminated abruptly"
        down = False

        def shutdown(self, wait=True, cancel_futures=False):
            Dead.down = True
    fresh = object()
    real = le.process_pool
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, _FrozenSim(T0, n_matches=2), workers=2)
        le.process_pool = lambda n: fresh
        try:
            eng._executor = Dead()
            assert eng._pool() is fresh and Dead.down
            assert eng._pool() is fresh                                # a sound pool is kept
        finally:
            le.process_pool = real
            eng._executor = None


def test_stale_weightings_unwind_at_the_cap_through_optimize_match():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer, _line_groups, _refit_overround
    from algoe.settings import Settings
    bk = _moving_book()
    s = Settings()
    for assignment in ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.05"):
        s.set(assignment)
    opt = ThetaOptimizer(s)
    want = opt.optimize_match(bk, "sweep").weights
    assert np.max(np.abs(want - 1.0)) > 0.02                           # the solve wants to move
    bk.w_prev = np.clip(2.0 - want, 0.95, 1.05)                         # the opposite tilt: the market turned
    dec = opt.optimize_match(bk, "sweep")
    odds1 = dec.odds_star / dec.weights
    lg = _line_groups(bk)
    fixed = (np.bincount(lg)[lg] < 2) | ~np.isfinite(odds1)
    start = np.clip(_refit_overround(odds1, bk.w_prev, lg, fixed), 0.95, 1.05)
    start[fixed] = 1.0
    assert np.max(np.abs(start - 1.0)) > s.optimizer.weighting_max_step_sweep + 1e-3
    assert np.max(np.abs(dec.weights - start)) <= s.optimizer.weighting_max_step_sweep + 1e-9, \
        np.max(np.abs(dec.weights - start))
    assert np.max(np.abs(dec.weights - 1.0)) > 1e-6                     # unwinding, not reset to theta*


def test_a_little_money_hold_keeps_the_last_weightings():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    from test_algoe import _stress_book
    bk = _stress_book(demand_scale=0.01)                                # HK$320 in all: under min_match_turnover
    bk.w_prev = np.ones(bk.n)
    bk.w_prev[0], bk.w_prev[1] = 1.02, 0.98                             # HILO 2.25 Over / Under
    d = ThetaOptimizer(Settings()).optimize_match(bk, "sweep")
    assert d.status == "kept board (little money)" and d.theta_star == d.theta_now
    assert abs(d.weights[0] / d.weights[1] - 1.02 / 0.98) < 1e-9 and np.allclose(np.delete(d.weights, [0, 1]), 1.0)
    assert abs(np.sum(1.0 / (bk.odds_now[:2] * d.weights[:2])) - np.sum(1.0 / bk.odds_now[:2])) < 1e-9
    assert np.allclose(d.odds_star, bk.odds_now * d.weights)


def test_last_weightings_that_break_the_market_guard_go_back_to_theta_star():
    from test_algoe import _stress_book
    bk = _stress_book()
    bk.odds_mkt = bk.odds_now.copy()                  # the market sits on HKJC's prices: nothing may go past them
    bk.w_prev = np.ones(bk.n)
    bk.w_prev[0], bk.w_prev[1] = 1.03, 0.97
    opt, _ = _stage2(bk, ("optimizer.weighting_market_lines=all", "optimizer.weighting_max_step_sweep=0.005"))
    binding = []
    w = opt._stage2(bk, bk.odds_now.copy(), "sweep", binding)
    pool = bk.pool == bk.pool[0]
    assert np.allclose(w[pool], 1.0) and any("weighting_reset" in b for b in binding), (w[pool], binding)
    assert opt._market_guard(bk, bk.odds_now * w, bk.odds_now) == 0


def _unwinding():
    """A book whose last weightings lean the way the money no longer backs, and an optimizer for it."""
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    bk = _moving_book()
    s = Settings()
    for assignment in ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.05"):
        s.set(assignment)
    opt = ThetaOptimizer(s)
    bk.w_prev = np.clip(2.0 - opt.optimize_match(bk, "sweep").weights, 0.95, 1.05)
    return bk, opt


def test_a_chained_unwind_goes_out_rather_than_jump_to_one():
    import dataclasses
    bk, opt = _unwinding()
    dec = opt.optimize_match(bk, "sweep")
    # stage 1 held at HKJC's theta: what can go out is the board's theta with these weightings, or the board
    held = dataclasses.replace(dec, theta_star=dict(dec.theta_now), status="kept board (no feasible improvement)")
    q = opt.quantize(bk, held, 2, 2, 0.005)
    tilted = q.weights != 1.0
    assert q.egm < q.egm_board, (q.egm, q.egm_board)                   # the unwind scores below the board...
    assert q.chosen == "theta*" and tilted.any(), q.chosen               # ...and still goes out, step by step
    assert np.allclose(q.weights[tilted], np.round(held.weights, 2)[tilted])
    for fresh in (None, np.ones(bk.n)):                                  # a fresh tilt that loses never goes out
        bk.w_prev = fresh
        q0 = opt.quantize(bk, held, 2, 2, 0.005)
        assert q0.chosen == "board" and np.all(q0.weights == 1.0), fresh


def test_one_pools_broken_board_does_not_drop_the_other_pools_weightings():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    from test_algoe import _stress_book
    bk = _stress_book()
    # under min_odds on HKJC's own board, further than a capped step of weightings can mend
    bk.odds_now[int(np.flatnonzero(bk.pool == "CHLO")[0])] = 0.95
    bk.w_prev = np.ones(bk.n)
    bk.w_prev[0], bk.w_prev[1] = 1.01, 0.99                             # HILO 2.25 Over / Under
    d = ThetaOptimizer(Settings(), free_dims=[]).optimize_match(bk, "sweep")      # stage 1 holds the board
    hilo = bk.pool == "HILO"
    assert d.theta_star == d.theta_now and np.any(np.abs(d.weights[hilo] - 1.0) > 1e-6), (d.status, d.weights)
    assert np.allclose(d.weights[bk.pool == "CHLO"], 1.0)


def test_a_stale_tilt_unwinds_through_the_deadband():
    from algoe.optimizer.theta_optimizer import _line_groups, _refit_overround
    bk, _ = _unwinding()
    _, w = _stage2(bk, ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.05",
                        "optimizer.weighting_min_gain_bps=1e9"))          # no gain is ever enough to move
    lg = _line_groups(bk)
    fixed = np.bincount(lg)[lg] < 2
    start = np.clip(_refit_overround(bk.odds_now, bk.w_prev, lg, fixed), 0.95, 1.05)
    start[fixed] = 1.0

    def tilt(x):
        return float(np.sum(np.abs(np.log(x))))
    assert tilt(w) < tilt(start) - 1e-6, (tilt(w), tilt(start))


def test_a_last_tilt_past_the_band_is_mended_inside_the_cap_not_reset():
    bk = _moving_book()
    _, wide = _stage2(bk, ("optimizer.weighting_ridge=0", "optimizer.weighting_band=0.1"))
    bk.w_prev = wide                                                    # past 3 points: past the band below
    opt, _ = _stage2(bk, ("optimizer.weighting_ridge=0",))
    binding = []
    w = opt._stage2(bk, bk.odds_now.copy(), "sweep", binding)
    leaning = np.abs(bk.w_prev - 1.0) > 0.03
    assert leaning.any() and not any("weighting_reset" in b for b in binding), binding
    assert np.all(np.abs(w[leaning] - 1.0) > 0.01), w[leaning]


def test_a_match_the_sweep_does_not_reach_keeps_its_last_weightings():
    src = _FrozenSim(T0, n_matches=6)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        mid = next(m for m, lv in eng.matches.items() if lv.weights)
        tilted = {k: 1.01 for k in eng.matches[mid].weights}
        eng.matches[mid].weights = dict(tilted)
        real = eng.optimizer.optimize_card
        eng.optimizer.optimize_card = lambda books, **kw: {m: d for m, d in real(books, **kw).items() if m != mid}
        eng.run_sweep(T0)
        assert eng.matches[mid].weights == tilted


def test_the_sweep_leaves_a_fast_lane_match_to_the_fast_lane():
    src, near, other = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        at = T0 + pd.Timedelta(seconds=30)
        eng.run_fast_cycle(at)
        live = eng.matches[near]
        dec, row, w = live.decision, live.board_row, dict(live.weights)
        eng._fast_thread = _Alive()
        later = T0 + pd.Timedelta(seconds=60)                           # a sweep that read after the fast lane
        eng.run_sweep(later)
        assert live.decision is dec and live.board_row is row and live.weights == w
        assert live.refreshed_at == at and live.forecast is not None
        assert eng.matches[other].refreshed_at == later                  # off the fast lane: the sweep's


def test_the_scans_money_check_counts_only_the_model_window():
    src, far = _far_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        far_money = float(np.nansum(eng.matches[far].rows["forecast"].to_numpy(dtype="float64")))
        inwin = sum(float(np.nansum(lv.rows.loc[lv.rows["forecastable"].astype(bool), "forecast"]))
                    for m, lv in eng.matches.items() if m in eng.card and lv.rows is not None)
        eng.check_triggers(T0 + pd.Timedelta(seconds=10))
        h = eng.health()["money_feed"]
    assert far_money > 0, "the far match expects no money: the check below proves nothing"
    assert h["read"] == "scan" and abs(h["expected"] - inwin) < 1e-6, (h, inwin, far_money)


def _far_history(burst: bool):
    """Two matches a day for 14 days, money steady in each match; the last four days (the holdout) at HK$1000 a
    bucket, with ``burst`` a HK$60K ticket every 13th bucket that the trailing hour then overstates."""
    rng = np.random.default_rng(11)
    inv, ko = [], []
    for m in range(28):
        day = m // 2
        k = pd.Timestamp("2026-10-01 20:00") + pd.Timedelta(days=day)
        ko.append({"match_id": m, "ko_time": k, "league_code": "A"})
        test = day >= 10
        base = 1000.0 if test else float(rng.choice([300.0, 1000.0, 3000.0]))
        for j, b in enumerate(pd.date_range(k - pd.Timedelta(hours=24), k - pd.Timedelta(minutes=5), freq="5min")):
            y, t = base, 4
            if test and burst and j % 13 == 0:
                y, t = base + 60_000.0, 5
            inv.append({"match_id": m, "start_sell_time": b + pd.Timedelta(minutes=1), "turnover": y,
                        "ticket_count": t})
    return pd.DataFrame(inv), pd.DataFrame(ko)


def test_the_far_curves_k_is_chosen_without_the_holdout():
    from algoe.models.far_prematch import fit_far_curve
    calm = fit_far_curve(*_far_history(burst=False), holdout_days=4)
    noisy = fit_far_curve(*_far_history(burst=True), holdout_days=4)
    assert calm.k == noisy.k, (calm.k, noisy.k)                         # the holdout only scores it
    assert calm.metrics["scored_on"] == "holdout" and noisy.metrics["wape"] != calm.metrics["wape"]


def test_a_started_match_that_turns_implied_says_our_message_stays():
    src = _FrozenSim(T0, n_matches=6)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=5)
        eng.run_sweep(T0)
        started = [m for m, mp in eng.publisher.matches.items() if mp.started]
        assert started
        mid = started[0]
        p = src.snap.params
        src.snap.params = p[pd.to_numeric(p["match_id"], errors="coerce") != mid].reset_index(drop=True)
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=400)
        eng.run_sweep(T0)
        why = eng.publisher.matches[mid].last["why"]
    assert "implied" in why and "stays on the engine" in why, why


def test_a_match_without_a_book_says_why():
    from src.api import live_payload
    src = _FrozenSim(T0, n_matches=6)
    p = src.snap.params
    mid = int(p[p["GameState"].astype(str).str.lower().str.contains("pre")]["match_id"].iloc[0])
    src.snap.params = p[p["match_id"] != mid].reset_index(drop=True)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        opts = eng._book_options()
        eng._book_options = lambda: dict(opts, implied=False)          # as if the board gave no implied fit
        eng.run_sweep(T0)
        row = next(r for r in live_payload.board(eng)["matches"] if r["match_id"] == mid)
    assert row["status"] == "no book", row["status"]
    assert any(a["text"].startswith("no book: no HKJC TG/SUP for goal") for a in row["alerts"]), row["alerts"]


def test_the_w16_settings_refuse_negative_values():
    from algoe.settings import ConfigError, Settings
    for key in ("live.money_feed_min_expected", "live.theta_age_alert_inplay_min", "live.nowcast_ticket_k",
                "optimizer.max_odds_age_live_prematch_min", "optimizer.liability_lambda",
                "optimizer.weighting_max_step", "optimizer.weighting_max_step_sweep",
                "optimizer.weighting_market_band", "optimizer.weighting_min_gain_bps"):
        s = Settings()
        s.set("{}=-1".format(key))
        try:
            s.check()
        except ConfigError as exc:
            assert key in str(exc), (key, str(exc))
        else:
            raise AssertionError("{} accepted -1".format(key))


def test_the_payload_says_which_far_curve_serves():
    from src.api import live_payload
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, _FrozenSim(T0, n_matches=2))
        assert eng.models()["far_curve"]["source"] == "default"
        eng.run_sweep(T0)
        assert live_payload.board(eng)["models"]["far_curve"]["source"] == "default"


def test_the_sweep_hands_the_optimizer_half_the_pool():
    src = _FrozenSim(T0, n_matches=4)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)

        class Stub:
            _max_workers = 8
        eng._executor = Stub()
        seen = {}
        real = eng.optimizer.optimize_card

        def spy(books, **kw):
            seen.update(kw)
            return real(books, mode=kw["mode"])
        eng.optimizer.optimize_card = spy
        try:
            eng.run_sweep(T0)
        finally:
            eng._executor = None
    assert seen["mode"] == "sweep" and isinstance(seen["executor"], Stub) and seen["max_in_flight"] == 4, seen


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<72} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<72} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
