@echo off
REM Algo E - bring Raw_Data up to now with the queries of hkjc_code\1 Data Extraction.ipynb.
REM From the day before the newest day every table has: monthly tables a whole month at a time,
REM Match_Investments a day at a time; each file replaces the old one only once it is complete.
REM Then the cached panel and feature days from that day are dropped and built again.
REM     algoe-update-data.bat                     from the day before the newest day on disk to now
REM     algoe-update-data.bat --dry-run           print what it would extract, change nothing
REM     algoe-update-data.bat --from 2026-09-01   extract again from that day
REM     algoe-update-data.bat --report            then refresh the W10 backtest report through yesterday
REM Task Scheduler (algoe-schedule-update.bat) passes --unattended: no pause at the end.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe update-data %*
set CODE=%ERRORLEVEL%
echo.
echo %* | find /i "--dry-run" >nul && (echo Dry run: nothing was extracted.) && goto :end
if "%CODE%"=="0" (echo Raw_Data is up to date.) else if "%CODE%"=="2" (echo Finished with a warning - read the lines above.) else (echo NOT COMPLETE - a file that FAILED kept its old version, the others were updated. Run it again once SQL answers. The log is under AlgoE_Work\logs next to Raw_Data.)
:end
echo %* | find /i "--unattended" >nul || pause
exit /b %CODE%
