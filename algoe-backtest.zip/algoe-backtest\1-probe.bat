@echo off
REM Step 1: check the data. Reads parquet metadata only, finishes in seconds.
setlocal
cd /d "%~dp0"
set "DATA=%~1"
if not defined DATA set "DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data"
echo Probing "%DATA%"
python -m backtest.run probe --data-dir "%DATA%" --out-dir "out"
echo.
echo Read out\probe.txt before running the backtest.
pause
