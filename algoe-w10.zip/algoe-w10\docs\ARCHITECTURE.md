# Algo E W10 - architecture

## The loop

Every 5-minute bucket, for every live match: **forecast** the money each selection will take,
**believe** a win probability for each selection that does not come from HKJC's own theta,
**search** the eight TG/SUP parameters, re-running demand at every candidate price, and
**score** each candidate by expected gross margin `E[GM] = sum demand x (1 - offer x belief)`.
Between buckets, for the matches a trader has open, the same loop runs every ~15 s with the
money already in the bucket.

## Folders

```
backend/
    algoe/                      the library (this document)
        core/                   settings-free plumbing: exceptions, logging, validation, taxonomy, calendar, io
        settings.py             every tunable number, one dataclass per layer
        data/                   panels (historical, live), day splits, synthetic world, replay source
        features/               catalog (features + hypotheses), engineer, encoders, feature store
        models/                 estimators, TurnoverForecaster, ProbabilityCalibrator
        pricing/                score-grid pricer, in-play conventions, panel pricing
        optimizer/              ThetaOptimizer, demand response, books
        realtime/               LiveEngine, nowcaster
        backtest/               Backtester
        evaluation/             metrics, train/serve parity
        monitoring/             Monitor
        registry/               ModelStore
        reporting/              HTML report pieces
        cli.py, __main__.py     python -m algoe <command>
        selftest.py             the whole chain on a world with known truth
    scripts/sNN_*.py            one numbered wrapper per CLI command, in pipeline order
    src/                        the W06-W08 desk (API, SQL / capture / sim sources, parquet engine)
    tests/test_algoe.py         unit tests (pytest or plain python)
deploy/algoe-*.bat              office-box launchers
docs/                           this, RUNBOOK, FEATURES, HKJC_CODE_REVIEW
package-algoe.ps1               builds dist/algoe-w10 (selftest-gated)
```

**Layering** (an import may only point down): `realtime`, `backtest`, `cli` -> `optimizer` ->
`pricing`; `models` -> `features` -> `data` -> `core`. `algoe` wraps the W06 parquet engine
(`src/backtest/parquet`: loader, per-day panel cache); that engine never imports `algoe`, so the
workbench keeps working unchanged. The desk API (`src/api/routes/live.py`) is the one place `src`
imports `algoe`.

## Data flow

```
TRAINING                                              SERVING (live engine)
Raw_Data parquet                                      SQL / capture / sim / replay snapshot
  -> HistoricalPanel (W06 per-day cache)                -> LivePanelBuilder  (same W06 build_day,
       + contract validation                                 same start odds across midnight,
                                                            same contract, same one-hour tail)
  -> FeatureEngineer.prepare_day(panel, tail, ...)      -> FeatureEngineer.prepare_live(panel, extra)
  -> FeatureStore (per day, per feature version)            (calls prepare_day the same way)
  -> features_for_* -> estimators                       -> features_for_* -> champion models
                                                        -> build_books -> ThetaOptimizer
                                                        -> board / match view / monitor log
```

**One row** = (bucket T, pool_id, line_id, combination_id): the price known at the start of T
and the money that arrived in `[T, T+5)`. A row is `forecastable` only if it was priced before
T and inside the pre-match window or in play; rows that merely took money are labels, never
feature rows.

**Parity is tested, not assumed.** `evaluation/parity.py` builds one bucket through both
columns above - the serving path from Raw_Data replayed as of the bucket start, so it cannot
see inside the bucket - and compares every model input of all five feature sets row by row.
Identical inputs mean no train/serve skew and no leak. The selftest runs it on every build;
`python -m algoe parity --at ...` runs it on the real data. It found six real problems during
W10, all fixed: odds age measured at the end of the bucket (a leak); the event provider chosen
with later goals (a leak); first-half pools kept alive after half time; a live selling start
rounded up a bucket, so lines looked five minutes younger; start odds lost across midnight;
money-today and lags split at midnight differently from training.

## The classes and their verbs

Method names follow `verb_[algorithm]_[response or source]`, so a reader can find any piece
from its name.

**`FeatureEngineer`** (`features/engineer.py`)
`prepare_day`, `prepare_live`; `features_for_turnover_match_total`,
`features_for_turnover_pool_share`, `features_for_turnover_selection_share`,
`features_for_turnover_selection`, `features_for_probability`; `fit_encoders`.
Features are grouped (money history, events, lifecycle, calendar, concurrency, price, line
position, bet type, popularity), each with the hypothesis it tests (`features/catalog.py`,
listed in `FEATURES.md`).

**`TurnoverForecaster`** (`models/turnover.py`)
`train_{glm,gam,gbm,nn}_{match_total,pool_share,selection_share,selection_turnover}`,
`train_naive_profile`; `predict_match_total`, `predict_pool_share`, `predict_selection_share`,
`predict_selection_turnover`, `predict_remaining_bucket`; `evaluate_match_total`,
`evaluate_pool_share`, `evaluate_selection_share`, `evaluate_selection_turnover`;
`train_all`, `refit_for_serving`, `write_backtest_series`, `save`, `load`.

**`ProbabilityCalibrator`** (`models/probability.py`)
`train_{platt,beta,isotonic}_{hkjc_true,market,...}`, `train_logit_pool`, `train_contextual`,
`train_stack` (trader -> market -> customer layers);
`predict_true_prob`, `predict_for_day`; `train_all`, `refit_for_serving`, `save`, `load`.

**`ThetaOptimizer`** (`optimizer/theta_optimizer.py`)
`prices`, `demand_at` (selection split + pool volume), `expected_gm`, `optimize_match` (stage 1
theta, stage 2 weightings), `optimize_card`; `build_books` turns a bucket's rows into one
`MatchBook` per match; `desk_weightings` states a decision in the desk's
`fair / (1 + margin) x weighting` terms.

**`Backtester`** (`backtest/backtester.py`)
`compare_turnover`, `compare_trueprob`, `compare_optimizer`, `compare_gm`,
`compare_feature_groups`, `check_replication`, `run_all`, `render`.

**`LiveEngine`** (`realtime/live_engine.py`)
`run_sweep`, `run_focus`, `check_triggers`, `step`, `start`, `stop`, `focus_on`, `focus_off`,
`trigger`, `board`, `match_view`.

**`Monitor`** (`monitoring/monitor.py`) `log_forecasts`, `join_realised`, `health_from_frames`,
`feature_reference`, `drift`, `novelty`, `write_health`.
**`ModelStore`** (`registry/model_store.py`) `save`, `load`, `champion`, `promote`,
`promote_if_better`, `list`.

## Modelling decisions

**Turnover.** The response is decomposed as
`selection money = match total x pool share x selection share` (the three-stage pipelines),
and also modelled directly (`direct:` pipelines); each piece has its own features and loss:
Tweedie / Poisson deviance with a log link for money, multinomial-style shares with exposure.
Estimators: penalised-IRLS GLM (scale-invariant ridge), GAM (P-splines), GBM (LightGBM, or
sklearn's HistGradientBoosting), NN (torch, optional), and the anchored GLM + GBM / GLM + NN.
Every model carries log(exposure) as an offset; LightGBM through `init_score`, exact for any
Tweedie power (fitting the rate y / exposure with exposure as the weight is exact only for
Poisson). Each pipeline may be blended toward last 5 minutes, with the weight chosen on
validation days. Days are split by calendar (train | val | test, never random); the champion is
the lowest validation deviance, reported once on test with WAPE (selection, match, active
selections), bias, bias on the biggest 1% of matches, Diebold-Mariano against last 5 minutes
and days better / worse. A bundle is promoted only if it beats last 5 minutes and the current
champion on the same validation days.

**Market size.** Money features are divided by a market index - the median daily turnover of
the last 28 cached days ending two days before the day - and the match-total and direct models
carry the index as exposure (forecast = index x model). A market that grows or shrinks does
not shift the inputs, a tree never extrapolates in HK$, and the labels and baselines stay in
HK$. Two days, not one: the live engine starts the day before the nightly has built yesterday,
and both paths must divide by the same number (parity checks it).

**Bigger than anything seen.** The index handles the market as a whole, not one match bigger
than any in training (a World Cup final): a tree predicts a constant past its last split, and
a network's output there is an accident of its activations (its inputs are held to the training
range, so it saturates like a tree). The anchored models (`glm_gbm`, `glm_nn`) fit the GBM or
network on top of the GLM's linear predictor: inside the training range the inner model learns
what the GLM misses; past it the money levels (`m_log_*`, `p_log_*`, `s_log_*`, `pos_log_*`,
`log_board_*`) carry the GLM's log-linear trend, capped at 10x the value at the edge, while every
other input is held at its edge (a weekday or pool count the GLM never saw says nothing about
size). On a test world with matches 1.6-7x bigger than any in training, plain GBM and NN forecast
75% too little and the anchored models were within 2-3%, with the same deviance inside the range.
The champion rule serves the anchored twin of a plain gbm / nn winner when it is within 1% on
validation. Within a day the match effect (a match's own money so far) also pulls any forecast
toward a big match after its first buckets; the anchor fixes the first buckets too.

**Lines that move.** Each line's rank in its pool is set by how balanced its prices are (rank 0 =
the best line, where the market centres); every selection has a slot - offset from the best line
in quarter goals, and side. Memory is kept per slot as well as per line id (`pos_*`), across
midnight, so when the market re-centres in play (2.5 / 3.5 becomes 1.5 / 2.5) the new line
inherits its slot's money instead of starting from zero (`line_new` marks it). The model is
blended toward `last5_hybrid`: a line's own last bucket, its slot's only for a line not priced a
bucket ago that took nothing of its own (`turnover.blend_base`). The slot alone (`last5_pos`)
lost to the line's own money on every office test day: once a line has money, money follows
the line, not its offset.

**Unknowns.** Leagues and pools are target-encoded with empirical-Bayes shrinkage to their
parent (league -> global; pool x phase -> family x phase -> global), so an unseen league or
pool code gets its parent's level, never an error or a random code. The encoders read every
cached day in the two years before the validation days, evidence halving every 180 days, and
every refit relearns them: a new league or bet type has its own level from the first refit after
it appears, and one that has not played for months drifts back toward its parent. Pool codes the
taxonomy has never seen are placed by their spelling (`core/taxonomy.py`) and confirmed in
`config/pools.json`. Within a day, a match's own money updates a shrunk match effect, so a new
league learns in hours.

**Calendar.** Hong Kong's general holidays are computed for any year (`core/hk_holidays.py`: the
Chinese calendar from new moons and solar terms in UTC+8, Easter, Ching Ming, the Sunday and
coincidence rules); the holidays file adds a one-off day or removes one.

**Belief.** Settled selections only, with the soft outcome `(r+1)/2` for quarter lines and
pushes dropped; live prices only (a withdrawn line keeps a stale quote). Every source (HKJC
true odds, external market median, Poisson from HKJC's theta with the in-play score shift,
de-margined odds) x every method (raw, Platt, beta, isotonic, logit pool, contextual), fitted
on train days, chosen on validation log-loss, renormalised within each line. The stacked model
builds the final belief in three layers, each fitted on top of the one before (its logit is the
next layer's offset), so each layer's gain is reported on its own: trader (HKJC's sources,
calibrated by phase, bet type and price level), market (how far to move toward the bookmakers'
consensus, by phase, bet type and quote age), customer (weight of money - a side's share of its
line's money against its price -, ticket size against its pool's, liquidity, recent price moves).
Interactions use the best HKJC source a row has (true odds, else Poisson, else de-margined).
Every method is also scored by money (stake-weighted log-loss and ECE, expected minus realised
margin), because the optimiser's E[GM] is a sum over money; a stake-weighted stack competes, and
`probability.champion_metric` can choose by money. Poisson-from-theta is empty for extra-time
pools (theta is full time) and cached per day beside the features.

**Pricing and in-play.** One score grid per (TG, SUP) collapsed to total / difference
marginals, one effective-probability formula for whole, half and quarter lines. In play,
HKJC's `Goal90CurrentTG` is goals still to come, so full-match lines are priced on the grid
shifted by the current score; `check_replication` confirms this convention reproduces HKJC's
own board for every pool.

**Optimizer.** `price_mode = delta`: our offer is HKJC's posted odds moved by our model's
relative price change, `O(theta) = O_now x p(theta_now) / p(theta)`, so the lift measures the
theta decision alone. Demand at a candidate price comes from the turnover model's own price
terms, renormalised within each pool - only if those terms make a longer price take more money
at evens with and without a market price. History does not always measure demand: HKJC shortens
a price after money arrives, so a share model fitted on rows without HKJC true odds or a market
price can learn that longer prices take less (the office model: -0.43 at evens without a market
price). Then the optimiser uses a fixed elasticity instead and says so. A block without HKJC's
TG / SUP (or CTG / CSUP) is left alone rather than priced at a default theta.
Guards: a trust band around HKJC's theta, a max step
from the previous recommendation, coherence (first half inside the full match, |SUP| <= TG),
a per-selection probability band, and the external market as a cap on main-line offers.
theta_now is always a candidate, so a recommendation is never worse than HKJC's theta under
the model. Books are split into independent blocks (goal / corner x FT / FH) so each
evaluation prices only what the moved dimensions touch.

A pool's total money follows its price level: `exp(-e x change in log overround)`, with
`e = 1 / margin` by default (`volume_response = neutral`) - the elasticity at which HKJC's own
margin is the volume-optimal one. The history cannot measure this elasticity cleanly (margins are
policy, and big matches carry both lower margins and more money), so the default assumes HKJC
prices its margin well rather than letting the optimiser chase margin; `fixed` or `none`
override it.

Stage 2 is the local layer: with theta* fixed, a weighting per selection
(`O = O(theta*) x w`, the desk's `fair / (1 + margin) x weighting`), each within +-3%, each line
keeping HKJC's overround, no cross-line arbitrage (an over is never shorter than the over of a
lower line; handicaps likewise), neighbouring lines' weightings on the same side penalised for
differing and every weighting for leaving 1, max 1% per focus refresh. It is solved pool by pool
and kept only where it beats theta* alone; the backtest reports the two lifts separately.

## Real time and compute

| Loop | When | What | Cost (synthetic card of 9-12 matches) |
|------|------|------|------|
| sweep | every bucket boundary | the whole card: forecast, belief, theta* for every match with expected money above `optimizer.min_match_turnover`, richest first, inside `optimizer.budget_seconds`, in a process pool | 4.7-5.9 s |
| focus | every `live.focus_interval_seconds` (15 s) for matches open on the desk (heartbeat, 3-minute TTL) or hit by a trigger | re-fetch that match only; nowcast the rest of the bucket; re-optimise from the last answer with one start and a max step | 0.6-1.2 s per match |
| triggers | every focus interval, whole card, cheap | goal / red card; main-line price move > `live.trigger_odds_move`; one minute's money > `live.trigger_big_bet_multiple` x the forecast minute | tens of ms |

**Nowcast** (`realtime/nowcast.py`): with bucket forecast F and money x after e minutes, the
rate is `(F/5 x m0 + x) / (m0 + e)` - a Gamma-Poisson update where the forecast counts as m0
minutes of evidence - applied at match level and spread over its selections, so
`remaining = rate x (5 - e)`. The next bucket's forecast is scaled by how hot this one runs.
Money arrives in tickets, not as a smooth stream, so the rate is capped at
`live.nowcast_max_hot` (4) x the forecast rate: one HK$1M ticket a minute into a HK$50k bucket
raises the rest of the bucket to HK$160k, not HK$1.36M, and the next bucket at most 2x.

**Guards on theta\***: within `optimizer.theta_band` of HKJC's theta (focus: also within
`max_step` of the last answer), TG >= |SUP| and first half <= full time, every price within
`prob_band` of the board, main lines no longer than the market, and never below the board's
E[GM]. A match expecting less than `min_match_turnover` is not solved. The optimizer moves theta
for `optimizer.pools` (default `@theta_lines`: every FT / FH goal and corner line market, team
totals included); `test_optimizer_with_no_money_and_with_a_flood` pins the behaviour at zero money
and at 100x / 10,000x on one selection.

## Validation, logging, traceability

- **Contracts** (`core/validation.py`): every panel (historical and live) passes the same
  column rules - type coercion, sentinels (odds 9999) to null, ranges clipped or nulled, required
  fills (unknown pool name -> `UNKNOWN`), duplicate keys counted - and a report is logged.
- **Logging** (`core/logging.py`): every stage is a boxed `STEP` with a `[PASS]`/`[FAIL]` line
  and its timing, to the console, a text log and a JSON-lines log with the data behind each line.
- **Runs**: every CLI command writes `AlgoE_Work/runs/<stamp>_<command>/` with the resolved
  settings and a summary (exit code, error, headline numbers).
- **Versions**: `FEATURE_VERSION` keys the feature store and is stamped on every model;
  the store refuses a bundle whose checksum or feature version does not match, and a champion
  on older features cannot block a promotion.

## Tests

| Layer | Where | Runs |
|-------|-------|------|
| unit | `backend/tests/test_algoe.py` | pricer vs legacy, quarter-line settlement, team totals vs closed-form Poisson, HK holidays for any year (vs the gazette and, where installed, a century of python-holidays tables), a new line inheriting its slot's money, money features unchanged when the market doubles, GLM recovers rates, save / load, unseen encodings and pool codes, pool rules, date split, validation, pool close times, nowcast (incl. one big ticket), optimizer at zero money and under a flood (stage 2: band, overround kept, ladder arbitrage-free), volume response keeps HKJC's margin, settings, model store guards, PSI, goal-pulse time consistency, CLI parsing |
| system | `python -m algoe selftest` | 11 checks on a generated world, including train/serve parity and a live sweep + focus |
| real data | `python -m algoe parity` | train/serve parity on Raw_Data |
| desk | `backend/tests/test_optimizer.py`, `contract.py` | the W06 desk still serves every field the UI reads |

## Extending

- **A new feature**: add it in the engineer's group method, add a `FeatureSpec` (group,
  hypothesis, fill, clip) to `features/catalog.py`, bump `FEATURE_VERSION`, run the selftest
  (parity must stay identical) and the backtest (`compare_feature_groups` says what it is worth).
- **A new estimator**: subclass `Estimator` (`fit`, `predict`, `to_state`, `from_state`), register it,
  add `train_<algo>_<response>` methods and a pipeline name; it joins the leaderboard.
- **A new response or pipeline**: a `ResponseSpec` (builder, family, exposure) and a pipeline
  string such as `three_stage:gbm+glm+gbm`.
- **A new pool code or league**: nothing to code (see RUNBOOK section 5).
