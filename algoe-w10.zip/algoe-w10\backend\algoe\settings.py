"""
Settings

Every knob Algo E has, in one place, grouped by the layer that reads it.
Nothing else in the library holds a tunable constant.

Precedence, lowest to highest:

    1. the defaults below
    2. a JSON settings file   (--settings PATH, or env ALGOE_SETTINGS)
    3. environment            (ALGOE_DATA_DIR, ALGOE_WORK_DIR)
    4. command line           (--set optimizer.theta_band.goal_tg=0.8, repeatable)

``Settings.save`` writes the resolved result next to every run's output, so
any number in a report can be traced back to exactly the settings that made
it.

Paths default to folders BESIDE Raw_Data, never inside the code folder: the
parquet and everything derived from it stay on the office box, and a code
update (unzip over the old folder) never touches trained models.

    <Algo E>/Raw_Data              the extraction output (read only)
    <Algo E>/algoe_panel_cache     the W06 per-day panel cache (shared)
    <Algo E>/Backtest_Data         the workbench's series folders (shared)
    <Algo E>/AlgoE_Work            this library: models, features, reports, logs

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Paths made absolute in check(); monitor.drift_skip_groups; panel.pools by rule (default
                line markets + 1X2); window.val_start / test_start; max_fit_rows caps
2026-10-11      live: corners trigger too; trigger_focus_seconds; event_shift
"""

from __future__ import annotations

import copy
import json
import os
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .core.exceptions import ConfigError
from .core.taxonomy import RULES_VERSION

DEFAULT_DATA_DIR = r"S:\Users\Yeung\20260520 Algo E\Raw_Data"
THETA_DIMS = ("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup", "corner_tg", "corner_sup", "corner_fh_tg",
              "corner_fh_sup")
ANCHOR_LAYERS = ("current", "basis", "model", "first_seen")


@dataclass
class PathSettings:
    data_dir: str = DEFAULT_DATA_DIR
    work_dir: str = ""              # default <data_dir>/../AlgoE_Work
    panel_cache_dir: str = ""       # default <data_dir>/../algoe_panel_cache
    backtest_data_dir: str = ""     # default <data_dir>/../Backtest_Data
    pool_overrides: str = ""        # default <work_dir>/config/pools.json
    holidays_file: str = ""         # default <work_dir>/config/holidays.txt

    def _base(self) -> Path:
        # abspath, not resolve(): resolve() turns the mapped S: drive into its UNC path
        return Path(os.path.abspath(os.path.expanduser(self.data_dir))).parent

    @property
    def work(self) -> Path:
        return Path(self.work_dir) if self.work_dir else self._base() / "AlgoE_Work"

    @property
    def panel_cache(self) -> Path:
        return Path(self.panel_cache_dir) if self.panel_cache_dir else self._base() / "algoe_panel_cache"

    @property
    def backtest_data(self) -> Path:
        return Path(self.backtest_data_dir) if self.backtest_data_dir else self._base() / "Backtest_Data"

    @property
    def models(self) -> Path:
        return self.work / "models"

    @property
    def features(self) -> Path:
        return self.work / "features"

    @property
    def reports(self) -> Path:
        return self.work / "reports"

    @property
    def logs(self) -> Path:
        return self.work / "logs"

    @property
    def monitor(self) -> Path:
        return self.work / "monitor"

    @property
    def pools_file(self) -> Path:
        return Path(self.pool_overrides) if self.pool_overrides else self.work / "config" / "pools.json"

    @property
    def holidays(self) -> Path:
        return Path(self.holidays_file) if self.holidays_file else self.work / "config" / "holidays.txt"


@dataclass
class WindowSettings:
    """Which days are used for what. Splits are by calendar day, never random.

    By dates (both set): train [start, val_start), val [val_start, test_start), test
    [test_start, end]. Otherwise by counts: the last test_days days with data are test,
    the val_days before them val, the rest train."""
    start: str = "2026-07-01"
    end: str = "2026-09-15"
    val_start: str = ""             # e.g. "2025-07-01"
    test_start: str = ""            # e.g. "2026-07-01"
    val_days: int = 7               # just before the test block: model choice, blend weight
    test_days: int = 14             # last days: touched once, for the reported numbers
    min_train_days: int = 14
    walk_forward_warmup_days: int = 14
    walk_forward_refit_days: int = 7


@dataclass
class PanelSettings:
    """Knobs that shape the cached panel. Changing one opens a new cache space."""
    bucket_minutes: int = 5
    # Pool codes, or rules matched against what each code is (core/taxonomy.py POOL_RULES), so a new
    # code joins on the day it appears. Default: every goal / corner total and handicap (what theta
    # prices) plus 1X2 (the match's main money). [] = every pool in the feed - correct score, scorer
    # and next-goal pools too, which is several times the rows.
    pools: List[str] = field(default_factory=lambda: ["@line_markets", "@three_way"])
    # build-panel / build-features: months in parallel processes. Each holds one month of raw odds and
    # money in memory (a few GB on the office data), so set it by RAM. 0 = cores - 1, at most 4.
    workers: int = 1
    prematch_window_min: int = 360
    lookback_days: int = 2
    true_prob_source: str = "auto"
    normalize_book: bool = True
    hdc_sign: str = "home"                           # home | flip


@dataclass
class FeatureSettings:
    lag_buckets: int = 6
    ewma_alpha: float = 0.5
    goal_pulse_taus: List[float] = field(default_factory=lambda: [3.0, 10.0])
    red_pulse_tau: float = 10.0
    ko_knots: List[float] = field(default_factory=lambda: [0, 5, 10, 15, 30, 45, 60, 90, 120, 180, 240, 360])
    minute_knots: List[float] = field(default_factory=lambda: [5, 15, 30, 40, 45, 50, 60, 70, 80, 88, 95])
    # empirical-Bayes strength: evidence needed before a group moves halfway from its parent
    league_prior: float = 50.0       # match-buckets
    pool_prior: float = 300.0        # selection-buckets
    team_prior: float = 150.0        # match-buckets of the team (about two matches), shrunk to its league
    match_prior: float = 4.0         # buckets, for the in-day match effect
    match_prior_new_league: float = 1.5
    # The encoders learn from every cached day this far back before the validation days, older
    # evidence counting less (half-life), so a league or bet type gets its own level as soon as it has
    # data and a seasonal league is not forgotten by a short refit window.
    encoder_history_days: int = 730
    encoder_half_life_days: float = 180.0     # 0 = every day counts the same
    # Money features are divided by the market's size, so a growing or shrinking market does not move
    # them: the median daily turnover of the last market_index_days cached days ending two days before
    # the day (yesterday is not built yet when the live engine starts after midnight), over the
    # reference. build-panel builds that many days before the window too.
    market_index_days: int = 28
    market_index_reference: float = 1e8
    # weight of money: prior stake, in reference-market HK$, that a line's money is shrunk toward
    wom_prior: float = 2000.0


@dataclass
class TurnoverSettings:
    responses: List[str] = field(default_factory=lambda: [
        "match_total", "pool_share", "selection_share", "selection_turnover", "board_total", "match_share"])
    # glm_gbm / glm_nn: a GBM / MLP on top of the GLM's linear predictor (models/estimators.py, EXTRAPOLATION)
    algorithms: List[str] = field(default_factory=lambda: [
        "naive", "glm", "gam", "gbm", "xgb", "cat", "nn", "glm_gbm", "glm_xgb", "glm_cat", "glm_nn"])
    # composed selection forecasts that get a leaderboard row; each needs its library (skipped without it:
    # gbm lightgbm or scikit-learn, xgb xgboost, cat catboost, nn torch)
    pipelines: List[str] = field(default_factory=lambda: [
        "last5", "last5_hybrid", "last5_pos", "ma3", "ema",
        "direct:glm", "direct:gbm", "direct:glm_gbm", "direct:xgb", "direct:cat", "direct:nn", "direct:glm_nn",
        "three_stage:glm+glm+glm", "three_stage:gam+glm+glm", "three_stage:gbm+gbm+gbm",
        "three_stage:gbm+glm+glm", "three_stage:glm_gbm+gbm+gbm", "three_stage:glm_gbm+glm+glm",
        "three_stage:xgb+xgb+xgb", "three_stage:glm_xgb+xgb+xgb", "three_stage:cat+cat+cat",
        "three_stage:glm_cat+cat+cat",
        "three_stage:nn+nn+nn", "three_stage:glm_nn+nn+nn", "three_stage:glm_gbm+nn+nn",
        # the board's money, then each match's share of it (matches compete for the same money)
        "four_stage:gbm+gbm+gbm+gbm", "four_stage:glm+gbm+gbm+gbm",
    ])
    # A tree (or a network on clipped inputs) stops at its biggest training value; the anchored twin of a
    # gbm / nn level follows the GLM's trend past it. The twin is served when its validation deviance is
    # within this fraction of the winner's (0 = always the plain winner).
    extrapolation_tolerance: float = 0.01
    # past the training range an anchored model goes at most this many times beyond its edge value
    extrapolation_cap: float = 10.0
    # What a model forecast is blended toward on the validation days:
    #   hybrid   - the line's own last bucket; a line just opened with no money of its own takes its
    #              slot's (offset from the best line, side) instead of a zero
    #   position - the slot's last bucket for every line (lost to line on the office data: money follows
    #              a line that carries on)
    #   line     - last bucket's money on the same line id (the W06 baseline)
    blend_base: str = "hybrid"
    tweedie_power: float = 1.5
    ridge: float = 1e-3
    fit_rows_per_day: int = 60000           # selection rows sampled per training day
    max_fit_rows: int = 2_000_000           # per response and role over all days; the daily sample shrinks to fit
    blend_alphas: List[float] = field(default_factory=lambda: [0.0, 0.25, 0.5, 0.75, 1.0])
    selection_metric: str = "poisson_deviance"   # what picks the champion
    gam_knots: int = 8
    gam_lambdas: List[float] = field(default_factory=lambda: [0.1, 1.0, 10.0])
    gbm: Dict[str, Any] = field(default_factory=lambda: {
        "n_estimators": 400, "learning_rate": 0.05, "num_leaves": 31,
        "min_child_samples": 200, "subsample": 0.8, "colsample_bytree": 0.8,
        "reg_lambda": 1.0, "early_stopping_rounds": 40})
    nn: Dict[str, Any] = field(default_factory=lambda: {
        "hidden": [64, 32], "dropout": 0.1, "epochs": 30, "batch_size": 4096,
        "lr": 2e-3, "patience": 4})
    xgb: Dict[str, Any] = field(default_factory=lambda: {
        "n_estimators": 600, "learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1.0,
        "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0, "early_stopping_rounds": 40})
    cat: Dict[str, Any] = field(default_factory=lambda: {
        "iterations": 800, "learning_rate": 0.08, "depth": 6, "l2_leaf_reg": 3.0, "early_stopping_rounds": 40})
    seed: int = 7


@dataclass
class ProbabilitySettings:
    sources: List[str] = field(default_factory=lambda: ["hkjc_true", "market", "poisson", "demargin"])
    methods: List[str] = field(default_factory=lambda: [
        "raw", "platt", "beta", "isotonic", "logit_pool", "contextual", "stack", "stack_money"])
    # How settled rows are weighted when a calibrator is fitted:
    #   selection - every settled selection counts once, however long it traded
    #   money     - weighted by turnover, i.e. calibrate where the money is
    weight: str = "selection"
    ridge: float = 1.0
    min_fit_rows: int = 200
    max_fit_rows: int = 2_000_000           # settled selections per role over all days
    min_market_books: int = 1
    # log_loss: every settled selection counts once. money_log_loss: weighted by the money each took - how
    # good the belief is where the optimiser's E[GM] is decided (noisier: a few big bets weigh a lot)
    champion_metric: str = "log_loss"


@dataclass
class OptimizerSettings:
    # trust region around HKJC's own theta for this bucket
    theta_band: Dict[str, float] = field(default_factory=lambda: {
        "goal_tg": 0.60, "goal_sup": 0.50, "goal_fh_tg": 0.35, "goal_fh_sup": 0.30,
        "corner_tg": 2.00, "corner_sup": 1.50, "corner_fh_tg": 1.20, "corner_fh_sup": 0.90})
    # largest move from the previous recommendation in one focus refresh
    max_step: Dict[str, float] = field(default_factory=lambda: {
        "goal_tg": 0.15, "goal_sup": 0.15, "goal_fh_tg": 0.10, "goal_fh_sup": 0.10,
        "corner_tg": 0.50, "corner_sup": 0.40, "corner_fh_tg": 0.30, "corner_fh_sup": 0.25})
    # delta: HKJC's posted odds moved by our model's relative price change (lift = theta edge only)
    # absolute: our pricer + margin table (needs the replication check to pass)
    price_mode: str = "delta"
    # a line whose price has not moved for this long is treated as withdrawn
    max_odds_age_prematch_min: float = 90.0
    max_odds_age_inplay_min: float = 10.0
    min_odds: float = 1.01
    max_odds: float = 500.0
    prob_band: float = 0.05          # |1/our odds - 1/HKJC odds| cap per selection; 0 = off
    # moving one dimension by its whole theta_band must earn at least this share of the money at
    # stake (1e-4 = 1 bp); dimensions the money is indifferent to then stay at HKJC's value
    stay_cost: float = 1e-4
    market_cap: bool = True          # main-line offer may not beat the best external price
    # demand response to price: share_model (turnover share model's price terms),
    # fixed (t' = t * (O'/O)^elasticity, renormalised in the pool) or none
    demand: str = "share_model"
    fixed_elasticity: float = 1.0
    max_elasticity: float = 6.0
    # How a pool's total money reacts to its overall price level (its lines' overround) - a worse
    # board takes fewer bets, not only bets elsewhere:
    #   neutral  elasticity 1 / margin: the one at which HKJC's current margin is volume-optimal, so the
    #            optimiser never chases margin on an assumption the history cannot test
    #   fixed    volume_elasticity;  none: pool money fixed (only its split between selections moves)
    volume_response: str = "neutral"
    volume_elasticity: float = 0.0
    # Stage 2: a weighting per selection on top of theta* - the desk's sell = fair / (1 + margin) x
    # weighting. Each line keeps HKJC's overround (weighting_margin_band 0), so stage 2 moves margin
    # between sides and lines; no cross-line arbitrage; neighbours on the same side move together.
    weightings: bool = True
    weighting_band: float = 0.03          # each weighting within 1 +- this
    weighting_max_step: float = 0.01      # focus refresh: furthest from the last weighting
    weighting_margin_band: float = 0.0    # relative change a line's overround may take; 0 = HKJC's
    weighting_smoothness: float = 5.0     # penalty on neighbouring lines' (same side) weightings differing
    weighting_ridge: float = 1.0          # penalty on a weighting away from 1: no move without a gain
    starts_sweep: int = 3
    starts_focus: int = 1
    max_iter: int = 60
    min_match_turnover: float = 500.0   # expected money below this: keep HKJC theta, skip the solve
    budget_seconds: float = 200.0       # full sweep wall clock
    workers: int = 0                    # 0 = min(cpu - 1, 8)
    # Pools whose odds move with theta: codes and / or rules (see panel.pools). @theta_lines = every
    # 90-minute and first-half goal / corner line market, team totals included.
    pools: List[str] = field(default_factory=lambda: ["@theta_lines"])
    # In play, does a line settle on the whole match (goals already scored count)
    # or only on goals from here on? Per market; the replication check tests both.
    settle_total: str = "full_match"      # full_match | rest_of_match
    settle_handicap: str = "full_match"
    # Publishing: goals are priced with the match's Goal90DrawFactor, as the engine prices them. Without
    # publishing (the desk, the backtests) the draw factor stays 1.0.
    draw_factor: bool = True
    # The dimensions the optimiser may move. A first-half dimension left out follows its full-match one by
    # HKJC's own ratio for the bucket (the pricing engine derives the first half itself); publishing moves
    # publish.free_dims. Backtest the four: --set optimizer.free_dims=["goal_tg","goal_sup","corner_tg","corner_sup"]
    free_dims: List[str] = field(default_factory=lambda: [
        "goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup", "corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup"])
    # What the trust band is drawn around: current (HKJC's Current layer, the posted theta), basis / model
    # (that layer of algo_param, scaled to the clock in play), first_seen (HKJC's theta before Algo E's first
    # message for the match). Not current once our messages may become HKJC's Current layer.
    anchor_layer: str = "current"
    margins: Dict[str, float] = field(default_factory=lambda: {
        "HILO": 0.075, "HDC": 0.075, "CHLO": 0.10, "CHDC": 0.10, "FHLO": 0.085, "FHDC": 0.085,
        "HAD": 0.115, "FHAD": 0.115, "HHAD": 0.12, "_default": 0.09})


@dataclass
class LiveSettings:
    source: str = "sim"                 # sim | capture | sql | replay (historical Raw_Data as of a moment)
    data_lag_seconds: float = 0.0       # how far the investment feed trails the wall clock
    sweep_minutes: int = 5
    focus_interval_seconds: float = 15.0
    focus_ttl_seconds: float = 180.0    # a focus lapses without a UI heartbeat
    max_focus_matches: int = 12
    trigger_odds_move: float = 0.05     # relative move on a main-line price
    trigger_big_bet_multiple: float = 4.0   # one minute's money vs its expected minute
    trigger_events: List[str] = field(default_factory=lambda: ["goal", "red", "corner"])
    # how long a trigger keeps its match on focus refreshes (a desk heartbeat can keep it longer)
    trigger_focus_seconds: Dict[str, float] = field(default_factory=lambda: {
        "goal": 180.0, "red": 180.0, "corner": 60.0, "price": 60.0, "money": 60.0})
    event_shift: bool = True            # after an event, re-tune the rest of the bucket (models/turnover/EVENT_SHIFT.json)
    nowcast_prior_minutes: float = 2.0  # how much the bucket forecast weighs, in minutes of evidence
    nowcast_max_hot: float = 4.0        # one big ticket raises the rest-of-bucket money at most this many x
    publish_min_uplift: float = 0.0     # below this E[GM] gain the recommendation is not surfaced


@dataclass
class PublishSettings:
    """Publishing theta and weightings to HKJC's pricing engine (docs/specs/kafka-publish.spec.md).
    Endpoints, topics and credentials are environment variables on the office box, never settings."""
    # off | dry_run (file sink + mock engine) | test (test topics) | shadow (HKJC's theta to production,
    # theta* to the test topics) | live (theta* to production). ALGOE_PUBLISH sets it; shadow and live
    # also need ALGOE_PUBLISH set to that mode and AlgoE_Work/publish/CONFIRM-PRODUCTION.txt saying
    # "allow: <mode>". The desk can stop publishing, never start it.
    mode: str = "off"
    inplay_seconds: float = 15.0            # every in-play match is refreshed and published this often
    inplay_budget_seconds: float = 10.0     # the in-play cycle's solve budget; matches not reached go first next
    min_interval_seconds: float = 10.0      # at most one message per match this often
    free_dims: List[str] = field(default_factory=lambda: ["goal_tg", "goal_sup", "corner_tg", "corner_sup"])
    scope_leagues: List[str] = field(default_factory=list)     # [] = every league
    scope_matches: List[int] = field(default_factory=list)     # [] = every match
    scope_percent: float = 100.0            # of the rest, by a stable hash of the match id (A/B, rollout)
    scope_salt: str = "algoe"
    max_board_age_seconds: float = 90.0     # in play: a decision on an older read of the board is not sent
    max_board_age_prematch_seconds: float = 600.0   # pre-match: a sweep prices the board at the bucket start
    shadow_max_board_age_seconds: float = 20.0      # shadow: HKJC's theta goes to production only from a read this fresh
    reply_timeout_seconds: float = 10.0     # no reply this long: "no response"
    reply_order_slack_seconds: float = 2.0  # a reply computed this long before our newest message cannot answer it
    server_app_ids: List[str] = field(default_factory=lambda: ["E-HV11-01"])   # production replies from others: dropped ([] = any)
    clock_tolerance_seconds: float = 120.0  # the reply's clock against ours
    revert_guard: bool = True               # E[GM] on the engine's prices below the board's: send HKJC's theta
    revert_tolerance: float = 0.0           # HK$ below the board before the guard fires
    revert_tolerance_bps: float = 1.0       # ...or this share of the match's expected money, if larger (rounding)
    revert_minutes: float = 5.0
    gap_alert: float = 0.02                 # |1 / engine true odds - our probability| that raises an alert
    weight_overround_tolerance: float = 0.005
    msg_id_prefix: str = "ALGOE"
    shadow_test_copy: bool = True           # shadow: theta* to the test topics too, for engine prices
    mock_corner_dispersion: float = 1.0     # dry run: the mock engine's corners (1.52 plays the reply sample)
    audit_days: int = 14
    audit_raw: bool = False                 # keep every reply in full too (about 240 MB an hour on 40 matches)


PUBLISH_MODES = ("off", "dry_run", "test", "shadow", "live")


@dataclass
class MonitorSettings:
    rolling_days: int = 3
    wape_alert_ratio: float = 1.10      # model WAPE above 1.10 x last-5 WAPE
    bias_alert: float = 0.25            # |sum forecast / sum actual - 1|
    psi_alert: float = 0.25             # population stability index per feature
    # feature groups that move with the day's schedule by design; their drift is not a data problem
    drift_skip_groups: List[str] = field(default_factory=lambda: ["calendar", "lifecycle", "events", "concurrency"])
    ece_alert: float = 0.05
    min_rows: int = 500


def _scalar(text: str):
    """One item of a --set list: a number or true / false as JSON reads it, else the text."""
    try:
        return json.loads(text)
    except ValueError:
        return text


SECTIONS = {
    "paths": PathSettings, "window": WindowSettings, "panel": PanelSettings,
    "features": FeatureSettings, "turnover": TurnoverSettings,
    "probability": ProbabilitySettings, "optimizer": OptimizerSettings,
    "live": LiveSettings, "publish": PublishSettings, "monitor": MonitorSettings,
}


@dataclass
class Settings:
    paths: PathSettings = field(default_factory=PathSettings)
    window: WindowSettings = field(default_factory=WindowSettings)
    panel: PanelSettings = field(default_factory=PanelSettings)
    features: FeatureSettings = field(default_factory=FeatureSettings)
    turnover: TurnoverSettings = field(default_factory=TurnoverSettings)
    probability: ProbabilitySettings = field(default_factory=ProbabilitySettings)
    optimizer: OptimizerSettings = field(default_factory=OptimizerSettings)
    live: LiveSettings = field(default_factory=LiveSettings)
    publish: PublishSettings = field(default_factory=PublishSettings)
    monitor: MonitorSettings = field(default_factory=MonitorSettings)
    log_level: str = "INFO"

    # ------------------------------------------------------------ building
    @classmethod
    def load(cls, path: Optional[str] = None, overrides: Optional[List[str]] = None) -> "Settings":
        s = cls()
        path = path or os.environ.get("ALGOE_SETTINGS")
        if path:
            p = Path(path)
            if not p.exists():
                raise ConfigError("settings file {} does not exist".format(p))
            try:
                payload = json.loads(p.read_text(encoding="utf-8-sig"))     # Notepad may save a BOM
            except ValueError as exc:
                raise ConfigError("settings file {} is not valid JSON: {}".format(p, exc))
            s.update(payload)
        if os.environ.get("ALGOE_DATA_DIR"):
            s.paths.data_dir = os.environ["ALGOE_DATA_DIR"]
        if os.environ.get("ALGOE_WORK_DIR"):
            s.paths.work_dir = os.environ["ALGOE_WORK_DIR"]
        if os.environ.get("ALGOE_PUBLISH"):
            s.publish.mode = os.environ["ALGOE_PUBLISH"].strip().lower()
        for item in overrides or []:
            s.set(item)
        s.check()
        return s

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "Settings":
        """The inverse of to_dict(): how a worker process gets its parent's settings."""
        s = cls()
        s.update(payload)
        s.check()
        return s

    def update(self, payload: Dict[str, Any]) -> None:
        for section, values in (payload or {}).items():
            if section == "log_level":
                self.log_level = str(values)
                continue
            if section not in SECTIONS:
                raise ConfigError("unknown settings section {!r}; known: {}".format(
                    section, sorted(SECTIONS)))
            target = getattr(self, section)
            names = {f.name for f in fields(target)}
            for key, value in (values or {}).items():
                if section == "paths" and key == "resolved":      # derived by to_dict(), not a setting
                    continue
                if key not in names:
                    raise ConfigError("unknown setting {}.{}; known: {}".format(
                        section, key, sorted(names)))
                current = getattr(target, key)
                if isinstance(current, dict) and isinstance(value, dict):
                    merged = dict(current)
                    merged.update(value)
                    value = merged
                setattr(target, key, copy.deepcopy(value))

    def set(self, assignment: str) -> None:
        """``section.key=value`` or ``section.key.subkey=value``; value parsed as JSON if it can be. A list
        whose quotes cmd stripped on the way from a .bat (["ENG","ESP"] arrives as [ENG,ESP]) is read too."""
        if "=" not in assignment:
            raise ConfigError("--set expects section.key=value, got {!r}".format(assignment))
        lhs, rhs = assignment.split("=", 1)
        parts = lhs.strip().split(".")
        try:
            value = json.loads(rhs)
        except ValueError:
            value = rhs
            inner = rhs.strip()
            if inner.startswith("[") and inner.endswith("]"):
                value = [_scalar(x.strip()) for x in inner[1:-1].split(",") if x.strip()]
        if len(parts) == 2:
            self.update({parts[0]: {parts[1]: value}})
        elif len(parts) == 3:
            self.update({parts[0]: {parts[1]: {parts[2]: value}}})
        else:
            raise ConfigError("--set key must be section.key or section.key.subkey: {!r}".format(lhs))

    def check(self) -> None:
        # The panel cache is keyed by the data_dir string: "..\Raw_Data" and "S:\...\Raw_Data" would
        # be two caches of the same data. abspath, not resolve(): resolve() may turn the mapped S:
        # drive into its UNC path and miss the cache the workbench already built.
        p = self.paths
        for name in ("data_dir", "work_dir", "panel_cache_dir", "backtest_data_dir", "pool_overrides",
                     "holidays_file"):
            value = getattr(p, name)
            if value:
                setattr(p, name, os.path.abspath(os.path.expanduser(str(value))))
        w = self.window
        if w.val_days < 1 or w.test_days < 1:
            raise ConfigError("window.val_days and window.test_days must be >= 1")
        if bool(w.val_start) != bool(w.test_start):
            raise ConfigError("set both window.val_start and window.test_start, or neither")
        if w.val_start:
            try:
                start, val, test, end = (pd.Timestamp(x).normalize() for x in
                                         (w.start, w.val_start, w.test_start, w.end))
            except (ValueError, TypeError) as exc:
                raise ConfigError("window dates must be YYYY-MM-DD: {}".format(exc))
            if not start < val < test <= end:
                raise ConfigError("window needs start < val_start < test_start <= end, got {} / {} / {} / {}"
                                  .format(w.start, w.val_start, w.test_start, w.end))
        if self.panel.bucket_minutes <= 0:
            raise ConfigError("panel.bucket_minutes must be positive")
        if not 1.0 <= self.turnover.tweedie_power <= 2.0:
            raise ConfigError("turnover.tweedie_power must be in [1, 2]")
        if self.optimizer.demand not in ("share_model", "fixed", "none"):
            raise ConfigError("optimizer.demand must be share_model | fixed | none")
        if self.optimizer.price_mode not in ("delta", "absolute"):
            raise ConfigError("optimizer.price_mode must be delta | absolute")
        if self.optimizer.volume_response not in ("neutral", "fixed", "none"):
            raise ConfigError("optimizer.volume_response must be neutral | fixed | none")
        if not 0.0 <= self.optimizer.weighting_band < 0.5:
            raise ConfigError("optimizer.weighting_band must be in [0, 0.5)")
        for key in ("settle_total", "settle_handicap"):
            if getattr(self.optimizer, key) not in ("full_match", "rest_of_match"):
                raise ConfigError("optimizer.{} must be full_match | rest_of_match".format(key))
        bad = set(self.optimizer.free_dims) - set(THETA_DIMS)
        if bad or not self.optimizer.free_dims:
            raise ConfigError("optimizer.free_dims takes some of {}; got {}".format(", ".join(THETA_DIMS),
                                                                                     self.optimizer.free_dims))
        if self.optimizer.anchor_layer not in ANCHOR_LAYERS:
            raise ConfigError("optimizer.anchor_layer must be {}".format(" | ".join(ANCHOR_LAYERS)))
        pb = self.publish
        if pb.mode not in PUBLISH_MODES:
            raise ConfigError("publish.mode (or ALGOE_PUBLISH) must be {}; got {!r}".format(
                " | ".join(PUBLISH_MODES), pb.mode))
        if set(pb.free_dims) - set(THETA_DIMS) or not pb.free_dims:
            raise ConfigError("publish.free_dims takes some of {}".format(", ".join(THETA_DIMS)))
        if not 0.0 <= float(pb.scope_percent) <= 100.0:
            raise ConfigError("publish.scope_percent must be 0..100")
        for key in ("inplay_seconds", "min_interval_seconds", "reply_timeout_seconds", "max_board_age_seconds"):
            if float(getattr(pb, key)) <= 0:
                raise ConfigError("publish.{} must be positive".format(key))
        if self.probability.weight not in ("selection", "money", "row"):
            raise ConfigError("probability.weight must be selection | money | row")
        if self.turnover.blend_base not in ("hybrid", "position", "line"):
            raise ConfigError("turnover.blend_base must be hybrid | position | line")
        if not 0.0 <= self.turnover.extrapolation_tolerance < 0.5:
            raise ConfigError("turnover.extrapolation_tolerance must be in [0, 0.5)")
        if self.turnover.extrapolation_cap < 1.0:
            raise ConfigError("turnover.extrapolation_cap must be >= 1")
        if self.probability.champion_metric not in ("log_loss", "money_log_loss", "brier", "ece"):
            raise ConfigError("probability.champion_metric must be log_loss | money_log_loss | brier | ece")
        bad = set(self.live.trigger_events) - {"goal", "red", "corner"}
        if bad:
            raise ConfigError("live.trigger_events takes goal, red, corner; got {}".format(sorted(bad)))
        if any(float(v) < 0 for v in self.live.trigger_focus_seconds.values()):
            raise ConfigError("live.trigger_focus_seconds must be >= 0")

    # ------------------------------------------------------------- output
    def to_dict(self) -> Dict[str, Any]:
        out = {name: asdict(getattr(self, name)) for name in SECTIONS}
        out["log_level"] = self.log_level
        out["paths"]["resolved"] = {
            "work": str(self.paths.work), "panel_cache": str(self.paths.panel_cache),
            "backtest_data": str(self.paths.backtest_data)}
        return out

    def save(self, path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = self.to_dict()
        payload["paths"].pop("resolved", None)
        p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return p

    def margin_for(self, pool: str) -> float:
        m = self.optimizer.margins
        return float(m.get(str(pool).upper(), m.get("_default", 0.09)))

    # ------------------------------------------------ bridge to the W06 engine
    def legacy_config(self):
        """The W06 engine's Config with the same shaping knobs.

        The panel cache is keyed by these knobs. With the same knobs as the
        workbench (panel.pools = ["HILO", "HDC", "CHLO", "CHDC"]) this opens the
        cache 3-run.bat already built; the default (every pool in the feed) is a
        new cache space and is built once.
        """
        from src.backtest.parquet.config import Config
        cfg = Config(
            data_dir=Path(self.paths.data_dir),
            out_dir=self.paths.reports / "legacy",
            cache_dir=self.paths.panel_cache,
            start_date=self.window.start, end_date=self.window.end,
            bucket_minutes=self.panel.bucket_minutes,
            pools=list(self.panel.pools),
            pool_rule="|".join(sorted(str(p) for p in self.panel.pools)) + "#{}".format(RULES_VERSION)
            if any(str(p).startswith("@") for p in self.panel.pools) else "",
            prematch_window_min=self.panel.prematch_window_min,
            lookback_days=self.panel.lookback_days,
            true_prob_source=self.panel.true_prob_source,
            normalize_book=self.panel.normalize_book,
            hdc_sign=self.panel.hdc_sign,
        )
        return cfg


def describe(settings: Settings) -> str:
    """Short one-line summary for log headers."""
    w = settings.window
    split = "val from {} test from {}".format(w.val_start, w.test_start) if w.val_start else \
        "val {}d test {}d".format(w.val_days, w.test_days)
    return "data={} work={} window={}..{} {} live source={}".format(
        settings.paths.data_dir, settings.paths.work, w.start, w.end, split, settings.live.source)


def is_settings(obj) -> bool:
    return is_dataclass(obj) and isinstance(obj, Settings)
