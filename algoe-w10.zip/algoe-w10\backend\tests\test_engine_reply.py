"""
Engine reply tests - the reply on our book, E[GM] at the engine's prices, the replication gap (the first
half under both split readings), the weight echo, the clock and state, the revert guard and the price-move
trigger after our own message

    python tests/test_engine_reply.py          plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_engine_reply.py

Change Log:
-----------
2026-10-29      Initialize
"""

import copy
import json
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from test_publisher import T0, _candidate, _publisher  # noqa: E402

KEY = ["pool_id", "line_id", "combination_id"]


def _sent_and_reply(tmp, c=None, dispersion=1.0, **publish):
    """Publish one candidate through the mock engine; return the publisher, the candidate, the reply, its info."""
    from algoe.realtime.mock_engine import MockEngine
    from src.hkjc.kafka_transport import MemoryTransport
    c = c or _candidate()
    p = _publisher(tmp, **publish)
    mock = MockEngine(p.settings, p.mapping, lambda mid: (c.rows, c.header), corner_dispersion=dispersion)
    p.transport = MemoryTransport(responder=mock.reply)
    p.consider(c, "sweep")
    reply, info = p.poll()[0]
    return p, c, reply, info


def test_the_reply_joins_our_rows_by_ids_then_by_labels():
    from algoe.realtime.engine_reply import join_reply
    with tempfile.TemporaryDirectory() as tmp:
        _, c, reply, _ = _sent_and_reply(tmp)
    frame = reply.frame()
    moved = frame.copy()
    hilo = moved["pool_type"] == "HILO"
    moved.loc[hilo, "pool_id"] = 99                     # the engine's own pool id: only the labels match
    joined, stats = join_reply(moved, c.rows)
    assert stats["by_id"] == int((~hilo).sum()) and stats["by_label"] == int(hilo.sum()) and stats["unmatched"] == 0
    assert joined["engine_true_odds"].notna().sum() == len(frame)
    h25 = joined[(joined["pool_name"] == "HILO") & (joined["line"] == 2.5) & (joined["combination_string"] == "H")]
    assert np.isfinite(h25["engine_sell_odds"]).all()


def test_gm_on_the_engines_prices_gives_no_money_where_nothing_is_offered():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.realtime.engine_reply import engine_gm, join_reply
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        _, c, reply, _ = _sent_and_reply(tmp)
    opt = ThetaOptimizer(Settings(), free_dims=["goal_tg", "goal_sup", "corner_tg", "corner_sup"])
    frame = reply.frame()
    board = frame.copy()
    k = c.book.keys[KEY].astype("int64").assign(o=c.book.odds_now)
    board = board.drop(columns=["sell_odds"]).merge(k, on=KEY, how="left").rename(columns={"o": "sell_odds"})
    board["sell_odds"] = board["sell_odds"].fillna(2.0)
    joined, _ = join_reply(board, c.rows)
    gm = engine_gm(c.book, joined, opt)
    assert abs(gm - opt.expected_gm(c.book, c.book.odds_now)) < 1e-6      # the engine posting the board: the board
    shut = board.copy()
    shut.loc[shut["pool_type"] == "HILO", "sell_odds"] = 1.001             # HILO not offered
    shut["offered"] = shut["sell_odds"] > 1.001 + 1e-9
    joined2, _ = join_reply(shut, c.rows)
    gm2 = engine_gm(c.book, joined2, opt)
    hilo = c.book.pool == "HILO"
    assert np.isfinite(gm2) and gm2 != gm and not np.isnan(gm2)
    assert abs(engine_gm(c.book, joined2, opt, only=~hilo) - gm2) < 1e-6   # no money on what is not sold


def test_replication_gap_is_zero_on_our_own_pricing_and_finds_wider_corners():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.realtime.engine_reply import join_reply, replication_gap
    from algoe.settings import Settings
    opt = ThetaOptimizer(Settings(), free_dims=["goal_tg", "goal_sup", "corner_tg", "corner_sup"])
    with tempfile.TemporaryDirectory() as tmp:
        _, c, reply, info = _sent_and_reply(tmp)
    from src.hkjc.kafka_messages import load_mapping
    joined, _ = join_reply(reply.frame(), c.rows)
    gap = replication_gap(c.book, joined, info["sent"], c.header, opt, load_mapping())
    assert gap["max"] < 1e-4 and not gap["alert"], gap
    assert gap["first_half"]["as_first_half"] < 1e-4 < gap["first_half"]["as_second_half"]
    with tempfile.TemporaryDirectory() as tmp:
        _, c, wide, info = _sent_and_reply(tmp, dispersion=1.5)
    joined, _ = join_reply(wide.frame(), c.rows)
    gap = replication_gap(c.book, joined, info["sent"], c.header, opt, load_mapping(), alert=0.01)
    assert gap["alert"] and gap["worst_pool"] == "CHLO" and gap["pools"]["HILO"]["max"] < 1e-4


def test_every_weight_sent_comes_back_or_is_named():
    from algoe.realtime.engine_reply import weight_echo
    with tempfile.TemporaryDirectory() as tmp:
        p, c, reply, info = _sent_and_reply(tmp)
    sent = info["sent"]["weights"]
    assert sent and weight_echo(reply.frame(), sent) == []
    f = reply.frame()
    f.loc[f["pool_type"] == "HILO", "weight"] = 0.0                        # the engine dropped them
    bad = weight_echo(f, sent)
    assert bad and all("HILO" in b and "engine 0" in b for b in bad)


def test_the_replys_clock_and_state_against_ours():
    from algoe.realtime.engine_reply import clock_check
    from types import SimpleNamespace
    first = {"phase": "first_half", "minute": 30.0, "in_play": True, "game_state": "FirstHalf"}
    ok = SimpleNamespace(game_state="FirstHalf", clock_seconds=1830.0, clock_set=True)
    assert clock_check(ok, first, 120.0) == []
    late = SimpleNamespace(game_state="FirstHalf", clock_seconds=1500.0, clock_set=True)
    assert any("clock" in n for n in clock_check(late, first, 120.0))
    other = SimpleNamespace(game_state="SecondHalf", clock_seconds=1830.0, clock_set=True)
    assert any("state" in n for n in clock_check(other, first, 120.0))
    brk = {"phase": "half_time", "minute": 45.0, "in_play": True, "game_state": "FirstHalf"}
    held = SimpleNamespace(game_state="FirstHalf", clock_seconds=2700.0, clock_set=True)
    assert clock_check(held, brk, 120.0) == []
    pre = {"phase": "prematch", "minute": 0.0, "in_play": False, "game_state": "Prematch"}
    assert clock_check(SimpleNamespace(game_state="Prematch", clock_seconds=0.0, clock_set=False), pre, 120.0) == []


def test_the_engine_reads_a_reply_and_the_revert_guard_sends_hkjcs_theta_next():
    from test_algoe import _FrozenSim
    from test_inplay import _engine
    src = _FrozenSim(pd.Timestamp("2026-10-26 15:47:00"), n_matches=8)
    t0 = pd.Timestamp("2026-10-26 15:47:00")
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: t0 + pd.Timedelta(seconds=5)
        eng.run_sweep(t0)
        got = eng.publisher.poll()
        assert got
        for reply, info in got:
            eng.on_engine_prices(reply, info)
        mid = next(r.event_id for r, i in got if eng.matches[r.event_id].engine["gm_engine"] is not None
                   and not eng.matches[r.event_id].header.get("in_play"))      # pre-match: a sweep board stays fresh
        e = eng.matches[mid].engine
        assert e["ours"] and e["gap"]["max"] < 1e-3 and e["echo"] == [] and e["notes"] == []
        assert e["joined"]["engine_sell_odds"].notna().any()
        assert eng.publisher.matches[mid].revert_until is None
        # an engine that prices far worse than the board for us: the next message is HKJC's theta
        reply, info = got[[r.event_id for r, _ in got].index(mid)]
        bad = copy.deepcopy(reply)
        bad.rows = [dict(r, sell_odds=r["sell_odds"] * 3.0) for r in bad.rows]
        eng.on_engine_prices(bad, info)
        assert eng.publisher.matches[mid].revert_until is not None
        assert "revert" in " ".join(eng.matches[mid].engine["notes"])
        eng.publisher.clock = lambda: t0 + pd.Timedelta(seconds=30)
        rec = eng._publish(mid, "inplay")
        assert rec["action"] == "sent" and rec["chosen"] == "revert"
        th = eng.matches[mid].book.theta_now
        assert rec["engine_params"]["GoalTg"] == round(th["goal_tg"], 2)


def test_a_reply_is_read_against_its_messages_board_and_audited():
    import gzip
    from test_algoe import _FrozenSim
    from test_inplay import _engine
    t0 = pd.Timestamp("2026-10-26 15:47:00")
    src = _FrozenSim(t0, n_matches=8)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: t0 + pd.Timedelta(seconds=5)
        eng.run_sweep(t0)
        got = eng.publisher.poll()
        reply, info = next((r, i) for r, i in got if not eng.matches[r.event_id].header.get("in_play"))
        mid = reply.event_id
        with eng._lock:
            eng.matches[mid].book = eng.matches[mid].rows = None             # a newer refresh, no book behind it
        eng.on_engine_prices(reply, info)
        e = eng.matches[mid].engine
        assert e["gm_engine"] is not None and e["gap"]["max"] < 1e-3 and e["joined"] is not None, e["notes"]
        rows = []
        for f in (Path(tmp) / "publish" / "audit").glob("*.jsonl.gz"):
            with gzip.open(f, "rt", encoding="utf-8") as fh:
                rows += [json.loads(line) for line in fh]
        fb = [r for r in rows if r["kind"] == "feedback" and r["match_id"] == mid]
        assert fb and fb[-1]["msg_id"] == info["msg_id"] and abs(fb[-1]["gm_engine"] - e["gm_engine"]) < 1e-6
        assert fb[-1]["gap_max"] < 1e-3 and fb[-1]["revert"] is False and fb[-1]["echo"] == 0


def test_our_own_live_message_does_not_trigger_a_refresh():
    from test_algoe import _FrozenSim
    from test_inplay import _engine
    t0 = pd.Timestamp("2026-10-26 15:47:00")
    src = _FrozenSim(t0, n_matches=8)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: t0 + pd.Timedelta(seconds=5)
        eng.run_sweep(t0)
        got = eng.publisher.poll()
        reply, info = next((r, i) for r, i in got if eng.matches[r.event_id].last_main_odds)
        mid = reply.event_id
        before = dict(eng.matches[mid].last_main_odds)
        eng.on_engine_prices(reply, info)                                    # dry run: the board did not move
        assert eng.matches[mid].last_main_odds == before
        live_info = dict(info, target="production")
        live_info["sent"] = dict(info["sent"], what="star")
        eng.publisher.policy.mode = "live"
        eng.on_engine_prices(reply, live_info)                               # live: it will, to these prices
        after = eng.matches[mid].last_main_odds
        f = reply.frame().set_index(KEY)
        for k, v in after.items():
            if k in f.index and bool(f.loc[k, "offered"]):
                assert v == f.loc[k, "sell_odds"]
        assert after != before


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
