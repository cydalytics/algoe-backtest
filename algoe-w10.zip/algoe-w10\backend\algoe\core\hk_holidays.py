"""
Hong Kong General Holidays, for any year

The general holidays of the General Holidays Ordinance (Cap. 149) are computed, not listed, so the
calendar never runs out:

    fixed        1 Jan, Labour Day 1 May, HKSAR Establishment Day 1 Jul, National Day 1 Oct,
                 Christmas Day 25 Dec, the first weekday after Christmas Day
    Easter       Good Friday, the day following Good Friday, Easter Monday (Gregorian computus)
    solar term   Ching Ming: the day the Sun's apparent longitude reaches 15 deg, Hong Kong time
    lunar        Lunar New Year's Day and the next two days, the Birthday of the Buddha (4/8),
                 Tuen Ng (5/5), the day following Mid-Autumn (8/16), Chung Yeung (9/9)

A holiday falling on a Sunday moves to the next day that is neither a Sunday nor itself a holiday,
and so does the second of two holidays falling on the same day (Ching Ming on Easter Monday, the
day following Mid-Autumn on National Day). Any of the first three days of Lunar New Year on a
Sunday makes the fourth day a holiday instead. Before 2012 the rules differed (the day preceding
Lunar New Year; the Mid-Autumn Festival itself when the day following was a Sunday), and are kept
so historical days are marked as they were.

The Chinese calendar is computed the way the Hong Kong Observatory computes it: new moons and
principal solar terms in UTC+8; the month containing the winter solstice is the 11th; in a
13-month year the first month without a principal term is the leap month. New moons follow
Meeus, Astronomical Algorithms ch. 49; the Sun's longitude is the truncated VSOP87 series of
Meeus appendix III with nutation and aberration - about one arcsecond, i.e. seconds of time.
tests/test_algoe.py checks a century against the python-holidays tables where that package is
installed. One-off holidays (a gazetted extra day) go in the holidays file.

Change Log:
-----------
2026-10-01      Initialize (replaces the 2024-2027 list from the feature notebooks)
"""

from __future__ import annotations

import math
from datetime import date, timedelta
from functools import lru_cache
from typing import Dict, List, Tuple

UTC_OFFSET_HOURS = 8.0
_DAY0 = date(2000, 1, 1).toordinal()          # JD 2451544.5 is 2000-01-01 00:00 UT


# ----------------------------------------------------------------- time scales
def _delta_t_seconds(year: float) -> float:
    """TT - UT (Espenak & Meeus polynomials)."""
    y = year
    if y < 1941:
        u = (y - 1820) / 100.0
        return -20.0 + 32.0 * u * u
    if y < 1961:
        t = y - 1950
        return 29.07 + 0.407 * t - t * t / 233 + t ** 3 / 2547
    if y < 1986:
        t = y - 1975
        return 45.45 + 1.067 * t - t * t / 260 - t ** 3 / 718
    if y < 2005:
        t = y - 2000
        return (63.86 + 0.3345 * t - 0.060374 * t ** 2 + 0.0017275 * t ** 3 + 0.000651814 * t ** 4
                + 0.00002373599 * t ** 5)
    if y < 2050:
        t = y - 2000
        return 62.92 + 0.32217 * t + 0.005589 * t * t
    u = (y - 1820) / 100.0
    if y < 2150:
        return -20.0 + 32.0 * u * u - 0.5628 * (2150 - y)
    return -20.0 + 32.0 * u * u


def _local_ordinal(jde: float) -> int:
    """Proleptic Gregorian ordinal of the Hong Kong date at the instant ``jde`` (TT)."""
    year = 2000.0 + (jde - 2451545.0) / 365.25
    jd_ut = jde - _delta_t_seconds(year) / 86400.0
    return _DAY0 + int(math.floor(jd_ut - 2451544.5 + UTC_OFFSET_HOURS / 24.0))


def _jd_of_ordinal(ordinal: int) -> float:
    """JD (UT) at 00:00 Hong Kong time of a date ordinal."""
    return 2451544.5 + (ordinal - _DAY0) - UTC_OFFSET_HOURS / 24.0


# ------------------------------------------------------------------ new moons
_NM_CORR = (  # (coefficient, power of E, M, M', F, Omega multipliers) - Meeus table 49.A, new moon
    (-0.40720, 0, 0, 1, 0, 0), (0.17241, 1, 1, 0, 0, 0), (0.01608, 0, 0, 2, 0, 0),
    (0.01039, 0, 0, 0, 2, 0), (0.00739, 1, -1, 1, 0, 0), (-0.00514, 1, 1, 1, 0, 0),
    (0.00208, 2, 2, 0, 0, 0), (-0.00111, 0, 0, 1, -2, 0), (-0.00057, 0, 0, 1, 2, 0),
    (0.00056, 1, 1, 2, 0, 0), (-0.00042, 0, 0, 3, 0, 0), (0.00042, 1, 1, 0, 2, 0),
    (0.00038, 1, 1, 0, -2, 0), (-0.00024, 1, -1, 2, 0, 0), (-0.00017, 0, 0, 0, 0, 1),
    (-0.00007, 0, 2, 1, 0, 0), (0.00004, 0, 0, 2, -2, 0), (0.00004, 0, 3, 0, 0, 0),
    (0.00003, 0, 1, 1, -2, 0), (0.00003, 0, 0, 2, 2, 0), (-0.00003, 0, 1, 1, 2, 0),
    (0.00003, 0, -1, 1, 2, 0), (-0.00002, 0, -1, 1, -2, 0), (-0.00002, 0, 1, 3, 0, 0),
    (0.00002, 0, 0, 4, 0, 0),
)
_NM_PLANETARY = (  # (coefficient, constant deg, rate deg per lunation) - A1..A14
    (0.000325, 299.77, 0.107408), (0.000165, 251.88, 0.016321), (0.000164, 251.83, 26.651886),
    (0.000126, 349.42, 36.412478), (0.000110, 84.66, 18.206239), (0.000062, 141.74, 53.303771),
    (0.000060, 207.14, 2.453732), (0.000056, 154.84, 7.306860), (0.000047, 34.52, 27.261239),
    (0.000042, 207.19, 0.121824), (0.000040, 291.34, 1.844379), (0.000037, 161.72, 24.198154),
    (0.000035, 239.56, 25.513099), (0.000023, 331.55, 3.592518),
)


def new_moon_jde(k: int) -> float:
    """JDE (TT) of new moon number k; k = 0 is the new moon of 2000-01-06."""
    T = k / 1236.85
    jde = (2451550.09766 + 29.530588861 * k + 0.00015437 * T ** 2 - 0.000000150 * T ** 3
           + 0.00000000073 * T ** 4)
    E = 1.0 - 0.002516 * T - 0.0000074 * T ** 2
    M = math.radians(2.5534 + 29.10535670 * k - 0.0000014 * T ** 2 - 0.00000011 * T ** 3)
    Mp = math.radians(201.5643 + 385.81693528 * k + 0.0107582 * T ** 2 + 0.00001238 * T ** 3
                      - 0.000000058 * T ** 4)
    F = math.radians(160.7108 + 390.67050284 * k - 0.0016118 * T ** 2 - 0.00000227 * T ** 3
                     + 0.000000011 * T ** 4)
    Om = math.radians(124.7746 - 1.56375588 * k + 0.0020672 * T ** 2 + 0.00000215 * T ** 3)
    corr = 0.0
    for c, e_pow, m, mp, f, om in _NM_CORR:
        corr += c * (E ** e_pow) * math.sin(m * M + mp * Mp + f * F + om * Om)
    a1 = math.radians(299.77 + 0.107408 * k - 0.009173 * T ** 2)
    corr += _NM_PLANETARY[0][0] * math.sin(a1)
    for c, a0, rate in _NM_PLANETARY[1:]:
        corr += c * math.sin(math.radians(a0 + rate * k))
    return jde + corr


def _new_moon_day(k: int) -> int:
    return _local_ordinal(new_moon_jde(k))


def _k_on_or_before(ordinal: int) -> int:
    """The last new moon whose Hong Kong date is on or before ``ordinal``."""
    k = int(math.floor((_jd_of_ordinal(ordinal) - 2451550.09766) / 29.530588861)) + 1
    while _new_moon_day(k) > ordinal:
        k -= 1
    while _new_moon_day(k + 1) <= ordinal:
        k += 1
    return k


# ------------------------------------------------------------- solar longitude
# Earth's heliocentric longitude, VSOP87 truncated (Meeus table 32.A): (A, B, C) per term.
_L0 = (
    (175347046, 0, 0), (3341656, 4.6692568, 6283.07585), (34894, 4.6261, 12566.1517),
    (3497, 2.7441, 5753.3849), (3418, 2.8289, 3.5231), (3136, 3.6277, 77713.7715),
    (2676, 4.4181, 7860.4194), (2343, 6.1352, 3930.2097), (1324, 0.7425, 11506.7698),
    (1273, 2.0371, 529.691), (1199, 1.1096, 1577.3435), (990, 5.233, 5884.927), (902, 2.045, 26.298),
    (857, 3.508, 398.149), (780, 1.179, 5223.694), (753, 2.533, 5507.553), (505, 4.583, 18849.228),
    (492, 4.205, 775.523), (357, 2.92, 0.067), (317, 5.849, 11790.629), (284, 1.899, 796.298),
    (271, 0.315, 10977.079), (243, 0.345, 5486.778), (206, 4.806, 2544.314), (205, 1.869, 5573.143),
    (202, 2.458, 6069.777), (156, 0.833, 213.299), (132, 3.411, 2942.463), (126, 1.083, 20.775),
    (115, 0.645, 0.98), (103, 0.636, 4694.003), (102, 0.976, 15720.839), (102, 4.267, 7.114),
    (99, 6.21, 2146.17), (98, 0.68, 155.42), (86, 5.98, 161000.69), (85, 1.3, 6275.96),
    (85, 3.67, 71430.7), (80, 1.81, 17260.15), (79, 3.04, 12036.46), (75, 1.76, 5088.63),
    (74, 3.5, 3154.69), (74, 4.68, 801.82), (70, 0.83, 9437.76), (62, 3.98, 8827.39),
    (61, 1.82, 7084.9), (57, 2.78, 6286.6), (56, 4.39, 14143.5), (56, 3.47, 6279.55),
    (52, 0.19, 12139.55), (52, 1.33, 1748.02), (51, 0.28, 5856.48), (49, 0.49, 1194.45),
    (41, 5.37, 8429.24), (41, 2.4, 19651.05), (39, 6.17, 10447.39), (37, 6.04, 10213.29),
    (37, 2.57, 1059.38), (36, 1.71, 2352.87), (36, 1.78, 6812.77), (33, 0.59, 17789.85),
    (30, 0.44, 83996.85), (30, 2.74, 1349.87), (25, 3.16, 4690.48),
)
_L1 = (
    (628331966747, 0, 0), (206059, 2.678235, 6283.07585), (4303, 2.6351, 12566.1517),
    (425, 1.59, 3.523), (119, 5.796, 26.298), (109, 2.966, 1577.344), (93, 2.59, 18849.23),
    (72, 1.14, 529.69), (68, 1.87, 398.15), (67, 4.41, 5507.55), (59, 2.89, 5223.69),
    (56, 2.17, 155.42), (45, 0.4, 796.3), (36, 0.47, 775.52), (29, 2.65, 7.11), (21, 5.34, 0.98),
    (19, 1.85, 5486.78), (19, 4.97, 213.3), (17, 2.99, 6275.96), (16, 0.03, 2544.31),
    (16, 1.43, 2146.17), (15, 1.21, 10977.08), (12, 2.83, 1748.02), (12, 3.26, 5088.63),
    (12, 5.27, 1194.45), (12, 2.08, 4694.0), (11, 0.77, 553.57), (10, 1.3, 6286.6),
    (10, 4.24, 1349.87), (9, 2.7, 242.73), (9, 5.64, 951.72), (8, 5.3, 2352.87), (6, 2.65, 9437.76),
    (6, 4.67, 4690.48),
)
_L2 = (
    (52919, 0, 0), (8720, 1.0721, 6283.0758), (309, 0.867, 12566.152), (27, 0.05, 3.52),
    (16, 5.19, 26.3), (16, 3.68, 155.42), (10, 0.76, 18849.23), (9, 2.06, 77713.77), (7, 0.83, 775.52),
    (5, 4.66, 1577.34), (4, 1.03, 7.11), (4, 3.44, 5573.14), (3, 5.14, 796.3), (3, 6.05, 5507.55),
    (3, 1.19, 242.73), (3, 6.12, 529.69), (3, 0.31, 398.15), (3, 2.28, 553.57), (2, 4.38, 5223.69),
    (2, 3.75, 0.98),
)
_L3 = ((289, 5.844, 6283.076), (35, 0, 0), (17, 5.49, 12566.15), (3, 5.2, 155.42), (1, 4.72, 3.52),
       (1, 5.3, 18849.23), (1, 5.97, 242.73))
_L4 = ((114, 3.142, 0), (8, 4.13, 6283.08), (1, 3.84, 12566.15))
_L5 = ((1, 3.14, 0),)


def sun_apparent_longitude(jde: float) -> float:
    """Apparent geocentric longitude of the Sun, degrees in [0, 360)."""
    tau = (jde - 2451545.0) / 365250.0
    L = 0.0
    for power, series in enumerate((_L0, _L1, _L2, _L3, _L4, _L5)):
        L += sum(a * math.cos(b + c * tau) for a, b, c in series) * tau ** power
    lon = math.degrees(L / 1e8) + 180.0 - 0.09033 / 3600.0          # geocentric, FK5
    T = 10.0 * tau
    om = math.radians(125.04452 - 1934.136261 * T)
    ls = math.radians(280.4665 + 36000.7698 * T)
    lm = math.radians(218.3165 + 481267.8813 * T)
    dpsi = (-17.20 * math.sin(om) - 1.32 * math.sin(2 * ls) - 0.23 * math.sin(2 * lm)
            + 0.21 * math.sin(2 * om)) / 3600.0
    m = math.radians(357.52911 + 35999.05029 * T - 0.0001537 * T * T)
    r = 1.000140 - 0.016708 * math.cos(m) - 0.000139 * math.cos(2 * m)
    return (lon + dpsi - 20.4898 / 3600.0 / r) % 360.0


def solar_term_jde(year: int, angle: float) -> float:
    """JDE when the Sun's apparent longitude reaches ``angle`` during Gregorian ``year``."""
    offset = angle - 360.0 if angle >= 285.0 else angle       # Jan..mid-Mar terms precede the equinox
    jde = 2451545.0 + (year - 2000) * 365.2422 + 78.8 + offset / 360.0 * 365.2422
    for _ in range(12):
        d = (angle - sun_apparent_longitude(jde) + 180.0) % 360.0 - 180.0
        jde += d / 0.98564736
        if abs(d) < 1e-7:
            break
    return jde


def _term_day(year: int, angle: float) -> int:
    return _local_ordinal(solar_term_jde(year, angle))


# ------------------------------------------------------------ Chinese months
@lru_cache(maxsize=256)
def chinese_months(year: int) -> Tuple[Tuple[int, bool, int], ...]:
    """Months of the sui from the 11th month before ``year``'s Lunar New Year to the next 11th:
    (month number, is leap, first-day ordinal)."""
    s1, s2 = _term_day(year - 1, 270.0), _term_day(year, 270.0)
    k0, k1 = _k_on_or_before(s1), _k_on_or_before(s2)
    starts = [_new_moon_day(k) for k in range(k0, k1 + 1)]          # last one opens the next sui
    principal = [s1] + [_term_day(year, a) for a in (300, 330, 0, 30, 60, 90, 120, 150, 180, 210, 240)] + [s2]
    leap_year = (k1 - k0) == 13
    out: List[Tuple[int, bool, int]] = []
    number, leap_done = 11, False
    for j in range(k1 - k0):
        lo, hi = starts[j], starts[j + 1]
        if j == 0:
            out.append((11, False, lo))
            continue
        has_term = any(lo <= z < hi for z in principal)
        if leap_year and not leap_done and not has_term:
            out.append((number, True, lo))
            leap_done = True
            continue
        number = number % 12 + 1
        out.append((number, False, lo))
    return tuple(out)


def lunar_date(year: int, month: int, day: int) -> date:
    """Gregorian date of day ``day`` of (non-leap) lunar month ``month`` of the Chinese year
    whose New Year falls in Gregorian ``year`` (months 1-10)."""
    months = chinese_months(year)
    seen_first = False
    for number, leap, start in months:
        if number == 1 and not leap:
            seen_first = True
        if seen_first and number == month and not leap:
            return date.fromordinal(start + day - 1)
    raise ValueError("lunar month {} not found for {}".format(month, year))


def easter_sunday(year: int) -> date:
    """Gregorian Easter (anonymous computus)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    month = (h + l_ - 7 * m + 114) // 31
    day = (h + l_ - 7 * m + 114) % 31 + 1
    return date(year, month, day)


# ------------------------------------------------------------------ holidays
SUNDAY = 6


RULES_FROM = 2012          # the 2011 amendment: fourth day of Lunar New Year, second day after Mid-Autumn


@lru_cache(maxsize=256)
def hk_general_holidays(year: int) -> Dict[date, str]:
    """Every general holiday of ``year``: the holidays themselves (also when on a Sunday) and the
    days they move to."""
    h: Dict[date, str] = {}

    def add(d: date, name: str) -> None:
        h[d] = name if d not in h else h[d] + "; " + name

    lny = lunar_date(year, 1, 1)
    lny_days = [lny + timedelta(days=i) for i in range(3)]
    easter = easter_sunday(year)
    mid_autumn = lunar_date(year, 8, 15)
    after_mid_autumn = mid_autumn + timedelta(days=1)
    if year < RULES_FROM and after_mid_autumn.weekday() == SUNDAY:
        after_mid_autumn = mid_autumn
    boxing = date(year, 12, 26) if date(year, 12, 26).weekday() != SUNDAY else date(year, 12, 27)
    base: List[Tuple[date, str]] = [
        (date(year, 1, 1), "The first day of January"),
        (date.fromordinal(_term_day(year, 15.0)), "Ching Ming Festival"),
        (easter - timedelta(days=2), "Good Friday"), (easter - timedelta(days=1), "The day following Good Friday"),
        (easter + timedelta(days=1), "Easter Monday"),
        (date(year, 5, 1), "Labour Day"),
        (lunar_date(year, 4, 8), "The Birthday of the Buddha"),
        (lunar_date(year, 5, 5), "Tuen Ng Festival"),
        (date(year, 7, 1), "Hong Kong Special Administrative Region Establishment Day"),
        (after_mid_autumn, "The day following the Chinese Mid-Autumn Festival"),
        (date(year, 10, 1), "National Day"),
        (lunar_date(year, 9, 9), "Chung Yeung Festival"),
        (date(year, 12, 25), "Christmas Day"),
        (boxing, "The first weekday after Christmas Day"),
    ]
    for d, name in zip(lny_days, ("Lunar New Year's Day", "The second day of Lunar New Year",
                                  "The third day of Lunar New Year")):
        add(d, name)
    if any(d.weekday() == SUNDAY for d in lny_days):
        if year >= RULES_FROM:
            add(lny + timedelta(days=3), "The fourth day of Lunar New Year")
        else:
            add(lny - timedelta(days=1), "The day preceding Lunar New Year's Day")
    for d, name in base:
        add(d, name)
    # a Sunday, or a day already taken by another holiday, moves the holiday to the next free day
    taken = {d for d in lny_days}
    for d, name in sorted(base):
        if d.weekday() != SUNDAY and d not in taken:
            taken.add(d)
            continue
        taken.add(d)
        sub = d + timedelta(days=1)
        while sub in h or sub.weekday() == SUNDAY:
            sub += timedelta(days=1)
        add(sub, "{} (observed)".format(name))
    return dict(sorted(h.items()))
