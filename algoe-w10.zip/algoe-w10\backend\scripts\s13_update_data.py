"""
Step 13 - keep Raw_Data current

Extracts Raw_Data again with the queries of "1 Data Extraction.ipynb", from the day before the
newest day every table has to now: monthly tables a whole month at a time, Match_Investments a
day at a time. Each file replaces the old one only once it is complete. Then drops the cached
panel and feature days from that day on and builds them again.

    python scripts/s13_update_data.py [--dry-run] [--from 2026-09-01] [--report]

Exit code 1 if a file failed, 2 if another update is running. Same as: python -m algoe update-data
"""
from _algoe import run

if __name__ == "__main__":
    run("update-data")
