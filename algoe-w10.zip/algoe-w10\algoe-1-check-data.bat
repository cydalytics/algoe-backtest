@echo off
REM Algo E - what is in Raw_Data: tables, columns, coverage, pool codes, leagues.
REM Drag the Raw_Data folder onto this file, or double-click to use ALGOE_DATA_DIR
REM (default S:\Users\Yeung\20260520 Algo E\Raw_Data). Options pass through, e.g.
REM     algoe-1-check-data.bat --start 2026-07-01 --end 2026-09-15
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
set "ARGS=%*"
if not "%~1"=="" if exist "%~1\" (set "ALGOE_DATA_DIR=%~1" & set "ARGS=")
python -m algoe check-data %ARGS%
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo No FAIL. Read the WARN lines before training.) else (echo A check FAILED - fix the data before training.)
pause
exit /b %CODE%
