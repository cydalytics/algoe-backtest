module.exports=[84950,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_match_%5Bid%5D_page_actions_1bydmf0.js.map