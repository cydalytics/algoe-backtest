"""
Estimators

Every learning algorithm behind one interface, so the forecaster and the
calibrator choose an algorithm by name and never by import:

    fit(X, y, exposure=None, weight=None, X_val=None, y_val=None, ...)
    predict(X, exposure=None)   -> the MEAN (money, or a probability)
    to_state() / from_state()   -> plain dicts, so an artifact is a pickle of numbers

    glm    Tweedie / Poisson / binomial GLM by penalised IRLS         numpy only
    gam    the same with P-spline smooths (Eilers & Marx)             numpy only
    gbm    LightGBM, else scikit-learn HistGradientBoosting           optional
    nn     small MLP with a Poisson / Tweedie loss                    optional (torch)
    glm_gbm, glm_nn   the GLM's linear predictor as the offset of a GBM / MLP (AnchoredEstimator)

EXPOSURE. Shares are fitted as counts with the parent total as exposure:
mean = exposure x exp(eta). Every model carries log(exposure) as an offset -
LightGBM through init_score, which is exact for any Tweedie power; the
scikit-learn fallback (Poisson loss only) fits the rate y / exposure weighted
by exposure, which is the same Poisson likelihood. Predicted shares are
normalised inside their group by the forecaster, so the exposure only has to
be right in scale.

EXTRAPOLATION. A tree predicts a constant beyond the last split: a match bigger
than any in training gets the biggest leaf, not more. Money features are in
market-size units, so a market that grows as a whole stays inside the training
range; a single match beyond it does not. The anchored models keep the GLM's
log-linear trend there (capped at ``extrapolation_cap`` times its value at the
edge of the training range) and learn bounded corrections inside the range.

An optional backend that is not installed raises EstimatorUnavailable; the
forecaster logs it and skips that algorithm rather than failing the run.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.exceptions import EstimatorUnavailable, ModelError
from ..core.logging import get_logger

logger = get_logger(__name__)

ETA_LO, ETA_HI = -30.0, 25.0


# ---------------------------------------------------------------- deviance
def deviance(y, mu, family: str = "poisson", power: float = 1.5, weight=None) -> float:
    """Mean unit deviance (weighted). Poisson for power 1, log-loss x 2 for binomial."""
    y = np.asarray(y, dtype="float64")
    mu = np.asarray(mu, dtype="float64")
    w = np.ones_like(y) if weight is None else np.asarray(weight, dtype="float64")
    if family == "binomial":
        mu = np.clip(mu, 1e-9, 1 - 1e-9)
        d = -2.0 * (y * np.log(mu) + (1 - y) * np.log(1 - mu))
    elif family == "poisson" or abs(power - 1.0) < 1e-9:
        mu = np.maximum(mu, 1e-9)
        d = 2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))
    elif family == "gaussian":
        d = (y - mu) ** 2
    else:
        p = power
        mu = np.maximum(mu, 1e-9)
        d = 2.0 * (np.power(np.maximum(y, 0), 2 - p) / ((1 - p) * (2 - p))
                   - y * np.power(mu, 1 - p) / (1 - p) + np.power(mu, 2 - p) / (2 - p))
    return float(np.sum(w * d) / max(np.sum(w), 1e-12))


def _link_inverse(eta, family):
    eta = np.clip(eta, ETA_LO, ETA_HI)
    if family == "binomial":
        return 1.0 / (1.0 + np.exp(-eta))
    if family == "gaussian":
        return eta
    return np.exp(eta)


class Estimator:
    algorithm = "base"

    def __init__(self, family: str = "tweedie", power: float = 1.5, **params):
        if family not in ("tweedie", "poisson", "binomial", "gaussian"):
            raise ModelError("unknown family {!r}".format(family))
        self.family = "poisson" if (family == "tweedie" and abs(power - 1.0) < 1e-9) else family
        self.power = float(power)
        self.params = dict(params)
        self.features: List[str] = []
        self.info: Dict = {}

    # -------------------------------------------------------------- API
    def fit(self, X: pd.DataFrame, y, exposure=None, weight=None, X_val: Optional[pd.DataFrame] = None,
            y_val=None, exposure_val=None, weight_val=None) -> "Estimator":
        raise NotImplementedError

    def predict(self, X: pd.DataFrame, exposure=None) -> np.ndarray:
        raise NotImplementedError

    def to_state(self) -> dict:
        raise NotImplementedError

    @classmethod
    def from_state(cls, state: dict) -> "Estimator":
        raise NotImplementedError

    def summary(self) -> dict:
        return {"algorithm": self.algorithm, "family": self.family, "power": self.power,
                "features": len(self.features), **self.info}

    # --------------------------------------------------------- helpers
    def _dev(self, y, mu, w=None) -> float:
        return deviance(y, mu, self.family, self.power, w)

    @staticmethod
    def _exp(exposure, n) -> np.ndarray:
        if exposure is None:
            return np.ones(n)
        e = np.asarray(exposure, dtype="float64")
        return np.where(np.isfinite(e) & (e > 0), e, 0.0)

    def _matrix(self, X: pd.DataFrame) -> np.ndarray:
        missing = [c for c in self.features if c not in X.columns]
        if missing:
            raise ModelError("{} input is missing feature(s) {}".format(self.algorithm, missing[:8]))
        return X[self.features].to_numpy(dtype="float64")


# ------------------------------------------------------------ penalised IRLS
def _irls_weights(Z, beta, offset, weight, family, power):
    eta = np.clip(Z @ beta + offset, ETA_LO, ETA_HI)
    mu = _link_inverse(eta, family)
    if family == "binomial":
        w_irls = weight * np.clip(mu * (1 - mu), 1e-9, None)
    elif family == "gaussian":
        w_irls = weight
    else:
        pw = 1.0 if family == "poisson" else power
        w_irls = weight * np.power(np.maximum(mu, 1e-12), 2.0 - pw)
    return eta, mu, w_irls


def irls(Z: np.ndarray, y: np.ndarray, offset: np.ndarray, weight: np.ndarray, family: str,
         power: float, penalty_unit: np.ndarray, lam: float = 1.0, max_iter: int = 40,
         tol: float = 1e-7) -> dict:
    """Penalised IRLS for log (count families) or logit (binomial) link.

    The penalty is ``lam x s0 x penalty_unit`` where s0 = trace(Z'WZ) / p at
    the starting point. Measuring it against the curvature of the data makes
    one ``lam`` mean the same thing for HK$ turnover and for probabilities.
    ``penalty_unit`` must be zero on the intercept. Step-halving guarantees
    the penalised objective never goes up.
    """
    n, p = Z.shape
    beta = np.zeros(p)
    if family == "binomial":
        rate = float(np.clip(np.sum(weight * y) / max(np.sum(weight), 1e-12), 1e-4, 1 - 1e-4))
        beta[0] = np.log(rate / (1 - rate))
    elif family == "gaussian":
        beta[0] = float(np.sum(weight * y) / max(np.sum(weight), 1e-12))
    else:
        ybar = max(float(np.sum(weight * y) / max(np.sum(weight * np.exp(offset)), 1e-12)), 1e-9)
        beta[0] = np.log(ybar)
    _, _, w0 = _irls_weights(Z, beta, offset, weight, family, power)
    s0 = float(np.einsum("ij,i,ij->", Z, w0, Z)) / max(p, 1)
    penalty = lam * max(s0, 1e-12) * penalty_unit

    def objective(b):
        mu = _link_inverse(Z @ b + offset, family)
        return deviance(y, mu, family, power, weight) * np.sum(weight) + b @ penalty @ b

    obj = objective(beta)
    trace = []
    for it in range(max_iter):
        eta = np.clip(Z @ beta + offset, ETA_LO, ETA_HI)
        mu = _link_inverse(eta, family)
        if family == "binomial":
            w_irls = weight * np.clip(mu * (1 - mu), 1e-9, None)
            z = eta - offset + (y - mu) / np.clip(mu * (1 - mu), 1e-9, None)
        elif family == "gaussian":
            w_irls = weight
            z = y - offset
        else:
            pw = 1.0 if family == "poisson" else power
            w_irls = weight * np.power(np.maximum(mu, 1e-12), 2.0 - pw)
            z = eta - offset + (y - mu) / np.maximum(mu, 1e-12)
        zw = Z * w_irls[:, None]
        A = Z.T @ zw + penalty
        try:
            new = np.linalg.solve(A + 1e-10 * np.eye(p), zw.T @ z)
        except np.linalg.LinAlgError:
            new = np.linalg.lstsq(A, zw.T @ z, rcond=None)[0]
        step = new - beta
        new_obj = objective(new)
        halvings = 0
        while not np.isfinite(new_obj) or new_obj > obj * (1 + 1e-10) + 1e-12:
            step *= 0.5
            new = beta + step
            new_obj = objective(new)
            halvings += 1
            if halvings > 12:
                break
        change = float(np.max(np.abs(new - beta)))
        beta, obj = new, new_obj
        trace.append({"iter": it, "objective": obj, "change": change, "halvings": halvings})
        if change < tol:
            break
    return {"beta": beta, "iterations": len(trace), "objective": obj, "trace": trace[-3:]}


class GLMEstimator(Estimator):
    algorithm = "glm"

    def __init__(self, family="tweedie", power=1.5, ridge: float = 1e-3, features: Optional[Sequence[str]] = None,
                 **params):
        super().__init__(family, power, **params)
        self.ridge = float(ridge)
        self.features = list(features) if features is not None else []
        self.mean = self.std = self.beta = None

    def fit(self, X, y, exposure=None, weight=None, X_val=None, y_val=None, exposure_val=None, weight_val=None,
            offset=None, offset_val=None):
        """``offset`` is added to the linear predictor as is (a binomial layer stacked on an earlier
        layer's logit); for the count families log(exposure) is added as well."""
        started = time.time()
        if not self.features:
            self.features = list(X.columns)
        x = self._matrix(X)
        y = np.clip(np.asarray(y, dtype="float64"), 0, None) if self.family != "gaussian" else np.asarray(y, dtype="float64")
        e = self._exp(exposure, len(y))
        w = np.ones(len(y)) if weight is None else np.asarray(weight, dtype="float64")
        o = np.zeros(len(y)) if offset is None else np.asarray(offset, dtype="float64")
        keep = (e > 0) & np.isfinite(y) & (w > 0) & np.isfinite(o)
        x, y, e, w, o = x[keep], y[keep], e[keep], w[keep], o[keep]
        if len(y) < max(20, x.shape[1] + 2):
            raise ModelError("glm: {} usable rows for {} features".format(len(y), x.shape[1]))
        self.mean = np.average(x, axis=0, weights=w)
        self.std = np.sqrt(np.average((x - self.mean) ** 2, axis=0, weights=w))
        self.std[self.std < 1e-9] = 1.0
        Z = np.column_stack([np.ones(len(y)), (x - self.mean) / self.std])
        pen = np.eye(Z.shape[1])
        pen[0, 0] = 0.0
        off = (np.log(np.maximum(e, 1e-300)) if self.family not in ("binomial", "gaussian") else np.zeros(len(y))) + o
        res = irls(Z, y, off, w, self.family, self.power, pen, lam=self.ridge)
        self.beta = res["beta"]
        mu = _link_inverse(Z @ self.beta + off, self.family)
        self.info = {"rows": int(len(y)), "iterations": res["iterations"],
                     "train_deviance": self._dev(y, mu, w), "seconds": round(time.time() - started, 2)}
        if X_val is not None and y_val is not None:
            self.info["val_deviance"] = self._dev(np.asarray(y_val, dtype="float64"),
                                                  self.predict(X_val, exposure_val, offset=offset_val), weight_val)
        return self

    def eta(self, X) -> np.ndarray:
        return self.eta_matrix(self._matrix(X))

    def eta_matrix(self, x: np.ndarray) -> np.ndarray:
        """Linear predictor (exposure excluded) of a matrix in self.features order."""
        return np.column_stack([np.ones(len(x)), (x - self.mean) / self.std]) @ self.beta

    def predict(self, X, exposure=None, offset=None):
        if self.beta is None:
            raise ModelError("glm is not fitted")
        eta = self.eta(X)
        if offset is not None:
            eta = eta + np.asarray(offset, dtype="float64")
        if self.family not in ("binomial", "gaussian"):
            eta = eta + np.log(np.maximum(self._exp(exposure, len(eta)), 1e-300))
        out = _link_inverse(eta, self.family)
        if exposure is not None and self.family not in ("binomial", "gaussian"):
            out = np.where(self._exp(exposure, len(eta)) > 0, out, 0.0)
        return out

    def coefficients(self) -> Dict[str, float]:
        """Per original-unit coefficients (the effect of +1 in each feature on eta)."""
        if self.beta is None:
            return {}
        out = {"intercept": float(self.beta[0] - np.sum(self.beta[1:] * self.mean / self.std))}
        out.update({f: float(b / s) for f, b, s in zip(self.features, self.beta[1:], self.std)})
        return out

    def to_state(self):
        return {"algorithm": self.algorithm, "family": self.family, "power": self.power, "ridge": self.ridge,
                "features": self.features, "mean": self.mean, "std": self.std, "beta": self.beta,
                "info": self.info}

    @classmethod
    def from_state(cls, s):
        m = cls(s["family"], s["power"], s["ridge"], s["features"])
        m.mean, m.std, m.beta = (np.asarray(s[k], dtype="float64") for k in ("mean", "std", "beta"))
        m.info = dict(s.get("info") or {})
        return m


# ---------------------------------------------------------------- GAM
def bspline_basis(x: np.ndarray, knots: np.ndarray, degree: int = 3) -> np.ndarray:
    """Cox-de Boor B-spline basis. Values outside the knot range are clamped to it."""
    x = np.clip(np.asarray(x, dtype="float64"), knots[degree], knots[-degree - 1] - 1e-9)
    t = knots
    B = ((x[:, None] >= t[None, :-1]) & (x[:, None] < t[None, 1:])).astype("float64")
    for d in range(1, degree + 1):
        ld = t[d:-1] - t[:-(d + 1)]
        rd = t[d + 1:] - t[1:-d]
        left = np.where(ld > 0, (x[:, None] - t[None, :-(d + 1)]) / np.where(ld > 0, ld, 1.0), 0.0) * B[:, :-1]
        right = np.where(rd > 0, (t[None, d + 1:] - x[:, None]) / np.where(rd > 0, rd, 1.0), 0.0) * B[:, 1:]
        B = left + right
    return B


def _knots(x: np.ndarray, n_interior: int, degree: int = 3) -> Optional[np.ndarray]:
    x = x[np.isfinite(x)]
    if len(np.unique(x)) < 8:
        return None
    lo, hi = float(np.min(x)), float(np.max(x))
    if hi - lo < 1e-9:
        return None
    qs = np.unique(np.quantile(x, np.linspace(0, 1, n_interior + 2)[1:-1]))
    qs = qs[(qs > lo) & (qs < hi)]
    return np.concatenate([[lo] * (degree + 1), qs, [hi + 1e-6] * (degree + 1)])


class GAMEstimator(Estimator):
    """Penalised B-spline smooths on the continuous inputs, linear terms for the rest."""
    algorithm = "gam"

    def __init__(self, family="tweedie", power=1.5, n_knots: int = 8, lambdas: Sequence[float] = (0.1, 1.0, 10.0),
                 smooth: Optional[Sequence[str]] = None, features: Optional[Sequence[str]] = None,
                 ridge: float = 1e-3, max_smooth: int = 12, **params):
        super().__init__(family, power, **params)
        self.n_knots = int(n_knots)
        self.lambdas = list(lambdas)
        self.smooth_req = list(smooth) if smooth else None
        self.features = list(features) if features is not None else []
        self.ridge = float(ridge)
        self.max_smooth = int(max_smooth)
        self.knots: Dict[str, np.ndarray] = {}
        self.linear: List[str] = []
        self.mean = self.std = self.beta = None
        self.lam = None

    def _design(self, X: pd.DataFrame, fit: bool = False) -> np.ndarray:
        blocks = []
        for f in self.knots:
            blocks.append(bspline_basis(X[f].to_numpy(dtype="float64"), self.knots[f]))
        lin = X[self.linear].to_numpy(dtype="float64") if self.linear else np.zeros((len(X), 0))
        if fit:
            self.mean = lin.mean(axis=0) if lin.shape[1] else np.zeros(0)
            self.std = lin.std(axis=0) if lin.shape[1] else np.zeros(0)
            self.std[self.std < 1e-9] = 1.0
        lin = (lin - self.mean) / self.std if lin.shape[1] else lin
        return np.column_stack([np.ones(len(X))] + blocks + [lin])

    def _penalty(self, lam: float) -> np.ndarray:
        """Unit penalty: lam x second differences on each smooth, ridge on the linear part."""
        sizes = [len(k) - 4 for k in self.knots.values()]
        p = 1 + sum(sizes) + len(self.linear)
        P = np.zeros((p, p))
        pos = 1
        for s in sizes:
            D = np.diff(np.eye(s), n=2, axis=0)
            P[pos:pos + s, pos:pos + s] = lam * (D.T @ D) + 1e-4 * np.eye(s)
            pos += s
        P[pos:, pos:] = self.ridge * np.eye(len(self.linear))
        return P

    def fit(self, X, y, exposure=None, weight=None, X_val=None, y_val=None, exposure_val=None, weight_val=None):
        started = time.time()
        if not self.features:
            self.features = list(X.columns)
        y = np.clip(np.asarray(y, dtype="float64"), 0, None) if self.family != "gaussian" else np.asarray(y, dtype="float64")
        e = self._exp(exposure, len(y))
        w = np.ones(len(y)) if weight is None else np.asarray(weight, dtype="float64")
        keep = (e > 0) & np.isfinite(y) & (w > 0)
        Xk = X.loc[keep, self.features].reset_index(drop=True)
        y, e, w = y[keep], e[keep], w[keep]
        cands = self.smooth_req if self.smooth_req else [
            c for c in self.features if Xk[c].nunique() >= 10]
        self.knots = {}
        for c in cands[: self.max_smooth]:
            k = _knots(Xk[c].to_numpy(dtype="float64"), self.n_knots)
            if k is not None:
                self.knots[c] = k
        self.linear = [c for c in self.features if c not in self.knots]
        Z = self._design(Xk, fit=True)
        off = np.log(np.maximum(e, 1e-300)) if self.family not in ("binomial", "gaussian") else np.zeros(len(y))
        have_val = X_val is not None and y_val is not None and len(y_val) > 0
        best = None
        for lam in (self.lambdas if have_val else [self.lambdas[len(self.lambdas) // 2]]):
            res = irls(Z, y, off, w, self.family, self.power, self._penalty(lam), lam=1.0)
            self.beta, self.lam = res["beta"], lam
            score = self._dev(np.asarray(y_val, dtype="float64"), self.predict(X_val, exposure_val), weight_val) \
                if have_val else res["objective"]
            if best is None or score < best[0]:
                best = (score, lam, res["beta"], res["iterations"])
        self.lam, self.beta = best[1], best[2]
        mu = _link_inverse(Z @ self.beta + off, self.family)
        self.info = {"rows": int(len(y)), "smooth_terms": list(self.knots), "lambda": self.lam,
                     "iterations": best[3], "train_deviance": self._dev(y, mu, w),
                     "seconds": round(time.time() - started, 2)}
        if have_val:
            self.info["val_deviance"] = float(best[0])
        return self

    def predict(self, X, exposure=None):
        if self.beta is None:
            raise ModelError("gam is not fitted")
        Z = self._design(X[self.features])
        eta = Z @ self.beta
        if self.family not in ("binomial", "gaussian"):
            eta = eta + np.log(np.maximum(self._exp(exposure, len(eta)), 1e-300))
        out = _link_inverse(eta, self.family)
        if exposure is not None and self.family not in ("binomial", "gaussian"):
            out = np.where(self._exp(exposure, len(eta)) > 0, out, 0.0)
        return out

    def smooth_curve(self, feature: str, grid: np.ndarray) -> np.ndarray:
        """The fitted partial effect of one smooth on eta - what the report draws."""
        if feature not in self.knots:
            return np.zeros(len(grid))
        pos = 1
        for f, k in self.knots.items():
            n = len(k) - 4
            if f == feature:
                return bspline_basis(grid, k) @ self.beta[pos:pos + n]
            pos += n
        return np.zeros(len(grid))

    def to_state(self):
        return {"algorithm": self.algorithm, "family": self.family, "power": self.power,
                "n_knots": self.n_knots, "lambdas": self.lambdas, "features": self.features,
                "ridge": self.ridge, "knots": {k: v.tolist() for k, v in self.knots.items()},
                "linear": self.linear, "mean": self.mean, "std": self.std, "beta": self.beta,
                "lam": self.lam, "info": self.info}

    @classmethod
    def from_state(cls, s):
        m = cls(s["family"], s["power"], s["n_knots"], s["lambdas"], None, s["features"], s["ridge"])
        m.knots = {k: np.asarray(v, dtype="float64") for k, v in s["knots"].items()}
        m.linear = list(s["linear"])
        m.mean, m.std, m.beta = (np.asarray(s[k], dtype="float64") for k in ("mean", "std", "beta"))
        m.lam = s.get("lam")
        m.info = dict(s.get("info") or {})
        return m


# ---------------------------------------------------------------- GBM
def gbm_backend() -> Optional[str]:
    try:
        import lightgbm  # noqa: F401
        return "lightgbm"
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from sklearn.ensemble import HistGradientBoostingRegressor  # noqa: F401
        return "sklearn"
    except Exception:                                       # noqa: BLE001
        return None


class GBMEstimator(Estimator):
    algorithm = "gbm"

    def __init__(self, family="tweedie", power=1.5, features: Optional[Sequence[str]] = None, seed: int = 7,
                 **params):
        super().__init__(family, power, **params)
        self.features = list(features) if features is not None else []
        self.seed = int(seed)
        self.backend = gbm_backend()
        if self.backend is None:
            raise EstimatorUnavailable("gbm needs lightgbm or scikit-learn; neither is installed")
        self.model = None
        self.mode = "offset"
        self.base = 0.0
        self.lo = self.hi = None

    def fit(self, X, y, exposure=None, weight=None, X_val=None, y_val=None, exposure_val=None, weight_val=None,
            offset=None, offset_val=None):
        """``offset`` is added to the log mean as is (the GLM's linear predictor in an anchored model)."""
        started = time.time()
        if not self.features:
            self.features = list(X.columns)
        x = self._matrix(X)
        y = np.clip(np.asarray(y, dtype="float64"), 0, None)
        e = self._exp(exposure, len(y))
        w = np.ones(len(y)) if weight is None else np.asarray(weight, dtype="float64")
        o = np.zeros(len(y)) if offset is None else np.asarray(offset, dtype="float64")
        keep = (e > 0) & np.isfinite(y) & np.isfinite(o) & (w > 0)
        if not keep.any():
            raise ModelError("gbm: no rows with exposure")
        x, y, e, w, o = x[keep], y[keep], e[keep], w[keep], o[keep]
        self.lo, self.hi = np.min(x, axis=0), np.max(x, axis=0)
        # every row starts from its own scale (log exposure + offset) at the overall rate; the trees
        # learn the rest - the Tweedie likelihood of the money itself, whatever the power
        scale = np.log(e) + o
        self.base = float(np.log(max(np.sum(w * y), 1e-12)) - np.log(max(np.sum(w * np.exp(scale)), 1e-300)))
        p = self.params
        if self.backend == "lightgbm":
            import lightgbm as lgb
            objective = "poisson" if self.family == "poisson" else "tweedie"
            self.model = lgb.LGBMRegressor(
                objective=objective, tweedie_variance_power=self.power if objective == "tweedie" else 1.5,
                n_estimators=int(p.get("n_estimators", 400)), learning_rate=float(p.get("learning_rate", 0.05)),
                num_leaves=int(p.get("num_leaves", 31)), min_child_samples=int(p.get("min_child_samples", 200)),
                subsample=float(p.get("subsample", 0.8)), subsample_freq=1,
                colsample_bytree=float(p.get("colsample_bytree", 0.8)),
                reg_lambda=float(p.get("reg_lambda", 1.0)), random_state=self.seed, verbose=-1,
                n_jobs=int(p.get("n_jobs", 0)) or -1)
            fit_kw = {"sample_weight": w, "init_score": scale + self.base}
            callbacks = []
            if X_val is not None and y_val is not None and len(y_val):
                yv = np.asarray(y_val, dtype="float64")
                ev = self._exp(exposure_val, len(yv))
                ov = np.zeros(len(yv)) if offset_val is None else np.asarray(offset_val, dtype="float64")
                wv = np.ones(len(yv)) if weight_val is None else np.asarray(weight_val, dtype="float64")
                kv = (ev > 0) & np.isfinite(yv) & np.isfinite(ov)
                if kv.any():
                    xv = pd.DataFrame(X_val[self.features].to_numpy(dtype="float64")[kv], columns=self.features)
                    fit_kw.update(eval_set=[(xv, np.clip(yv[kv], 0, None))], eval_sample_weight=[wv[kv]],
                                  eval_init_score=[np.log(ev[kv]) + ov[kv] + self.base])
                    callbacks.append(lgb.early_stopping(int(p.get("early_stopping_rounds", 40)), verbose=False))
            self.model.fit(pd.DataFrame(x, columns=self.features), y, callbacks=callbacks or None, **fit_kw)
            best = getattr(self.model, "best_iteration_", None)
            self.info = {"backend": "lightgbm", "trees": int(best or self.model.n_estimators)}
        else:
            from sklearn.ensemble import HistGradientBoostingRegressor
            # no init_score here: the rate against each row's own scale, weighted by that scale (Poisson-exact)
            ee = np.exp(scale + self.base)
            self.model = HistGradientBoostingRegressor(
                loss="poisson", learning_rate=float(p.get("learning_rate", 0.05)),
                max_iter=int(p.get("n_estimators", 400)), max_leaf_nodes=int(p.get("num_leaves", 31)),
                min_samples_leaf=int(p.get("min_child_samples", 200)),
                l2_regularization=float(p.get("reg_lambda", 1.0)), early_stopping=True,
                validation_fraction=0.1, n_iter_no_change=int(p.get("early_stopping_rounds", 40)),
                random_state=self.seed)
            self.model.fit(x, y / ee, sample_weight=w * ee)
            self.info = {"backend": "sklearn", "trees": int(self.model.n_iter_)}
        mu = self.predict(X.loc[keep] if isinstance(X, pd.DataFrame) else X[keep], e, offset=o)
        self.info.update(rows=int(len(y)), train_deviance=self._dev(y, mu, w), seconds=round(time.time() - started, 2))
        if X_val is not None and y_val is not None and len(y_val):
            self.info["val_deviance"] = self._dev(np.asarray(y_val, dtype="float64"),
                                                  self.predict(X_val, exposure_val, offset=offset_val), weight_val)
        return self

    def predict(self, X, exposure=None, offset=None):
        if self.model is None:
            raise ModelError("gbm is not fitted")
        x = self._matrix(X)
        e = self._exp(exposure, len(x))
        if self.backend == "lightgbm":
            x = pd.DataFrame(x, columns=self.features)
        if self.mode == "rate":                         # an artifact fitted on the rate (before 2026-10-06)
            return np.clip(np.asarray(self.model.predict(x), dtype="float64"), 0, None) * e
        o = np.zeros(len(e)) if offset is None else np.nan_to_num(np.asarray(offset, dtype="float64"))
        scale = np.log(np.maximum(e, 1e-300)) + o + self.base
        if self.backend == "lightgbm":
            mu = _link_inverse(np.asarray(self.model.predict(x, raw_score=True), dtype="float64") + scale, "poisson")
        else:
            mu = np.clip(np.asarray(self.model.predict(x), dtype="float64"), 0, None) * np.exp(np.clip(scale, ETA_LO, ETA_HI))
        return np.where(e > 0, mu, 0.0)

    def importance(self) -> Dict[str, float]:
        imp = getattr(self.model, "feature_importances_", None)
        if imp is None:
            return {}
        tot = float(np.sum(imp)) or 1.0
        return {f: float(v) / tot for f, v in sorted(zip(self.features, imp), key=lambda t: -t[1])}

    def to_state(self):
        return {"algorithm": self.algorithm, "family": self.family, "power": self.power,
                "features": self.features, "seed": self.seed, "backend": self.backend,
                "params": self.params, "model": self.model, "info": self.info,
                "mode": self.mode, "base": self.base, "lo": self.lo, "hi": self.hi}

    @classmethod
    def from_state(cls, s):
        m = cls.__new__(cls)
        Estimator.__init__(m, s["family"], s["power"], **(s.get("params") or {}))
        m.features, m.seed, m.backend, m.model = s["features"], s["seed"], s["backend"], s["model"]
        m.info = dict(s.get("info") or {})
        m.mode, m.base = s.get("mode", "rate"), float(s.get("base", 0.0))
        m.lo, m.hi = s.get("lo"), s.get("hi")
        return m


# ----------------------------------------------------------------- NN
def nn_backend() -> bool:
    try:
        import torch  # noqa: F401
        return True
    except Exception:                                       # noqa: BLE001
        return False


class NNEstimator(Estimator):
    """Two-layer MLP, log link, exposure as offset, Poisson / Tweedie loss, early stopping.

    Inputs are held to their training range when predicting: past it a network's output is an
    accident of its activations, so it saturates like a tree (glm_nn carries the trend instead)."""
    algorithm = "nn"

    def __init__(self, family="tweedie", power=1.5, features: Optional[Sequence[str]] = None, seed: int = 7,
                 **params):
        super().__init__(family, power, **params)
        if not nn_backend():
            raise EstimatorUnavailable("nn needs torch, which is not installed")
        self.features = list(features) if features is not None else []
        self.seed = int(seed)
        self.mean = self.std = None
        self.lo = self.hi = None
        self.state_dict = None
        self.bias0 = 0.0

    def _inputs(self, X) -> np.ndarray:
        x = _owned(self._matrix(X))
        if self.lo is not None:
            np.clip(x, self.lo, self.hi, out=x)
        x -= self.mean
        x /= self.std
        return x

    def _net(self, n_in: int):
        import torch.nn as nn
        hidden = list(self.params.get("hidden", [64, 32]))
        drop = float(self.params.get("dropout", 0.1))
        layers, prev = [], n_in
        for h in hidden:
            layers += [nn.Linear(prev, h), nn.SiLU(), nn.Dropout(drop)]
            prev = h
        layers.append(nn.Linear(prev, 1))
        return nn.Sequential(*layers)

    def _loss(self, eta, y, w):
        import torch
        mu = torch.exp(torch.clamp(eta, ETA_LO, ETA_HI))
        if self.family == "poisson":
            l = mu - y * eta
        else:
            p = self.power
            l = -y * torch.exp((1 - p) * eta) / (1 - p) + torch.exp((2 - p) * eta) / (2 - p)
        return (w * l).sum() / w.sum()

    def fit(self, X, y, exposure=None, weight=None, X_val=None, y_val=None, exposure_val=None, weight_val=None,
            offset=None, offset_val=None):
        import torch
        started = time.time()
        torch.manual_seed(self.seed)
        torch.set_num_threads(max(1, min(8, (__import__("os").cpu_count() or 2) - 1)))
        if not self.features:
            self.features = list(X.columns)
        x = _owned(self._matrix(X))
        y = np.clip(np.asarray(y, dtype="float64"), 0, None)
        e = self._exp(exposure, len(y))
        w = np.ones(len(y)) if weight is None else np.asarray(weight, dtype="float64")
        o = np.zeros(len(y)) if offset is None else np.asarray(offset, dtype="float64")
        keep = (e > 0) & np.isfinite(y) & np.isfinite(o) & (w > 0)
        if not keep.any():
            raise ModelError("nn: no rows with exposure")
        if not keep.all():
            x, y, e, w, o = x[keep], y[keep], e[keep], w[keep], o[keep]
        self.lo, self.hi = x.min(axis=0), x.max(axis=0)
        self.mean, self.std = x.mean(axis=0), x.std(axis=0)
        self.std[self.std < 1e-9] = 1.0
        scale = np.log(e) + o
        self.bias0 = float(np.log(max(np.sum(w * y), 1e-12)) - np.log(max(np.sum(w * np.exp(scale)), 1e-300)))
        net = self._net(x.shape[1])
        with torch.no_grad():
            net[-1].bias.fill_(self.bias0)
        opt = torch.optim.Adam(net.parameters(), lr=float(self.params.get("lr", 2e-3)), weight_decay=1e-5)

        def tens(a):
            return torch.as_tensor(np.asarray(a, dtype="float32"))
        x -= self.mean                               # in place: two million rows x 150 inputs is 2 GB a copy
        x /= self.std
        xt, yt = tens(x), tens(y)
        del x
        ot, wt = tens(scale), tens(w)
        have_val = X_val is not None and y_val is not None and len(y_val)
        if have_val:
            yva = np.asarray(y_val, dtype="float64")
            ev = self._exp(exposure_val, len(yva))
            ova = np.zeros(len(yva)) if offset_val is None else np.asarray(offset_val, dtype="float64")
            kv = (ev > 0) & np.isfinite(yva) & np.isfinite(ova)
            have_val = bool(kv.any())
            xv = tens(self._inputs(X_val)[kv])
            yv, ov = tens(np.clip(yva[kv], 0, None)), tens(np.log(np.maximum(ev[kv], 1e-300)) + ova[kv])
            wv = tens((np.ones(len(yva)) if weight_val is None else np.asarray(weight_val, dtype="float64"))[kv])
        # at least ~50 optimiser steps per epoch, however small the sample
        bs = int(np.clip(len(yt) // 50, 256, int(self.params.get("batch_size", 4096))))
        best, best_state, bad = np.inf, None, 0
        g = torch.Generator().manual_seed(self.seed)
        epochs = int(self.params.get("epochs", 30))
        for epoch in range(epochs):
            net.train()
            perm = torch.randperm(len(yt), generator=g)
            for i in range(0, len(yt), bs):
                idx = perm[i:i + bs]
                opt.zero_grad()
                loss = self._loss(net(xt[idx]).squeeze(-1) + ot[idx], yt[idx], wt[idx])
                loss.backward()
                torch.nn.utils.clip_grad_norm_(net.parameters(), 5.0)
                opt.step()
            if have_val:
                net.eval()
                with torch.no_grad():
                    vl = float(self._loss(_eta_chunks(net, xv) + ov, yv, wv))
                if vl < best - 1e-7:
                    best, bad = vl, 0
                    best_state = {k: v.detach().clone() for k, v in net.state_dict().items()}
                else:
                    bad += 1
                    if bad >= int(self.params.get("patience", 4)):
                        break
        if best_state is not None:
            net.load_state_dict(best_state)
        self.state_dict = {k: v.cpu().numpy() for k, v in net.state_dict().items()}
        self.info = {"rows": int(len(y)), "epochs": epoch + 1, "seconds": round(time.time() - started, 2)}
        self.info["train_deviance"] = self._dev(y, self.predict(X.loc[keep], e, offset=o), w)
        if have_val:
            self.info["val_deviance"] = self._dev(np.asarray(y_val, dtype="float64"),
                                                  self.predict(X_val, exposure_val, offset=offset_val), weight_val)
        return self

    def predict(self, X, exposure=None, offset=None):
        import torch
        if self.state_dict is None:
            raise ModelError("nn is not fitted")
        net = self._net(len(self.features))
        net.load_state_dict({k: torch.as_tensor(v) for k, v in self.state_dict.items()})
        net.eval()
        with torch.no_grad():
            eta = _eta_chunks(net, torch.as_tensor(self._inputs(X).astype("float32"))).numpy().astype("float64")
        if offset is not None:
            eta = eta + np.nan_to_num(np.asarray(offset, dtype="float64"))
        e = self._exp(exposure, len(eta))
        return np.where(e > 0, _link_inverse(eta, "poisson") * e, 0.0)

    def to_state(self):
        return {"algorithm": self.algorithm, "family": self.family, "power": self.power,
                "features": self.features, "seed": self.seed, "params": self.params,
                "mean": self.mean, "std": self.std, "lo": self.lo, "hi": self.hi,
                "state_dict": self.state_dict, "bias0": self.bias0, "info": self.info}

    @classmethod
    def from_state(cls, s):
        m = cls(s["family"], s["power"], s["features"], s["seed"], **(s.get("params") or {}))
        m.mean, m.std = np.asarray(s["mean"]), np.asarray(s["std"])
        m.lo = None if s.get("lo") is None else np.asarray(s["lo"])
        m.hi = None if s.get("hi") is None else np.asarray(s["hi"])
        m.state_dict, m.bias0, m.info = s["state_dict"], s.get("bias0", 0.0), dict(s.get("info") or {})
        return m


def _owned(x: np.ndarray) -> np.ndarray:
    """An array that is safe to change in place: pandas hands back a read-only view when the frame
    already holds float64 (copy-on-write), and a fresh array when it converts from float32."""
    return x if x.flags.writeable else x.copy()


def _eta_chunks(net, x, rows: int = 262144):
    """The network's output in slices, so two million rows never sit in one activation matrix."""
    import torch
    if len(x) <= rows:
        return net(x).squeeze(-1)
    return torch.cat([net(x[i:i + rows]).squeeze(-1) for i in range(0, len(x), rows)])


# ------------------------------------------------------------- anchored
class AnchoredEstimator(Estimator):
    """A GLM's linear predictor as the offset of a GBM or an MLP (algorithm glm_gbm / glm_nn).

    The GLM carries the level and its log-linear trend; the inner model learns the corrections the
    GLM cannot (interactions, curvature) inside the training range, where they are bounded - a tree's
    leaves, a network on inputs held to the range. Past the range (a match bigger than any in training)
    the prediction follows the GLM's trend instead of stopping at the biggest leaf.

    Only the inputs in ``extrapolate`` (None = all) carry the trend - for turnover the money levels.
    Every other input is held to its training range inside the anchor too: a weekday, a pool count or
    a league level the GLM has not seen says nothing about how much bigger the money will be, and a
    GLM pushed along it can be far off. The trend is capped at ``cap`` times the anchor at the edge."""

    def __init__(self, inner: str, family="tweedie", power=1.5, glm: Optional["GLMEstimator"] = None,
                 inner_est: Optional[Estimator] = None, cap: float = 10.0,
                 extrapolate: Optional[Sequence[str]] = None):
        super().__init__(family, power)
        self.inner_name = inner
        self.algorithm = "glm_" + inner
        self.glm = glm
        self.inner = inner_est
        self.cap = float(cap)
        self.extrapolate = None if extrapolate is None else list(extrapolate)
        self.lo = self.hi = None

    def fit(self, X, y, exposure=None, weight=None, X_val=None, y_val=None, exposure_val=None, weight_val=None):
        started = time.time()
        if self.glm.beta is None:
            self.glm.fit(X, y, exposure=exposure, weight=weight, X_val=X_val, y_val=y_val,
                         exposure_val=exposure_val, weight_val=weight_val)
        e = self._exp(exposure, len(X))
        xg = self.glm._matrix(X)[e > 0]
        self.lo, self.hi = np.min(xg, axis=0), np.max(xg, axis=0)
        self.inner.fit(X, y, exposure=exposure, weight=weight, X_val=X_val, y_val=y_val, exposure_val=exposure_val,
                       weight_val=weight_val, offset=self.anchor(X),
                       offset_val=None if X_val is None else self.anchor(X_val))
        self.features = list(dict.fromkeys(list(self.glm.features) + list(self.inner.features)))
        self.info = dict(self.inner.info)
        self.info.update(anchor="glm", glm_val_deviance=self.glm.info.get("val_deviance"),
                         seconds=round(time.time() - started, 2))
        return self

    def _free(self) -> np.ndarray:
        """Which GLM inputs may carry the trend past the training range."""
        if self.extrapolate is None:
            return np.ones(len(self.glm.features), dtype=bool)
        keep = set(self.extrapolate)
        return np.array([f in keep for f in self.glm.features], dtype=bool)

    def anchor(self, X) -> np.ndarray:
        """The GLM's linear predictor with every input held to its training range, plus - for the inputs
        allowed to extrapolate - their trend past it, capped at log(cap)."""
        x = self.glm._matrix(X)
        if self.lo is None:
            return np.clip(self.glm.eta_matrix(x), ETA_LO, ETA_HI)
        held = np.clip(x, self.lo, self.hi)
        eta = self.glm.eta_matrix(held)
        free = self._free()
        if free.any():
            moved = held.copy()
            moved[:, free] = x[:, free]
            lim = float(np.log(max(self.cap, 1.0)))
            eta = eta + np.clip(self.glm.eta_matrix(moved) - eta, -lim, lim)
        return np.clip(eta, ETA_LO, ETA_HI)

    def outside(self, X) -> np.ndarray:
        """Rows with an extrapolating input past its training range (the rows the anchor carries on)."""
        if self.lo is None:
            return np.zeros(len(X), dtype=bool)
        free = self._free()
        x = self.glm._matrix(X)[:, free]
        return ((x < self.lo[free] - 1e-9) | (x > self.hi[free] + 1e-9)).any(axis=1)

    def predict(self, X, exposure=None):
        if self.glm is None or self.glm.beta is None or self.inner is None:
            raise ModelError("{} is not fitted".format(self.algorithm))
        return self.inner.predict(X, exposure=exposure, offset=self.anchor(X))

    def importance(self) -> Dict[str, float]:
        f = getattr(self.inner, "importance", None)
        return f() if f else {}

    def to_state(self):
        return {"algorithm": self.algorithm, "inner_name": self.inner_name, "family": self.family,
                "power": self.power, "cap": self.cap, "extrapolate": self.extrapolate, "lo": self.lo, "hi": self.hi,
                "features": self.features, "glm": self.glm.to_state(), "inner": self.inner.to_state(),
                "info": self.info}

    @classmethod
    def from_state(cls, s):
        m = cls(s["inner_name"], s["family"], s["power"], GLMEstimator.from_state(s["glm"]),
                load_estimator(s["inner"]), s.get("cap", 10.0), s.get("extrapolate"))
        m.lo = None if s.get("lo") is None else np.asarray(s["lo"], dtype="float64")
        m.hi = None if s.get("hi") is None else np.asarray(s["hi"], dtype="float64")
        m.features, m.info = list(s.get("features") or []), dict(s.get("info") or {})
        return m


# ------------------------------------------------------------- factory
REGISTRY = {"glm": GLMEstimator, "gam": GAMEstimator, "gbm": GBMEstimator, "nn": NNEstimator}
ANCHORED = ("glm_gbm", "glm_nn")


def available_algorithms() -> Dict[str, bool]:
    gbm, nn = gbm_backend() is not None, nn_backend()
    return {"glm": True, "gam": True, "gbm": gbm, "nn": nn, "glm_gbm": gbm, "glm_nn": nn, "naive": True}


def make_estimator(algorithm: str, family: str, power: float, settings=None, features=None,
                   features_glm=None, extrapolate=None) -> Estimator:
    """Build an estimator from settings. Raises EstimatorUnavailable for a missing backend.
    An anchored algorithm takes ``features`` for its inner model, ``features_glm`` for the GLM and
    ``extrapolate`` for the GLM inputs that may carry its trend past the training range (None = all)."""
    t = settings.turnover if settings is not None else None
    if algorithm in ANCHORED:
        inner = algorithm.split("_", 1)[1]
        glm = GLMEstimator(family, power, ridge=t.ridge if t else 1e-3, features=features_glm or features)
        return AnchoredEstimator(inner, family, power, glm, make_estimator(inner, family, power, settings, features),
                                 cap=float(getattr(t, "extrapolation_cap", 10.0)) if t else 10.0,
                                 extrapolate=extrapolate)
    if algorithm == "glm":
        return GLMEstimator(family, power, ridge=t.ridge if t else 1e-3, features=features)
    if algorithm == "gam":
        return GAMEstimator(family, power, n_knots=t.gam_knots if t else 8,
                            lambdas=t.gam_lambdas if t else (0.1, 1.0, 10.0), features=features,
                            ridge=t.ridge if t else 1e-3)
    if algorithm == "gbm":
        return GBMEstimator(family, power, features=features, seed=t.seed if t else 7, **(t.gbm if t else {}))
    if algorithm == "nn":
        return NNEstimator(family, power, features=features, seed=t.seed if t else 7, **(t.nn if t else {}))
    raise ModelError("unknown algorithm {!r}; known: {}".format(algorithm, sorted(REGISTRY) + list(ANCHORED)))


def load_estimator(state: dict) -> Estimator:
    if state.get("algorithm") in ANCHORED:
        return AnchoredEstimator.from_state(state)
    cls = REGISTRY.get(state.get("algorithm"))
    if cls is None:
        raise ModelError("artifact has unknown algorithm {!r}".format(state.get("algorithm")))
    return cls.from_state(state)
