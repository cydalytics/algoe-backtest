"""Theta -> probabilities -> sell odds. One pricer for backtest, optimiser and desk."""
