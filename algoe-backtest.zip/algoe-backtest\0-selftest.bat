@echo off
REM Verify the code on synthetic data. Touches no real data at all.
setlocal
cd /d "%~dp0"
python -m backtest.run selftest
pause
