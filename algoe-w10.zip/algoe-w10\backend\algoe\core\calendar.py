"""
Calendar

Bucket arithmetic and the Hong Kong calendar the day-level features use.

A bucket is named by its START: bucket T covers [T, T + 5 min). A forecast
for bucket T may only use what was known at T. ``elapsed_in_bucket`` is what
the intra-bucket nowcast needs when a focused match is refreshed mid-bucket.

HK public holidays for 2024-2027 are the list from the feature notebooks.
Later years come from ``settings.paths.holidays_file`` (one ISO date per
line), so the calendar never needs a code change to roll forward.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Iterable, Optional, Set

import numpy as np
import pandas as pd

from .logging import get_logger

logger = get_logger(__name__)

_NOTEBOOK_HOLIDAYS = {
    2024: [(1, 1), (2, 10), (2, 11), (2, 12), (2, 13), (3, 29), (3, 30), (4, 1), (4, 4), (5, 1),
           (5, 15), (6, 10), (7, 1), (9, 18), (10, 1), (10, 11), (12, 25), (12, 26)],
    2025: [(1, 1), (1, 29), (1, 30), (1, 31), (4, 4), (4, 18), (4, 19), (4, 21), (5, 1), (5, 5),
           (5, 31), (6, 2), (7, 1), (10, 1), (10, 7), (10, 29), (12, 25), (12, 26)],
    2026: [(1, 1), (2, 17), (2, 18), (2, 19), (4, 3), (4, 4), (4, 6), (5, 1), (5, 19), (6, 19),
           (7, 1), (9, 25), (10, 1), (10, 7), (12, 25), (12, 26)],
    2027: [(1, 1), (2, 6), (2, 8), (2, 9), (3, 26), (3, 27), (3, 29), (4, 5), (5, 1), (5, 13),
           (6, 9), (7, 1), (9, 16), (10, 1), (10, 8), (12, 25), (12, 27)],
}


class HKCalendar:
    def __init__(self, holidays_file: Optional[str] = None):
        self.holidays: Set[date] = {date(y, m, d) for y, days in _NOTEBOOK_HOLIDAYS.items()
                                    for m, d in days}
        if holidays_file and Path(holidays_file).exists():
            added = 0
            for line in Path(holidays_file).read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    self.holidays.add(pd.Timestamp(line).date())
                    added += 1
                except ValueError:
                    logger.warning("holiday file line %r is not a date", line)
            logger.info("calendar: %d extra holiday(s) from %s", added, holidays_file)
        self.last_year = max(d.year for d in self.holidays)

    def is_holiday(self, stamps: pd.Series) -> np.ndarray:
        d = pd.to_datetime(stamps).dt.date
        years = pd.to_datetime(stamps).dt.year
        if len(years) and int(years.max()) > self.last_year:
            logger.warning("calendar has no holidays after %d; later dates count as ordinary days",
                           self.last_year)
        return d.isin(self.holidays).to_numpy()


def floor_bucket(stamp, minutes: int = 5) -> pd.Timestamp:
    return pd.Timestamp(stamp).floor("{}min".format(int(minutes)))


def elapsed_in_bucket(now, minutes: int = 5) -> float:
    """Minutes already gone in the bucket containing ``now`` (0 <= x < minutes)."""
    now = pd.Timestamp(now)
    return float((now - floor_bucket(now, minutes)).total_seconds() / 60.0)


def day_range(start, end) -> list:
    lo, hi = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
    if hi < lo:
        return []
    return list(pd.date_range(lo, hi, freq="D"))


def fourier(values: np.ndarray, period: float, harmonics: int = 1) -> dict:
    """sin/cos pairs of ``values`` on a cycle of length ``period``."""
    out = {}
    v = np.asarray(values, dtype="float64")
    for k in range(1, harmonics + 1):
        out["sin{}".format(k)] = np.sin(2 * np.pi * k * v / period)
        out["cos{}".format(k)] = np.cos(2 * np.pi * k * v / period)
    return out


def iter_months(days: Iterable[pd.Timestamp]):
    """Group days by calendar month, oldest first: {month_start: [days]}."""
    out = {}
    for d in sorted(pd.Timestamp(x).normalize() for x in days):
        out.setdefault(d.to_period("M").start_time, []).append(d)
    return out
