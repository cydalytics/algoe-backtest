"""Versioned model artifacts with a champion pointer."""
