:HL["/_next/static/chunks/1edgiabh3pboy.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"4mctR74w9rCihqR0aODDO"}
