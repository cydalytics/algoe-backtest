"""
Mix Study - how the money splits, and what an event inside the bucket does to it

    selection_frame(dd, pred)       the forecastable selection-buckets with what the study groups by
    event_buckets(dd, inc, step)    every (match, bucket) with a goal, red card or corner inside it: which,
                                    how many minutes in, whose, the favourite's strength, the score after
    retune(frame, evb, shift)       the bucket forecast re-tuned at the event's minute with the fitted
                                    EventShift, as the live engine does when the event arrives
    MixScores                       proportion metrics for the bet-type mix of a match, its pool mix, the
                                    selection mix of each pool and the side mix of each bet type (the overs'
                                    share of the goal totals, the favourite's share of the handicap ...)
    ZeroSplit                       the selection WAPE split into error on rows that took money and money
                                    forecast on rows that took none
    run(...)                        one pass over the fit days (EventShift) and one over the test days

Proportion metrics, per group (a match-bucket for the bet-type and pool mix, a pool-bucket for the
selection mix, a bet type for the side mix) with actual shares a and forecast shares q:

    misallocated money   = 1/2 x sum |a - q|          the share of the money on the wrong item; 0-100%
    share log-loss       = - sum a x log q~           q~ = 99% q + 1% uniform, so a zero share is finite

both weighted by the group's money; groups that took nothing or hold one item are left out.

Change Log:
-----------
2026-10-11      Initialize
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import ref_phase
from ..features.engineer import _kickoff_value
from ..models.event_shift import (CLOCK, LEVELS, PRIORITY, EventShift, clock_label, incident_table, main_provider,
                                  side_groups, state_label, strength_label, who_label)

logger = get_logger(__name__)

SMOOTH = 0.01
MIX_LEVELS = ("bet type", "pool", "selection", "side")
MEASURES = ("hilo", "over", "hdc", "hdc_fav", "x1x2", "corners", "c_over")
MEASURE_LABELS = {"hilo": "HiLo share of the match", "over": "Over share of HiLo", "hdc": "handicap share",
                  "hdc_fav": "favourite's share of the handicap", "x1x2": "1X2 share", "corners": "corner totals share",
                  "c_over": "Over share of corner totals"}


def _num(frame: pd.DataFrame, col: str, default: float = np.nan) -> np.ndarray:
    if col not in frame.columns:
        return np.full(len(frame), default, dtype="float64")
    return pd.to_numeric(frame[col], errors="coerce").to_numpy(dtype="float64")


# ------------------------------------------------------------------ frames
def _cat(s: pd.DataFrame, col: str, fill: str, keep: np.ndarray) -> pd.Categorical:
    v = s[col] if col in s.columns else pd.Series(fill, index=s.index)
    return pd.Categorical(v[keep].astype("string").fillna(fill))


def selection_frame(dd, pred: pd.DataFrame, forecastable_only: bool = True) -> pd.DataFrame:
    """Selection-buckets: keys, bet type and side group, phase, money and its forecasts. Forecastable rows
    only by default (the split); every row, as the leaderboard scores them, for accuracy - a row that was
    not on the board at the bucket start is forecast at last 5 minutes by every pipeline. Labels are
    categoricals: an office day has millions of rows."""
    s = dd.sel
    if len(pred) != len(s):
        raise ValueError("the forecasts do not line up with the day's rows")
    fc = s["forecastable"].to_numpy(dtype=bool)
    keep = fc if forecastable_only else np.ones(len(s), dtype=bool)

    def money(col):
        return np.clip(np.nan_to_num(pred[col].to_numpy(dtype="float64")[keep]), 0, None)
    f = pd.DataFrame({
        "match_id": pd.to_numeric(s["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()[keep],
        "bucket": pd.to_datetime(s["bucket"]).astype("datetime64[ns]").to_numpy()[keep],
        "pool_name": _cat(s, "pool_name", "?", keep), "family": _cat(s, "family", "other", keep),
        "side": _cat(s, "side", "?", keep), "clock": _cat(s, "clock_bin", "unknown", keep),
        "window": _cat(s, "event_window", "unknown", keep), "league": _cat(s, "league_code", "unknown", keep),
        "fav_sign": np.sign(np.nan_to_num(_num(s, "fav_sign", 0.0)[keep])),
        "y": money("actual"), "model": money("forecast"), "last5": money("last5"), "forecastable": fc[keep]})
    ph = _cat(s, "phase", "prematch", keep)
    labels = np.where(ref_phase(np.asarray(ph.categories, dtype=object)) == "prematch", "pre-match", "in play")
    f["phase"] = pd.Categorical(labels[ph.codes].astype(object)) if len(ph.categories) \
        else pd.Categorical(np.full(len(f), "pre-match", dtype=object))
    # side groups for each distinct (bet type, side, favourite sign), mapped back to the rows
    combo = np.column_stack([f["family"].cat.codes.to_numpy(), f["side"].cat.codes.to_numpy(),
                             f["fav_sign"].to_numpy().astype("int64")]) if len(f) else np.zeros((0, 3), "int64")
    uniq, inv = np.unique(combo, axis=0, return_inverse=True)
    if len(uniq):
        names = side_groups(np.asarray(f["family"].cat.categories, dtype=object)[uniq[:, 0]],
                            np.asarray(f["side"].cat.categories, dtype=object)[uniq[:, 1]], uniq[:, 2])
        f["group"] = pd.Categorical(np.asarray(names, dtype=object)[np.asarray(inv).ravel()])
    else:
        f["group"] = pd.Categorical([])
    if forecastable_only:
        usual = _usual_share(dd, f)
        if usual is not None:
            f["usual"] = usual
    return f


def _usual_share(dd, f: pd.DataFrame) -> Optional[np.ndarray]:
    """Each row's part of its bet type's usual share of the money (the trailing reference): a bet type's
    rows in a match-bucket add up to that share."""
    p = dd.pool
    if p is None or p.empty or "p_ref_share" not in p.columns:
        return None
    ref = pd.DataFrame({"match_id": pd.to_numeric(p["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy(),
                        "pool_name": p["pool_name"].astype("string").fillna("?").to_numpy(dtype=object),
                        "bucket": pd.to_datetime(p["bucket"]).astype("datetime64[ns]").to_numpy(),
                        "u": np.exp(_num(p, "p_ref_share")) - 1e-4}).drop_duplicates(["match_id", "pool_name", "bucket"])
    left = pd.DataFrame({"match_id": f["match_id"].to_numpy(), "bucket": f["bucket"].to_numpy(),
                         "pool_name": f["pool_name"].astype(object).to_numpy()})
    u = left.merge(ref, on=["match_id", "pool_name", "bucket"], how="left")["u"].to_numpy(dtype="float64")
    u = np.where(np.isfinite(u), np.clip(u, 1e-3, None), 1e-3)
    n = f.groupby(["match_id", "bucket", "family"], sort=False, observed=True)["y"].transform("size")
    return u / np.maximum(n.to_numpy(dtype="float64"), 1.0)


def event_buckets(dd, inc: pd.DataFrame, step: pd.Timedelta) -> pd.DataFrame:
    """One row per in-play (match, bucket) with a goal, red card or corner inside it."""
    cols = ["match_id", "bucket", "event_id", "k", "w", "home", "away", "fav_sign", *LEVELS]
    m = dd.match
    cnt = ["home_goals", "away_goals", "home_reds", "away_reds", "home_corners", "away_corners"]
    if m is None or m.empty or any(c not in m.columns for c in cnt):
        return pd.DataFrame(columns=cols)
    m = m.sort_values(["match_id", "bucket"]).reset_index(drop=True)
    m = m.assign(bucket=pd.to_datetime(m["bucket"]).astype("datetime64[ns]"))
    sup_ko = _kickoff_value(m, "sup") if "sup" in m.columns else np.full(len(m), np.nan)
    nxt = m.groupby("match_id", sort=False)[["bucket"] + cnt].shift(-1)
    follows = ((nxt["bucket"] - m["bucket"]) == step).to_numpy()
    ip = np.nan_to_num(_num(m, "inplay", 0.0)) > 0
    d = {c: np.nan_to_num(pd.to_numeric(nxt[c], errors="coerce").to_numpy(dtype="float64") - _num(m, c)) for c in cnt}
    pairs = {"goal": ("home_goals", "away_goals"), "red": ("home_reds", "away_reds"),
             "corner": ("home_corners", "away_corners")}
    kind = np.full(len(m), "", dtype=object)
    home = np.zeros(len(m), dtype=bool)
    away = np.zeros(len(m), dtype=bool)
    for k in reversed(PRIORITY):                 # corner, then goal, then red: the rarer event labels the bucket
        hk, ak = d[pairs[k][0]] > 0, d[pairs[k][1]] > 0
        hit = follows & ip & (hk | ak)
        kind[hit], home[hit], away[hit] = k, hk[hit], ak[hit]
    sel = kind != ""
    if not sel.any():
        return pd.DataFrame(columns=cols)
    fav = np.nan_to_num(_num(m, "fav_sign", 0.0))
    out = pd.DataFrame({"match_id": pd.to_numeric(m["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()[sel],
                        "bucket": m["bucket"].to_numpy()[sel], "event": kind[sel], "home": home[sel], "away": away[sel],
                        "fav_sign": fav[sel], "_minute": np.nan_to_num(_num(m, "minute", 0.0))[sel],
                        "_sup": np.asarray(sup_ko, dtype="float64")[sel],
                        "_hg": pd.to_numeric(nxt["home_goals"], errors="coerce").to_numpy(dtype="float64")[sel],
                        "_ag": pd.to_numeric(nxt["away_goals"], errors="coerce").to_numpy(dtype="float64")[sel]})
    T = step / pd.Timedelta(minutes=1)
    out["k"] = _minutes_in(out, inc, step)
    out["w"] = np.clip(out["k"].to_numpy(dtype="float64") / T, 0.0, 1.0)
    out["clock"] = clock_label(out["_minute"].to_numpy() + out["k"].to_numpy())
    out["who"] = who_label(out["fav_sign"], out["home"], out["away"])
    out["strength"] = strength_label(out["fav_sign"], out["_sup"])
    out["state"] = state_label(out["fav_sign"], out["_hg"], out["_ag"])
    out["event_id"] = out["match_id"].astype(str) + "@" + pd.to_datetime(out["bucket"]).dt.strftime("%Y-%m-%d %H:%M")
    return out[cols].reset_index(drop=True)


def _minutes_in(evb: pd.DataFrame, inc: pd.DataFrame, step: pd.Timedelta) -> np.ndarray:
    """How far into the bucket the event came (the main provider's first one of that kind); half the
    bucket where the incidents do not say."""
    T = step / pd.Timedelta(minutes=1)
    k = np.full(len(evb), T / 2.0)
    if inc is None or inc.empty or evb.empty:
        return k
    i = main_provider(inc[(inc["sign"] > 0) & inc["match_id"].isin(evb["match_id"].unique())])
    if i.empty:
        return k
    i = i.assign(bucket=pd.to_datetime(i["t"]).dt.floor("{:g}min".format(T)).astype("datetime64[ns]"))
    first = i.groupby(["match_id", "bucket", "kind"], sort=False)["t"].min().reset_index().rename(columns={"kind": "event"})
    j = evb[["match_id", "bucket", "event"]].merge(first, on=["match_id", "bucket", "event"], how="left")
    got = (pd.to_datetime(j["t"]) - pd.to_datetime(j["bucket"])).dt.total_seconds().to_numpy(dtype="float64") / 60.0
    return np.where(np.isfinite(got), np.clip(got, 0.0, T), k)


def retune(frame: pd.DataFrame, evb: pd.DataFrame, shift: Optional[EventShift]) -> Tuple[np.ndarray, np.ndarray]:
    """The model's forecast with each event bucket re-tuned at the event's minute: F x (w + (1 - w) M);
    and M per row (1 outside event buckets)."""
    out = frame["model"].to_numpy(dtype="float64").copy()
    mult = np.ones(len(frame))
    if shift is None or evb is None or evb.empty:
        return out, mult
    j = frame[["match_id", "bucket"]].merge(evb[["match_id", "bucket", "event_id", "w"]],
                                            on=["match_id", "bucket"], how="left")
    hit = j["event_id"].notna().to_numpy()
    if not hit.any():
        return out, mult
    labels = evb.set_index("event_id")[list(LEVELS)].to_dict("index")
    sub = j.loc[hit, ["event_id", "w"]]
    groups = frame["group"].to_numpy()[hit]
    cache: Dict[tuple, float] = {}
    m = np.empty(len(sub))
    for i, (e, g) in enumerate(zip(sub["event_id"].to_numpy(), groups)):
        key = (e, g)
        if key not in cache:
            cache[key] = shift.lookup(g, labels[e])
        m[i] = cache[key]
    w = sub["w"].to_numpy(dtype="float64")
    out[hit] = out[hit] * (w + (1.0 - w) * m)
    mult[hit] = m
    return out, mult


def shift_rows(frame: pd.DataFrame, evb: pd.DataFrame) -> pd.DataFrame:
    """EventShift.fit's rows: money and forecast per (event bucket, side group)."""
    if evb.empty:
        return pd.DataFrame(columns=["event_id", "group", *LEVELS, "y", "f", "w"])
    j = frame[["match_id", "bucket", "group", "y", "model"]].merge(
        evb[["match_id", "bucket", "event_id"]], on=["match_id", "bucket"], how="inner")
    g = j.groupby(["event_id", "group"], sort=False, observed=True).agg(y=("y", "sum"), f=("model", "sum")).reset_index()
    g["group"] = g["group"].astype(str)
    lab = evb[["event_id", "w", *LEVELS]].drop_duplicates("event_id")
    return g.merge(lab, on="event_id", how="left")


# ------------------------------------------------------- bucket measures
def bucket_measures(frame: pd.DataFrame, value: str) -> pd.DataFrame:
    """Per (match, bucket): the money in ``value`` and how it splits (MEASURES)."""
    f = frame.reset_index(drop=True)
    v = f[value].astype("float64")
    key = ["match_id", "bucket"]
    tot = v.groupby([f["match_id"], f["bucket"]], sort=False).sum()
    fam = v.groupby([f["match_id"], f["bucket"], f["family"]], sort=False, observed=True).sum().unstack(fill_value=0.0)
    grp = v.groupby([f["match_id"], f["bucket"], f["group"]], sort=False, observed=True).sum().unstack(fill_value=0.0)
    fam, grp = fam.reindex(tot.index).fillna(0.0), grp.reindex(tot.index).fillna(0.0)

    def col(t, c):
        return t[c].to_numpy(dtype="float64") if c in t.columns else np.zeros(len(t))

    def div(a, b):
        return np.where(b > 0, a / np.where(b > 0, b, 1.0), np.nan)
    T = tot.to_numpy(dtype="float64")
    gt, hdc, ct = col(fam, "goal_total"), col(fam, "goal_hdc"), col(fam, "corner_total")
    out = pd.DataFrame({"money": T, "hilo": div(gt, T), "over": div(col(grp, "goal_total:over"), gt),
                        "hdc": div(hdc, T),
                        "hdc_fav": div(col(grp, "goal_hdc:favourite") + col(grp, "goal_hdc:home"), hdc),
                        "x1x2": div(col(fam, "goal_1x2"), T), "corners": div(ct, T),
                        "c_over": div(col(grp, "corner_total:over"), ct)}, index=tot.index)
    out.index.names = key
    return out


# ------------------------------------------------------------ mix scores
class MixScores:
    """Misallocated money and share log-loss, summed over days, per level x method x cut."""

    def __init__(self):
        self.sums: Dict[tuple, np.ndarray] = {}          # -> [money, money x misallocated, money x log-loss, groups]

    @staticmethod
    def _spec(level: str):
        return {"bet type": (["match_id", "bucket"], "family"), "pool": (["match_id", "bucket"], "pool_name"),
                "selection": (["match_id", "bucket", "pool_name"], None),
                "side": (["match_id", "bucket", "family"], "group")}[level]

    def add(self, frame: pd.DataFrame, methods: Dict[str, Dict[str, np.ndarray]], cuts: Dict[str, np.ndarray]) -> None:
        """``methods``: level -> {method: per-row forecast}; ``cuts``: dim -> per-row label, constant inside a
        match-bucket (the side level also gets a 'bet type' cut)."""
        if frame.empty:
            return
        y = frame["y"].to_numpy(dtype="float64")
        for level, ms in methods.items():
            if not ms:
                continue
            gcols, item = self._spec(level)
            g = frame.groupby(gcols, sort=False, observed=True).ngroup().to_numpy().astype("int64")
            if item is None:
                cell = np.arange(len(frame))
            else:
                it = pd.factorize(frame[item])[0].astype("int64")
                _, cell = np.unique(g * (int(it.max()) + 1) + it, return_inverse=True)
            ncell = int(cell.max()) + 1
            ng = int(g.max()) + 1
            cell_group = np.zeros(ncell, dtype="int64")
            cell_group[cell] = g
            sy = np.bincount(cell, weights=y, minlength=ncell)
            A = np.bincount(cell_group, weights=sy, minlength=ng)
            nitems = np.bincount(cell_group, minlength=ng).astype("float64")
            ok_g = (A > 0) & (nitems >= 2)
            a = sy / np.where(A[cell_group] > 0, A[cell_group], 1.0)
            first = np.full(ng, -1, dtype="int64")
            first[g[::-1]] = np.arange(len(g))[::-1]
            labs = {dim: np.asarray(v, dtype=object)[first] for dim, v in cuts.items()}
            if level == "side":
                labs["bet type"] = frame["family"].to_numpy(dtype=object)[first]
            for name, fv in ms.items():
                sf = np.bincount(cell, weights=np.asarray(fv, dtype="float64"), minlength=ncell)
                F = np.bincount(cell_group, weights=sf, minlength=ng)
                q = np.where(F[cell_group] > 0, sf / np.where(F[cell_group] > 0, F[cell_group], 1.0),
                             1.0 / nitems[cell_group])
                tvd = 0.5 * np.bincount(cell_group, weights=np.abs(a - q), minlength=ng)
                qs = (1.0 - SMOOTH) * q + SMOOTH / nitems[cell_group]
                ll = -np.bincount(cell_group, weights=a * np.log(qs), minlength=ng)
                for dim, lab in [("all", np.full(ng, "all", dtype=object))] + list(labs.items()):
                    for v in pd.unique(lab[ok_g]):
                        msk = ok_g & (lab == v)
                        k = (level, name, dim, str(v))
                        acc = self.sums.setdefault(k, np.zeros(4))
                        acc += (A[msk].sum(), (A[msk] * tvd[msk]).sum(), (A[msk] * ll[msk]).sum(), msk.sum())

    def rows(self) -> List[dict]:
        out = []
        for (level, method, dim, value), s in self.sums.items():
            if s[0] <= 0:
                continue
            out.append({"level": level, "method": method, "dim": dim, "value": value, "groups": int(s[3]),
                        "money": float(s[0]), "misallocated": float(s[1] / s[0]), "share_log_loss": float(s[2] / s[0])})
        order = {k: i for i, k in enumerate(MIX_LEVELS)}
        out.sort(key=lambda r: (order.get(r["level"], 9), r["dim"] != "all", r["dim"], r["value"], r["method"]))
        return out


# ------------------------------------------------------------- zero split
class ZeroSplit:
    """Selection WAPE = error on rows that took money + money forecast on rows that went quiet (money last
    bucket, none now) + money forecast on rows dead in both; all over the money that arrived."""

    def __init__(self):
        self.sums: Dict[str, np.ndarray] = {}
        self.rows_n = np.zeros(4)                        # rows, zero, quiet, dead

    def add(self, frame: pd.DataFrame, methods: Dict[str, np.ndarray]) -> None:
        y = frame["y"].to_numpy(dtype="float64")
        l5 = frame["last5"].to_numpy(dtype="float64")
        zero = y <= 0
        quiet, dead = zero & (l5 > 0), zero & (l5 <= 0)
        self.rows_n += (len(y), zero.sum(), quiet.sum(), dead.sum())
        for name, f in methods.items():
            f = np.asarray(f, dtype="float64")
            acc = self.sums.setdefault(name, np.zeros(5))
            acc += (y.sum(), np.abs(y[~zero] - f[~zero]).sum(), f[quiet].sum(), f[dead].sum(), f.sum())

    def rows(self) -> List[dict]:
        n, z, q, d = self.rows_n
        out = []
        for name, (Y, ae, fq, fd, F) in self.sums.items():
            if Y <= 0:
                continue
            out.append({"method": name, "rows": int(n), "zero_rows": float(z / n) if n else None,
                        "quiet_rows": float(q / n) if n else None, "dead_rows": float(d / n) if n else None,
                        "wape": float((ae + fq + fd) / Y), "wape_money_rows": float(ae / Y),
                        "wape_quiet_rows": float(fq / Y), "wape_dead_rows": float(fd / Y),
                        "forecast_on_zero_rows": float((fq + fd) / F) if F > 0 else None})
        return out


# ---------------------------------------------------------- in-bucket
class InBucket:
    """Match WAPE, bias and per-row deviance by what happened inside the bucket."""

    def __init__(self):
        self.sums: Dict[tuple, np.ndarray] = {}          # -> [buckets, rows, Y, |Y - F|, F, deviance]

    def add(self, frame: pd.DataFrame, cls: np.ndarray, methods: Dict[str, np.ndarray]) -> None:
        y = frame["y"].to_numpy(dtype="float64")
        g = frame.groupby(["match_id", "bucket"], sort=False).ngroup().to_numpy()
        ng = int(g.max()) + 1 if len(g) else 0
        first = np.full(ng, -1, dtype="int64")
        first[g[::-1]] = np.arange(len(g))[::-1]
        gcls = np.asarray(cls, dtype=object)[first]
        Y = np.bincount(g, weights=y, minlength=ng)
        rows = np.bincount(g, minlength=ng)
        for name, f in methods.items():
            f = np.asarray(f, dtype="float64")
            F = np.bincount(g, weights=f, minlength=ng)
            mu = np.maximum(f, 1.0)                     # as the leaderboard scores it (HK$1 floor)
            dev = 2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))
            D = np.bincount(g, weights=dev, minlength=ng)
            for v in pd.unique(gcls):
                for label in ("all", v):
                    msk = gcls == v
                    acc = self.sums.setdefault((label, name), np.zeros(6))
                    acc += (msk.sum(), rows[msk].sum(), Y[msk].sum(), np.abs(Y[msk] - F[msk]).sum(), F[msk].sum(),
                            D[msk].sum())

    def rows(self) -> List[dict]:
        out = []
        for (cls, name), (nb, nr, Y, ae, F, D) in self.sums.items():
            if nb == 0:
                continue
            out.append({"inside": cls, "method": name, "buckets": int(nb), "rows": int(nr), "money": float(Y),
                        "match_wape": float(ae / Y) if Y > 0 else None,
                        "bias": float(F / Y - 1.0) if Y > 0 else None,
                        "deviance": float(D / nr) if nr else None})
        order = {"all": 0, "none": 1, "goal": 2, "red": 3, "corner": 4, "pre-match": 5}
        out.sort(key=lambda r: (order.get(r["inside"], 9), r["method"]))
        return out


# ------------------------------------------------------------ comparison
def _unit_deviance(y: np.ndarray, f: np.ndarray) -> np.ndarray:
    mu = np.maximum(f, 1.0)                             # as the leaderboard scores it (HK$1 floor)
    return 2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))


class Compare:
    """Every forecast on the same rows, cut every way: match WAPE (each slice's money per match-bucket),
    selection WAPE, bias and per-row deviance by day, phase, clock, event window, bet type, league and
    what happened inside the bucket - the baseline-vs-model view."""

    def __init__(self):
        self.sums: Dict[tuple, np.ndarray] = {}          # -> [match-buckets, rows, Y, |Y - F|, F, deviance, |y - f|]

    def add(self, frame: pd.DataFrame, dims: Dict[str, np.ndarray], methods: Dict[str, np.ndarray]) -> None:
        if frame.empty:
            return
        y = frame["y"].to_numpy(dtype="float64")
        mb = frame.groupby(["match_id", "bucket"], sort=False).ngroup().to_numpy().astype("int64")
        dev = {name: _unit_deviance(y, np.asarray(f, dtype="float64")) for name, f in methods.items()}
        for dim, lab in dims.items():
            codes, values = pd.factorize(np.asarray(lab, dtype=object))
            nv = max(len(values), 1)
            uniq, cell = np.unique(mb * nv + codes.astype("int64"), return_inverse=True)
            cv = (uniq % nv).astype("int64")                # each cell's slice value
            nc = len(uniq)
            Yc = np.bincount(cell, weights=y, minlength=nc)
            Rc = np.bincount(cell, minlength=nc).astype("float64")
            for name, f in methods.items():
                f = np.asarray(f, dtype="float64")
                Fc = np.bincount(cell, weights=f, minlength=nc)
                Dc = np.bincount(cell, weights=dev[name], minlength=nc)
                Ac = np.bincount(cell, weights=np.abs(y - f), minlength=nc)
                agg = np.column_stack([np.ones(nc), Rc, Yc, np.abs(Yc - Fc), Fc, Dc, Ac])
                per = np.zeros((nv, 7))
                np.add.at(per, cv, agg)
                for i, v in enumerate(values):
                    acc = self.sums.setdefault((dim, str(v), name), np.zeros(7))
                    acc += per[i]

    def rows(self) -> List[dict]:
        out = []
        for (dim, value, name), (nb, nr, Y, mae, F, D, ae) in self.sums.items():
            if nr == 0:
                continue
            out.append({"dim": dim, "value": value, "method": name, "buckets": int(nb), "rows": int(nr),
                        "money": float(Y), "forecast": float(F),
                        "match_wape": float(mae / Y) if Y > 0 else None, "wape": float(ae / Y) if Y > 0 else None,
                        "bias": float(F / Y - 1.0) if Y > 0 else None, "deviance": float(D / nr)})
        out.sort(key=lambda r: (r["dim"], r["value"], r["method"]))
        return out


ERROR_BINS = np.round(np.arange(-3.0, 3.0001, 0.2), 3)


class ErrorHist:
    """How far each match-bucket's forecast was from what arrived: log10((F + 1) / (Y + 1)), counted per
    forecast, in play and pre-match apart (0 = right; +1 = ten times too much)."""

    def __init__(self):
        self.counts: Dict[tuple, np.ndarray] = {}

    def add(self, frame: pd.DataFrame, methods: Dict[str, np.ndarray]) -> None:
        if frame.empty:
            return
        g = frame.groupby(["match_id", "bucket"], sort=False).ngroup().to_numpy()
        ng = int(g.max()) + 1
        first = np.full(ng, -1, dtype="int64")
        first[g[::-1]] = np.arange(len(g))[::-1]
        Y = np.bincount(g, weights=frame["y"].to_numpy(dtype="float64"), minlength=ng)
        phase = frame["phase"].to_numpy(dtype=object)[first]
        for name, f in methods.items():
            F = np.bincount(g, weights=np.asarray(f, dtype="float64"), minlength=ng)
            r = np.clip(np.log10((F + 1.0) / (Y + 1.0)), ERROR_BINS[0], ERROR_BINS[-1] - 1e-9)
            keep = (Y > 0) | (F > 0)
            for ph in ("in play", "pre-match"):
                m = keep & (phase == ph)
                h = np.histogram(r[m], bins=ERROR_BINS)[0].astype("float64")
                acc = self.counts.setdefault((ph, name), np.zeros(len(ERROR_BINS) - 1))
                acc += h

    def rows(self) -> List[dict]:
        out = []
        for (ph, name), c in self.counts.items():
            tot = c.sum()
            for lo, hi, n in zip(ERROR_BINS[:-1], ERROR_BINS[1:], c):
                out.append({"phase": ph, "method": name, "lo": float(lo), "hi": float(hi), "n": int(n),
                            "share": float(n / tot) if tot > 0 else 0.0})
        return out


def _match_series(frame: pd.DataFrame, dd, evb: pd.DataFrame, top: int, day) -> List[dict]:
    """The day's ``top`` biggest matches bucket by bucket: what arrived and what each forecast said."""
    if frame.empty:
        return []
    money = frame.groupby("match_id")["y"].sum().sort_values(ascending=False)
    cols = [c for c in ("y", "last5", "model", "retune") if c in frame.columns]
    m = dd.match
    names = m.drop_duplicates("match_id").set_index("match_id") if m is not None and len(m) else pd.DataFrame()
    minute = m.assign(bucket=pd.to_datetime(m["bucket"]).astype("datetime64[ns]")).set_index(
        ["match_id", "bucket"]) if m is not None and len(m) else None
    out = []
    for mid in money.index[:top]:
        sub = frame[frame["match_id"] == mid]
        b = sub.groupby("bucket", sort=True)[cols].sum()
        ph = sub.groupby("bucket", sort=True)["phase"].first().astype(object)
        live = np.flatnonzero(ph.to_numpy(dtype=object) == "in play")
        # the match and the three hours before kick-off; a match that did not start this day, its last four hours
        lo = max(0, int(live[0]) - 36) if len(live) else max(0, len(b) - 48)
        b = b.iloc[lo:]
        pts = []
        for t, row in b.iterrows():
            mi = None
            if minute is not None and (mid, t) in minute.index and "minute" in minute.columns:
                v = minute.loc[(mid, t), "minute"]
                mi = float(v.iloc[0] if hasattr(v, "iloc") else v)
            pts.append({"t": pd.Timestamp(t).strftime("%H:%M"), "minute": mi, "phase": str(ph.get(t, "")),
                        **{("actual" if c == "y" else c): round(float(row[c]), 1) for c in cols}})
        evs = []
        if evb is not None and len(evb):
            for r in evb[evb["match_id"] == mid].itertuples(index=False):
                evs.append({"t": pd.Timestamp(r.bucket).strftime("%H:%M"), "event": r.event, "who": r.who,
                            "k": float(r.k), "clock": r.clock, "state": r.state})
        home = str(names.loc[mid, "home_name"]) if "home_name" in names.columns and mid in names.index else ""
        away = str(names.loc[mid, "away_name"]) if "away_name" in names.columns and mid in names.index else ""
        lg = str(names.loc[mid, "league_code"]) if "league_code" in names.columns and mid in names.index else ""
        out.append({"day": str(pd.Timestamp(day).date()), "match_id": int(mid), "home": home, "away": away,
                    "league": lg, "money": float(money[mid]), "points": pts, "events": evs})
    return out


# ---------------------------------------------------------------- runner
def _day(forecaster, store, d, step):
    dd = store.get(d)
    if dd.empty:
        return None
    pred = forecaster.predict_selection_turnover(dd)
    full = selection_frame(dd, pred, forecastable_only=False)
    pos = np.flatnonzero(full["forecastable"].to_numpy(dtype=bool))
    frame = full.iloc[pos].reset_index(drop=True)
    if frame.empty:
        return None
    usual = _usual_share(dd, frame)
    if usual is not None:
        frame["usual"] = usual
    try:
        inc = incident_table(store.panel.events_for(d))
    except Exception as exc:                                    # noqa: BLE001
        logger.warning("incidents for %s not read (%s): events placed mid-bucket", pd.Timestamp(d).date(), exc)
        inc = incident_table(None)
    evb = event_buckets(dd, inc, step)
    inplay = dd.match.assign(bucket=pd.to_datetime(dd.match["bucket"]).astype("datetime64[ns]")).set_index(
        ["match_id", "bucket"])["inplay"] if "inplay" in dd.match.columns else None
    return dd, frame, evb, inplay, full, pos


def _event_rows(evb: pd.DataFrame, actual: pd.DataFrame, model: pd.DataFrame, inplay, step) -> List[dict]:
    """Section 7: the last full bucket before each event and the first full one after it."""
    out = []
    if evb.empty:
        return out
    for r in evb.itertuples(index=False):
        before, after = (r.match_id, r.bucket - step), (r.match_id, r.bucket + step)
        if before not in actual.index or after not in actual.index:
            continue
        if inplay is not None and not float(np.nan_to_num(inplay.get(before, 0.0))) > 0:
            continue
        b, a, f = actual.loc[before], actual.loc[after], model.loc[after]
        row = {"event": r.event, "favourite": r.strength, "who": r.who, "state": r.state, "clock": r.clock,
               "money_before": float(b["money"]), "money_after": float(a["money"])}
        for c in MEASURES:
            row[c + "_before"], row[c + "_after"], row[c + "_model"] = float(b[c]), float(a[c]), float(f[c])
        out.append(row)
    return out


def _summarise(rows: List[dict], by: Sequence[str], suffixes=("_before", "_after", "_model"),
               money=("money_before", "money_after")) -> List[dict]:
    if not rows:
        return []
    ev = pd.DataFrame(rows)
    order = {lab: i for i, (_, _, lab) in enumerate(CLOCK)}
    table = []
    for keys, g in ev.groupby(list(by), sort=False):
        keys = keys if isinstance(keys, tuple) else (keys,)
        t = {k: v for k, v in zip(by, keys)}
        t["n"] = int(len(g))
        mb, ma = g[money[0]].sum(), g[money[1]].sum()
        t["money_x"] = float(ma / mb) if mb > 0 else None
        for c in MEASURES:
            for sfx in suffixes:
                col = c + sfx
                if col in g.columns:
                    v = pd.to_numeric(g[col], errors="coerce")
                    t[col] = float(v.mean()) if v.notna().any() else None
        table.append(t)
    table.sort(key=lambda t: tuple(order.get(t.get(k), 99) if k == "clock" else str(t.get(k)) for k in by))
    return table


def _spread_days(days: Sequence, n: int) -> list:
    days = list(days)
    if n <= 0 or len(days) <= n:
        return days
    return [days[i] for i in sorted({int(round(x)) for x in np.linspace(0, len(days) - 1, n)})]


def run(forecaster, store, test_days: Sequence, fit_days: Sequence, bucket_minutes: int = 5,
        prior_events: float = 30.0, series_days: int = 12, series_matches: int = 2) -> Tuple[dict, Optional[EventShift]]:
    step = pd.Timedelta(minutes=bucket_minutes)
    # 1. fit the event shift on days the turnover model did not train on
    parts = []
    for d in fit_days:
        got = _day(forecaster, store, d, step)
        if got is None:
            continue
        _, frame, evb, _, _, _ = got
        if not evb.empty:
            parts.append(shift_rows(frame, evb))
    shift = None
    if parts:
        rows = pd.concat(parts, ignore_index=True)
        if len(rows):
            shift = EventShift(prior_events).fit(rows)
            shift.meta.update({"fit_days": [str(pd.Timestamp(d).date()) for d in fit_days],
                               "turnover_model": getattr(forecaster, "version", None),
                               "events_by_kind": rows.drop_duplicates("event_id")["event"].value_counts().to_dict()})
    # 2. score everything on the test days
    mix, zeros, inb, cmp, errs = MixScores(), ZeroSplit(), InBucket(), Compare(), ErrorHist()
    events, effects, events_n, series = [], [], {}, []
    replay_days = {str(pd.Timestamp(x).date()) for x in _spread_days(test_days, series_days)}
    for d in test_days:
        got = _day(forecaster, store, d, step)
        if got is None:
            continue
        dd, frame, evb, inplay, full, pos = got
        tuned, mult = retune(frame, evb, shift)
        frame = frame.assign(retune=tuned, post=frame["model"].to_numpy() * mult)
        # accuracy is scored on every row, as the leaderboard scores it: the re-tune moves forecastable rows only
        full_tuned = full["model"].to_numpy(dtype="float64").copy()
        full_tuned[pos] = tuned
        full = full.assign(retune=full_tuned)
        j = full[["match_id", "bucket"]].merge(evb[["match_id", "bucket", "event"]], on=["match_id", "bucket"],
                                               how="left") if len(evb) else None
        inside_all = j["event"].fillna("none").to_numpy(dtype=object) if j is not None \
            else np.full(len(full), "none", dtype=object)
        inside_all = np.where(full["phase"].to_numpy(dtype=object) == "pre-match", "pre-match", inside_all).astype(object)
        inside = inside_all[pos]
        day_label = str(pd.Timestamp(d).date())
        cuts = {"phase": frame["phase"].to_numpy(dtype=object), "inside the bucket": inside,
                "day": np.full(len(frame), day_label, dtype=object)}
        base = {"last 5 min": frame["last5"].to_numpy(), "model": frame["model"].to_numpy()}
        base_all = {"last 5 min": full["last5"].to_numpy(), "model": full["model"].to_numpy()}
        if shift is not None:
            base["model re-tuned at the event"] = tuned
            base_all["model re-tuned at the event"] = full_tuned
        levels = {lv: dict(base) for lv in MIX_LEVELS}
        if "usual" in frame.columns:
            levels["bet type"]["usual split"] = frame["usual"].to_numpy()
        mix.add(frame, levels, cuts)
        zeros.add(full, {"last 5 min": full["last5"].to_numpy(), "model": full["model"].to_numpy()})
        inb.add(full, inside_all, base_all)
        cmp.add(full, {"all": np.full(len(full), "all", dtype=object), "day": np.full(len(full), day_label, dtype=object),
                       "phase": full["phase"].to_numpy(dtype=object), "clock": full["clock"].to_numpy(dtype=object),
                       "event window": full["window"].to_numpy(dtype=object),
                       "bet type": full["family"].to_numpy(dtype=object),
                       "league": full["league"].to_numpy(dtype=object), "inside the bucket": inside_all}, base_all)
        errs.add(full, base_all)
        if day_label in replay_days:
            series.extend(_match_series(full, dd, evb, series_matches, d))
        if len(evb):
            for k, v in evb["event"].value_counts().items():
                events_n[k] = events_n.get(k, 0) + int(v)
            act, mod = bucket_measures(frame, "y"), bucket_measures(frame, "model")
            events.extend(_event_rows(evb, act, mod, inplay, step))
            if shift is not None:
                sub = frame[frame.set_index(["match_id", "bucket"]).index.isin(
                    pd.MultiIndex.from_frame(evb[["match_id", "bucket"]]))]
                pre, post = bucket_measures(sub, "model"), bucket_measures(sub, "post")
                for r in evb.itertuples(index=False):
                    k = (r.match_id, r.bucket)
                    if k not in pre.index:
                        continue
                    row = {"event": r.event, "favourite": r.strength, "who": r.who, "state": r.state, "clock": r.clock,
                           "money_before": float(pre.loc[k, "money"]), "money_after": float(post.loc[k, "money"])}
                    for c in MEASURES:
                        row[c + "_before"], row[c + "_after"] = float(pre.loc[k, c]), float(post.loc[k, c])
                    effects.append(row)
    out = {"test_days": [str(pd.Timestamp(d).date()) for d in test_days],
           "fit_days": [str(pd.Timestamp(d).date()) for d in fit_days],
           "mix": mix.rows(), "zeros": zeros.rows(), "inbucket": inb.rows(), "events_inside": events_n,
           "compare": cmp.rows(), "errors": errs.rows(), "series": series,
           "events": {"events": len(events),
                      "by_favourite": _summarise(events, ["event", "favourite", "who", "clock"]),
                      "by_state": _summarise(events, ["event", "state", "clock"]),
                      "rows": events},
           "effects": {"by_event": _summarise(effects, ["event", "who", "clock"], ("_before", "_after")),
                       "goal_by_state": _summarise([e for e in effects if e["event"] == "goal"], ["state", "clock"],
                                                   ("_before", "_after")),
                       "goal_by_favourite": _summarise([e for e in effects if e["event"] == "goal"],
                                                       ["favourite", "who", "clock"], ("_before", "_after"))},
           "shift": shift.to_dict() if shift is not None else None}
    return out, shift
