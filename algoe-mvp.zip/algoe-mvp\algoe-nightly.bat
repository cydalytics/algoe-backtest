@echo off
REM Algo E - the nightly refresh, for Windows Task Scheduler (no pause; returns an exit code).
REM On the 75 days ending yesterday: Raw_Data brought up to date (each investment day checked), new
REM panel / feature days, the new days scored for the models that served them (score-days, the
REM Backtest tab's walk-forward days), health check, retrain turnover and probability, promote only
REM what beats last 5 minutes and the current champion. AlgoE_Work\reports\daily\_nightly.json keeps
REM the last run for the desk.
REM
REM start.ps1 registers it as "AlgoE daily" (06:00, this user, no admin rights); by hand:
REM     algoe-schedule-daily.bat
REM Exit code 0 ok, 1 a step failed, 2 finished with alerts.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe nightly %*
exit /b %ERRORLEVEL%
