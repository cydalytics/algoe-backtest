"""
Calendar

Bucket arithmetic and the Hong Kong calendar the day-level features use.

A bucket is named by its START: bucket T covers [T, T + 5 min). A forecast
for bucket T may only use what was known at T. ``elapsed_in_bucket`` is what
the intra-bucket nowcast needs when a focused match is refreshed mid-bucket.

HK general holidays are computed for any year (core/hk_holidays.py: the
Chinese calendar, Easter, Ching Ming and the Sunday rules), so the calendar
never runs out. ``settings.paths.holidays_file`` corrects it without a code
change: a line ``YYYY-MM-DD`` adds a day (a one-off gazetted holiday), a
line ``-YYYY-MM-DD`` removes one.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Holidays computed for every year (the notebook list ended in 2027 and had 2025 / 2026
                days wrong); the holidays file adds and removes days
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Dict, Iterable, Optional, Set

import numpy as np
import pandas as pd

from .hk_holidays import hk_general_holidays
from .logging import get_logger

logger = get_logger(__name__)


class HKCalendar:
    def __init__(self, holidays_file: Optional[str] = None):
        self.added: Set[date] = set()
        self.removed: Set[date] = set()
        if holidays_file and Path(holidays_file).exists():
            for line in Path(holidays_file).read_text(encoding="utf-8").splitlines():
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                target = self.removed if line.startswith("-") else self.added
                try:
                    target.add(pd.Timestamp(line.lstrip("-").strip()).date())
                except ValueError:
                    logger.warning("holiday file line %r is not a date", line)
            logger.info("calendar: %d day(s) added, %d removed by %s", len(self.added), len(self.removed),
                        holidays_file)
        self._years: Dict[int, Set[date]] = {}

    def holidays_of(self, year: int) -> Set[date]:
        if year not in self._years:
            days = set(hk_general_holidays(int(year)))
            self._years[year] = (days | {d for d in self.added if d.year == year}) - self.removed
        return self._years[year]

    def is_holiday(self, stamps: pd.Series) -> np.ndarray:
        t = pd.to_datetime(stamps)
        days: Set[date] = set()
        for y in pd.unique(t.dt.year.dropna()):
            days |= self.holidays_of(int(y))
        return t.dt.date.isin(days).to_numpy()


def floor_bucket(stamp, minutes: int = 5) -> pd.Timestamp:
    return pd.Timestamp(stamp).floor("{}min".format(int(minutes)))


def elapsed_in_bucket(now, minutes: int = 5) -> float:
    """Minutes already gone in the bucket containing ``now`` (0 <= x < minutes)."""
    now = pd.Timestamp(now)
    return float((now - floor_bucket(now, minutes)).total_seconds() / 60.0)


def day_range(start, end) -> list:
    lo, hi = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
    if hi < lo:
        return []
    return list(pd.date_range(lo, hi, freq="D"))


def fourier(values: np.ndarray, period: float, harmonics: int = 1) -> dict:
    """sin/cos pairs of ``values`` on a cycle of length ``period``."""
    out = {}
    v = np.asarray(values, dtype="float64")
    for k in range(1, harmonics + 1):
        out["sin{}".format(k)] = np.sin(2 * np.pi * k * v / period)
        out["cos{}".format(k)] = np.cos(2 * np.pi * k * v / period)
    return out


def iter_months(days: Iterable[pd.Timestamp]):
    """Group days by calendar month, oldest first: {month_start: [days]}."""
    out = {}
    for d in sorted(pd.Timestamp(x).normalize() for x in days):
        out.setdefault(d.to_period("M").start_time, []).append(d)
    return out
