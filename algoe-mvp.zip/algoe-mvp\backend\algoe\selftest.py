"""
Selftest

The whole chain on a generated world whose truth is known, so "it runs" and
"it is right" are both checked before anything is packaged or deployed. No
Raw_Data, no SQL, no network:

    S1   generate      SyntheticWorld -> Raw_Data-shaped parquet. A league and a
                       pool code the models have never seen appear near the end.
    S2   data check    the W06 probe finds every table; no FAIL
    S3   panel         every day builds and passes the panel contract
    S4   features      finite inputs, unique keys, forecastable rows only
    S5   pricer        our score-grid pricer agrees with the legacy poisson_betting
    S6   turnover      the champion beats last 5 minutes on the test days
    S7   probability   the calibrated belief vs 1/true_odds on test log-loss (WARN only:
                       a few synthetic days are a noisy judge of a small gain)
    S8   parity        the serving path at a bucket start builds the same rows and the
                       same inputs as the training path - also the leak test
    S9   live          one sweep and one focus refresh on the replay source; theta* never
                       has lower E[GM] than HKJC's theta and stays inside the trust band; the
                       focus refresh prices on HKJC's newest TG/SUP and odds before it, and
                       leaves the sweep's bucket forecast alone
    S10  monitor       published forecasts are joined to what arrived; health computed
    S11  unknowns      the new league and pool code are forecast (parent level, taxonomy
                       rule) and flagged by the monitor, not dropped or crashed on
    S12  events        the backtest's mix section: proportions scored, the event shift fitted,
                       goal buckets re-tuned; then a replayed goal re-tunes the live engine's
                       rest-of-bucket forecast and keeps the match on focus refreshes
    S13  publish       the publish loop in dry-run mode on the mock engine: the sweep and the in-play
                       cycle publish, every reply is matched to its message, the replication gap is
                       nil on our own pricing (the first half under both split readings), every
                       weight comes back, a mock with wider corners shows in the gap, and nothing
                       goes out with the kill switch on

    python -m algoe selftest            exit code 0 only if nothing FAILed

Change Log:
-----------
2026-10-01      Initialize
2026-10-11      S12 events
2026-10-26      S9: the focus refresh reads the board at the refresh, not at the bucket start
2026-10-29      S13 publish
"""

from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .core.logging import get_logger

logger = get_logger(__name__)

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"
WARMUP_DAYS = 2          # generated before the window: what the first day's market index is read from


class Checks:
    """Ordered PASS / WARN / FAIL lines; an exception inside a check is a FAIL, not a crash."""

    def __init__(self):
        self.rows: List[dict] = []

    def run(self, code: str, title: str, fn: Callable[[], Tuple[str, str]]) -> Optional[str]:
        started = time.time()
        try:
            level, detail = fn()
        except Exception as exc:                                        # noqa: BLE001
            logger.exception("%s %s raised", code, title)
            level, detail = FAIL, "{}: {}".format(type(exc).__name__, exc)
        row = {"code": code, "title": title, "level": level, "detail": detail,
               "seconds": round(time.time() - started, 1)}
        self.rows.append(row)
        log = logger.error if level == FAIL else (logger.warning if level == WARN else logger.info)
        log("[%s] %-4s %-12s %s (%.1fs)", level, code, title, detail, row["seconds"])
        return level

    @property
    def failed(self) -> bool:
        return any(r["level"] == FAIL for r in self.rows)

    def table(self) -> str:
        lines = ["", "{:<5} {:<5} {:<13} {}".format("", "code", "check", "result"), "-" * 96]
        for r in self.rows:
            lines.append("{:<5} {:<5} {:<13} {}".format(r["level"], r["code"], r["title"], r["detail"]))
        n = {k: sum(1 for r in self.rows if r["level"] == k) for k in (PASS, WARN, FAIL)}
        lines += ["-" * 96, "{} PASS, {} WARN, {} FAIL".format(n[PASS], n[WARN], n[FAIL])]
        return "\n".join(lines)


def selftest_settings(root: Path, days: int, start: str = "2026-07-01"):
    """Defaults plus the synthetic paths - never the office settings file or ALGOE_* variables."""
    from .settings import Settings
    end = (pd.Timestamp(start) + pd.Timedelta(days=days - 1)).strftime("%Y-%m-%d")
    s = Settings()
    for item in ('paths.data_dir="{}"'.format((root / "Raw_Data").as_posix()),
                 'paths.work_dir="{}"'.format((root / "work").as_posix()),
                 'window.start="{}"'.format(start), 'window.end="{}"'.format(end),
                 "window.val_days=2", "window.test_days=3", "window.min_train_days=4",
                 "turnover.fit_rows_per_day=20000", "optimizer.budget_seconds=60"):
        s.set(item)
    s.check()
    return s


def run_selftest(root=None, days: int = 10, matches_per_day: int = 5, seed: int = 7,
                 fresh: bool = False) -> Tuple[Checks, dict]:
    from .backtest.backtester import Backtester                       # noqa: F401  (import check)
    from .data.panel import HistoricalPanel
    from .data.replay import ReplaySource
    from .data.synthetic import SyntheticWorld
    from .evaluation.parity import busiest_bucket, train_serve_parity
    from .features.engineer import FeatureEngineer
    from .features.store import FeatureStore
    from .models.probability import ProbabilityCalibrator
    from .models.turnover import TurnoverForecaster
    from .monitoring.monitor import Monitor
    from .realtime.live_engine import LiveEngine

    root = Path(root) if root else Path(__file__).resolve().parents[1] / ".selftest_data"
    # --fresh regenerates the world; logs and run folders stay (this run is writing to them)
    doomed = [root / "Raw_Data", root / "algoe_panel_cache", root / "synthetic_truth.json"] if fresh else []
    # models and features always start clean, so a stale champion cannot pass for a new one
    doomed.append(root / "work")
    for p in doomed:
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
    raw = root / "Raw_Data"
    s = selftest_settings(root, days)
    ctx: Dict = {"settings": s}
    ck = Checks()

    def s1():
        if (root / "synthetic_truth.json").exists() and (raw / "Match_Information").exists():
            return PASS, "reusing {} (pass --fresh to regenerate)".format(raw)
        # two days before the window: the market index of day 1 reads the days up to two days before it
        start = (pd.Timestamp(s.window.start) - pd.Timedelta(days=WARMUP_DAYS)).strftime("%Y-%m-%d")
        SyntheticWorld(days=days + WARMUP_DAYS, matches_per_day=matches_per_day, start=start, seed=seed).write(raw)
        import json
        t = ctx["truth"] = json.loads((root / "synthetic_truth.json").read_text(encoding="utf-8"))
        return PASS, "{} days, {} matches, unseen league {} and pool code {} from day {}".format(
            t.get("days"), t.get("matches"), t.get("new_league"), t.get("new_pool"), t.get("new_league_day"))

    def s2():
        from src.backtest.parquet.probe import probe
        rep = probe(s.legacy_config())
        fails = [c for c in rep["checks"] if c["level"] == "FAIL"]
        if fails:
            return FAIL, "; ".join("{}: {}".format(c["check"], c["detail"]) for c in fails)
        return PASS, "{} tables, {} checks, no FAIL".format(len(rep["tables"]), len(rep["checks"]))

    def s3():
        hp = ctx["panel"] = HistoricalPanel(s)
        ds = ctx["days"] = hp.days()
        hp.ensure(ds)
        rows = {}
        for d in ds:
            frame = hp.load_day(d)
            rows[str(d.date())] = 0 if frame is None else len(frame)
        empty = [d for d, n in rows.items() if n == 0]
        if empty:
            return FAIL, "no panel rows for {}".format(empty)
        return PASS, "{} days, {:,} rows".format(len(ds), sum(rows.values()))

    def s4():
        fe = ctx["engineer"] = FeatureEngineer(s)
        store = ctx["store"] = FeatureStore(s, ctx["panel"], fe)
        dd = store.get(ctx["days"][len(ctx["days"]) // 2])
        problems = []
        for name, fs in (("match_total", fe.features_for_turnover_match_total(dd)),
                         ("pool_share", fe.features_for_turnover_pool_share(dd)),
                         ("selection", fe.features_for_turnover_selection(dd)),
                         ("probability", fe.features_for_probability(dd))):
            X = fs.X.to_numpy(dtype="float64")
            if not np.isfinite(X).all():
                problems.append("{}: non-finite inputs".format(name))
            if not len(fs):
                problems.append("{}: no rows".format(name))
        if dd.sel.duplicated(["pool_id", "line_id", "combination_id", "bucket"]).any():
            problems.append("duplicate selection keys")
        return (FAIL, "; ".join(problems)) if problems else (
            PASS, "{:,} selection rows, {} selection features, all finite".format(
                int(dd.sel["forecastable"].sum()), len(fe.features_for_turnover_selection(dd).feature_names)))

    def s5():
        from src.backtest.parquet import poisson_betting as pb
        from .pricing.pricer import marginals, score_grid, two_way
        worst = 0.0
        for tg in (1.4, 2.6, 3.4):
            for sup in (-0.9, 0.0, 0.7):
                m = marginals(score_grid(tg, sup, 10))
                for line in (1.5, 2.25, 2.5, 2.75, 3.0):
                    ours = float(two_way(m.total_values, m.total_probs, line)[0][0])
                    worst = max(worst, abs(ours - 1.0 / pb.calculate_over_under_odds(tg, sup, line)["Over"]))
                for h in (-1.25, -0.5, 0.0, 0.25, 0.75):
                    ours = float(two_way(m.diff_values, m.diff_probs, -h)[0][0])
                    worst = max(worst, abs(ours - 1.0 / pb.calculate_asian_handicap_odds(tg, sup, h)["Home"]))
        return (PASS if worst < 1e-9 else FAIL), "worst |p ours - p legacy| = {:.2e} over 90 lines".format(worst)

    def s6():
        tf = ctx["forecaster"] = TurnoverForecaster(s, ctx["engineer"], ctx["store"])
        meta = tf.train_all(ctx["days"])
        tf.save()
        lb = {r["pipeline"]: r for r in meta["leaderboard"]}
        champ, base = lb[tf.champion], lb["last5"]
        detail = "champion {}: test deviance {:.4g} vs last5 {:.4g}, match WAPE {:.1%} vs {:.1%}".format(
            tf.champion, champ["test_deviance"], base["test_deviance"], champ["test_match_wape"],
            base["test_match_wape"])
        if tf.champion == "last5" or champ["test_deviance"] >= base["test_deviance"]:
            return FAIL, detail + " - the models should beat persistence on a world with signal"
        return PASS, detail

    def s7():
        pc = ctx["calibrator"] = ProbabilityCalibrator(s, ctx["engineer"], ctx["store"])
        pc.train_all(ctx["days"])
        pc.save()
        rows = {r["method"]: r for r in pc.leaderboard}
        champ, base = rows[pc.champion], rows["raw:hkjc_true"]
        detail = "champion {}: test log-loss {:.5f} vs raw {:.5f}".format(
            pc.champion, champ["test_log_loss"], base["test_log_loss"])
        return (PASS if champ["test_log_loss"] <= base["test_log_loss"] else WARN), detail

    def s8():
        store, fe = ctx["store"], ctx["engineer"]
        last = store.get(ctx["days"][-1])
        moments = [busiest_bucket(last)]
        # the first bucket after midnight that has rows: lags there come from the previous day
        early = last.sel.loc[last.sel["forecastable"] & (last.sel["bucket"] < last.day + pd.Timedelta(hours=3)),
                             "bucket"]
        if len(early):
            moments.append(pd.Timestamp(early.min()))
        # where a pool closes - exactly on a bucket boundary, and inside a bucket - a closed pool must
        # leave the board in both paths, while the money it took stays in the history
        panel = ctx["panel"].load_day(ctx["days"][-1])
        if panel is not None and "close_time" in panel.columns:
            ct = pd.to_datetime(panel["close_time"], errors="coerce")
            b = pd.to_datetime(panel["bucket"])
            step = "{}min".format(s.panel.bucket_minutes)
            on_board = set(pd.to_datetime(last.sel.loc[last.sel["forecastable"], "bucket"]).unique())
            for cand in (b[ct.notna() & (ct == b)], b[ct.notna() & (ct.dt.floor(step) == b) & (ct != b)]):
                cand = cand[cand.isin(on_board)]          # a moment with something left to compare
                if len(cand):
                    moments.append(pd.Timestamp(cand.max()))
        moments = sorted({pd.Timestamp(m) for m in moments if m is not None})
        bad = []
        source = ReplaySource(s)
        for at in moments:
            rep = train_serve_parity(s, store, fe, at, source=source)
            for level, r in rep["levels"].items():
                if not r["ok"]:
                    bad.append("{} {}: {} only-train, {} only-serve, differ {}".format(
                        at, level, r["only_train"], r["only_serve"], [d["feature"] for d in r["diffs"]][:5]))
            if rep.get("note"):
                bad.append("{}: {}".format(at, rep["note"]))
        ctx["at"] = busiest_bucket(last)
        return (FAIL, "; ".join(bad)) if bad else (PASS, "identical rows and inputs at {} (5 levels)".format(
            ", ".join(m.strftime("%H:%M") for m in moments)))

    def s9():
        s.live.source = "replay"
        mon = ctx["monitor"] = Monitor(s)
        eng = ctx["engine"] = LiveEngine(s, ReplaySource(s), ctx["forecaster"], ctx["calibrator"], mon)
        at = ctx["at"]
        sw = eng.run_sweep(at)
        worse, outside = [], []
        for mid, live in eng.matches.items():
            d = live.decision
            if d is None or not d.status.startswith("solved"):
                continue
            if d.lift < -1e-6:
                worse.append(mid)
            for k, band in s.optimizer.theta_band.items():
                if k in d.theta_star and k in d.theta_now and abs(d.theta_star[k] - d.theta_now[k]) > band + 1e-6:
                    outside.append((mid, k))
        if not eng.matches:
            return FAIL, "the sweep at {} produced no match".format(at)
        top = max(eng.matches.values(), key=lambda m: m.decision.turnover if m.decision else 0.0)
        f_sweep = top.forecast[["pool_id", "line_id", "combination_id", "forecast"]].copy()
        focus_at = at + pd.Timedelta(seconds=150)
        live = eng.run_focus(top.match_id, focus_at)
        problems = []
        if worse:
            problems.append("theta* worse than HKJC for {}".format(worse))
        if outside:
            problems.append("outside the trust band: {}".format(outside[:5]))
        if live is None or not np.isfinite(live.remaining) or live.remaining < 0:
            problems.append("focus refresh gave no usable nowcast")
        board = _board_check(s, live, at, focus_at, f_sweep) if live is not None else {"problems": ["no focus"]}
        problems += board["problems"]
        detail = "sweep {} matches ({} solved) in {}s, lift {:.0f}; focus {}: observed {:.0f}, remaining {:.0f}; {}".format(
            sw.get("matches"), sw.get("solved"), sw.get("seconds", {}).get("total"), sw.get("lift", 0.0),
            top.match_id, live.observed if live else float("nan"), live.remaining if live else float("nan"),
            board.get("detail", ""))
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    def s10():
        mon, day = ctx["monitor"], pd.Timestamp(ctx["at"]).normalize()
        joined = mon.join_realised(day, ctx["store"])
        if joined is None or joined.empty:
            return FAIL, "no logged forecast could be joined to what arrived"
        health = mon.health_from_frames({day: joined})
        d = health["daily"][0] if health["daily"] else {}
        return PASS, "{:,} published rows scored; WAPE {} vs last5 {}".format(
            len(joined), _pct(d.get("wape_model")), _pct(d.get("wape_last5")))

    def s11():
        fe, store, tf = ctx["engineer"], ctx["store"], ctx["forecaster"]
        inferred = fe.taxonomy.inferred_codes()
        last = store.get(ctx["days"][-1])
        known = set(fe.encoders.league.tables.get("league_code", {})) if fe.encoders.league else set()
        new_leagues = sorted(set(last.match["league_code"].astype(str)) - known)
        fc = tf.predict_selection_turnover(last)
        new_rows = fc["match_id"].isin(last.match.loc[last.match["league_code"].astype(str).isin(new_leagues),
                                                      "match_id"])
        finite = bool(np.isfinite(fc.loc[new_rows, "forecast"]).all()) and bool((fc.loc[new_rows, "forecast"] >= 0).all())
        nov = ctx["monitor"].novelty(last, fe.encoders, fe.taxonomy)
        problems = []
        if not new_leagues:
            problems.append("the test days carry no unseen league (world too short?)")
        if not finite or not new_rows.any():
            problems.append("no finite forecast for the unseen league's rows")
        if not inferred:
            problems.append("no pool code needed the taxonomy rules")
        if not nov["alerts"]:
            problems.append("the monitor raised no novelty alert")
        detail = "unseen league(s) {} forecast on {:,} rows; pool code(s) {} placed by rule; {} alert(s)".format(
            new_leagues, int(new_rows.sum()), sorted(inferred), len(nov["alerts"]))
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    def s12():
        from .backtest.backtester import Backtester
        bt = Backtester(s, ctx["store"], ctx["forecaster"], ctx["calibrator"])
        out = bt.compare_mix()
        problems = []
        inside = out.get("events_inside") or {}
        ib = {(r["inside"], r["method"]): r for r in out.get("inbucket") or []}
        g, gt = ib.get(("goal", "model")) or {}, ib.get(("goal", "model re-tuned at the event")) or {}
        if not inside.get("goal"):
            problems.append("no goal inside a bucket on the test days")
        if out.get("shift") is None:
            problems.append("no event shift fitted")
        if not np.isfinite(gt.get("match_wape", np.nan)):
            problems.append("goal buckets were not re-tuned")
        if not any(r["level"] == "bet type" and r["dim"] == "all" for r in out.get("mix") or []):
            problems.append("no bet-type proportion scores")
        lb = {r["pipeline"]: r for r in ctx["forecaster"].leaderboard}
        cmp = {r["method"]: r for r in out.get("compare") or [] if r["dim"] == "all"}
        champ = lb.get(ctx["forecaster"].champion, {})
        if not cmp or abs((cmp.get("model") or {}).get("deviance", np.nan) - champ.get("test_deviance", np.nan)) > \
                1e-6 * max(1.0, abs(champ.get("test_deviance") or 1.0)):
            problems.append("baseline-vs-model rows do not reproduce the leaderboard's deviance")
        if not out.get("series"):
            problems.append("no match replay")
        # a goal on the last test day, replayed through a fresh engine that reads the fitted shift
        eng = LiveEngine(s, ReplaySource(s), ctx["forecaster"], ctx["calibrator"])
        day = pd.Timestamp(ctx["forecaster"].metadata["split"]["test"][-1])
        ev = ctx["panel"].events_for(day)
        t_ev = pd.to_datetime(ev["incident_datetime"])
        goals = ev[(pd.to_numeric(ev["incident_type"], errors="coerce") == 27) & (t_ev.dt.normalize() == day)
                   & ((t_ev - t_ev.dt.floor("{}min".format(s.panel.bucket_minutes))) < pd.Timedelta(minutes=3))]
        live_note = None
        for _, row in goals.sort_values("incident_datetime").head(10).iterrows():
            t, mid = pd.Timestamp(row["incident_datetime"]), int(row["match_id"])
            eng.run_sweep(t.floor("{}min".format(s.panel.bucket_minutes)) + pd.Timedelta(seconds=5))
            if mid not in eng.matches or eng.matches[mid].forecast is None:
                continue
            eng.check_triggers(t + pd.Timedelta(seconds=20))
            eng.step(t + pd.Timedelta(seconds=20))
            m = eng.matches[mid]
            if mid not in eng.focused():
                problems.append("the goal's trigger did not keep match {} on focus refreshes".format(mid))
            if m.event is None:
                problems.append("the refresh after the goal at {} was not re-tuned".format(t.strftime("%H:%M:%S")))
            elif not np.isfinite(m.remaining) or m.remaining < 0:
                problems.append("the re-tuned nowcast is not usable")
            else:
                live_note = "live re-tuned match {} for a {} goal at {} ({})".format(
                    mid, m.event["labels"]["who"], m.event["labels"]["clock"], m.event["labels"]["state"])
            break
        if live_note is None and not problems:
            problems.append("no goal on the last test day could be replayed")
        detail = "{} event bucket(s) {}; goal buckets match WAPE {} -> {} re-tuned; {}".format(
            sum(inside.values()), inside, _pct(g.get("match_wape")), _pct(gt.get("match_wape")), live_note)
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    def s13():
        import copy
        from .realtime.mock_engine import MockEngine
        sp = copy.deepcopy(s)
        sp.live.source, sp.publish.mode = "replay", "dry_run"
        sp.paths.work_dir = str(Path(s.paths.work) / "s13")
        eng = LiveEngine(sp, ReplaySource(sp), ctx["forecaster"], ctx["calibrator"])
        pub, at = eng.publisher, pd.Timestamp(ctx["at"])
        problems = []
        if pub is None or pub.mode != "dry_run":
            return FAIL, "no dry-run publisher: {}".format(eng.publish_refused)

        def read(after):
            got = pub.poll()
            for reply, info in got:
                eng.on_engine_prices(reply, info)
            return got
        pub.clock = lambda: at + pd.Timedelta(seconds=30)
        eng.run_sweep(at)
        replies = read(at)
        cyc = {}
        if any(m.header.get("in_play") for m in eng.matches.values()):
            pub.clock = lambda: at + pd.Timedelta(seconds=50)
            cyc = eng.run_fast_cycle(at + pd.Timedelta(seconds=45))
            replies += read(at)
        sent = pub.counts["sent"]
        if not sent:
            problems.append("nothing was published")
        if len(replies) != sent or not all(info["ours"] for _, info in replies):
            problems.append("{} message(s) sent, {} reply(ies) matched to them".format(
                sent, sum(1 for _, i in replies if i["ours"])))
        engines = [m.engine for m in eng.matches.values() if m.engine and m.engine.get("gap")]
        worst = max((e["gap"]["max"] for e in engines), default=np.nan)
        if not engines or not worst < 1e-3:
            problems.append("replication gap {} on our own pricing (want < 0.001)".format(worst))
        echo = [b for e in engines for b in e["echo"]]
        if echo:
            problems.append("weights did not come back: {}".format(echo[:3]))
        if pub.counts["reverts"]:
            problems.append("{} revert(s) on our own pricing".format(pub.counts["reverts"]))
        fh = next((e["gap"]["first_half"] for e in engines if e["gap"].get("first_half")), {})
        if not fh:
            # the two readings of the split only differ before kick-off: a sweep before the day's first one
            kos = [pd.Timestamp(m.header["kickoff"]) for m in eng.matches.values() if m.header.get("kickoff")]
            pre_at = (min(kos) - pd.Timedelta(minutes=20)).floor("{}min".format(s.panel.bucket_minutes)) if kos else None
            if pre_at is not None and pre_at.normalize() == at.normalize():
                sq = copy.deepcopy(sp)
                sq.paths.work_dir = str(Path(s.paths.work) / "s13_prematch")
                pre = LiveEngine(sq, ReplaySource(sq), ctx["forecaster"], ctx["calibrator"])
                pre.publisher.clock = lambda: pre_at + pd.Timedelta(seconds=30)
                pre.run_sweep(pre_at)
                for reply, info in pre.publisher.poll():
                    pre.on_engine_prices(reply, info)
                fh = next((m.engine["gap"]["first_half"] for m in pre.matches.values()
                           if m.engine and (m.engine.get("gap") or {}).get("first_half")), {})
                pre.stop()
        if not fh:
            problems.append("no pre-match first-half pool to read both split readings on")
        elif not fh["as_first_half"] < fh["as_second_half"]:
            problems.append("first half: the reading the mock uses did not fit best {}".format(fh))
        # an engine whose corners are wider than Poisson (the reply sample: negative binomial 1.52)
        wide = MockEngine(sp, pub.mapping, eng._mock_lookup, corner_dispersion=1.52)
        pub.transport.responder = wide.reply
        corner = next((m for m, live in eng.matches.items() if live.book is not None and live.decision is not None
                       and np.isin(live.book.rows.theta_domain, ["corner"]).any()
                       and (pub.matches.get(m) and pub.matches[m].started)), None)
        corner_note = "no corner book"
        if corner is not None:
            pub.clock = lambda: at + pd.Timedelta(seconds=80)
            eng._publish(corner, "selftest")
            read(at)
            g = (eng.matches[corner].engine or {}).get("gap") or {}
            corner_note = "wider corners: gap {} on {}".format(_num(g.get("max")), g.get("worst_pool"))
            if not g or not str(g.get("worst_pool", "")).startswith(("CHL", "CHD", "FCH")) or not g.get("max", 0) > 1e-3:
                problems.append("a mock with wider corners did not show in the replication gap ({})".format(g))
        pub.stop("selftest", "S13")
        before = pub.counts["sent"]
        pub.clock = lambda: at + pd.Timedelta(seconds=120)
        stopped = [eng._publish(m, "selftest") for m in list(eng.matches)[:3]]
        if pub.counts["sent"] != before or any(r and r.get("action") == "sent" for r in stopped):
            problems.append("a message went out with the kill switch on")
        pub.resume("selftest")
        eng.stop()
        detail = "{} sent, {} replies matched; gap max {} on our pricing; first half {}; {}; fast lane {} " \
                 "match(es) {}s; kill switch held".format(
                     sent, sum(1 for _, i in replies if i["ours"]), _num(worst),
                     {k: _num(v) for k, v in fh.items()} or "n/a", corner_note, cyc.get("matches", 0),
                     (cyc.get("seconds") or {}).get("total", "-"))
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    for code, title, fn in (("S1", "generate", s1), ("S2", "data check", s2), ("S3", "panel", s3),
                            ("S4", "features", s4), ("S5", "pricer", s5), ("S6", "turnover", s6),
                            ("S7", "probability", s7), ("S8", "parity", s8), ("S9", "live", s9),
                            ("S10", "monitor", s10), ("S11", "unknowns", s11), ("S12", "events", s12),
                            ("S13", "publish", s13)):
        needs = {"S3": ["S2"], "S4": ["S3"], "S6": ["S4"], "S7": ["S4"], "S8": ["S6"], "S9": ["S6", "S7", "S8"],
                 "S10": ["S9"], "S11": ["S6", "S9"], "S12": ["S6", "S7", "S9"], "S13": ["S6", "S7", "S9"]}.get(code, [])
        failed_before = {r["code"] for r in ck.rows if r["level"] == FAIL}
        if any(n in failed_before for n in needs):
            ck.rows.append({"code": code, "title": title, "level": FAIL, "seconds": 0.0,
                            "detail": "skipped: depends on {}".format([n for n in needs if n in failed_before])})
            continue
        ck.run(code, title, fn)
    return ck, ctx


def _board_check(s, live, bucket_start, focus_at, f_sweep) -> dict:
    """A focus refresh prices on the board at the refresh: HKJC's newest TG/SUP and odds at or before it (not
    the bucket start's), the sweep's bucket forecast unchanged, a decision inside the guards."""
    from .data.replay import ReplaySource
    key = ["pool_id", "line_id", "combination_id"]
    mid, problems = live.match_id, []
    snap = ReplaySource(s).fetch(focus_at, match_ids=[mid])
    p = snap.params[pd.to_numeric(snap.params["match_id"], errors="coerce") == mid].copy()
    p["event_time"] = pd.to_datetime(p["event_time"])
    newest = p[p["event_time"] <= focus_at].sort_values("event_time")
    at_start = p[p["event_time"] < bucket_start].sort_values("event_time")
    bk, moved, checked = live.book, False, 0
    if bk is None:
        return {"problems": ["the focus refresh built no book"], "detail": ""}
    if not newest.empty:
        want, got = float(newest["tg"].iloc[-1]), float(bk.theta_now.get("goal_tg", np.nan))
        if not np.isclose(got, want):
            problems.append("focus TG {:.4f} is not HKJC's newest before the refresh ({:.4f})".format(got, want))
        moved = not at_start.empty and not np.isclose(float(at_start["tg"].iloc[-1]), want)
    o = snap.odds[pd.to_numeric(snap.odds["match_id"], errors="coerce") == mid]
    o = o[pd.to_datetime(o["effective_datetime"]) <= focus_at].sort_values("effective_datetime")
    last = {tuple(int(v) for v in k): float(x) for k, x in o.groupby(key)["odds"].last().items()}
    wrong = 0
    for i, k in enumerate(bk.keys[key].astype("int64").itertuples(index=False, name=None)):
        if k in last:
            checked += 1
            wrong += int(not np.isclose(float(bk.odds_now[i]), last[k]))
    if wrong:
        problems.append("{} of {} book price(s) are not HKJC's newest before the refresh".format(wrong, checked))
    f = f_sweep.merge(live.forecast[key + ["forecast"]], on=key, suffixes=("_sweep", "_focus"))
    if not len(f) or not np.allclose(f["forecast_sweep"], f["forecast_focus"]):
        problems.append("the focus refresh changed the sweep's bucket forecast")
    d = live.decision
    if d is not None and d.status.startswith("solved"):
        if d.lift < -1e-6:
            problems.append("focus theta* below the board's E[GM]")
        for k, band in s.optimizer.theta_band.items():
            if k in d.theta_star and k in d.theta_now and abs(d.theta_star[k] - d.theta_now[k]) > band + 1e-6:
                problems.append("focus theta* outside the trust band on {}".format(k))
    detail = "focus priced at {:%H:%M:%S}: TG/SUP of {} ({}), {} book price(s) at their newest".format(
        focus_at, newest["event_time"].iloc[-1].strftime("%H:%M:%S") if not newest.empty else "-",
        "moved inside the bucket" if moved else "same as at the bucket start", checked)
    return {"problems": problems, "detail": detail}


def _pct(v) -> str:
    return "{:.1%}".format(v) if v is not None and np.isfinite(v) else "n/a"


def _num(v) -> str:
    return "{:.4f}".format(v) if v is not None and np.isfinite(v) else "n/a"
