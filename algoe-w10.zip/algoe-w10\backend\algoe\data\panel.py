"""
Panels

One row per (5-minute bucket, pool_id, line_id, combination_id), carrying
what was known at the START of the bucket and the money that then arrived
inside it. Everything downstream - features, models, backtest, live - reads
this one shape.

    HistoricalPanel    days from Raw_Data, through the W06 per-day cache
    LivePanelBuilder   the current bucket from a live Snapshot, built by the
                       SAME code, so a feature computed at serve time is the
                       feature the model was trained on

Two additions the cached W06 panel does not carry:

    score_asof()       goals / corners / reds for each match at each bucket
                       start, from Match_Events. In play the Current TG is
                       goals still to come, so pricing a full-match line
                       needs the score on the board.
    market_consensus() median bookmaker price per selection and bucket,
                       with the swapped bookmaker / bet-type columns of the
                       historical extraction already repaired by the loader.

``forecastable`` marks rows a forecaster at T could actually have scored:
inside the pre-match window (or in play) AND priced before T. The W06 panel
also keeps any row that took money, even outside that window; its very
presence is the label, so it must never be used as a feature row.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      LivePanelBuilder built as training reads a cached day: closed pools end at their last
                activity, selling start floored to its bucket, start odds across midnight from the
                previous day, the panel contract, and the previous day's last hour as the lag tail;
                a row is forecastable only while its pool is open at the bucket start; live close
                times from the source, params_history preferred over the newest-row params
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger, log_frame
from ..core.validation import ColumnRule, Contract, validate

logger = get_logger(__name__)

KEY = ["pool_id", "line_id", "combination_id"]
GOAL, GOAL_CANCEL = 27, 6
CORNER, CORNER_CANCEL = 13, 5
RED, RED_CANCEL, YELLOW_RED, YELLOW_RED_CANCEL = 57, 8, 79, 10

PANEL_CONTRACT = Contract("panel", key=KEY + ["bucket"], unique_key=True, rules=[
    ColumnRule("bucket", "datetime", nullable=False),
    ColumnRule("match_id", "int", nullable=False),
    ColumnRule("pool_id", "int", nullable=False),
    ColumnRule("line_id", "int", nullable=False),
    ColumnRule("combination_id", "int", nullable=False),
    ColumnRule("pool_name", "str", nullable=False, fill="UNKNOWN"),
    ColumnRule("odds", "float", lo=1.0, hi=2000.0, sentinels=(9999.0,), on_bad="null"),
    ColumnRule("true_odds", "float", required=False, lo=1.0, hi=2000.0, sentinels=(9999.0,)),
    ColumnRule("turnover", "float", nullable=False, fill=0.0, lo=0.0, hi=5e8, on_bad="clip"),
    ColumnRule("tg", "float", required=False, lo=0.0, hi=15.0, on_bad="null", max_null_ratio=0.5),
    ColumnRule("sup", "float", required=False, lo=-10.0, hi=10.0, on_bad="null"),
    ColumnRule("ctg", "float", required=False, lo=0.0, hi=40.0, on_bad="null"),
    ColumnRule("csup", "float", required=False, lo=-20.0, hi=20.0, on_bad="null"),
    ColumnRule("match_minute", "float", required=False, lo=0.0, hi=150.0, on_bad="clip"),
    ColumnRule("league_code", "str", required=False, fill="unknown", max_null_ratio=0.3),
])


# ------------------------------------------------------------ event state
def score_asof(events: pd.DataFrame, match_buckets: pd.DataFrame) -> pd.DataFrame:
    """Running score, corners and reds for each (match_id, bucket) at bucket start.

    Incidents stamped exactly at T are not known at T. Cancellations (6, 5,
    8, 10) reverse the incident they cancel. The feed carries several
    providers; each is counted separately and the largest count wins, the
    same rule the feature notebook uses, so one provider that missed a goal
    cannot hide it.
    """
    mb = match_buckets[["match_id", "bucket"]].drop_duplicates().reset_index(drop=True)
    cols = ["home_goals", "away_goals", "home_corners", "away_corners", "home_reds", "away_reds"]
    for c in cols:
        mb[c] = 0
    mb["last_goal_at"] = pd.NaT
    if events is None or events.empty or "incident_type" not in events.columns:
        return mb
    ev = events.dropna(subset=["match_id", "incident_datetime", "incident_type"]).copy()
    ev["match_id"] = pd.to_numeric(ev["match_id"], errors="coerce").astype("int64")
    ev["incident_type"] = pd.to_numeric(ev["incident_type"], errors="coerce")
    side = pd.to_numeric(ev.get("home_or_away"), errors="coerce")
    ev["side"] = side
    ev = ev[ev["side"].isin([1, 2])]
    if "provider_id" not in ev.columns:
        ev["provider_id"] = 1
    ev["provider_id"] = pd.to_numeric(ev["provider_id"], errors="coerce").fillna(-1).astype("int64")
    ev["t"] = pd.to_datetime(ev["incident_datetime"]).astype("datetime64[ns]")
    kinds = {"goals": (GOAL, GOAL_CANCEL), "corners": (CORNER, CORNER_CANCEL),
             "reds": ((RED, YELLOW_RED), (RED_CANCEL, YELLOW_RED_CANCEL))}
    mb_sorted = mb.sort_values(["match_id", "bucket"]).reset_index()
    by_match = {m: g for m, g in ev.groupby("match_id")}
    out = {c: np.zeros(len(mb_sorted), dtype="int64") for c in cols}
    last_goal = np.full(len(mb_sorted), np.datetime64("NaT"), dtype="datetime64[ns]")
    for m, rows in mb_sorted.groupby("match_id").groups.items():
        g = by_match.get(m)
        if g is None:
            continue
        pos = np.asarray(list(rows))
        t_b = mb_sorted.loc[pos, "bucket"].to_numpy(dtype="datetime64[ns]")
        for kind, (plus, minus) in kinds.items():
            plus = plus if isinstance(plus, tuple) else (plus,)
            minus = minus if isinstance(minus, tuple) else (minus,)
            best_h = np.zeros(len(pos), dtype="int64")
            best_a = np.zeros(len(pos), dtype="int64")
            for _, gp in g.groupby("provider_id"):
                sub = gp[gp["incident_type"].isin(plus + minus)].sort_values("t")
                if sub.empty:
                    continue
                delta = np.where(sub["incident_type"].isin(plus), 1, -1)
                t = sub["t"].to_numpy(dtype="datetime64[ns]")
                for s, best in ((1, best_h), (2, best_a)):
                    d = np.where(sub["side"].to_numpy() == s, delta, 0)
                    csum = np.cumsum(d)
                    idx = np.searchsorted(t, t_b, side="left") - 1      # strictly before T
                    val = np.where(idx >= 0, csum[np.clip(idx, 0, None)], 0)
                    np.maximum(best, np.maximum(val, 0), out=best)
                if kind == "goals":
                    gt = sub.loc[sub["incident_type"].isin(plus), "t"].to_numpy(dtype="datetime64[ns]")
                    if len(gt):
                        j = np.searchsorted(gt, t_b, side="left") - 1
                        cand = np.where(j >= 0, gt[np.clip(j, 0, None)], np.datetime64("NaT"))
                        cur = last_goal[pos]
                        take = ~np.isnat(cand) & (np.isnat(cur) | (cand > cur))
                        cur[take] = cand[take]
                        last_goal[pos] = cur
            out["home_" + kind][pos] = best_h
            out["away_" + kind][pos] = best_a
    for c in cols:
        mb_sorted[c] = out[c]
    mb_sorted["last_goal_at"] = last_goal
    return mb_sorted.set_index("index").sort_index()[["match_id", "bucket"] + cols + ["last_goal_at"]]


def market_consensus(market: pd.DataFrame, bucket_minutes: int = 5) -> pd.DataFrame:
    """Median across bookmakers of each bookmaker's last price per selection-bucket."""
    need = ["pool_id", "line_id", "combination_id", "odds", "effective_datetime"]
    if market is None or market.empty or any(c not in market.columns for c in need):
        return pd.DataFrame(columns=KEY + ["_at", "mkt_odds", "mkt_books"])
    m = market.dropna(subset=["odds", "effective_datetime"] + KEY).copy()
    for c in KEY:
        m[c] = pd.to_numeric(m[c], errors="coerce").astype("int64")
    m = m[(m["odds"] > 1.0) & (m["odds"] < 1000.0)]
    m["_at"] = pd.to_datetime(m["effective_datetime"]).dt.floor("{}min".format(bucket_minutes))
    book = "bookmaker" if "bookmaker" in m.columns else None
    by = KEY + ["_at"] + ([book] if book else [])
    last = m.sort_values("effective_datetime").groupby(by, observed=True)["odds"].last().reset_index()
    out = last.groupby(KEY + ["_at"], observed=True)["odds"].agg(["median", "size"]).reset_index()
    out = out.rename(columns={"median": "mkt_odds", "size": "mkt_books"})
    out["_at"] = pd.to_datetime(out["_at"]).astype("datetime64[ns]")
    return out


def asof_before(frame: pd.DataFrame, right: pd.DataFrame, value: str, by: List[str],
                lag_minutes: float = 0.0) -> np.ndarray:
    """``value`` from the last ``right`` row at or before (bucket - lag), strictly before bucket.

    ``right`` must carry the join keys, ``_at`` (its bucket) and ``value``.
    A right row with ``_at == bucket`` is the price posted inside the bucket
    and is excluded.
    """
    out = np.full(len(frame), np.nan)
    if right is None or right.empty or frame.empty:
        return out
    left = frame[by + ["bucket"]].copy()
    for c in by:
        left[c] = pd.to_numeric(left[c], errors="coerce").fillna(-1).astype("int64")
    left["_row"] = np.arange(len(frame))
    left["_at"] = (pd.to_datetime(left["bucket"]) - pd.Timedelta(minutes=lag_minutes)).astype("datetime64[ns]")
    left = left.sort_values("_at")
    r = right[by + ["_at", value]].copy()
    for c in by:
        r[c] = pd.to_numeric(r[c], errors="coerce").fillna(-1).astype("int64")
    r = r.sort_values("_at")
    m = pd.merge_asof(left, r, on="_at", by=by, direction="backward", allow_exact_matches=False)
    out[m["_row"].to_numpy()] = pd.to_numeric(m[value], errors="coerce").to_numpy(dtype="float64")
    return out


def mark_forecastable(panel: pd.DataFrame, prematch_window_min: int) -> pd.DataFrame:
    inplay = panel["is_inplay"].fillna(False).astype(bool) if "is_inplay" in panel.columns \
        else pd.Series(False, index=panel.index)
    mins = pd.to_numeric(panel.get("mins_to_ko"), errors="coerce")
    in_window = inplay | (mins.notna() & (mins <= prematch_window_min))
    priced = panel["priced_before"].fillna(False).astype(bool) if "priced_before" in panel.columns \
        else pd.Series(True, index=panel.index)
    odds = pd.to_numeric(panel.get("odds"), errors="coerce")
    # The W06 span keeps a pool's rows through floor(close_time), so a pool closing exactly on a
    # bucket boundary still has a row for the bucket it is closed for. Open at the bucket start
    # means close_time > T.
    if "close_time" in panel.columns:
        close = pd.to_datetime(panel["close_time"], errors="coerce")
        open_at_start = (close.isna() | (close > pd.to_datetime(panel["bucket"]))).to_numpy()
    else:
        open_at_start = np.ones(len(panel), dtype=bool)
    panel["in_window"] = in_window.to_numpy()
    panel["forecastable"] = (in_window & priced & odds.notna() & (odds > 1.0)).to_numpy() & open_at_start
    return panel


# ---------------------------------------------------------- historical
class HistoricalPanel:
    """Per-day panel over Raw_Data, cached in the W06 panel cache."""

    def __init__(self, settings):
        from src.backtest.parquet.cache import PanelCache, resolve_cache_root
        self.settings = settings
        self.cfg = settings.legacy_config()
        root = resolve_cache_root(self.cfg, [settings.paths.panel_cache])
        self.cache = PanelCache(self.cfg, root)
        self._month_events: Dict[pd.Timestamp, pd.DataFrame] = {}
        self._month_market: Dict[pd.Timestamp, pd.DataFrame] = {}
        logger.info("panel cache %s (space %s)", self.cache.root, self.cache.space)

    def days(self, start=None, end=None) -> List[pd.Timestamp]:
        from ..core.calendar import day_range
        return day_range(start or self.settings.window.start, end or self.settings.window.end)

    def ensure(self, days: Sequence) -> dict:
        """Build every missing day, a calendar month of raw parquet at a time."""
        missing = [d for d in days if not self.cache.has_day(d)]
        if not missing:
            logger.info("panel: all %d day(s) already cached", len(days))
            return {"built": 0}

        def progress(info):
            if info.get("stage") == "day":
                logger.info("panel built %s rows=%s turnover=%s (%s/%s)", info.get("day"),
                            f"{int(info.get('rows') or 0):,}", f"{float(info.get('turnover') or 0):,.0f}",
                            info.get("done"), info.get("total"))
            elif info.get("message"):
                logger.info("panel %s: %s", info.get("stage"), info.get("message"))
        logger.info("panel: building %d missing day(s) from %s", len(missing), self.cfg.data_dir)
        return self.cache.build(missing, progress=progress)

    def load_day(self, day, validate_rows: bool = True) -> Optional[pd.DataFrame]:
        frame = self.cache.load_day(day)
        if frame is None or frame.empty:
            return None
        frame = frame.copy()
        frame["bucket"] = pd.to_datetime(frame["bucket"]).astype("datetime64[ns]")
        if validate_rows:
            frame, rep = validate(frame, PANEL_CONTRACT)
            if rep.errors or rep.warnings or rep.duplicate_keys:
                rep.log()
        frame = mark_forecastable(frame, self.settings.panel.prematch_window_min)
        return frame

    def previous_tail(self, day, hours: float = 1.0) -> Optional[pd.DataFrame]:
        """The last hour of the previous day: lag history for buckets after midnight."""
        prev = pd.Timestamp(day).normalize() - pd.Timedelta(days=1)
        if not self.cache.has_day(prev):
            return None
        path = self.cache.panel_path(prev)
        if not path.exists():
            return None
        cols = KEY + ["bucket", "match_id", "pool_name", "turnover", "tickets", "odds", "line_label",
                      "combination_string", "is_inplay", "mins_to_ko", "priced_before"]
        try:
            tail = pd.read_parquet(path, columns=[c for c in cols])
        except Exception:                                       # noqa: BLE001
            tail = pd.read_parquet(path)
        tail["bucket"] = pd.to_datetime(tail["bucket"]).astype("datetime64[ns]")
        cut = pd.Timestamp(day).normalize() - pd.Timedelta(hours=hours)
        return tail[tail["bucket"] >= cut]

    def _month(self, day, store: Dict, name: str, pad_days: int) -> pd.DataFrame:
        from src.backtest.parquet.loader import load_window
        m0 = pd.Timestamp(day).to_period("M").start_time
        if m0 not in store:
            try:
                store[m0] = load_window(self.cfg.data_dir, name, m0 - pd.Timedelta(days=pad_days),
                                        m0 + pd.offsets.MonthBegin(1))
            except Exception as exc:                            # noqa: BLE001
                logger.warning("%s for %s not loaded (%s); features that need it are neutral",
                               name, m0.strftime("%Y-%m"), exc)
                store[m0] = pd.DataFrame()
            if len(store) > 2:
                store.pop(sorted(store)[0])
        return store[m0]

    def events_for(self, day) -> pd.DataFrame:
        ev = self._month(day, self._month_events, "events", 2)
        if ev.empty:
            return ev
        lo = pd.Timestamp(day).normalize() - pd.Timedelta(days=1)
        hi = pd.Timestamp(day).normalize() + pd.Timedelta(days=1)
        t = pd.to_datetime(ev["incident_datetime"])
        return ev[(t >= lo) & (t < hi)]

    def market_for(self, day) -> pd.DataFrame:
        mk = self._month(day, self._month_market, "market", self.cfg.lookback_days)
        if mk.empty:
            return mk
        lo = pd.Timestamp(day).normalize() - pd.Timedelta(days=self.cfg.lookback_days)
        hi = pd.Timestamp(day).normalize() + pd.Timedelta(days=1)
        t = pd.to_datetime(mk["effective_datetime"])
        return mk[(t >= lo) & (t < hi)]


# ----------------------------------------------------------------- live
class _FrameCache:
    """Duck-types the W06 MonthCache from in-memory frames."""

    def __init__(self, cfg, odds, inv, params, events):
        from src.backtest.parquet import panel as P
        self.cfg = cfg
        self.odds, self.inv, self.params, self.events = odds, inv, params, events
        self.agg = P.aggregate_investments(inv, cfg.bucket_minutes)
        self.settle = P.build_settlement(inv)
        self.odds_bucket = P.bucket_last_odds(odds, cfg.bucket_minutes)
        self.params_bucket = P.bucket_last_params(params)
        self.event_marks = P.event_marks(events)
        self.keys = P.collect_keys(odds, inv)


class LivePanelBuilder:
    """A live Snapshot -> the panel rows for the bucket being forecast (and its history)."""

    def __init__(self, settings):
        self.settings = settings
        self.cfg = settings.legacy_config()

    @staticmethod
    def _canon(name: str, frame: pd.DataFrame) -> pd.DataFrame:
        from src.backtest.parquet import loader as L
        if frame is None or frame.empty:
            return pd.DataFrame(columns=sorted(set(L.ALIASES[name].keys())))
        rename = L._resolve(name, list(frame.columns))
        # a frame already in canonical names (the replay source) keeps them
        for canon in L.ALIASES[name]:
            if canon in frame.columns and canon not in rename.values():
                rename[canon] = canon
        out = frame[list(rename)].rename(columns=rename)
        out = out.loc[:, ~out.columns.duplicated()]
        return L.normalise(name, out)

    def build(self, snapshot, as_of=None) -> Tuple[pd.DataFrame, dict]:
        """Panel rows up to and including the current bucket, plus the raw frames used."""
        from src.backtest.parquet import panel as P
        as_of = pd.Timestamp(as_of or snapshot.as_of)
        step = self.settings.panel.bucket_minutes
        current = as_of.floor("{}min".format(step))
        odds = self._canon("odds", snapshot.odds)
        inv = self._canon("investments", snapshot.investments)
        # A bucket takes TG/SUP from the last row strictly before it; the SQL source's ``params`` keeps
        # only the newest row, which a mid-bucket refresh cannot use, so the full history wins.
        history = getattr(snapshot, "params_history", None)
        params = self._canon("params", history if history is not None and not history.empty else snapshot.params)
        events = self._canon("events", snapshot.events)
        matches = self._canon("matches", snapshot.match_info).drop_duplicates("match_id")
        market = self._canon("market", snapshot.market)
        # money and prices after as_of cannot be known yet, whatever the feed returned
        if not inv.empty:
            inv = inv[inv["start_sell_time"] < as_of]
        if not odds.empty:
            odds = odds[odds["effective_datetime"] <= as_of]
        if not inv.empty and "pool_name" not in inv.columns and not odds.empty:
            inv = inv.merge(odds[["pool_id", "pool_name"]].drop_duplicates("pool_id"), on="pool_id", how="left")
        # The real-time match info only carries a full-time score once the match is over; a replay
        # of history carries every final score from the start, so it cannot say a match has ended.
        finished = set()
        if getattr(snapshot, "source", "") != "replay" and "ft_home" in matches.columns:
            ft = pd.to_numeric(matches["ft_home"], errors="coerce")
            finished = set(pd.to_numeric(matches.loc[ft >= 0, "match_id"], errors="coerce").dropna().astype("int64"))
        pools = self._pools(snapshot, odds, inv, step, current, finished)
        fc = _FrameCache(self.cfg, odds, inv, params, events)
        # Built exactly as training reads a cached day: today's rows, start odds taken across midnight
        # from the previous day's last six hours (PanelCache.load_day), and money lags from its last
        # hour (HistoricalPanel.previous_tail). The snapshot holds only live matches, so the
        # previous day is a handful of rows.
        day0 = current.normalize()
        frames = []
        for day in (day0 - pd.Timedelta(days=1), day0):
            f = P.build_day(self.cfg, day, fc, pools, matches, prices=False)
            if f is not None and not f.empty:
                frames.append(f)
        if not frames:
            return pd.DataFrame(), {"events": events, "market": market, "current_bucket": current}
        both = pd.concat(frames, ignore_index=True)
        both["bucket"] = pd.to_datetime(both["bucket"]).astype("datetime64[ns]")
        before = both[both["bucket"] < day0]
        panel = both[(both["bucket"] >= day0) & (both["bucket"] <= current)].reset_index(drop=True)
        if panel.empty:
            return pd.DataFrame(), {"events": events, "market": market, "current_bucket": current}
        prev = before.loc[before["bucket"] >= day0 - pd.Timedelta(hours=6),
                          [c for c in KEY + ["bucket", "odds", "true_odds"] if c in before.columns]]
        panel = P.start_odds(self.cfg, panel, prev if not prev.empty else None)
        panel["bucket"] = pd.to_datetime(panel["bucket"]).astype("datetime64[ns]")
        # the same contract HistoricalPanel.load_day applies: sentinels, ranges, duplicate keys
        panel, rep = validate(panel, PANEL_CONTRACT)
        if rep.errors or rep.duplicate_keys:
            rep.log()
        panel = mark_forecastable(panel, self.settings.panel.prematch_window_min)
        tail = before[before["bucket"] >= day0 - pd.Timedelta(hours=1)]
        log_frame(logger, "live panel @ {:%H:%M}".format(current), panel,
                  ["odds", "true_odds", "tg", "turnover"], level=10)
        return panel, {"events": events, "market": market, "current_bucket": current,
                       "tail": tail.reset_index(drop=True) if not tail.empty else None}

    @staticmethod
    def _pools(snapshot, odds: pd.DataFrame, inv: pd.DataFrame, bucket_minutes: int = 5,
               current: Optional[pd.Timestamp] = None, finished: Optional[set] = None) -> pd.DataFrame:
        """Pool_Details as the feed implies it.

        Training rows stop at each pool's close_time, and a row is forecastable only while the pool
        is open at the bucket start. Live, in order of preference:
          - the close time the source lists with the pool (SQL pool_h.close_datetime, replay);
          - a pool the source no longer lists closed just after its last price or bet;
          - a 90-minute pool of a match whose full-time result is published closed at the current
            bucket (the SQL list keeps every pool that ever started selling).
        Closed pools keep their rows up to the close: the match history needs the money they took."""
        seen = [f[["pool_id", "match_id"]] for f in (odds, inv) if not f.empty and "match_id" in f.columns]
        ids = pd.concat(seen, ignore_index=True) if seen else pd.DataFrame(columns=["pool_id", "match_id"])
        ap = snapshot.active_pools
        listed = ap is not None and not ap.empty and "pool_id" in ap.columns
        if listed:
            ids = pd.concat([ap[["pool_id", "match_id"]], ids], ignore_index=True)
        ids = ids.assign(pool_id=pd.to_numeric(ids["pool_id"], errors="coerce").astype("Int64"),
                         match_id=pd.to_numeric(ids["match_id"], errors="coerce").astype("Int64"))
        ids = ids.dropna(subset=["pool_id"]).drop_duplicates("pool_id")
        # The first price stands in for the selling start. Floored to its bucket: the span code
        # rounds a start UP to the next bucket, and start_odds needs the bucket that holds the
        # first price to exist, or the line only counts as priced one bucket late.
        step = "{}min".format(int(bucket_minutes))
        first = odds.groupby("pool_id")["effective_datetime"].min().dt.floor(step).rename("start_selling_time") \
            if not odds.empty else pd.Series(dtype="datetime64[ns]", name="start_selling_time")
        names = odds[["pool_id", "pool_name"]].drop_duplicates("pool_id") if not odds.empty else \
            pd.DataFrame(columns=["pool_id", "pool_name"])
        out = ids.merge(first.reset_index(), on="pool_id", how="left").merge(names, on="pool_id", how="left")
        out["close_time"] = pd.Series(pd.NaT, index=out.index, dtype="datetime64[ns]")
        pid = out["pool_id"].astype("int64")
        if listed:
            active = set(pd.to_numeric(ap["pool_id"], errors="coerce").dropna().astype("int64"))
            if "close_time" in ap.columns:
                # usually none yet: an open pool has no close time
                table = {int(p): c for p, c in zip(pd.to_numeric(ap["pool_id"], errors="coerce"),
                                                   pd.to_datetime(ap["close_time"], errors="coerce"))
                         if pd.notna(p) and pd.notna(c)}
                if table:
                    out["close_time"] = pd.to_datetime(pid.map(table)).astype("datetime64[ns]")
            last = [odds.groupby("pool_id")["effective_datetime"].max()] if not odds.empty else []
            if not inv.empty:
                last.append(inv.groupby("pool_id")["start_sell_time"].max())
            if last:
                seen_at = pd.concat(last, axis=1).max(axis=1)
                closed = ~pid.isin(active)
                out.loc[closed, "close_time"] = pid[closed].map(seen_at) + pd.Timedelta(minutes=1)
        if finished and current is not None:
            # also when the listed close is later: it may be a scheduled close, and the result says it is over
            extra_time = out["pool_name"].astype("string").fillna("").str.upper().str.startswith("ET").to_numpy()
            later = (out["close_time"].isna() | (out["close_time"] > pd.Timestamp(current))).to_numpy()
            over = (out["match_id"].astype("Int64").isin(list(finished)).fillna(False).to_numpy()
                    & later & ~extra_time)
            if over.any():
                out.loc[over, "close_time"] = pd.Timestamp(current)
                logger.debug("closed %d pool(s) of %d finished match(es) at %s", int(over.sum()), len(finished),
                             current)
        out["pool_type"] = out.get("pool_name")
        return out[["pool_id", "start_selling_time", "close_time", "pool_name", "pool_type", "match_id"]]
