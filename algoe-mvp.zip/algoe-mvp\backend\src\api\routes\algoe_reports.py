"""
Algo E Report Routes - the W10 backtest reports on the desk's Backtest tab

    GET /api/algoe/reports      every backtest_* folder under AlgoE_Work/reports, newest first, with the
                                sections each one holds and the models that made it
    GET /api/algoe/report       one report: the newest copy of every section across those folders, so a full
                                run and a later `--only events` run read as one; ?ids=a,b picks the folders

Both take ?work= for another AlgoE_Work folder. Without it the folder is the command line's
(ALGOE_SETTINGS / ALGOE_DATA_DIR / ALGOE_WORK_DIR): what algoe-3-backtest.bat wrote is what the tab shows.
Reports are read from disk, never recomputed here. /api/algoe/report's ``data_quality`` names the report's
days whose Match_Investments file was written after the report, is suspect now, or that it left out.

Change Log:
-----------
2026-10-12      Initialize
2026-11-20      data_quality: changed, suspect and excluded days (Raw_Data/_algoe_quality.json; ?data=);
                walkforward: the days score-days scored after the report (reports/daily)
"""

import json
import math
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
from fastapi import APIRouter, HTTPException, Query

from src.backtest.parquet.quality import read_quality

router = APIRouter()

_lock = threading.Lock()
_cache: Dict[Tuple[str, float], dict] = {}            # (report.json path, mtime) -> parsed, cleaned


def _clean(obj):
    """JSON a browser can parse: NaN and inf to null, numpy scalars to Python."""
    if isinstance(obj, dict):
        return {str(k): _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        try:
            return _clean(obj.item())
        except (ValueError, AttributeError):
            return str(obj)
    return obj


def _work(work: Optional[str]) -> Path:
    if work:
        p = Path(work).expanduser()
        if not p.is_dir():
            raise HTTPException(404, "no folder {}".format(p))
        return p
    try:
        from algoe.settings import Settings
        return Path(Settings.load().paths.work)
    except Exception as exc:                                   # noqa: BLE001
        raise HTTPException(500, "cannot resolve the AlgoE_Work folder from the settings: {}".format(exc))


def _read(path: Path) -> dict:
    key = (str(path), path.stat().st_mtime)
    with _lock:
        hit = _cache.get(key)
    if hit is not None:
        return hit
    data = _clean(json.loads(path.read_text(encoding="utf-8")))
    meta = data.get("meta") or {}
    window = ((meta.get("settings") or {}).get("window")) or {}
    data["meta"] = {k: v for k, v in meta.items() if k != "settings"}
    data["meta"]["window"] = window
    with _lock:
        for k in [k for k in _cache if k[0] == str(path)]:
            _cache.pop(k, None)
        _cache[key] = data
    return data


SECTION_ORDER = ("turnover", "feature_groups", "trueprob", "gm", "optimizer", "replication", "drift", "events",
                 "elasticity", "mix")


def _sections(data: dict) -> List[str]:
    return [k for k in SECTION_ORDER if data.get(k)]


def _folders(root: Path) -> List[Path]:
    rep = root / "reports"
    if not rep.is_dir():
        return []
    out = [p for p in rep.iterdir() if p.is_dir() and p.name.startswith("backtest_") and (p / "report.json").exists()]
    return sorted(out, key=lambda p: (p / "report.json").stat().st_mtime, reverse=True)


def _row(p: Path) -> dict:
    data = _read(p / "report.json")
    meta = data.get("meta") or {}
    t = data.get("turnover") or {}
    mx = data.get("mix") or {}
    days = t.get("days") or mx.get("test_days") or []
    return {"id": p.name, "generated": meta.get("generated"), "seconds": meta.get("seconds"),
            "turnover_model": meta.get("turnover_model"), "probability_model": meta.get("probability_model"),
            "sections": _sections(data), "test_days": len(days),
            "first_day": days[0] if days else None, "last_day": days[-1] if days else None,
            "size": (p / "report.json").stat().st_size}


@router.get("/algoe/reports")
def reports(work: Optional[str] = Query(None, description="an AlgoE_Work folder; default from the settings")):
    root = _work(work)
    rows = []
    for p in _folders(root):
        try:
            rows.append(_row(p))
        except (OSError, ValueError) as exc:
            rows.append({"id": p.name, "error": str(exc), "sections": []})
    return {"work": str(root), "reports_dir": str(root / "reports"), "exists": (root / "reports").is_dir(),
            "reports": rows}


def _data_dir(data: Optional[str]) -> Optional[Path]:
    if isinstance(data, str) and data:                     # (called directly, the default is FastAPI's Query)
        return Path(data).expanduser()
    try:
        from algoe.settings import Settings
        return Path(Settings.load().paths.data_dir)
    except Exception:                                          # noqa: BLE001
        return None


def _data_quality(raw: Optional[Path], metas: List[dict], sections: Dict[str, object]) -> dict:
    """The report's days whose Match_Investments file was written after the oldest report used, is suspect
    now, or that a report left out."""
    q = read_quality(raw) if raw is not None else {}
    by_day = q.get("days") or {}
    t, mx = sections.get("turnover") or {}, sections.get("mix") or {}
    days = set(t.get("days") or []) | set(mx.get("test_days") or [])
    made = [t for t in (pd.to_datetime(m.get("generated"), errors="coerce") for m in metas) if not pd.isna(t)]
    first = min(made) if made else None

    def written_after(rec):
        w = pd.to_datetime((rec or {}).get("written_at"), errors="coerce")
        return bool(first is not None and not pd.isna(w) and w > first)
    return {"changed": sorted(d for d in days if written_after(by_day.get(d))),
            "suspect": sorted(d for d in days if (by_day.get(d) or {}).get("verdict") == "suspect"),
            "excluded": sorted({d for m in metas for d in (m.get("excluded_days") or [])}),
            "checked": q.get("checked")}


def _walkforward(root: Path, raw: Optional[Path], sections: Dict[str, object]) -> dict:
    """The days score-days scored after the report's own (reports/daily), as day rows of the compare chart, with
    how often the model beat last 5 minutes and the days whose file changed after their score."""
    from algoe.evaluation.walkforward import better, scored
    docs = scored(root / "reports" / "daily")
    t, mx = sections.get("turnover") or {}, sections.get("mix") or {}
    in_report = set(t.get("days") or []) | set(mx.get("test_days") or [])
    days = sorted(d for d in docs if d not in in_report)
    q = (read_quality(raw).get("days") or {}) if raw is not None else {}

    def changed(d):
        w = pd.to_datetime((q.get(d) or {}).get("written_at"), errors="coerce")
        s = pd.to_datetime(docs[d].get("scored_at"), errors="coerce")
        return not pd.isna(w) and not pd.isna(s) and w > s
    moved = [d for d in days if changed(d)]
    suspect = [d for d in days if (q.get(d) or {}).get("verdict") == "suspect"]
    # a day whose money is suspect, or that changed after its score, is drawn faint and not counted
    wins = [better(docs[d]) for d in days if d not in moved and d not in suspect]
    return {"days": days, "since": days[0] if days else None,
            "compare": [r for d in days for r in docs[d].get("compare") or [] if r.get("dim") == "day"],
            "better": sum(w is True for w in wins), "scored": sum(w is not None for w in wins),
            "models": sorted({docs[d].get("turnover_model") for d in days if docs[d].get("turnover_model")}),
            "changed": moved, "suspect": suspect}


@router.get("/algoe/report")
def report(ids: Optional[str] = Query(None, description="comma-separated report folders; default every folder"),
           work: Optional[str] = Query(None),
           data: Optional[str] = Query(None, description="the Raw_Data folder; default from the settings")):
    root = _work(work)
    folders = _folders(root)
    if ids:
        want = [x.strip() for x in ids.split(",") if x.strip()]
        by_name = {p.name: p for p in folders}
        missing = [x for x in want if x not in by_name]
        if missing:
            raise HTTPException(404, "no report {} under {}".format(", ".join(missing), root / "reports"))
        folders = sorted((by_name[x] for x in want), key=lambda p: (p / "report.json").stat().st_mtime, reverse=True)
    if not folders:
        raise HTTPException(404, "no backtest report under {} - run algoe-3-backtest.bat".format(root / "reports"))
    merged: Dict[str, object] = {}
    source: Dict[str, str] = {}
    metas: Dict[str, dict] = {}
    for p in folders:                                           # newest first: the first copy of a section wins
        doc = _read(p / "report.json")
        metas[p.name] = doc.get("meta") or {}
        for k in _sections(doc):
            if k not in merged:
                merged[k] = doc[k]
                source[k] = p.name
    used = sorted(set(source.values()), key=lambda x: [p.name for p in folders].index(x))
    models = {x: metas[x].get("turnover_model") for x in used}
    raw = _data_dir(data)
    return {"work": str(root), "ids": used, "source": source, "models": models,
            "meta": {x: metas[x] for x in used}, "sections": merged,
            "mixed_models": len({m for m in models.values() if m}) > 1,
            "data_quality": _data_quality(raw, [metas[x] for x in used], merged),
            "walkforward": _walkforward(root, raw, merged)}
