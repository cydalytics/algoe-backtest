# Spec - W16 desk execution

W16, 2026-11-19. Folder: `BiWeekly Meetings/W16_2026-11-24_ui`, a copy of W14 as shipped (GitHub `7705aed`).

## 1. Problem

Office screenshots of 19 Nov, desk on the W14 zips:

- **Board**: most prematch matches read `NO SOLVE`. Four gates stop them: the turnover model only
  forecasts inside `panel.prematch_window_min` (360) of kick-off (`mark_forecastable`); `build_books`
  drops a prematch line whose odds have not moved for 90 min (`max_odds_age_prematch_min`); a block with
  no HKJC TG/SUP row is left alone (the rows whose theta age reads `-m`); a sweep skips a match expecting
  under `min_match_turnover` (HK$500).
- **Cockpit**: `So far` and `Last 5m` are 0 on every selection while the bucket forecast is HK$109K.
  Every SQL connection now asks for `ApplicationIntent=ReadOnly`; the live money table
  (`ticket_bets_dtl_agg_mem`, memory-optimized, read `WITH (SNAPSHOT)`) may be empty on a readable
  secondary. What the table holds (per minute or cumulative) has never been checked in play.
- Any opened match refreshes every 15 s however far from kick-off; the 15-second in-play cycle only runs
  when publishing is on; the cockpit polls every 5 s.
- Stage 2 weightings exist (each line keeps its overround, +-3%, ridge, ladder) but the desk never shows
  them; the step cap applies to focus refreshes only; the market cap covers main lines only.
- **Backtest tab**: one red day. `match_investments_2026-09-27` / `-28` are 12-16 KB against 10-20 MB days:
  extracted before the source had them, never re-extracted (the updater restarts at the newest day - 1),
  never checked. The bet database comes from a list that ends at 2026-02.
- Data and report stop in October: the daily task exists only if `algoe-schedule-update.bat` was run once;
  the nightly never writes a report; `update-data --report` refuses the nightly's serving refits.
- Every live read re-pulls full odds / true odds / market / money history; the trigger scan reads the
  whole card every 15 s; each sweep starts a new process pool.

## 2. Outcome

Every match on sale has theta* and weightings. Matches in play or within 90 min of kick-off refresh every
15 s, the rest every 5 min. The cockpit shows each selection's bucket money (expected, received,
remaining, the bucket clock) and its stage-2 weighting with the line's overround. Raw_Data is checked day
by day and kept current by a daily task, which also extends the Backtest tab with honest walk-forward days.
The live pipeline reads less, is measured, and every piece of its logic is audited.

## 3. Non-goals

- No retrain, no `FEATURE_VERSION` change; the models still train on the last 6 h before kick-off.
- No change to the live money query and no automatic switch to ReadWrite: the probe decides, the data
  engineering team agrees.
- The W06-W08 MVP desk, the W06 parquet engine and the simulators keep their behaviour.
- Matches whose TG/SUP is implied from the board are not published.
- No new dependency.

## 4. Acceptance criteria

| # | Criterion | Proof |
|---|-----------|-------|
| AC1 | W16 is W14 as shipped with history; W14 is untouched; the library bundle is `algoe-w16`. | git log; package |
| AC2 | `probe-live --intent both` reads the live money for the match on a ReadOnly and a ReadWrite connection and prints rows, money and newest minute per intent and a verdict. `ALGOE_SQL_INTENT_BIS2` (`readonly` / `readwrite`, default `readonly`) sets the bis2 connection's intent. | unit tests |
| AC3 | When matches in the model window expect at least `live.money_feed_min_expected` (HK$20,000) in total and three reads in a row find no money in the current or previous bucket, the board shows `live money feed empty` until money is seen again. Every read (sweep, fast lane, scan) counts model-window rows only; one read that sees money resets the count. | unit tests |
| AC4 | Every match with a selling line-market pool gets a decision: far matches, prematch lines with old odds, matches below `min_match_turnover`, matches without an HKJC TG/SUP row. Statuses are solved or held (kept board), tagged `far` / `implied θ`; no on-sale match reads `no solve`. | unit tests; selftest S9 |
| AC5 | A far row's forecast is its match total - a credibility blend of the match's own last 60 min of money and `anchor x g(hours to KO)` - split by the champion's shares. `fit-far-prematch` writes `models/turnover/FAR_PREMATCH.json` (curve, league anchors, credibility, held-out WAPE vs last 5); the credibility k is chosen on the fit window, so the held-out days only score it. Without it a default curve serves; `models.far_curve` in the payload says which curve serves and the Engine row shows it. | unit tests |
| AC6 | A block without an HKJC TG/SUP row is priced at theta fitted to the de-margined board; on a book priced at known theta with a margin, the fit recovers TG and SUP within 0.03 (corners 0.1). The publisher skips such a match: `TG/SUP implied from the board: desk only`, adding that our last message stays on the engine when one was sent. Without a fit the block is left out and the board's `no book` alert names the missing block. | unit tests |
| AC7 | The sweep solves on the engine's persistent pool with at most half its workers in flight. A pool whose worker died is replaced before the next solve, and the card in flight finishes in-process. | unit tests |
| AC8 | `TG/SUP N min old` is an alert in play only (`live.theta_age_alert_inplay_min`, 2); prematch the age is shown, not alerted. | payload test |
| AC9 | Every `live.fast_seconds` (15) the fast lane refreshes each match in play or within `live.fast_lane_minutes` (90) of kick-off, publishing on or off. Other matches refresh at the sweep and once when opened. A fast-lane match's board row, decision and weightings come from the fast lane (the sweep hands it the bucket forecast only); each book is solved or marked behind and solved first next cycle, the cycle inside `live.fast_seconds`. | unit tests |
| AC10 | A prematch fast-lane decision is published with `update: "refresh"`; `sweep` and `inplay` keep their meaning. | test_publisher; snapshot spec |
| AC11 | The cockpit polls at its lane's cadence (fast lane `live.fast_seconds`, otherwise 60 s, 2 s while refreshing) and its header names the lane. | build; browser |
| AC12 | The cockpit carries `bucket` {start, end, minutes, elapsed_s, clock_s, received, remaining, expected_total, forecast, next_bucket, hot, horizon, horizon_money} (`clock_s` on the engine's clock, which the bucket clock runs on); each selection carries `expected_total` = observed + remaining. Outside the fast lane received and remaining follow the trigger scan's read without a re-solve. | payload test; unit test |
| AC13 | The book shows 5m expected, received, remaining, a progress bar and the bucket clock (m:ss / 5:00); the header says what the solve used. | build; screenshots |
| AC14 | The Weightings tab shows each line's received money per side and the approximate payout if each side wins. `optimizer.liability_lambda` (default 0) adds a payout-variance penalty to stage 2; at 0 decisions are unchanged. | unit test |
| AC15 | Each selection shows W, the change in implied probability (pp) and the weighted price; each line shows overround before and after (equal within 1e-6), the changes summing to 0, the market gap and the binding constraint. | payload test; screenshots |
| AC16 | Stage 2 has a step cap in every mode (`weighting_max_step` focus, `weighting_max_step_sweep` sweep), partial adjustment `weighting_adjust` in implied-probability space (overround and ladder kept), ticket credibility in the nowcast (`live.nowcast_ticket_k`), a market guard on every line with a market price (`weighting_market_lines`, `weighting_market_band`) and a deadband (`weighting_min_gain_bps`). The cap holds through `optimize_match`: chained weightings are not held to beat stage 1 (a tilt the money no longer backs unwinds at the cap), a held match carries them, a match the budget does not reach keeps them. Last weightings that break a constraint on the new prices and that no capped move mends go back to 1 for their pool (`<pool>:weighting_reset`): the constraints come before the cap. | unit tests |
| AC17 | `backtest --only optimizer` reports `weight_churn`, the mean change in a weighting between a match's consecutive sampled decisions, each from 1 (unchained), with the stage-2 configuration it ran; the live chain's churn is a live metric (AC27). | unit test |
| AC18 | Each Match_Investments day is checked before it is written: pools with money vs pools concluded (G2_pool_details, the extract's own filter) and money per concluded pool vs the trailing 28-day median of the same day type; without the pool count (check-data on pool files without `conclude_date`) money and rows vs that median. Suspect under half the pools (or three quarters of the usual share) or a quarter of the usual money; provisional newer than D-2; ok otherwise; in `Raw_Data/_algoe_quality.json` with when the file was written. An extract with under 95% of the money on disk does not replace it (`--force` does); the verdict is then the file's. | unit tests |
| AC19 | The plan re-extracts suspect and provisional days of the last 30 days and `--days FROM:TO`; bet databases are found in `sys.databases`, the old list as fallback. | unit tests |
| AC20 | Panel, features, backtest and training skip suspect days (the window's days leave them out) and the report lists them; `check-data` gives every day on disk a verdict, saves it and prints the odd ones (2026-09-27/28 to be confirmed on the office box); `/api/algoe/report` carries `data_quality` {changed, suspect, excluded} and the Backtest tab names those days. | unit tests |
| AC21 | `start.ps1` registers `AlgoE daily` (06:00, this user, no admin) when missing, through `algoe-schedule-daily.bat --quiet`, running `algoe-nightly.bat`; `-NoSchedule` skips it; `algoe-schedule-daily.bat --dry-run` prints the command. | script tests (dry run, parse) |
| AC22 | Before it refits, the nightly runs `score-days`: each day after the turnover champion's fit (a serving refit's recorded window, else train and validation), not suspect and not scored yet, scored for it against last 5 on every row of the day, written to `reports/daily/<day>.json`; the nightly writes `reports/daily/_nightly.json`. `update-data --report` and `backtest --days` accept a serving refit for days after its fit. | unit tests; end to end on the selftest champion |
| AC23 | `/api/algoe/report` carries `walkforward` (days after the report's, their compare rows, better / scored, changed after their score); the tab extends the day chart with dashed bars and `walk-forward since <day>: B better on x of y`, grey for suspect or changed days; the board's Engine row shows the newest day, the last daily run and recent suspect days (`health.data`). | API tests; screenshots |
| AC24 | With `live.incremental_fetch` (on) the fast lane reads only the odds, market odds and money rows since the newest row held per match and table, on the data's own clock, less 2 min (SqlSource `since=` per table; another source is read whole and cut, giving the same snapshot), merged by key with the newer row winning; the scan, now off the fast lane every minute, reads whole. Each sweep's full read reconciles, per match and table, the settled rows the incremental reads brought in (rows on one side only count, as do true odds and tickets) and reports the mismatch rate per table; above `live.incremental_max_mismatch` reads stay full until a sweep agrees, and after three failed sweeps in a row until a restart. Incremental snapshots equal full ones on the simulator and on replay (selftest S14). | unit tests; selftest S14 |
| AC25 | The trigger scan no longer reads the whole card every 15 s: fast-lane matches use the fast lane's read, the others are scanned every `live.scan_seconds` (60). | unit test |
| AC26 | The turnover forecast and the belief have separate locks; at a bucket boundary the fast lane carries the previous bucket's next-bucket forecast until the sweep's lands. | unit test |
| AC27 | `/api/live/status` and the board carry the fast lane's p50 / p95 cycle seconds, behind, data age and the live weighting churn (mean change between a match's consecutive decisions); `bench-live` prints them; selftest S14 passes on the simulator. | selftest |
| AC28 | `docs/W16_PIPELINE_AUDIT.md` lists every check with finding, test, fix and evidence. | review |
| AC29 | Backend tests (baseline 186 + the known W06 failure), selftest, API contract and `npm run build` pass; board, cockpit and backtest screenshots at 1440 and 390 px with `scrollWidth <= innerWidth`; the zips are on `cydalytics/algoe-backtest` with the office steps. | outputs |

## 5. Interfaces

- Settings, `live`: `fast_lane_minutes` 90, `fast_seconds` 15, `fast_budget_seconds` 10, `scan_seconds` 60,
  `money_feed_min_expected` 20000, `theta_age_alert_inplay_min` 2, `nowcast_ticket_k` 3, `incremental_fetch`
  true, `incremental_overlap_seconds` 120, `incremental_max_mismatch` 0.01. `publish.inplay_seconds` /
  `inplay_budget_seconds` stay accepted; changed from their defaults they set the fast lane's.
- Settings, `optimizer`: `weighting_max_step_sweep` 0.02, `weighting_adjust` 0.5, `weighting_market_lines`
  `all`, `weighting_market_band` 0.05, `weighting_min_gain_bps` 0.5, `liability_lambda` 0,
  `max_odds_age_live_prematch_min` 0 (no limit on the live desk's pre-match lines, far or near: the live feed
  drops deleted lines itself; the backtests keep `max_odds_age_prematch_min`). Every new numeric setting must
  be >= 0 (`check()` refuses less).
- `python -m algoe probe-live --match ID --intent readonly|readwrite|both`;
  `python -m algoe fit-far-prematch [--days N]`; `python -m algoe score-days`;
  `python -m algoe bench-live [--source ...] [--cycles N]`; `update-data --days FROM:TO [--force]`.
- Cockpit payload: `bucket`, `freshness.lane` / `theta_age_alert_min`, `weighting_rules`, selection
  `expected_total`, `weighting_prev`, `implied_now`, `implied_stage1`, `implied_star`, `weight_binding`,
  `desk_weighting`; a line's overround before / after is the sum of its sides' `implied_stage1` /
  `implied_star` (the UI adds them up). `models.far_curve` {source, fitted, k, metrics}.
  Board: row `lane`, `far`, `theta_source`, `held`; top-level `health` (money feed, fast lane, data).
  Publish status `inplay.fast_seconds` / `fast_lane_minutes`.
- Snapshot message: `update` takes `refresh` as well.

## 6. Edge cases

- A far match with no money at all: forecast 0, solved, held at HKJC's theta.
- A match crossing 90 min to kick-off joins the fast lane at its next cycle; one that kicks off stays in it.
- The fast lane at a bucket boundary before the sweep lands: carried forecast, flagged.
- Implied theta that does not converge or prices outside bounds: the block is left alone, the reason shown.
- A day re-extracted with less money than on disk: the old file stays and keeps its own verdict (a
  suspect file is retried next run; `--force` replaces it).
- A day the server says concluded no pool: no money is right, the day is not suspect.
- A month moved to an archive database the list does not know: found in `sys.databases`; if it is in
  neither, the quality check marks the day suspect instead of replacing a good file.
- `schtasks` refused by policy: `start.ps1` says so and the desk still starts; the stale-data update on
  start still runs.

## 7. Risks

- The live money table's meaning and the ReadOnly hypothesis are unverified until the office probe.
- The far curve is only as good as the office fit; until then a default curve serves, flagged.
- Implied theta is not HKJC's internal TG/SUP.
- More Kafka messages (fast-lane prematch, every far match on the sweep); dry run today.
- Incremental reads miss a row changed behind the watermark until the next sweep reconciles (5 min max).
- Days next to a Match_Investments day that is written again keep features built from its old file until
  `build-features` runs over them (as before W16).

## 8. Open questions (answered on the office box)

1. Does the ReadOnly connection see `ticket_bets_dtl_agg_mem`? (`algoe-6-probe-live.bat --intent both`)
2. Is that table per minute or cumulative? (same probe, `--tickets`)
3. How long do the sweep and the fast lane take on a Saturday card? (`/api/live/status`, `bench-live`)
4. How well does the far curve forecast far buckets? (`fit-far-prematch`)
