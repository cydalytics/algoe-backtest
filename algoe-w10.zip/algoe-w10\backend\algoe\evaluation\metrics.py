"""
Metrics

Definitions match the W06 report so a number here is comparable with one
already shown at a meeting:

    WAPE      sum |y - f| / sum y            "off by x% of the money"
    bias      sum f / sum y - 1              over / under forecast
    deviance  mean Poisson unit deviance     proper score for a MEAN forecast;
                                             WAPE is minimised by the median and
                                             rewards forecasting zero on sparse rows
    active    rows with money now or in the previous bucket (the W06 honest subset)

Match-level WAPE sums inside each (match, bucket) first: what the optimiser's
volume anchor needs. Probability metrics use the soft outcome (r + 1) / 2.

``diebold_mariano`` tests whether one forecast's daily loss is lower than
another's with a Newey-West (lag 1) variance, so "beats last 5 minutes" is a
statement about days, not about a million correlated rows.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd


def wape(y, f) -> Optional[float]:
    y = np.asarray(y, dtype="float64")
    d = float(np.abs(y).sum())
    return float(np.abs(y - np.asarray(f, dtype="float64")).sum()) / d if d > 0 else None


def bias(y, f) -> Optional[float]:
    s = float(np.sum(y))
    return float(np.sum(f)) / s - 1.0 if s > 0 else None


def poisson_deviance(y, f, floor: float = 1.0) -> float:
    """Mean Poisson unit deviance. ``floor`` keeps a zero forecast finite (HK$1)."""
    y = np.asarray(y, dtype="float64")
    mu = np.maximum(np.asarray(f, dtype="float64"), floor)
    return float(np.mean(2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))))


def turnover_scores(y, f, last5=None, group=None) -> Dict[str, Optional[float]]:
    y = np.asarray(y, dtype="float64")
    f = np.asarray(f, dtype="float64")
    out = {"rows": int(len(y)), "sum_actual": float(y.sum()), "sum_forecast": float(f.sum()),
           "wape": wape(y, f), "bias": bias(y, f), "deviance": poisson_deviance(y, f)}
    if last5 is not None:
        l5 = np.asarray(last5, dtype="float64")
        act = (y > 0) | (l5 > 0)
        out["active_rows"] = int(act.sum())
        out["active_wape"] = wape(y[act], f[act]) if act.any() else None
    if group is not None:
        g = pd.DataFrame({"g": np.asarray(group), "y": y, "f": f}).groupby("g")[["y", "f"]].sum()
        out["match_wape"] = wape(g["y"], g["f"])
    return out


class ScoreAccumulator:
    """Additive sums so a long window is scored one day at a time, in flat memory."""

    def __init__(self):
        self.sums: Dict[str, Dict[str, float]] = {}

    def add(self, name: str, y, f, last5, match_key) -> None:
        y = np.asarray(y, dtype="float64")
        f = np.asarray(f, dtype="float64")
        l5 = np.asarray(last5, dtype="float64")
        act = (y > 0) | (l5 > 0)
        mu = np.maximum(f, 1.0)
        dev = 2.0 * (np.where(y > 0, y * np.log(np.maximum(y, 1e-12) / mu), 0.0) - (y - mu))
        g = pd.DataFrame({"g": match_key, "y": y, "f": f}).groupby("g")[["y", "f"]].sum()
        s = self.sums.setdefault(name, {k: 0.0 for k in (
            "n", "y", "f", "ae", "dev", "act_y", "act_ae", "act_n", "m_ae", "m_y")})
        s["n"] += len(y)
        s["y"] += float(y.sum())
        s["f"] += float(f.sum())
        s["ae"] += float(np.abs(y - f).sum())
        s["dev"] += float(dev.sum())
        s["act_n"] += float(act.sum())
        s["act_y"] += float(y[act].sum())
        s["act_ae"] += float(np.abs(y - f)[act].sum())
        s["m_ae"] += float(np.abs(g["y"] - g["f"]).sum())
        s["m_y"] += float(g["y"].sum())

    def result(self, name: str) -> Dict[str, Optional[float]]:
        s = self.sums.get(name)
        if not s or s["n"] == 0:
            return {}
        return {"rows": int(s["n"]), "sum_actual": s["y"], "sum_forecast": s["f"],
                "wape": s["ae"] / s["y"] if s["y"] else None,
                "bias": s["f"] / s["y"] - 1 if s["y"] else None,
                "deviance": s["dev"] / s["n"],
                "active_wape": s["act_ae"] / s["act_y"] if s["act_y"] else None,
                "active_rows": int(s["act_n"]),
                "match_wape": s["m_ae"] / s["m_y"] if s["m_y"] else None}

    def names(self) -> List[str]:
        return list(self.sums)


def diebold_mariano(loss_a: Sequence[float], loss_b: Sequence[float]) -> Dict[str, Optional[float]]:
    """H0: equal expected loss. Negative statistic = A has lower loss. Newey-West lag 1."""
    a = np.asarray(loss_a, dtype="float64")
    b = np.asarray(loss_b, dtype="float64")
    ok = np.isfinite(a) & np.isfinite(b)
    d = a[ok] - b[ok]
    n = len(d)
    if n < 3:
        return {"n": n, "stat": None, "p_value": None, "mean_diff": float(d.mean()) if n else None}
    mean = d.mean()
    c0 = np.mean((d - mean) ** 2)
    c1 = np.mean((d[1:] - mean) * (d[:-1] - mean))
    var = (c0 + 2 * 0.5 * c1) / n
    if var <= 0:
        return {"n": n, "stat": None, "p_value": None, "mean_diff": float(mean)}
    stat = mean / np.sqrt(var)
    from math import erf, sqrt
    p = 1.0 - 0.5 * (1.0 + erf(abs(stat) / sqrt(2.0)))
    return {"n": n, "stat": float(stat), "p_value": float(2 * p), "mean_diff": float(mean),
            "days_a_better": int((d < 0).sum()), "days_b_better": int((d > 0).sum())}


# ------------------------------------------------------------ probability
def log_loss(p, y, w=None) -> Optional[float]:
    p = np.clip(np.asarray(p, dtype="float64"), 1e-6, 1 - 1e-6)
    y = np.asarray(y, dtype="float64")
    w = np.ones_like(y) if w is None else np.asarray(w, dtype="float64")
    ok = np.isfinite(p) & np.isfinite(y)
    if not ok.any():
        return None
    return float(-np.sum(w[ok] * (y[ok] * np.log(p[ok]) + (1 - y[ok]) * np.log(1 - p[ok]))) / np.sum(w[ok]))


def brier(p, y, w=None) -> Optional[float]:
    p = np.asarray(p, dtype="float64")
    y = np.asarray(y, dtype="float64")
    w = np.ones_like(y) if w is None else np.asarray(w, dtype="float64")
    ok = np.isfinite(p) & np.isfinite(y)
    return float(np.sum(w[ok] * (p[ok] - y[ok]) ** 2) / np.sum(w[ok])) if ok.any() else None


def calibration_bins(p, y, w=None, bins: int = 10) -> List[dict]:
    """Equal-mass bins: mean forecast vs mean outcome, with counts."""
    p = np.asarray(p, dtype="float64")
    y = np.asarray(y, dtype="float64")
    w = np.ones_like(y) if w is None else np.asarray(w, dtype="float64")
    ok = np.isfinite(p) & np.isfinite(y) & (w > 0)
    if ok.sum() < bins:
        return []
    p, y, w = p[ok], y[ok], w[ok]
    order = np.argsort(p, kind="mergesort")
    cw = np.cumsum(w[order])
    edges = np.searchsorted(cw, np.linspace(0, cw[-1], bins + 1)[1:-1])
    out = []
    for idx in np.split(order, edges):
        if len(idx) == 0:
            continue
        ww = w[idx]
        out.append({"p_mean": float(np.sum(ww * p[idx]) / ww.sum()), "y_mean": float(np.sum(ww * y[idx]) / ww.sum()),
                    "weight": float(ww.sum()), "n": int(len(idx))})
    return out


def ece(p, y, w=None, bins: int = 10) -> Optional[float]:
    b = calibration_bins(p, y, w, bins)
    if not b:
        return None
    tot = sum(x["weight"] for x in b)
    return float(sum(x["weight"] * abs(x["p_mean"] - x["y_mean"]) for x in b) / tot)


def calibration_slope(p, y, w=None) -> Dict[str, Optional[float]]:
    """Cox calibration: logit P(y) = a + b logit(p). b < 1 means over-confident."""
    from ..models.estimators import GLMEstimator
    p = np.clip(np.asarray(p, dtype="float64"), 1e-6, 1 - 1e-6)
    y = np.asarray(y, dtype="float64")
    ok = np.isfinite(p) & np.isfinite(y)
    if ok.sum() < 50:
        return {"intercept": None, "slope": None}
    X = pd.DataFrame({"lp": np.log(p[ok] / (1 - p[ok]))})
    m = GLMEstimator("binomial", ridge=1e-8).fit(X, y[ok], weight=None if w is None else np.asarray(w)[ok])
    c = m.coefficients()
    return {"intercept": c["intercept"], "slope": c["lp"]}


def probability_scores(p, y, w=None) -> Dict[str, Optional[float]]:
    p = np.asarray(p, dtype="float64")
    ok = np.isfinite(p)
    y = np.asarray(y, dtype="float64")
    w_arr = None if w is None else np.asarray(w, dtype="float64")[ok]
    out = {"rows": int(ok.sum()), "log_loss": log_loss(p[ok], y[ok], w_arr),
           "brier": brier(p[ok], y[ok], w_arr), "ece": ece(p[ok], y[ok], w_arr)}
    out.update(calibration_slope(p[ok], y[ok], w_arr))
    return out


def psi(expected: np.ndarray, actual: np.ndarray, bins: int = 10) -> Optional[float]:
    """Population stability index of ``actual`` against ``expected`` (quantile bins of expected)."""
    e = np.asarray(expected, dtype="float64")
    a = np.asarray(actual, dtype="float64")
    e, a = e[np.isfinite(e)], a[np.isfinite(a)]
    if len(e) < bins * 5 or len(a) < bins * 5:
        return None
    edges = np.unique(np.quantile(e, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    pe = np.histogram(e, edges)[0] / len(e)
    pa = np.histogram(a, edges)[0] / len(a)
    pe, pa = np.clip(pe, 1e-4, None), np.clip(pa, 1e-4, None)
    return float(np.sum((pa - pe) * np.log(pa / pe)))
