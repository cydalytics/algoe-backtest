"""
Process Pools

    process_pool(n)   a ProcessPoolExecutor of n workers that leave when the process that made it is gone

A parent killed outright (start.ps1 stops the API with Stop-Process -Force) never shuts its pool down, and
on Windows the workers then wait on their queue for ever, each holding its memory: the live engine's
in-play pool left eight idle processes behind at every such stop. Each worker starts a thread that waits on
its parent's process handle and ends the worker when the parent exits.

Change Log:
-----------
2026-10-29      Initialize
"""

import os
import threading
import time
from concurrent.futures import ProcessPoolExecutor

SYNCHRONIZE = 0x00100000
INFINITE = 0xFFFFFFFF
WAIT_OBJECT_0 = 0
ERROR_INVALID_PARAMETER = 87          # OpenProcess on a pid that is no longer running


def process_pool(max_workers: int) -> ProcessPoolExecutor:
    return ProcessPoolExecutor(max_workers=max_workers, initializer=leave_with, initargs=(os.getpid(),))


def leave_with(parent: int) -> None:
    """Pool worker initializer: end this worker when ``parent`` exits."""
    threading.Thread(target=_watch, args=(int(parent),), name="algoe-parent-watch", daemon=True).start()


def _watch(parent: int) -> None:
    if os.name == "nt":
        import ctypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.OpenProcess.restype = ctypes.c_void_p
        k32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        k32.WaitForSingleObject.restype = ctypes.c_uint32
        k32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        handle = k32.OpenProcess(SYNCHRONIZE, 0, parent)
        if not handle:
            if ctypes.get_last_error() != ERROR_INVALID_PARAMETER:
                return                    # not allowed to watch it: the worker stays, as without the watch
        elif k32.WaitForSingleObject(handle, INFINITE) != WAIT_OBJECT_0:
            return
        os._exit(0)
    while os.getppid() == parent:
        time.sleep(2.0)
    os._exit(0)
