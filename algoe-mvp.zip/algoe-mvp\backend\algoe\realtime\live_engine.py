"""
Live Engine

Keeps a TG/SUP recommendation for every active match, refreshed at two
speeds, because the desk cannot wait five minutes after a goal and the box
cannot re-solve a hundred matches every fifteen seconds.

    SWEEP (every bucket boundary, all matches; its own thread)
        fetch everything -> panel (same code as training) -> features
        -> bucket forecast F per selection (champion turnover pipeline)
        -> belief p per selection (champion calibration)
        -> optimise every match with enough expected money, richest first,
           inside a time budget, in parallel
        Every match on the panel is listed, with or without a book to solve.
    FOCUS (every ~15 s, only the matches the desk has open or a trigger fired on;
           its own thread and its own source, so a sweep never holds it up)
        fetch THAT match only -> the board as it stands now: the newest odds and
           true odds, HKJC's newest TG/SUP, the clock and the score at the refresh
           (LivePanelBuilder.build(board_at=)), not at the bucket start
        -> nowcast: remaining = rate x (5 - elapsed), rate from F and what has
           arrived (realtime/nowcast.py); the next bucket carries the surge
        -> belief from those prices
        -> re-optimise that match from its last answer (warm start, one start,
           each dimension limited to max_step from the last recommendation)
        The bucket forecast F stays the sweep's: it is the one built on the inputs
        the model was trained on.
    FAST LANE (every live.fast_seconds, every match in play or within
           live.fast_lane_minutes of kick-off; its own thread and source, publishing or not)
        one fetch and one board of the moment for all of them -> nowcast -> books ->
        every match re-solved on the engine's pool inside live.fast_budget_seconds ->
        published (inplay; refresh before kick-off). A focused match off the fast lane is
        read once when the desk opens it, then follows the sweep.

    TRIGGERS refresh a match at once and keep it on focus refreshes for
    trigger_focus_seconds: a goal, red card or corner (or its cancellation), a
    main-line price moving more than trigger_odds_move, or one minute's money
    exceeding trigger_big_bet_multiple times what the forecast expected for a minute.

    AFTER AN EVENT inside the bucket, the rest of the bucket is forecast from the
    bucket forecast shifted by the fitted EventShift (models/event_shift.py: what
    a goal / red card / corner at this clock, by this side, with this favourite and
    this score does to each bet type and side), and the nowcast's evidence is the
    money since the event, not since the bucket started. The next sweep sees the
    event in its features.

A UI heartbeat keeps a match in focus (``focus_on``); without one the focus
lapses after focus_ttl_seconds, so a forgotten tab does not cost CPU forever.
``request_focus`` is the desk opening a match: it wakes the focus thread at once.

Everything the engine publishes is also appended to the monitor's forecast
log, where the next sweep joins the money that actually arrived.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Days built with prepare_live; a price-move trigger resets after its refresh, a big-money
                trigger fires once per minute
2026-10-11      Corners and VAR cancellations trigger too; a trigger keeps its match on focus refreshes
                (it used to refresh once); the rest of the bucket after an event is re-tuned with the
                fitted event shift and nowcast from the money since the event
2026-10-26      Focus prices on the board at the refresh (board_at), not at the bucket start; a focus
                thread with its own source beside the sweep thread; request_focus; every match on the
                panel listed; header, every selection's prices and flow, the book and the trader's
                extras (quotes, incidents, price history) kept per match
2026-11-19      Every match on sale solved: outside the model window from the far pre-match curve
                (models/far_prematch.py), a block without HKJC's TG/SUP at the theta the board implies, the
                live feed's pre-match prices whatever their age; the sweep on the engine's own pool with half
                of it left free; the live money feed checked
"""

from __future__ import annotations

import heapq
import os
import threading
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..core.pool import process_pool
from ..data.panel import KEY, LivePanelBuilder
from ..features.engineer import FeatureEngineer, _kickoff_value
from ..models.event_shift import (PRIORITY, EventShift, clock_label, incident_table, main_provider, side_groups,
                                  state_label, strength_label, who_label)
from ..models.far_prematch import FarCurve, far_forecast, window_money
from ..optimizer.theta_optimizer import (DemandResponse, MatchBook, MatchDecision, ThetaOptimizer, _warm,
                                         anchor_theta, build_books, desk_weightings, publish_odds, weights_by_key)
from ..pricing.panel_pricing import state_of
from ..pricing.pricer import repair_theta
from .engine_reply import clock_check, engine_gm, join_reply, replication_gap, weight_echo
from .nowcast import BucketNowcaster
from .publisher import Candidate, create_publisher

logger = get_logger(__name__)


@dataclass
class MatchLive:
    match_id: int
    bucket: Optional[pd.Timestamp] = None
    forecast: Optional[pd.DataFrame] = None       # KEY + forecast for the current bucket (from the sweep)
    decision: Optional[MatchDecision] = None
    view: Optional[pd.DataFrame] = None           # per book selection: odds now / star, belief, demand
    refreshed_at: Optional[pd.Timestamp] = None
    mode: str = "sweep"
    triggers: List[str] = field(default_factory=list)
    last_events: tuple = ()                       # incident counts by code, the main provider's
    event: Optional[dict] = None                  # the event the rest of this bucket is re-tuned for
    last_main_odds: Dict[tuple, float] = field(default_factory=dict)
    last_big_minute: Optional[pd.Timestamp] = None
    observed: float = 0.0
    remaining: float = 0.0
    hot: float = 1.0
    money_at: Optional[pd.Timestamp] = None       # when the bucket's money (observed, remaining) was last read
    weights: Dict[tuple, float] = field(default_factory=dict)    # last stage-2 weighting per selection
    header: dict = field(default_factory=dict)    # teams, league, kick-off, phase, clock, score, corners, reds
    rows: Optional[pd.DataFrame] = None           # every selection of the bucket, in the book or not
    book: Optional[MatchBook] = None              # the last book solved: what-ifs and curves price on it
    extras: dict = field(default_factory=dict)    # focus refreshes: quotes, incidents, price history, all prices
    board_at: Optional[pd.Timestamp] = None       # when the prices, TG/SUP and score in use were read
    params_at: Optional[pd.Timestamp] = None      # the TG/SUP row in use
    requested_at: Optional[float] = None          # wall clock of the desk's last request for a refresh
    refresh_started: Optional[float] = None       # wall clock the last finished focus refresh started
    error: Optional[str] = None                   # why the last focus refresh failed, until one succeeds
    failed_at: Optional[pd.Timestamp] = None      # the last failed focus refresh: the retry waits an interval
    board_row: Optional[dict] = None              # the match as the last sweep priced it: its row on the board
    params_raw: dict = field(default_factory=dict)    # the newest algo_param row's own columns (draw factor, layers)
    first_seen: Optional[dict] = None             # HKJC's theta before Algo E's first message (anchor first_seen)
    engine: Optional[dict] = None                 # the pricing engine's last reply for the match, read against ours
    behind: bool = False                          # the last in-play cycle's budget ran out before this match
    note: Optional[str] = None                    # why a block (or the whole book) was left out at the last read

    @property
    def refreshing(self) -> bool:
        """The desk asked for a refresh that has not finished yet."""
        return self.requested_at is not None and (self.refresh_started is None
                                                  or self.refresh_started < self.requested_at)

    def summary(self) -> dict:
        d, h, rows = self.decision, self.header, self.rows
        listed = rows is not None and len(rows) > 0
        age = (self.board_at - self.params_at).total_seconds() / 60.0 \
            if self.board_at is not None and self.params_at is not None else None
        on_sale = listed and "selling" in rows.columns and bool(rows["selling"].any()) \
            and not bool(rows["forecastable"].any())
        bk = self.book
        if d is not None:
            status = d.status
        elif on_sale:
            status = "on sale"
        elif rows is not None:
            status = "no book"
        else:
            status = "pending"
        return {"match_id": self.match_id, "bucket": str(self.bucket), "mode": self.mode,
                "refreshed_at": str(self.refreshed_at), "triggers": list(self.triggers),
                "status": status, "note": self.note,
                "lift": d.lift if d else 0.0,
                "lift_bps": d.lift_bps if d else 0.0, "turnover": d.turnover if d else 0.0,
                "theta_now": d.theta_now if d else {}, "theta_star": d.theta_star if d else {},
                "observed_in_bucket": self.observed, "remaining_in_bucket": self.remaining,
                "money_at": _stamp(self.money_at), "hot": self.hot, "binding": d.binding if d else [],
                "event_in_bucket": (self.event or {}).get("labels"),
                "home": h.get("home"), "away": h.get("away"), "league": h.get("league"),
                "league_code": h.get("league_code"), "kickoff": h.get("kickoff"), "phase": h.get("phase"),
                "minute": h.get("minute"), "in_play": h.get("in_play"), "score": h.get("score"),
                "corners": h.get("corners"), "board_at": _stamp(self.board_at), "params_at": _stamp(self.params_at),
                "theta_age_min": age, "gm_now": d.egm_board if d else None, "gm_star": d.egm_star if d else None,
                "expected": float(np.nansum(rows["forecast"])) if listed else 0.0,
                "last_bucket": float(np.nansum(rows["last_bucket"])) if listed else 0.0,
                "tickets_last_bucket": float(np.nansum(rows["tickets_last_bucket"])) if listed else 0.0,
                "selections": int(len(rows)) if rows is not None else 0,
                "pools": int(rows["pool_id"].nunique()) if listed else 0,
                "open": int(rows["selling"].sum()) if listed and "selling" in rows.columns
                else int(rows["forecastable"].sum()) if listed else 0,
                "in_book": int(rows["in_book"].sum()) if listed else 0,
                "far": bool(bk.far) if bk is not None else bool(on_sale),
                "theta_source": ("implied" if bk.implied else "hkjc") if bk is not None else None,
                "refreshing": self.refreshing, "error": self.error}


class LiveEngine:
    def __init__(self, settings, source=None, forecaster=None, calibrator=None, monitor=None, clock=None,
                 focus_source=None, publisher=None):
        self.settings = settings
        self.source = source if source is not None else _default_source(settings)
        self.focus_source = focus_source if focus_source is not None else _second_source(self.source)
        publishing = settings.publish.mode != "off" or publisher is not None
        self.fast_source = _second_source(self.source)
        self.forecaster = forecaster
        self.calibrator = calibrator
        self.monitor = monitor
        self.engineer = forecaster.engineer if forecaster is not None else FeatureEngineer(settings)
        self.builder = LivePanelBuilder(settings)
        # money features are in market-index units; with no cached day to size the market, the model's own
        self.builder.market_index_fallback = (getattr(forecaster, "metadata", None) or {}).get("market_index_last")
        # The historical extraction has no HKJC true odds while the live feed does: a model trained without
        # them must see the price inputs it learned on (de-margined odds, Poisson), not new ones.
        coverage = (getattr(forecaster, "metadata", None) or {}).get("true_odds_coverage")
        if coverage is not None and np.isfinite(coverage) and coverage < 0.5:
            self.builder.ignore_true_odds = True
            logger.warning("the turnover model was trained with HKJC true odds on %.0f%% of rows; live true odds are "
                           "ignored so its inputs match. Re-extract history with true odds to use them.",
                           100 * coverage)
        # publishing moves only what the pricing engine takes; the engine derives the first half itself
        self.optimizer = ThetaOptimizer(settings, DemandResponse.from_forecaster(forecaster, settings),
                                        free_dims=settings.publish.free_dims if publishing else None)
        self.nowcaster = forecaster.nowcaster if forecaster is not None else BucketNowcaster(
            settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes,
            max_hot=settings.live.nowcast_max_hot)
        self.nowcaster.ticket_k = float(settings.live.nowcast_ticket_k)
        self.far = FarCurve.load(FarCurve.default_path(settings)) or FarCurve(
            edge_minutes=float(settings.panel.prematch_window_min), bucket_minutes=float(settings.panel.bucket_minutes))
        logger.info("far pre-match curve: %s%s", self.far.source,
                    "" if self.far.source == "fitted" else " (fit-far-prematch fits it on Raw_Data)")
        self.event_shift: Optional[EventShift] = None
        if settings.live.event_shift:
            path = EventShift.default_path(settings)
            self.event_shift = EventShift.load(path)
            if self.event_shift is None:
                logger.info("no event shift at %s: after an event the rest of the bucket follows the money arriving "
                            "only (algoe-3-backtest.bat --only events fits it)", path)
            else:
                logger.info("event shift: %d cell(s), fitted %s on %s", len(self.event_shift.cells),
                            self.event_shift.meta.get("fitted"), self.event_shift.meta.get("turnover_model"))
        self.clock = clock or (lambda: pd.Timestamp.now())
        self.matches: Dict[int, MatchLive] = {}
        self.card: set = set()                        # the matches on the last sweep's panel
        self.focus: Dict[int, float] = {}
        self._queue: List[Tuple[float, float, int, str]] = []    # (-priority, wall time asked, match, reason)
        self._lock = threading.RLock()
        self._model_lock = threading.Lock()           # one model prediction at a time across the two threads
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._focus_thread: Optional[threading.Thread] = None
        self._fast_thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.last_sweep: dict = {}
        self.last_fast: dict = {}
        self._money = {"status": "unknown", "strikes": 0, "since": None, "at": None, "read": None,
                       "expected": 0.0, "seen": 0.0, "matches": 0}
        self._behind: set = set()                     # in-play matches the last cycle's budget did not reach
        self._executor: Optional[ProcessPoolExecutor] = None
        self._pool_lock = threading.Lock()            # the sweep and the in-play threads both ask for the pool
        self.publisher, self.publish_refused = publisher, None
        if publisher is None and publishing:
            self.publisher, self.publish_refused = create_publisher(settings, self.optimizer, self._mock_lookup,
                                                                    clock=self.clock)
            if self.publisher is None:                 # refused or no transport: the desk as with publishing off
                self.optimizer = ThetaOptimizer(settings, self.optimizer.demand, free_dims=None)

    # ============================================================ interest
    def focus_on(self, match_id: int, ttl: Optional[float] = None) -> None:
        with self._lock:
            self.focus[int(match_id)] = time.time() + (ttl or self.settings.live.focus_ttl_seconds)

    def focus_off(self, match_id: int) -> None:
        with self._lock:
            self.focus.pop(int(match_id), None)

    def focused(self) -> List[int]:
        now = time.time()
        with self._lock:
            for m in [m for m, t in self.focus.items() if t < now]:
                self.focus.pop(m, None)
            return sorted(self.focus)

    def trigger(self, match_id: int, reason: str, priority: float = 1.0, focus: Optional[str] = None) -> None:
        """Refresh the match at the next focus step; ``focus`` (goal / red / corner / price / money) also keeps
        it on focus refreshes for live.trigger_focus_seconds[focus]."""
        with self._lock:
            heapq.heappush(self._queue, (-priority, time.time(), int(match_id), reason))
            live = self.matches.setdefault(int(match_id), MatchLive(int(match_id)))
            live.triggers = (live.triggers + [reason])[-5:]
            ttl = float(self.settings.live.trigger_focus_seconds.get(focus, 0.0)) if focus else 0.0
            if ttl > 0:
                self.focus[int(match_id)] = max(self.focus.get(int(match_id), 0.0), time.time() + ttl)
        self._wake.set()
        logger.info("trigger match %s: %s", match_id, reason)

    def request_focus(self, match_id: int, reason: str = "opened on the desk", ttl: Optional[float] = None) -> float:
        """The desk opened the match: keep it in focus and refresh it now. Returns the wall time of the
        request; the match reads ``refreshing`` until a refresh that started after it has finished."""
        mid, now = int(match_id), time.time()
        self.focus_on(mid, ttl)
        with self._lock:
            self.matches.setdefault(mid, MatchLive(mid)).requested_at = now
        self.trigger(mid, reason, priority=3.0)
        return now

    def models(self) -> dict:
        """What is serving: the champions, or the W06 MVP rule where there is none; and the far pre-match curve
        (fitted by fit-far-prematch, or the default)."""
        tf, pc, far = self.forecaster, self.calibrator, self.far
        metrics = {}
        for k in ("wape", "wape_last5", "buckets", "scored_on", "fit_matches", "test_matches", "holdout_days"):
            v = (far.metrics or {}).get(k)
            if isinstance(v, (int, float, np.integer, np.floating)):
                v = float(v) if np.isfinite(float(v)) else None
            metrics[k] = v
        return {"turnover": getattr(tf, "version", None), "turnover_pipeline": getattr(tf, "champion", None),
                "probability": getattr(pc, "version", None), "probability_method": getattr(pc, "champion", None),
                "fallback": [name for name, m in (("turnover: last 5 minutes", tf),
                                                  ("belief: 1 / HKJC true odds", pc)) if m is None],
                "far_curve": {"source": far.source, "fitted": far.fitted, "k": float(far.k), "metrics": metrics}}

    # =============================================================== health
    MONEY_STRIKES = 3

    def _money_check(self, read: str, expected: float, seen: float, matches: int, as_of) -> None:
        """Money the models expect against money the feed shows. MONEY_STRIKES reads in a row that expect at
        least live.money_feed_min_expected and find nothing in the current or previous bucket mean the live
        money feed is empty (a read-only replica without the in-memory money table reads as no bets at all)."""
        floor = float(self.settings.live.money_feed_min_expected)
        with self._lock:
            m = self._money
            was = m["status"]
            m.update(at=str(pd.Timestamp(as_of)), read=read, expected=float(expected), seen=float(seen),
                     matches=int(matches))
            if seen > 0:
                m.update(status="ok", strikes=0, since=None)
            elif floor > 0 and expected >= floor:
                m["strikes"] += 1
                if m["strikes"] >= self.MONEY_STRIKES:
                    if was != "empty":
                        m["since"] = str(pd.Timestamp(as_of))
                    m["status"] = "empty"
            now = m["status"]
        if now == "empty" and was != "empty":
            logger.error("live money feed empty: HK$%.0f expected over %d match(es), no money in the current or "
                         "previous bucket on %d reads in a row - run algoe-6-probe-live.bat --match <id> --intent both",
                         expected, matches, self.MONEY_STRIKES)
        elif was == "empty" and now == "ok":
            logger.info("live money feed back: HK$%.0f seen", seen)

    def health(self) -> dict:
        with self._lock:
            return {"money_feed": dict(self._money)}

    # =========================================================== publishing
    @property
    def publishing(self) -> bool:
        return self.publisher is not None and self.publisher.mode != "off"

    @property
    def fast_running(self) -> bool:
        return self._fast_thread is not None and self._fast_thread.is_alive()

    def lane(self, live: Optional["MatchLive"], as_of=None) -> str:
        """fast (in play, or kick-off within live.fast_lane_minutes) or sweep."""
        at = pd.Timestamp(as_of or self.clock())
        return "fast" if _in_fast_lane(live, at, self.settings.live.fast_lane_minutes) else "sweep"

    def _mock_lookup(self, match_id: int):
        """The mock engine's view of a match: its rows and header at the last refresh."""
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None or live.rows is None:
                return None
            header = dict(live.header)
            header["theta_now"] = dict(live.book.theta_now) if live.book is not None else None
            if not header.get("game_state"):
                header["game_state"] = live.params_raw.get("GameState")
            return live.rows, header

    def _pool(self) -> Optional[ProcessPoolExecutor]:
        """The process pool the fast lane and the sweep solve on, kept for the engine's life (a new pool costs
        seconds on Windows, more than a 15-second cycle can spare) and replaced once a worker has died: a broken
        pool refuses every task."""
        with self._pool_lock:
            broken = getattr(self._executor, "_broken", False) if self._executor is not None else False
            if broken:
                logger.error("the solver pool is broken (%s): starting a new one", broken)
                self._executor.shutdown(wait=False, cancel_futures=True)
                self._executor = None
            if self._executor is None:
                n = self.settings.optimizer.workers or min(max((os.cpu_count() or 2) - 1, 1), 8)
                if n > 1:
                    self._executor = process_pool(n)
            return self._executor

    def _sweep_in_flight(self) -> Optional[int]:
        """The sweep queues at most half the pool, so a fast-lane solve waits for one match, not a card."""
        pool = self._executor
        return max(1, int(getattr(pool, "_max_workers", 2)) // 2) if pool is not None else None

    def _book_options(self) -> dict:
        """How the live desk builds books: every match on sale, the live feed's pre-match prices whatever their
        age (optimizer.max_odds_age_live_prematch_min), a block without HKJC's TG/SUP at the board's theta."""
        return {"on_sale": True, "implied": True, "chain_weights": True,
                "prematch_max_age": float(self.settings.optimizer.max_odds_age_live_prematch_min)}

    @staticmethod
    def _far_mask(sel: pd.DataFrame) -> np.ndarray:
        """Selling pre-match rows outside the model window."""
        if sel.empty or "selling" not in sel.columns:
            return np.zeros(len(sel), dtype=bool)
        inplay = pd.to_numeric(sel["inplay"], errors="coerce").fillna(0).to_numpy() > 0 if "inplay" in sel.columns \
            else np.zeros(len(sel), dtype=bool)
        return sel["selling"].fillna(False).to_numpy(dtype=bool) & \
            ~sel["forecastable"].fillna(False).to_numpy(dtype=bool) & ~inplay

    def _far_forecast(self, day, sel_now: pd.DataFrame, far: np.ndarray, snap, current, as_of,
                      references) -> np.ndarray:
        """The far pre-match curve's next-bucket money for the far rows of ``sel_now``: each match's total
        from its last hour of money and the curve, split by the day's own money and the prior."""
        rows = sel_now[far].reset_index(drop=True)
        mids = rows["match_id"].astype("int64").unique()
        earlier = day.sel[(pd.to_datetime(day.sel["bucket"]) < pd.Timestamp(current))
                          & day.sel["match_id"].astype("int64").isin(mids)]
        if earlier.empty:
            today = np.zeros(len(rows))
            tickets: Dict[int, float] = {}
        else:
            by_key = earlier.groupby(KEY)["y"].sum()
            today = by_key.reindex(pd.MultiIndex.from_frame(rows[KEY].astype("int64"))).fillna(0.0).to_numpy()
            tk = earlier.groupby("match_id")["tickets"].sum() if "tickets" in earlier.columns else pd.Series(dtype=float)
            tickets = {int(m): float(v) for m, v in tk.items()}
        inv = self.builder._canon("investments", snap.investments)
        money = window_money(inv, mids, as_of, self.far.window_minutes)
        return far_forecast(self.far, rows, today, tickets, money, references)

    def _warm_pool(self) -> None:
        pool = self._pool()
        if pool is not None:
            n = getattr(pool, "_max_workers", 1)
            started = time.time()
            for f in [pool.submit(_warm) for _ in range(n)]:
                f.result(timeout=120)
            logger.info("in-play pool: %d worker(s) ready in %.1fs", n, time.time() - started)

    def _publish_inputs(self, raw: Dict[int, dict], match: pd.DataFrame, bucket) -> Tuple[Optional[dict], Optional[dict]]:
        """What a book needs when publishing: the match's own draw factor (the engine prices with it) and the
        centre of its trust band when that is not HKJC's posted theta (optimizer.anchor_layer)."""
        if not self.publishing:
            return None, None
        dfs = None
        if self.settings.optimizer.draw_factor:
            dfs = {m: v for m, v in ((m, _number(r.get("Goal90DrawFactor"))) for m, r in raw.items())
                   if v is not None and v > 0}
        layer = self.settings.optimizer.anchor_layer
        if layer == "current" or match is None or match.empty:
            return dfs, None
        anchors = {}
        rows = match[pd.to_datetime(match["bucket"]) == pd.Timestamp(bucket)]
        for _, r in rows.drop_duplicates("match_id").iterrows():
            m = int(r["match_id"])
            live = self.matches.get(m)
            splits = (_number(r.get("goal_split_fh")) or 0.45, _number(r.get("corner_split_fh")) or 0.47)
            a = anchor_theta(layer, None, raw.get(m), live.first_seen if live else None, state_of(r), splits)
            if a is not None:
                anchors[m] = a
        return dfs, anchors

    def _remember_first_seen(self, live: MatchLive) -> None:
        """HKJC's theta at each refresh until Algo E's first message for the match, then frozen."""
        if self.publisher is None or live.book is None:
            return
        mp = self.publisher.matches.get(live.match_id)
        if mp is None or not mp.started:
            live.first_seen = {"theta": dict(live.book.theta_now), "minute": float(live.header.get("minute") or 0.0)}

    def _publish(self, match_id: int, reason: str) -> Optional[dict]:
        """Hand the match's current decision to the publisher."""
        if not self.publishing:
            return None
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None or live.decision is None or live.book is None:
                return None
            header = dict(live.header)
            if not header.get("game_state"):
                header["game_state"] = live.params_raw.get("GameState")
            c = Candidate(match_id=int(match_id), decision=live.decision, book=live.book, rows=live.rows,
                          header=header, board_at=live.board_at,
                          draw_factor=_number(live.params_raw.get("Goal90DrawFactor")),
                          as_of=pd.Timestamp(live.refreshed_at))
        try:
            return self.publisher.consider(c, reason)
        except Exception as exc:                                         # noqa: BLE001
            logger.exception("publishing match %s failed: %s", match_id, exc)
            return {"action": "refused", "why": "{}: {}".format(type(exc).__name__, exc)}

    # ================================================================ sweep
    def run_sweep(self, as_of=None) -> dict:
        as_of = pd.Timestamp(as_of or self.clock())
        started = time.time()
        snap = self.source.fetch(as_of)
        t_fetch = time.time() - started
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            with self._lock:
                self.card = set()
            self.last_sweep = {"as_of": str(as_of), "matches": 0, "note": "no active matches"}
            return self.last_sweep
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        t_feat = time.time() - started - t_fetch
        forecast = self._forecast(day)
        belief = self._belief(day)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        sel_now = day.sel[now_rows].reset_index(drop=True)
        F, p = forecast[now_rows].copy(), belief[now_rows]
        far = self._far_mask(sel_now)
        if far.any():
            F[far] = self._far_forecast(day, sel_now, far, snap, current, as_of, extra.get("references"))
        with self._lock:
            prev = {m: l.decision.theta_star for m, l in self.matches.items() if l.decision is not None}
            wprev = {m: l.weights for m, l in self.matches.items() if l.weights}
        raw = _params_raw(snap, as_of)
        dfs, anchors = self._publish_inputs(raw, day.match, current)
        notes: Dict[int, str] = {}
        books = build_books(sel_now, day.match, F, p, self.settings, theta_prev=prev, weights_prev=wprev,
                            draw_factors=dfs, anchors=anchors, notes=notes, **self._book_options())
        t_prep = time.time() - started - t_fetch - t_feat
        pool = self._pool()
        decisions = self.optimizer.optimize_card(books, mode="sweep", executor=pool,
                                                 max_in_flight=self._sweep_in_flight())
        t_opt = time.time() - started - t_fetch - t_feat - t_prep
        fc_now = pd.DataFrame({**{k: sel_now[k].to_numpy() for k in KEY + ["match_id", "pool_name"]},
                               "forecast": F, "belief": p, "odds": sel_now["odds"].to_numpy(dtype="float64")})
        # at the bucket start the whole bucket is still to come
        rows = _rows(sel_now, F, np.zeros(len(sel_now)), F, F, p)
        info = self.builder._canon("matches", snap.match_info).drop_duplicates("match_id")
        params_at = _params_at(panel, current)
        by_book = {bk.match_id: bk for bk in books}
        mids = sel_now["match_id"].astype("int64").to_numpy()
        listed = sorted(set(mids.tolist()))
        inwin = rows["forecastable"].to_numpy(dtype=bool)
        self._money_check("sweep", float(np.nansum(F[inwin])), float(np.nansum(rows["last_bucket"].to_numpy()[inwin])),
                          len(set(mids[inwin].tolist())), as_of)
        installed = []
        lane_min = float(self.settings.live.fast_lane_minutes)
        with self._lock:
            self.card = set(listed)
            fast = self.fast_running
            for mid in listed:
                live = self.matches.setdefault(mid, MatchLive(mid))
                mine = fc_now[fc_now["match_id"] == mid].reset_index(drop=True)
                if fast and live.mode == "focus" and _in_fast_lane(live, as_of, lane_min):
                    # the fast lane prices this match every few seconds on the board of the moment: it takes the
                    # bucket's forecast, and its decision, weightings (the chain) and board row stay the fast lane's
                    live.forecast = mine
                    continue
                bk, dec = by_book.get(mid), decisions.get(mid)
                # the board ranks the whole card on this sweep's bucket; a focus read prices another horizon
                swept = MatchLive(mid, bucket=current, mode="sweep", refreshed_at=as_of, decision=dec, book=bk,
                                  rows=_with_book(rows[mids == mid].reset_index(drop=True), bk, dec),
                                  header=_header(info, day.match, mid, current), board_at=current,
                                  params_at=params_at.get(mid), remaining=float(np.nansum(F[mids == mid])),
                                  note=notes.get(mid))
                live.board_row = swept.summary()
                if live.mode == "focus" and live.refreshed_at is not None and live.refreshed_at > as_of:
                    # a focus refresh has read a newer board than this sweep: keep it, take the bucket forecast
                    live.forecast = mine
                    continue
                live.bucket, live.mode, live.refreshed_at = current, "sweep", as_of
                live.board_at, live.params_at = current, swept.params_at
                live.forecast = mine
                live.decision, live.book, live.note = dec, bk, notes.get(mid)
                live.view = _view(bk, dec) if bk is not None else None
                if bk is None:
                    live.weights = {}
                elif dec is not None:                      # a match the budget did not reach keeps its chain
                    live.weights = _weights_by_key(bk, dec)
                live.rows = swept.rows
                live.header = swept.header
                live.observed, live.remaining, live.hot = 0.0, swept.remaining, 1.0
                live.money_at = current                    # the sweep reads the bucket as it starts
                live.last_events = self._event_signature(extra["events"], mid)
                live.event = None
                live.last_main_odds = _main_odds(bk) if bk is not None else {}
                live.params_raw = raw.get(mid, live.params_raw)
                self._remember_first_seen(live)
                installed.append(mid)
        published = 0
        if self.publishing:
            # the fast lane publishes its matches on a newer board than the bucket start
            for mid in installed:
                live = self.matches[mid]
                if self.fast_running and _in_fast_lane(live, as_of, self.settings.live.fast_lane_minutes):
                    continue
                rec = self._publish(mid, "sweep")
                published += int(bool(rec) and rec.get("action") == "sent")
        if self.monitor is not None:
            # the champion's rows only: a far row's forecast is the curve's, not the model's
            self.monitor.log_forecasts(current, fc_now[~far].reset_index(drop=True),
                                       model=getattr(self.forecaster, "version", None))
        self.last_sweep = {"as_of": str(as_of), "bucket": str(current), "matches": len(books), "listed": len(listed),
                           "solved": sum(1 for d in decisions.values() if d.status.startswith("solved")),
                           "lift": float(sum(d.lift for d in decisions.values())),
                           "lift_weightings": float(sum(d.lift_stage2 for d in decisions.values())),
                           "turnover": float(sum(d.turnover for d in decisions.values())), "published": published,
                           "seconds": {"fetch": round(t_fetch, 2), "features": round(t_feat, 2),
                                       "books": round(t_prep, 2), "optimise": round(t_opt, 2),
                                       "total": round(time.time() - started, 2)}}
        logger.info("sweep %s: %d match(es), %d with a book, E[GM] lift %.0f on %.0f expected, %.1fs (%s)",
                    current.strftime("%H:%M"), len(listed), len(books), self.last_sweep["lift"],
                    self.last_sweep["turnover"], self.last_sweep["seconds"]["total"], self.last_sweep["seconds"])
        return self.last_sweep

    def _forecast(self, day) -> np.ndarray:
        if self.forecaster is None:
            return day.sel["tv1"].to_numpy(dtype="float64")
        with self._model_lock:
            return self.forecaster.predict_selection_turnover(day)["forecast"].to_numpy(dtype="float64")

    def _belief(self, day) -> np.ndarray:
        raw = day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        if self.calibrator is None:
            return raw
        with self._model_lock:
            p = self.calibrator.predict_for_day(day)
        return np.where(np.isfinite(p), p, raw)

    # ================================================================ focus
    def run_focus(self, match_id: int, as_of=None) -> Optional[MatchLive]:
        """Refresh one match on the board as it stands now: the newest prices, TG/SUP and score, the rest of
        the bucket nowcast from the money already in, re-optimised from the last answer."""
        as_of = pd.Timestamp(as_of or self.clock())
        mid = int(match_id)
        started = time.time()
        with self._lock:
            live = self.matches.setdefault(mid, MatchLive(mid))
        try:
            return self._focus(live, mid, as_of, started)
        except Exception as exc:
            with self._lock:
                # the desk's request is answered with the error; the next try waits an interval
                live.error = "{}: {}".format(type(exc).__name__, exc)
                live.refresh_started, live.failed_at = started, as_of
            raise

    def _focus(self, live: MatchLive, mid: int, as_of: pd.Timestamp, started: float) -> MatchLive:
        with self._lock:
            forecast, bucket, decision, weights = live.forecast, live.bucket, live.decision, live.weights
        snap = _only(self.focus_source.fetch(as_of, match_ids=[mid]), mid)
        current = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        events = self.builder._canon("events", snap.events)
        has_event = self.event_shift is not None and self._event_since(events, mid, current, as_of)
        # The bucket forecast is the sweep's. A match the sweep has not forecast for this bucket, or an event
        # inside it (its labels read the state at the bucket start), needs the bucket-start board as well.
        start, extra0 = None, {}
        own_forecast = forecast is None or bucket != current
        if own_forecast or has_event:
            panel0, extra0 = self.builder.build(snap, as_of)
            if not panel0.empty:
                start = self.engineer.prepare_live(panel0, extra0)
        board, bx = self.builder.build(snap, as_of, board_at=as_of)
        day = self.engineer.prepare_live(board, bx) if not board.empty else None
        edge = bx["current_bucket"]
        now_rows = (day.sel["bucket"] == edge).to_numpy() if day is not None and not day.empty else None
        sel_now = day.sel[now_rows].reset_index(drop=True) if now_rows is not None else pd.DataFrame()
        if sel_now.empty:
            with self._lock:
                live.refresh_started, live.failed_at = started, as_of
                live.error = "no priced selection on the board at {:%H:%M:%S}".format(as_of)
            return live
        if own_forecast and start is not None:
            s_rows = (start.sel["bucket"] == current).to_numpy()
            s_sel = start.sel[s_rows].reset_index(drop=True)
            f0 = self._forecast(start)[s_rows].copy()
            far0 = self._far_mask(s_sel)
            if far0.any():
                f0[far0] = self._far_forecast(start, s_sel, far0, snap, current, as_of, extra0.get("references"))
            mine = s_sel[KEY + ["match_id", "pool_name"]].assign(forecast=f0)
        elif own_forecast:
            mine = None
        else:
            mine = forecast
        F = sel_now[KEY].merge(mine[KEY + ["forecast"]], on=KEY, how="left")["forecast"].fillna(0.0) \
            .to_numpy(dtype="float64") if mine is not None else np.zeros(len(sel_now))
        lag = self.settings.live.data_lag_seconds
        observed = _observed(snap.investments, sel_now, current, as_of)
        tickets = _observed(snap.investments, sel_now, current, as_of, column="ticket_count")
        elapsed = max((as_of - current).total_seconds() - lag, 0.0) / 60.0
        ev = self._event_in_bucket(events, start.match, mid, current, as_of) \
            if has_event and start is not None else None
        if ev is not None:
            # the rest of the bucket comes after the event: its forecast shifted for it, and the evidence is the
            # money since the event (the feed floors a bet to its minute)
            groups = side_groups(sel_now["family"].to_numpy(dtype=object), sel_now["side"].to_numpy(dtype=object),
                                 np.nan_to_num(pd.to_numeric(sel_now.get("fav_sign", 0.0), errors="coerce")))
            F_post = F * self.event_shift.multipliers(groups, ev["labels"])
            since = pd.Timestamp(ev["time"]).floor("min")
            x_post = _observed(snap.investments, sel_now, since, as_of)
            k_post = _observed(snap.investments, sel_now, since, as_of, column="ticket_count")
            e_post = max((as_of - since).total_seconds() - lag, 0.0) / 60.0
            nc = self.nowcaster.update(F_post, x_post, e_post, match_key=sel_now["match_id"].to_numpy(),
                                       next_forecast=F_post,
                                       left=max(self.settings.panel.bucket_minutes - elapsed, 0.0), tickets=k_post)
        else:
            nc = self.nowcaster.update(F, observed, elapsed, match_key=sel_now["match_id"].to_numpy(), next_forecast=F,
                                       tickets=tickets)
        horizon = nc.remaining + nc.next_bucket
        belief = self._belief(day)[now_rows]
        prev = {mid: decision.theta_star} if decision is not None else None
        raw = _params_raw(snap, as_of)
        dfs, anchors = self._publish_inputs(raw, day.match, edge)
        notes: Dict[int, str] = {}
        books = build_books(sel_now, day.match, horizon, belief, self.settings, theta_prev=prev,
                            weights_prev={mid: weights} if weights else None, draw_factors=dfs, anchors=anchors,
                            received=observed, notes=notes, **self._book_options())
        bk = books[0] if books else None
        dec = self.optimizer.optimize_match(bk, mode="focus") if bk is not None else None
        rows = _with_book(_rows(sel_now, F, observed, nc.remaining, nc.next_bucket, belief), bk, dec)
        info = self.builder._canon("matches", snap.match_info).drop_duplicates("match_id")
        shift = bx.get("board_shift", pd.Timedelta(0))
        p_at = _params_at(board, edge).get(mid)
        extras = _extras(self.builder, snap, mid, as_of)
        with self._lock:
            if live.refreshed_at is not None and live.refreshed_at > as_of:
                # a sweep that read a newer board landed while this refresh ran: it stays
                live.refresh_started, live.error = started, None
                logger.info("focus %s @%s: a newer board (%s) landed meanwhile; not published", mid,
                            as_of.strftime("%H:%M:%S"), live.refreshed_at)
                return live
            live.bucket, live.mode, live.refreshed_at = current, "focus", as_of
            live.board_at, live.params_at = bx.get("board_at", as_of), (p_at - shift) if p_at is not None else None
            if own_forecast and mine is not None:
                live.forecast = mine
            live.decision, live.book, live.note = dec, bk, notes.get(mid)
            live.view = _view(bk, dec).assign(bucket=current) if bk is not None else None
            live.weights = _weights_by_key(bk, dec) if bk is not None else {}
            live.rows = rows
            live.header = _header(info, day.match, mid, edge)
            live.extras = extras
            live.observed = float(observed.sum())
            live.remaining = float(nc.remaining.sum())
            live.money_at = as_of
            live.hot = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
            # the board this refresh priced on is the reference the next price-move trigger reads against
            live.last_main_odds = _main_odds(bk) if bk is not None else {}
            live.last_events = self._event_signature(events, mid)
            live.event = ev
            live.refresh_started = started
            live.error, live.failed_at = None, None
            live.params_raw = raw.get(mid, live.params_raw)
            self._remember_first_seen(live)
        logger.info("focus %s @%s: observed %.0f, remaining %.0f (hot x%.2f)%s, lift %.1f, %s in %.2fs",
                    mid, as_of.strftime("%H:%M:%S"), live.observed, live.remaining, live.hot,
                    "" if ev is None else ", re-tuned for {} {} {} ({})".format(
                        ev["labels"]["event"], ev["labels"]["who"], ev["labels"]["clock"], ev["labels"]["state"]),
                    dec.lift if dec is not None else 0.0, dec.status if dec is not None else "no book",
                    time.time() - started)
        if live.header.get("in_play"):
            # a goal, a red card or the desk opening an in-play match: published now (pre-match: sweep only)
            self._publish(mid, "focus")
        return live

    # ============================================================ fast lane
    def run_fast_cycle(self, as_of=None) -> dict:
        """Every match in the fast lane - in play, or within live.fast_lane_minutes of kick-off - in one pass, on
        the board as it stands now, and each published (``inplay`` in play, ``refresh`` before kick-off).

        One fetch, one board of the moment, one feature pass; the bucket forecast is the sweep's (or this
        read's bucket start where the sweep has none), nowcast to the money already in and shifted after an
        event like a focus refresh; one belief pass, the books, then every match solved from its last answer
        on the engine's own process pool inside live.fast_budget_seconds, the matches the last cycle did not
        reach first. A match the budget does not reach keeps its last answer and is marked behind."""
        as_of = pd.Timestamp(as_of or self.clock())
        started = time.time()
        minutes = self.settings.panel.bucket_minutes
        current = as_of.floor("{}min".format(minutes))
        out = {"as_of": str(as_of), "matches": 0, "in_play": 0, "prematch": 0, "books": 0, "solved": 0,
               "behind": [], "published": 0}
        lane_min = float(self.settings.live.fast_lane_minutes)
        with self._lock:
            mids = sorted(m for m in self.card if _in_fast_lane(self.matches.get(m), as_of, lane_min))
        if not mids:
            self.last_fast = out
            return out
        snap = (self.fast_source or self.focus_source).fetch(as_of, match_ids=mids)
        t_fetch = time.time() - started
        board, bx = self.builder.build(snap, as_of, board_at=as_of)
        day = self.engineer.prepare_live(board, bx) if not board.empty else None
        if day is None or day.empty:
            self.last_fast = dict(out, note="no priced selection on the board")
            return self.last_fast
        edge = bx["current_bucket"]
        now_rows = (day.sel["bucket"] == edge).to_numpy()
        m_now = day.match[pd.to_datetime(day.match["bucket"]) == pd.Timestamp(edge)]
        live_ids = pd.to_numeric(m_now["match_id"], errors="coerce")
        on = pd.to_numeric(m_now["inplay"], errors="coerce").fillna(0) > 0 if "inplay" in m_now.columns else \
            m_now["phase"].astype(str).ne("prematch")
        in_play = set(live_ids[on].dropna().astype(int).tolist())
        playing = sorted(set(live_ids.dropna().astype(int).tolist()) & set(mids))
        keep = day.sel.loc[now_rows, "match_id"].astype("int64").isin(playing).to_numpy()
        sel_now = day.sel[now_rows][keep].reset_index(drop=True)
        belief = self._belief(day)[now_rows][keep]
        events = self.builder._canon("events", snap.events)
        t_feat = time.time() - started - t_fetch
        with self._lock:
            lives = {m: self.matches.setdefault(m, MatchLive(m)) for m in playing}
            have = {m: l.forecast for m, l in lives.items() if l.forecast is not None and l.bucket == current}
            prev = {m: l.decision.theta_star for m, l in lives.items() if l.decision is not None}
            wprev = {m: l.weights for m, l in lives.items() if l.weights}
        evented = [m for m in playing if self.event_shift is not None and self._event_since(events, m, current, as_of)]
        missing = [m for m in playing if m not in have]
        start = None
        if missing or evented:
            panel0, extra0 = self.builder.build(snap, as_of)
            if not panel0.empty:
                start = self.engineer.prepare_live(panel0, extra0)
        own: Dict[int, pd.DataFrame] = {}
        if start is not None and missing:
            s_rows = (start.sel["bucket"] == current).to_numpy()
            f0 = start.sel.loc[s_rows, KEY + ["match_id", "pool_name"]].reset_index(drop=True) \
                .assign(forecast=self._forecast(start)[s_rows])
            for m in missing:
                own[m] = f0[f0["match_id"].astype("int64") == m].reset_index(drop=True)
        frames = [f[KEY + ["forecast"]] for f in list(have.values()) + list(own.values()) if f is not None and len(f)]
        fc = pd.concat(frames, ignore_index=True).drop_duplicates(KEY) if frames else \
            pd.DataFrame({k: pd.Series(dtype="int64") for k in KEY}).assign(forecast=pd.Series(dtype="float64"))
        F = sel_now[KEY].merge(fc, on=KEY, how="left")["forecast"].fillna(0.0).to_numpy(dtype="float64")
        lag = self.settings.live.data_lag_seconds
        observed = _observed(snap.investments, sel_now, current, as_of)
        tickets = _observed(snap.investments, sel_now, current, as_of, column="ticket_count")
        elapsed = max((as_of - current).total_seconds() - lag, 0.0) / 60.0
        row_mid = sel_now["match_id"].astype("int64").to_numpy()
        remaining, nxt, hot = np.zeros(len(sel_now)), np.zeros(len(sel_now)), {}
        evs = {}
        for m in evented:
            ev = self._event_in_bucket(events, start.match, m, current, as_of) if start is not None else None
            if ev is not None:
                evs[m] = ev
        plain = ~np.isin(row_mid, list(evs))
        if plain.any():
            nc = self.nowcaster.update(F[plain], observed[plain], elapsed, match_key=row_mid[plain],
                                       next_forecast=F[plain], tickets=tickets[plain])
            remaining[plain], nxt[plain] = nc.remaining, nc.next_bucket
            for m in set(row_mid[plain].tolist()):
                h = np.asarray(nc.match_hot)[row_mid[plain] == m] if len(nc.match_hot) == plain.sum() else []
                hot[m] = float(np.nanmedian(h)) if len(h) else 1.0
        for m, ev in evs.items():
            r = row_mid == m
            sub = sel_now[r].reset_index(drop=True)
            groups = side_groups(sub["family"].to_numpy(dtype=object), sub["side"].to_numpy(dtype=object),
                                 np.nan_to_num(pd.to_numeric(sub.get("fav_sign", 0.0), errors="coerce")))
            F_post = F[r] * self.event_shift.multipliers(groups, ev["labels"])
            since = pd.Timestamp(ev["time"]).floor("min")
            x_post = _observed(snap.investments, sub, since, as_of)
            k_post = _observed(snap.investments, sub, since, as_of, column="ticket_count")
            e_post = max((as_of - since).total_seconds() - lag, 0.0) / 60.0
            nc = self.nowcaster.update(F_post, x_post, e_post, match_key=row_mid[r], next_forecast=F_post,
                                       left=max(minutes - elapsed, 0.0), tickets=k_post)
            remaining[r], nxt[r] = nc.remaining, nc.next_bucket
            hot[m] = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
        raw = _params_raw(snap, as_of)
        dfs, anchors = self._publish_inputs(raw, day.match, edge)
        notes: Dict[int, str] = {}
        books = build_books(sel_now, day.match, remaining + nxt, belief, self.settings, theta_prev=prev,
                            weights_prev=wprev, draw_factors=dfs, anchors=anchors, received=observed, notes=notes,
                            **self._book_options())
        by_book = {bk.match_id: bk for bk in books}
        t_prep = time.time() - started - t_fetch - t_feat
        decisions = self.optimizer.optimize_card(books, mode="focus",
                                                 budget_seconds=self.settings.live.fast_budget_seconds,
                                                 executor=self._pool(), first=self._behind)
        t_opt = time.time() - started - t_fetch - t_feat - t_prep
        behind = sorted(set(by_book) - set(decisions))
        self._behind = set(behind)
        rows = _rows(sel_now, F, observed, remaining, nxt, belief)
        self._money_check("fast lane", float(np.nansum(F)),
                          float(np.nansum(observed) + np.nansum(rows["last_bucket"].to_numpy())), len(playing), as_of)
        info = self.builder._canon("matches", snap.match_info).drop_duplicates("match_id")
        shift = bx.get("board_shift", pd.Timedelta(0))
        p_at = _params_at(board, edge)
        open_now = set(self.focused())
        installed = []
        for m in playing:
            bk, dec = by_book.get(m), decisions.get(m)
            r = row_mid == m
            if bk is not None and dec is None:
                with self._lock:
                    lives[m].behind = True                # not reached: its last answer stays up, marked
                continue
            # quotes, incidents and price history are the cockpit's: only for matches the desk has open
            extras = _extras(self.builder, snap, m, as_of) if m in open_now else None
            mrows = _with_book(rows[r].reset_index(drop=True), bk, dec)
            with self._lock:
                live = lives[m]
                if live.refreshed_at is not None and live.refreshed_at > as_of:
                    continue                              # a newer board landed while this cycle ran
                live.bucket, live.mode, live.refreshed_at = current, "focus", as_of
                live.board_at = bx.get("board_at", as_of)
                live.params_at = (p_at[m] - shift) if m in p_at else None
                if m in own:
                    live.forecast = own[m]
                live.decision, live.book, live.note = dec, bk, notes.get(m)
                live.view = _view(bk, dec).assign(bucket=current) if bk is not None else None
                live.weights = _weights_by_key(bk, dec) if bk is not None else {}
                live.rows = mrows
                live.header = _header(info, day.match, m, edge)
                if extras is not None:
                    live.extras = extras
                live.observed, live.remaining = float(observed[r].sum()), float(remaining[r].sum())
                live.money_at = as_of
                live.hot = hot.get(m, 1.0)
                live.last_main_odds = _main_odds(bk) if bk is not None else {}
                live.last_events = self._event_signature(events, m)
                live.event = evs.get(m)
                live.refresh_started = started
                live.error, live.failed_at, live.behind = None, None, False
                live.params_raw = raw.get(m, live.params_raw)
                self._remember_first_seen(live)
                # the board shows a fast-lane match as this cycle priced it, not as the bucket's sweep did
                live.board_row = live.summary()
            installed.append(m)
        t_install = time.time() - started - t_fetch - t_feat - t_prep - t_opt
        published = 0
        for m in installed:
            rec = self._publish(m, "inplay" if m in in_play else "refresh")
            published += int(bool(rec) and rec.get("action") == "sent")
        total = time.time() - started
        self.last_fast = {**out, "bucket": str(current), "matches": len(playing),
                          "in_play": len(in_play & set(playing)), "prematch": len(set(playing) - in_play),
                          "books": len(books), "solved": len(decisions), "behind": behind, "published": published,
                          "seconds": {"fetch": round(t_fetch, 2), "features": round(t_feat, 2),
                                      "books": round(t_prep, 2), "optimise": round(t_opt, 2),
                                      "install": round(t_install, 2),
                                      "publish": round(total - t_fetch - t_feat - t_prep - t_opt - t_install, 2),
                                      "total": round(total, 2)}}
        logger.info("fast lane %s: %d match(es) (%d in play), %d book(s), %d solved, %d behind, %d published, %.1fs "
                    "(%s)", as_of.strftime("%H:%M:%S"), len(playing), self.last_fast["in_play"], len(books),
                    len(decisions), len(behind), published, total, self.last_fast["seconds"])
        return self.last_fast

    # ============================================================ triggers
    def check_triggers(self, as_of=None) -> List[Tuple[int, str]]:
        """Cheap scan of the whole card for events, price jumps and big bets since the last look."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        snap = self.source.fetch(as_of)
        fired = []
        ev = self.builder._canon("events", snap.events)
        odds = self.builder._canon("odds", snap.odds)
        inv = self.builder._canon("investments", snap.investments)
        for mid, live in list(self.matches.items()):
            sig = self._event_signature(ev, mid)
            if sig and sig != live.last_events:
                kind, what = self._newest_incident(ev, mid)
                fired.append((mid, what, kind))
                live.last_events = sig                      # one trigger per change, not one per scan
            if live.last_main_odds and not odds.empty:
                o = odds[odds["match_id"] == mid].sort_values("effective_datetime").groupby(
                    ["pool_id", "line_id", "combination_id"]).last()["odds"]
                for k, v0 in live.last_main_odds.items():
                    v1 = o.get(k)
                    if v1 is not None and v0 > 0 and abs(v1 / v0 - 1.0) > lv.trigger_odds_move:
                        fired.append((mid, "main-line price moved {:+.0%}".format(v1 / v0 - 1.0), "price"))
                        break
            since = as_of.floor("min") - pd.Timedelta(minutes=1)
            if live.forecast is not None and not inv.empty and live.last_big_minute != since:
                minute = inv[(inv["match_id"] == mid) & (inv["start_sell_time"] >= since)]
                per_min = float(live.forecast["forecast"].sum()) / self.settings.panel.bucket_minutes
                if per_min > 0 and float(minute["turnover"].sum()) > lv.trigger_big_bet_multiple * per_min:
                    live.last_big_minute = since
                    fired.append((mid, "big money: {:.0f} in a minute vs {:.0f} expected".format(
                        float(minute["turnover"].sum()), per_min), "money"))
        for mid, reason, key in fired:
            self.trigger(mid, reason, priority=2.0, focus=key)
        current = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        self._scan_money(snap, current, as_of)
        with self._lock:
            reads = [lv_.rows for m, lv_ in self.matches.items()
                     if m in self.card and lv_.rows is not None and lv_.bucket == current
                     and "forecastable" in lv_.rows.columns]
        # the models' rows only, as the sweep counts them: a far match's curve forecast says nothing of the feed
        expected, window = 0.0, set()
        for r in reads:
            f = r["forecastable"].fillna(False).to_numpy(dtype=bool)
            if f.any():
                expected += float(np.nansum(r["forecast"].to_numpy(dtype="float64")[f]))
                window |= set(pd.to_numeric(r["match_id"], errors="coerce")[f].dropna().astype("int64").tolist())
        recent = inv[inv["match_id"].isin(window)
                     & (inv["start_sell_time"] >= current - pd.Timedelta(minutes=self.settings.panel.bucket_minutes))] \
            if not inv.empty else inv
        self._money_check("scan", expected, float(recent["turnover"].sum()) if not recent.empty else 0.0,
                          len(window), as_of)
        return [(mid, reason) for mid, reason, _ in fired]

    def _scan_money(self, snap, current, as_of) -> int:
        """The money already in this bucket for every match off the fast lane, from the scan's read: received and
        the nowcast rest move with it, the decision stays the sweep's. Returns how many matches it moved."""
        lane_min = float(self.settings.live.fast_lane_minutes)
        elapsed = max((pd.Timestamp(as_of) - pd.Timestamp(current)).total_seconds()
                      - self.settings.live.data_lag_seconds, 0.0) / 60.0
        with self._lock:
            todo = [(m, lv_.rows) for m, lv_ in self.matches.items()
                    if m in self.card and lv_.rows is not None and len(lv_.rows) and lv_.bucket == current
                    and not _in_fast_lane(lv_, as_of, lane_min)]
        moved = 0
        for mid, rows in todo:
            x = _observed(snap.investments, rows, current, as_of)
            k = _observed(snap.investments, rows, current, as_of, column="ticket_count")
            F = np.nan_to_num(rows["forecast"].to_numpy(dtype="float64"))
            nc = self.nowcaster.update(F, x, elapsed, match_key=rows["match_id"].to_numpy(), next_forecast=F, tickets=k)
            new = rows.assign(observed=x, remaining=nc.remaining, next_bucket=nc.next_bucket)
            with self._lock:
                live = self.matches.get(mid)
                if live is None or live.rows is not rows:
                    continue                                  # a refresh landed meanwhile: its read is newer
                live.rows = new
                live.observed, live.remaining = float(x.sum()), float(nc.remaining.sum())
                live.hot = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
                live.money_at = pd.Timestamp(as_of)
                if live.board_row is not None:
                    live.board_row.update(observed_in_bucket=live.observed, remaining_in_bucket=live.remaining,
                                          money_at=_stamp(live.money_at), hot=live.hot)
            moved += 1
        return moved

    # ============================================================ events
    def _event_kinds(self) -> List[str]:
        return [k for k in PRIORITY if k in self.settings.live.trigger_events]

    def _event_signature(self, events: Optional[pd.DataFrame], mid: int) -> tuple:
        """The match's incident counts by code (events and their cancellations), from its main provider:
        any change - a goal, a corner, a VAR cancellation - is a new state of the match."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return ()
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds)]
        if inc.empty:
            return ()
        return tuple(int(((inc["kind"] == k) & (inc["sign"] == s)).sum()) for k in kinds for s in (1.0, -1.0))

    def _newest_incident(self, events: pd.DataFrame, mid: int) -> Tuple[str, str]:
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(self._event_kinds())]
        if inc.empty:
            return "goal", "event"
        last = inc.iloc[-1]
        name = {"goal": "goal", "red": "red card", "corner": "corner"}[last["kind"]]
        return str(last["kind"]), name if last["sign"] > 0 else name + " cancelled"

    def _event_since(self, events: Optional[pd.DataFrame], mid: int, current, as_of) -> bool:
        """Any goal, red card or corner (or a cancellation) of the match's main provider in [current, as_of]."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return False
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds) & (inc["t"] >= pd.Timestamp(current)) & (inc["t"] <= pd.Timestamp(as_of))]
        return not inc.empty

    def _event_in_bucket(self, events: Optional[pd.DataFrame], match: pd.DataFrame, mid: int, current,
                         as_of) -> Optional[dict]:
        """The goal / red card / corner since the bucket started (the rarest kind there is, net of
        cancellations), with the labels the event shift is kept by; None without one."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return None
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds) & (inc["t"] >= pd.Timestamp(current)) & (inc["t"] <= pd.Timestamp(as_of))]
        if inc.empty:
            return None
        net = inc.groupby("kind")["sign"].sum()
        kind = next((k for k in PRIORITY if net.get(k, 0.0) > 0), None)
        if kind is None:
            return None
        last = inc[(inc["kind"] == kind) & (inc["sign"] > 0)].iloc[-1]
        m = match[pd.to_numeric(match["match_id"], errors="coerce") == mid].sort_values("bucket").reset_index(drop=True)
        if m.empty:
            return None
        sup_ko = _kickoff_value(m, "sup") if "sup" in m.columns else np.full(len(m), np.nan)
        at = m.index[pd.to_datetime(m["bucket"]) <= pd.Timestamp(current)]
        i = int(at[-1]) if len(at) else len(m) - 1
        row = m.iloc[i]
        sgn = float(np.nan_to_num(pd.to_numeric(row.get("fav_sign", 0.0), errors="coerce")))
        goals = inc[(inc["kind"] == "goal")]
        hg = float(np.nan_to_num(pd.to_numeric(row.get("home_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 1, "sign"].sum())
        ag = float(np.nan_to_num(pd.to_numeric(row.get("away_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 2, "sign"].sum())
        minute = float(np.nan_to_num(pd.to_numeric(row.get("minute", 0.0), errors="coerce"))) + \
            (pd.Timestamp(last["t"]) - pd.Timestamp(current)).total_seconds() / 60.0
        labels = {"event": kind, "clock": clock_label([minute])[0],
                  "who": who_label([sgn], [last["side"] == 1], [last["side"] == 2])[0],
                  "strength": strength_label([sgn], [sup_ko[i]])[0], "state": state_label([sgn], [hg], [ag])[0]}
        return {"kind": kind, "time": pd.Timestamp(last["t"]), "side": last["side"], "labels": labels}

    # ================================================================ loop
    def _sweep_step(self, as_of=None) -> Optional[dict]:
        as_of = pd.Timestamp(as_of or self.clock())
        bucket = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        if not self.last_sweep or self.last_sweep.get("bucket") != str(bucket):
            return self.run_sweep(as_of)
        return None

    def _focus_step(self, as_of=None) -> List[int]:
        """Refresh what is due one match at a time, choosing again after each: a match the desk opens while
        others are refreshing waits for one refresh, not for all of them."""
        done: List[int] = []
        while len(done) < self.settings.live.max_focus_matches:
            at = pd.Timestamp(as_of or self.clock())
            mid = self._next_due(at, done)
            if mid is None:
                break
            done.append(mid)
            try:
                # the board is read now, after the choice: a request that came in meanwhile is covered
                self.run_focus(mid, as_of)
            except Exception as exc:                                   # noqa: BLE001
                logger.exception("focus refresh of match %s failed: %s", mid, exc)
        return done

    def _next_due(self, as_of: pd.Timestamp, done: List[int]) -> Optional[int]:
        """The desk's requests and triggers first, first come first served within a priority (a request a
        refresh has since covered is dropped), then the focused fast-lane match whose last refresh or failed try
        is the oldest past the interval. Off the fast lane a match is read once when asked (and again after a
        failed read); after that it follows the sweep."""
        lane_min = float(self.settings.live.fast_lane_minutes)
        with self._lock:
            while self._queue:
                _, pushed, mid, _ = heapq.heappop(self._queue)
                live = self.matches.get(mid)
                if live is not None and live.refresh_started is not None and live.refresh_started >= pushed:
                    continue
                return mid
            pick, oldest = None, None
            cycling = self.fast_running
            for mid in self.focused():
                if mid in done:
                    continue
                live = self.matches.get(mid)
                fast = _in_fast_lane(live, as_of, lane_min)
                if cycling and fast:
                    continue                              # the fast lane refreshes it every few seconds
                last = live.refreshed_at if live else None
                if live is not None and live.failed_at is not None and (last is None or live.failed_at > last):
                    last = live.failed_at
                if last is None:
                    return mid
                if not fast and (live is None or live.error is None):
                    continue
                age = (as_of - last).total_seconds()
                if age >= self.settings.live.focus_interval_seconds and (oldest is None or age > oldest):
                    pick, oldest = mid, age
            return pick

    def step(self, as_of=None) -> dict:
        """One scheduler tick on one thread: sweep at a new bucket, then the focus refreshes that are due."""
        as_of = pd.Timestamp(as_of or self.clock())
        return {"sweep": self._sweep_step(as_of), "focus": self._focus_step(as_of)}

    def start(self, poll_seconds: float = 1.0) -> None:
        """The sweep (and the trigger scan) on one thread, focus refreshes on another, so a sweep that takes
        minutes on a full card never holds up the match a trader has just opened."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def sweep_loop():
            logger.info("live engine started (source %s)", type(self.source).__name__)
            last_scan = 0.0
            while not self._stop.is_set():
                try:
                    if time.time() - last_scan > self.settings.live.focus_interval_seconds:
                        self.check_triggers()
                        last_scan = time.time()
                    self._sweep_step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live sweep step failed: %s", exc)
                self._stop.wait(poll_seconds)
            logger.info("live engine stopped")

        def focus_loop():
            while not self._stop.is_set():
                try:
                    self._focus_step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live focus step failed: %s", exc)
                self._wake.wait(poll_seconds)
                self._wake.clear()

        def fast_loop():
            try:
                self._warm_pool()
            except Exception as exc:                                    # noqa: BLE001
                logger.warning("the solver pool did not warm up: %s", exc)
            while not self._stop.is_set():
                began = time.time()
                try:
                    if self.last_sweep:                                 # the card is the sweep's
                        self.run_fast_cycle()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("fast lane failed: %s", exc)
                self._stop.wait(max(self.settings.live.fast_seconds - (time.time() - began), 0.5))

        self._thread = threading.Thread(target=sweep_loop, name="algoe-live", daemon=True)
        self._focus_thread = threading.Thread(target=focus_loop, name="algoe-focus", daemon=True)
        self._fast_thread = threading.Thread(target=fast_loop, name="algoe-fast", daemon=True)
        self._thread.start()
        self._focus_thread.start()
        self._fast_thread.start()
        if self.publishing:
            self.publisher.start(self.on_engine_prices)

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        for t in (self._thread, self._focus_thread, self._fast_thread):
            if t:
                t.join(timeout=10)
        if self.publisher is not None:
            self.publisher.shutdown()
        with self._pool_lock:
            if self._executor is not None:
                self._executor.shutdown(wait=False, cancel_futures=True)
                self._executor = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ============================================================== replies
    def on_engine_prices(self, reply, info: dict) -> None:
        """The pricing engine's reply for a match, read against our book: its prices on our rows, E[GM] on
        them, the replication gap, the echo of our weights, its clock and state. theta* the engine prices
        worse for us than the board reverts the match to HKJC's theta for publish.revert_minutes. In live
        mode the board moves to the engine's prices, so they become the price-move trigger's reference."""
        mid = int(reply.event_id)
        p = self.settings.publish
        sent = info.get("sent") or {}
        with self._lock:
            live = self.matches.get(mid)
            if live is None:
                return
            bk, rows, header, dec = live.book, live.rows, dict(live.header), live.decision
        if sent.get("book") is not None:               # read against what the message was decided on
            bk, rows, header, dec = sent["book"], sent["rows"], dict(sent["header"]), sent["decision"]
        frame = reply.frame()
        mapping = self.publisher.mapping if self.publisher is not None else None
        joined, stats = join_reply(frame, rows) if rows is not None and len(rows) else (None, {})
        gm = engine_gm(bk, joined, self.optimizer) if bk is not None else None
        gap = replication_gap(bk, joined, sent, header, self.optimizer, mapping, alert=p.gap_alert) \
            if bk is not None and sent else None
        if gap is not None and joined is not None:
            joined = joined.merge(gap.pop("by_row"), on=KEY, how="left")
        echo = weight_echo(frame, sent.get("weights") or {}) if info.get("ours") else []
        notes = clock_check(reply, header, p.clock_tolerance_seconds)
        if not info.get("ours"):
            notes.append("not ours: the engine answered with no message of ours waiting")
        if echo:
            notes.append("mapping: {} weight(s) did not come back".format(len(echo)))
        if gap and gap["alert"]:
            notes.append("replication gap {:.3f} on {}".format(gap["max"], gap["worst_pool"]))
        # only a message that carried theta* can be worse than HKJC's own theta, and what reverting sends is HKJC's
        # theta at the engine's precision: that is the board to beat, not the trader's exact one
        base = sent.get("egm_board", dec.egm_board if dec is not None else None)
        tol = max(float(p.revert_tolerance), float(p.revert_tolerance_bps) * 1e-4 * float(dec.turnover)
                  if dec is not None else 0.0)
        revert = bool(p.revert_guard and info.get("ours") and not info.get("late") and sent.get("chosen") == "theta*"
                      and gm is not None and base is not None and gm < base - tol)
        moved = {k for k, w in (sent.get("weights") or {}).items() if abs(w - 1.0) > 1e-9}
        proof = None if not info.get("ours") else (
            "weights missing" if echo else "weights came back" if moved else "no weights sent: matched by timing only")
        if revert:
            why = "E[GM] {:.0f} on the engine's prices < {:.0f} with HKJC's theta".format(gm, base)
            notes.append("revert: " + why)
            if self.publisher is not None:
                self.publisher.flag_revert(mid, p.revert_minutes, why)
        with self._lock:
            live.engine = {"at": info.get("at"), "ours": info.get("ours"), "msg_id": info.get("msg_id"),
                           "target": info.get("target"), "latency": info.get("latency"),
                           "server": reply.server_app_id, "event_time": reply.event_time,
                           "game_state": reply.game_state, "clock_seconds": reply.clock_seconds,
                           "rows": frame, "joined": joined, "join": stats, "gm_engine": gm,
                           "gm_board": dec.egm_board if dec is not None else None,
                           "gm_star": dec.egm_star if dec is not None else None,
                           "gap": gap, "echo": echo, "notes": notes, "revert": revert, "proof": proof}
            if (self.publisher is not None and self.publisher.mode == "live" and info.get("ours")
                    and not info.get("late") and info.get("target") == "production" and sent.get("what") == "star"
                    and live.last_main_odds):
                f = frame.set_index(KEY)
                for k in list(live.last_main_odds):
                    if k in f.index and bool(f.loc[k, "offered"]):
                        live.last_main_odds[k] = float(f.loc[k, "sell_odds"])
        if self.publisher is not None:
            self.publisher.record_feedback(mid, {
                "msg_id": info.get("msg_id"), "target": info.get("target"), "ours": bool(info.get("ours")),
                "late": bool(info.get("late")), "gm_engine": gm, "gm_board_sent": base, "revert": revert, "proof": proof,
                "gap_max": gap["max"] if gap else None, "gap_mean": gap["mean"] if gap else None,
                "gap_worst_pool": gap["worst_pool"] if gap else None, "echo": len(echo), "notes": notes})
        if notes:
            logger.info("engine reply for match %s: %s", mid, "; ".join(notes))

    # ================================================================ read
    def board(self) -> dict:
        """The last sweep's card, each match as that sweep priced it (the cockpit carries the newer focus
        reads), with whether a refresh is asked for, failed or triggered. A match a desk opened that no
        sweep has priced yet shows its own read."""
        focused = self.focused()
        now = pd.Timestamp(self.clock())
        with self._lock:
            rows = []
            for m in self.matches.values():
                if m.match_id in self.card and m.board_row is not None:
                    r = dict(m.board_row)
                elif m.board_row is None and m.match_id in focused:
                    r = m.summary()
                else:
                    continue
                r.update(refreshing=m.refreshing, error=m.error, triggers=list(m.triggers), lane=self.lane(m, now))
                r["publish"] = self._publish_brief(m)
                rows.append(r)
        rows.sort(key=lambda r: -r["turnover"])
        return {"last_sweep": self.last_sweep, "focused": focused, "matches": rows, "publish": self.publish_status(),
                "health": self.health()}

    def _publish_brief(self, live: MatchLive) -> Optional[dict]:
        """A board row's publish badge: the last decision, the reply state, the engine's flags."""
        if self.publisher is None:
            return None
        out = self.publisher.match_brief(live.match_id)
        e = live.engine or {}
        out.update(gap_alert=bool((e.get("gap") or {}).get("alert")), notes=list(e.get("notes") or []),
                   gm_engine=e.get("gm_engine"))
        return out

    def publish_status(self) -> dict:
        """Publishing for the board strip and /api/live/publish/status."""
        p = self.settings.publish
        if self.publisher is None:
            from .publisher import read_stop
            return {"mode": "off", "configured": p.mode, "refused": self.publish_refused,
                    "stopped": read_stop(os.path.join(str(self.settings.paths.work), "publish")),
                    "targets": [], "transport": None, "mapping": None, "scope": None, "counts": {}, "matches": 0,
                    "awaiting": 0, "no_response": [], "last_sent": None, "latency_seconds": None,
                    "inplay": self.last_fast, "inplay_running": self.fast_running}
        out = self.publisher.status()
        out.update(inplay=self.last_fast, inplay_running=self.fast_running)
        return out

    def price_at(self, match_id: int, theta: Dict[str, float]) -> Optional[dict]:
        """What-if: the match's last book at another theta (the dimensions not given stay at HKJC's), priced,
        its demand re-run and its E[GM] scored the way the optimiser scores a candidate."""
        with self._lock:
            live = self.matches.get(int(match_id))
            bk = live.book if live is not None else None
        if bk is None:
            return None
        th = repair_theta({**bk.theta_now, **{k: float(v) for k, v in (theta or {}).items()}})
        odds, p = self.optimizer.prices(bk, th)
        odds = np.where(np.isfinite(odds), odds, bk.odds_now)
        T = self.optimizer.demand_at(bk, odds)
        return {"theta": th, "keys": bk.keys[KEY].reset_index(drop=True), "odds": odds, "model_prob": p,
                "demand": T, "gm": self.optimizer.expected_gm(bk, odds, T), "turnover": float(np.nansum(T)),
                "gm_board": self.optimizer.expected_gm(bk, bk.odds_now), "turnover_board": bk.total_demand,
                "belief": bk.p_true, "odds_now": bk.odds_now, "legs": bk.n}

    def curves(self, match_id: int, points: int = 13) -> Optional[dict]:
        """E[GM] along each dimension across the trust band around HKJC's theta, the others held at theta*."""
        with self._lock:
            live = self.matches.get(int(match_id))
            bk, dec = (live.book, live.decision) if live is not None else (None, None)
        if bk is None:
            return None
        star = dict(dec.theta_star) if dec is not None else repair_theta(bk.theta_now)
        band = self.settings.optimizer.theta_band
        out = {}
        for dim, now in bk.theta_now.items():
            if dim not in band or now is None or not np.isfinite(now):
                continue
            xs = np.linspace(now - band[dim], now + band[dim], int(points))
            if dim.endswith("_tg"):
                xs = np.maximum(xs, 0.0)
            gm = []
            for x in xs:
                odds, _ = self.optimizer.prices(bk, repair_theta({**star, dim: float(x)}))
                odds = np.where(np.isfinite(odds), odds, bk.odds_now)
                gm.append(self.optimizer.expected_gm(bk, odds, self.optimizer.demand_at(bk, odds)))
            out[dim] = {"x": [float(x) for x in xs], "gm": gm, "now": float(now), "star": float(star.get(dim, now))}
        return {"match_id": int(match_id), "turnover": bk.total_demand, "curves": out}

    def match_view(self, match_id: int) -> dict:
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None:
                return {"match_id": int(match_id), "status": "unknown"}
            view = live.view.to_dict("records") if live.view is not None else []
            rows = live.rows.to_dict("records") if live.rows is not None else []
            extras = {k: (v.to_dict("records") if isinstance(v, pd.DataFrame) else v) for k, v in live.extras.items()}
            engine, engine_rows = _engine_view(live.engine)
            return {**live.summary(), "lane": self.lane(live), "header": dict(live.header), "rows": rows,
                    "selections": view,
                    "per_pool": live.decision.per_pool if live.decision else [], "extras": extras,
                    "theta_hkjc": dict(live.book.theta_now) if live.book is not None else {},
                    "requested_at": live.requested_at, "models": self.models(), "behind": live.behind,
                    "engine": engine, "engine_rows": engine_rows,
                    "publish": self.publisher.match_view(match_id) if self.publisher is not None
                    else {"mode": "off", "state": "idle", "started": False}}


# ---------------------------------------------------------------- helpers
def _default_source(settings):
    if settings.live.source == "replay":
        from ..data.replay import ReplaySource
        return ReplaySource(settings)
    from src.hkjc.source import get_source
    return get_source(settings.live.source)


def _second_source(source):
    """The focus thread's source: a SQL source on its own connections (a pyodbc connection belongs to one
    thread); replay, capture and simulated sources only read, and are shared."""
    clone = getattr(source, "clone", None)
    return clone() if callable(clone) else source


def _only(snap, mid: int):
    """Keep one match's rows; the simulator ignores match_ids, SQL and replay honour it."""
    for name in ("active_pools", "match_info", "params", "params_history", "params_raw", "events", "odds", "market",
                 "investments"):
        frame = getattr(snap, name, None)
        if frame is not None and not frame.empty and "match_id" in frame.columns:
            setattr(snap, name, frame[pd.to_numeric(frame["match_id"], errors="coerce") == mid])
        elif frame is not None and not frame.empty and name == "match_info":
            col = next((c for c in ("MatchId", "match_id") if c in frame.columns), None)
            if col:
                setattr(snap, name, frame[pd.to_numeric(frame[col], errors="coerce") == mid])
    return snap


PARAMS_RAW = ("GameState", "Goal90DrawFactor", "Goal90BasisTG", "Goal90BasisSUP", "Goal90ModelTG", "Goal90ModelSUP",
              "Corner90BasisTG", "Corner90BasisSUP", "Corner90ModelTG", "Corner90ModelSUP", "EventTime")


def _params_raw(snap, as_of) -> Dict[int, dict]:
    """Per match, the newest algo_param row at or before ``as_of``, with the columns the panel does not
    keep: the draw factor the engine prices with, the Basis and Model layers, the GameState text."""
    p = getattr(snap, "params_raw", None)             # a replay's (its params are the panel's columns)
    if p is None or p.empty:
        p = getattr(snap, "params_history", None)
    if p is None or p.empty:
        p = getattr(snap, "params", None)
    if p is None or p.empty:
        return {}
    col = "match_id" if "match_id" in p.columns else "EventLevel2ID" if "EventLevel2ID" in p.columns else None
    if col is None:
        return {}
    p = p.assign(_m=pd.to_numeric(p[col], errors="coerce"))
    if "EventTime" in p.columns:
        t = pd.to_datetime(p["EventTime"], errors="coerce")
        p = p.assign(_t=t)[t <= pd.Timestamp(as_of)].sort_values("_t", kind="mergesort")
    last = p.dropna(subset=["_m"]).groupby("_m").tail(1)
    cols = [c for c in PARAMS_RAW if c in last.columns]
    return {int(m): {c: v for c, v in zip(cols, vals)} for m, vals in zip(last["_m"], last[cols].to_numpy())}


ENGINE_COLS = ("engine_true_odds", "engine_sell_odds", "engine_weight", "engine_margin", "engine_offered",
               "engine_gap")


def _engine_view(engine: Optional[dict]) -> Tuple[Optional[dict], List[dict]]:
    """The last reply for the cockpit: its summary, and one record per selection it priced - our rows joined,
    then every other selection of the reply by its ids (the pools Algo E does not model)."""
    if not engine:
        return None, []
    summary = {k: v for k, v in engine.items() if k not in ("rows", "joined")}
    out: List[dict] = []
    joined, frame = engine.get("joined"), engine.get("rows")
    seen = set()
    if joined is not None and len(joined):
        cols = [c for c in KEY + list(ENGINE_COLS) if c in joined.columns]
        for r in joined[joined["joined_by"].notna()][cols].to_dict("records"):
            out.append(r)
            seen.add(tuple(int(r[k]) for k in KEY))
    if frame is not None and len(frame):
        f = frame.rename(columns={"true_odds": "engine_true_odds", "sell_odds": "engine_sell_odds",
                                  "weight": "engine_weight", "margin": "engine_margin", "offered": "engine_offered"})
        for r in f[KEY + ["engine_true_odds", "engine_sell_odds", "engine_weight", "engine_margin",
                          "engine_offered"]].to_dict("records"):
            if tuple(int(r[k]) for k in KEY) not in seen:
                out.append(r)
    return summary, out


def _maybe_in_play(live: Optional[MatchLive], as_of) -> bool:
    """In play at the last refresh, or kicked off since and not finished (the board decides)."""
    if live is None:
        return False
    h = live.header or {}
    if h.get("in_play"):
        return True
    if str(h.get("phase") or "") in ("finished", "full_time"):
        return False
    try:
        ko = pd.Timestamp(h.get("kickoff")) if h.get("kickoff") else None
    except (ValueError, TypeError):
        ko = None
    return ko is not None and not pd.isna(ko) and ko <= pd.Timestamp(as_of)


def _in_fast_lane(live: Optional[MatchLive], as_of, minutes: float) -> bool:
    """In play (or kicked off and not finished), or kick-off within ``minutes``."""
    if live is None:
        return False
    if _maybe_in_play(live, as_of):
        return True
    h = live.header or {}
    if str(h.get("phase") or "") in ("finished", "full_time"):
        return False
    try:
        ko = pd.Timestamp(h.get("kickoff")) if h.get("kickoff") else None
    except (ValueError, TypeError):
        ko = None
    return ko is not None and not pd.isna(ko) and (ko - pd.Timestamp(as_of)).total_seconds() <= float(minutes) * 60.0


def _observed(investments: pd.DataFrame, sel: pd.DataFrame, bucket, as_of, column: str = "turnover") -> np.ndarray:
    """Money (``column="ticket_count"``: tickets) each selection has taken since the bucket started."""
    if investments is None or investments.empty:
        return np.zeros(len(sel))
    inv = LivePanelBuilder._canon("investments", investments)
    inv = inv[(inv["start_sell_time"] >= bucket) & (inv["start_sell_time"] <= as_of)]
    if inv.empty or column not in inv.columns:
        return np.zeros(len(sel))
    for c in KEY:
        inv[c] = pd.to_numeric(inv[c], errors="coerce").fillna(-1).astype("int64")
    inv[column] = pd.to_numeric(inv[column], errors="coerce").fillna(0.0).astype("float64")
    got = inv.groupby(KEY)[column].sum()
    idx = pd.MultiIndex.from_frame(sel[KEY].astype("int64"))
    return got.reindex(idx).fillna(0.0).to_numpy(dtype="float64")


def _main_odds(book) -> Dict[tuple, float]:
    if book is None or book.keys is None:
        return {}
    out = {}
    for i in np.flatnonzero(book.is_main):
        k = book.keys.iloc[i]
        out[(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"]))] = float(book.odds_now[i])
    return out


def _view(book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    v = book.keys.copy() if book.keys is not None else pd.DataFrame(index=range(book.n))
    v["line"] = book.rows.line
    v["side"] = book.rows.side
    v["odds_now"] = book.odds_now
    v["belief"] = book.p_true
    v["model_prob"] = book.p_now if book.p_now is not None else np.nan
    v["demand"] = book.demand
    if dec is not None and dec.odds_star is not None:
        v["odds_star"] = dec.odds_star
        v["odds_star_ladder"] = publish_odds(dec.odds_star)
        v["demand_star"] = dec.demand_star
        # stage 2: our weighting on top of theta*, and the price in the desk's terms
        # (sell = fair(theta*) / (1 + margin) x desk_weighting)
        w = dec.weights if dec.weights is not None else np.ones(book.n)
        v["weighting"] = w
        v["odds_stage1"] = dec.odds_star / np.where(w > 0, w, 1.0)
        v["desk_weighting"] = desk_weightings(book, dec)
    v["weighting_prev"] = book.w_prev if book.w_prev is not None and len(book.w_prev) == book.n else np.nan
    return v


def _weights_by_key(book, dec: Optional[MatchDecision]) -> Dict[tuple, float]:
    return weights_by_key(book.keys if book is not None else None, dec.weights if dec is not None else None)


def _stamp(value) -> Optional[str]:
    if value is None:
        return None
    t = pd.Timestamp(value)
    return None if pd.isna(t) else str(t)


def _text(value) -> Optional[str]:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return None
    out = str(value).strip()
    return out or None


def _number(value) -> Optional[float]:
    v = pd.to_numeric(value, errors="coerce")
    return float(v) if v is not None and np.isfinite(v) else None


def _rows(sel: pd.DataFrame, forecast, observed, remaining, next_bucket, belief) -> pd.DataFrame:
    """Every selection of the bucket with its prices and its money: what the desk's book draws."""
    def col(name, default=np.nan):
        return sel[name].to_numpy() if name in sel.columns else np.full(len(sel), default)

    out = pd.DataFrame({c: col(c) for c in KEY + ["match_id"]})
    for c in ("pool_name", "line_label", "combination_string", "market", "segment", "theta_domain", "family", "side"):
        out[c] = pd.Series(col(c, None), dtype="object").where(pd.notna(col(c, None)), None)
    for c in ("line", "odds", "true_odds", "p_hkjc_true", "p_market", "mkt_odds", "odds_age_min"):
        out[c] = pd.to_numeric(pd.Series(col(c)), errors="coerce").to_numpy(dtype="float64")
    out["belief"] = np.asarray(belief, dtype="float64")
    out["forecast"] = np.asarray(forecast, dtype="float64")
    out["observed"] = np.asarray(observed, dtype="float64")
    out["remaining"] = np.asarray(remaining, dtype="float64")
    out["next_bucket"] = np.asarray(next_bucket, dtype="float64")
    out["last_bucket"] = pd.to_numeric(pd.Series(col("tv1", 0.0)), errors="coerce").fillna(0.0).to_numpy()
    out["tickets_last_bucket"] = pd.to_numeric(pd.Series(col("tk1", 0.0)), errors="coerce").fillna(0.0).to_numpy()
    out["is_main"] = pd.to_numeric(pd.Series(col("rank_0", 0.0)), errors="coerce").fillna(0.0).to_numpy() > 0
    out["forecastable"] = pd.Series(col("forecastable", True)).fillna(False).astype(bool).to_numpy()
    if "selling" in sel.columns:
        out["selling"] = pd.Series(col("selling")).fillna(False).astype(bool).to_numpy()
    else:
        out["selling"] = out["forecastable"].to_numpy()
    for c in KEY + ["match_id"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").astype("int64")
    return out


def _with_book(rows: pd.DataFrame, book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    """The book's prices on the rows it holds: the model's probability at HKJC's theta, theta*'s odds."""
    out = rows.copy()
    out["in_book"] = False
    cols = ("model_prob", "odds_star", "odds_star_ladder", "demand", "demand_star", "weighting", "desk_weighting",
            "odds_stage1", "weighting_prev")
    for c in cols:
        out[c] = np.nan
    if book is None or book.keys is None or out.empty:
        return out
    v = _view(book, dec)
    keep = [c for c in cols if c in v.columns]
    v = v[KEY + keep].copy()
    for c in KEY:
        v[c] = pd.to_numeric(v[c], errors="coerce").astype("int64")
    v["in_book"] = True
    merged = out.drop(columns=["in_book"] + keep).merge(v, on=KEY, how="left")
    merged["in_book"] = merged["in_book"].fillna(False).astype(bool)
    return merged[list(out.columns)]


def _header(info: pd.DataFrame, match: pd.DataFrame, mid: int, bucket) -> dict:
    """Teams, league and kick-off from the match information; phase, clock and score from the bucket's row."""
    h: dict = {}
    if info is not None and not info.empty and "match_id" in info.columns:
        r = info[pd.to_numeric(info["match_id"], errors="coerce") == mid]
        if len(r):
            r = r.iloc[0]
            h.update(home=_text(r.get("home_name")), away=_text(r.get("away_name")),
                     league=_text(r.get("league_name")) or _text(r.get("league_code")),
                     league_code=_text(r.get("league_code")), kickoff=_stamp(r.get("ko_time")))
    if match is not None and not match.empty:
        m = match[pd.to_numeric(match["match_id"], errors="coerce") == mid]
        at = m[pd.to_datetime(m["bucket"]) == pd.Timestamp(bucket)]
        m = at if len(at) else m.sort_values("bucket")
        if len(m):
            r = m.iloc[-1]

            def count(name):
                return int(np.nan_to_num(_number(r.get(name)) or 0.0))
            for side in ("home", "away"):
                if not h.get(side):
                    h[side] = _text(r.get(side + "_name"))
            h.update(phase=_text(r.get("phase")) or "prematch", minute=_number(r.get("minute")),
                     in_play=bool((_number(r.get("inplay")) or 0.0) > 0), game_state=_text(r.get("game_state")),
                     score=[count("home_goals"), count("away_goals")],
                     corners=[count("home_corners"), count("away_corners")],
                     reds=[count("home_reds"), count("away_reds")],
                     splits={"goal": _number(r.get("goal_split_fh")), "corner": _number(r.get("corner_split_fh"))})
    return h


def _params_at(panel: pd.DataFrame, bucket) -> Dict[int, pd.Timestamp]:
    """Per match, the EventTime of the TG/SUP row the bucket's rows carry."""
    if panel is None or panel.empty or "event_time" not in panel.columns:
        return {}
    rows = panel[pd.to_datetime(panel["bucket"]) == pd.Timestamp(bucket)]
    t = pd.to_datetime(rows["event_time"], errors="coerce")
    got = t.groupby(pd.to_numeric(rows["match_id"], errors="coerce")).max().dropna()
    return {int(k): pd.Timestamp(v) for k, v in got.items()}


def _extras(builder: LivePanelBuilder, snap, mid: int, as_of, history: int = 40) -> dict:
    """What a trader reads beside the book, from the focus refresh's own read: the external quotes, the
    incidents, HKJC's recent price track and every pool's latest price (the pools the panel leaves out too)."""
    as_of = pd.Timestamp(as_of)
    out: dict = {}
    odds = builder._canon("odds", snap.odds)
    if not odds.empty:
        odds = odds[(pd.to_numeric(odds["match_id"], errors="coerce") == mid)
                    & (pd.to_datetime(odds["effective_datetime"]) <= as_of)].sort_values("effective_datetime",
                                                                                      kind="mergesort")
        cols = [c for c in KEY + ["pool_name", "line_label", "combination_string", "odds", "true_odds",
                                  "effective_datetime"] if c in odds.columns]
        out["latest"] = odds.groupby(KEY, as_index=False).last()[cols]
        out["history"] = odds.groupby(KEY).tail(history)[[c for c in KEY + ["effective_datetime", "odds", "true_odds"]
                                                          if c in odds.columns]].reset_index(drop=True)
    market = builder._canon("market", snap.market)
    if not market.empty:
        market = market[(pd.to_numeric(market["match_id"], errors="coerce") == mid)
                        & (pd.to_datetime(market["effective_datetime"]) <= as_of)]
        if not market.empty:
            by = KEY + [c for c in ("bookmaker",) if c in market.columns]
            q = market.sort_values("effective_datetime", kind="mergesort").groupby(by, as_index=False).last()
            q["age_sec"] = (as_of - pd.to_datetime(q["effective_datetime"])).dt.total_seconds().round()
            out["quotes"] = q[[c for c in KEY + ["bookmaker", "bookmaker_str", "odds", "age_sec"] if c in q.columns]]
    events = builder._canon("events", snap.events)
    if not events.empty:
        e = events[(pd.to_numeric(events["match_id"], errors="coerce") == mid)
                   & (pd.to_datetime(events["incident_datetime"]) <= as_of)]
        out["incidents"] = e.sort_values("incident_datetime", ascending=False, kind="mergesort").head(60)[
            [c for c in ("incident_datetime", "incident_type", "home_or_away", "provider_id") if c in e.columns]]
    return out
