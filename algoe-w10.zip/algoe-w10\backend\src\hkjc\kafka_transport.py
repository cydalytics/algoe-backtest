"""
Kafka Transports

One interface for every way a params message can leave and a reply can come
back:

    send(topic, key, value, tag=None)   queue one message (value: the wire text)
    poll(timeout)                       replies that arrived since the last poll
    deliveries()                        what happened to the messages sent since the last call
    flush(timeout) / close()

    MemoryTransport   tests: messages in a list, replies pushed in by hand or by a responder
    FileTransport     dry run: one wire message per line in <root>/out/<YYYYMMDD>.jsonl (the
                      Kafka owner can check the format from it), replies read from
                      <root>/in/*.jsonl; with a responder (the mock engine) each message is
                      answered into in/ at once
    KafkaTransport    the office: confluent_kafka, imported on first use. Messages are keyed by
                      EventId, so one match's messages stay in order on one partition; acks=all;
                      the consumer starts from the newest replies

Endpoints, topics and credentials come from the environment only
(kafka_config_from_env): the zips are public, so none of them is written in the
code, and a secret is never logged or shown.

Change Log:
-----------
2026-10-29      Initialize
"""

import json
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

import pandas as pd

from src.core.logging import get_logger

log = get_logger(__name__)

ENV = {
    "bootstrap": "ALGOE_KAFKA_BOOTSTRAP",
    "topic_params": "ALGOE_KAFKA_TOPIC_PARAMS",
    "topic_prices": "ALGOE_KAFKA_TOPIC_PRICES",
    "test_topic_params": "ALGOE_KAFKA_TEST_TOPIC_PARAMS",
    "test_topic_prices": "ALGOE_KAFKA_TEST_TOPIC_PRICES",
    "group": "ALGOE_KAFKA_GROUP",
    "security_protocol": "ALGOE_KAFKA_SECURITY_PROTOCOL",
    "sasl_mechanism": "ALGOE_KAFKA_SASL_MECHANISM",
    "username": "ALGOE_KAFKA_USERNAME",
    "password": "ALGOE_KAFKA_PASSWORD",
    "keytab": "ALGOE_KAFKA_KEYTAB",
    "principal": "ALGOE_KAFKA_PRINCIPAL",
    "service_name": "ALGOE_KAFKA_SERVICE_NAME",
    "ca_file": "ALGOE_KAFKA_CA_FILE",
}
SECRET = ("username", "password", "keytab", "principal")
INSTALL = ("confluent-kafka is not installed. From the offline wheels: python -m pip install --no-index "
           "--find-links <offline-wheels folder> -r backend\\requirements-kafka.txt")


class TransportError(RuntimeError):
    """The transport cannot be built or used; the text says what to do."""


@dataclass
class Received:
    topic: str
    key: Optional[str]
    value: str
    at: pd.Timestamp


@dataclass
class Delivery:
    tag: Optional[str]
    topic: str
    ok: bool
    error: Optional[str]
    seconds: float


class _Base:
    def __init__(self):
        self._lock = threading.Lock()
        self._done: deque = deque(maxlen=10000)

    def deliveries(self) -> List[Delivery]:
        with self._lock:
            out = list(self._done)
            self._done.clear()
        return out

    def flush(self, timeout: float = 5.0) -> int:
        return 0

    def close(self) -> None:
        return None


# ================================================================ memory
class MemoryTransport(_Base):
    def __init__(self, responder: Optional[Callable[[str], Optional[str]]] = None, reply_topic: str = "prices"):
        super().__init__()
        self.sent: List[tuple] = []
        self.inbox: deque = deque()
        self.responder = responder
        self.reply_topic = reply_topic
        self.fail: Optional[str] = None             # tests: every send fails with this error

    def send(self, topic: str, key, value: str, tag: Optional[str] = None) -> None:
        if self.fail:
            with self._lock:
                self._done.append(Delivery(tag, topic, False, self.fail, 0.0))
            return
        with self._lock:
            self.sent.append((topic, None if key is None else str(key), value))
            self._done.append(Delivery(tag, topic, True, None, 0.0))
        if self.responder is not None:
            reply = self.responder(value)
            if reply is not None:
                self.push(reply, key)

    def push(self, value: str, key=None, topic: Optional[str] = None) -> None:
        with self._lock:
            self.inbox.append(Received(topic or self.reply_topic, None if key is None else str(key), value,
                                       pd.Timestamp.now()))

    def poll(self, timeout: float = 0.0) -> List[Received]:
        with self._lock:
            out = list(self.inbox)
            self.inbox.clear()
        return out


# ================================================================== file
class FileTransport(_Base):
    def __init__(self, root, responder: Optional[Callable[[str], Optional[str]]] = None, reply_topic: str = "prices"):
        super().__init__()
        self.root = Path(root)
        self.out_dir, self.in_dir = self.root / "out", self.root / "in"
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.in_dir.mkdir(parents=True, exist_ok=True)
        self.responder = responder
        self.reply_topic = reply_topic
        self._offsets: Dict[str, int] = {}
        # replies already in in/ when we start were answered to an earlier run
        for p in self.in_dir.glob("*.jsonl"):
            self._offsets[p.name] = p.stat().st_size

    def _append(self, folder: Path, text: str) -> None:
        day = pd.Timestamp.now().strftime("%Y%m%d")
        with open(folder / "{}.jsonl".format(day), "a", encoding="utf-8", newline="\n") as fh:
            fh.write(text.replace("\n", " ") + "\n")

    def send(self, topic: str, key, value: str, tag: Optional[str] = None) -> None:
        started = time.time()
        try:
            with self._lock:
                self._append(self.out_dir, value)
        except OSError as exc:
            with self._lock:
                self._done.append(Delivery(tag, topic, False, str(exc), time.time() - started))
            return
        with self._lock:
            self._done.append(Delivery(tag, topic, True, None, time.time() - started))
        if self.responder is not None:
            reply = self.responder(value)
            if reply is not None:
                with self._lock:
                    self._append(self.in_dir, reply)

    def poll(self, timeout: float = 0.0) -> List[Received]:
        out: List[Received] = []
        with self._lock:
            for p in sorted(self.in_dir.glob("*.jsonl")):
                start = self._offsets.get(p.name, 0)
                size = p.stat().st_size
                if size <= start:
                    continue
                with open(p, "rb") as fh:
                    fh.seek(start)
                    chunk = fh.read(size - start)
                end = chunk.rfind(b"\n")
                if end < 0:
                    continue                          # a line still being written
                for line in chunk[:end].split(b"\n"):
                    text = line.decode("utf-8", errors="replace").strip()
                    if text:
                        out.append(Received(self.reply_topic, None, text, pd.Timestamp.now()))
                self._offsets[p.name] = start + end + 1
        return out


# ================================================================= kafka
@dataclass
class KafkaConfig:
    values: Dict[str, str] = field(default_factory=dict)
    extra: Dict[str, str] = field(default_factory=dict)

    def get(self, name: str) -> Optional[str]:
        v = self.values.get(name)
        return v if v else None

    def topics(self, target: str) -> tuple:
        """(params topic, prices topic) for target 'test' or 'production'."""
        if target == "test":
            return self.get("test_topic_params"), self.get("test_topic_prices")
        return self.get("topic_params"), self.get("topic_prices")

    def missing(self, targets) -> List[str]:
        need = ["bootstrap"]
        for t in targets:
            need += ["test_topic_params", "test_topic_prices"] if t == "test" else ["topic_params", "topic_prices"]
        mech = (self.get("sasl_mechanism") or "").upper()
        if mech in ("PLAIN", "SCRAM-SHA-256", "SCRAM-SHA-512"):
            need += ["username", "password"]
        elif mech == "GSSAPI":
            need += ["keytab", "principal"]
        return [ENV[n] for n in dict.fromkeys(need) if not self.get(n)]

    def overlap(self) -> List[str]:
        """Topics named both for test and for production: a test message there would reach production."""
        live = {t for t in self.topics("production") if t}
        return sorted({t for t in self.topics("test") if t} & live)

    def describe(self) -> Dict[str, str]:
        """Every setting, with the secrets shown as set or not set only."""
        out = {}
        for name, var in ENV.items():
            v = self.get(name)
            out[var] = ("(set)" if v else "(not set)") if name in SECRET else (v or "(not set)")
        return out

    def librdkafka(self, consumer: bool = False, commit: bool = True) -> Dict[str, str]:
        conf = {"bootstrap.servers": self.get("bootstrap") or "", "client.id": "algoe"}
        for name, key in (("security_protocol", "security.protocol"), ("sasl_mechanism", "sasl.mechanism"),
                          ("username", "sasl.username"), ("password", "sasl.password"),
                          ("keytab", "sasl.kerberos.keytab"), ("principal", "sasl.kerberos.principal"),
                          ("service_name", "sasl.kerberos.service.name"), ("ca_file", "ssl.ca.location")):
            if self.get(name):
                conf[key] = self.get(name)
        if consumer:
            conf.update({"group.id": self.get("group") or "algoe-prices", "auto.offset.reset": "latest",
                         "enable.auto.commit": bool(commit)})
        else:
            conf.update({"acks": "all", "linger.ms": 5, "message.timeout.ms": 15000})
        conf.update(self.extra)
        return conf


def kafka_config_from_env(env=None) -> KafkaConfig:
    """The Kafka settings from the environment. ALGOE_KAFKA_EXTRA may hold more librdkafka settings as
    JSON (no secrets there: put them in the variables above)."""
    env = os.environ if env is None else env
    extra = {}
    if env.get("ALGOE_KAFKA_EXTRA"):
        try:
            extra = {str(k): v for k, v in json.loads(env["ALGOE_KAFKA_EXTRA"]).items()}
        except (ValueError, AttributeError) as exc:
            raise TransportError("ALGOE_KAFKA_EXTRA is not a JSON object: {}".format(exc))
    return KafkaConfig({name: env.get(var, "") for name, var in ENV.items()}, extra)


class KafkaTransport(_Base):
    def __init__(self, config: KafkaConfig, reply_topics: List[str], commit: bool = True):
        super().__init__()
        self.config = config
        self.reply_topics = [t for t in reply_topics if t]
        self.commit = commit                          # False: no group offsets kept, every start at the newest
        self._producer = None
        self._consumer = None
        self._early: List[Received] = []              # replies read while waiting for the partitions

    @staticmethod
    def _module():
        try:
            import confluent_kafka
        except ImportError:
            raise TransportError(INSTALL)
        return confluent_kafka

    def _p(self):
        if self._producer is None:
            self._producer = self._module().Producer(self.config.librdkafka())
        return self._producer

    def _c(self):
        if self._consumer is None:
            c = self._module().Consumer(self.config.librdkafka(consumer=True, commit=self.commit))
            if self.reply_topics:
                c.subscribe(self.reply_topics)
            self._consumer = c
        return self._consumer

    def send(self, topic: str, key, value: str, tag: Optional[str] = None) -> None:
        started = time.time()

        def done(err, msg, tag=tag, topic=topic, started=started):
            with self._lock:
                self._done.append(Delivery(tag, topic, err is None, None if err is None else str(err),
                                           time.time() - started))
        p = self._p()
        payload = value.encode("utf-8")
        k = None if key is None else str(key).encode("utf-8")
        try:
            p.produce(topic, value=payload, key=k, on_delivery=done)
        except BufferError:
            p.poll(0.5)                               # the local queue is full: let it drain once
            p.produce(topic, value=payload, key=k, on_delivery=done)
        p.poll(0)

    def metadata(self, timeout: float = 10.0):
        """The cluster's brokers and topics: proves the brokers answer and the login works."""
        return self._p().list_topics(timeout=timeout)

    def wait_assigned(self, timeout: float = 15.0) -> bool:
        """Join the consumer group and wait for partitions. The consumer starts from the newest replies, so
        a reply sent before it is assigned would be missed."""
        if not self.reply_topics:
            return False
        c = self._c()
        end = time.time() + timeout
        while time.time() < end:
            self._early += self._read(c, 0.5)
            if c.assignment():
                return True
        return False

    def poll(self, timeout: float = 0.0) -> List[Received]:
        if self._producer is not None:
            self._producer.poll(0)
        if not self.reply_topics:
            return []
        early, self._early = self._early, []
        return early + self._read(self._c(), timeout)

    def _read(self, c, timeout: float) -> List[Received]:
        out: List[Received] = []
        msg = c.poll(timeout)
        while msg is not None:
            err = msg.error()
            if err is None:
                key = msg.key()
                out.append(Received(msg.topic(), None if key is None else key.decode("utf-8", errors="replace"),
                                    msg.value().decode("utf-8", errors="replace"), pd.Timestamp.now()))
            elif err.code() != self._module().KafkaError._PARTITION_EOF:
                log.warning("kafka consumer: %s", err)
            msg = c.poll(0)
        return out

    def flush(self, timeout: float = 5.0) -> int:
        return int(self._producer.flush(timeout)) if self._producer is not None else 0

    def close(self) -> None:
        try:
            self.flush(5.0)
        finally:
            if self._consumer is not None:
                self._consumer.close()
                self._consumer = None
