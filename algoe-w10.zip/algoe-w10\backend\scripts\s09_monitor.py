"""
Step 09 - is the model still good?

Accuracy: what the live engine published, joined to the money that arrived
(or, offline, the champion replayed over the days), rolling WAPE / deviance /
bias against last 5 minutes. Inputs: each feature against its training
distribution (PSI). Novelty: leagues the encoder never saw, pool codes the
taxonomy had to place by rule. Writes AlgoE_Work/monitor/health.json and
appends to alerts.jsonl.

    python scripts/s09_monitor.py --days 7

Exit code 2 when there are alerts. Same as: python -m algoe monitor
"""
from _algoe import run

if __name__ == "__main__":
    run("monitor")
