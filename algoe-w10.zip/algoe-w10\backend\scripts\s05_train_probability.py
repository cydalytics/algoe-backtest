"""
Step 05 - train the probability calibrator

Settled selections only (soft outcome for quarter lines, pushes dropped), live
prices only (a withdrawn line's stale quote is not a belief). Every source
(HKJC true odds, external market, Poisson from HKJC theta, de-margined odds)
x every method (raw, Platt, beta, isotonic, logit pool, contextual) is fitted
on train days, chosen on validation log-loss and reported on test days with
Brier, ECE, calibration slope and the expected vs realised margin.

    python scripts/s05_train_probability.py --start 2026-07-01 --end 2026-09-15

Same as: python -m algoe train-probability
"""
from _algoe import run

if __name__ == "__main__":
    run("train-probability")
