"""
Replay Source

Serves the live engine a snapshot "as of" any past moment, cut from the
historical Raw_Data: odds, investments, parameters and incidents up to that
moment, for the matches whose pools are selling then. It is the shadow-mode
rehearsal on the office box - run a real past evening through exactly the
code that will run live, and compare the recommendations with what happened.

Same interface as the desk's sources (src/hkjc/source.py): ``fetch(as_of,
match_ids=None)`` returns an object with the seven snapshot frames.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      48 hours of history, so start odds across midnight see yesterday's prices; pools listed
                as the SQL feed lists them (closed ones included, close time once passed)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from ..core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ReplaySnapshot:
    as_of: pd.Timestamp
    source: str
    active_pools: pd.DataFrame
    match_info: pd.DataFrame
    params: pd.DataFrame
    events: pd.DataFrame
    odds: pd.DataFrame
    market: pd.DataFrame
    investments: pd.DataFrame
    notes: List[str] = field(default_factory=list)

    @property
    def match_ids(self) -> List[int]:
        return sorted(pd.to_numeric(self.active_pools["match_id"], errors="coerce").dropna().astype(int).unique())


class ReplaySource:
    def __init__(self, settings, history_hours: float = 48.0, keep_closed_hours: float = 3.0):
        self.settings = settings
        self.cfg = settings.legacy_config()
        self.history = pd.Timedelta(hours=history_hours)
        self.keep_closed = pd.Timedelta(hours=keep_closed_hours)
        self._day: Optional[pd.Timestamp] = None
        self._frames: Dict[str, pd.DataFrame] = {}

    def _load(self, as_of: pd.Timestamp) -> None:
        from src.backtest.parquet.loader import load_static, load_window
        day = as_of.normalize()
        if self._day == day:
            return
        # from the start of the day, so every moment of the day has the same history behind it
        lo, hi = day - self.history, day + pd.Timedelta(days=1)
        f = {}
        for name in ("odds", "investments", "params", "events", "market"):
            try:
                f[name] = load_window(self.cfg.data_dir, name, lo, hi)
            except Exception as exc:                                  # noqa: BLE001
                logger.warning("replay: %s not loaded (%s)", name, exc)
                f[name] = pd.DataFrame()
        pools, matches = load_static(self.cfg.data_dir, lo, hi)
        f["pools"], f["matches"] = pools, matches
        self._frames, self._day = f, day
        logger.info("replay loaded %s: %s", day.date(), {k: len(v) for k, v in f.items()})

    def fetch(self, as_of=None, match_ids=None) -> ReplaySnapshot:
        as_of = pd.Timestamp(as_of)
        self._load(as_of)
        f = self._frames
        pools = f["pools"]
        # As the SQL feed lists them: every pool that has started selling, closed ones included (their
        # money is the history of the board), each with its close time once that has passed - a
        # future close is not known live. Pools closed more than keep_closed ago are dropped.
        live = pools
        if not pools.empty:
            close = pd.to_datetime(pools["close_time"], errors="coerce")
            live = pools[(pools["start_selling_time"] <= as_of)
                         & (close.isna() | (close > as_of - self.keep_closed))].copy()
            live["close_time"] = pd.to_datetime(live["close_time"], errors="coerce").where(
                pd.to_datetime(live["close_time"], errors="coerce") <= as_of)
        ids = set(pd.to_numeric(live["match_id"], errors="coerce").dropna().astype(int)) if not live.empty else set()
        if match_ids is not None:
            ids &= {int(m) for m in match_ids}

        def cut(frame, tcol):
            if frame is None or frame.empty:
                return frame
            out = frame[pd.to_numeric(frame["match_id"], errors="coerce").isin(ids)]
            if tcol and tcol in out.columns:
                out = out[pd.to_datetime(out[tcol]) <= as_of]
            return out.copy()
        inv = cut(f["investments"], "start_sell_time")
        if inv is not None and not inv.empty:
            # the feed floors a bet to its minute: the minute in progress is only part-known
            inv = inv[pd.to_datetime(inv["start_sell_time"]) < as_of.floor("min") + pd.Timedelta(minutes=1)]
        return ReplaySnapshot(
            as_of=as_of, source="replay",
            active_pools=live[pd.to_numeric(live["match_id"], errors="coerce").isin(ids)][
                ["match_id", "pool_id", "close_time"]]
            if not live.empty else pd.DataFrame(columns=["match_id", "pool_id", "close_time"]),
            match_info=f["matches"][pd.to_numeric(f["matches"]["match_id"], errors="coerce").isin(ids)].copy()
            if not f["matches"].empty else f["matches"],
            params=cut(f["params"], "event_time"), events=cut(f["events"], "incident_datetime"),
            odds=cut(f["odds"], "effective_datetime"), market=cut(f["market"], "effective_datetime"),
            investments=inv)
