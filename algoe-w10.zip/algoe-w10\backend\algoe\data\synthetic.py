"""
Synthetic World

A football book with KNOWN ground truth, written as Raw_Data parquet in the
exact raw column names the extraction notebooks produce. It exists so the
whole pipeline - panel, features, every model, calibration, optimiser, live
loop - can be proven on this laptop, where the real parquet is not.

What is true in this world, and what each part of Algo E should find:

    demand      money per minute = base x league x match x clock x goal shock
                x concurrency split x calendar. Last 5 minutes sees none of
                those drivers, so a real turnover model must beat it.
    mix         pools split the match by phase; inside a pool, lines and
                sides split by softmax(-kappa |line - fair line| + beta x value),
                value = p_true x offered odds - 1. beta > 0 is genuine price
                elasticity: the optimiser has something real to trade.
    belief      HKJC's theta is the truth plus noise, and its true_odds are
                over-confident (logit slope OVERCONFIDENCE). The market is
                priced off the truth with small noise. A calibrator should
                pull the slope back and a blend should lean on the market.
    in play     Goal90CurrentTG is goals still to come; lines settle on the
                whole match. The pricer's full_match convention reproduces
                the board; rest_of_match does not.
    novelty     a league and a pool code that only appear in the last days,
                so unknown-category handling is exercised end to end.

Real-feed quirks reproduced on purpose: TimeInSecond stored as datetime
nanoseconds, Pool_Details.match_id as text, Market_Odds with the bookmaker
and bet-type names swapped, a duplicate event provider.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import json
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..pricing.pricer import BookPricer, BookRows, Conventions, MatchState, settle_matrix

logger = get_logger(__name__)

LEAGUES = {                # code: (name, popularity, country)
    "EPL": ("Eng Premier", 3.0, "ENG"), "UCL": ("UE Champions", 2.4, "EUR"),
    "SPA": ("Spanish Division 1", 1.6, "SPA"), "GER": ("German Division 1", 1.4, "GER"),
    "JV1": ("J1 League", 0.8, "JAP"), "AUS": ("Australian Division 1", 0.7, "AUS"),
    "MLS": ("US Major League", 0.9, "USA"), "BD1": ("Brazilian Division 1", 1.0, "BRA"),
}
NEW_LEAGUE = ("NEW", ("New Test League", 1.3, "XXX"))
BET_CODE = {"HAD": 1, "HILO": 3, "FHLO": 4, "CHLO": 5, "HDC": 6, "CHDC": 48, "NHILO": 90}
POOL_TYPE = {"HAD": "HAD", "HILO": "HIL", "FHLO": "FHL", "CHLO": "CHL", "HDC": "HDC",
             "CHDC": "CHD", "NHILO": "NHL"}
MARGIN = {"HAD": 0.115, "HILO": 0.075, "FHLO": 0.085, "CHLO": 0.10, "HDC": 0.075,
          "CHDC": 0.10, "NHILO": 0.08}
BOOKMAKERS = [(12, "Bet365"), (9, "Sbobet_com"), (13, "PinnacleSports")]

# pool -> (theta domain, market, share pre-match, share in play)
POOLS = {
    "HAD": ("goal", "three_way", 0.24, 0.12),
    "HDC": ("goal", "handicap", 0.26, 0.22),
    "HILO": ("goal", "total", 0.26, 0.38),
    "CHLO": ("corner", "total", 0.10, 0.13),
    "CHDC": ("corner", "handicap", 0.05, 0.05),
    "FHLO": ("goal_fh", "total", 0.09, 0.10),
    "NHILO": ("goal", "total", 0.06, 0.06),
}

PRE_MIN = 360                  # money simulated from 6h before kick-off
FH_END, HT_END, FT_END = 47, 62, 110   # wall minutes after kick-off


@dataclass
class Truth:
    base_per_minute: float = 2200.0
    kappa_line: float = 1.8          # share decay per goal of distance from the fair line
    beta_value: float = 9.0          # price elasticity on punter value
    over_pref: float = 0.15
    home_pref: float = 0.05
    goal_shock: float = 2.2
    goal_decay_min: float = 4.0
    concurrency: float = 0.08
    weekend: float = 1.3
    evening: float = 1.2
    mean_stake: float = 250.0
    stake_sigma: float = 1.0
    overconfidence: float = 1.18     # HKJC true-odds logit slope
    hkjc_theta_sd: float = 0.14
    market_theta_sd: float = 0.05
    league_pop: Dict[str, float] = field(default_factory=lambda: {k: v[1] for k, v in LEAGUES.items()})

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def _label(line: float) -> str:
    if abs((abs(line) * 4.0) % 2.0 - 1.0) < 1e-9:
        return "{:g}/{:g}".format(line - 0.25, line + 0.25)
    return "{:g}".format(line)


def _quarter(x: float) -> float:
    return float(np.round(x * 4.0) / 4.0)


class SyntheticWorld:
    def __init__(self, days: int = 28, matches_per_day: int = 12, start: str = "2026-07-01",
                 seed: int = 11, new_league_day: Optional[int] = None,
                 new_pool_day: Optional[int] = None, truth: Optional[Truth] = None):
        self.days = int(days)
        self.matches_per_day = int(matches_per_day)
        self.start = pd.Timestamp(start).normalize()
        self.seed = int(seed)
        self.new_league_day = self.days - 4 if new_league_day is None else new_league_day
        self.new_pool_day = self.days - 4 if new_pool_day is None else new_pool_day
        self.truth = truth or Truth()
        self.pricer = BookPricer(Conventions(settle_total="full_match", settle_handicap="full_match",
                                             draw_factor=1.05))

    # ------------------------------------------------------------ schedule
    def _schedule(self, rng) -> List[dict]:
        out = []
        codes = list(LEAGUES)
        weights = np.array([0.18, 0.08, 0.14, 0.12, 0.12, 0.10, 0.12, 0.14])
        weights = weights / weights.sum()
        mid = 60_000_000
        for d in range(self.days):
            day = self.start + pd.Timedelta(days=d)
            n = self.matches_per_day + int(rng.integers(-2, 3))
            for k in range(max(n, 2)):
                mid += 1
                lg = rng.choice(codes, p=weights)
                if self.new_league_day is not None and d >= self.new_league_day and k % 5 == 0:
                    lg = NEW_LEAGUE[0]
                hour = float(rng.choice([18.5, 19.5, 20.0, 21.0, 22.0, 23.0, 0.5, 2.0, 3.0],
                                        p=[.08, .12, .14, .12, .12, .12, .12, .1, .08]))
                ko = day + pd.Timedelta(hours=hour if hour >= 12 else hour + 24)
                out.append({"match_id": mid, "league": lg, "ko": ko, "day_index": d})
        return out

    @staticmethod
    def _n_live(schedule: List[dict]):
        kos = np.array([m["ko"].value for m in schedule], dtype="int64")
        ends = kos + np.int64(FT_END * 60 * 1_000_000_000)

        def count(t_ns: np.ndarray) -> np.ndarray:
            t = t_ns[:, None]
            return ((kos[None, :] <= t) & (ends[None, :] > t)).sum(axis=1)
        return count

    # --------------------------------------------------------------- match
    def _match(self, rng, m: dict, n_live, pool_ids: Dict, line_ids: Dict) -> Dict[str, list]:
        tr = self.truth
        lg = m["league"]
        lg_info = LEAGUES.get(lg, NEW_LEAGUE[1])
        pop = lg_info[1] * float(np.exp(rng.normal(0.0, 0.45)))
        ko = m["ko"]
        mid = m["match_id"]

        tg = float(np.clip(rng.normal(2.65, 0.35), 1.6, 4.2))
        sup = float(np.clip(rng.normal(0.2, 0.7), -1.8, 1.8))
        sup = float(np.clip(sup, -tg + 0.3, tg - 0.3))
        ctg = float(np.clip(rng.normal(9.8, 1.2), 6.5, 14.0))
        csup = float(np.clip(rng.normal(0.6, 1.2), -3.5, 3.5))
        err = rng.normal(0.0, tr.hkjc_theta_sd, size=4) * np.array([1.0, 1.0, 4.0, 4.0])

        wall = np.arange(-PRE_MIN, FT_END + 1)          # minute offsets from kick-off
        n = len(wall)
        # timestamps stay int64 nanoseconds until the dump; Timestamp maths per row is the slow part
        minute_ns = np.int64(ko.value) + wall.astype("int64") * np.int64(60_000_000_000)
        stamps = pd.DatetimeIndex(minute_ns)
        inplay = (wall >= 0) & (wall < FT_END)
        ht_break = (wall >= FH_END) & (wall < HT_END)
        clock = np.where(wall < 0, 0.0, np.where(wall < FH_END, wall.astype(float),
                         np.where(wall < HT_END, 45.0, 45.0 + (wall - HT_END))))
        playing = inplay & ~ht_break

        # --- events, minute by minute
        hg = np.zeros(n, dtype=int)
        ag = np.zeros(n, dtype=int)
        hc = np.zeros(n, dtype=int)
        ac = np.zeros(n, dtype=int)
        reds = np.zeros(n, dtype=int)
        events = []
        lam_h, lam_a = (tg + sup) / 2 / 90.0, (tg - sup) / 2 / 90.0
        cl_h, cl_a = (ctg + csup) / 2 / 90.0, (ctg - csup) / 2 / 90.0
        red_mult = [1.0, 1.0]
        h = a = ch = ca = r = 0
        ht_score = (0, 0)
        ht_corners = (0, 0)
        for i in range(n):
            if playing[i]:
                late = 1.3 if clock[i] > 75 else 1.0
                u = rng.random(6)
                t0 = int(minute_ns[i]) + int(u[5] * 59) * 1_000_000_000
                w_i = int(wall[i])
                if u[0] < lam_h * late * red_mult[0]:
                    h += 1
                    events.append((t0, 27, 1, w_i))
                if u[1] < lam_a * late * red_mult[1]:
                    a += 1
                    events.append((t0, 27, 2, w_i))
                if u[2] < cl_h:
                    ch += 1
                    events.append((t0, 13, 1, w_i))
                if u[3] < cl_a:
                    ca += 1
                    events.append((t0, 13, 2, w_i))
                if u[4] < 0.0022:
                    side = int(rng.integers(1, 3))
                    r += 1
                    red_mult[side - 1] *= 0.7
                    red_mult[2 - side] *= 1.15
                    events.append((t0, 57, side, w_i))
                elif u[4] > 1.0 - 0.035:
                    events.append((t0, 78, int(rng.integers(1, 3)), w_i))
            if wall[i] == FH_END:
                ht_score, ht_corners = (h, a), (ch, ca)
            hg[i], ag[i], hc[i], ac[i], reds[i] = h, a, ch, ca, r
        final = (h, a)
        final_corners = (ch, ca)

        # --- remaining-goal thetas (HKJC and the truth) per wall minute
        remain = np.where(wall < 0, 1.0, np.clip((90.0 - clock) / 90.0, 0.0, 1.0))
        drift = np.clip((wall + PRE_MIN) / PRE_MIN, 0.0, 1.0)          # HKJC learns towards KO
        hk_err = err[None, :] * (1.0 - 0.4 * drift[:, None])
        hk = np.column_stack([(tg + hk_err[:, 0]) * remain, (sup + hk_err[:, 1]) * remain,
                              (ctg + hk_err[:, 2]) * remain, (csup + hk_err[:, 3]) * remain])
        hk[:, 0] = np.maximum(hk[:, 0], 0.02)
        hk[:, 1] = np.clip(hk[:, 1], -hk[:, 0], hk[:, 0])
        hk[:, 2] = np.maximum(hk[:, 2], 0.05)
        hk[:, 3] = np.clip(hk[:, 3], -hk[:, 2], hk[:, 2])
        true_th = np.column_stack([tg * remain, sup * remain, ctg * remain, csup * remain])
        fh_frac = np.where(wall < 0, 0.45, np.clip((45.0 - clock) / np.maximum(90.0 - clock, 1.0), 0, 1))
        fh_frac = np.where(wall >= FH_END, 0.0, fh_frac)

        # --- odds ticks: every 5 min pre-match, every minute in play
        tick = ((wall < 0) & (wall % 5 == 0)) | inplay
        pools_today = [p for p in POOLS if p != "NHILO" or
                       (self.new_pool_day is not None and m["day_index"] >= self.new_pool_day)]

        odds_rows, market_rows, inv_rows, param_rows = [], [], [], []
        sel_state: Dict[tuple, dict] = {}     # (pool, label, side) -> ids + current prices
        concurrency = n_live(minute_ns)
        weekday = stamps.dayofweek.to_numpy()
        hour = stamps.hour.to_numpy()

        current: Dict[str, List[tuple]] = {}    # pool -> list of (label, side, key)
        offered: set = set()
        last_goal_wall = -10_000
        goal_walls = sorted({ev[3] for ev in events if ev[1] == 27})
        red_walls = sorted({ev[3] for ev in events if ev[1] == 57})

        for i in range(n):
            w = int(wall[i])
            if w in goal_walls:
                last_goal_wall = w
            phase = ("prematch" if w < 0 else "first_half" if w < FH_END else
                     "half_time" if w < HT_END else "second_half" if w < FT_END else "finished")
            state = MatchState(home_goals=int(hg[i]), away_goals=int(ag[i]), home_corners=int(hc[i]),
                               away_corners=int(ac[i]), minute=float(clock[i]), phase=phase)
            if phase == "finished":
                break
            if tick[i] or not current:
                hk_theta = {"goal_tg": hk[i, 0], "goal_sup": hk[i, 1], "goal_fh_tg": hk[i, 0] * fh_frac[i],
                            "goal_fh_sup": hk[i, 1] * fh_frac[i], "corner_tg": hk[i, 2],
                            "corner_sup": hk[i, 3], "corner_fh_tg": hk[i, 2] * fh_frac[i],
                            "corner_fh_sup": hk[i, 3] * fh_frac[i]}
                tr_theta = {"goal_tg": true_th[i, 0], "goal_sup": true_th[i, 1],
                            "goal_fh_tg": true_th[i, 0] * fh_frac[i], "goal_fh_sup": true_th[i, 1] * fh_frac[i],
                            "corner_tg": true_th[i, 2], "corner_sup": true_th[i, 3],
                            "corner_fh_tg": true_th[i, 2] * fh_frac[i], "corner_fh_sup": true_th[i, 3] * fh_frac[i]}
                current = self._lines(pools_today, hk_theta, state)
                offered = self._offered(current)
                rows = [(p, lab, s) for p, items in current.items() for lab, s, _ in items]
                if not rows:
                    continue
                book = BookRows([POOLS[p][0] for p, _, _ in rows], [POOLS[p][1] for p, _, _ in rows],
                                [self._line_of(lab) for _, lab, _ in rows], [s for _, _, s in rows])
                p_hk, _ = self.pricer.probabilities(book, hk_theta, state)
                p_tr, _ = self.pricer.probabilities(book, tr_theta, state)
                t_at = int(minute_ns[i])
                jit = rng.integers(0, 50, size=len(rows) * 4) * 1_000_000_000
                tick_rows = []
                feed_sum: Dict[tuple, float] = {}
                for k, (pool, lab, side) in enumerate(rows):
                    if not np.isfinite(p_hk[k]) or p_hk[k] <= 0.01 or p_hk[k] >= 0.99:
                        continue
                    key = (pool, lab, side)
                    st = sel_state.get(key)
                    if st is None:
                        pid = pool_ids.setdefault((mid, pool), 1_600_000_000 + len(pool_ids) + 1)
                        if (pid, lab) not in line_ids:
                            line_ids[(pid, lab)] = line_ids.get(("n", pid), 0) + 1
                            line_ids[("n", pid)] = line_ids[(pid, lab)]
                        st = {"pool_id": pid, "line_id": line_ids[(pid, lab)],
                              "comb_id": {"H": 1, "A": 2, "D": 3}[side]}
                        sel_state[key] = st
                    lo = np.log(p_hk[k] / (1 - p_hk[k]))
                    feed = 1.0 / (1.0 + np.exp(-tr.overconfidence * lo))
                    feed_sum[(pool, lab)] = feed_sum.get((pool, lab), 0.0) + feed
                    sell = max(round(1.0 / p_hk[k] / (1.0 + MARGIN[pool]), 2), 1.01)
                    st.update(p_hk=p_hk[k], p_tr=p_tr[k], sell=sell, at=w, label=lab)
                    tick_rows.append((k, pool, lab, side, st, feed))
                noise = np.exp(rng.normal(0, tr.market_theta_sd, size=(len(rows), len(BOOKMAKERS))))
                for j, (k, pool, lab, side, st, feed) in enumerate(tick_rows):
                    comb = side if POOLS[pool][1] != "total" else ("H" if side == "H" else "L")
                    lab_out = lab if POOLS[pool][1] != "three_way" else None
                    true_odds = round(feed_sum[(pool, lab)] / feed, 3) if feed > 0 else np.nan
                    odds_rows.append((mid, BET_CODE[pool], pool, st["pool_id"], st["line_id"], lab_out,
                                      st["comb_id"], comb, st["sell"], t_at + int(jit[j]), true_odds))
                    if (w < 0 and w % 10 == 0) or (w >= 0 and w % 2 == 0):
                        for b, (bk, bname) in enumerate(BOOKMAKERS):
                            mo = 1.0 / max(p_tr[k] * noise[j, b], 0.02) / 1.04
                            market_rows.append((mid, BET_CODE[pool], st["pool_id"], st["line_id"], lab_out,
                                                st["comb_id"], comb, bk, round(max(mo, 1.01), 2),
                                                t_at + int(jit[len(rows) + j * 3 + b]), bname, pool))
            # params: every 15 min pre-match, every minute in play
            if (w < 0 and w % 15 == 0) or w >= 0:
                param_rows.append(self._param_row(mid, int(minute_ns[i]), clock[i], phase, tg, sup,
                                                  ctg, csup, hk[i], err, rng))

            # --- money this minute
            intensity = (tr.base_per_minute * pop *
                         self._clock_curve(w, clock[i], ht_break[i]) *
                         (1.0 + tr.goal_shock * np.exp(-(w - last_goal_wall) / tr.goal_decay_min)
                          if w >= last_goal_wall >= 0 else 1.0) *
                         (1.0 + 0.8 * np.exp(-(w - red_walls[-1]) / 8.0)
                          if red_walls and 0 <= red_walls[-1] <= w else 1.0) /
                         (1.0 + tr.concurrency * max(int(concurrency[i]) - 1, 0)) *
                         (tr.weekend if weekday[i] >= 5 else 1.0) *
                         (tr.evening if 19 <= hour[i] <= 23 else 1.0))
            # sorted: a set of strings iterates in a per-process hash order, and the money draws follow it
            live = [(key, sel_state[key]) for key in sorted(offered) if key in sel_state]
            if not live:
                continue
            by_pool: Dict[str, list] = {}
            for key, st in live:
                by_pool.setdefault(key[0], []).append((key, st))
            share_pool = {p: (POOLS[p][2] if w < 0 else POOLS[p][3]) for p in by_pool}
            if w >= FH_END:
                share_pool.pop("FHLO", None)
            tot = sum(share_pool.values())
            t_min = int(minute_ns[i])
            for pool, items in by_pool.items():
                if pool not in share_pool or tot <= 0:
                    continue
                pool_money = intensity * share_pool[pool] / tot
                fair_line = self._fair_line(pool, state, true_th[i], fh_frac[i])
                u = []
                for (p, lab, side), st in items:
                    value = st["p_tr"] * st["sell"] - 1.0
                    dist = abs(self._line_of(lab) - fair_line) if fair_line is not None else 0.0
                    pref = (tr.over_pref if side == "H" and POOLS[p][1] == "total" else 0.0) + \
                           (tr.home_pref if side == "H" and POOLS[p][1] != "total" else 0.0)
                    u.append(-tr.kappa_line * dist + tr.beta_value * value + pref)
                u = np.array(u)
                share = np.exp(u - u.max())
                share = share / share.sum()
                lam = pool_money * share / tr.mean_stake
                k_tickets = rng.poisson(lam)
                for j, ((p, lab, side), st) in enumerate(items):
                    if k_tickets[j] <= 0:
                        continue
                    stakes = rng.lognormal(np.log(tr.mean_stake) - tr.stake_sigma ** 2 / 2,
                                           tr.stake_sigma, size=int(k_tickets[j]))
                    turn = float(np.round(np.maximum(stakes, 10.0).sum(), 2))
                    inv_rows.append([st["pool_id"], p, POOL_TYPE[p], mid, st["line_id"], st["comb_id"],
                                     st["comb_id"], turn, st["sell"], int(k_tickets[j]), t_min, lab, side])

        settle = self._settlement(final, final_corners, ht_score, ht_corners)
        return {"odds": odds_rows, "market": market_rows, "inv": inv_rows, "params": param_rows,
                "events": [(mid, t, ty, side) for t, ty, side, _ in events],
                "match": {"match_id": mid, "league": lg, "ko": ko, "final": final, "ht": ht_score,
                          "final_corners": final_corners, "ht_corners": ht_corners,
                          "pop": pop, "theta": (tg, sup, ctg, csup)},
                "settle": settle, "pools": {p: pool_ids[(mid, p)] for p in POOLS if (mid, p) in pool_ids}}

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _line_of(label) -> float:
        s = str(label)
        if "/" in s:
            a, b = s.split("/")
            return (float(a) + float(b)) / 2.0
        return float(s) if s not in ("None", "nan", "") else float("nan")

    @staticmethod
    def _offered(current) -> set:
        return {(p, lab, s) for p, items in current.items() for lab, s, _ in items}

    def _lines(self, pools, th, state: MatchState) -> Dict[str, List[tuple]]:
        """Lines HKJC would offer now: the balanced one and its neighbours."""
        out: Dict[str, List[tuple]] = {}
        goals = state.home_goals + state.away_goals
        diff = state.home_goals - state.away_goals
        corners = state.home_corners + state.away_corners
        cdiff = state.home_corners - state.away_corners
        for p in pools:
            dom, market = POOLS[p][0], POOLS[p][1]
            if dom == "goal_fh" and state.ht_done:
                continue
            if market == "three_way":
                out[p] = [(None, s, None) for s in ("H", "D", "A")]
                continue
            if dom.startswith("corner"):
                base = (corners + th["corner_tg"]) if market == "total" else -(cdiff + th["corner_sup"])
                offsets = (-1.0, 0.0, 1.0) if market == "total" else (0.0,)
            elif dom == "goal_fh":
                base = goals + th["goal_fh_tg"]
                offsets = (0.0, 0.5)
            else:
                base = (goals + th["goal_tg"]) if market == "total" else -(diff + th["goal_sup"])
                offsets = (-0.5, 0.0, 0.5) if market == "total" else (-0.5, 0.0, 0.5)
            main = _quarter(base - (0.25 if market == "total" else 0.0))
            lines = [main + o for o in offsets]
            if market == "total":
                floor = (corners if dom.startswith("corner") else goals) + 0.5
                lines = [x for x in lines if x >= floor]
            out[p] = [(_label(x), s, None) for x in lines for s in ("H", "A")]
        return out

    def _fair_line(self, pool, state: MatchState, th_row, fh_frac):
        dom, market = POOLS[pool][0], POOLS[pool][1]
        if market == "three_way":
            return None
        if dom.startswith("corner"):
            return (state.home_corners + state.away_corners + th_row[2]) if market == "total" else \
                -((state.home_corners - state.away_corners) + th_row[3])
        if dom == "goal_fh":
            return state.home_goals + state.away_goals + th_row[0] * fh_frac
        return (state.home_goals + state.away_goals + th_row[0]) if market == "total" else \
            -((state.home_goals - state.away_goals) + th_row[1])

    @staticmethod
    def _clock_curve(w: int, clock: float, ht_break: bool) -> float:
        if w < 0:
            return 0.12 + 0.88 * float(np.exp(w / 75.0))
        if ht_break:
            return 0.55
        return 1.35 * (1.0 + 0.35 * clock / 90.0) * (0.6 if clock > 91 else 1.0)

    def _param_row(self, mid, t_ns, clock, phase, tg, sup, ctg, csup, hk_row, err, rng):
        gs = {"prematch": "Prematch", "first_half": "FirstHalf", "half_time": "FirstHalf",
              "second_half": "SecondHalf"}[phase]
        secs = int(round(clock * 60))
        return (mid, t_ns + int(rng.integers(0, 50)) * 1_000_000_000, gs, secs,
                int(clock), int(secs % 60),
                tg + err[0], sup + err[1], tg + err[0] * 0.8, sup + err[1] * 0.8,
                float(hk_row[0]), float(hk_row[1]), 1.05, 0.45, 0.555,
                ctg + err[2], csup + err[3], ctg + err[2] * 0.8, csup + err[3] * 0.8,
                float(hk_row[2]), float(hk_row[3]), 0.47, 0.53)

    @staticmethod
    def _settlement(final, final_corners, ht, ht_corners):
        return {"goal": final, "corner": final_corners, "goal_fh": ht, "corner_fh": ht_corners}

    @staticmethod
    def _payout(pool: str, label, side: str, settle: dict, odds: float) -> float:
        dom, market = POOLS[pool][0], POOLS[pool][1]
        h, a = settle[dom]
        if market == "three_way":
            won = "H" if h > a else "A" if h < a else "D"
            return odds if side == won else 0.0
        line = SyntheticWorld._line_of(label)
        if market == "total":
            r = float(settle_matrix(np.array([float(h + a)]), np.array([line]))[0, 0])
        else:
            r = float(settle_matrix(np.array([float(h - a)]), np.array([-line]))[0, 0])
        if side != "H":
            r = -r
        return {1.0: odds, 0.5: 0.5 * odds + 0.5, 0.0: 1.0, -0.5: 0.5, -1.0: 0.0}[round(r * 2) / 2]

    # ----------------------------------------------------------------- write
    def write(self, root) -> dict:
        root = Path(root)
        rng = np.random.default_rng(self.seed)
        for sub in ("HKJC_Odds", "Match_Investments", "Pool_Details", "Match_Information",
                    "HKJC_Parameters", "Match_Events", "Market_Odds"):
            (root / sub).mkdir(parents=True, exist_ok=True)
        schedule = self._schedule(rng)
        n_live = self._n_live(schedule)
        pool_ids: Dict = {}
        line_ids: Dict = {}
        acc = {"odds": [], "market": [], "inv": [], "params": [], "events": [], "matches": [], "pools": []}
        for k, m in enumerate(schedule):
            res = self._match(rng, m, n_live, pool_ids, line_ids)
            settle = res["settle"]
            for row in res["inv"]:
                pid, pool, ptype, mid, lid, cid, oid, turn, odds, tickets, t, lab, side = row
                div = round(turn * self._payout(pool, lab, side, settle, odds), 2)
                acc["inv"].append((pid, pool, ptype, mid, "FB{}".format(mid % 100000),
                                   LEAGUES.get(m["league"], NEW_LEAGUE[1])[0], "H{}".format(mid),
                                   "A{}".format(mid), settle["goal_fh"][0], settle["goal_fh"][1],
                                   settle["goal"][0], settle["goal"][1], m["ko"].normalize(), t, cid,
                                   str(lid), oid, turn, div, round(div * 0.98, 2),
                                   "{}[{}]".format(side, lab) if lab and lab != "None" else side,
                                   odds, tickets))
            acc["odds"].extend(res["odds"])
            acc["market"].extend(res["market"])
            acc["params"].extend(res["params"])
            acc["events"].extend(res["events"])
            info = res["match"]
            acc["matches"].append(info)
            for pool, pid in res["pools"].items():
                close = m["ko"] + pd.Timedelta(minutes=FH_END if pool == "FHLO" else FT_END)
                acc["pools"].append({
                    "pool_id": pid, "pool_name": pool, "pool_status_id": 8, "instance_no": 0,
                    "is_offer": 1, "pool_type": POOL_TYPE[pool], "is_conclude": 1,
                    "start_selling_time": m["ko"] - pd.Timedelta(hours=24), "close_time": close,
                    "odds_type": "F", "match_id": str(m["match_id"]), "league_code": m["league"],
                    "kickoff_date": m["ko"].normalize()})
            if (k + 1) % 50 == 0:
                logger.info("synthetic: %d / %d matches", k + 1, len(schedule))
        summary = self._dump(root, acc)
        truth = self.truth.to_dict()
        truth.update({"matches": len(schedule), "days": self.days, "start": str(self.start.date()),
                      "new_league": NEW_LEAGUE[0], "new_league_day": self.new_league_day,
                      "new_pool": "NHILO", "new_pool_day": self.new_pool_day,
                      "match_pop": {str(i["match_id"]): i["pop"] for i in acc["matches"]}})
        (root.parent / "synthetic_truth.json").write_text(json.dumps(truth, indent=2, default=str),
                                                          encoding="utf-8")
        logger.info("synthetic world written to %s: %s", root, summary)
        return summary

    def _dump(self, root: Path, acc: dict) -> dict:
        odds = pd.DataFrame(acc["odds"], columns=[
            "match_id", "bet_type_code", "EnumString", "pool_id", "line_id", "line_label",
            "combination_id", "combination_string", "odds", "effective_datetime", "true_odds"])
        inv = pd.DataFrame(acc["inv"], columns=[
            "pool_id", "pool_name", "pool_type", "match_id", "frontend_id", "tournament", "h_team",
            "a_team", "ht_home_score", "ht_away_score", "ft_home_score", "ft_away_score",
            "kickoff_date", "start_sell_time", "comb_id", "line_no", "odds_id", "turnover",
            "dividend", "es_dividend", "odds_combination", "odds", "ticket_count"])
        params = pd.DataFrame(acc["params"], columns=[
            "EventLevel2ID", "EventTime", "GameState", "TimeInSecond", "Minutes", "Seconds",
            "Goal90BasisTG", "Goal90BasisSUP", "Goal90ModelTG", "Goal90ModelSUP", "Goal90CurrentTG",
            "Goal90CurrentSUP", "Goal90DrawFactor", "Goal90SecondHalfSplitFH", "Goal90SecondHalfSplitFT",
            "Corner90BasisTG", "Corner90BasisSUP", "Corner90ModelTG", "Corner90ModelSUP",
            "Corner90CurrentTG", "Corner90CurrentSUP", "Corner90SecondHalfSplitFH",
            "Corner90SecondHalfSplitFT"])
        # the real extraction stores the seconds counter as datetime nanoseconds
        params["TimeInSecond"] = pd.to_datetime(params["TimeInSecond"].astype("int64"), unit="ns")
        params["EventTime"] = pd.to_datetime(params["EventTime"].astype("int64"), unit="ns")
        odds["effective_datetime"] = pd.to_datetime(odds["effective_datetime"].astype("int64"), unit="ns")
        inv["start_sell_time"] = pd.to_datetime(inv["start_sell_time"].astype("int64"), unit="ns")
        events = pd.DataFrame(acc["events"], columns=["event_id", "incident_datetime", "incident_type",
                                                      "home_or_away"])
        events["incident_datetime"] = pd.to_datetime(events["incident_datetime"].astype("int64"), unit="ns")
        events["provider_id"] = 1
        dup = events.copy()
        dup["provider_id"] = 7
        dup["incident_datetime"] = dup["incident_datetime"] + pd.Timedelta(seconds=4)
        events = pd.concat([events, dup], ignore_index=True)
        events["is_deleted"] = False
        market = pd.DataFrame(acc["market"], columns=[
            "match_id", "bet_type_code", "pool_id", "line_id", "line_label", "combination_id",
            "combination_string", "bookmaker", "odds", "effective_datetime",
            "bet_type_code_str", "bookmaker_str"])
        market["effective_datetime"] = pd.to_datetime(market["effective_datetime"].astype("int64"), unit="ns")
        matches = pd.DataFrame([{
            "MatchId": i["match_id"], "FrontendID": "FB{}".format(i["match_id"] % 100000),
            "LeagueId": zlib.crc32(i["league"].encode("utf-8")) % 10_000_000, "LeagueCode": i["league"],
            "LeagueName": LEAGUES.get(i["league"], NEW_LEAGUE[1])[0],
            "Country": LEAGUES.get(i["league"], NEW_LEAGUE[1])[2],
            "HomeName": "H{}".format(i["match_id"]), "AwayName": "A{}".format(i["match_id"]),
            "KOTime": i["ko"], "HomeScoreFT": i["final"][0], "AwayScoreFT": i["final"][1],
            "HomeScoreHT": i["ht"][0], "AwayScoreHT": i["ht"][1],
            "HomeCornerFT": i["final_corners"][0], "AwayCornerFT": i["final_corners"][1],
            "HomeCornerHT": i["ht_corners"][0], "AwayCornerHT": i["ht_corners"][1],
            "IsVoid": False} for i in acc["matches"]])
        pools = pd.DataFrame(acc["pools"])

        def month_dump(frame: pd.DataFrame, sub: str, stem: str, tcol: str) -> int:
            if frame.empty:
                return 0
            t = pd.to_datetime(frame[tcol])
            for period, part in frame.groupby(t.dt.to_period("M")):
                nxt = (period + 1).strftime("%Y-%m")
                part.to_parquet(root / sub / "{}_{}_{}.parquet".format(stem, period.strftime("%Y-%m"), nxt),
                                index=False)
            return len(frame)

        n = {
            "odds": month_dump(odds, "HKJC_Odds", "hkjc_odds", "effective_datetime"),
            "market": month_dump(market, "Market_Odds", "market_odds", "effective_datetime"),
            "params": month_dump(params, "HKJC_Parameters", "hkjc_parameters", "EventTime"),
            "events": month_dump(events, "Match_Events", "match_events", "incident_datetime"),
            "matches": month_dump(matches, "Match_Information", "match_information", "KOTime"),
            "pools": month_dump(pools, "Pool_Details", "pool_details", "start_selling_time"),
        }
        inv_t = pd.to_datetime(inv["start_sell_time"])
        for day, part in inv.groupby(inv_t.dt.normalize()):
            nxt = (day + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
            part.to_parquet(root / "Match_Investments" / "match_investments_{}_{}.parquet".format(
                day.strftime("%Y-%m-%d"), nxt), index=False)
        n["investments"] = len(inv)
        return n
