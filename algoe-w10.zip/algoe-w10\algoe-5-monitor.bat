@echo off
REM Algo E - is the champion still good? Accuracy vs last 5 min over the last 7 days,
REM feature drift against training, leagues / pool codes never seen before.
REM Exit code 2 means "finished, with alerts" - read the ALERT lines.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
set "ARGS=%*"
if not "%~1"=="" if exist "%~1\" (set "ALGOE_DATA_DIR=%~1" & set "ARGS=")
python -m algoe monitor %ARGS%
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Healthy.) else if "%CODE%"=="2" (echo Finished with alerts - see above.) else (echo Monitor failed with exit code %CODE%.)
pause
exit /b %CODE%
