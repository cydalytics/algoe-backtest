"""
Step 01 - what is in Raw_Data

Tables, columns (raw -> canonical), time coverage of the window, whether
true odds / dividends / parameters are there, every pool code and how the
taxonomy will treat it (known, or placed by rule), and every league. Reads
parquet metadata plus the two small reference tables, so it takes seconds.

    python scripts/s01_check_data.py --data-dir "S:\\Users\\Yeung\\20260520 Algo E\\Raw_Data"
    python scripts/s01_check_data.py --start 2026-07-01 --end 2026-09-15

Exit code 1 if any check FAILs. Same as: python -m algoe check-data
"""
from _algoe import run

if __name__ == "__main__":
    run("check-data")
