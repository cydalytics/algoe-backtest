@echo off
REM Algo E - the nightly refresh, for Windows Task Scheduler (no pause; returns an exit code).
REM On the 75 days ending yesterday: new panel / feature days, health check, retrain turnover and
REM probability, promote only what beats last 5 minutes and the current champion.
REM
REM Register once (run in an elevated prompt, adjust the folder):
REM     schtasks /Create /TN "AlgoE nightly" /SC DAILY /ST 06:30 /TR "\"D:\AlgoE\algoe-w10\algoe-nightly.bat\""
REM Exit code 0 ok, 1 a step failed, 2 finished with monitor alerts.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe nightly %*
exit /b %ERRORLEVEL%
