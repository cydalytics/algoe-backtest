@echo off
REM Step 3: turnover + belief on every row. No TG/SUP solver.
setlocal
cd /d "%~dp0"
set "DATA=%~1"
if not defined DATA set "DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data"
echo Scoring turnover and belief on every row. TG/SUP solve is 4-optimize.bat.
python -m backtest.run run --data-dir "%DATA%" --out-dir "out" ^
    --start 2026-07-01 --end 2026-09-15
echo.
echo Open out\report.html for WAPE and ECE. Then 4-optimize.bat for TG/SUP lift.
pause
