"""
Theta Optimizer

For one match at one moment, choose the 8-dimensional theta that maximises

    E[GM](theta) = sum_i  T_i(theta) x risk_i x (1 - O_i(theta) x p_i)

    p_i       belief (ProbabilityCalibrator), fixed while theta moves
    O_i       the price we would post at theta
    T_i       money that price attracts over the horizon (TurnoverForecaster,
              nowcast-adjusted in focus mode)
    risk_i    share of a stake actually at risk (pushes / quarter-line halves)

This is project.md's four-step loop: step 1 anchors each pool's volume from
the forecast, step 2 searches theta, step 3 re-runs the demand response at the
candidate prices and renormalises inside the pool, step 4 scores E[GM].

PRICES (settings.optimizer.price_mode):

    delta     O_i(theta) = O_i(now) x p_i(theta_now) / p_i(theta)
              HKJC's posted board moved by our model's relative price change.
              At theta_now it IS the board, so the lift cannot come from a
              margin-table or rounding difference - only from theta.
    absolute  O_i(theta) = fair_i(theta) / (1 + margin_pool); needs the pricer
              to replicate HKJC's board (see the backtest's replication check).

DEMAND (settings.optimizer.demand):

    share_model   money moves between the lines and sides of a pool through
                  the price terms of the GLM selection-share model
                  (softmax with those coefficients)
    fixed         the same with one elasticity on log odds
    none          demand does not react; the solver will then only ever push
                  theta to the edge of its band, which is why it is not default

    and the pool's total money follows its price level (settings.optimizer.volume_response):
    factor exp(-e x money-weighted change in log overround). "neutral" sets e = 1 / margin, the
    elasticity at which HKJC's current margin is the volume-optimal one - without it, raising every
    price's margin would look free, because money only moved between selections.

STAGE 2 (settings.optimizer.weightings): with theta* fixed, a weighting w_i per selection,
O_i = O_i(theta*) x w_i - the desk's sell = fair / (1 + margin) x weighting. Each w within 1 +-
weighting_band (focus: within weighting_max_step of the last one); each line keeps its overround
(weighting_margin_band); no cross-line arbitrage (an over never shorter than the over of a lower
line; handicaps likewise); neighbours on the same side penalised for differing, every w for leaving
1. Solved pool by pool, kept only where it beats stage 1; MatchDecision reports both lifts.

GUARDS: theta stays inside a band around HKJC's own theta and (in focus mode)
within ``max_step`` of the previous recommendation; TG >= |SUP|, first half
<= full match, second half coherent; main-line offers never beat the best
external price; every price inside [min_odds, max_odds] and within
``prob_band`` of HKJC's implied probability. HKJC's theta is always a
candidate, so the answer is never worse than doing nothing.

Goal and corner blocks share no parameter and no pool (demand is normalised
inside a pool), so each is solved as its own small problem.

Change Log:
-----------
2026-09-30      Initialize (replaces optimizer_v2b / backtest optimize / desk optimizer maths)
2026-10-01      Pool volume follows the price level (volume_response); stage 2 per-selection weightings
"""

from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..core.taxonomy import ASIAN, default_taxonomy, resolve_pools
from ..features.catalog import PRICE_FEATURES
from ..pricing.pricer import DIMS, BookPricer, BookRows, Conventions, MatchState, ladder, repair_theta

logger = get_logger(__name__)

try:
    from scipy.optimize import minimize
    HAVE_SCIPY = True
except Exception:                                          # pragma: no cover
    HAVE_SCIPY = False

BLOCKS = {"goal": ("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup"),
          "corner": ("corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup")}
ABS_BOUNDS = {"goal_tg": (0.02, 9.0), "goal_sup": (-5.0, 5.0), "goal_fh_tg": (0.0, 5.0),
              "goal_fh_sup": (-3.0, 3.0), "corner_tg": (0.2, 25.0), "corner_sup": (-10.0, 10.0),
              "corner_fh_tg": (0.0, 14.0), "corner_fh_sup": (-6.0, 6.0)}
PENALTY = 1e4


# =============================================================== demand
@dataclass
class DemandResponse:
    """How a selection's money responds when its price moves, holding its pool's volume."""
    mode: str = "share_model"
    coef: Dict[str, float] = field(default_factory=dict)       # per-unit coefficients on PRICE_FEATURES
    elasticity: float = 1.0                                   # fixed mode, on log odds
    cap: float = 6.0
    volume_mode: str = "neutral"                              # neutral | fixed | none
    volume_elasticity: float = 0.0                            # fixed volume mode

    @classmethod
    def from_forecaster(cls, forecaster, settings) -> "DemandResponse":
        dr = cls._from_forecaster(forecaster, settings)
        dr.volume_mode = settings.optimizer.volume_response
        dr.volume_elasticity = float(settings.optimizer.volume_elasticity)
        return dr

    def volume_factor(self, overround_now: np.ndarray, overround_new: np.ndarray) -> np.ndarray:
        """Multiplier on a pool's money when its (money-weighted) overround moves now -> new."""
        if self.volume_mode == "none":
            return np.ones_like(overround_now)
        d = np.log(np.maximum(overround_new, 1e-9)) - np.log(np.maximum(overround_now, 1e-9))
        if self.volume_mode == "fixed":
            e = np.full_like(overround_now, self.volume_elasticity)
        else:
            e = 1.0 / np.clip(overround_now - 1.0, 0.02, None)        # 1 / margin, at most 50
        return np.exp(np.clip(-e * d, -1.6, 1.6))

    @classmethod
    def _from_forecaster(cls, forecaster, settings) -> "DemandResponse":
        o = settings.optimizer
        if o.demand == "none":
            return cls(mode="none")
        if o.demand == "fixed" or forecaster is None:
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        m = forecaster.models.get(("glm", "selection_share")) if forecaster is not None else None
        if m is None:
            logger.warning("no GLM selection-share model: demand falls back to fixed elasticity %.2f",
                           o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        c = m.coefficients()
        coef = {k: float(c.get(k, 0.0)) for k in PRICE_FEATURES}
        dr = cls(mode="share_model", coef=coef, cap=o.max_elasticity)
        e = dr.elasticity_at(odds=1.9, p_true=0.5, p_mkt=0.5, o_mkt=1.9)
        if e < 0:
            logger.warning("share model says longer prices take LESS money (elasticity %.3f at evens); "
                           "that is reverse causality in the data, not demand - using fixed %.2f instead",
                           e, o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        logger.info("demand response from the share model: price coefficients %s, elasticity at evens %.3f",
                    {k: round(v, 4) for k, v in coef.items()}, e)
        return dr

    def elasticity_at(self, odds, p_true, p_mkt, o_mkt) -> float:
        """d log(money) / d log(odds) at one price."""
        if self.mode == "none":
            return 0.0
        if self.mode == "fixed":
            return self.elasticity
        c = self.coef
        return float(-c.get("imp", 0.0) / odds + c.get("log_odds", 0.0) + c.get("value_true", 0.0) * odds * p_true
                     + c.get("value_mkt", 0.0) * odds * p_mkt + c.get("hk_vs_mkt", 0.0) * odds / o_mkt)

    def log_shift(self, odds_new, odds_now, p_ref, p_mkt, o_mkt) -> np.ndarray:
        """Change in log money per selection when its price moves from odds_now to odds_new."""
        if self.mode == "none":
            return np.zeros_like(odds_new)
        if self.mode == "fixed":
            d = self.elasticity * (np.log(odds_new) - np.log(odds_now))
        else:
            c = self.coef
            d = (c.get("imp", 0.0) * (1.0 / odds_new - 1.0 / odds_now)
                 + c.get("log_odds", 0.0) * (np.log(odds_new) - np.log(odds_now))
                 + c.get("value_true", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_ref)
                 + c.get("value_mkt", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_mkt)
                 + c.get("hk_vs_mkt", 0.0) * np.where(np.isfinite(o_mkt), (odds_new - odds_now) / o_mkt, 0.0))
        return np.clip(d, -self.cap, self.cap)


# ================================================================= book
@dataclass
class MatchBook:
    match_id: int
    rows: BookRows
    pool: np.ndarray
    group: np.ndarray              # pool index: demand is renormalised inside it
    margin: np.ndarray
    demand: np.ndarray             # expected money at the current price, over the horizon
    p_true: np.ndarray
    p_ref: np.ndarray              # HKJC true prob (the value_true feature's reference)
    p_mkt: np.ndarray
    odds_now: np.ndarray
    odds_mkt: np.ndarray
    is_main: np.ndarray
    state: MatchState
    theta_now: Dict[str, float]
    theta_prev: Optional[Dict[str, float]] = None
    keys: Optional[pd.DataFrame] = None
    p_now: Optional[np.ndarray] = None
    risk: Optional[np.ndarray] = None
    w_prev: Optional[np.ndarray] = None           # last stage-2 weighting per row (focus refreshes)
    line_group: Optional[np.ndarray] = None       # index of (pool, line) per row, filled on first use

    @property
    def n(self) -> int:
        return len(self.demand)

    @property
    def total_demand(self) -> float:
        return float(np.nansum(self.demand))


@dataclass
class MatchDecision:
    match_id: int
    status: str
    theta_now: Dict[str, float]
    theta_star: Dict[str, float]
    egm_board: float               # posted board, current demand
    egm_now: float                 # theta_now through the pricing mode (== board in delta mode)
    egm_star: float
    turnover: float
    seconds: float
    n_selections: int
    evaluations: int = 0
    binding: List[str] = field(default_factory=list)
    odds_star: Optional[np.ndarray] = None
    demand_star: Optional[np.ndarray] = None
    per_pool: List[dict] = field(default_factory=list)
    egm_stage1: float = float("nan")              # theta* alone, before the weightings
    weights: Optional[np.ndarray] = None          # stage-2 weighting per selection (1 = none)

    @property
    def lift(self) -> float:
        return self.egm_star - self.egm_board

    @property
    def lift_stage1(self) -> float:
        return (self.egm_stage1 if np.isfinite(self.egm_stage1) else self.egm_star) - self.egm_board

    @property
    def lift_stage2(self) -> float:
        return self.egm_star - self.egm_stage1 if np.isfinite(self.egm_stage1) else 0.0

    @property
    def lift_bps(self) -> float:
        return 1e4 * self.lift / self.turnover if self.turnover > 0 else 0.0

    def to_dict(self) -> dict:
        w = self.weights if self.weights is not None else np.ones(0)
        return {"match_id": self.match_id, "status": self.status, "theta_now": self.theta_now,
                "theta_star": self.theta_star, "egm_board": self.egm_board, "egm_now": self.egm_now,
                "egm_stage1": self.egm_stage1, "egm_star": self.egm_star, "lift": self.lift,
                "lift_stage1": self.lift_stage1, "lift_stage2": self.lift_stage2, "lift_bps": self.lift_bps,
                "turnover": self.turnover, "seconds": self.seconds, "n_selections": self.n_selections,
                "evaluations": self.evaluations, "binding": self.binding, "per_pool": self.per_pool,
                "weights_moved": int(np.sum(np.abs(w - 1.0) > 1e-6)),
                "weight_max_move": float(np.max(np.abs(w - 1.0))) if len(w) else 0.0}


# ============================================================ optimiser
class ThetaOptimizer:
    def __init__(self, settings, demand: Optional[DemandResponse] = None):
        self.settings = settings
        o = settings.optimizer
        self.o = o
        self.pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
        self.demand = demand or DemandResponse(mode=o.demand if o.demand != "share_model" else "fixed",
                                               elasticity=o.fixed_elasticity, cap=o.max_elasticity,
                                               volume_mode=o.volume_response,
                                               volume_elasticity=float(o.volume_elasticity))
        self.price_mode = getattr(o, "price_mode", "delta")

    # ------------------------------------------------------------ pieces
    def prices(self, book: MatchBook, theta: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        p, _ = self.pricer.probabilities(book.rows, theta, book.state)
        if self.price_mode == "delta":
            with np.errstate(divide="ignore", invalid="ignore"):
                odds = book.odds_now * book.p_now / p
        else:
            odds = BookPricer.sell_odds(p, book.margin)
        return odds, p

    def demand_at(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        shift = self.demand.log_shift(np.clip(odds, 1.0001, None), book.odds_now, book.p_ref, book.p_mkt,
                                      book.odds_mkt)
        w = book.demand * np.exp(shift)
        pool_now = _group_sum(book.demand, book.group)
        pool_new = _group_sum(w, book.group)
        T = np.where(pool_new > 0, w * pool_now / np.maximum(pool_new, 1e-12), book.demand)
        if self.demand.volume_mode != "none":
            T = T * self._volume(book, odds)
        return T

    def _volume(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        """Each pool's money multiplier from the change in its lines' overround (money-weighted)."""
        lg = _line_groups(book)
        inv_now = np.where(book.odds_now > 1.0, 1.0 / np.where(book.odds_now > 1.0, book.odds_now, 2.0), 0.0)
        good = np.isfinite(odds) & (odds > 1.0)
        inv_new = np.where(good, 1.0 / np.where(good, odds, 2.0), inv_now)
        sizes = np.bincount(lg, minlength=int(lg.max()) + 1)[lg]
        r_now, r_new = _group_sum(inv_now, lg), _group_sum(inv_new, lg)
        two = sizes >= 2                                  # a lone side has no overround to speak of
        d = np.where(two & (r_now > 0) & (r_new > 0), np.log(np.maximum(r_new, 1e-12) / np.maximum(r_now, 1e-12)), 0.0)
        dem = np.nan_to_num(book.demand)
        tot = np.maximum(_group_sum(dem, book.group), 1e-12)
        pool_d = _group_sum(dem * d, book.group) / tot
        pool_r = np.where(_group_sum(dem * two, book.group) > 0,
                          _group_sum(dem * np.where(two, r_now, 0.0), book.group) /
                          np.maximum(_group_sum(dem * two, book.group), 1e-12), 1.0)
        return self.demand.volume_factor(pool_r, pool_r * np.exp(pool_d))

    def expected_gm(self, book: MatchBook, odds: np.ndarray, demand: Optional[np.ndarray] = None) -> float:
        T = book.demand if demand is None else demand
        return float(np.nansum(T * book.risk * (1.0 - odds * book.p_true)))

    def _violation(self, book: MatchBook, odds: np.ndarray) -> float:
        o = self.o
        v = 0.0
        bad = ~np.isfinite(odds)
        v += float(bad.sum()) * 10.0
        od = np.where(bad, o.min_odds, odds)
        v += float(np.sum(np.maximum(o.min_odds - od, 0.0) ** 2 + np.maximum(od - o.max_odds, 0.0) ** 2 * 1e-4))
        if o.prob_band and o.prob_band > 0:
            gap = np.abs(1.0 / od - 1.0 / book.odds_now) - o.prob_band
            v += float(np.sum(np.maximum(gap, 0.0) ** 2) * 100.0)
        if o.market_cap:
            cap = np.where(np.isfinite(book.odds_mkt), np.maximum(book.odds_mkt, book.odds_now), np.inf)
            over = np.where(book.is_main, np.maximum(od - cap, 0.0), 0.0)
            v += float(np.sum(over ** 2) * 10.0)
        return v

    # -------------------------------------------------------------- solve
    def optimize_match(self, book: MatchBook, mode: str = "sweep") -> MatchDecision:
        started = time.time()
        o = self.o
        th_now = repair_theta(book.theta_now)
        base_odds = book.odds_now
        egm_board = self.expected_gm(book, base_odds)
        if book.total_demand < o.min_match_turnover and mode == "sweep":
            return MatchDecision(book.match_id, "skipped: expected money below min_match_turnover", th_now,
                                 dict(th_now), egm_board, egm_board, egm_board, book.total_demand,
                                 round(time.time() - started, 4), book.n, 0, odds_star=base_odds,
                                 demand_star=book.demand, egm_stage1=egm_board, weights=np.ones(book.n))
        evals = [0]
        free_all = self._free_dims(book)
        theta = dict(th_now)
        odds_now_model, _ = self.prices(book, th_now)
        egm_now = self.expected_gm(book, odds_now_model, self.demand_at(book, odds_now_model))
        binding = []
        for block, dims in BLOCKS.items():
            free = [d for d in dims if d in free_all]
            if not free:
                continue
            # a block's parameters only price its own domain's pools, and demand is
            # renormalised inside a pool, so the block is scored on its rows alone
            sub = _sub_book(book, np.isin(book.rows.theta_domain, [block, block + "_fh"]))
            scale = max(sub.total_demand, 1.0)
            lo, hi = self._bounds(free, th_now, book.theta_prev if mode == "focus" else None)
            # a dimension the money is indifferent to (SUP when everything sits on one total) stays at HKJC's value
            anchor = np.array([th_now[d] for d in free])
            width = np.array([max(float(o.theta_band.get(d, 0.5)), 1e-6) for d in free])
            stay = float(getattr(o, "stay_cost", 0.0))

            def score(vec, free=free, sub=sub, scale=scale, anchor=anchor, width=width):
                th = dict(theta)
                th.update(zip(free, vec))
                th = repair_theta(th)
                odds, _ = self.prices(sub, th)
                evals[0] += 1
                T = self.demand_at(sub, np.where(np.isfinite(odds), odds, sub.odds_now))
                return -self.expected_gm(sub, np.where(np.isfinite(odds), odds, 1.0), T) / scale \
                    + PENALTY * self._violation(sub, odds) + stay * float(np.sum(((vec - anchor) / width) ** 2))

            x0 = np.array([theta[d] for d in free])
            best_x, best_f = x0.copy(), score(x0)
            starts = [x0]
            n_starts = o.starts_focus if mode == "focus" else o.starts_sweep
            if book.theta_prev is not None and mode == "focus":
                starts.insert(0, np.clip([book.theta_prev.get(d, theta[d]) for d in free], lo, hi))
            rng = np.random.default_rng(book.match_id % 100000)
            while len(starts) < n_starts:
                starts.append(lo + rng.random(len(free)) * (hi - lo))
            if HAVE_SCIPY:
                cons = self._coherence(free, theta)
                # a focus refresh starts next to the answer; it must never cost a full solve
                max_iter = min(o.max_iter, 20) if mode == "focus" else o.max_iter
                for s0 in starts[:max(n_starts, 1)]:
                    try:
                        # the objective is E[GM] per $ of demand (~0.1), so 1e-7 is far below a cent per HK$1000
                        res = minimize(score, np.clip(s0, lo, hi), method="SLSQP", bounds=list(zip(lo, hi)),
                                       constraints=cons, options={"maxiter": max_iter, "ftol": 1e-7, "eps": 1e-3})
                    except Exception as exc:                        # noqa: BLE001
                        logger.debug("match %s block %s SLSQP failed: %s", book.match_id, block, exc)
                        continue
                    if np.all(np.isfinite(res.x)) and res.fun < best_f:
                        best_x, best_f = np.clip(res.x, lo, hi), float(res.fun)
            else:
                best_x, best_f = _grid(score, x0, lo, hi)
            for d, v, l, h in zip(free, best_x, lo, hi):
                theta[d] = float(v)
                if min(v - l, h - v) < 1e-4 * max(h - l, 1e-9):
                    binding.append("{}@{}".format(d, "lo" if v - l < h - v else "hi"))
            th_b = repair_theta(theta)
            odds_b, _ = self.prices(sub, th_b)
            if o.prob_band and np.any(np.abs(1.0 / np.where(np.isfinite(odds_b), odds_b, 1.0) - 1.0 / sub.odds_now)
                                      > o.prob_band - 1e-3):
                binding.append("{}:prob_band".format(block))
        theta = repair_theta(theta)
        odds_star, _ = self.prices(book, theta)
        feasible = self._violation(book, odds_star) < 1e-6 and np.all(np.isfinite(odds_star))
        T_star = self.demand_at(book, np.where(np.isfinite(odds_star), odds_star, book.odds_now))
        egm_star = self.expected_gm(book, odds_star, T_star) if feasible else -np.inf
        status = "solved"
        if not feasible or egm_star < egm_board:
            # the board as posted is always available: never recommend something worse
            theta, odds_star, T_star, egm_star = dict(th_now), base_odds.copy(), book.demand.copy(), egm_board
            status = "kept board (no feasible improvement)" if feasible or not np.isfinite(egm_star) else \
                "kept board (infeasible)"
        # stage 2: per-selection weightings on top of theta*, kept only where they beat it
        egm_stage1, weights = egm_star, np.ones(book.n)
        if getattr(o, "weightings", False):
            w = self._stage2(book, odds_star, mode, binding)
            if np.any(np.abs(w - 1.0) > 1e-9):
                odds_w = odds_star * w
                T_w = self.demand_at(book, odds_w)
                egm_w = self.expected_gm(book, odds_w, T_w)
                if self._violation(book, odds_w) < 1e-6 and np.all(np.isfinite(odds_w)) and egm_w > egm_star + 1e-9:
                    odds_star, T_star, egm_star, weights = odds_w, T_w, egm_w, w
                    if status.startswith("kept"):
                        status = "solved (weightings only)"
        dec = MatchDecision(book.match_id, status, th_now, theta, egm_board, egm_now, egm_star,
                            book.total_demand, round(time.time() - started, 4), book.n, evals[0], binding,
                            odds_star, T_star, self._per_pool(book, odds_star, T_star),
                            egm_stage1=egm_stage1, weights=weights)
        return dec

    def _stage2(self, book: MatchBook, odds1: np.ndarray, mode: str, binding: List[str]) -> np.ndarray:
        """Weightings per selection on the stage-1 prices, pool by pool (demand moves inside a pool)."""
        o = self.o
        n = book.n
        w = np.ones(n)
        band = float(getattr(o, "weighting_band", 0.0))
        if not HAVE_SCIPY or n < 2 or band <= 0:
            return w
        lo, hi = np.full(n, 1.0 - band), np.full(n, 1.0 + band)
        start = np.ones(n)
        if mode == "focus" and book.w_prev is not None and len(book.w_prev) == n:
            start = np.clip(np.where(np.isfinite(book.w_prev), book.w_prev, 1.0), lo, hi)
            step = float(o.weighting_max_step)
            lo, hi = np.maximum(lo, start - step), np.minimum(hi, start + step)
        lg = _line_groups(book)
        sizes = np.bincount(lg, minlength=int(lg.max()) + 1)[lg]
        fixed = (sizes < 2) | ~np.isfinite(odds1)          # a lone side, or no price: left alone
        lo[fixed] = hi[fixed] = start[fixed] = 1.0
        margin_band = float(o.weighting_margin_band)
        for pool in np.unique(book.pool):
            rows = np.flatnonzero(book.pool == pool)
            if (~fixed[rows]).sum() < 2:
                continue
            sub = _sub_book(book, book.pool == pool)
            o1, lo_p, hi_p, lgp = odds1[rows], lo[rows], hi[rows], lg[rows]
            cons = []
            for g in np.unique(lgp):
                j = np.flatnonzero(lgp == g)
                if len(j) < 2:
                    continue
                r1 = float(np.sum(1.0 / o1[j]))

                def over(x, j=j, r1=r1):
                    return float(np.sum(1.0 / (o1[j] * x[j]))) - r1
                if margin_band <= 0:
                    cons.append({"type": "eq", "fun": over})
                else:
                    cons.append({"type": "ineq", "fun": lambda x, f=over, r1=r1: f(x) + margin_band * r1})
                    cons.append({"type": "ineq", "fun": lambda x, f=over, r1=r1: margin_band * r1 - f(x)})
            ladder_pairs, neighbours = _ladder(sub, o1)
            for a, b in ladder_pairs:                      # O_a <= O_b keeps the ladder arbitrage-free
                cons.append({"type": "ineq", "fun": lambda x, a=a, b=b: o1[b] * x[b] - o1[a] * x[a]})
            scale = max(sub.total_demand, 1.0)

            def score(x, sub=sub, o1=o1, neighbours=neighbours):
                odds = o1 * x
                T = self.demand_at(sub, odds)
                lx = np.log(np.maximum(x, 1e-9))
                pen = float(o.weighting_ridge) * float(np.sum(lx ** 2))
                if neighbours:
                    pen += float(o.weighting_smoothness) * float(sum((lx[a] - lx[b]) ** 2 for a, b in neighbours))
                return -self.expected_gm(sub, odds, T) / scale + pen + PENALTY * self._violation(sub, odds)

            x0 = np.clip(start[rows], lo_p, hi_p)
            try:
                res = minimize(score, x0, method="SLSQP", bounds=list(zip(lo_p, hi_p)), constraints=cons,
                               options={"maxiter": 20 if mode == "focus" else 60, "ftol": 1e-10, "eps": 1e-5})
            except Exception as exc:                        # noqa: BLE001
                logger.debug("match %s pool %s weightings failed: %s", book.match_id, pool, exc)
                continue
            x = np.clip(res.x, lo_p, hi_p) if np.all(np.isfinite(res.x)) else x0
            held = all(abs(c["fun"](x)) <= 1e-7 if c["type"] == "eq" else c["fun"](x) >= -1e-9 for c in cons)
            if held and score(x) < score(x0) - 1e-12:
                w[rows] = x
                if np.any((np.minimum(x - lo_p, hi_p - x) < 1e-5) & (hi_p - lo_p > 1e-9)):
                    binding.append("{}:weighting_band".format(pool))
        return w

    def _free_dims(self, book: MatchBook) -> List[str]:
        doms = set(book.rows.theta_domain.tolist())
        free = []
        if "goal" in doms:
            free += ["goal_tg", "goal_sup"]
        if "goal_fh" in doms and not book.state.ht_done:
            free += ["goal_fh_tg", "goal_fh_sup"]
        if "corner" in doms:
            free += ["corner_tg", "corner_sup"]
        if "corner_fh" in doms and not book.state.ht_done:
            free += ["corner_fh_tg", "corner_fh_sup"]
        return free

    def _bounds(self, free, th_now, th_prev) -> Tuple[np.ndarray, np.ndarray]:
        lo, hi = [], []
        for d in free:
            a, b = ABS_BOUNDS[d]
            band = float(self.o.theta_band.get(d, 0.5))
            l, h = max(a, th_now[d] - band), min(b, th_now[d] + band)
            if th_prev is not None and d in th_prev:
                step = float(self.o.max_step.get(d, band))
                l, h = max(l, th_prev[d] - step), min(h, th_prev[d] + step)
            if l > h:
                l = h = float(np.clip(th_now[d], a, b))
            lo.append(l)
            hi.append(h)
        return np.array(lo), np.array(hi)

    @staticmethod
    def _coherence(free, theta):
        """Linear coherence constraints on the free dims (the others held at theta)."""
        idx = {d: i for i, d in enumerate(free)}

        def val(x, d):
            return x[idx[d]] if d in idx else theta[d]
        cons = []
        for tg, sup, ftg, fsup in (BLOCKS["goal"], BLOCKS["corner"]):
            if tg in idx or sup in idx:
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) - val(x, sup)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) + val(x, sup)})
            if ftg in idx or fsup in idx:
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) - val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) + val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, f=ftg: val(x, tg) - val(x, f)})
        return cons

    def _per_pool(self, book: MatchBook, odds_star, T_star) -> List[dict]:
        out = []
        for p in np.unique(book.pool):
            m = book.pool == p
            now = float(np.nansum(book.demand[m] * book.risk[m] * (1 - book.odds_now[m] * book.p_true[m])))
            star = float(np.nansum(T_star[m] * book.risk[m] * (1 - odds_star[m] * book.p_true[m])))
            out.append({"pool": str(p), "turnover": float(np.nansum(book.demand[m])), "egm_board": now,
                        "egm_star": star, "lift": star - now})
        return sorted(out, key=lambda r: -r["lift"])

    # --------------------------------------------------------------- card
    def optimize_card(self, books: Sequence[MatchBook], mode: str = "sweep",
                      budget_seconds: Optional[float] = None, workers: Optional[int] = None,
                      on_result=None, key: str = "match") -> Dict[int, MatchDecision]:
        """Richest matches first; stop starting new ones when the budget is spent.

        Returns {match_id: decision}, or {position in ``books``: decision} with
        key="index" (a backtest batch can hold several buckets of one match).
        """
        budget = self.o.budget_seconds if budget_seconds is None else budget_seconds
        order = sorted(range(len(books)), key=lambda i: -books[i].total_demand)
        n_workers = workers if workers is not None else (self.o.workers or min(max((os.cpu_count() or 2) - 1, 1), 8))
        started = time.time()
        out: Dict[int, MatchDecision] = {}

        def label(i):
            return i if key == "index" else books[i].match_id
        if n_workers <= 1 or len(order) <= 2:
            for i in order:
                if budget and time.time() - started > budget:
                    logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out), len(order))
                    break
                out[label(i)] = self.optimize_match(books[i], mode)
                if on_result:
                    on_result(books[i].match_id, out[label(i)])
            return out
        with ProcessPoolExecutor(max_workers=n_workers) as pool:
            futures = {pool.submit(_solve_one, self.settings, self.demand, books[i], mode): i for i in order}
            for fut in as_completed(futures):
                i = futures[fut]
                try:
                    out[label(i)] = fut.result()
                except Exception as exc:                          # noqa: BLE001
                    logger.exception("match %s failed to optimise: %s", books[i].match_id, exc)
                    continue
                if on_result:
                    on_result(books[i].match_id, out[label(i)])
                if budget and time.time() - started > budget:
                    for f in futures:
                        f.cancel()
                    logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out), len(order))
                    break
        return out


def _solve_one(settings, demand, book, mode):
    return ThetaOptimizer(settings, demand).optimize_match(book, mode)


def _sub_book(book: MatchBook, mask: np.ndarray) -> MatchBook:
    m = np.asarray(mask, dtype=bool)
    rows = BookRows(book.rows.theta_domain[m], book.rows.market[m], book.rows.line[m], book.rows.side[m])
    _, group = np.unique(book.group[m], return_inverse=True)

    def cut(a):
        return None if a is None else a[m]
    return MatchBook(book.match_id, rows, book.pool[m], group.astype(int), book.margin[m], book.demand[m],
                     book.p_true[m], book.p_ref[m], book.p_mkt[m], book.odds_now[m], book.odds_mkt[m],
                     book.is_main[m], book.state, book.theta_now, book.theta_prev, None, cut(book.p_now),
                     cut(book.risk), cut(book.w_prev))


def _group_sum(values: np.ndarray, group: np.ndarray) -> np.ndarray:
    s = np.bincount(group, weights=np.nan_to_num(values), minlength=int(group.max()) + 1 if len(group) else 0)
    return s[group]


def _line_groups(book: MatchBook) -> np.ndarray:
    """Index of (pool, line) per row, cached on the book."""
    if book.line_group is None or len(book.line_group) != book.n:
        lines = np.where(np.isfinite(book.rows.line), np.round(book.rows.line * 4.0) / 4.0, -999.0)
        key = np.char.add(np.char.add(book.pool.astype(str), "|"), lines.astype(str))
        book.line_group = np.unique(key, return_inverse=True)[1].astype(int).reshape(-1)
    return book.line_group


def _ladder(book: MatchBook, odds: np.ndarray) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    """For one pool's rows: pairs (a, b) that must keep O_a <= O_b for the ladder of lines to stay free of
    arbitrage - an over is never shorter than the over of a lower line, an under never longer; for a
    home handicap h the home side shortens as h grows, the away side lengthens - kept only where the
    stage-1 prices already obey them; and neighbour pairs (same side, adjacent lines)."""
    order, neighbours = [], []
    lines, sides, markets = book.rows.line, book.rows.side.astype(str), book.rows.market.astype(str)
    for side in np.unique(sides):
        idx = np.flatnonzero((sides == side) & np.isfinite(lines))
        if len(idx) < 2:
            continue
        idx = idx[np.argsort(lines[idx], kind="mergesort")]
        rising = (side == "H") if markets[idx[0]] != "handicap" else (side != "H")
        for a, b in zip(idx[:-1], idx[1:]):
            if lines[a] >= lines[b]:
                continue
            neighbours.append((int(a), int(b)))
            lo, hi = (a, b) if rising else (b, a)          # the price that must be the shorter one first
            if np.isfinite(odds[lo]) and np.isfinite(odds[hi]) and odds[lo] <= odds[hi] + 1e-12:
                order.append((int(lo), int(hi)))
    return order, neighbours


def desk_weightings(book: MatchBook, decision: "MatchDecision", pricer: Optional[BookPricer] = None) -> np.ndarray:
    """The decision's prices in the desk's terms: O / (fair(theta*) / (1 + margin)) per selection."""
    if decision is None or decision.odds_star is None:
        return np.full(book.n, np.nan)
    pricer = pricer or BookPricer()
    p, _ = pricer.probabilities(book.rows, repair_theta(decision.theta_star), book.state)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(p > 0, decision.odds_star * p * (1.0 + book.margin), np.nan)


def _grid(score, x0, lo, hi, steps: int = 9):
    best, best_f = x0.copy(), score(x0)
    span = (hi - lo) / 4.0
    for _ in range(3):
        axes = [np.linspace(max(b - s, l), min(b + s, h), steps) for b, s, l, h in zip(best, span, lo, hi)]
        for pt in np.array(np.meshgrid(*axes)).T.reshape(-1, len(x0)):
            f = score(pt)
            if f < best_f:
                best, best_f = pt.copy(), f
        span /= 3.0
    return best, best_f


# ======================================================= books from rows
def build_books(sel: pd.DataFrame, match: pd.DataFrame, demand: np.ndarray, p_true: np.ndarray,
                settings, taxonomy=None, theta_prev: Optional[Dict[int, Dict[str, float]]] = None,
                weights_prev: Optional[Dict[int, Dict[tuple, float]]] = None) -> List[MatchBook]:
    """MatchBooks for ONE bucket from feature-engineer rows (sel) and match rows.

    ``demand`` and ``p_true`` are aligned to ``sel``. Rows are kept when the
    pool is in scope and priceable, the price is live, and both a belief and
    a demand exist.
    """
    from ..pricing.panel_pricing import hkjc_theta, state_of
    o = settings.optimizer
    s = sel.copy()
    s["_demand"] = np.asarray(demand, dtype="float64")
    s["_p"] = np.asarray(p_true, dtype="float64")
    inplay = s["inplay"].fillna(0).to_numpy(dtype="float64") > 0 if "inplay" in s.columns else np.zeros(len(s), bool)
    age = np.expm1(s["log_odds_age"].to_numpy(dtype="float64")) if "log_odds_age" in s.columns else np.zeros(len(s))
    max_age = np.where(inplay, getattr(o, "max_odds_age_inplay_min", 10.0), getattr(o, "max_odds_age_prematch_min", 90.0))
    names = s["pool_name"].astype(str).str.upper()
    in_scope = set(resolve_pools(o.pools, names.unique(), taxonomy or default_taxonomy()))
    keep = (names.isin(in_scope).to_numpy()
            & s["forecastable"].to_numpy(dtype=bool)
            & s["market"].isin(list(ASIAN)).to_numpy()
            & np.isfinite(s["odds"].to_numpy(dtype="float64")) & (s["odds"].to_numpy(dtype="float64") > 1.0)
            & np.isfinite(s["_p"].to_numpy()) & (s["_p"].to_numpy() > 0) & (s["_p"].to_numpy() < 1)
            & np.isfinite(s["line"].to_numpy(dtype="float64"))
            & (age <= max_age))
    s = s[keep]
    if s.empty:
        return []
    ctx_cols = [c for c in ("match_id", "bucket", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh",
                            "phase", "minute", "home_goals", "away_goals", "home_corners", "away_corners")
                if c in match.columns]
    ctx = match[ctx_cols].drop_duplicates(["match_id", "bucket"]).set_index(["match_id", "bucket"])
    pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
    books = []
    for (mid, b), g in s.groupby(["match_id", "bucket"], sort=False):
        if (mid, b) not in ctx.index:
            continue
        r = ctx.loc[(mid, b)].to_dict()
        st = state_of(r)
        th = hkjc_theta(r, st)
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        p_now, risk = pricer.probabilities(rows, repair_theta(th), st)
        ok = np.isfinite(p_now) & (p_now > 1e-6)
        if not ok.any():
            continue
        g = g[ok]
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        pools = g["pool_name"].astype(str).to_numpy()
        _, group = np.unique(pools, return_inverse=True)
        margin = np.array([settings.margin_for(p) for p in pools])
        wp = (weights_prev or {}).get(int(mid))
        w_prev = None if not wp else np.array([wp.get((int(a), int(b), int(c)), 1.0) for a, b, c in zip(
            g["pool_id"], g["line_id"], g["combination_id"])], dtype="float64")
        books.append(MatchBook(
            match_id=int(mid), rows=rows, pool=pools, group=group.astype(int), margin=margin,
            demand=np.clip(g["_demand"].to_numpy(dtype="float64"), 0, None), p_true=g["_p"].to_numpy(dtype="float64"),
            p_ref=g["p_hkjc_true"].to_numpy(dtype="float64") if "p_hkjc_true" in g.columns else np.full(len(g), np.nan),
            p_mkt=g["p_market"].to_numpy(dtype="float64") if "p_market" in g.columns else np.full(len(g), np.nan),
            odds_now=g["odds"].to_numpy(dtype="float64"),
            odds_mkt=g["mkt_odds"].to_numpy(dtype="float64") if "mkt_odds" in g.columns else np.full(len(g), np.nan),
            is_main=(g["rank_0"].to_numpy(dtype="float64") > 0) if "rank_0" in g.columns else np.ones(len(g), bool),
            state=st, theta_now=th, theta_prev=(theta_prev or {}).get(int(mid)),
            keys=g[["pool_id", "line_id", "combination_id", "match_id", "pool_name", "bucket"]].reset_index(drop=True),
            p_now=p_now[ok], risk=risk[ok], w_prev=w_prev))
    return books


def publish_odds(odds: np.ndarray) -> np.ndarray:
    """The ladder-rounded prices a trader would actually post."""
    return np.array([ladder(float(o)) if np.isfinite(o) else np.nan for o in odds])
