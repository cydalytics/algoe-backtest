"""Train a turnover model on Backtest_Data and write it back as a new series.

Reads, per day, the files the backtest already wrote:

    Backtest_Data/index/YYYY-MM-DD.parquet             one row per selection-bucket
    Backtest_Data/Turnover/actual/YYYY-MM-DD.parquet   turnover in the bucket
    Backtest_Data/Turnover/last5min/YYYY-MM-DD.parquet turnover in the bucket before

Writes one file per day, same rows in the same order as the index:

    Backtest_Data/Turnover/<name>/YYYY-MM-DD.parquet   column "value"

Open cached again and ``<name>`` is a choice next to last 5 min.

Walk-forward: day N is predicted by a fit on days before N only. Until
``--warmup-days`` days have been seen, the written value is last 5 min, so the
early days compare as a tie instead of dropping out.

Any other model can be dropped in the same way: one parquet per day with a
"value" column, row i matching row i of the index file for that day.

    python -m src.backtest.parquet.train_turnover --root "S:\\Users\\Yeung\\20260520 Algo E\\Backtest_Data"
    python -m src.backtest.parquet.train_turnover selftest
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

STEP = pd.Timedelta(minutes=5)
ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)

POOLS = ("HILO", "HDC", "CHLO", "CHDC", "HAD", "FHAD", "FHILO", "FHLO", "FHDC", "SGA")
CLOCK = ("pre", "00-15", "15-30", "30-45", "ht", "45-60", "60-75", "75-90", "90+", "ft")
WINDOWS = ("prematch", "quiet", "post_goal_5", "post_goal_15", "post_corner_5")

INDEX_COLS = ["as_of", "label_key", "match_id", "pool_code", "clock_bin",
              "event_window", "is_main_line", "minutes_since_goal",
              "hkjc_true_odds", "sell_odds"]


def wape(y, yhat) -> float:
    y = np.asarray(y, dtype="float64")
    d = float(np.abs(y).sum())
    return float(np.abs(y - np.asarray(yhat, dtype="float64")).sum()) / d if d > 0 else float("nan")


# ------------------------------------------------------------------ files
def _value(root: Path, family: str, name: str, day: str, n: int) -> np.ndarray:
    path = root / family / name / "{}.parquet".format(day)
    if not path.exists():
        raise FileNotFoundError(path)
    v = pd.read_parquet(path)["value"].to_numpy(dtype="float64")
    if len(v) != n:
        raise RuntimeError("{} has {} rows, index has {}".format(path, len(v), n))
    return v


def load_day(root: Path, day: str) -> pd.DataFrame:
    idx = pd.read_parquet(root / "index" / "{}.parquet".format(day))
    have = [c for c in INDEX_COLS if c in idx.columns]
    f = idx[have].copy()
    n = len(f)
    f["y"] = np.nan_to_num(_value(root, "Turnover", "actual", day, n))
    f["last5"] = np.nan_to_num(_value(root, "Turnover", "last5min", day, n))
    f["as_of"] = pd.to_datetime(f["as_of"])
    return f


def write_day(root: Path, name: str, day: str, values: np.ndarray) -> Path:
    path = root / "Turnover" / name / "{}.parquet".format(day)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    pd.DataFrame({"value": np.asarray(values, dtype="float32")}).to_parquet(tmp, index=False)
    tmp.replace(path)
    return path


def days_in(root: Path) -> List[str]:
    folder = root / "index"
    if not folder.is_dir():
        raise SystemExit("no {} yet. Open cached in the backtest first, then run this.".format(folder))
    days = sorted(p.stem for p in folder.glob("*.parquet"))
    if not days:
        raise SystemExit("{} is empty".format(folder))
    return days


# --------------------------------------------------------------- features
def add_lags(f: pd.DataFrame, prev: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Turnover 10 and 15 minutes back, from rows already on disk.

    The index keeps every row that took money, so a missing row means zero.
    ``prev`` is the previous day's rows, for buckets just after midnight.
    """
    hist = f[["label_key", "as_of", "y"]]
    if prev is not None and not prev.empty:
        hist = pd.concat([prev[["label_key", "as_of", "y"]], hist], ignore_index=True)
    hist = hist.groupby(["label_key", "as_of"], observed=True, as_index=False)["y"].sum()
    for k, col in ((2, "lag2"), (3, "lag3")):
        h = hist.rename(columns={"y": col})
        h["as_of"] = h["as_of"] + k * STEP
        f = f.merge(h, on=["label_key", "as_of"], how="left")
        f[col] = f[col].fillna(0.0)
    return f


def design(f: pd.DataFrame) -> np.ndarray:
    l1 = np.log1p(np.clip(f["last5"].to_numpy(dtype="float64"), 0, None))
    l2 = np.log1p(np.clip(f["lag2"].to_numpy(dtype="float64"), 0, None))
    l3 = np.log1p(np.clip(f["lag3"].to_numpy(dtype="float64"), 0, None))
    true = pd.to_numeric(f.get("hkjc_true_odds"), errors="coerce").to_numpy(dtype="float64")
    sell = pd.to_numeric(f.get("sell_odds"), errors="coerce").to_numpy(dtype="float64")
    odds = np.where(np.isfinite(true) & (true > 1), true, sell)
    odds = np.where(np.isfinite(odds) & (odds > 1), odds, 2.0)
    key = ["match_id", "as_of"]
    match_last5 = f.groupby(key, observed=True)["last5"].transform("sum").to_numpy(dtype="float64")
    board_last5 = f.groupby("as_of", observed=True)["last5"].transform("sum").to_numpy(dtype="float64")
    share = np.where(match_last5 > 0, f["last5"].to_numpy(dtype="float64") / np.maximum(match_last5, 1e-9), 0.0)
    goal = pd.to_numeric(f.get("minutes_since_goal"), errors="coerce").to_numpy(dtype="float64")
    goal = np.where(np.isfinite(goal), np.clip(goal, 0, 90), 90.0) / 90.0
    main = f["is_main_line"].fillna(False).astype(float).to_numpy() if "is_main_line" in f.columns \
        else np.zeros(len(f))
    cols = [
        np.ones(len(f)), l1, l2, l3, l1 - l2, (l1 > 0).astype(float),
        np.log(odds), np.log1p(match_last5), np.log1p(board_last5), share, goal, main,
    ]
    pool = f["pool_code"].astype(str).to_numpy() if "pool_code" in f.columns else np.array([""] * len(f))
    clock = f["clock_bin"].astype(str).to_numpy() if "clock_bin" in f.columns else np.array([""] * len(f))
    win = f["event_window"].astype(str).to_numpy() if "event_window" in f.columns else np.array([""] * len(f))
    cols += [(pool == p).astype(float) for p in POOLS]
    cols += [(clock == c).astype(float) for c in CLOCK]
    cols += [(win == w).astype(float) for w in WINDOWS]
    return np.nan_to_num(np.column_stack(cols), nan=0.0, posinf=0.0, neginf=0.0)


# ------------------------------------------------------------------ model
class LogRidge:
    """log1p(turnover) on the design, blended toward last 5 min by alpha."""

    def __init__(self, lam: float = 1.0):
        self.lam = float(lam)
        self.beta: Optional[np.ndarray] = None
        self.mean = None
        self.std = None
        self.smear = 1.0
        self.alpha = 0.0

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        self.mean = x.mean(axis=0)
        self.std = x.std(axis=0)
        self.mean[0], self.std[0] = 0.0, 1.0
        self.std[self.std < 1e-8] = 1.0
        z = (x - self.mean) / self.std
        t = np.log1p(np.clip(y, 0, None))
        pen = self.lam * np.eye(z.shape[1])
        pen[0, 0] = 0.0
        self.beta = np.linalg.solve(z.T @ z + pen, z.T @ t)
        resid = t - z @ self.beta
        # log fits aim at the median. This puts the level back on the mean.
        self.smear = float(np.clip(np.mean(np.exp(resid)), 0.5, 5.0))

    def level(self, x: np.ndarray) -> np.ndarray:
        z = (x - self.mean) / self.std
        return np.clip(np.expm1(np.clip(z @ self.beta, 0, 25)) * self.smear, 0, None)

    def predict(self, x: np.ndarray, last5: np.ndarray) -> np.ndarray:
        lag = np.clip(last5, 0, None)
        if self.beta is None or self.alpha <= 0:
            return lag
        return self.alpha * self.level(x) + (1 - self.alpha) * lag

    def pick_alpha(self, x: np.ndarray, y: np.ndarray, last5: np.ndarray) -> dict:
        lag = np.clip(last5, 0, None)
        lev = self.level(x)
        scores = {str(a): wape(y, a * lev + (1 - a) * lag) for a in ALPHAS}
        best = min(ALPHAS, key=lambda a: scores[str(a)] if np.isfinite(scores[str(a)]) else np.inf)
        self.alpha = float(best) if scores[str(best)] < scores["0.0"] - 1e-6 else 0.0
        return scores


def _refit(store: List[dict], inner_days: int) -> Tuple[LogRidge, dict]:
    inner_n = min(inner_days, max(len(store) - 1, 0))
    fit = store[:len(store) - inner_n] or store
    inner = store[len(store) - inner_n:] if inner_n else []
    m = LogRidge()
    m.fit(np.concatenate([d["x"] for d in fit]), np.concatenate([d["y"] for d in fit]))
    scores = {}
    if inner:
        scores = m.pick_alpha(np.concatenate([d["x"] for d in inner]),
                              np.concatenate([d["y"] for d in inner]),
                              np.concatenate([d["last5"] for d in inner]))
    return m, {"fit_days": len(fit), "inner_days": len(inner), "alpha": m.alpha, "inner_wape": scores}


# -------------------------------------------------------------------- run
def run(root: Path, name: str = "ridge", warmup_days: int = 14, inner_days: int = 7,
        refit_every: int = 7, per_day: int = 40000, seed: int = 7) -> dict:
    root = Path(root)
    days = days_in(root)
    rng = np.random.default_rng(seed)
    model: Optional[LogRidge] = None
    store: List[dict] = []
    since = 0
    prev = None
    log, daily = [], []
    tot = {"y": 0.0, "p": 0.0, "m": 0.0}
    for day in days:
        f = load_day(root, day)
        n = len(f)
        f = add_lags(f, prev)
        if len(f) != n:
            raise RuntimeError("{}: lag join changed the row count".format(day))
        x = design(f)
        last5 = f["last5"].to_numpy(dtype="float64")
        y = f["y"].to_numpy(dtype="float64")

        pred = model.predict(x, last5) if model is not None else np.clip(last5, 0, None)
        write_day(root, name, day, pred)
        if model is not None:
            tot["y"] += float(np.abs(y).sum())
            tot["p"] += float(np.abs(y - last5).sum())
            tot["m"] += float(np.abs(y - pred).sum())
            daily.append({"day": day, "wape_last5": wape(y, last5), "wape_model": wape(y, pred)})
            print("[score] {} last5={:.1%} {}={:.1%}".format(day, daily[-1]["wape_last5"], name,
                                                        daily[-1]["wape_model"]), flush=True)
        else:
            print("[warmup] {} rows={:,} (wrote last 5 min)".format(day, n), flush=True)

        take = rng.choice(n, size=min(per_day, n), replace=False) if n else np.array([], dtype=int)
        store.append({"x": x[take].astype("float32"), "y": y[take].astype("float32"),
                      "last5": last5[take].astype("float32")})
        since += 1
        if len(store) >= warmup_days and (model is None or since >= refit_every):
            model, info = _refit(store, inner_days)
            info["after"] = day
            log.append(info)
            since = 0
            print("[fit] after {} days alpha={}".format(len(store), model.alpha), flush=True)
        cutoff = f["as_of"].max() - 3 * STEP
        prev = f.loc[f["as_of"] > cutoff, ["label_key", "as_of", "y"]]

    report = {
        "name": name, "days": len(days), "warmup_days": warmup_days,
        "scored_days": len(daily),
        "wape_last5": tot["p"] / tot["y"] if tot["y"] else None,
        "wape_model": tot["m"] / tot["y"] if tot["y"] else None,
        "refits": log, "daily": daily,
    }
    out = root / "Turnover" / name / "_report.json"
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    if report["wape_model"] is None:
        print("[result] nothing scored yet: {} day(s), warm-up is {}".format(len(days), warmup_days))
    else:
        print("[result] scored {} day(s): last5 {:.1%}  {} {:.1%}".format(
            len(daily), report["wape_last5"], name, report["wape_model"]))
    print("[out] {}".format(out.parent))
    return report


# --------------------------------------------------------------- selftest
def _fail(msg: str) -> None:
    raise SystemExit("[train_turnover selftest] FAIL: " + msg)


def selftest() -> None:
    import tempfile
    from .book import _load_day

    rng = np.random.default_rng(5)
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        root = base / "Backtest_Data"
        days = ["2026-07-{:02d}".format(d) for d in range(1, 21)]
        for d, day in enumerate(days):
            buckets = pd.date_range(day + " 19:00", periods=24, freq="5min")
            rows = []
            level = {k: float(rng.uniform(200, 4000)) for k in range(12)}
            prev = {k: 0.0 for k in level}
            for b in buckets:
                for k, lvl in level.items():
                    # money arrives on and off; its size follows the selection's level
                    y = lvl * rng.uniform(0.7, 1.3) if rng.random() < 0.55 else 0.0
                    rows.append({"as_of": b, "label_key": "1:HILO:{}:{}".format(k // 2, k % 2 + 1),
                                 "match_id": 1, "pool_code": "HILO", "clock_bin": "pre",
                                 "event_window": "prematch", "is_main_line": k < 2,
                                 "minutes_since_goal": np.nan, "hkjc_true_odds": 1.9,
                                 "sell_odds": 1.8, "y": y, "last5": prev[k]})
                    prev[k] = y
            f = pd.DataFrame(rows)
            (root / "index").mkdir(parents=True, exist_ok=True)
            f.drop(columns=["y", "last5"]).to_parquet(root / "index" / "{}.parquet".format(day), index=False)
            write_day(root, "actual", day, f["y"])
            write_day(root, "last5min", day, f["last5"])
            for fam in ("True_Prob",):
                for nm in ("actual", "inverse_hkjc_true_odds"):
                    p = root / fam / nm / "{}.parquet".format(day)
                    p.parent.mkdir(parents=True, exist_ok=True)
                    pd.DataFrame({"value": np.full(len(f), 0.5, dtype="float32")}).to_parquet(p, index=False)

        rep = run(root, "ridge", warmup_days=8, inner_days=3, refit_every=4, per_day=5000)
        if rep["wape_model"] is None:
            _fail("nothing scored")
        if not rep["wape_model"] < rep["wape_last5"]:
            _fail("model {:.3f} did not beat last5 {:.3f}".format(rep["wape_model"], rep["wape_last5"]))
        for day in days:
            if not (root / "Turnover" / "ridge" / "{}.parquet".format(day)).exists():
                _fail("missing output for " + day)
        # the backtest reader must pick the new folder up as a turnover model
        class Cache:
            root = base
            cfg = None
        frame = _load_day(Cache(), days[-1])
        if "t_hat__ridge" not in frame.columns:
            _fail("backtest did not see Turnover/ridge")
        if not np.isfinite(frame["t_hat__ridge"]).all():
            _fail("written forecast has gaps")
        # warm-up days are last 5 min, so nothing drops out of a comparison
        first = _load_day(Cache(), days[0])
        if not np.allclose(first["t_hat__ridge"], first["t5m"]):
            _fail("warm-up forecast is not last 5 min")
    print("[train_turnover selftest] PASS", flush=True)


def main(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", nargs="?", default="train", choices=["train", "selftest"])
    p.add_argument("--root", default=r"S:\Users\Yeung\20260520 Algo E\Backtest_Data")
    p.add_argument("--name", default="ridge", help="folder name under Turnover, and the name in the backtest")
    p.add_argument("--warmup-days", type=int, default=14)
    p.add_argument("--inner-days", type=int, default=7)
    p.add_argument("--refit-every", type=int, default=7)
    p.add_argument("--per-day", type=int, default=40000)
    a = p.parse_args(argv)
    if a.command == "selftest":
        selftest()
        return
    run(Path(a.root), a.name, a.warmup_days, a.inner_days, a.refit_every, a.per_day)


if __name__ == "__main__":
    main()
