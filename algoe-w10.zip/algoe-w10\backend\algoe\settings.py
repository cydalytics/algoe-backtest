"""
Settings

Every knob Algo E has, in one place, grouped by the layer that reads it.
Nothing else in the library holds a tunable constant.

Precedence, lowest to highest:

    1. the defaults below
    2. a JSON settings file   (--settings PATH, or env ALGOE_SETTINGS)
    3. environment            (ALGOE_DATA_DIR, ALGOE_WORK_DIR)
    4. command line           (--set optimizer.theta_band.goal_tg=0.8, repeatable)

``Settings.save`` writes the resolved result next to every run's output, so
any number in a report can be traced back to exactly the settings that made
it.

Paths default to folders BESIDE Raw_Data, never inside the code folder: the
parquet and everything derived from it stay on the office box, and a code
update (unzip over the old folder) never touches trained models.

    <Algo E>/Raw_Data              the extraction output (read only)
    <Algo E>/algoe_panel_cache     the W06 per-day panel cache (shared)
    <Algo E>/Backtest_Data         the workbench's series folders (shared)
    <Algo E>/AlgoE_Work            this library: models, features, reports, logs

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Paths made absolute in check(); monitor.drift_skip_groups; panel.pools by rule (default
                line markets + 1X2); window.val_start / test_start; max_fit_rows caps
"""

from __future__ import annotations

import copy
import json
import os
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .core.exceptions import ConfigError

DEFAULT_DATA_DIR = r"S:\Users\Yeung\20260520 Algo E\Raw_Data"


@dataclass
class PathSettings:
    data_dir: str = DEFAULT_DATA_DIR
    work_dir: str = ""              # default <data_dir>/../AlgoE_Work
    panel_cache_dir: str = ""       # default <data_dir>/../algoe_panel_cache
    backtest_data_dir: str = ""     # default <data_dir>/../Backtest_Data
    pool_overrides: str = ""        # default <work_dir>/config/pools.json
    holidays_file: str = ""         # default <work_dir>/config/holidays.txt

    def _base(self) -> Path:
        # abspath, not resolve(): resolve() turns the mapped S: drive into its UNC path
        return Path(os.path.abspath(os.path.expanduser(self.data_dir))).parent

    @property
    def work(self) -> Path:
        return Path(self.work_dir) if self.work_dir else self._base() / "AlgoE_Work"

    @property
    def panel_cache(self) -> Path:
        return Path(self.panel_cache_dir) if self.panel_cache_dir else self._base() / "algoe_panel_cache"

    @property
    def backtest_data(self) -> Path:
        return Path(self.backtest_data_dir) if self.backtest_data_dir else self._base() / "Backtest_Data"

    @property
    def models(self) -> Path:
        return self.work / "models"

    @property
    def features(self) -> Path:
        return self.work / "features"

    @property
    def reports(self) -> Path:
        return self.work / "reports"

    @property
    def logs(self) -> Path:
        return self.work / "logs"

    @property
    def monitor(self) -> Path:
        return self.work / "monitor"

    @property
    def pools_file(self) -> Path:
        return Path(self.pool_overrides) if self.pool_overrides else self.work / "config" / "pools.json"

    @property
    def holidays(self) -> Path:
        return Path(self.holidays_file) if self.holidays_file else self.work / "config" / "holidays.txt"


@dataclass
class WindowSettings:
    """Which days are used for what. Splits are by calendar day, never random.

    By dates (both set): train [start, val_start), val [val_start, test_start), test
    [test_start, end]. Otherwise by counts: the last test_days days with data are test,
    the val_days before them val, the rest train."""
    start: str = "2026-07-01"
    end: str = "2026-09-15"
    val_start: str = ""             # e.g. "2025-07-01"
    test_start: str = ""            # e.g. "2026-07-01"
    val_days: int = 7               # just before the test block: model choice, blend weight
    test_days: int = 14             # last days: touched once, for the reported numbers
    min_train_days: int = 14
    walk_forward_warmup_days: int = 14
    walk_forward_refit_days: int = 7


@dataclass
class PanelSettings:
    """Knobs that shape the cached panel. Changing one opens a new cache space."""
    bucket_minutes: int = 5
    # Pool codes, or rules matched against what each code is (core/taxonomy.py POOL_RULES), so a new
    # code joins on the day it appears. Default: every goal / corner total and handicap (what theta
    # prices) plus 1X2 (the match's main money). [] = every pool in the feed - correct score, scorer
    # and next-goal pools too, which is several times the rows.
    pools: List[str] = field(default_factory=lambda: ["@line_markets", "@three_way"])
    prematch_window_min: int = 360
    lookback_days: int = 2
    true_prob_source: str = "auto"
    normalize_book: bool = True
    hdc_sign: str = "home"                           # home | flip


@dataclass
class FeatureSettings:
    lag_buckets: int = 6
    ewma_alpha: float = 0.5
    goal_pulse_taus: List[float] = field(default_factory=lambda: [3.0, 10.0])
    red_pulse_tau: float = 10.0
    ko_knots: List[float] = field(default_factory=lambda: [0, 5, 10, 15, 30, 45, 60, 90, 120, 180, 240, 360])
    minute_knots: List[float] = field(default_factory=lambda: [5, 15, 30, 40, 45, 50, 60, 70, 80, 88, 95])
    # empirical-Bayes strength: evidence needed before a group moves halfway from its parent
    league_prior: float = 50.0       # match-buckets
    pool_prior: float = 300.0        # selection-buckets
    match_prior: float = 4.0         # buckets, for the in-day match effect
    match_prior_new_league: float = 1.5


@dataclass
class TurnoverSettings:
    responses: List[str] = field(default_factory=lambda: [
        "match_total", "pool_share", "selection_share", "selection_turnover"])
    algorithms: List[str] = field(default_factory=lambda: ["naive", "glm", "gam", "gbm", "nn"])
    # composed selection forecasts that get a leaderboard row
    pipelines: List[str] = field(default_factory=lambda: [
        "last5", "ma3", "ema",
        "direct:glm", "direct:gbm",
        "three_stage:glm+glm+glm", "three_stage:gam+glm+glm", "three_stage:gbm+gbm+gbm",
        "three_stage:gbm+glm+glm",
    ])
    tweedie_power: float = 1.5
    ridge: float = 1e-3
    fit_rows_per_day: int = 60000           # selection rows sampled per training day
    max_fit_rows: int = 2_000_000           # per response and role over all days; the daily sample shrinks to fit
    blend_alphas: List[float] = field(default_factory=lambda: [0.0, 0.25, 0.5, 0.75, 1.0])
    selection_metric: str = "poisson_deviance"   # what picks the champion
    gam_knots: int = 8
    gam_lambdas: List[float] = field(default_factory=lambda: [0.1, 1.0, 10.0])
    gbm: Dict[str, Any] = field(default_factory=lambda: {
        "n_estimators": 400, "learning_rate": 0.05, "num_leaves": 31,
        "min_child_samples": 200, "subsample": 0.8, "colsample_bytree": 0.8,
        "reg_lambda": 1.0, "early_stopping_rounds": 40})
    nn: Dict[str, Any] = field(default_factory=lambda: {
        "hidden": [64, 32], "dropout": 0.1, "epochs": 30, "batch_size": 4096,
        "lr": 2e-3, "patience": 4})
    seed: int = 7


@dataclass
class ProbabilitySettings:
    sources: List[str] = field(default_factory=lambda: ["hkjc_true", "market", "poisson", "demargin"])
    methods: List[str] = field(default_factory=lambda: [
        "raw", "platt", "beta", "isotonic", "logit_pool", "contextual"])
    # How settled rows are weighted when a calibrator is fitted:
    #   selection - every settled selection counts once, however long it traded
    #   money     - weighted by turnover, i.e. calibrate where the money is
    weight: str = "selection"
    ridge: float = 1.0
    min_fit_rows: int = 200
    max_fit_rows: int = 2_000_000           # settled selections per role over all days
    min_market_books: int = 1
    champion_metric: str = "log_loss"


@dataclass
class OptimizerSettings:
    # trust region around HKJC's own theta for this bucket
    theta_band: Dict[str, float] = field(default_factory=lambda: {
        "goal_tg": 0.60, "goal_sup": 0.50, "goal_fh_tg": 0.35, "goal_fh_sup": 0.30,
        "corner_tg": 2.00, "corner_sup": 1.50, "corner_fh_tg": 1.20, "corner_fh_sup": 0.90})
    # largest move from the previous recommendation in one focus refresh
    max_step: Dict[str, float] = field(default_factory=lambda: {
        "goal_tg": 0.15, "goal_sup": 0.15, "goal_fh_tg": 0.10, "goal_fh_sup": 0.10,
        "corner_tg": 0.50, "corner_sup": 0.40, "corner_fh_tg": 0.30, "corner_fh_sup": 0.25})
    # delta: HKJC's posted odds moved by our model's relative price change (lift = theta edge only)
    # absolute: our pricer + margin table (needs the replication check to pass)
    price_mode: str = "delta"
    # a line whose price has not moved for this long is treated as withdrawn
    max_odds_age_prematch_min: float = 90.0
    max_odds_age_inplay_min: float = 10.0
    min_odds: float = 1.01
    max_odds: float = 500.0
    prob_band: float = 0.05          # |1/our odds - 1/HKJC odds| cap per selection; 0 = off
    market_cap: bool = True          # main-line offer may not beat the best external price
    # demand response to price: share_model (turnover share model's price terms),
    # fixed (t' = t * (O'/O)^elasticity, renormalised in the pool) or none
    demand: str = "share_model"
    fixed_elasticity: float = 1.0
    max_elasticity: float = 6.0
    starts_sweep: int = 3
    starts_focus: int = 1
    max_iter: int = 60
    min_match_turnover: float = 500.0   # expected money below this: keep HKJC theta, skip the solve
    budget_seconds: float = 200.0       # full sweep wall clock
    workers: int = 0                    # 0 = min(cpu - 1, 8)
    pools: List[str] = field(default_factory=lambda: ["HILO", "HDC", "CHLO", "CHDC", "FHLO", "FHDC"])
    # In play, does a line settle on the whole match (goals already scored count)
    # or only on goals from here on? Per market; the replication check tests both.
    settle_total: str = "full_match"      # full_match | rest_of_match
    settle_handicap: str = "full_match"
    draw_factor: bool = True             # use Goal90DrawFactor when the feed has it
    margins: Dict[str, float] = field(default_factory=lambda: {
        "HILO": 0.075, "HDC": 0.075, "CHLO": 0.10, "CHDC": 0.10, "FHLO": 0.085, "FHDC": 0.085,
        "HAD": 0.115, "FHAD": 0.115, "HHAD": 0.12, "_default": 0.09})


@dataclass
class LiveSettings:
    source: str = "sim"                 # sim | capture | sql | replay (historical Raw_Data as of a moment)
    data_lag_seconds: float = 0.0       # how far the investment feed trails the wall clock
    sweep_minutes: int = 5
    focus_interval_seconds: float = 15.0
    focus_ttl_seconds: float = 180.0    # a focus lapses without a UI heartbeat
    max_focus_matches: int = 12
    trigger_odds_move: float = 0.05     # relative move on a main-line price
    trigger_big_bet_multiple: float = 4.0   # one minute's money vs its expected minute
    trigger_events: List[str] = field(default_factory=lambda: ["goal", "red"])
    nowcast_prior_minutes: float = 2.0  # how much the bucket forecast weighs, in minutes of evidence
    publish_min_uplift: float = 0.0     # below this E[GM] gain the recommendation is not surfaced


@dataclass
class MonitorSettings:
    rolling_days: int = 3
    wape_alert_ratio: float = 1.10      # model WAPE above 1.10 x last-5 WAPE
    bias_alert: float = 0.25            # |sum forecast / sum actual - 1|
    psi_alert: float = 0.25             # population stability index per feature
    # feature groups that move with the day's schedule by design; their drift is not a data problem
    drift_skip_groups: List[str] = field(default_factory=lambda: ["calendar", "lifecycle", "events", "concurrency"])
    ece_alert: float = 0.05
    min_rows: int = 500


SECTIONS = {
    "paths": PathSettings, "window": WindowSettings, "panel": PanelSettings,
    "features": FeatureSettings, "turnover": TurnoverSettings,
    "probability": ProbabilitySettings, "optimizer": OptimizerSettings,
    "live": LiveSettings, "monitor": MonitorSettings,
}


@dataclass
class Settings:
    paths: PathSettings = field(default_factory=PathSettings)
    window: WindowSettings = field(default_factory=WindowSettings)
    panel: PanelSettings = field(default_factory=PanelSettings)
    features: FeatureSettings = field(default_factory=FeatureSettings)
    turnover: TurnoverSettings = field(default_factory=TurnoverSettings)
    probability: ProbabilitySettings = field(default_factory=ProbabilitySettings)
    optimizer: OptimizerSettings = field(default_factory=OptimizerSettings)
    live: LiveSettings = field(default_factory=LiveSettings)
    monitor: MonitorSettings = field(default_factory=MonitorSettings)
    log_level: str = "INFO"

    # ------------------------------------------------------------ building
    @classmethod
    def load(cls, path: Optional[str] = None, overrides: Optional[List[str]] = None) -> "Settings":
        s = cls()
        path = path or os.environ.get("ALGOE_SETTINGS")
        if path:
            p = Path(path)
            if not p.exists():
                raise ConfigError("settings file {} does not exist".format(p))
            try:
                payload = json.loads(p.read_text(encoding="utf-8"))
            except ValueError as exc:
                raise ConfigError("settings file {} is not valid JSON: {}".format(p, exc))
            s.update(payload)
        if os.environ.get("ALGOE_DATA_DIR"):
            s.paths.data_dir = os.environ["ALGOE_DATA_DIR"]
        if os.environ.get("ALGOE_WORK_DIR"):
            s.paths.work_dir = os.environ["ALGOE_WORK_DIR"]
        for item in overrides or []:
            s.set(item)
        s.check()
        return s

    def update(self, payload: Dict[str, Any]) -> None:
        for section, values in (payload or {}).items():
            if section == "log_level":
                self.log_level = str(values)
                continue
            if section not in SECTIONS:
                raise ConfigError("unknown settings section {!r}; known: {}".format(
                    section, sorted(SECTIONS)))
            target = getattr(self, section)
            names = {f.name for f in fields(target)}
            for key, value in (values or {}).items():
                if key not in names:
                    raise ConfigError("unknown setting {}.{}; known: {}".format(
                        section, key, sorted(names)))
                current = getattr(target, key)
                if isinstance(current, dict) and isinstance(value, dict):
                    merged = dict(current)
                    merged.update(value)
                    value = merged
                setattr(target, key, copy.deepcopy(value))

    def set(self, assignment: str) -> None:
        """``section.key=value`` or ``section.key.subkey=value``; value parsed as JSON if it can be."""
        if "=" not in assignment:
            raise ConfigError("--set expects section.key=value, got {!r}".format(assignment))
        lhs, rhs = assignment.split("=", 1)
        parts = lhs.strip().split(".")
        try:
            value = json.loads(rhs)
        except ValueError:
            value = rhs
        if len(parts) == 2:
            self.update({parts[0]: {parts[1]: value}})
        elif len(parts) == 3:
            self.update({parts[0]: {parts[1]: {parts[2]: value}}})
        else:
            raise ConfigError("--set key must be section.key or section.key.subkey: {!r}".format(lhs))

    def check(self) -> None:
        # The panel cache is keyed by the data_dir string: "..\Raw_Data" and "S:\...\Raw_Data" would
        # be two caches of the same data. abspath, not resolve(): resolve() may turn the mapped S:
        # drive into its UNC path and miss the cache the workbench already built.
        p = self.paths
        for name in ("data_dir", "work_dir", "panel_cache_dir", "backtest_data_dir", "pool_overrides",
                     "holidays_file"):
            value = getattr(p, name)
            if value:
                setattr(p, name, os.path.abspath(os.path.expanduser(str(value))))
        w = self.window
        if w.val_days < 1 or w.test_days < 1:
            raise ConfigError("window.val_days and window.test_days must be >= 1")
        if bool(w.val_start) != bool(w.test_start):
            raise ConfigError("set both window.val_start and window.test_start, or neither")
        if w.val_start:
            try:
                start, val, test, end = (pd.Timestamp(x).normalize() for x in
                                         (w.start, w.val_start, w.test_start, w.end))
            except (ValueError, TypeError) as exc:
                raise ConfigError("window dates must be YYYY-MM-DD: {}".format(exc))
            if not start < val < test <= end:
                raise ConfigError("window needs start < val_start < test_start <= end, got {} / {} / {} / {}"
                                  .format(w.start, w.val_start, w.test_start, w.end))
        if self.panel.bucket_minutes <= 0:
            raise ConfigError("panel.bucket_minutes must be positive")
        if not 1.0 <= self.turnover.tweedie_power <= 2.0:
            raise ConfigError("turnover.tweedie_power must be in [1, 2]")
        if self.optimizer.demand not in ("share_model", "fixed", "none"):
            raise ConfigError("optimizer.demand must be share_model | fixed | none")
        if self.optimizer.price_mode not in ("delta", "absolute"):
            raise ConfigError("optimizer.price_mode must be delta | absolute")
        for key in ("settle_total", "settle_handicap"):
            if getattr(self.optimizer, key) not in ("full_match", "rest_of_match"):
                raise ConfigError("optimizer.{} must be full_match | rest_of_match".format(key))
        if self.probability.weight not in ("selection", "money", "row"):
            raise ConfigError("probability.weight must be selection | money | row")

    # ------------------------------------------------------------- output
    def to_dict(self) -> Dict[str, Any]:
        out = {name: asdict(getattr(self, name)) for name in SECTIONS}
        out["log_level"] = self.log_level
        out["paths"]["resolved"] = {
            "work": str(self.paths.work), "panel_cache": str(self.paths.panel_cache),
            "backtest_data": str(self.paths.backtest_data)}
        return out

    def save(self, path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = self.to_dict()
        payload["paths"].pop("resolved", None)
        p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return p

    def margin_for(self, pool: str) -> float:
        m = self.optimizer.margins
        return float(m.get(str(pool).upper(), m.get("_default", 0.09)))

    # ------------------------------------------------ bridge to the W06 engine
    def legacy_config(self):
        """The W06 engine's Config with the same shaping knobs.

        The panel cache is keyed by these knobs. With the same knobs as the
        workbench (panel.pools = ["HILO", "HDC", "CHLO", "CHDC"]) this opens the
        cache 3-run.bat already built; the default (every pool in the feed) is a
        new cache space and is built once.
        """
        from src.backtest.parquet.config import Config
        cfg = Config(
            data_dir=Path(self.paths.data_dir),
            out_dir=self.paths.reports / "legacy",
            cache_dir=self.paths.panel_cache,
            start_date=self.window.start, end_date=self.window.end,
            bucket_minutes=self.panel.bucket_minutes,
            pools=list(self.panel.pools),
            pool_rule="|".join(sorted(str(p) for p in self.panel.pools))
            if any(str(p).startswith("@") for p in self.panel.pools) else "",
            prematch_window_min=self.panel.prematch_window_min,
            lookback_days=self.panel.lookback_days,
            true_prob_source=self.panel.true_prob_source,
            normalize_book=self.panel.normalize_book,
            hdc_sign=self.panel.hdc_sign,
        )
        return cfg


def describe(settings: Settings) -> str:
    """Short one-line summary for log headers."""
    w = settings.window
    return "data={} work={} window={}..{} val={}d test={}d source={}".format(
        settings.paths.data_dir, settings.paths.work, w.start, w.end, w.val_days, w.test_days,
        settings.live.source)


def is_settings(obj) -> bool:
    return is_dataclass(obj) and isinstance(obj, Settings)
