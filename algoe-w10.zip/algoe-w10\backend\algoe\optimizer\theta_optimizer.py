"""
Theta Optimizer

For one match at one moment, choose the 8-dimensional theta that maximises

    E[GM](theta) = sum_i  T_i(theta) x risk_i x (1 - O_i(theta) x p_i)

    p_i       belief (ProbabilityCalibrator), fixed while theta moves
    O_i       the price we would post at theta
    T_i       money that price attracts over the horizon (TurnoverForecaster,
              nowcast-adjusted in focus mode)
    risk_i    share of a stake actually at risk (pushes / quarter-line halves)

This is project.md's four-step loop: step 1 anchors each pool's volume from
the forecast, step 2 searches theta, step 3 re-runs the demand response at the
candidate prices and renormalises inside the pool, step 4 scores E[GM].

PRICES (settings.optimizer.price_mode):

    delta     O_i(theta) = O_i(now) x p_i(theta_now) / p_i(theta)
              HKJC's posted board moved by our model's relative price change.
              At theta_now it IS the board, so the lift cannot come from a
              margin-table or rounding difference - only from theta.
    absolute  O_i(theta) = fair_i(theta) / (1 + margin_pool); needs the pricer
              to replicate HKJC's board (see the backtest's replication check).

DEMAND (settings.optimizer.demand):

    share_model   money moves between the lines and sides of a pool through
                  the price terms of the GLM selection-share model
                  (softmax with those coefficients; pool volume fixed)
    fixed         the same with one elasticity on log odds
    none          demand does not react; the solver will then only ever push
                  theta to the edge of its band, which is why it is not default

GUARDS: theta stays inside a band around HKJC's own theta and (in focus mode)
within ``max_step`` of the previous recommendation; TG >= |SUP|, first half
<= full match, second half coherent; main-line offers never beat the best
external price; every price inside [min_odds, max_odds] and within
``prob_band`` of HKJC's implied probability. HKJC's theta is always a
candidate, so the answer is never worse than doing nothing.

Goal and corner blocks share no parameter and no pool (demand is normalised
inside a pool), so each is solved as its own small problem.

Change Log:
-----------
2026-09-30      Initialize (replaces optimizer_v2b / backtest optimize / desk optimizer maths)
"""

from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..features.catalog import PRICE_FEATURES
from ..pricing.pricer import DIMS, BookPricer, BookRows, Conventions, MatchState, ladder, repair_theta

logger = get_logger(__name__)

try:
    from scipy.optimize import minimize
    HAVE_SCIPY = True
except Exception:                                          # pragma: no cover
    HAVE_SCIPY = False

BLOCKS = {"goal": ("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup"),
          "corner": ("corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup")}
ABS_BOUNDS = {"goal_tg": (0.02, 9.0), "goal_sup": (-5.0, 5.0), "goal_fh_tg": (0.0, 5.0),
              "goal_fh_sup": (-3.0, 3.0), "corner_tg": (0.2, 25.0), "corner_sup": (-10.0, 10.0),
              "corner_fh_tg": (0.0, 14.0), "corner_fh_sup": (-6.0, 6.0)}
PENALTY = 1e4


# =============================================================== demand
@dataclass
class DemandResponse:
    """How a selection's money responds when its price moves, holding its pool's volume."""
    mode: str = "share_model"
    coef: Dict[str, float] = field(default_factory=dict)       # per-unit coefficients on PRICE_FEATURES
    elasticity: float = 1.0                                   # fixed mode, on log odds
    cap: float = 6.0

    @classmethod
    def from_forecaster(cls, forecaster, settings) -> "DemandResponse":
        o = settings.optimizer
        if o.demand == "none":
            return cls(mode="none")
        if o.demand == "fixed" or forecaster is None:
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        m = forecaster.models.get(("glm", "selection_share")) if forecaster is not None else None
        if m is None:
            logger.warning("no GLM selection-share model: demand falls back to fixed elasticity %.2f",
                           o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        c = m.coefficients()
        coef = {k: float(c.get(k, 0.0)) for k in PRICE_FEATURES}
        dr = cls(mode="share_model", coef=coef, cap=o.max_elasticity)
        e = dr.elasticity_at(odds=1.9, p_true=0.5, p_mkt=0.5, o_mkt=1.9)
        if e < 0:
            logger.warning("share model says longer prices take LESS money (elasticity %.3f at evens); "
                           "that is reverse causality in the data, not demand - using fixed %.2f instead",
                           e, o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        logger.info("demand response from the share model: price coefficients %s, elasticity at evens %.3f",
                    {k: round(v, 4) for k, v in coef.items()}, e)
        return dr

    def elasticity_at(self, odds, p_true, p_mkt, o_mkt) -> float:
        """d log(money) / d log(odds) at one price."""
        if self.mode == "none":
            return 0.0
        if self.mode == "fixed":
            return self.elasticity
        c = self.coef
        return float(-c.get("imp", 0.0) / odds + c.get("log_odds", 0.0) + c.get("value_true", 0.0) * odds * p_true
                     + c.get("value_mkt", 0.0) * odds * p_mkt + c.get("hk_vs_mkt", 0.0) * odds / o_mkt)

    def log_shift(self, odds_new, odds_now, p_ref, p_mkt, o_mkt) -> np.ndarray:
        """Change in log money per selection when its price moves from odds_now to odds_new."""
        if self.mode == "none":
            return np.zeros_like(odds_new)
        if self.mode == "fixed":
            d = self.elasticity * (np.log(odds_new) - np.log(odds_now))
        else:
            c = self.coef
            d = (c.get("imp", 0.0) * (1.0 / odds_new - 1.0 / odds_now)
                 + c.get("log_odds", 0.0) * (np.log(odds_new) - np.log(odds_now))
                 + c.get("value_true", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_ref)
                 + c.get("value_mkt", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_mkt)
                 + c.get("hk_vs_mkt", 0.0) * np.where(np.isfinite(o_mkt), (odds_new - odds_now) / o_mkt, 0.0))
        return np.clip(d, -self.cap, self.cap)


# ================================================================= book
@dataclass
class MatchBook:
    match_id: int
    rows: BookRows
    pool: np.ndarray
    group: np.ndarray              # pool index: demand is renormalised inside it
    margin: np.ndarray
    demand: np.ndarray             # expected money at the current price, over the horizon
    p_true: np.ndarray
    p_ref: np.ndarray              # HKJC true prob (the value_true feature's reference)
    p_mkt: np.ndarray
    odds_now: np.ndarray
    odds_mkt: np.ndarray
    is_main: np.ndarray
    state: MatchState
    theta_now: Dict[str, float]
    theta_prev: Optional[Dict[str, float]] = None
    keys: Optional[pd.DataFrame] = None
    p_now: Optional[np.ndarray] = None
    risk: Optional[np.ndarray] = None

    @property
    def n(self) -> int:
        return len(self.demand)

    @property
    def total_demand(self) -> float:
        return float(np.nansum(self.demand))


@dataclass
class MatchDecision:
    match_id: int
    status: str
    theta_now: Dict[str, float]
    theta_star: Dict[str, float]
    egm_board: float               # posted board, current demand
    egm_now: float                 # theta_now through the pricing mode (== board in delta mode)
    egm_star: float
    turnover: float
    seconds: float
    n_selections: int
    evaluations: int = 0
    binding: List[str] = field(default_factory=list)
    odds_star: Optional[np.ndarray] = None
    demand_star: Optional[np.ndarray] = None
    per_pool: List[dict] = field(default_factory=list)

    @property
    def lift(self) -> float:
        return self.egm_star - self.egm_board

    @property
    def lift_bps(self) -> float:
        return 1e4 * self.lift / self.turnover if self.turnover > 0 else 0.0

    def to_dict(self) -> dict:
        return {"match_id": self.match_id, "status": self.status, "theta_now": self.theta_now,
                "theta_star": self.theta_star, "egm_board": self.egm_board, "egm_now": self.egm_now,
                "egm_star": self.egm_star, "lift": self.lift, "lift_bps": self.lift_bps,
                "turnover": self.turnover, "seconds": self.seconds, "n_selections": self.n_selections,
                "evaluations": self.evaluations, "binding": self.binding, "per_pool": self.per_pool}


# ============================================================ optimiser
class ThetaOptimizer:
    def __init__(self, settings, demand: Optional[DemandResponse] = None):
        self.settings = settings
        o = settings.optimizer
        self.o = o
        self.pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
        self.demand = demand or DemandResponse(mode=o.demand if o.demand != "share_model" else "fixed",
                                               elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        self.price_mode = getattr(o, "price_mode", "delta")

    # ------------------------------------------------------------ pieces
    def prices(self, book: MatchBook, theta: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        p, _ = self.pricer.probabilities(book.rows, theta, book.state)
        if self.price_mode == "delta":
            with np.errstate(divide="ignore", invalid="ignore"):
                odds = book.odds_now * book.p_now / p
        else:
            odds = BookPricer.sell_odds(p, book.margin)
        return odds, p

    def demand_at(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        shift = self.demand.log_shift(np.clip(odds, 1.0001, None), book.odds_now, book.p_ref, book.p_mkt,
                                      book.odds_mkt)
        w = book.demand * np.exp(shift)
        pool_now = _group_sum(book.demand, book.group)
        pool_new = _group_sum(w, book.group)
        return np.where(pool_new > 0, w * pool_now / np.maximum(pool_new, 1e-12), book.demand)

    def expected_gm(self, book: MatchBook, odds: np.ndarray, demand: Optional[np.ndarray] = None) -> float:
        T = book.demand if demand is None else demand
        return float(np.nansum(T * book.risk * (1.0 - odds * book.p_true)))

    def _violation(self, book: MatchBook, odds: np.ndarray) -> float:
        o = self.o
        v = 0.0
        bad = ~np.isfinite(odds)
        v += float(bad.sum()) * 10.0
        od = np.where(bad, o.min_odds, odds)
        v += float(np.sum(np.maximum(o.min_odds - od, 0.0) ** 2 + np.maximum(od - o.max_odds, 0.0) ** 2 * 1e-4))
        if o.prob_band and o.prob_band > 0:
            gap = np.abs(1.0 / od - 1.0 / book.odds_now) - o.prob_band
            v += float(np.sum(np.maximum(gap, 0.0) ** 2) * 100.0)
        if o.market_cap:
            cap = np.where(np.isfinite(book.odds_mkt), np.maximum(book.odds_mkt, book.odds_now), np.inf)
            over = np.where(book.is_main, np.maximum(od - cap, 0.0), 0.0)
            v += float(np.sum(over ** 2) * 10.0)
        return v

    # -------------------------------------------------------------- solve
    def optimize_match(self, book: MatchBook, mode: str = "sweep") -> MatchDecision:
        started = time.time()
        o = self.o
        th_now = repair_theta(book.theta_now)
        base_odds = book.odds_now
        egm_board = self.expected_gm(book, base_odds)
        if book.total_demand < o.min_match_turnover and mode == "sweep":
            return MatchDecision(book.match_id, "skipped: expected money below min_match_turnover", th_now,
                                 dict(th_now), egm_board, egm_board, egm_board, book.total_demand,
                                 round(time.time() - started, 4), book.n, 0, odds_star=base_odds,
                                 demand_star=book.demand)
        evals = [0]
        free_all = self._free_dims(book)
        theta = dict(th_now)
        odds_now_model, _ = self.prices(book, th_now)
        egm_now = self.expected_gm(book, odds_now_model, self.demand_at(book, odds_now_model))
        binding = []
        for block, dims in BLOCKS.items():
            free = [d for d in dims if d in free_all]
            if not free:
                continue
            # a block's parameters only price its own domain's pools, and demand is
            # renormalised inside a pool, so the block is scored on its rows alone
            sub = _sub_book(book, np.isin(book.rows.theta_domain, [block, block + "_fh"]))
            scale = max(sub.total_demand, 1.0)
            lo, hi = self._bounds(free, th_now, book.theta_prev if mode == "focus" else None)

            def score(vec, free=free, sub=sub, scale=scale):
                th = dict(theta)
                th.update(zip(free, vec))
                th = repair_theta(th)
                odds, _ = self.prices(sub, th)
                evals[0] += 1
                T = self.demand_at(sub, np.where(np.isfinite(odds), odds, sub.odds_now))
                return -self.expected_gm(sub, np.where(np.isfinite(odds), odds, 1.0), T) / scale \
                    + PENALTY * self._violation(sub, odds)

            x0 = np.array([theta[d] for d in free])
            best_x, best_f = x0.copy(), score(x0)
            starts = [x0]
            n_starts = o.starts_focus if mode == "focus" else o.starts_sweep
            if book.theta_prev is not None and mode == "focus":
                starts.insert(0, np.clip([book.theta_prev.get(d, theta[d]) for d in free], lo, hi))
            rng = np.random.default_rng(book.match_id % 100000)
            while len(starts) < n_starts:
                starts.append(lo + rng.random(len(free)) * (hi - lo))
            if HAVE_SCIPY:
                cons = self._coherence(free, theta)
                # a focus refresh starts next to the answer; it must never cost a full solve
                max_iter = min(o.max_iter, 20) if mode == "focus" else o.max_iter
                for s0 in starts[:max(n_starts, 1)]:
                    try:
                        # the objective is E[GM] per $ of demand (~0.1), so 1e-7 is far below a cent per HK$1000
                        res = minimize(score, np.clip(s0, lo, hi), method="SLSQP", bounds=list(zip(lo, hi)),
                                       constraints=cons, options={"maxiter": max_iter, "ftol": 1e-7, "eps": 1e-3})
                    except Exception as exc:                        # noqa: BLE001
                        logger.debug("match %s block %s SLSQP failed: %s", book.match_id, block, exc)
                        continue
                    if np.all(np.isfinite(res.x)) and res.fun < best_f:
                        best_x, best_f = np.clip(res.x, lo, hi), float(res.fun)
            else:
                best_x, best_f = _grid(score, x0, lo, hi)
            for d, v, l, h in zip(free, best_x, lo, hi):
                theta[d] = float(v)
                if min(v - l, h - v) < 1e-4 * max(h - l, 1e-9):
                    binding.append("{}@{}".format(d, "lo" if v - l < h - v else "hi"))
            th_b = repair_theta(theta)
            odds_b, _ = self.prices(sub, th_b)
            if o.prob_band and np.any(np.abs(1.0 / np.where(np.isfinite(odds_b), odds_b, 1.0) - 1.0 / sub.odds_now)
                                      > o.prob_band - 1e-3):
                binding.append("{}:prob_band".format(block))
        theta = repair_theta(theta)
        odds_star, _ = self.prices(book, theta)
        feasible = self._violation(book, odds_star) < 1e-6 and np.all(np.isfinite(odds_star))
        T_star = self.demand_at(book, np.where(np.isfinite(odds_star), odds_star, book.odds_now))
        egm_star = self.expected_gm(book, odds_star, T_star) if feasible else -np.inf
        status = "solved"
        if not feasible or egm_star < egm_board:
            # the board as posted is always available: never recommend something worse
            theta, odds_star, T_star, egm_star = dict(th_now), base_odds.copy(), book.demand.copy(), egm_board
            status = "kept board (no feasible improvement)" if feasible or not np.isfinite(egm_star) else \
                "kept board (infeasible)"
        dec = MatchDecision(book.match_id, status, th_now, theta, egm_board, egm_now, egm_star,
                            book.total_demand, round(time.time() - started, 4), book.n, evals[0], binding,
                            odds_star, T_star, self._per_pool(book, odds_star, T_star))
        return dec

    def _free_dims(self, book: MatchBook) -> List[str]:
        doms = set(book.rows.theta_domain.tolist())
        free = []
        if "goal" in doms:
            free += ["goal_tg", "goal_sup"]
        if "goal_fh" in doms and not book.state.ht_done:
            free += ["goal_fh_tg", "goal_fh_sup"]
        if "corner" in doms:
            free += ["corner_tg", "corner_sup"]
        if "corner_fh" in doms and not book.state.ht_done:
            free += ["corner_fh_tg", "corner_fh_sup"]
        return free

    def _bounds(self, free, th_now, th_prev) -> Tuple[np.ndarray, np.ndarray]:
        lo, hi = [], []
        for d in free:
            a, b = ABS_BOUNDS[d]
            band = float(self.o.theta_band.get(d, 0.5))
            l, h = max(a, th_now[d] - band), min(b, th_now[d] + band)
            if th_prev is not None and d in th_prev:
                step = float(self.o.max_step.get(d, band))
                l, h = max(l, th_prev[d] - step), min(h, th_prev[d] + step)
            if l > h:
                l = h = float(np.clip(th_now[d], a, b))
            lo.append(l)
            hi.append(h)
        return np.array(lo), np.array(hi)

    @staticmethod
    def _coherence(free, theta):
        """Linear coherence constraints on the free dims (the others held at theta)."""
        idx = {d: i for i, d in enumerate(free)}

        def val(x, d):
            return x[idx[d]] if d in idx else theta[d]
        cons = []
        for tg, sup, ftg, fsup in (BLOCKS["goal"], BLOCKS["corner"]):
            if tg in idx or sup in idx:
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) - val(x, sup)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) + val(x, sup)})
            if ftg in idx or fsup in idx:
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) - val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) + val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, f=ftg: val(x, tg) - val(x, f)})
        return cons

    def _per_pool(self, book: MatchBook, odds_star, T_star) -> List[dict]:
        out = []
        for p in np.unique(book.pool):
            m = book.pool == p
            now = float(np.nansum(book.demand[m] * book.risk[m] * (1 - book.odds_now[m] * book.p_true[m])))
            star = float(np.nansum(T_star[m] * book.risk[m] * (1 - odds_star[m] * book.p_true[m])))
            out.append({"pool": str(p), "turnover": float(np.nansum(book.demand[m])), "egm_board": now,
                        "egm_star": star, "lift": star - now})
        return sorted(out, key=lambda r: -r["lift"])

    # --------------------------------------------------------------- card
    def optimize_card(self, books: Sequence[MatchBook], mode: str = "sweep",
                      budget_seconds: Optional[float] = None, workers: Optional[int] = None,
                      on_result=None, key: str = "match") -> Dict[int, MatchDecision]:
        """Richest matches first; stop starting new ones when the budget is spent.

        Returns {match_id: decision}, or {position in ``books``: decision} with
        key="index" (a backtest batch can hold several buckets of one match).
        """
        budget = self.o.budget_seconds if budget_seconds is None else budget_seconds
        order = sorted(range(len(books)), key=lambda i: -books[i].total_demand)
        n_workers = workers if workers is not None else (self.o.workers or min(max((os.cpu_count() or 2) - 1, 1), 8))
        started = time.time()
        out: Dict[int, MatchDecision] = {}

        def label(i):
            return i if key == "index" else books[i].match_id
        if n_workers <= 1 or len(order) <= 2:
            for i in order:
                if budget and time.time() - started > budget:
                    logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out), len(order))
                    break
                out[label(i)] = self.optimize_match(books[i], mode)
                if on_result:
                    on_result(books[i].match_id, out[label(i)])
            return out
        with ProcessPoolExecutor(max_workers=n_workers) as pool:
            futures = {pool.submit(_solve_one, self.settings, self.demand, books[i], mode): i for i in order}
            for fut in as_completed(futures):
                i = futures[fut]
                try:
                    out[label(i)] = fut.result()
                except Exception as exc:                          # noqa: BLE001
                    logger.exception("match %s failed to optimise: %s", books[i].match_id, exc)
                    continue
                if on_result:
                    on_result(books[i].match_id, out[label(i)])
                if budget and time.time() - started > budget:
                    for f in futures:
                        f.cancel()
                    logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out), len(order))
                    break
        return out


def _solve_one(settings, demand, book, mode):
    return ThetaOptimizer(settings, demand).optimize_match(book, mode)


def _sub_book(book: MatchBook, mask: np.ndarray) -> MatchBook:
    m = np.asarray(mask, dtype=bool)
    rows = BookRows(book.rows.theta_domain[m], book.rows.market[m], book.rows.line[m], book.rows.side[m])
    _, group = np.unique(book.group[m], return_inverse=True)

    def cut(a):
        return None if a is None else a[m]
    return MatchBook(book.match_id, rows, book.pool[m], group.astype(int), book.margin[m], book.demand[m],
                     book.p_true[m], book.p_ref[m], book.p_mkt[m], book.odds_now[m], book.odds_mkt[m],
                     book.is_main[m], book.state, book.theta_now, book.theta_prev, None, cut(book.p_now),
                     cut(book.risk))


def _group_sum(values: np.ndarray, group: np.ndarray) -> np.ndarray:
    s = np.bincount(group, weights=np.nan_to_num(values), minlength=int(group.max()) + 1 if len(group) else 0)
    return s[group]


def _grid(score, x0, lo, hi, steps: int = 9):
    best, best_f = x0.copy(), score(x0)
    span = (hi - lo) / 4.0
    for _ in range(3):
        axes = [np.linspace(max(b - s, l), min(b + s, h), steps) for b, s, l, h in zip(best, span, lo, hi)]
        for pt in np.array(np.meshgrid(*axes)).T.reshape(-1, len(x0)):
            f = score(pt)
            if f < best_f:
                best, best_f = pt.copy(), f
        span /= 3.0
    return best, best_f


# ======================================================= books from rows
def build_books(sel: pd.DataFrame, match: pd.DataFrame, demand: np.ndarray, p_true: np.ndarray,
                settings, taxonomy=None, theta_prev: Optional[Dict[int, Dict[str, float]]] = None) -> List[MatchBook]:
    """MatchBooks for ONE bucket from feature-engineer rows (sel) and match rows.

    ``demand`` and ``p_true`` are aligned to ``sel``. Rows are kept when the
    pool is in scope and priceable, the price is live, and both a belief and
    a demand exist.
    """
    from ..pricing.panel_pricing import hkjc_theta, state_of
    o = settings.optimizer
    s = sel.copy()
    s["_demand"] = np.asarray(demand, dtype="float64")
    s["_p"] = np.asarray(p_true, dtype="float64")
    inplay = s["inplay"].fillna(0).to_numpy(dtype="float64") > 0 if "inplay" in s.columns else np.zeros(len(s), bool)
    age = np.expm1(s["log_odds_age"].to_numpy(dtype="float64")) if "log_odds_age" in s.columns else np.zeros(len(s))
    max_age = np.where(inplay, getattr(o, "max_odds_age_inplay_min", 10.0), getattr(o, "max_odds_age_prematch_min", 90.0))
    keep = (s["pool_name"].astype(str).str.upper().isin([p.upper() for p in o.pools]).to_numpy()
            & s["forecastable"].to_numpy(dtype=bool)
            & s["market"].isin(["total", "handicap"]).to_numpy()
            & np.isfinite(s["odds"].to_numpy(dtype="float64")) & (s["odds"].to_numpy(dtype="float64") > 1.0)
            & np.isfinite(s["_p"].to_numpy()) & (s["_p"].to_numpy() > 0) & (s["_p"].to_numpy() < 1)
            & np.isfinite(s["line"].to_numpy(dtype="float64"))
            & (age <= max_age))
    s = s[keep]
    if s.empty:
        return []
    ctx_cols = [c for c in ("match_id", "bucket", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh",
                            "phase", "minute", "home_goals", "away_goals", "home_corners", "away_corners")
                if c in match.columns]
    ctx = match[ctx_cols].drop_duplicates(["match_id", "bucket"]).set_index(["match_id", "bucket"])
    pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
    books = []
    for (mid, b), g in s.groupby(["match_id", "bucket"], sort=False):
        if (mid, b) not in ctx.index:
            continue
        r = ctx.loc[(mid, b)].to_dict()
        st = state_of(r)
        th = hkjc_theta(r, st)
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        p_now, risk = pricer.probabilities(rows, repair_theta(th), st)
        ok = np.isfinite(p_now) & (p_now > 1e-6)
        if not ok.any():
            continue
        g = g[ok]
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        pools = g["pool_name"].astype(str).to_numpy()
        _, group = np.unique(pools, return_inverse=True)
        margin = np.array([settings.margin_for(p) for p in pools])
        books.append(MatchBook(
            match_id=int(mid), rows=rows, pool=pools, group=group.astype(int), margin=margin,
            demand=np.clip(g["_demand"].to_numpy(dtype="float64"), 0, None), p_true=g["_p"].to_numpy(dtype="float64"),
            p_ref=g["p_hkjc_true"].to_numpy(dtype="float64") if "p_hkjc_true" in g.columns else np.full(len(g), np.nan),
            p_mkt=g["p_market"].to_numpy(dtype="float64") if "p_market" in g.columns else np.full(len(g), np.nan),
            odds_now=g["odds"].to_numpy(dtype="float64"),
            odds_mkt=g["mkt_odds"].to_numpy(dtype="float64") if "mkt_odds" in g.columns else np.full(len(g), np.nan),
            is_main=(g["rank_0"].to_numpy(dtype="float64") > 0) if "rank_0" in g.columns else np.ones(len(g), bool),
            state=st, theta_now=th, theta_prev=(theta_prev or {}).get(int(mid)),
            keys=g[["pool_id", "line_id", "combination_id", "match_id", "pool_name", "bucket"]].reset_index(drop=True),
            p_now=p_now[ok], risk=risk[ok]))
    return books


def publish_odds(odds: np.ndarray) -> np.ndarray:
    """The ladder-rounded prices a trader would actually post."""
    return np.array([ladder(float(o)) if np.isfinite(o) else np.nan for o in odds])
