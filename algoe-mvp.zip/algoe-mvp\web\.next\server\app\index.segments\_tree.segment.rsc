:HL["/_next/static/chunks/3enj9cb_65lqr.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"oG8kAEQaPsO7_mqxuBvSh"}
