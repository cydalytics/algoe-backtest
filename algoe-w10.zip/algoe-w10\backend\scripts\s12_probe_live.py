"""
Step 12 - live money probe

Reads one match from the live feed and checks its money rows the way the
models were trained to read money: one row per selection and minute, money
per interval (not a running total), no row counted twice. Also checks the
first-half split HKJC's parameters carry against HKJC's own first-half
prices. Writes AlgoE_Work/diagnostics/<stamp>_probe_<match>/.

    python scripts/s12_probe_live.py --match 1234567 [--minutes 60] [--tickets]

Exit code 1 if a check fails, 2 if one warns. Same as: python -m algoe probe-live
"""
from _algoe import run

if __name__ == "__main__":
    run("probe-live")
