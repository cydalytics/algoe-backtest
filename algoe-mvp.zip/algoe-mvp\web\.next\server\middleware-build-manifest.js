globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/b2XctbTZ5FopZ5sdKWXaC/_buildManifest.js",
    "static/b2XctbTZ5FopZ5sdKWXaC/_ssgManifest.js",
    "static/b2XctbTZ5FopZ5sdKWXaC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2tswzwt7g9k6a.js",
    "static/chunks/02fh7_m5mrih8.js",
    "static/chunks/2a2r6ih4qqdp9.js",
    "static/chunks/turbopack-1ghne-gwqwval.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
