@echo off
REM Train the turnover model from Raw_Data on CPU and write it into Backtest_Data.
REM Double-click, or drag the Raw_Data folder onto this file.
cd /d "%~dp0backend"
set DATA=%~1
if "%DATA%"=="" set DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data
python -m src.backtest.parquet.raw_turnover train --data-dir "%DATA%"
echo.
echo Done. In the backtest page: Run, then Open cached. raw_gbm is next to Last 5 min.
pause
