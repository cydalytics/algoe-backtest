# Algo E — offline install

Everything here runs with no internet. Nothing calls out, nothing needs npm
or pip to reach a registry, and no font, map or CDN is fetched at page load.

You need two things already on the machine:

- **Python 3.9+** with `pandas`, `numpy`, `scipy` and `pyodbc` — the same
  interpreter that runs `5 Data Extraction - Real Time.ipynb` already has all
  four. Only `fastapi` and `uvicorn` are likely to be missing.
- **Node 18+** — used only to serve the built page. Nothing is compiled here
  and `node_modules` is already inside `web/`, so `npm` is never invoked.

---

## 1. Check the machine

```powershell
cd backend
python scripts\preflight.py --skip-tick
```

This tells you what is missing before anything else has a chance to fail in a
more confusing way. Read the `FAIL` lines; `WARN` lines are usually fine.

Near the top it prints a **wheel tag**, like `cp311-win_amd64`, and checks
the bundled `vendor` folder against it. Install what is missing:

```powershell
pip install --no-index --find-links ..\vendor -r requirements.txt
```

### If a wheel refuses to install

Compiled packages — `pydantic_core`, `numpy`, `scipy`, `pandas`, `pyarrow`,
`pyodbc` — are built per interpreter version *and* per architecture, and pip's
error names a filename rather than the reason. There is exactly one tag that
works on this machine, and preflight prints it. To read it directly:

```powershell
python -c "import sys, sysconfig; print(sys.version); print(sysconfig.get_platform())"
```

`3.11` plus `win-amd64` means every compiled wheel must say `cp311` and
`win_amd64`. Not `cp312`, not `win32` (that is 32-bit Python), not
`win_arm64` (that is Windows on ARM). Pure-Python wheels say `py3-none-any`
and work anywhere.

If the tag does not match what is in `vendor`, rebuild the bundle on the
connected machine for this target — no need to have that Python installed
there:

```powershell
.\package.ps1 -Wheels -PythonVersion 311 -Platform win_amd64 -Zip
```

`vendor\TARGET.txt` records what the folder was built for.

---

## 2. Prove it works without touching the database

```bat
start.bat -Source sim
```

Use the `.bat`, not the `.ps1`. From cmd, Explorer or Git Bash a `.ps1` is
just a file, and Windows asks how you want to open it. The `.bat` hands it
to PowerShell. Double-clicking `start.bat` is the same as `start.bat` with
no arguments (simulator, unless you set `ALGOE_SOURCE`).

This runs the whole pipeline on the built-in simulator: no SQL, no network.
The board opens at <http://localhost:3000>. Twelve fake matches, a full book,
a working optimizer. The backtest page is at <http://localhost:3000/backtest>
— `Run` → `Real data`, point it at the parquet root that already lives on
this machine (nothing is downloaded).

**If this works, the software is fine** and anything that goes wrong next is
about database access, not about the code.

---

## 3. Point it at the real database

The three connection strings come straight from the notebook and are the
defaults, so normally there is nothing to set:

| Variable            | Default                                                          |
| ------------------- | ---------------------------------------------------------------- |
| `ALGOE_CONN_QFM`    | `DRIVER={SQL Server};SERVER=QFMWDB1ST12,40000;DATABASE=qfm_outbound_db` |
| `ALGOE_CONN_BIS`    | `DRIVER={SQL Server};SERVER=QFMBDB2LSR3A,40000;DATABASE=bis1_fbuser_db` |
| `ALGOE_CONN_BIS2`   | `DRIVER={SQL Server};SERVER=QFMBDB2LSR3A,40000;DATABASE=QFM`      |

Check they open, and that the queries return rows:

```powershell
cd backend
python scripts\preflight.py --source sql
```

Then run for real:

```bat
start.bat -Source sql
```

If a connection string differs on this machine, set it before starting:

```powershell
$env:ALGOE_CONN_QFM = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=...;DATABASE=..."
```

---

## What you are looking at

Both screens read the **W10 live engine** (`start.bat` starts it with the
API). It uses the champion models trained by the `algoe-*.bat` launchers,
read from `AlgoE_Work` beside `Raw_Data`; without them the `Engine` line in
the cockpit says `no W10 model` and the numbers fall back to the MVP rules
below.

**The board** (`/`) is one row per match on the engine's card, sorted by how
much expected margin the optimizer thinks is being left on the table. The
`Uplift` column is that number: expected GM at the recommended parameters
minus expected GM at the current ones, over the expected turnover.

The engine sweeps the whole card at every five-minute boundary, richest
first; until the first sweep finishes the strip at the top says so. Every row
is that sweep, so the card is ranked on the same footing; a match someone has
open carries `open`, and its cockpit has the newer numbers. A row
with prices but no HKJC TG/SUP or no live line market says `no book`. A
match's pools close at their close time, or when the feed posts the
full-time result, so a finished match has nothing open to price.
`ALGOE_SHOW_FINISHED` only affects the old W06 tick now.

**Opening a match** asks the engine to read it again at once and re-solve it
on the board as it stands at that moment - HKJC's newest TG/SUP, prices,
clock and score - rather than as it stood at the bucket start. While the page
is open it is re-read every 15 seconds; leaving the page releases it. The
header says which TG/SUP row the book is priced on and how old it is, and
whose board it is: `live · every 15s`, `bucket sweep`, or `reading the feed…`
while a refresh is running.

**The cockpit** (click any row) is one match in full:

- **left** — the eight parameters. Current value, recommended value, and a
  slider. Drag one and the whole book re-prices against it.
- **middle** — every selection, grouped the way the pools are grouped. Our
  price beside HKJC's, beside the external market's.
- **right** — why. The solver's own account of itself, the response curves,
  which pools the uplift comes from, the external quotes, the money flow, and
  the match tape.

Every number on both screens comes from the engine: the board from its last
sweep, the cockpit from this match's latest read, a slider's what-if from the
engine pricing the match's book at the dragged parameters. The frontend does
no pricing of its own, so what the screen shows and what the optimizer
decided cannot drift apart.

**The backtest page** (`/backtest`) has two sources, switched at the top:

- **Algo E model (W10)** reads the reports `algoe-3-backtest.bat` wrote under
  `AlgoE_Work\reports` (beside `Raw_Data`). The newest copy of every section is
  used, so the full run and a later `algoe-3-backtest.bat --only events` read
  as one report; `Reports` picks other folders or another `AlgoE_Work`. Views:
  *Overview* (the champion against last 5 minutes and what the run says),
  *Baseline vs model* (headline deltas, day by day, every slice - phase, clock,
  after an event, an event inside the 5 minutes, bet type, league - the split,
  the rows that took nothing, a match replay with the events marked, how far
  off each match-bucket was), *Leaderboard* (every pipeline, any two against
  each other, the feature groups), *Proportions*, *Events* (goals, red cards and
  corners before and after, inside the bucket, the fitted event shift) and
  *Drift, belief, margin*. The folder comes from `ALGOE_DATA_DIR` /
  `ALGOE_WORK_DIR` like the command line; set either before `start.bat` if
  `Raw_Data` is not at `S:\Users\Yeung\20260520 Algo E\Raw_Data`.
- **Workbench (W06 parquet)** is the parquet bench as before (Build, Open
  cached, One model, A vs B).

---

## What the numbers rest on

Each is labelled in the UI rather than hidden, because they are the things a
trader must know before trusting a number here:

1. **Belief** - the probability the optimizer scores with - is the W10
   calibrated model (`Belief` in the book). Without a trained model it falls
   back to 1 / HKJC true odds, the MVP rule.
2. **The five-minute turnover** is the W10 forecast for each selection
   (`F 5m`), updated with the money already in the bucket (`So far`). The MVP
   rule, next five minutes = the last five, is the `Last 5m` column, kept only
   to compare against. The forecast reads the live money table as money per
   minute per selection; `algoe-6-probe-live.bat --match <id>` checks that on
   a match in play (the id is the number in the cockpit's address) and writes
   `verdict.txt` under `AlgoE_Work\diagnostics`.
3. **First-half pools** say `FH split unverified`: before kick-off their
   parameters are the full match's x `Goal90SecondHalfSplitFH`, and whether
   that column is the first half's share or the second half's is being
   checked (`algoe-3-backtest.bat --only replication --days FROM:TO`).

Everything downstream — expected margin, the recommendation, the uplift — is
only as good as these.

---

## Keeping the data current

The backtest reads the parquet in `Raw_Data`. `algoe-update-data.bat` brings it up to now
with the queries of `1 Data Extraction.ipynb`. It starts from the day before the newest day
on disk: the monthly files are extracted whole again, and Match_Investments day by day. A
file replaces the old one only when it is complete. The cached days it read again are
dropped and built again.

```bat
algoe-update-data.bat --dry-run      what it would extract; changes nothing
algoe-update-data.bat                the update
algoe-schedule-update.bat            every morning at 06:00, no admin rights needed
```

`start.bat` checks the data too. When the newest day is before yesterday, or no update has
run yet, it starts the update in its own window and the desk opens anyway. Use
`start.bat -NoDataUpdate` to skip that.

---

## Running the pieces separately

```powershell
# API only
cd backend
python -m uvicorn src.api.main:app --port 8001

# board only, against an API already running
cd web
$env:ALGOE_API_URL = "http://127.0.0.1:8001"
node server.js
```

One tick to the console, no servers at all:

```powershell
cd backend
python scripts\main.py --source sql
```

Record a live snapshot, then replay it later without the database — useful
for reproducing something odd that happened at 20:15 last night:

```powershell
python scripts\capture.py                 # writes captures\<timestamp>\
start.bat -Source capture
```

---

## When something looks wrong

**The board says it cannot reach the API.** The web server proxies `/api` to
`ALGOE_API_URL`. If you started the API on a different port, `start.ps1`
handles it; if you started them by hand, set that variable.

**The board is empty but the API is up.** No live matches, or the queries
returned nothing. `python scripts\preflight.py --source sql` says which.

**`pyodbc` imports but no connection opens.** Almost always a missing ODBC
driver rather than credentials. Preflight lists the registered drivers; if
`SQL Server` is not among them, the connection string's `DRIVER={...}` needs
to name one that is.

**The numbers look wrong.** Check the source chip in the top-right first. If
it says `sim` you are looking at generated data, not the real book. Then the
cockpit's `Engine` line: `no W10 model` means the MVP rules are pricing.

**The five-minute turnover looks wrong for a match.** Run
`algoe-6-probe-live.bat --match <id>` while it is in play and send back the
folder it prints. A FAIL in `verdict.txt` means the live money feed is not
what the engine reads it as.

**A match is flagged `incoherent from the feed`.** `algo_param` sent a
supremacy larger than the total it is a difference of, or a first half
larger than the whole match. No score grid can be built from that, so the
values are clamped before pricing — the Solve tab shows exactly what changed.
Worth chasing upstream: the recommendation is sound but the input was not.

**A match says `no solve`.** The solver ran and could not converge. That is
different from `queued to solve`, which just means it has not got there yet.

**Everything is slow on a very large card.** The solve is capped at
`ALGOE_OPT_BUDGET` seconds per tick (240 by default); matches not reached
keep their prices and simply get no recommendation that tick. Raise it, or
lower `ALGOE_OPT_MAXITER`, if the trade-off is wrong for this desk.

**Time the solver on the real card**, without the UI in the way:

```powershell
cd backend
python tests\smoke_solve.py sql
```

One line per match — turnover, GM now, GM at the recommendation, and how
many milliseconds it took — plus any complaint scipy made. This is the
place to look if a recommendation seems off, because it shows the solve on
its own rather than through three layers of plumbing.

**Check the whole thing still hangs together:**

```powershell
cd backend
python tests\test_optimizer.py    # the solver, against known-bad inputs
python tests\test_tradable.py     # which matches reach the board
python tests\contract.py          # every field the UI reads, on every endpoint
```

All three run on generated data and need no database.
