"""
IO helpers

Atomic writes (write to a temp name, then rename) so a crash or a Ctrl-C
never leaves a half-written parquet that the next run would trust, and a
content hash so an artifact can prove it was not edited after training.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import hashlib
import json
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def _tmp(path: Path) -> Path:
    return path.with_name(path.name + ".tmp")


def write_parquet(frame: pd.DataFrame, path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp(path)
    frame.to_parquet(tmp, index=False)
    tmp.replace(path)
    return path


def _default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (pd.Timestamp,)):
        return o.isoformat()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def write_json(payload: Any, path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp(path)
    tmp.write_text(json.dumps(payload, indent=2, default=_default), encoding="utf-8")
    tmp.replace(path)
    return path


def read_json(path, default=None):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def write_pickle(obj: Any, path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp(path)
    with tmp.open("wb") as fh:
        pickle.dump(obj, fh, protocol=pickle.HIGHEST_PROTOCOL)
    tmp.replace(path)
    return path


def read_pickle(path):
    with Path(path).open("rb") as fh:
        return pickle.load(fh)


def file_sha1(path) -> str:
    h = hashlib.sha1()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def stable_hash(payload: Any, length: int = 12) -> str:
    blob = json.dumps(payload, sort_keys=True, default=_default)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:length]
