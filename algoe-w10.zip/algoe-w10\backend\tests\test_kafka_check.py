"""
Kafka transport and kafka-check tests on a stand-in confluent_kafka

    python tests/test_kafka_check.py           plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_kafka_check.py

No broker here: a fake confluent_kafka module with the calls the transport makes (Producer.produce / poll /
flush / list_topics, Consumer.subscribe / poll / assignment / close, KafkaError._PARTITION_EOF) checks how
they are used. The real broker, login and topics are checked at the office with algoe-7-kafka-check.bat.

Change Log:
-----------
2026-10-29      Initialize
"""

import contextlib
import io
import json
import os
import sys
import tempfile
import traceback
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "kafka"
ENV = {"ALGOE_KAFKA_BOOTSTRAP": "broker-a:9093", "ALGOE_KAFKA_SECURITY_PROTOCOL": "SASL_SSL",
       "ALGOE_KAFKA_SASL_MECHANISM": "SCRAM-SHA-512", "ALGOE_KAFKA_USERNAME": "algoe",
       "ALGOE_KAFKA_PASSWORD": "pw-never-printed", "ALGOE_KAFKA_TEST_TOPIC_PARAMS": "t.params",
       "ALGOE_KAFKA_TEST_TOPIC_PRICES": "t.prices", "ALGOE_KAFKA_GROUP": "algoe-check"}


class _Msg:
    def __init__(self, topic, value, key=None, err=None):
        self._t, self._v, self._k, self._e = topic, value, key, err

    def error(self):
        return self._e

    def topic(self):
        return self._t

    def key(self):
        return self._k

    def value(self):
        return self._v


class _Err:
    def __init__(self, code):
        self._c = code

    def code(self):
        return self._c

    def __str__(self):
        return "err {}".format(self._c)


def _fake_kafka(reply_for=None, fail=None, brokers=None):
    """A confluent_kafka stand-in. ``reply_for(value)`` -> reply text put on the prices topic per message;
    ``brokers`` -> what the metadata lists (id -> an object with host and port, as confluent_kafka gives)."""
    mod = types.ModuleType("confluent_kafka")
    mod.KafkaError = types.SimpleNamespace(_PARTITION_EOF=-191)
    state = {"produced": [], "confs": [], "inbox": [], "subscribed": [], "closed": False}

    class Producer:
        def __init__(self, conf):
            state["confs"].append(dict(conf))
            self.cb = []

        def produce(self, topic, value=None, key=None, on_delivery=None):
            state["produced"].append((topic, key, value))
            self.cb.append(on_delivery)
            if reply_for is not None:
                state["inbox"].append(_Msg("t.prices", reply_for(value).encode("utf-8")))

        def poll(self, timeout=0):
            for cb in self.cb:
                cb(_Err(1) if fail else None, None)
            self.cb = []
            return 0

        def flush(self, timeout=0):
            self.poll(0)
            return 0

        def list_topics(self, timeout=None):
            if fail == "metadata":
                raise RuntimeError("SASL authentication error: bad credentials")
            return types.SimpleNamespace(brokers=brokers or {1: "b1", 2: "b2"},
                                         topics={"t.params": 1, "t.prices": 1, "x": 1})

    class Consumer:
        def __init__(self, conf):
            state["confs"].append(dict(conf))

        def subscribe(self, topics):
            state["subscribed"] = list(topics)

        def assignment(self):
            return [("t.prices", 0)] if state["subscribed"] else []

        def poll(self, timeout=0):
            return state["inbox"].pop(0) if state["inbox"] else None

        def close(self):
            state["closed"] = True
    mod.Producer, mod.Consumer = Producer, Consumer
    return mod, state


@contextlib.contextmanager
def _installed(mod, env=None):
    saved = sys.modules.get("confluent_kafka")
    keys = set(ENV) | set(env or {})
    old_env = {k: os.environ.get(k) for k in keys}
    sys.modules["confluent_kafka"] = mod
    for k in keys:
        os.environ.pop(k, None)
    os.environ.update(env or {})
    try:
        yield
    finally:
        if saved is None:
            sys.modules.pop("confluent_kafka", None)
        else:
            sys.modules["confluent_kafka"] = saved
        for k, v in old_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _reply(value):
    msg = json.loads(value)
    out = json.loads((FIXTURES / "prices_message.json").read_text(encoding="utf-8"))
    out["EventId"] = out["MapResult"]["EventID"] = msg["EventId"]
    return json.dumps(out)


def test_the_transport_keys_by_event_reports_deliveries_and_reads_replies():
    from src.hkjc import kafka_transport as kt
    mod, st = _fake_kafka()
    st["inbox"] += [_Msg("t.prices", None, err=_Err(-191)), _Msg("t.prices", b'{"x": 1}', key=b"7")]
    with _installed(mod):
        t = kt.KafkaTransport(kt.kafka_config_from_env(ENV), ["t.prices"])
        t.send("t.params", 50075870, '{"EventId":50075870}', tag="ALGOE_1")
        assert st["produced"] == [("t.params", b"50075870", b'{"EventId":50075870}')]
        assert st["confs"][0]["acks"] == "all" and st["confs"][0]["sasl.password"] == "pw-never-printed"
        got = t.poll(0.1)                                    # the end-of-partition marker is not a reply
        assert [(r.topic, r.key, r.value) for r in got] == [("t.prices", "7", '{"x": 1}')]
        assert st["subscribed"] == ["t.prices"] and st["confs"][1]["auto.offset.reset"] == "latest"
        assert [(d.tag, d.ok) for d in t.deliveries()] == [("ALGOE_1", True)]
        assert t.wait_assigned(1.0) and t.metadata(1.0).brokers
        t.close()
        assert st["closed"]


def test_kafka_check_names_what_is_missing():
    from algoe.cli import main
    mod, _ = _fake_kafka()
    out = io.StringIO()
    with _installed(mod, {"ALGOE_KAFKA_BOOTSTRAP": "b:1"}), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, \
            contextlib.redirect_stdout(out):
        code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp])
    assert code == 1 and "ALGOE_KAFKA_TEST_TOPIC_PARAMS" in out.getvalue()


def test_kafka_check_connects_without_sending_unless_asked():
    from algoe.cli import main
    mod, st = _fake_kafka()
    out = io.StringIO()
    with _installed(mod, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp])
    text = out.getvalue()
    assert code == 0 and st["produced"] == [] and "2 broker" in text and "t.prices" in text
    assert "pw-never-printed" not in text and "(set)" in text
    bad, _ = _fake_kafka(fail="metadata")
    out = io.StringIO()
    with _installed(bad, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        assert main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp]) == 1
    assert "bad credentials" in out.getvalue()


def test_kafka_check_sends_one_message_to_the_test_topic_and_prints_the_reply():
    from algoe.cli import main
    mod, st = _fake_kafka(reply_for=_reply)
    out = io.StringIO()
    with _installed(mod, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "61234567",
                     "--wait", "2"])
    text = out.getvalue()
    assert code == 0, text
    assert len(st["produced"]) == 1 and st["produced"][0][0] == "t.params"           # the test topic only
    sent = json.loads(st["produced"][0][2])
    assert sent["EventId"] == 61234567 and sent["MsgId"].startswith("ALGOE_CHECK_") and sent["PoolWeightings"] == []
    assert "E-HV11-01" in text and "HILO" in text and "pw-never-printed" not in text
    silent, _ = _fake_kafka()
    out = io.StringIO()
    with _installed(silent, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        assert main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "1",
                     "--wait", "1"]) == 2                                              # sent, no reply: an alert


def test_kafka_check_reads_in_its_own_group_hides_the_login_and_refuses_production_topics():
    from algoe.cli import main
    env = dict(ENV, ALGOE_KAFKA_USERNAME="svc-u7")
    for extra, group in (([], "algoe-check-check"), (["--group", "desk-7"], "desk-7")):
        mod, st = _fake_kafka(reply_for=_reply)
        out = io.StringIO()
        with _installed(mod, env), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, \
                contextlib.redirect_stdout(out):
            code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "61234567",
                         "--wait", "2"] + extra)
        consumer = [c for c in st["confs"] if "group.id" in c]
        assert code == 0 and consumer and consumer[0]["group.id"] == group, (code, consumer)
        assert "svc-u7" not in out.getvalue()
    mod, st = _fake_kafka(reply_for=_reply)
    out = io.StringIO()
    with _installed(mod, dict(env, ALGOE_KAFKA_TOPIC_PARAMS="t.params")), \
            tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "1"])
    assert code == 1 and st["produced"] == [] and st["confs"] == [] and "production" in out.getvalue()


def test_kafka_check_names_each_broker_and_refuses_one_that_gives_localhost():
    """A test broker on someone's PC can give its address as localhost: the bootstrap answers, then every
    message goes to this box's own port 9092."""
    from algoe.cli import main

    def broker(host):
        return types.SimpleNamespace(id=0, host=host, port=9092)
    mod, st = _fake_kafka(brokers={0: broker("ctxfb2vpcst12")})
    out = io.StringIO()
    with _installed(mod, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        assert main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp]) == 0
    assert "broker 0 at ctxfb2vpcst12:9092" in out.getvalue() and "WARNING" not in out.getvalue()
    for send in ([], ["--send", "--event-id", "61234567", "--wait", "1"]):
        mod, st = _fake_kafka(reply_for=_reply, brokers={0: broker("localhost")})
        out = io.StringIO()
        with _installed(mod, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, \
                contextlib.redirect_stdout(out):
            code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp] + send)
        text = out.getvalue()
        assert "broker 0 at localhost:9092" in text and "advertised.listeners" in text, text
        assert code == (1 if send else 2) and st["produced"] == []


def test_kafka_check_sends_nothing_to_a_topic_it_cannot_see_and_commits_no_offset():
    from algoe.cli import main
    mod, st = _fake_kafka(reply_for=_reply)
    out = io.StringIO()
    with _installed(mod, dict(ENV, ALGOE_KAFKA_TEST_TOPIC_PARAMS="t.parms")), \
            tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, contextlib.redirect_stdout(out):
        code = main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "1", "--wait", "1"])
    assert code == 1 and st["produced"] == [] and "t.parms" in out.getvalue(), out.getvalue()
    mod, st = _fake_kafka(reply_for=_reply)
    with _installed(mod, ENV), tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, \
            contextlib.redirect_stdout(io.StringIO()):
        assert main(["kafka-check", "--work-dir", tmp, "--data-dir", tmp, "--send", "--event-id", "61234567",
                     "--wait", "2"]) == 0
    consumer = [c for c in st["confs"] if "group.id" in c]
    assert consumer and consumer[0]["enable.auto.commit"] is False      # every check starts at the newest reply


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
