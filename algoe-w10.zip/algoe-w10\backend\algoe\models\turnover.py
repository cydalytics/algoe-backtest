"""
Turnover Forecaster

One class that owns every way Algo E forecasts next-bucket turnover.

RESPONSE VARIABLES. Money for a selection in bucket T is decomposed into
three quantities that behave very differently, and each is modelled on its
own:

    match_total          M   money the whole match takes in T            (volume)
    pool_share           pi  share of M that goes to each pool           (mix across markets)
    selection_share      s   share of the pool's money on each line/side (mix within a market;
                                                                           where price elasticity lives)
    selection_turnover   y   the selection's money directly              (single-stage alternative)
    board_total          B   money the whole board takes in T            (four-stage level)
    match_share          q   share of B that goes to each match          (competition between matches)

    three_stage:  y_hat = M_hat x pi_hat x s_hat     (shares normalised inside their group)
    four_stage:   y_hat = B_hat x q_hat x pi_hat x s_hat
    direct:       y_hat = f(selection, pool and match features)

The split is also what the optimiser needs: repricing moves money WITHIN a
pool (s depends on price), while the match's volume is an anchor that price
does not change in the short run (project.md section 5, step 3).

METHOD NAMES are systematic, one per (algorithm, response):

    train_<algo>_<response>(data)     algo in glm | gam | gbm | nn
    predict_<response>(day, algo)     predict_selection_turnover(day, pipeline) composes them
    evaluate_<response>(algo, days)   evaluate_selection_turnover(pipeline, days)
    predict_remaining_bucket(...)     intra-bucket nowcast for the live loop
    train_all(days)                   every enabled combination, champion chosen on validation days

SPLITS. Coefficients are fitted on train days; the blend weight toward
last-5-minutes and the champion are chosen on validation days; test days
are scored once, at the end, for the leaderboard. A pipeline that does not
beat last 5 minutes on validation is blended to weight 0, i.e. it IS last 5
minutes: the deployed forecast can never be worse than the baseline on the
days it was chosen on.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Feature version on every bundle; refit_for_serving; prepare_training_data can reuse a split
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.exceptions import EstimatorUnavailable, ModelError
from ..core.io import write_parquet
from ..core.logging import get_logger, log_step
from ..data.panel import KEY
from ..data.splits import DaySplit, walk_forward
from ..evaluation.metrics import ScoreAccumulator, diebold_mariano, poisson_deviance
from ..features.engineer import MKEY, PKEY, DayData, FeatureEngineer, FeatureSet
from ..features.store import FEATURE_VERSION, FeatureStore
from ..realtime.nowcast import BucketNowcaster
from ..registry.model_store import ModelStore
from .estimators import ANCHORED, Estimator, available_algorithms, load_estimator, make_estimator

logger = get_logger(__name__)

ALGORITHMS = ("glm", "gam", "gbm", "nn")
# last5_pos: last bucket's money in the same slot (offset from the best line, side), for every line.
# last5_hybrid: a line's own last bucket; a line just opened with no money of its own takes its slot's. On
# the office data (2026-07..09) last5_pos lost to last5 on all 87 test days: money follows a line that
# carries on, the slot only matters for a new one.
NAIVE = ("last5", "last5_hybrid", "last5_pos", "ma3", "ema", "profile")


@dataclass(frozen=True)
class ResponseSpec:
    name: str
    builder: str
    family: str
    uses_exposure: bool
    normalise: Optional[str]         # None | "match" | "pool"
    smooth: Tuple[str, ...]


# match_total and selection_turnover carry the market index as exposure: they forecast money per unit of
# market size, so a market twice the size needs no refit and a tree never extrapolates in HK$
RESPONSES: Dict[str, ResponseSpec] = {
    "match_total": ResponseSpec("match_total", "features_for_turnover_match_total", "tweedie", True, None,
                                ("pre_ko_min", "minute", "m_log_l1", "m_log_ewma", "m_log_today",
                                 "log_board_l1", "tg_full", "n_live")),
    "pool_share": ResponseSpec("pool_share", "features_for_turnover_pool_share", "poisson", True, "match",
                               ("minute", "pre_ko_min", "p_share_l1", "p_share_ewma")),
    "selection_share": ResponseSpec("selection_share", "features_for_turnover_selection_share", "poisson", True,
                                    "pool", ("s_share_pool_l1", "s_share_pool_ewma", "line_offset", "imp",
                                             "value_true", "log_odds_age")),
    "selection_turnover": ResponseSpec("selection_turnover", "features_for_turnover_selection", "tweedie", True,
                                       None, ("s_log_l1", "s_log_ewma_fast", "m_log_l1", "pre_ko_min", "minute",
                                              "line_offset", "imp")),
    # four_stage: the board's money per bucket (market index as exposure), then each match's share of it
    "board_total": ResponseSpec("board_total", "features_for_turnover_board_total", "tweedie", True, None,
                                ("log_board_l1", "log_board_today", "board_rel", "hour_c1")),
    "match_share": ResponseSpec("match_share", "features_for_turnover_match_share", "poisson", True, "board",
                                ("pre_ko_min", "minute", "m_log_l1", "m_log_ewma", "pop_board_share")),
}
# which feature kinds each algorithm is handed (catalog.py); an anchored model's GLM takes the glm kinds
TREE_KINDS = ("raw", "flag", "encoded")
KINDS_FOR = {"glm": ("raw", "basis", "flag", "encoded"), "gam": ("raw", "flag", "encoded"),
             "gbm": TREE_KINDS, "xgb": TREE_KINDS, "cat": TREE_KINDS, "nn": ("raw", "basis", "flag", "encoded"),
             "glm_gbm": TREE_KINDS, "glm_xgb": TREE_KINDS, "glm_cat": TREE_KINDS,
             "glm_nn": ("raw", "basis", "flag", "encoded")}
# the stage a pipeline's level comes from: a tree or a network there stops at its biggest training value
LEVEL_ANCHOR = {"gbm": "glm_gbm", "nn": "glm_nn", "xgb": "glm_xgb", "cat": "glm_cat"}
# the inputs an anchored model may carry past the training range: money levels in market-index units
# (log1p money memory of the match, pool, selection, slot and board) - a match bigger than any seen.
# A weekday, a pool count or a price outside the range is held at its edge.
LEVEL_FEATURE = re.compile(r"^(m_log_|p_log_|s_log_|pos_log_|log_board_)")


@dataclass
class TrainingData:
    split: DaySplit
    train: Dict[str, FeatureSet] = field(default_factory=dict)
    val: Dict[str, FeatureSet] = field(default_factory=dict)


class TurnoverForecaster:
    def __init__(self, settings, engineer: Optional[FeatureEngineer] = None,
                 store: Optional[FeatureStore] = None, model_store: Optional[ModelStore] = None):
        self.settings = settings
        self.engineer = engineer or FeatureEngineer(settings)
        self.store = store
        self.model_store = model_store or ModelStore(settings.paths.models, "turnover", FEATURE_VERSION)
        self.models: Dict[Tuple[str, str], Estimator] = {}
        self.blend: Dict[str, float] = {}
        self.profile: Dict[str, float] = {}
        self.champion: str = "last5"
        self.leaderboard: List[dict] = []
        self.nowcaster = BucketNowcaster(settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes,
                                         max_hot=settings.live.nowcast_max_hot)
        self.version: Optional[str] = None
        self.metadata: dict = {}
        # (algo, response) -> the TrainingData it was last fitted on: an anchored model reuses the GLM
        # only when that GLM was fitted on the very same rows
        self._fitted_on: Dict[Tuple[str, str], object] = {}

    # ===================================================== train (systematic)
    def train_glm_match_total(self, data: TrainingData) -> Estimator:
        return self._train("glm", "match_total", data)

    def train_gam_match_total(self, data: TrainingData) -> Estimator:
        return self._train("gam", "match_total", data)

    def train_gbm_match_total(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "match_total", data)

    def train_nn_match_total(self, data: TrainingData) -> Estimator:
        return self._train("nn", "match_total", data)

    def train_glm_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("glm", "pool_share", data)

    def train_gam_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("gam", "pool_share", data)

    def train_gbm_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "pool_share", data)

    def train_nn_pool_share(self, data: TrainingData) -> Estimator:
        return self._train("nn", "pool_share", data)

    def train_glm_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("glm", "selection_share", data)

    def train_gam_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("gam", "selection_share", data)

    def train_gbm_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "selection_share", data)

    def train_nn_selection_share(self, data: TrainingData) -> Estimator:
        return self._train("nn", "selection_share", data)

    def train_glm_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("glm", "selection_turnover", data)

    def train_gam_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("gam", "selection_turnover", data)

    def train_gbm_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("gbm", "selection_turnover", data)

    def train_nn_selection_turnover(self, data: TrainingData) -> Estimator:
        return self._train("nn", "selection_turnover", data)

    def train_naive_profile(self, data: TrainingData) -> Dict[str, float]:
        """Gametime profile baseline: mean selection money by (clock bin, family) on train days."""
        fs = data.train.get("selection_turnover")
        if fs is None or not len(fs):
            self.profile = {}
            return self.profile
        key = np.char.add(np.char.add(labels(fs.cuts["clock_bin"]).astype(str), "|"),
                          labels(fs.cuts["family"]).astype(str))
        rate = fs.y / np.maximum(fs.exposure, 1e-12)               # market-index units
        self.profile = pd.Series(rate).groupby(key).mean().to_dict()
        self.profile["_global"] = float(np.mean(rate))
        logger.info("naive profile: %d (clock, family) cells", len(self.profile) - 1)
        return self.profile

    def _train(self, algo: str, response: str, data: TrainingData) -> Estimator:
        spec = RESPONSES[response]
        tr, va = data.train.get(response), data.val.get(response)
        if tr is None or not len(tr):
            raise ModelError("no training rows for {}".format(response))
        feats = tr.columns_for(KINDS_FOR[algo])
        anchored = algo in ANCHORED
        glm_feats = tr.columns_for(KINDS_FOR["glm"]) if anchored else None
        est = make_estimator(algo, spec.family, self.settings.turnover.tweedie_power, self.settings, feats,
                             features_glm=glm_feats,
                             extrapolate=[f for f in glm_feats if LEVEL_FEATURE.match(f)] if anchored else None)
        if anchored and self._fitted_on.get(("glm", response)) is data and ("glm", response) in self.models:
            est.glm = self.models[("glm", response)]
        if algo == "gam":
            est.smooth_req = [c for c in spec.smooth if c in feats]
        exp_tr = tr.exposure if spec.uses_exposure else None
        exp_va = (va.exposure if spec.uses_exposure else None) if va is not None else None
        with log_step(logger, "T", "train {} {}".format(algo, response),
                      "{:,} train rows, {:,} val rows, {} features".format(
                          len(tr), 0 if va is None else len(va), len(feats))) as step:
            est.fit(tr.X, tr.y, exposure=exp_tr, weight=tr.weight,
                    X_val=None if va is None else va.X, y_val=None if va is None else va.y,
                    exposure_val=exp_va, weight_val=None if va is None else va.weight)
            step["result"] = "train dev {:.4g} val dev {}".format(
                est.info.get("train_deviance", float("nan")),
                "{:.4g}".format(est.info["val_deviance"]) if "val_deviance" in est.info else "n/a")
        self.models[(algo, response)] = est
        self._fitted_on[(algo, response)] = data
        return est

    # ============================================================ data
    def prepare_training_data(self, days: Sequence, store: Optional[FeatureStore] = None,
                              split: Optional[DaySplit] = None, fit_encoders: bool = True) -> TrainingData:
        """Build train / val FeatureSets for every response; fit encoders on train days only.

        ``split`` reuses a model's own split (the backtest's ablation must refit on the days the
        model was fitted on, or the comparison - and the shared encoders - would change).
        ``fit_encoders=False`` keeps the encoders the model already carries (the ablation's sample)."""
        store = store or self.store
        if store is None:
            raise ModelError("prepare_training_data needs a FeatureStore")
        t = self.settings.turnover
        rng = np.random.default_rng(t.seed)
        # a cached day has rows (empty days are never written), so only uncached days are opened
        usable = [pd.Timestamp(d).normalize() for d in days if store.has(d) or not store.get(d).empty]
        w = self.settings.window
        if split is not None:
            ok = set(usable)
            split = DaySplit(*(tuple(d for d in part if pd.Timestamp(d).normalize() in ok)
                               for part in (split.train, split.val, split.test)))
        else:
            split = DaySplit.for_window(usable, w)
        logger.info("turnover split: %s", split.describe())
        with log_step(logger, "F1", "fit encoders on train days" if fit_encoders else "keep the model's encoders",
                      split.describe()) as step:
            if fit_encoders or not self.engineer.encoders.fitted:
                self.engineer.fit_encoders_from(store, split.train, cutoff=_cutoff(split))
            step["result"] = "leagues {} pools {}".format(
                len((self.engineer.encoders.league.tables.get("league_code", {}) if self.engineer.encoders.league else {})),
                len((self.engineer.encoders.pool.tables.get("pool_key", {}) if self.engineer.encoders.pool else {})))
        data = TrainingData(split=split)
        parts: Dict[str, Dict[str, List[FeatureSet]]] = {"train": {}, "val": {}}
        with log_step(logger, "F2", "build training feature sets") as step:
            for role, role_days in (("train", split.train), ("val", split.val)):
                for d in role_days:
                    dd = store.get(d)
                    for name, spec in RESPONSES.items():
                        fs = getattr(self.engineer, spec.builder)(dd)
                        if not len(fs):
                            continue
                        fs = _sample_groups(fs, _day_cap(t, name, len(role_days)), rng)
                        parts[role].setdefault(name, []).append(fs)
            for role in ("train", "val"):
                for name, lst in parts[role].items():
                    getattr(data, role)[name] = FeatureSet.concat(lst)
            step["result"] = ", ".join("{} {:,}/{:,}".format(k, len(data.train.get(k, [])) if k in data.train else 0,
                                                            len(data.val[k]) if k in data.val else 0)
                                       for k in RESPONSES)
        return data

    # ========================================================= train all
    def train_all(self, days: Sequence, store: Optional[FeatureStore] = None) -> dict:
        store = store or self.store
        self.store = store
        t = self.settings.turnover
        avail = available_algorithms()
        data = self.prepare_training_data(days, store)
        self.train_naive_profile(data)
        skipped = {}
        for response in t.responses:
            if response not in RESPONSES:
                logger.warning("unknown response %r in settings.turnover.responses; skipped", response)
                continue
            for algo in t.algorithms:
                if algo == "naive" or algo not in self._algos_needed(response):
                    continue                      # no pipeline uses it: nothing to train, nothing missed
                if not avail.get(algo, False):
                    skipped["{}_{}".format(algo, response)] = "backend not installed"
                    continue
                try:
                    named = getattr(self, "train_{}_{}".format(algo, response), None)
                    named(data) if named else self._train(algo, response, data)
                except (EstimatorUnavailable, ModelError, np.linalg.LinAlgError, ValueError) as exc:
                    skipped["{}_{}".format(algo, response)] = str(exc)
                    logger.warning("train_%s_%s skipped: %s", algo, response, exc)
        pipelines = self._runnable_pipelines()
        with log_step(logger, "V", "choose blend and champion on validation days",
                      ", ".join(pipelines)) as step:
            val_scores = self._score_days(data.split.val, pipelines, choose_blend=True)
            self.champion = self._pick_champion(val_scores)
            step["result"] = "champion {} (blend {:.2f})".format(self.champion, self.blend.get(self.champion, 0.0))
        with log_step(logger, "E", "score every pipeline on test days", data.split.describe()) as step:
            test_scores = self._score_days(data.split.test, pipelines, choose_blend=False, cuts=True)
            self.leaderboard = self._leaderboard(val_scores, test_scores)
            champ = next((r for r in self.leaderboard if r["pipeline"] == self.champion), {})
            base = next((r for r in self.leaderboard if r["pipeline"] == "last5"), {})
            step["result"] = "test deviance {} vs last5 {}; WAPE {} vs {}".format(
                _fmt(champ.get("test_deviance")), _fmt(base.get("test_deviance")),
                _pct(champ.get("test_wape")), _pct(base.get("test_wape")))
        self.metadata = {
            "window": {"start": str(pd.Timestamp(days[0]).date()), "end": str(pd.Timestamp(days[-1]).date())},
            "split": data.split.to_dict(), "champion_pipeline": self.champion, "blend": self.blend,
            "leaderboard": self.leaderboard, "skipped": skipped,
            "features": {r: data.train[r].feature_names for r in data.train},
            "models": {"{}|{}".format(a, r): m.summary() for (a, r), m in self.models.items()},
            "selection": {"metric": "deviance", "days": data.split.to_dict()["val"],
                          "deviance": next((r["val_deviance"] for r in self.leaderboard if r["pipeline"] == self.champion), None)},
            "test_cuts": test_scores.get("_cuts", {}), "dm_test": test_scores.get("_dm", {}),
            "settings": self.settings.to_dict()["turnover"],
            "feature_reference": {r: _reference(data.train[r].X) for r in data.train},
            # a model trained without HKJC true odds must be served without them (see LiveEngine)
            "true_odds_coverage": true_odds_coverage(store, data.split.train),
            # the live engine's market size when the panel cache has no day to size it from
            "market_index_last": _last_market_index(store, list(data.split.train) + list(data.split.val)),
        }
        return self.metadata

    def _algos_needed(self, response: str) -> set:
        need = set()
        for p in self.settings.turnover.pipelines:
            for r, a in _components(p).items():
                if r == response:
                    need.add(a)
        return need

    def _runnable_pipelines(self) -> List[str]:
        out = []
        for p in self.settings.turnover.pipelines:
            kind, _ = _parse_pipeline(p)
            if kind == "naive":
                if p != "profile" or self.profile:
                    out.append(p)
            elif all((a, r) in self.models for r, a in _components(p).items()):
                out.append(p)
            else:
                logger.info("pipeline %s not runnable (a component was not trained)", p)
        if "last5" not in out:
            out.insert(0, "last5")
        return out

    # =========================================================== predict
    def predict_match_total(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fm = self.engineer.features_for_turnover_match_total(day)
        mu = self._model(algo, "match_total").predict(fm.X, exposure=fm.exposure)
        mu = self._match_effect(day.match, mu)
        out = fm.keys.copy()
        out["forecast"], out["actual"], out["last5"] = mu, fm.y, fm.last5
        return out

    def predict_pool_share(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fp = self.engineer.features_for_turnover_pool_share(day)
        raw = self._model(algo, "pool_share").predict(fp.X, exposure=np.ones(len(fp)))
        out = fp.keys.copy()
        out["share"] = _normalise(raw, fp.group)
        out["actual_share"] = np.where(fp.exposure > 0, fp.y / np.maximum(fp.exposure, 1e-12), np.nan)
        return out

    def predict_selection_share(self, day: DayData, algo: str = "glm") -> pd.DataFrame:
        fs = self.engineer.features_for_turnover_selection_share(day)
        raw = self._model(algo, "selection_share").predict(fs.X, exposure=np.ones(len(fs)))
        out = fs.keys.copy()
        out["share"] = _normalise(raw, fs.group)
        out["actual_share"] = np.where(fs.exposure > 0, fs.y / np.maximum(fs.exposure, 1e-12), np.nan)
        return out

    def predict_selection_turnover(self, day: DayData, pipeline: Optional[str] = None,
                                   blend: Optional[float] = None) -> pd.DataFrame:
        """Next-bucket money for every row of the day (forecastable rows modelled, others last 5 min)."""
        pipeline = pipeline or self.champion
        sel = day.sel
        f = sel["forecastable"].to_numpy(dtype=bool)
        model_pred = self._pipeline_raw(day, pipeline)
        a = self.blend.get(pipeline, 1.0) if blend is None else blend
        last5 = sel["tv1"].to_numpy(dtype="float64")
        base = self._blend_base(sel)
        pred = last5.copy()
        if model_pred is not None:
            pred[f] = a * model_pred + (1.0 - a) * base[f]
        out = sel[KEY + ["match_id", "pool_name", "bucket"]].copy()
        out["forecast"], out["last5"], out["actual"] = pred, last5, sel["y"].to_numpy(dtype="float64")
        out["forecastable"] = f
        return out

    def predict_remaining_bucket(self, bucket_forecast, observed_so_far, elapsed_minutes: float,
                                 match_key=None, next_forecast=None):
        """Rest-of-bucket money given what has already arrived (see realtime/nowcast.py)."""
        return self.nowcaster.update(bucket_forecast, observed_so_far, elapsed_minutes, match_key, next_forecast)

    def _model(self, algo: str, response: str) -> Estimator:
        m = self.models.get((algo, response))
        if m is None:
            raise ModelError("no trained {} model for {}".format(algo, response))
        return m

    def _blend_base(self, sel: pd.DataFrame) -> np.ndarray:
        """What a model is shrunk toward (turnover.blend_base): hybrid - the line's own last bucket, its
        slot's for a line just opened; position - the slot's for every line; line - the line id's."""
        mode = self.settings.turnover.blend_base
        if mode == "line" or "pos_tv1" not in sel.columns:
            return sel["tv1"].to_numpy(dtype="float64")
        if mode == "position":
            return sel["pos_tv1"].to_numpy(dtype="float64")
        return _hybrid_last5(sel)

    def _pipeline_raw(self, day: DayData, pipeline: str, cache: Optional[dict] = None) -> Optional[np.ndarray]:
        """Unblended model forecast aligned to day.sel[forecastable] rows.

        ``cache`` (one dict per day) shares the day's feature sets and each component's prediction
        between pipelines: scoring ten pipelines builds the features once, not ten times."""
        cache = {} if cache is None else cache
        kind, algos = _parse_pipeline(pipeline)
        if "_sel" not in cache:
            cache["_sel"] = day.sel[day.sel["forecastable"]]
        s = cache["_sel"]

        def fset(name, builder):
            if name not in cache:
                cache[name] = builder(day)
            return cache[name]

        def comp(key, fn):
            if key not in cache:
                cache[key] = fn()
            return cache[key]
        if kind == "naive":
            tv = [s["tv{}".format(k)].to_numpy(dtype="float64") for k in (1, 2, 3)]
            if pipeline == "last5":
                return tv[0]
            if pipeline == "last5_pos":
                return s["pos_tv1"].to_numpy(dtype="float64") if "pos_tv1" in s.columns else tv[0]
            if pipeline == "last5_hybrid":
                return _hybrid_last5(s) if "pos_tv1" in s.columns else tv[0]
            if pipeline == "ma3":
                return (tv[0] + tv[1] + tv[2]) / 3.0
            if pipeline == "ema":
                return 0.5 * tv[0] + 0.3 * tv[1] + 0.2 * tv[2]
            if pipeline == "profile":
                g = self.profile.get("_global", 0.0)
                scale = s["market_index"].to_numpy(dtype="float64") if "market_index" in s.columns else 1.0
                if "clock_bin" not in s.columns:
                    return np.full(len(s), g) * scale
                key = np.char.add(np.char.add(labels(s["clock_bin"]).astype(str), "|"), labels(s["family"]).astype(str))
                return pd.Series(key).map(self.profile).fillna(g).to_numpy(dtype="float64") * scale
            raise ModelError("unknown naive pipeline {}".format(pipeline))
        if kind == "direct":
            fd = fset("_fd", self.engineer.features_for_turnover_selection)
            return comp(("direct", algos[0]),
                        lambda: self._model(algos[0], "selection_turnover").predict(fd.X, exposure=fd.exposure))
        if kind == "three_stage":
            a_m, a_p, a_s = algos
            fm = fset("_fm", self.engineer.features_for_turnover_match_total)
            M = comp(("M", a_m), lambda: self._match_effect(
                day.match, self._model(a_m, "match_total").predict(fm.X, exposure=fm.exposure)))
            return self._split_match_money(day, M, fm.keys, a_p, a_s, fset, comp)
        if kind == "four_stage":
            # the board's money, then each match's share of it (normalised over the matches on the board
            # at that bucket): a bigger match on the board takes its money from the others
            a_b, a_ms, a_p, a_s = algos
            fb = fset("_fb", self.engineer.features_for_turnover_board_total)
            B = comp(("B", a_b), lambda: self._model(a_b, "board_total").predict(fb.X, exposure=fb.exposure))
            fq = fset("_fq", self.engineer.features_for_turnover_match_share)
            q = comp(("q", a_ms), lambda: _normalise(
                self._model(a_ms, "match_share").predict(fq.X, exposure=np.ones(len(fq))), fq.group))
            M = comp(("M4", a_b, a_ms), lambda: self._match_effect(day.match, np.nan_to_num(
                _take(B, comp("_pos_b", lambda: _positions(fb.keys[["bucket"]], fq.keys[["bucket"]]))) * q)))
            return self._split_match_money(day, M, fq.keys, a_p, a_s, fset, comp)
        raise ModelError("unknown pipeline {!r}".format(pipeline))

    def _split_match_money(self, day: DayData, M: np.ndarray, match_keys: pd.DataFrame, a_p: str, a_s: str,
                           fset, comp) -> np.ndarray:
        """A match's money (aligned to day.match) down to its pools, then to their selections."""
        fp = fset("_fp", self.engineer.features_for_turnover_pool_share)
        pi = comp(("pi", a_p), lambda: _normalise(
            self._model(a_p, "pool_share").predict(fp.X, exposure=np.ones(len(fp))), fp.group))
        P = _take(M, comp("_pos_m", lambda: _positions(match_keys[MKEY], fp.keys[MKEY]))) * pi
        fs = fset("_fs", self.engineer.features_for_turnover_selection_share)
        sh = comp(("sh", a_s), lambda: _normalise(
            self._model(a_s, "selection_share").predict(fs.X, exposure=np.ones(len(fs))), fs.group))
        Ps = _take(P, comp("_pos_p", lambda: _positions(fp.keys[PKEY], fs.keys[PKEY])))
        return np.nan_to_num(Ps, nan=0.0) * sh

    def _match_effect(self, match: pd.DataFrame, mu: np.ndarray) -> np.ndarray:
        """In-day match random effect: scale by (money so far + prior) / (forecast so far + prior).

        Uses only buckets of the same match earlier the same day, which are
        settled at T. A league never seen in training trusts the match's own
        buckets sooner (settings.features.match_prior_new_league).
        """
        fs = self.settings.features
        if match is None or match.empty or len(mu) != len(match):
            return mu
        known = np.ones(len(match))
        if self.engineer.encoders.league is not None and "league_code" in match.columns:
            _, known = self.engineer.encoders.league.transform(match)
        k = np.where(known > 0, fs.match_prior, fs.match_prior_new_league)
        f = pd.DataFrame({"m": match["match_id"].to_numpy(), "b": match["bucket"].to_numpy(),
                          "y": match["y"].to_numpy(dtype="float64"), "mu": np.asarray(mu, dtype="float64"),
                          "k": k, "pos": np.arange(len(match))}).sort_values(["m", "b"])
        g = f.groupby("m", sort=False)
        cy = g["y"].cumsum() - f["y"]
        cm = g["mu"].cumsum() - f["mu"]
        prior = f["k"] * f["mu"].clip(lower=1.0)
        u = ((cy + prior) / (cm + prior)).clip(0.2, 5.0)
        out = np.empty(len(match))
        out[f["pos"].to_numpy()] = (f["mu"] * u).to_numpy()
        return out

    # ========================================================== evaluate
    def evaluate_match_total(self, algo: str, days: Sequence) -> dict:
        acc = ScoreAccumulator()
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            p = self.predict_match_total(dd, algo)
            key = p["match_id"].astype(str) + "|" + p["bucket"].astype(str)
            acc.add(algo, p["actual"], p["forecast"], p["last5"], key)
            acc.add("last5", p["actual"], p["last5"], p["last5"], key)
        return {"model": acc.result(algo), "last5": acc.result("last5")}

    def evaluate_pool_share(self, algo: str, days: Sequence) -> dict:
        return self._share_eval(days, lambda dd: self.predict_pool_share(dd, algo), "pool")

    def evaluate_selection_share(self, algo: str, days: Sequence) -> dict:
        return self._share_eval(days, lambda dd: self.predict_selection_share(dd, algo), "selection")

    def _share_eval(self, days, fn, level) -> dict:
        ce, ce_flat, n = 0.0, 0.0, 0.0
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            p = fn(dd)
            a = p["actual_share"].to_numpy(dtype="float64")
            ok = np.isfinite(a)
            key = p.loc[ok, MKEY].astype(str).agg("|".join, axis=1) if level == "pool" else \
                p.loc[ok, PKEY].astype(str).agg("|".join, axis=1)
            flat = 1.0 / key.map(key.value_counts()).to_numpy(dtype="float64")
            ce += float(-np.sum(a[ok] * np.log(np.clip(p["share"].to_numpy(dtype="float64")[ok], 1e-6, 1))))
            ce_flat += float(-np.sum(a[ok] * np.log(np.clip(flat, 1e-6, 1))))
            n += float(key.nunique())
        return {"cross_entropy": ce / max(n, 1), "cross_entropy_flat": ce_flat / max(n, 1), "groups": int(n)}

    def evaluate_selection_turnover(self, pipeline: str, days: Sequence) -> dict:
        s = self._score_days(days, [pipeline, "last5"] if pipeline != "last5" else ["last5"], choose_blend=False)
        return {"model": s.get(pipeline, {}).get("all"), "last5": s.get("last5", {}).get("all")}

    def _score_days(self, days: Sequence, pipelines: Sequence[str], choose_blend: bool,
                    cuts: bool = False) -> dict:
        """Stream days; accumulate scores per pipeline (and per blend weight when choosing)."""
        alphas = list(self.settings.turnover.blend_alphas) if choose_blend else None
        acc = {p: ScoreAccumulator() for p in pipelines}
        daily = {p: [] for p in pipelines}
        cut_acc: Dict[str, ScoreAccumulator] = {}
        # match-day totals (actual, forecast) per pipeline, for the biggest-matches check
        mb: Dict[str, List[np.ndarray]] = {p: [] for p in pipelines}
        for d in days:
            dd = self.store.get(d)
            if dd.empty:
                continue
            sel = dd.sel
            f = sel["forecastable"].to_numpy(dtype=bool)
            y = sel["y"].to_numpy(dtype="float64")
            l5 = sel["tv1"].to_numpy(dtype="float64")
            base = self._blend_base(sel)
            mkey = (sel["match_id"].astype(str) + "|" + sel["bucket"].astype(str)).to_numpy()
            day_cache: dict = {}
            for p in pipelines:
                try:
                    raw = self._pipeline_raw(dd, p, day_cache)
                except ModelError as exc:
                    logger.warning("pipeline %s skipped on %s: %s", p, pd.Timestamp(d).date(), exc)
                    continue
                grid = alphas if (choose_blend and p not in NAIVE) else [self.blend.get(p, 1.0)]
                for a in grid:
                    pred = l5.copy()
                    pred[f] = a * raw + (1 - a) * base[f]
                    acc[p].add(str(a), y, pred, l5, mkey)
                if not choose_blend:
                    daily[p].append(poisson_deviance(y, pred))
                    g = pd.DataFrame({"k": sel["match_id"].to_numpy(), "y": y, "f": pred}).groupby(
                        "k", sort=True)[["y", "f"]].sum()
                    mb[p].append(g.to_numpy(dtype="float64"))
                    if cuts and p in (self.champion, "last5"):
                        for dim in ("phase", "family", "clock_bin", "event_window", "league_code"):
                            if dim not in sel.columns:
                                continue
                            vals = labels(sel[dim])
                            for v in np.unique(vals):
                                m = vals == v
                                cut_acc.setdefault("{}|{}={}".format(p, dim, v), ScoreAccumulator()).add(
                                    "x", y[m], pred[m], l5[m], mkey[m])
        out = {}
        for p in pipelines:
            names = acc[p].names()
            if not names:
                continue
            if choose_blend and p not in NAIVE:
                best = min(names, key=lambda a: acc[p].result(a)["deviance"])
                base = acc[p].result("0.0") if "0.0" in names else None
                a = float(best)
                if base is not None and acc[p].result(best)["deviance"] >= base["deviance"] * (1 - 1e-6):
                    a = 0.0
                self.blend[p] = a
                out[p] = {"all": acc[p].result(str(a)) if str(a) in names else acc[p].result(best),
                          "by_alpha": {n: acc[p].result(n)["deviance"] for n in names}}
            else:
                if p in NAIVE:
                    self.blend.setdefault(p, 1.0)
                out[p] = {"all": acc[p].result(names[0])}
                if mb[p]:
                    out[p]["all"].update(_biggest(np.vstack(mb[p])))
            out[p]["daily_deviance"] = daily[p]
        if cuts:
            out["_cuts"] = {k: v.result("x") for k, v in cut_acc.items()}
            base = daily.get("last5") or []
            out["_dm"] = {p: diebold_mariano(daily[p], base) for p in pipelines if p != "last5" and daily[p]}
        return out

    def _pick_champion(self, val_scores: dict) -> str:
        best, best_dev = "last5", (val_scores.get("last5", {}).get("all") or {}).get("deviance", np.inf)
        for p, s in val_scores.items():
            if p.startswith("_"):
                continue
            dev = (s.get("all") or {}).get("deviance")
            if dev is not None and dev < best_dev * (1 - 1e-6):
                best, best_dev = p, dev
        # Validation days rarely hold a match bigger than every training match; the future will. When
        # the winner's level is a tree or a network and its GLM-anchored twin is as good within the
        # tolerance, serve the twin: same accuracy, and it does not stop at the biggest training value.
        tol = float(self.settings.turnover.extrapolation_tolerance)
        kind, algos = _parse_pipeline(best)
        if tol > 0 and kind in ("direct", "three_stage") and algos[0] in LEVEL_ANCHOR:
            twin = "{}:{}".format(kind, "+".join((LEVEL_ANCHOR[algos[0]],) + algos[1:]))
            t = (val_scores.get(twin) or {}).get("all") or {}
            b = (val_scores.get(best) or {}).get("all") or {}
            twin_dev, twin_bias, best_bias = t.get("deviance"), t.get("bias"), b.get("bias")
            # as good means as good on the level too: a deviance this close can hide a level 15% short
            level_ok = twin_bias is None or best_bias is None or abs(twin_bias) <= abs(best_bias) + 0.02
            if twin_dev is not None and twin_dev <= best_dev * (1 + tol) and level_ok:
                logger.info("champion %s -> %s: validation deviance %.4g vs %.4g is within %.1f%% (bias %+.1f%% vs "
                            "%+.1f%%), and the anchored level extrapolates past the training range", best, twin,
                            twin_dev, best_dev, 100 * tol, 100 * (twin_bias or 0), 100 * (best_bias or 0))
                return twin
            if twin_dev is not None:
                logger.info("champion %s kept: its anchored twin %s is %.1f%% worse on validation (tolerance %.1f%%), "
                            "bias %+.1f%% vs %+.1f%%", best, twin, 100 * (twin_dev / best_dev - 1), 100 * tol,
                            100 * (twin_bias or 0), 100 * (best_bias or 0))
        return best

    def _leaderboard(self, val: dict, test: dict) -> List[dict]:
        rows = []
        for p in val:
            if p.startswith("_"):
                continue
            v, t = (val[p].get("all") or {}), ((test.get(p) or {}).get("all") or {})
            dm = (test.get("_dm") or {}).get(p) or {}
            rows.append({"pipeline": p, "blend": self.blend.get(p, 1.0), "champion": p == self.champion,
                         "val_deviance": v.get("deviance"), "val_wape": v.get("wape"),
                         "test_deviance": t.get("deviance"), "test_wape": t.get("wape"),
                         "test_active_wape": t.get("active_wape"), "test_match_wape": t.get("match_wape"),
                         "test_bias": t.get("bias"), "test_top1_bias": t.get("top1_bias"),
                         "test_top1_wape": t.get("top1_wape"), "dm_stat_vs_last5": dm.get("stat"),
                         "dm_p_vs_last5": dm.get("p_value"), "days_better": dm.get("days_a_better"),
                         "days_worse": dm.get("days_b_better")})
        rows.sort(key=lambda r: (r["test_deviance"] is None, r["test_deviance"] or 0))
        return rows

    # =================================================== walk-forward series
    def write_backtest_series(self, days: Sequence, pipeline: Optional[str] = None,
                              name: Optional[str] = None) -> dict:
        """Honest day-by-day series for the W06 workbench: day N from a fit on days before N.

        Writes Backtest_Data/Turnover/<name>/_keyed/<day>.parquet and aligns it
        to Backtest_Data/index when that exists (the workbench's row order).
        """
        from src.backtest.parquet.raw_turnover import align_day
        pipeline = pipeline or self.champion
        name = name or "algoe_" + pipeline.replace(":", "_").replace("+", "_")
        w = self.settings.window
        root = self.settings.paths.backtest_data
        kind, algos = _parse_pipeline(pipeline)
        needed = _components(pipeline)
        frozen = dict(self.models), dict(self.blend), self.engineer.encoders
        report = {"pipeline": pipeline, "name": name, "days": []}
        try:
            for day, fit_days, choose_days, refit in walk_forward(days, w.walk_forward_warmup_days,
                                                                   w.walk_forward_refit_days, min(3, w.val_days)):
                dd = self.store.get(day)
                if dd.empty:
                    continue
                if fit_days and refit and needed:
                    self._refit_components(fit_days, choose_days, needed, pipeline)
                use = pipeline if (fit_days and (needed or kind == "naive")) else "last5"
                pred = self.predict_selection_turnover(dd, use)
                keyed = pred[["match_id", "pool_name", "line_id", "combination_id", "bucket"]].copy()
                keyed["value"] = pred["forecast"].astype("float32")
                stamp = "{:%Y-%m-%d}".format(pd.Timestamp(day))
                write_parquet(keyed, root / "Turnover" / name / "_keyed" / "{}.parquet".format(stamp))
                aligned = align_day(root, name, stamp)
                row = {"day": stamp, "pipeline_used": use, "refit": bool(refit and fit_days),
                       "deviance_model": poisson_deviance(pred["actual"], pred["forecast"]),
                       "deviance_last5": poisson_deviance(pred["actual"], pred["last5"])}
                if aligned:
                    row.update(aligned)
                report["days"].append(row)
                logger.info("walk-forward %s %s: deviance %s vs last5 %s%s", name, stamp,
                            _fmt(row["deviance_model"]), _fmt(row["deviance_last5"]),
                            "" if aligned else " (no Backtest_Data/index yet; keyed file written)")
        finally:
            self.models, self.blend, self.engineer.encoders = frozen[0], frozen[1], frozen[2]
        return report

    def refit_for_serving(self, days: Sequence) -> dict:
        """Refit the champion pipeline on the newest days for serving.

        train_all chooses and scores honestly, so the model it leaves behind has
        never seen the last val + test days - three weeks by default, which is
        stale at the start of a season. This refits only the champion's
        components on every day but the last val_days, re-chooses the blend
        toward last 5 minutes on those, and drops the other pipelines (their
        models were fitted with the old encoders). The leaderboard keeps the
        honest numbers; the Backtester must not be run on a refitted bundle,
        because its test days are now in the fit.
        """
        needed = _components(self.champion)
        if not needed:
            return {"refit": False, "reason": "{} has no fitted component".format(self.champion)}
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        v = max(1, min(self.settings.window.val_days, len(usable) // 4))
        fit_days, blend_days = usable[:-v], usable[-v:]
        detail = "fit {}..{} ({} days), blend on {}..{}".format(
            fit_days[0].date(), fit_days[-1].date(), len(fit_days), blend_days[0].date(), blend_days[-1].date())
        with log_step(logger, "R", "refit {} for serving".format(self.champion), detail) as step:
            self._refit_components(fit_days, blend_days, needed, self.champion)
            keep = {(a, r) for r, a in needed.items()}
            self.models = {k: m for k, m in self.models.items() if k in keep}
            info = {"refit": True, "fit": [str(fit_days[0].date()), str(fit_days[-1].date()), len(fit_days)],
                    "blend_days": [str(d.date()) for d in blend_days],
                    "blend": float(self.blend.get(self.champion, 1.0))}
            self.metadata["serving_fit"] = info
            step["result"] = "blend {:.2f}; {} component(s) kept".format(info["blend"], len(self.models))
        return info

    def _refit_components(self, fit_days, choose_days, needed: Dict[str, str], pipeline: str) -> None:
        t = self.settings.turnover
        rng = np.random.default_rng(t.seed)
        cut = choose_days[0] if len(choose_days) else pd.Timestamp(fit_days[-1]) + pd.Timedelta(days=1)
        self.engineer.fit_encoders_from(self.store, fit_days, cutoff=cut)
        data = TrainingData(split=DaySplit(tuple(fit_days), tuple(choose_days), tuple()))
        for role, role_days in (("train", fit_days), ("val", choose_days)):
            for r in needed:
                lst = []
                for d in role_days:
                    fs = getattr(self.engineer, RESPONSES[r].builder)(self.store.get(d))
                    if len(fs):
                        lst.append(_sample_groups(fs, _day_cap(t, r, len(role_days)), rng))
                if lst:
                    getattr(data, role)[r] = FeatureSet.concat(lst)
        for r, a in needed.items():
            self._train(a, r, data)
        if choose_days:
            self._score_days(choose_days, [pipeline], choose_blend=True)

    # ========================================================= persistence
    def to_bundle(self) -> dict:
        return {"models": {"{}|{}".format(a, r): m.to_state() for (a, r), m in self.models.items()},
                "encoders": self.engineer.encoders.to_state(), "blend": dict(self.blend),
                "profile": dict(self.profile), "champion": self.champion,
                "nowcast_prior_minutes": self.nowcaster.m0}

    def save(self, promote: bool = True) -> str:
        version = self.model_store.new_version(self.champion.replace(":", "-").replace("+", "_"))
        self.model_store.save(version, self.to_bundle(), self.metadata)
        self.version = version
        if promote:
            lb = {r["pipeline"]: r for r in self.leaderboard}
            champ = lb.get(self.champion, {})
            base = lb.get("last5", {})
            if self.champion == "last5":
                if self.model_store.champion() is None:
                    self.model_store.promote(version, "no model beat last 5 minutes on validation days; "
                                                      "serving the baseline")
                else:
                    logger.warning("no model beat last 5 minutes; the existing champion %s is kept",
                                   self.model_store.champion())
            elif champ.get("test_deviance") is not None and base.get("test_deviance") is not None:
                vs = self.metadata.get("versus_champion")
                self.model_store.promote_if_better(
                    version, "deviance", champ["val_deviance"] or np.inf, base["val_deviance"] or np.inf,
                    versus=(vs["challenger"], vs["champion_score"]) if vs else None)
                if champ["test_deviance"] >= base["test_deviance"]:
                    logger.warning("champion %s did not beat last 5 minutes on TEST days (%.4g vs %.4g); "
                                   "it was chosen on validation days - check the leaderboard before using it",
                                   self.champion, champ["test_deviance"], base["test_deviance"])
        return version

    @classmethod
    def load(cls, settings, version: Optional[str] = None, engineer: Optional[FeatureEngineer] = None,
             store: Optional[FeatureStore] = None) -> "TurnoverForecaster":
        from ..features.encoders import EncoderState
        ms = ModelStore(settings.paths.models, "turnover", FEATURE_VERSION)
        bundle, meta = ms.load(version)
        eng = engineer or FeatureEngineer(settings)
        eng.encoders = EncoderState.from_state(bundle.get("encoders"))
        f = cls(settings, eng, store, ms)
        f.models = {tuple(k.split("|", 1)): load_estimator(v) for k, v in bundle["models"].items()}
        f.blend = dict(bundle.get("blend") or {})
        f.profile = dict(bundle.get("profile") or {})
        f.champion = bundle.get("champion", "last5")
        f.nowcaster.m0 = float(bundle.get("nowcast_prior_minutes", f.nowcaster.m0))
        f.version, f.metadata = meta.get("version"), meta
        f.leaderboard = meta.get("leaderboard") or []
        logger.info("loaded turnover %s: champion %s, %d model(s)", f.version, f.champion, len(f.models))
        return f


# --------------------------------------------------------------- helpers
def _parse_pipeline(p: str) -> Tuple[str, Tuple[str, ...]]:
    p = str(p).strip()
    if p in NAIVE:
        return "naive", (p,)
    if ":" not in p:
        raise ModelError("pipeline {!r} must be naive (last5|ma3|ema|profile), direct:<algo>, "
                         "three_stage:<algo>+<algo>+<algo> or four_stage:<algo>+<algo>+<algo>+<algo>".format(p))
    kind, rest = p.split(":", 1)
    algos = tuple(rest.split("+"))
    if kind in STAGES and len(algos) == len(STAGES[kind]):
        return kind, algos
    raise ModelError("pipeline {!r} is not understood".format(p))


# the response each stage of a composed pipeline is fitted on
STAGES = {"direct": ("selection_turnover",),
          "three_stage": ("match_total", "pool_share", "selection_share"),
          "four_stage": ("board_total", "match_share", "pool_share", "selection_share")}


def _components(p: str) -> Dict[str, str]:
    """response -> algorithm for every fitted component of a pipeline ({} for a naive one)."""
    kind, algos = _parse_pipeline(p)
    return dict(zip(STAGES[kind], algos)) if kind in STAGES else {}


def _reference(X: pd.DataFrame) -> dict:
    from ..monitoring.monitor import Monitor
    return Monitor.feature_reference(X)


def labels(series: pd.Series) -> np.ndarray:
    """Text labels with missing values as 'unknown' (pandas 3 keeps NaN through astype(str))."""
    return series.astype("string").fillna("unknown").to_numpy(dtype=object)


def _positions(src: pd.DataFrame, dst: pd.DataFrame) -> np.ndarray:
    """The row of ``src`` holding each row of ``dst``'s keys; -1 where none does."""
    return pd.MultiIndex.from_frame(src).get_indexer(pd.MultiIndex.from_frame(dst))


def _take(values, pos: np.ndarray) -> np.ndarray:
    out = np.full(len(pos), np.nan)
    ok = pos >= 0
    out[ok] = np.asarray(values, dtype="float64")[pos[ok]]
    return out


def _biggest(tot: np.ndarray, share: float = 0.01, at_least: int = 10) -> dict:
    """Bias and WAPE over the biggest matches: the top ``share`` of match-days by the day's actual money
    (a whole day's money, so one lucky bucket does not pick the sample). A model that stops at its
    biggest training value under-forecasts exactly these."""
    if tot.ndim != 2 or len(tot) < at_least:
        return {}
    y, f = tot[:, 0], tot[:, 1]
    n = max(at_least, int(np.ceil(share * len(y))))
    top = np.argsort(-y, kind="stable")[:n]
    sy = float(y[top].sum())
    if sy <= 0:
        return {}
    return {"top1_bias": float(f[top].sum()) / sy - 1.0, "top1_wape": float(np.abs(y[top] - f[top]).sum()) / sy,
            "top1_matches": int(n), "top1_smallest": float(y[top].min())}


def _normalise(raw: np.ndarray, group: np.ndarray) -> np.ndarray:
    raw = np.clip(np.nan_to_num(np.asarray(raw, dtype="float64"), nan=0.0), 0, None)
    den = pd.Series(raw).groupby(np.asarray(group)).transform("sum").to_numpy()
    n = pd.Series(raw).groupby(np.asarray(group)).transform("size").to_numpy()
    return np.where(den > 0, raw / np.maximum(den, 1e-300), 1.0 / np.maximum(n, 1))


def true_odds_coverage(store, days, sample: int = 15) -> float:
    """Share of forecastable rows with an HKJC true price, over up to ``sample`` of ``days``."""
    days = list(days)
    if not days:
        return float("nan")
    n = hit = 0
    for i in sorted({int(x) for x in np.linspace(0, len(days) - 1, min(sample, len(days)))}):
        s = store.get(days[i]).sel
        if s.empty or "p_hkjc_true" not in s.columns:
            continue
        f = s["forecastable"].to_numpy(dtype=bool)
        n += int(f.sum())
        hit += int(np.isfinite(s.loc[f, "p_hkjc_true"].to_numpy(dtype="float64")).sum())
    return hit / n if n else float("nan")


def _hybrid_last5(sel: pd.DataFrame) -> np.ndarray:
    """A line's own last-bucket money; its slot's only for a line that was not priced a bucket ago
    and took nothing of its own (a line opened during the last bucket keeps its own money)."""
    own = sel["tv1"].to_numpy(dtype="float64")
    if "line_new" not in sel.columns:
        return own
    empty = (sel["line_new"].to_numpy(dtype="float64") > 0) & ~(own > 0)
    return np.where(empty, sel["pos_tv1"].to_numpy(dtype="float64"), own)


def _last_market_index(store, days) -> Optional[float]:
    for d in sorted(days, reverse=True):
        m = store.get(d).match
        if len(m) and "market_index" in m.columns:
            return float(m["market_index"].iloc[0])
    return None


def _cutoff(split: DaySplit) -> pd.Timestamp:
    """The first day the model is chosen or scored on: encoders may learn from anything before it."""
    for part in (split.val, split.test):
        if len(part):
            return pd.Timestamp(min(part)).normalize()
    return pd.Timestamp(max(split.train)).normalize() + pd.Timedelta(days=1)


def _day_cap(t, response: str, n_days: int) -> int:
    """Rows to keep from one day: the per-day cap, shrunk so n_days fit in max_fit_rows."""
    per_day = 10 ** 9 if response in ("match_total", "match_share", "board_total") else t.fit_rows_per_day
    return int(max(500, min(per_day, t.max_fit_rows // max(n_days, 1))))


def _sample_groups(fs: FeatureSet, cap: int, rng) -> FeatureSet:
    """Keep whole normalisation groups so sampled shares still sum to one."""
    if len(fs) <= cap:
        return fs
    groups = np.unique(fs.group)
    frac = cap / len(fs)
    keep = set(groups[rng.random(len(groups)) < frac].tolist())
    return fs.subset(np.isin(fs.group, list(keep)))


def _fmt(x) -> str:
    return "n/a" if x is None else "{:,.1f}".format(x)


def _pct(x) -> str:
    return "n/a" if x is None else "{:.1%}".format(x)
