"""
Step 10 - the nightly refresh (Windows Task Scheduler)

On a rolling window ending yesterday: build the new panel and feature days,
check health on the last 7 days, retrain turnover and probability (chosen and
scored honestly, then refitted on the newest days for serving), and promote
only what beats last 5 minutes and the current champion. Each step has its
own run folder; the nightly log is under AlgoE_Work/logs.

    python scripts/s10_nightly.py                    window of 75 days ending yesterday
    python scripts/s10_nightly.py --window-days 60 --end 2026-09-15

Exit code 1 if a step failed, 2 if it finished with monitor alerts.
Same as: python -m algoe nightly
"""
from _algoe import run

if __name__ == "__main__":
    run("nightly")
