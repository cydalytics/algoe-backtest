"""
Feature Store

``prepare_day`` is the expensive part of every experiment, and it depends
only on the panel and the feature settings - never on which model is being
tried. So each day's DayData is built once and kept:

    <work>/features/<key>/<YYYY-MM-DD>.{sel,match,pool}.parquet

``key`` hashes the panel cache space, the feature settings and
FEATURE_VERSION. Change any of them and a new folder is used; nothing stale
is ever read back.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      FEATURE_VERSION 4 (odds age, FH after half time, goal pulse, midnight);
                5 (a pool is forecastable only while open at the bucket start); 6 (probabilities
                cached at float64); build(days, workers): months in parallel processes;
                7 (money in market-index units, slots by offset from the best line, customer
                features, m_margin, computed holidays); a cached day is rebuilt if its market index
                changed; available_days for the encoders' history
"""

from __future__ import annotations

import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..core.io import stable_hash, write_parquet
from ..core.logging import get_logger
from .engineer import DayData, FeatureEngineer

logger = get_logger(__name__)

# Bump when engineer.py changes a column or a number.
FEATURE_VERSION = 7


class FeatureStore:
    def __init__(self, settings, panel, engineer: FeatureEngineer, enabled: bool = True):
        self.settings = settings
        self.panel = panel
        self.engineer = engineer
        self.enabled = enabled
        self.key = stable_hash({"v": FEATURE_VERSION, "space": getattr(panel.cache, "space", "live"),
                                "features": asdict(settings.features)})
        self.root = Path(settings.paths.features) / self.key
        self._memo: dict = {}

    def _paths(self, day):
        stem = "{:%Y-%m-%d}".format(pd.Timestamp(day))
        return {k: self.root / "{}.{}.parquet".format(stem, k) for k in ("sel", "match", "pool")}

    def get(self, day, keep_in_memory: bool = False) -> DayData:
        day = pd.Timestamp(day).normalize()
        if day in self._memo:
            return self._memo[day]
        paths = self._paths(day)
        index = self._market_index(day)
        dd = None
        if self.enabled and all(p.exists() for p in paths.values()):
            dd = DayData(day, *(pd.read_parquet(paths[k]) for k in ("sel", "match", "pool")))
            cached = float(dd.match["market_index"].iloc[0]) if "market_index" in dd.match.columns and len(dd.match) \
                else float("nan")
            if not np.isclose(cached, index if np.isfinite(index) else 1.0, rtol=1e-9, atol=0.0):
                # days before it were added to the panel cache since: its money is in other units now
                logger.info("features %s: market index %.6g, cached with %.6g - rebuilding", day.date(),
                            index, cached)
                dd = None
        if dd is None:
            panel = self.panel.load_day(day)
            if panel is None:
                dd = DayData(day, pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
            else:
                dd = self.engineer.prepare_day(panel, self.panel.previous_tail(day), self.panel.events_for(day),
                                               self.panel.market_for(day), day=day, market_index=index)
            if self.enabled and not dd.empty:
                for k in ("sel", "match", "pool"):
                    write_parquet(_compact(getattr(dd, k)), paths[k])
        if keep_in_memory:
            self._memo[day] = dd
        return dd

    def _market_index(self, day) -> float:
        fn = getattr(self.panel, "market_index", None)
        return float(fn(day)) if fn is not None else float("nan")

    def has(self, day) -> bool:
        return all(p.exists() for p in self._paths(day).values())

    def available_days(self) -> List[pd.Timestamp]:
        """Days whose features are cached (any build, any window)."""
        if not self.root.exists():
            return []
        out = []
        for p in self.root.glob("*.match.parquet"):
            try:
                out.append(pd.Timestamp(p.name.split(".", 1)[0]))
            except ValueError:
                continue
        return sorted(d for d in out if self.has(d))

    def summary(self, day) -> dict:
        """A cached day's row counts, read from two columns rather than the whole day."""
        p = self._paths(day)
        out = {"day": str(pd.Timestamp(day).date()), "selection_rows": 0, "forecastable": 0, "matches": 0,
               "theta_coverage": None}
        if all(x.exists() for x in p.values()):
            f = pd.read_parquet(p["sel"], columns=["forecastable"])
            try:
                m = pd.read_parquet(p["match"], columns=["match_id", "tg"])
            except Exception:                                           # noqa: BLE001
                m = pd.read_parquet(p["match"], columns=["match_id"]).assign(tg=np.nan)
            out.update(selection_rows=len(f), forecastable=int(f["forecastable"].sum()),
                       matches=int(m["match_id"].nunique()),
                       # share of match-buckets with HKJC's TG: below about 0.9, its parameters feed had gaps
                       theta_coverage=round(float(np.isfinite(pd.to_numeric(m["tg"], errors="coerce")).mean()), 3)
                       if len(m) else None)
        return out

    def build(self, days, workers: int = 1) -> List[dict]:
        """Every day's features on disk (months in parallel processes when workers > 1); one
        summary row per day."""
        from ..core.exceptions import DataError
        from ..data.panel import by_month, worker_count
        todo = [pd.Timestamp(d).normalize() for d in days if not self.has(d)]
        months = by_month(todo)
        n = worker_count(workers, len(months)) if months else 1
        logger.info("features: %d of %d day(s) to build, %d month(s), %d worker(s) -> %s",
                    len(todo), len(days), len(months), n, self.root)
        seconds: Dict[str, float] = {}
        if n <= 1:
            for d in todo:
                t0 = time.time()
                self.get(d)
                seconds[str(d.date())] = round(time.time() - t0, 1)
                logger.info("features %s built in %.1fs", d.date(), seconds[str(d.date())])
        else:
            failed = []
            payload = self.settings.to_dict()
            with ProcessPoolExecutor(max_workers=n) as pool:
                futures = {pool.submit(_feature_worker, payload, [str(d.date()) for d in ds]): m
                           for m, ds in months.items()}
                for k, fut in enumerate(as_completed(futures), 1):
                    month = futures[fut]
                    try:
                        seconds.update(fut.result())
                    except Exception as exc:                    # noqa: BLE001
                        failed.append(month)
                        logger.error("features month %s failed: %s: %s", month, type(exc).__name__, exc)
                        continue
                    logger.info("features month %s done (%d/%d months)", month, k, len(months))
            if failed:
                raise DataError("feature month(s) {} failed (see the errors above); the other months are "
                                "cached - rerun to retry".format(", ".join(sorted(failed))))
        rows = []
        for d in days:
            r = self.summary(d)
            r["seconds"] = seconds.get(r["day"], 0.0)
            rows.append(r)
        thin = [r["day"] for r in rows if r.get("theta_coverage") is not None and r["theta_coverage"] < 0.5]
        if thin:
            logger.warning("%d day(s) have HKJC TG / SUP for under half their match-buckets (gaps in HKJC_Parameters; "
                           "those matches are priced and optimised without them): %s", len(thin),
                           ", ".join(thin[:20]) + (" ..." if len(thin) > 20 else ""))
        return rows


_WORKER: dict = {}


def _feature_worker(payload: dict, days: List[str]) -> Dict[str, float]:
    """Child process: build these days' feature files (one file set per day, nothing shared)."""
    store = _WORKER.get("store")
    if store is None:
        from ..data.panel import HistoricalPanel
        from ..settings import Settings
        s = Settings.from_dict(payload)
        store = _WORKER["store"] = FeatureStore(s, HistoricalPanel(s), FeatureEngineer(s))
    out = {}
    for d in days:
        t0 = time.time()
        store.get(d)
        out[d] = round(time.time() - t0, 1)
        logger.info("features %s built in %.1fs", d, out[d])
    return out


def _compact(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    for c in out.columns:
        # Probabilities stay float64: the belief models read their logits, and float32 rounding near
        # 0 or 1 moves a logit by ~1e-4 - a gap between training (cached) and serving (fresh).
        if pd.api.types.is_float_dtype(out[c]) and c not in ("y", "turnover", "pool_y", "exposure", "last5",
                                                               "market_index", "pos_tv1") \
                and not c.startswith("p_"):
            out[c] = out[c].astype("float32")
        elif out[c].dtype == object:
            out[c] = out[c].astype("string")
    return out
