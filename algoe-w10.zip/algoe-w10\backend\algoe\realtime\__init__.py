"""Live loop: 5-minute full sweep, focus-match refresh, intra-bucket nowcast."""
