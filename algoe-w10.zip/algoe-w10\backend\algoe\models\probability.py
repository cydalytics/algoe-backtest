"""
Probability Calibrator

What the desk believes each selection is worth - the p in
E[GM] = sum T x (1 - O x p) - and whether that belief means what it says.

SOURCES (each renormalised so a line's sides sum to one):

    hkjc_true   1 / HKJC true odds                        the MVP rule
    market      median bookmaker price, de-margined       the outside view
    poisson     HKJC's TG/SUP through our pricer,         their parameters,
                in-play score applied                     our maths
    demargin    HKJC's public odds, margin removed        the offer itself

METHODS (all fitted on train days, chosen on validation days, reported on
test days; all but ``raw`` map in logit space):

    raw:<s>          p = source                          the baseline to beat
    platt:<s>        logit p' = a + b logit p            b < 1 fixes over-confidence
    beta:<s>         logit p' = a + b ln p - c ln(1-p)   asymmetric (favourite-longshot)
    isotonic:<s>     monotone map (PAV)                  no shape assumed
    logit_pool       logit p' = w0 + sum_s w_s logit p_s  the roadmap's
                                                          p = b0 p_HKJC + b1 p_Market,
                                                          done where probabilities add
    contextual       logit_pool + phase / family / odds-band / clock interactions

After mapping, the sides of every line are renormalised so the belief the
optimiser prices against is coherent.

OUTCOMES are read from the money actually paid (engineer._outcome): soft
label (r + 1) / 2 for full / half win or loss; pushes carry no information
and are dropped. Every settled selection counts once however long it
traded (settings.probability.weight = "selection"), so a pre-match line that
sat on the board for six hours does not outvote an in-play one.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Feature version on every bundle; refit_for_serving
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.exceptions import ModelError
from ..core.logging import get_logger, log_step
from ..data.splits import DaySplit
from ..evaluation.metrics import calibration_bins, probability_scores
from ..features.engineer import FeatureEngineer, FeatureSet
from ..features.store import FEATURE_VERSION, FeatureStore
from ..pricing.panel_pricing import price_rows_at_hkjc
from ..pricing.pricer import Conventions
from ..registry.model_store import ModelStore
from .estimators import GLMEstimator

logger = get_logger(__name__)

SOURCES = ("hkjc_true", "market", "poisson", "demargin")
SINGLE = ("platt", "beta", "isotonic")
EPS = 1e-4


def _logit(p):
    p = np.clip(np.asarray(p, dtype="float64"), EPS, 1 - EPS)
    return np.log(p / (1 - p))


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def _pav(x, y, w):
    order = np.argsort(x, kind="mergesort")
    xs, ys, ws = x[order], y[order], w[order]
    blocks = []                          # [sum_wy, sum_w, x_hi]
    for xv, yv, wv in zip(xs, ys, ws):
        blocks.append([yv * wv, wv, xv])
        while len(blocks) > 1 and blocks[-2][0] / blocks[-2][1] >= blocks[-1][0] / blocks[-1][1]:
            b = blocks.pop()
            blocks[-1][0] += b[0]
            blocks[-1][1] += b[1]
            blocks[-1][2] = b[2]
    xk = np.array([b[2] for b in blocks])
    yk = np.array([b[0] / b[1] for b in blocks])
    return xk, yk


class ProbabilityCalibrator:
    def __init__(self, settings, engineer: Optional[FeatureEngineer] = None, store: Optional[FeatureStore] = None,
                 model_store: Optional[ModelStore] = None):
        self.settings = settings
        self.engineer = engineer or FeatureEngineer(settings)
        self.store = store
        self.model_store = model_store or ModelStore(settings.paths.models, "probability", FEATURE_VERSION)
        o = settings.optimizer
        self.conventions = Conventions(o.settle_total, o.settle_handicap)
        self.fitted: Dict[str, dict] = {}
        self.champion = "raw:hkjc_true"
        self.leaderboard: List[dict] = []
        self.metadata: dict = {}
        self.version: Optional[str] = None

    # ============================================================ data
    def features_for_day(self, day, require_outcome: bool = True) -> FeatureSet:
        """Probability rows for one day (a date, or a DayData) with the in-play-correct poisson source."""
        dd = day if hasattr(day, "sel") else self.store.get(day)
        if dd.empty:
            return self.engineer.features_for_probability(dd, require_outcome)
        sel = dd.sel
        mask = sel["forecastable"].to_numpy(dtype=bool).copy()
        if require_outcome:
            mask &= sel["outcome"].notna().to_numpy()
        p_pois = price_rows_at_hkjc(sel, dd.match, self.conventions, mask)
        dd2 = type(dd)(dd.day, sel.assign(p_poisson=_renorm(sel, p_pois)), dd.match, dd.pool)
        return self.engineer.features_for_probability(dd2, require_outcome)

    def predict_for_day(self, day, method: Optional[str] = None) -> np.ndarray:
        """Belief for every row of day.sel (NaN where the price is not live or not priceable)."""
        dd = day if hasattr(day, "sel") else self.store.get(day)
        out = np.full(len(dd.sel), np.nan)
        if dd.empty:
            return out
        fs = self.features_for_day(dd, require_outcome=False)
        if len(fs):
            out[fs.keys["_row"].to_numpy()] = self.predict_true_prob(fs, method)
        return out

    def _day_cap(self, n_days: int) -> int:
        """Settled selections to keep from one day, so n_days fit in probability.max_fit_rows."""
        return int(max(500, min(60000, self.settings.probability.max_fit_rows // max(n_days, 1))))

    def _collect(self, days: Sequence, cap_per_day: int = 60000, seed: int = 7) -> Optional[FeatureSet]:
        rng = np.random.default_rng(seed)
        parts = []
        for d in days:
            fs = self.features_for_day(d)
            if not len(fs):
                continue
            if len(fs) > cap_per_day:
                fs = fs.subset(rng.random(len(fs)) < cap_per_day / len(fs))
            parts.append(fs)
        return FeatureSet.concat(parts) if parts else None

    # =================================================== train (systematic)
    def train_platt_hkjc_true(self, fs): return self._train_single("platt", "hkjc_true", fs)
    def train_platt_market(self, fs): return self._train_single("platt", "market", fs)
    def train_platt_poisson(self, fs): return self._train_single("platt", "poisson", fs)
    def train_platt_demargin(self, fs): return self._train_single("platt", "demargin", fs)
    def train_beta_hkjc_true(self, fs): return self._train_single("beta", "hkjc_true", fs)
    def train_beta_market(self, fs): return self._train_single("beta", "market", fs)
    def train_isotonic_hkjc_true(self, fs): return self._train_single("isotonic", "hkjc_true", fs)
    def train_isotonic_market(self, fs): return self._train_single("isotonic", "market", fs)

    def train_logit_pool(self, fs: FeatureSet) -> dict:
        X = self._pool_design(fs.keys)
        m = GLMEstimator("binomial", ridge=self.settings.probability.ridge * 1e-3).fit(X, fs.y, weight=fs.weight)
        self.fitted["logit_pool"] = {"kind": "glm", "model": m.to_state(), "design": "pool"}
        logger.info("logit_pool weights: %s", {k: round(v, 3) for k, v in m.coefficients().items()})
        return self.fitted["logit_pool"]

    def train_contextual(self, fs: FeatureSet) -> dict:
        X = self._context_design(fs)
        m = GLMEstimator("binomial", ridge=self.settings.probability.ridge * 1e-2).fit(X, fs.y, weight=fs.weight)
        self.fitted["contextual"] = {"kind": "glm", "model": m.to_state(), "design": "context"}
        return self.fitted["contextual"]

    def _train_single(self, method: str, source: str, fs: FeatureSet) -> Optional[dict]:
        p = fs.keys["p_" + source].to_numpy(dtype="float64")
        ok = np.isfinite(p)
        name = "{}:{}".format(method, source)
        if ok.sum() < self.settings.probability.min_fit_rows:
            logger.warning("%s skipped: %d rows with the source (need %d)", name, int(ok.sum()),
                           self.settings.probability.min_fit_rows)
            return None
        y, w = fs.y[ok], fs.weight[ok]
        if method == "isotonic":
            xk, yk = _pav(p[ok], y, w)
            self.fitted[name] = {"kind": "isotonic", "x": xk, "y": np.clip(yk, EPS, 1 - EPS)}
        else:
            lp = _logit(p[ok])
            X = pd.DataFrame({"lp": lp}) if method == "platt" else \
                pd.DataFrame({"lnp": np.log(np.clip(p[ok], EPS, 1)), "ln1p": np.log(np.clip(1 - p[ok], EPS, 1))})
            m = GLMEstimator("binomial", ridge=1e-6).fit(X, y, weight=w)
            self.fitted[name] = {"kind": "glm", "model": m.to_state(), "design": method}
            logger.info("%s: %s", name, {k: round(v, 4) for k, v in m.coefficients().items()})
        return self.fitted[name]

    # ======================================================== design
    @staticmethod
    def _pool_design(keys: pd.DataFrame) -> pd.DataFrame:
        X = {}
        for s in SOURCES:
            p = keys["p_" + s].to_numpy(dtype="float64")
            has = np.isfinite(p)
            X["logit_" + s] = np.where(has, _logit(np.where(has, p, 0.5)), 0.0)
            X["has_" + s] = has.astype("float64")
        return pd.DataFrame(X)

    def _context_design(self, fs: FeatureSet) -> pd.DataFrame:
        X = self._pool_design(fs.keys)
        c = fs.X
        lh = X["logit_hkjc_true"].to_numpy()
        lm = X["logit_market"].to_numpy()
        for col in ("inplay", "minute", "pre_ko", "rank_0", "log_odds", "book_margin", "side_home_over",
                    "log_odds_age"):
            if col in c.columns:
                X[col] = c[col].to_numpy(dtype="float64")
        ip = c["inplay"].to_numpy(dtype="float64") if "inplay" in c.columns else np.zeros(len(c))
        X["lh_x_inplay"] = lh * ip
        X["lm_x_inplay"] = lm * ip
        X["lh_x_abs"] = lh * np.abs(lh)                   # favourite-longshot curvature
        for f in ("goal_total", "goal_hdc", "corner_total", "corner_hdc", "goal_1x2"):
            col = "fam_" + f
            if col in c.columns:
                X[col] = c[col].to_numpy(dtype="float64")
                X["lh_x_" + f] = lh * c[col].to_numpy(dtype="float64")
        return X

    # ======================================================= predict
    def predict_true_prob(self, fs: FeatureSet, method: Optional[str] = None) -> np.ndarray:
        """Calibrated, line-coherent probability per row; falls back to the raw source where needed."""
        method = method or self.champion
        keys = fs.keys
        base = keys["p_hkjc_true"].to_numpy(dtype="float64")
        fallback = np.where(np.isfinite(base), base, keys["p_demargin"].to_numpy(dtype="float64"))
        if method.startswith("raw:"):
            p = keys["p_" + method.split(":", 1)[1]].to_numpy(dtype="float64")
            return np.where(np.isfinite(p), p, fallback)
        fit = self.fitted.get(method)
        if fit is None:
            raise ModelError("calibration {!r} is not trained".format(method))
        if method in ("logit_pool", "contextual"):
            X = self._pool_design(keys) if method == "logit_pool" else self._context_design(fs)
            p = GLMEstimator.from_state(fit["model"]).predict(X)
        else:
            src = method.split(":", 1)[1]
            raw = keys["p_" + src].to_numpy(dtype="float64")
            ok = np.isfinite(raw)
            p = np.full(len(raw), np.nan)
            if fit["kind"] == "isotonic":
                p[ok] = np.interp(raw[ok], fit["x"], fit["y"])
            else:
                m = GLMEstimator.from_state(fit["model"])
                X = pd.DataFrame({"lp": _logit(raw[ok])}) if fit["design"] == "platt" else \
                    pd.DataFrame({"lnp": np.log(np.clip(raw[ok], EPS, 1)), "ln1p": np.log(np.clip(1 - raw[ok], EPS, 1))})
                p[ok] = m.predict(X)
            p = np.where(np.isfinite(p), p, fallback)
        return _renorm_keys(keys, np.clip(p, EPS, 1 - EPS))

    # ======================================================= train all
    def candidates(self) -> List[str]:
        out = ["raw:" + s for s in SOURCES]
        methods = self.settings.probability.methods
        for m in SINGLE:
            if m in methods:
                out += ["{}:{}".format(m, s) for s in ("hkjc_true", "market")]
        for m in ("logit_pool", "contextual"):
            if m in methods:
                out.append(m)
        return out

    def train_all(self, days: Sequence, store: Optional[FeatureStore] = None) -> dict:
        self.store = store or self.store
        if self.store is None:
            raise ModelError("train_all needs a FeatureStore")
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        split = DaySplit.for_window(usable, self.settings.window)
        with log_step(logger, "P1", "collect settled selections", split.describe()) as step:
            train = self._collect(split.train, self._day_cap(len(split.train)))
            val = self._collect(split.val, self._day_cap(len(split.val)))
            test = self._collect(split.test, self._day_cap(len(split.test)))
            if train is None or val is None or test is None:
                raise ModelError("not enough settled selections in one of train / val / test")
            step["result"] = "train {:,} val {:,} test {:,} rows; sources available (train): {}".format(
                len(train), len(val), len(test),
                {s: round(float(np.isfinite(train.keys["p_" + s]).mean()), 3) for s in SOURCES})
        with log_step(logger, "P2", "fit calibrators on train days") as step:
            for name in self.candidates():
                if name.startswith("raw:"):
                    continue
                try:
                    if name in ("logit_pool", "contextual"):
                        getattr(self, "train_" + name)(train)
                    else:
                        method, src = name.split(":")
                        getattr(self, "train_{}_{}".format(method, src))(train)
                except (ModelError, np.linalg.LinAlgError, ValueError, AttributeError) as exc:
                    logger.warning("%s skipped: %s", name, exc)
            step["result"] = "{} fitted".format(len(self.fitted))
        with log_step(logger, "P3", "choose on validation, report on test") as step:
            rows = []
            for name in self.candidates():
                if not name.startswith("raw:") and name not in self.fitted:
                    continue
                rv, rt = self._score(val, name), self._score(test, name)
                rows.append({"method": name, **{"val_" + k: v for k, v in rv.items()},
                             **{"test_" + k: v for k, v in rt.items()}})
            base = next(r for r in rows if r["method"] == "raw:hkjc_true")
            metric = "val_" + self.settings.probability.champion_metric
            best = min((r for r in rows if r.get(metric) is not None), key=lambda r: r[metric])
            self.champion = best["method"] if best[metric] < (base.get(metric) or np.inf) else "raw:hkjc_true"
            for r in rows:
                r["champion"] = r["method"] == self.champion
            rows.sort(key=lambda r: (r.get("test_log_loss") is None, r.get("test_log_loss") or 0))
            self.leaderboard = rows
            champ = next(r for r in rows if r["champion"])
            step["result"] = "champion {}: test log-loss {:.5f} vs raw {:.5f}, ECE {:.4f} vs {:.4f}".format(
                self.champion, champ["test_log_loss"], base["test_log_loss"],
                champ["test_ece"] or 0, base["test_ece"] or 0)
        self.metadata = {"split": split.to_dict(), "champion": self.champion, "leaderboard": self.leaderboard,
                         "selection": {"metric": metric, "days": split.to_dict()["val"],
                                       metric: next(r[metric] for r in rows if r["champion"])},
                         "calibration_test": {m: calibration_bins(self.predict_true_prob(test, m), test.y,
                                                                  test.weight, 10)
                                              for m in ("raw:hkjc_true", self.champion)},
                         "cuts_test": self._cuts(test), "settings": self.settings.to_dict()["probability"]}
        return self.metadata

    def _score(self, fs: FeatureSet, method: str) -> dict:
        p = self.predict_true_prob(fs, method)
        out = probability_scores(p, fs.y, fs.weight)
        stake = fs.keys["stake"].to_numpy(dtype="float64")
        odds = fs.keys["odds"].to_numpy(dtype="float64")
        r = fs.keys["outcome"].to_numpy(dtype="float64")
        pay = np.select([r >= 0.99, r >= 0.49, r <= -0.99, r <= -0.49], [odds, 0.5 * odds + 0.5, 0.0, 0.5], 1.0)
        m = stake > 0
        if m.any():
            out["expected_margin"] = float(np.sum(stake[m] * (1 - odds[m] * p[m])) / np.sum(stake[m]))
            out["realised_margin"] = float(np.sum(stake[m] * (1 - pay[m])) / np.sum(stake[m]))
        return out

    def _cuts(self, fs: FeatureSet) -> Dict[str, dict]:
        out = {}
        for dim in ("phase", "family"):
            vals = fs.cuts[dim].astype(str).to_numpy()
            for v in np.unique(vals):
                m = vals == v
                if m.sum() < 200:
                    continue
                sub = fs.subset(m)
                out["{}={}".format(dim, v)] = {meth: self._score(sub, meth)
                                               for meth in ("raw:hkjc_true", self.champion)}
        return out

    def refit_for_serving(self, days: Sequence) -> dict:
        """Refit the champion calibration on every day, test block included (see TurnoverForecaster)."""
        if self.champion.startswith("raw:"):
            return {"refit": False, "reason": "{} needs no fit".format(self.champion)}
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        with log_step(logger, "R", "refit {} for serving".format(self.champion),
                      "{}..{} ({} days)".format(usable[0].date(), usable[-1].date(), len(usable))) as step:
            fs = self._collect(usable, self._day_cap(len(usable)))
            if fs is None:
                raise ModelError("no settled selections to refit on")
            if self.champion in ("logit_pool", "contextual"):
                getattr(self, "train_" + self.champion)(fs)
            else:
                method, src = self.champion.split(":")
                getattr(self, "train_{}_{}".format(method, src))(fs)
            self.fitted = {self.champion: self.fitted[self.champion]}
            info = {"refit": True, "days": [str(usable[0].date()), str(usable[-1].date()), len(usable)],
                    "rows": int(len(fs))}
            self.metadata["serving_fit"] = info
            step["result"] = "{:,} settled selections".format(len(fs))
        return info

    # ===================================================== persistence
    def save(self, promote: bool = True) -> str:
        version = self.model_store.new_version(self.champion.replace(":", "-"))
        self.model_store.save(version, {"fitted": self.fitted, "champion": self.champion}, self.metadata)
        self.version = version
        if promote:
            rows = {r["method"]: r for r in self.leaderboard}
            metric = self.metadata["selection"]["metric"]
            if self.champion == "raw:hkjc_true":
                if self.model_store.champion() is None:
                    self.model_store.promote(version, "no calibration beat 1/true_odds; serving the raw source")
            else:
                self.model_store.promote_if_better(version, metric, rows[self.champion][metric],
                                                   rows["raw:hkjc_true"][metric])
        return version

    @classmethod
    def load(cls, settings, version: Optional[str] = None, engineer=None, store=None) -> "ProbabilityCalibrator":
        ms = ModelStore(settings.paths.models, "probability", FEATURE_VERSION)
        bundle, meta = ms.load(version)
        c = cls(settings, engineer, store, ms)
        c.fitted, c.champion = bundle["fitted"], bundle["champion"]
        c.metadata, c.version, c.leaderboard = meta, meta.get("version"), meta.get("leaderboard") or []
        logger.info("loaded probability %s: champion %s", c.version, c.champion)
        return c


def _renorm(sel: pd.DataFrame, p: np.ndarray) -> np.ndarray:
    keys = ["match_id", "pool_name", "line_id", "bucket"]
    s = pd.Series(np.where(np.isfinite(p), p, np.nan))
    tot = s.groupby([sel[k].to_numpy() for k in keys]).transform("sum").to_numpy()
    cnt = s.groupby([sel[k].to_numpy() for k in keys]).transform("count").to_numpy()
    size = s.groupby([sel[k].to_numpy() for k in keys]).transform("size").to_numpy()
    return np.where((cnt == size) & (tot > 0), p / np.where(tot > 0, tot, 1.0), np.nan)


def _renorm_keys(keys: pd.DataFrame, p: np.ndarray) -> np.ndarray:
    cols = [c for c in ("match_id", "pool_name", "line_id", "bucket") if c in keys.columns]
    if not cols:
        return p
    s = pd.Series(p)
    tot = s.groupby([keys[c].to_numpy() for c in cols]).transform("sum").to_numpy()
    size = s.groupby([keys[c].to_numpy() for c in cols]).transform("size").to_numpy()
    # a line with only one settled side in the sample keeps its own number
    return np.where((size >= 2) & (tot > 0), p / np.where(tot > 0, tot, 1.0), p)
