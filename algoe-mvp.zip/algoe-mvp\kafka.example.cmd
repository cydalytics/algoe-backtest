@echo off
REM Algo E - Kafka settings for publishing to HKJC's pricing engine (RUNBOOK, Publishing).
REM
REM Copy this file to %USERPROFILE%\algoe-kafka.cmd and fill it in THERE. start.bat and
REM algoe-7-kafka-check.bat read that copy. Never keep the filled copy in this folder, a zip or git:
REM the bundle is public. The names below carry no values; the Kafka owner gives you yours.
REM Keep the quotes: set "NAME=value" protects & ^ and spaces in a value (write a % as %%).
REM
REM Publishing mode: off (default) | dry_run | test | shadow | live.
REM shadow and live write to production and also need AlgoE_Work\publish\CONFIRM-PRODUCTION.txt
REM holding the line "allow: shadow" or "allow: live". The desk can stop publishing, never start it.
set "ALGOE_PUBLISH=off"

REM Brokers, comma-separated host:port
set "ALGOE_KAFKA_BOOTSTRAP="
REM Topics: params out and prices in, production and test
set "ALGOE_KAFKA_TOPIC_PARAMS="
set "ALGOE_KAFKA_TOPIC_PRICES="
set "ALGOE_KAFKA_TEST_TOPIC_PARAMS="
set "ALGOE_KAFKA_TEST_TOPIC_PRICES="
REM Consumer group for the replies, one per box
set "ALGOE_KAFKA_GROUP="
REM Security protocol: PLAINTEXT | SSL | SASL_PLAINTEXT | SASL_SSL
REM SASL mechanism:    PLAIN | SCRAM-SHA-256 | SCRAM-SHA-512 | GSSAPI
set "ALGOE_KAFKA_SECURITY_PROTOCOL="
set "ALGOE_KAFKA_SASL_MECHANISM="
REM PLAIN / SCRAM login
set "ALGOE_KAFKA_USERNAME="
set "ALGOE_KAFKA_PASSWORD="
REM Kerberos (GSSAPI): principal and keytab file
set "ALGOE_KAFKA_PRINCIPAL="
set "ALGOE_KAFKA_KEYTAB="
set "ALGOE_KAFKA_SERVICE_NAME="
REM The CA certificate file, when the brokers' certificate is not one Windows trusts
set "ALGOE_KAFKA_CA_FILE="
REM Anything else librdkafka needs, as JSON - no secrets here, e.g.
REM set "ALGOE_KAFKA_EXTRA={"socket.timeout.ms": 9000}"
set "ALGOE_KAFKA_EXTRA="
