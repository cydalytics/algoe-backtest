"""
Match_Investments day quality tests - the verdicts, the update's guard and retries, the bet databases, the
days left out downstream, check-data, and the report's changed days

    python tests/test_quality.py               plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_quality.py

No SQL: a fake reader stands in for the HKJC servers.

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      Review: a suspect re-extract, Pool_Details files not read, online bet databases, --days checks,
                suspect days out of the market index and the lag history
"""

import json
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from test_raw_update import NOW, FakeReader, _raw  # noqa: E402

TODAY = pd.Timestamp("2026-10-26")


def _history(end="2026-10-25", days=40, weekday=1_000_000.0, weekend=3_000_000.0):
    """Checked days before ``end``: weekdays HK$1M on 50k rows and 400 of 420 pools, weekends three times that."""
    out = {}
    for d in pd.date_range(pd.Timestamp(end) - pd.Timedelta(days=days), end):
        wk = d.dayofweek >= 5
        out[str(d.date())] = {"day": str(d.date()), "verdict": "ok", "rows": 120_000 if wk else 50_000,
                              "money": weekend if wk else weekday, "pools": 900 if wk else 400,
                              "pools_expected": 950 if wk else 420}
    return out


def _day_frame(day, money, pools=40, rows=200):
    """A Match_Investments day: ``rows`` rows over ``pools`` pools adding up to ``money``."""
    t0 = pd.Timestamp(day) + pd.Timedelta(hours=12)
    return pd.DataFrame({"pool_id": np.arange(rows) % pools, "match_id": np.arange(rows) % 7,
                         "start_sell_time": [t0 + pd.Timedelta(minutes=i % 300) for i in range(rows)],
                         "turnover": np.full(rows, money / rows), "ticket_count": np.ones(rows, dtype=int)})


# ------------------------------------------------------------------ verdicts
def test_a_thin_day_is_suspect_against_its_own_kind_of_day():
    from src.backtest.parquet.quality import judge
    hist = _history()
    wed = pd.Timestamp("2026-10-21")                                     # a Wednesday
    thin = judge(wed, {"rows": 4_000, "money": 100_000.0, "pools": 30}, hist, TODAY)
    assert thin["verdict"] == "suspect" and any("usual" in r for r in thin["reasons"]), thin
    fine = judge(wed, {"rows": 46_000, "money": 900_000.0, "pools": 380}, hist, TODAY)
    assert fine["verdict"] == "ok" and not fine["reasons"], fine
    sat = pd.Timestamp("2026-10-24")                                     # a Saturday is held to Saturdays
    assert judge(sat, {"rows": 110_000, "money": 2_800_000.0, "pools": 880}, hist, TODAY)["verdict"] == "ok"
    assert judge(sat, {"rows": 50_000, "money": 600_000.0, "pools": 400}, hist, TODAY)["verdict"] == "suspect"
    assert judge(TODAY - pd.Timedelta(days=1), {"rows": 50_000, "money": 1e6, "pools": 400}, hist,
                 TODAY)["verdict"] == "provisional"                      # late bets still land until D-2
    assert judge(TODAY - pd.Timedelta(days=2), {"rows": 50_000, "money": 1e6, "pools": 400}, hist,
                 TODAY)["verdict"] == "ok"


def test_pools_without_money_mark_a_day_extracted_before_its_bets():
    from src.backtest.parquet.quality import judge
    hist = _history()
    wed = pd.Timestamp("2026-10-21")
    early = judge(wed, {"rows": 45_000, "money": 950_000.0, "pools": 60}, hist, TODAY, expected=420)
    assert early["verdict"] == "suspect" and any("60 of the 420 pools" in r for r in early["reasons"]), early
    whole = judge(wed, {"rows": 45_000, "money": 950_000.0, "pools": 395}, hist, TODAY, expected=420)
    assert whole["verdict"] == "ok", whole
    quiet = judge(wed, {"rows": 5_000, "money": 110_000.0, "pools": 44}, hist, TODAY, expected=46)
    assert quiet["verdict"] == "ok", quiet                               # an international break: few pools, all paid


# ------------------------------------------------------------------ the update
class _MoneyReader(FakeReader):
    """Investment days with money in them (on ``pools`` pools); ``expected`` pools concluded per day."""

    def __init__(self, money, expected=None, pools=40):
        super().__init__()
        self.money, self.expected, self.pools = dict(money), expected, pools

    def read(self, job):
        if job.table != "investments":
            return super().read(job)
        return _day_frame(job.start, self.money.get(str(job.start.date()), 1_000_000.0), pools=self.pools)

    def expected_pools(self, job):
        return self.expected


def test_a_smaller_re_extract_keeps_the_file_unless_forced():
    from src.backtest.parquet.quality import file_stats, read_quality
    from src.backtest.parquet.raw_update import plan, run
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        day = root / "Match_Investments" / "match_investments_2026-09-29_2026-09-30.parquet"
        _day_frame("2026-09-29", 1_000_000.0).to_parquet(day)
        p = plan(root, now=NOW, days=("2026-09-29", "2026-09-29"))
        st = run(p, _MoneyReader({"2026-09-29": 400_000.0}))
        kept = file_stats(day)
        rec = next(r for r in st["files"] if r["file"].endswith(day.name))
        q = read_quality(root)["days"]["2026-09-29"]
        forced = run(plan(root, now=NOW, days=("2026-09-29", "2026-09-29")), _MoneyReader({"2026-09-29": 400_000.0}),
                     force=True)
        replaced = file_stats(day)
    assert abs(kept["money"] - 1_000_000.0) < 1e-6 and rec["kept_old"] and rec["rows"] == 0, (kept, rec)
    assert "stays" in " ".join(q["reasons"]) and q["money"] == kept["money"], q
    assert abs(replaced["money"] - 400_000.0) < 1e-6 and forced["files_written"] == 1


def test_a_suspect_re_extract_does_not_replace_a_file_that_is_not():
    """96% of the money on a quarter of the pools: past the money guard, still a broken extract."""
    from src.backtest.parquet.quality import file_stats, read_quality
    from src.backtest.parquet.raw_update import plan, run
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        day = root / "Match_Investments" / "match_investments_2026-09-29_2026-09-30.parquet"
        _day_frame("2026-09-29", 1_000_000.0, pools=40).to_parquet(day)
        broken = _MoneyReader({"2026-09-29": 960_000.0}, expected=40, pools=10)
        st = run(plan(root, now=NOW, days=("2026-09-29", "2026-09-29")), broken)
        kept = file_stats(day)
        rec = next(r for r in st["files"] if r["file"].endswith(day.name))
        q = read_quality(root)["days"]["2026-09-29"]
        run(plan(root, now=NOW, days=("2026-09-29", "2026-09-29")), broken, force=True)
        forced = file_stats(day)
    assert kept["pools"] == 40 and rec["kept_old"] and rec["rows"] == 0, (kept, rec)
    assert q["verdict"] == "ok" and "suspect" in q["reasons"][0] and "stays" in q["reasons"][0], q
    assert forced["pools"] == 10


def _pool_files(root, good, other, other_kind):
    """Pool_Details: one file whose pools conclude across ``good``, and one over ``other`` that lacks
    conclude_date ("legacy") or cannot be read ("broken"). 40 pools conclude each day: a day file holds
    the money of the pools concluded on it and the next day, 80."""
    folder = root / "Pool_Details"
    folder.mkdir(parents=True, exist_ok=True)
    days = pd.date_range(*good)
    pd.DataFrame({"pool_id": np.arange(40 * len(days)), "pool_type": "HAD",
                  "conclude_date": np.repeat(days, 40)}).to_parquet(
        folder / "pool_details_{:%Y-%m-%d}_{:%Y-%m-%d}.parquet".format(*map(pd.Timestamp, good)))
    name = folder / "pool_details_{:%Y-%m-%d}_{:%Y-%m-%d}.parquet".format(*map(pd.Timestamp, other))
    if other_kind == "legacy":
        pd.DataFrame({"pool_id": [1], "pool_type": ["HAD"]}).to_parquet(name)
    else:
        name.write_bytes(b"not a parquet file")


def _investment_days(root, first, last, odd):
    """Normal days, but on each day of ``odd``: (money, pools)."""
    (root / "Match_Investments").mkdir(parents=True, exist_ok=True)
    for d in pd.date_range(first, last):
        money, pools = odd.get(str(d.date()), (3e6 if d.dayofweek >= 5 else 1e6, 80))
        _day_frame(d, money, pools=pools, rows=400).to_parquet(
            root / "Match_Investments" / "match_investments_{:%Y-%m-%d}_{:%Y-%m-%d}.parquet".format(
                d, d + pd.Timedelta(days=1)))


def test_a_pool_file_without_conclude_date_leaves_only_its_own_days_uncounted():
    from src.backtest.parquet.quality import check_days
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "Raw_Data"
        _pool_files(root, ("2026-09-01", "2026-09-30"), ("2024-01-01", "2024-01-31"), "legacy")
        _investment_days(root, "2026-09-01", "2026-09-30", {"2026-09-23": (1e6, 10)})
        by_day = {r["day"]: r for r in check_days(root, today=TODAY)}
    # September's pools are still counted: a day with money on 10 of its 80 is suspect
    assert by_day["2026-09-23"]["pools_expected"] == 80 and by_day["2026-09-23"]["verdict"] == "suspect", \
        by_day["2026-09-23"]
    assert by_day["2026-09-14"]["pools_expected"] == 80 and by_day["2026-09-14"]["verdict"] == "ok"


def test_an_unreadable_pool_file_is_not_a_day_without_pools():
    from src.backtest.parquet.quality import check_days
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "Raw_Data"
        _pool_files(root, ("2026-09-01", "2026-09-30"), ("2026-10-01", "2026-10-31"), "broken")
        _investment_days(root, "2026-09-01", "2026-10-20", {"2026-10-14": (12_000.0, 3)})
        by_day = {r["day"]: r for r in check_days(root, today=TODAY)}
    # October's file was not read: its days are judged on their money, not as days that concluded nothing
    assert by_day["2026-10-14"]["pools_expected"] is None and by_day["2026-10-14"]["verdict"] == "suspect", \
        by_day["2026-10-14"]
    assert by_day["2026-09-14"]["pools_expected"] == 80 and by_day["2026-09-14"]["verdict"] == "ok"


def test_every_written_day_gets_a_verdict_and_a_time():
    from src.backtest.parquet.quality import read_quality
    from src.backtest.parquet.raw_update import plan, run
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        run(plan(root, now=NOW), _MoneyReader({"2026-10-12": 20_000.0}, expected=40))
        days = read_quality(root)["days"]
    assert days["2026-10-26"]["verdict"] == "provisional" and days["2026-10-25"]["verdict"] == "provisional"
    assert days["2026-10-12"]["verdict"] == "suspect", days["2026-10-12"]           # a fiftieth of its Mondays
    assert days["2026-10-13"]["verdict"] == "ok" and days["2026-10-13"]["pools_expected"] == 40
    assert all(r.get("written_at") for r in days.values())


def test_the_plan_retries_suspect_and_provisional_days_of_the_last_30():
    from src.backtest.parquet.quality import QUALITY
    from src.backtest.parquet.raw_update import plan
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        (root / QUALITY).write_text(json.dumps({"days": {
            "2026-09-27": {"verdict": "suspect"}, "2026-09-29": {"verdict": "provisional"},
            "2026-09-28": {"verdict": "ok"}, "2026-09-10": {"verdict": "suspect"}}}), encoding="utf-8")
        p = plan(root, now=NOW)
        lines = p.describe()
    days = sorted(j.start for j in p.jobs if j.table == "investments")
    assert p.retry == [pd.Timestamp("2026-09-27"), pd.Timestamp("2026-09-29")], p.retry
    assert days[0] == pd.Timestamp("2026-09-27") and pd.Timestamp("2026-09-28") not in days
    assert pd.Timestamp("2026-09-10") not in days and p.restart == pd.Timestamp("2026-09-30")
    assert any("2026-09-27" in ln and "again" in ln for ln in lines), lines


def test_named_days_extract_only_those_days():
    from src.backtest.parquet.raw_update import plan
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        p = plan(root, now=NOW, days=("2026-09-27", "2026-09-28"))
    assert [(j.table, str(j.start.date())) for j in p.jobs] == [("investments", "2026-09-27"),
                                                               ("investments", "2026-09-28")]
    assert p.restart == pd.Timestamp("2026-09-27") and not p.foreign


def test_update_data_days_extracts_and_drops_only_those_days():
    from algoe import cli
    from src.backtest.parquet import raw_update as U
    from src.backtest.parquet.quality import read_quality
    real = U.SqlReader
    cached = ("2026-09-27", "2026-09-28", "2026-10-05")
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:    # the run's log stays open
        root = _raw(Path(tmp) / "Raw_Data")
        space = Path(tmp) / "algoe_panel_cache" / "s1"
        (space / "panel").mkdir(parents=True)
        for d in cached:
            (space / "panel" / "{}.parquet".format(d)).write_bytes(b"x")
        (space / "manifest.json").write_text(json.dumps({"days": {d: {"rows": 3} for d in cached}}), encoding="utf-8")
        common = ["--data-dir", str(root), "--work-dir", str(Path(tmp) / "work"), "--log-level", "ERROR"]
        try:
            U.SqlReader = lambda: _MoneyReader({}, expected=40)
            code = cli.main(["update-data", "--no-build", "--days", "2026-09-28:2026-09-28"] + common)
            left = sorted(json.loads((space / "manifest.json").read_text(encoding="utf-8"))["days"])
            q = read_quality(root)["days"]
            st = U.read_status(root)
        finally:
            U.SqlReader = real
    assert code == 0 and st["files_written"] == 1 and st["caches"]["panel"] == 1, st
    assert left == ["2026-09-27", "2026-10-05"], left
    assert q["2026-09-28"]["pools_expected"] == 40 and q["2026-09-28"]["written_at"]


def test_bet_databases_are_found_in_sys_databases():
    from src.hkjc import history_queries as Q
    found = Q.bet_buckets(["master", "fbis1_fo_as_db", "fbis_fo_as_202603_202604", "fbis_fo_cs_202603_202604",
                           "fbis_fo_as_202605_202606"])
    assert found == ("202603_202604",), found                           # both halves, or not usable
    assert Q.investments_databases("2026-03-15", found) == ("fbis_fo_as_202603_202604", "fbis_fo_cs_202603_202604")
    assert Q.investments_databases("2026-03-15") == ("fbis1_fo_as_db", "fbis1_fo_cs_db")
    assert Q.investments_databases("2025-08-15", found) == ("fbis_fo_as_202507_202508", "fbis_fo_cs_202507_202508")
    sql = Q.investments_setup_sql("2026-03-15", "2026-03-16", found)
    assert "[fbis_fo_as_202603_202604]..c_account_ord_fo_selections" in sql
    assert "sys.databases" in Q.BET_DATABASES_SQL and "conclude_date between '2026-03-15' and '2026-03-16'" in \
        Q.concluded_pools_sql("2026-03-15", "2026-03-16")
    assert "state = 0" in Q.BET_DATABASES_SQL                           # online only: not restoring or offline


def test_days_must_run_forward_and_not_past_today():
    from algoe import cli
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:    # the run's log stays open
        root = _raw(Path(tmp) / "Raw_Data")
        common = ["--data-dir", str(root), "--work-dir", str(Path(tmp) / "work"), "--log-level", "ERROR"]
        backwards = cli.main(["update-data", "--no-build", "--days", "2026-09-28:2026-09-27"] + common)
        ahead = cli.main(["update-data", "--no-build", "--days", "2099-01-01:2099-01-02"] + common)
        nonsense = cli.main(["update-data", "--no-build", "--days", "yesterday:2026-09-27"] + common)
        bt = cli.main(["backtest", "--only", "replication", "--days", "2026-10-15:2026-10-10"] + common)
        status = (root / "_algoe_update.json").exists()
    assert backwards == ahead == nonsense == bt == cli.EXIT_FAIL, (backwards, ahead, nonsense, bt)
    assert not status                                                    # nothing ran, nothing recorded


# ------------------------------------------------------------------ downstream
def _settings(tmp, raw):
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.work_dir="{}"'.format((Path(tmp) / "AlgoE_Work").as_posix()))
    s.set('paths.data_dir="{}"'.format(Path(raw).as_posix()))
    return s


def test_suspect_days_are_left_out_of_every_window():
    from algoe.backtest.backtester import Backtester
    from algoe.data.panel import HistoricalPanel
    from src.backtest.parquet.quality import QUALITY
    with tempfile.TemporaryDirectory() as tmp:
        raw = _raw(Path(tmp) / "Raw_Data")
        (raw / QUALITY).write_text(json.dumps({"days": {"2026-09-28": {"verdict": "suspect"},
                                                        "2026-09-29": {"verdict": "ok"}}}), encoding="utf-8")
        s = _settings(tmp, raw)
        days = HistoricalPanel(s).days("2026-09-27", "2026-09-30")
        bt = Backtester(s, store=None)
        scored = bt._test_days(pd.date_range("2026-09-27", "2026-09-30"))
    assert pd.Timestamp("2026-09-28") not in days and len(days) == 3, days
    assert pd.Timestamp("2026-09-28") not in scored and bt.excluded == ["2026-09-28"], (scored, bt.excluded)


def test_a_suspect_day_feeds_no_market_index_and_no_lag_history():
    from types import SimpleNamespace
    from algoe.data.panel import HistoricalPanel
    from src.backtest.parquet.quality import QUALITY
    with tempfile.TemporaryDirectory() as tmp:
        raw = _raw(Path(tmp) / "Raw_Data")
        (raw / QUALITY).write_text(json.dumps({"days": {"2026-09-28": {"verdict": "suspect"}}}), encoding="utf-8")
        panel = HistoricalPanel(_settings(tmp, raw))
        tail = Path(tmp) / "2026-09-28.parquet"
        pd.DataFrame({"bucket": [pd.Timestamp("2026-09-28 23:30")], "turnover": [1.0]}).to_parquet(tail)
        panel.cache = SimpleNamespace(days={"2026-09-27": {"turnover": 2e8}, "2026-09-28": {"turnover": 1e6}},
                                      has_day=lambda d: True, panel_path=lambda d: tail)
        index = panel.market_index("2026-09-30")
        lag = panel.previous_tail("2026-09-29")
    assert abs(index - 2.0) < 1e-9 and lag is None, (index, lag)          # 2e8 / 1e8, not their median


def test_drop_days_forgets_only_those_days():
    from algoe.features.store import drop_days as drop_feature_days
    from src.backtest.parquet.cache import drop_days as drop_panel_days
    with tempfile.TemporaryDirectory() as tmp:
        panel = Path(tmp) / "panel" / "space1"
        panel.mkdir(parents=True)
        days = ["2026-09-26", "2026-09-27", "2026-09-28"]
        (panel / "manifest.json").write_text(json.dumps({"days": {d: {} for d in days}}), encoding="utf-8")
        for d in days:
            (panel / "{}.parquet".format(d)).write_bytes(b"x")
        feats = Path(tmp) / "features" / "key1"
        feats.mkdir(parents=True)
        for d in days:
            (feats / "{}.sel.parquet".format(d)).write_bytes(b"x")
        a = drop_panel_days(Path(tmp) / "panel", ["2026-09-27"], report=True)
        b = drop_feature_days(Path(tmp) / "features", [pd.Timestamp("2026-09-27")], report=True)
        left = sorted(json.loads((panel / "manifest.json").read_text(encoding="utf-8"))["days"])
        files = sorted(f.name[:10] for f in panel.glob("*.parquet"))
        feat_files = sorted(f.name[:10] for f in feats.glob("*.parquet"))
    assert a["dropped"] == 1 and b["dropped"] == 1 and not a["kept"] and not b["kept"]
    assert left == files == feat_files == ["2026-09-26", "2026-09-28"], (left, files, feat_files)


def test_check_data_gives_every_day_on_disk_a_verdict():
    from src.backtest.parquet.quality import check_days, read_quality
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "Raw_Data"
        (root / "Match_Investments").mkdir(parents=True)
        for d in pd.date_range("2026-09-01", "2026-10-25"):
            money = 12_000.0 if d == pd.Timestamp("2026-09-28") else (3e6 if d.dayofweek >= 5 else 1e6)
            _day_frame(d, money, rows=60 if d == pd.Timestamp("2026-09-28") else 400).to_parquet(
                root / "Match_Investments" / "match_investments_{:%Y-%m-%d}_{:%Y-%m-%d}.parquet".format(
                    d, d + pd.Timedelta(days=1)))
        recs = check_days(root, today=TODAY)
        saved = read_quality(root)["days"]
    by_day = {r["day"]: r for r in recs}
    assert by_day["2026-09-28"]["verdict"] == "suspect", by_day["2026-09-28"]
    assert by_day["2026-10-25"]["verdict"] == "provisional"
    assert sum(r["verdict"] == "ok" for r in recs) == len(recs) - 2
    assert saved["2026-09-28"]["verdict"] == "suspect"


def test_the_report_marks_days_whose_data_changed_after_it():
    from src.api.routes import algoe_reports
    from src.backtest.parquet.quality import QUALITY
    with tempfile.TemporaryDirectory() as tmp:
        raw = Path(tmp) / "Raw_Data"
        raw.mkdir()
        work = Path(tmp) / "AlgoE_Work"
        rep = work / "reports" / "backtest_20261020-060000"
        rep.mkdir(parents=True)
        (rep / "report.json").write_text(json.dumps({
            "meta": {"generated": "2026-10-20 06:10:00", "excluded_days": ["2026-10-02"],
                     "settings": {"paths": {"data_dir": str(raw)}}},
            "turnover": {"days": ["2026-09-27", "2026-09-28", "2026-09-29"], "leaderboard": []}}), encoding="utf-8")
        (raw / QUALITY).write_text(json.dumps({"days": {
            "2026-09-28": {"verdict": "ok", "written_at": "2026-10-21 06:05:00"},
            "2026-09-27": {"verdict": "suspect", "written_at": "2026-10-01 06:05:00"},
            "2026-09-29": {"verdict": "ok", "written_at": "2026-10-01 06:05:00"}}}), encoding="utf-8")
        out = algoe_reports.report(ids=None, work=str(work), data=str(raw))
    dq = out["data_quality"]
    assert dq["changed"] == ["2026-09-28"] and dq["suspect"] == ["2026-09-27"] and dq["excluded"] == ["2026-10-02"], dq


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<72} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<72} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
