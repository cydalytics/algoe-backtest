# Spec - the desk on the W10 live engine

W12, 2026-10-26. Parent of the "W12 live desk" plan. Folder: `BiWeekly Meetings/W12_2026-10-27_true-odds`.

## 1. Problem

The W10 report is better than the baseline (match WAPE 39.9% vs 49.1%, calibrated log-loss below
1 / true odds), but the desk a trader opens does not use any of it.

- `frontend/src/app/match/[id]/page.tsx` and the board read `/api/desk` only: the W04 MVP
  pipeline (`src/pipeline.py`) - next 5 minutes = last 5 minutes (`TURNOVER_MODEL="persistence"`,
  `TURNOVER_FLOOR=100`), belief = 1 / HKJC true odds, an optimizer whose demand ignores price
  (`DEMAND_ELASTICITY=0`). On Al Ahli Jeddah v Al Gharafa (26 Oct, pre-match) one HK$892k bucket on
  CHDC -3.5 Al Gharafa (5 tickets @178k) was carried forward as the next bucket, and theta* ran to
  the max move on SUP HT (-0.30), TC HT (-1.20) and CSUP HT (-0.90): uplift 300,633 (2,208 bps).
- Opening a match serves a cached tick (TTL 300 s, polled every 60 s); nothing is fetched again.
- The W10 engine (`/api/live/*`) is never called by the UI, `deploy/start.ps1` does not start it
  (`ALGOE_LIVE`), its focus refresh shares the sweep's thread, and a focus refresh prices on the
  bucket-start board: the panel takes TG/SUP, odds and score strictly before the bucket
  (`_attach_params`, `merge_asof(..., allow_exact_matches=False)`), so a TG/SUP or price change
  inside the bucket is not seen until the next bucket. `docs/ARCHITECTURE.md` says focus uses the
  latest odds, parameters and score.
- Two things nobody has checked: the live money table (`ticket_bets_dtl_agg_mem`,
  `IntervalTimeStart`) against the ticket-level tables the models were trained on
  (`1 Data Extraction.ipynb`), and the first-half split: every layer prices the first half at
  `full x Goal90SecondHalfSplitFH`, while the data schema has that column at mean 0.52 (0.375-0.59)
  and on the match above `full x (1 - split)` reproduces HKJC's own first-half true odds (FCRS 0:0
  19.8% vs 19.8%; summed error over 12 first-half selections 10.7 pp against 37.9 pp).

## 2. Outcome

Opening a match shows numbers fetched after the click - HKJC's newest TG/SUP, odds and score, the
W10 forecast, belief and theta* - refreshed every 15 s while it is open; the board is the W10 sweep.
One office command answers whether the live money matches what the models learned on, and the
backtest reports which first-half split reproduces HKJC's first-half board.

## 3. Non-goals

- No retrain, no `FEATURE_VERSION` change (stays 9), no change to the default first-half split.
- No change to the live money query before the probe says it is wrong.
- The MVP desk (`src/pipeline.py`, `src/models`, `src/optimizer`, `/api/desk*`), the W06 parquet
  engine, the Backtest tab and the simulators stay as they are.
- No new dependency.

## 4. Acceptance criteria

| # | Criterion | Proof |
|---|-----------|-------|
| AC1 | Opening a match requests a focus refresh at once. After it, the payload's `refreshed_at` >= the server time the open arrived (`requested_at`); `theta_now` is the newest algo_param row at or before the refresh; HKJC odds are the newest posted; score, corners and red cards come from incidents at or before the refresh. | unit test on the overlay; selftest S9 |
| AC2 | While open, the match refreshes every `live.focus_interval_seconds` (15 s); leaving the page releases it; without a heartbeat it lapses after `live.focus_ttl_seconds` (180 s). | unit test (heartbeat / release); browser check |
| AC3 | A running sweep never delays a focus refresh. | unit test with a slow sweep |
| AC4 | A focus refresh does not change the sweep's bucket forecast F; train/serve parity (S8) unchanged. | selftest S8, S9 |
| AC5 | Every selection shows F (this bucket), money so far, the rest (nowcast), the next bucket and the last bucket (the naive baseline, panel `tv1`); the header names the turnover and belief models serving, or "fallback: MVP" when there is none. | payload test, contract |
| AC6 | theta* comes from the W10 `ThetaOptimizer` with every guard; a focus decision is never below the board's E[GM] and stays inside the guards. | selftest S9 |
| AC7 | The board is the W10 sweep, one row per match in the panel, a match without a line market listed as "no book". | payload test |
| AC8 | `python -m algoe probe-live --match <id>` writes the raw live money rows, the spacing / duplicate / cumulative / ticket checks, the first-half split comparison and a verdict. | unit tests on the checks |
| AC9 | The replication check reports first-half pools under both split conventions; default pricing unchanged (existing tests green); `backtest --only replication` runs without a model. | unit tests |

## 5. Interfaces

- `LivePanelBuilder.build(snapshot, as_of=None, board_at=None)`; with `board_at`, the current
  bucket's odds, true odds, TG/SUP (with splits, game state, clock) and score are read at
  `board_at` (newest at or before it). `latest_board(...)` is the overlay on its own.
- `LiveEngine.request_focus(match_id, reason)`; `start()` runs a sweep thread and a focus thread
  (its own source); `match_view(match_id)` adds labels, prices, flow, freshness and models.
- `python -m algoe probe-live --match ID [--minutes N] [--tickets]`; output in
  `AlgoE_Work/diagnostics/<stamp>_probe_<match>/`.
- `GET /api/live/desk`, `GET /api/live/desk/{id}?open=1`, `POST /api/live/desk/{id}/price`,
  `GET /api/live/desk/{id}/curves`; `DELETE /api/live/focus/{id}` releases. Payloads keep the
  shapes the desk already draws (`Board`, `Cockpit`, `WhatIf`) plus `freshness` and `models`.
- `theta_from_params(..., fh_split="as_first_half")`, `"as_second_half"` = full x (1 - split),
  pre-match only; `Conventions.fh_split`.

## 6. Edge cases

- A match opened before the sweep has seen it, or opened while the first sweep is running: the
  focus refresh builds it from scratch and forecasts it on its own; until then the payload says
  `refreshing`.
- No champion on disk: the engine serves last 5 minutes / 1 / true odds and the desk says so.
- In play, a goal inside the bucket: the book is priced on the score after it; suspended or stale
  prices drop out (`max_odds_age_inplay_min`).
- The same match open in two tabs: one focus; either heartbeat keeps it.
- A tab closed without unmounting: the focus lapses after the TTL.
- The SQL read fails in a focus refresh: the last view stays, the error is reported, the next
  interval retries.
- Sweep and focus publishing at once: both take the engine lock.

## 7. Risks

- Office SQL load: the trigger scan fetches the whole card every 15 s on top of the sweep and the
  focus refreshes. Read the timings in `/api/live/status` before adding more.
- Running `algoe-4-live.bat` beside the desk makes two engines.
- Until the split is settled, first-half pools' model price and theta* keep today's convention.
- The report's match WAPE is not the selection-level accuracy the cockpit shows.

## 8. Open questions (answered on the office box, not by assumption)

1. Is `ticket_bets_dtl_agg_mem` per interval or cumulative, and in the same units as the
   ticket-level tables? (`algoe-6-probe-live.bat`)
2. Which first-half split reproduces HKJC's first-half board over many matches?
   (`algoe-3-backtest.bat --only replication`)
3. How long do a sweep, a trigger scan and a focus refresh take on the real card?
   (`/api/live/status`)
