"""Saved compare book, split the way a comparison is actually run.

One row is one selection in one 5-minute bucket. The index file holds that
identity. Every series is its own folder, in the same row order, so a new
model is a new folder and the backtest reads it next to ``actual``.

    compare/index/YYYY-MM-DD.parquet
    compare/turnover/actual/YYYY-MM-DD.parquet
    compare/turnover/last5min/YYYY-MM-DD.parquet
    compare/turnover/ma3/YYYY-MM-DD.parquet
    compare/turnover/ema/YYYY-MM-DD.parquet
    compare/turnover/<any other model>/YYYY-MM-DD.parquet
    compare/true_prob/actual/YYYY-MM-DD.parquet
    compare/true_prob/inverse_hkjc_true_odds/YYYY-MM-DD.parquet
    compare/true_prob/poisson/YYYY-MM-DD.parquet
    compare/true_prob/demargin/YYYY-MM-DD.parquet

``turnover/actual`` is this bucket's turnover. ``turnover/last5min`` is the
previous bucket. ``true_prob/actual`` is the settlement the probability is
scored against. ``true_prob/inverse_hkjc_true_odds`` is 1 / HKJC true odds.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .adapter import (
    DEFAULT_CALIBRATORS, WALK_FORWARD_MODEL, _Calibration, compact, models_present,
    to_facts,
)
from .beliefs import SOURCES

KEYS = ["pool_id", "line_id", "combination_id"]
STEP = pd.Timedelta(minutes=5)
VERSION = 2

# Folder name on disk -> the id the workbench already compares.
_TURNOVER_ID = {
    "last5min": "persistence",
    "ma3": "trailing_mean",
    "ema": "ema",
    "hurdle": "hurdle",
    "oracle": "oracle",
    "zero": "zero",
}
_TURNOVER_FOLDER = {v: k for k, v in _TURNOVER_ID.items()}
_PROB_FOLDER = {
    "hkjc_true": "inverse_hkjc_true_odds",
    "poisson": "poisson",
    "demargin": "demargin",
}
_PROB_SOURCE = {v: k for k, v in _PROB_FOLDER.items()}


def _dir(cache) -> Path:
    path = Path(cache.root) / "compare"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _stamp(day) -> str:
    return "{:%Y-%m-%d}".format(pd.Timestamp(day))


def _series_path(cache, family: str, name: str, day) -> Path:
    return _dir(cache) / family / name / "{}.parquet".format(_stamp(day))


def _index_path(cache, day) -> Path:
    return _dir(cache) / "index" / "{}.parquet".format(_stamp(day))


def _meta_path(cache) -> Path:
    return _dir(cache) / "meta.json"


def _read_meta(cache) -> dict:
    path = _meta_path(cache)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_meta(cache, payload: dict) -> None:
    _meta_path(cache).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_value(cache, family: str, name: str, day, values) -> None:
    path = _series_path(cache, family, name, day)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"value": np.asarray(values, dtype="float32")}).to_parquet(path, index=False)


def _read_value(cache, family: str, name: str, day, n: int) -> np.ndarray:
    path = _series_path(cache, family, name, day)
    if not path.exists():
        return np.full(n, np.nan, dtype="float32")
    values = pd.read_parquet(path)["value"].to_numpy(dtype="float32")
    if len(values) != n:
        raise RuntimeError("{} {} {} has {} rows, index has {}".format(
            family, name, _stamp(day), len(values), n))
    return values


def _folder_names(cache, family: str) -> List[str]:
    root = _dir(cache) / family
    if not root.is_dir():
        return []
    return sorted(p.name for p in root.iterdir() if p.is_dir())


def _prob_folder(source: str, calibrator: str) -> str:
    base = _PROB_FOLDER.get(source, source)
    if calibrator in ("", "raw"):
        return base
    return "{}__{}".format(base, calibrator)


def _split_prob_folder(name: str):
    base, sep, cal = name.partition("__")
    source = _PROB_SOURCE.get(base, base)
    return source, (cal if sep else "raw")


def _write_day(cache, day, facts: pd.DataFrame) -> None:
    """Index plus one file per series. Row i is the same selection in every file."""
    _write_value(cache, "turnover", "actual", day, facts["t_actual"])
    for col in facts.columns:
        if not col.startswith("t_hat__"):
            continue
        model = col[len("t_hat__"):]
        _write_value(cache, "turnover", _TURNOVER_FOLDER.get(model, model), day, facts[col])
    _write_value(cache, "true_prob", "actual", day, facts["result"])
    for col in facts.columns:
        if not str(col).startswith("p__"):
            continue
        source, _, cal = col[len("p__"):].partition("__")
        _write_value(cache, "true_prob", _prob_folder(source, cal or "raw"), day, facts[col])
    drop = [c for c in facts.columns
            if c.startswith("t_hat__") or str(c).startswith("p__")
            or c in ("t_actual", "t5m", "result")]
    path = _index_path(cache, day)
    path.parent.mkdir(parents=True, exist_ok=True)
    facts.drop(columns=drop).to_parquet(path, index=False)


def _load_day(cache, day) -> Optional[pd.DataFrame]:
    path = _index_path(cache, day)
    if not path.exists():
        return None
    frame = pd.read_parquet(path)
    n = len(frame)
    if n == 0:
        return frame
    frame["t_actual"] = _read_value(cache, "turnover", "actual", day, n)
    last5 = _read_value(cache, "turnover", "last5min", day, n)
    frame["t5m"] = last5
    for name in _folder_names(cache, "turnover"):
        if name == "actual":
            continue
        model = _TURNOVER_ID.get(name, name)
        frame["t_hat__{}".format(model)] = _read_value(cache, "turnover", name, day, n)
    if "t_hat__persistence" not in frame.columns:
        frame["t_hat__persistence"] = last5
    frame["result"] = _read_value(cache, "true_prob", "actual", day, n)
    for name in _folder_names(cache, "true_prob"):
        if name == "actual":
            continue
        source, cal = _split_prob_folder(name)
        frame["p__{}__{}".format(source, cal)] = _read_value(cache, "true_prob", name, day, n)
    return frame


def _align(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in KEYS:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce").fillna(-1).astype("int64")
    if "bucket" in out.columns:
        out["bucket"] = pd.to_datetime(out["bucket"]).astype("datetime64[ns]")
    return out


def restate_lags(panel: pd.DataFrame, carry: Optional[pd.DataFrame],
                 step: pd.Timedelta = STEP) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Last 5 / 15 minutes from this day's turnover plus the previous day's tail.

    ``lag1`` on a cached panel is whatever the builder merged. Recomputing it
    from ``turnover`` makes the previous bucket the previous bucket, including
    across midnight.
    """
    if panel is None or panel.empty or "turnover" not in panel.columns:
        empty = panel if panel is not None else pd.DataFrame()
        return empty, pd.DataFrame(columns=KEYS + ["bucket", "turnover"])
    if any(c not in panel.columns for c in KEYS):
        return panel, pd.DataFrame(columns=KEYS + ["bucket", "turnover"])

    panel = _align(panel)
    cur = (panel[KEYS + ["bucket", "turnover"]]
           .groupby(KEYS + ["bucket"], as_index=False, observed=True)["turnover"].sum())
    hist = cur
    if carry is not None and not carry.empty:
        hist = pd.concat([_align(carry), cur], ignore_index=True)
        hist = hist.groupby(KEYS + ["bucket"], as_index=False, observed=True)["turnover"].sum()

    out = panel.drop(columns=[c for c in ("lag1", "lag2", "lag3") if c in panel.columns])
    for k, name in ((1, "lag1"), (2, "lag2"), (3, "lag3")):
        lag = hist[KEYS + ["bucket", "turnover"]].copy()
        lag["bucket"] = lag["bucket"] + k * step
        lag = lag.rename(columns={"turnover": name})
        out = out.merge(lag, on=KEYS + ["bucket"], how="left")
        out[name] = pd.to_numeric(out[name], errors="coerce").fillna(0.0)
    out["f_persist"] = out["lag1"]
    out["f_ma3"] = out[["lag1", "lag2", "lag3"]].mean(axis=1)
    out["f_ema"] = 0.5 * out["lag1"] + 0.3 * out["lag2"] + 0.2 * out["lag3"]
    out["f_zero"] = 0.0
    out["f_oracle"] = pd.to_numeric(out["turnover"], errors="coerce").fillna(0.0)
    if cur.empty:
        tail = cur
    else:
        cutoff = cur["bucket"].max() - 2 * step
        tail = cur.loc[cur["bucket"] >= cutoff, KEYS + ["bucket", "turnover"]]
    return out, tail


def _keep(panel: pd.DataFrame) -> pd.DataFrame:
    """Rows that can move a turnover or belief score."""
    if panel.empty:
        return panel
    money = pd.to_numeric(panel["turnover"], errors="coerce").fillna(0.0) > 0
    prev = pd.to_numeric(panel.get("lag1"), errors="coerce").fillna(0.0) > 0
    settled = (panel["settled"].fillna(False).astype(bool)
               if "settled" in panel.columns else False)
    kept = panel.loc[money | prev | settled]
    return panel if kept.empty else kept


def _forecast(model, facts: pd.DataFrame) -> np.ndarray:
    last5 = pd.to_numeric(facts["t5m"], errors="coerce").fillna(0.0).to_numpy(dtype="float64")
    if model is None or not getattr(model, "ready", False):
        return last5
    true = pd.to_numeric(facts.get("hkjc_true_odds"), errors="coerce").to_numpy(dtype="float64")
    odds = pd.to_numeric(facts.get("sell_odds"), errors="coerce").to_numpy(dtype="float64")
    use = np.where(np.isfinite(true) & (true > 1.0), true, odds)
    use = np.where(np.isfinite(use) & (use > 1.0), use, 2.0)
    return model.predict(last5, use)


def _sample(facts: pd.DataFrame, cap: int, rng: np.random.Generator) -> dict:
    n = len(facts)
    take = facts if n <= cap else facts.iloc[rng.choice(n, size=cap, replace=False)]
    true = pd.to_numeric(take.get("hkjc_true_odds"), errors="coerce").to_numpy(dtype="float64")
    odds = pd.to_numeric(take.get("sell_odds"), errors="coerce").to_numpy(dtype="float64")
    use = np.where(np.isfinite(true) & (true > 1.0), true, odds)
    return {
        "last5": pd.to_numeric(take["t5m"], errors="coerce").fillna(0.0).to_numpy(dtype="float32"),
        "y": pd.to_numeric(take["t_actual"], errors="coerce").fillna(0.0).to_numpy(dtype="float32"),
        "odds": np.where(np.isfinite(use) & (use > 1.0), use, 2.0).astype("float32"),
    }


def _refit(stored: List[dict], inner_days: int):
    from .extract_forecast import TurnoverRidge
    inner_n = min(int(inner_days), max(len(stored) - 1, 0))
    fit_days = stored[:len(stored) - inner_n] or stored
    inner = stored[len(stored) - inner_n:] if inner_n else []
    model = TurnoverRidge()
    try:
        info = model.fit(
            np.concatenate([d["last5"] for d in fit_days]),
            np.concatenate([d["y"] for d in fit_days]),
            np.concatenate([d["odds"] for d in fit_days]),
        )
    except (ValueError, np.linalg.LinAlgError) as exc:
        return None, {"error": str(exc)}
    if inner:
        alpha = model.pick_alpha(
            np.concatenate([d["last5"] for d in inner]),
            np.concatenate([d["y"] for d in inner]),
            np.concatenate([d["odds"] for d in inner]),
        )
    else:
        model.alpha = 0.0
        alpha = {"alpha": 0.0, "scores": {}}
    return model, {"rows": info["rows"], "alpha": alpha["alpha"], "beta": info["beta"]}


def _covered(cache, days: Sequence, calibrators: Sequence[str]) -> bool:
    meta = _read_meta(cache)
    if meta.get("version") != VERSION:
        return False
    if list(meta.get("calibrators") or []) != list(calibrators):
        return False
    have = set(meta.get("days") or [])
    # A calendar day with no panel is not a hole in the book. Rebuilding the
    # window every time a weekend sits in the range would wipe the saved file.
    for day in days:
        if not cache.has_day(day):
            continue
        key = "{:%Y-%m-%d}".format(pd.Timestamp(day))
        needed = (
            _index_path(cache, day),
            _series_path(cache, "turnover", "actual", day),
            _series_path(cache, "turnover", "last5min", day),
            _series_path(cache, "true_prob", "actual", day),
            _series_path(cache, "true_prob", "inverse_hkjc_true_odds", day),
        )
        if key not in have or not all(p.exists() for p in needed):
            return False
    return True


def _seed_carry(cache, first) -> pd.DataFrame:
    prev = pd.Timestamp(first) - pd.Timedelta(days=1)
    if not cache.has_day(prev):
        return pd.DataFrame(columns=KEYS + ["bucket", "turnover"])
    panel = cache.load_day(prev)
    if panel is None or panel.empty:
        return pd.DataFrame(columns=KEYS + ["bucket", "turnover"])
    _, tail = restate_lags(panel, None)
    return tail


def build_books(cache, days: Sequence, calibrators: Sequence[str],
                progress=None, warmup_days: int = 14, inner_days: int = 7,
                refit_every: int = 7) -> dict:
    """Write one compare parquet per day. Existing files for these days are replaced."""
    days = list(days)
    cal = _Calibration(SOURCES, calibrators)
    carry = _seed_carry(cache, days[0]) if days else pd.DataFrame()
    rng = np.random.default_rng(7)
    model = None
    stored: List[dict] = []
    since = 0
    log = []
    written = []
    skipped = []
    for i, day in enumerate(days, start=1):
        key = "{:%Y-%m-%d}".format(pd.Timestamp(day))
        panel = cache.load_day(day)
        if panel is None or panel.empty:
            skipped.append(key)
            if progress is not None:
                progress({"stage": "assemble", "day": key, "rows": 0,
                          "done": i, "total": len(days), "source": "panel"})
            continue
        stated, carry = restate_lags(panel, carry)
        stated = _keep(stated)
        facts = to_facts(stated)
        facts["t_hat__persistence"] = pd.to_numeric(facts["t5m"], errors="coerce").fillna(0.0)
        hat = _forecast(model, facts)
        if len(hat) != len(facts):
            raise RuntimeError("forecast length {} != fact rows {}".format(len(hat), len(facts)))
        facts["t_hat__{}".format(WALK_FORWARD_MODEL)] = hat
        cal.transform(facts)
        cal.observe(facts)
        facts = facts.drop(columns=[c for c in facts.columns if c.startswith("p_src__")])
        _write_day(cache, day, facts)
        stored.append(_sample(facts, 20000, rng))
        since += 1
        if len(stored) >= warmup_days and (model is None or since >= refit_every):
            model, info = _refit(stored, inner_days)
            since = 0
            info["after"] = key
            log.append(info)
        written.append(key)
        if progress is not None:
            progress({"stage": "assemble", "day": key, "rows": len(facts),
                      "done": i, "total": len(days), "source": "write"})
    previous = _read_meta(cache)
    have = set(previous.get("days") or [])
    if list(previous.get("calibrators") or []) != list(calibrators) or previous.get("version") != VERSION:
        have = set()
    have.update(written)
    _write_meta(cache, {
        "version": VERSION,
        "calibrators": list(calibrators),
        "days": sorted(have),
        "walk_forward": log,
    })
    return {"written": written, "skipped": skipped, "walk_forward": log}


def load_compare(cache, start, end, calibrators: Sequence[str] = DEFAULT_CALIBRATORS,
                 max_rows: int = 0, progress=None):
    """Facts for a window. Builds the book the first time, reads it after that."""
    from .cache import day_list
    days = day_list(start, end)
    if not _covered(cache, days, calibrators):
        build_books(cache, days, calibrators, progress=progress)
    pieces = []
    kept = []
    skipped = []
    for i, day in enumerate(days, start=1):
        key = "{:%Y-%m-%d}".format(pd.Timestamp(day))
        frame = _load_day(cache, day)
        if frame is None or frame.empty:
            skipped.append(key)
            continue
        pieces.append(frame)
        kept.append(key)
        if progress is not None:
            progress({"stage": "assemble", "day": key, "rows": len(frame),
                      "done": i, "total": len(days), "source": "book"})
    if not pieces:
        return pd.DataFrame(), {
            "days": [], "rows": 0, "empty_days": skipped, "trimmed_days": [],
            "calibrators": list(calibrators), "source": "book",
            "walk_forward": _read_meta(cache).get("walk_forward") or [],
        }
    trimmed = []
    rows = sum(len(p) for p in pieces)
    if max_rows and rows > max_rows:
        while pieces and rows > max_rows:
            rows -= len(pieces[0])
            pieces.pop(0)
            trimmed.append(kept.pop(0))
    facts = compact(pd.concat(pieces, ignore_index=True))
    meta = {
        "days": kept,
        "rows": int(len(facts)),
        "empty_days": skipped,
        "trimmed_days": trimmed,
        "calibrators": list(calibrators),
        "models": models_present(facts),
        "memory_mb": round(facts.memory_usage(deep=True).sum() / 1e6, 1),
        "source": "book",
        "walk_forward": _read_meta(cache).get("walk_forward") or [],
    }
    return facts, meta


def _fail(msg: str) -> None:
    raise SystemExit("[book selftest] FAIL: " + msg)


def selftest() -> None:
    import tempfile

    def panel(bucket, turnover, true_odds=1.90):
        return pd.DataFrame([{
            "bucket": pd.Timestamp(bucket),
            "match_id": 7, "pool_id": 1, "line_id": 2, "combination_id": 1,
            "pool_name": "HILO", "line_label": "2.5", "combination_string": "H",
            "home_name": "H", "away_name": "A", "league_name": "EPL", "league_code": "EPL",
            "turnover": turnover, "tickets": 3, "tickets_lag1": 1, "odds": 1.80,
            "true_odds": true_odds,
            "p__hkjc_true": 1.0 / true_odds, "p__poisson": np.nan, "p__demargin": 1.0 / 1.80 / 1.06,
            "y_frac": 1.0, "avg_odds": 1.80, "settled": True,
            "tg": 2.6, "sup": 0.1, "match_minute": 10.0, "is_inplay": True,
            "clock_bin": "live 0-15m", "event_window": "quiet", "event_kind": "none",
            "sell_book_sum": 1.06, "book__hkjc_true": 1.0, "hkjc_margin": 0.06,
        }])

    day1 = panel("2024-06-01 23:55", 100.0)
    day2 = panel("2024-06-02 00:00", 40.0)
    stated, carry = restate_lags(day1, None)
    if float(stated["lag1"].iloc[0]) != 0.0:
        _fail("first bucket should have no last-5 turnover")
    stated2, _ = restate_lags(day2, carry)
    if float(stated2["lag1"].iloc[0]) != 100.0:
        _fail("midnight bucket last-5 is {}, expected 100".format(stated2["lag1"].iloc[0]))
    if float(stated2["f_persist"].iloc[0]) != 100.0:
        _fail("persistence is not last-5")

    class Cache:
        def __init__(self, root):
            self.root = Path(root)
            self.days = {
                pd.Timestamp("2024-06-01"): day1,
                pd.Timestamp("2024-06-02"): day2,
            }

        def has_day(self, day):
            return pd.Timestamp(day).normalize() in {
                pd.Timestamp("2024-06-01"), pd.Timestamp("2024-06-02")}

        def load_day(self, day, columns=None):
            frame = self.days.get(pd.Timestamp(day).normalize())
            if frame is None:
                # also match exact
                return self.days.get(pd.Timestamp(day))
            return frame

    with tempfile.TemporaryDirectory() as tmp:
        cache = Cache(tmp)
        # has_day for the day before June 1 is false; June 2's carry comes from
        # building June 1 in the same pass.
        facts, meta = load_compare(cache, "2024-06-01", "2024-06-02", ("raw",))
        if meta.get("source") != "book":
            _fail("source {}".format(meta.get("source")))
        second, _ = load_compare(cache, "2024-06-01", "2024-06-02", ("raw",))
        late = second[second["t_actual"] == 40.0]
        if late.empty or float(late["t5m"].iloc[0]) != 100.0:
            _fail("saved book lost the last 5 minutes")
        if float(late["t_hat__persistence"].iloc[0]) != 100.0:
            _fail("saved persistence is not the last 5 minutes")
        if not np.isclose(float(late["hkjc_true_odds"].iloc[0]), 1.90):
            _fail("saved true odds {}".format(late["hkjc_true_odds"].iloc[0]))
        if not np.isfinite(late["t_hat__hurdle"]).all():
            _fail("hurdle column is blank")
        p_col = "p__hkjc_true__raw"
        if p_col not in late.columns or not np.isclose(float(late[p_col].iloc[0]), 1.0 / 1.90, atol=1e-5):
            _fail("inverse true odds {}".format(late[p_col].iloc[0] if p_col in late.columns else "missing"))
        for family, name in (
            ("turnover", "actual"), ("turnover", "last5min"),
            ("true_prob", "actual"), ("true_prob", "inverse_hkjc_true_odds"),
        ):
            if not _series_path(cache, family, name, "2024-06-02").exists():
                _fail("missing {}/{}".format(family, name))
        # second open must not rewrite the series (same bytes)
        path = _series_path(cache, "turnover", "last5min", "2024-06-02")
        stamp = path.stat().st_mtime_ns
        load_compare(cache, "2024-06-02", "2024-06-02", ("raw",))
        if path.stat().st_mtime_ns != stamp:
            _fail("second open rewrote the book")
    print("[book selftest] PASS", flush=True)


if __name__ == "__main__":
    selftest()
