"""
Live money probe

The turnover models learned money from the bet tables (1 Data Extraction.ipynb: every bet's
turnover summed per minute); the live engine and the MVP desk read it from
ticket_bets_dtl_agg_mem by IntervalTimeStart. Parity builds both of its paths from Raw_Data, so it
cannot tell whether the live table says the same thing. This reads one match from the live feed
and answers from its own rows:

    spacing       how far apart a selection's intervals start (the training data is per minute)
    duplicates    more than one row for a selection and interval: money a join counts twice
    money shape   per interval, or a running total read as if it were the interval's money
                  (a selection's money only ever rising, row after row)
    bucket        the last five minutes per selection: one row, several, or one row repeated -
                  what the desk's "tickets @ stake" column is made of
    first half    the first-half goals / corners each reading of Goal90SecondHalfSplitFH gives,
                  against what HKJC's own first-half true odds imply (FCRS 0:0, the main
                  first-half total lines)
    tickets       (--tickets) the same minutes from the bet tables the training extraction reads

    python -m algoe probe-live --match 1234567 [--minutes 60] [--tickets]

Change Log:
-----------
2026-10-26      Initialize
"""

from __future__ import annotations

import math
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..core.taxonomy import parse_line, side_of
from ..data.panel import KEY, LivePanelBuilder

logger = get_logger(__name__)

_SCORE = re.compile(r"^\s*(\d{1,2})\s*[:\-]\s*(\d{1,2})\s*$")
# a selection's money that never falls over this many rows reads as a running total
MIN_SHAPE_ROWS = 4


# ================================================================== checks
def _sorted(inv: pd.DataFrame) -> pd.DataFrame:
    out = inv.copy()
    for c in KEY:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out["start_sell_time"] = pd.to_datetime(out["start_sell_time"], errors="coerce")
    out = out.dropna(subset=KEY + ["start_sell_time"])
    for c in KEY:
        out[c] = out[c].astype("int64")
    out["turnover"] = pd.to_numeric(out["turnover"], errors="coerce").fillna(0.0).astype("float64")
    tickets = out["ticket_count"] if "ticket_count" in out.columns else pd.Series(0.0, index=out.index)
    out["ticket_count"] = pd.to_numeric(tickets, errors="coerce").fillna(0.0).astype("float64")
    return out.sort_values(KEY + ["start_sell_time"], kind="mergesort").reset_index(drop=True)


def interval_spacing(inv: pd.DataFrame) -> dict:
    """How far apart a selection's intervals start, and whether they start on the minute."""
    s = _sorted(inv)
    starts = s.drop_duplicates(KEY + ["start_sell_time"])
    gaps = starts.groupby(KEY)["start_sell_time"].diff().dt.total_seconds().dropna()
    gaps = gaps[gaps > 0]
    t = s["start_sell_time"]
    return {"rows": int(len(s)), "selections": int(s.groupby(KEY).ngroups) if len(s) else 0,
            "modal_seconds": float(gaps.round().mode().iloc[0]) if len(gaps) else float("nan"),
            "smallest_seconds": float(gaps.min()) if len(gaps) else float("nan"),
            "on_minute_share": float(((t.dt.second == 0) & (t.dt.microsecond == 0)).mean()) if len(t)
            else float("nan")}


def duplicate_rows(inv: pd.DataFrame) -> dict:
    """Rows beyond the first for one selection and interval, and the money in them."""
    s = _sorted(inv)
    cols = KEY + ["start_sell_time"]
    extra = s[s.groupby(cols).cumcount() > 0]
    keys = s[s.duplicated(cols, keep=False)].drop_duplicates(cols)
    return {"rows": int(len(extra)), "keys": int(len(keys)), "money": float(extra["turnover"].sum())}


def money_shape(inv: pd.DataFrame, min_rows: int = MIN_SHAPE_ROWS) -> dict:
    """Per interval or a running total: per selection, does its money rise and never fall?

    Money that arrives interval by interval goes up and down; a running total only goes up. A
    selection whose rows never change says nothing either way and is left out.
    """
    s = _sorted(inv)
    if s.empty:
        return {"selections": 0, "rising_only": 0, "share": float("nan"), "verdict": "no rows",
                "min_rows": int(min_rows)}
    g = s.groupby(KEY)
    s["_d"] = g["turnover"].diff()
    s["_dt"] = g["ticket_count"].diff()
    per = s.groupby(KEY).agg(n=("turnover", "size"), falls=("_d", lambda d: bool((d < -1e-9).any())),
                             rises=("_d", lambda d: bool((d > 1e-9).any())),
                             ticket_falls=("_dt", lambda d: bool((d < -1e-9).any())))
    per = per[(per["n"] >= min_rows) & (per["rises"] | per["falls"])]
    if per.empty:
        return {"selections": 0, "rising_only": 0, "share": float("nan"), "verdict": "too few rows",
                "min_rows": int(min_rows)}
    rising = per["rises"] & ~per["falls"]
    share = float(rising.mean())
    shape = "cumulative" if share >= 0.8 else ("unclear" if share >= 0.5 else "per interval")
    return {"selections": int(len(per)), "rising_only": int(rising.sum()), "share": share,
            "tickets_rising_only": int((rising & ~per["ticket_falls"]).sum()), "verdict": shape,
            "min_rows": int(min_rows)}


def bucket_breakdown(inv: pd.DataFrame, as_of, minutes: float = 5.0) -> pd.DataFrame:
    """The desk's last-5-minutes money per selection, (as_of - minutes, as_of], and what made it:
    one row, several rows, or the same row repeated. Biggest first."""
    as_of = pd.Timestamp(as_of)
    s = _sorted(inv)
    w = s[(s["start_sell_time"] > as_of - pd.Timedelta(minutes=minutes)) & (s["start_sell_time"] <= as_of)]
    labels = [c for c in ("pool_name", "line_label", "combination_string") if c in w.columns]
    if w.empty:
        return pd.DataFrame(columns=KEY + labels + ["rows", "tickets", "money", "largest_row", "largest_row_tickets",
                                                    "largest_row_share", "distinct_rows", "pattern"])
    rows = []
    for key, g in w.groupby(KEY, sort=False):
        top = g.loc[g["turnover"].idxmax()]
        money = float(g["turnover"].sum())
        distinct = int(g[["turnover", "ticket_count"]].drop_duplicates().shape[0])
        pattern = "one row" if len(g) == 1 else ("repeated row" if distinct == 1 else "several rows")
        rec = dict(zip(KEY, key))
        rec.update({c: g[c].iloc[0] for c in labels})
        rec.update(rows=int(len(g)), tickets=float(g["ticket_count"].sum()), money=money,
                   largest_row=float(top["turnover"]), largest_row_tickets=float(top["ticket_count"]),
                   largest_row_share=float(top["turnover"]) / money if money > 0 else float("nan"),
                   distinct_rows=distinct, pattern=pattern)
        rows.append(rec)
    return pd.DataFrame(rows).sort_values("money", ascending=False, kind="mergesort").reset_index(drop=True)


def _score(comb) -> Optional[Tuple[int, int]]:
    m = _SCORE.match(re.sub(r"\[.*?\]", "", str(comb or "")))
    return (int(m.group(1)), int(m.group(2))) if m else None


def _poisson_mean_for_over(p_over: float, line: float) -> float:
    """The Poisson mean m with P(X > line) = p_over, for a half line."""
    from scipy.optimize import brentq
    from scipy.stats import poisson
    k = int(math.floor(line))
    return float(brentq(lambda m: poisson.sf(k, m) - p_over, 1e-9, 80.0, xtol=1e-12))


def implied_first_half(odds: pd.DataFrame) -> List[dict]:
    """What HKJC's own first-half prices say about the first half's expectancy.

    FCRS 0:0 is no goal in the first half, exp(-first-half TG) for two independent Poisson
    counts. On the main half line of FHLO / FCHLO the de-margined over probability gives the
    Poisson mean of the first-half total. Quarter and whole lines are skipped (they push).
    One row per selection, the latest price.
    """
    if odds is None or odds.empty:
        return []
    o = odds.copy()
    o["pool_name"] = o["pool_name"].astype(str).str.strip().str.upper()
    out = []
    for r in o[o["pool_name"] == "FCRS"].to_dict("records"):
        true = pd.to_numeric(r.get("true_odds"), errors="coerce")
        if _score(r.get("combination_string")) == (0, 0) and np.isfinite(true) and true > 1.0:
            p = 1.0 / float(true)
            out.append({"source": "FCRS 0:0", "domain": "goal", "line": None, "hkjc_prob": p,
                        "implied": -math.log(p), "price": "true odds"})
    for pool, domain in (("FHLO", "goal"), ("FCHLO", "corner")):
        best = None
        lines = o[o["pool_name"] == pool]
        for label, g in lines.groupby(lines["line_label"].astype(str)):
            line = parse_line(label)
            if line is None or (2 * line) % 2 != 1:
                continue
            side = g["combination_string"].map(side_of)
            over, under = g[side == "H"], g[side == "A"]
            if over.empty or under.empty:
                continue
            t_o = float(pd.to_numeric(over["true_odds"], errors="coerce").iloc[-1])
            t_u = float(pd.to_numeric(under["true_odds"], errors="coerce").iloc[-1])
            if np.isfinite(t_o) and np.isfinite(t_u) and t_o > 1.0 and t_u > 1.0:
                a, b, price = t_o, t_u, "true odds"
            else:
                a = float(pd.to_numeric(over["odds"], errors="coerce").iloc[-1])
                b = float(pd.to_numeric(under["odds"], errors="coerce").iloc[-1])
                price = "posted odds, de-margined"
            if not (np.isfinite(a) and np.isfinite(b) and a > 1.0 and b > 1.0):
                continue
            p_over = (1.0 / a) / (1.0 / a + 1.0 / b)
            if best is None or abs(p_over - 0.5) < abs(best[1] - 0.5):
                best = (line, p_over, price)
        if best is not None:
            line, p_over, price = best
            out.append({"source": "{} {:g}".format(pool, line), "domain": domain, "line": line, "hkjc_prob": p_over,
                        "implied": _poisson_mean_for_over(p_over, line), "price": price})
    return out


def first_half_split(params: dict, implied: List[dict]) -> List[dict]:
    """Each implied first-half value against full x split and full x (1 - split).

    Pre-match only: in play Goal90CurrentTG is what is left of the match, and the first half's
    share of it is the clock's, not the split's.
    """
    def num(key):
        v = pd.to_numeric(params.get(key), errors="coerce")
        return float(v) if v is not None and np.isfinite(v) else float("nan")

    state = str(params.get("GameState") or "Prematch").strip().lower()
    prematch = state in ("prematch", "pre-match", "", "none", "nan")
    rows = []
    for r in implied:
        goal = r["domain"] == "goal"
        ft = num("Goal90CurrentTG" if goal else "Corner90CurrentTG")
        split = num("Goal90SecondHalfSplitFH" if goal else "Corner90SecondHalfSplitFH")
        split_ft = num("Goal90SecondHalfSplitFT" if goal else "Corner90SecondHalfSplitFT")
        a, b = ft * split, ft * (1.0 - split)
        closer, note = None, ""
        if not prematch:
            note = "in play ({}): the split prices the first half pre-match only".format(params.get("GameState"))
        elif np.isfinite(a) and np.isfinite(b):
            closer = "as_second_half" if abs(b - r["implied"]) < abs(a - r["implied"]) else "as_first_half"
        rows.append({"source": r["source"], "domain": r["domain"], "line": r["line"], "price": r["price"],
                     "hkjc_prob": r["hkjc_prob"], "implied": r["implied"], "full": ft, "split_fh": split,
                     "split_ft": split_ft, "as_first_half": a, "as_second_half": b, "closer": closer, "note": note})
    return rows


def compare_ticket_money(agg: pd.DataFrame, tickets: pd.DataFrame, tolerance: float = 0.01, lo=None,
                         hi=None) -> dict:
    """The live table's money per selection and minute against the bet tables' for the same minutes;
    ``lo`` / ``hi`` keep the minutes [lo, hi), the ones both sides saw whole."""
    a = _sorted(agg)
    a["minute"] = a["start_sell_time"].dt.floor("min")
    A = a.groupby(KEY + ["minute"], as_index=False)[["turnover", "ticket_count"]].sum()
    t = tickets.copy()
    for c in KEY:
        t[c] = pd.to_numeric(t[c], errors="coerce")
    t = t.dropna(subset=KEY)
    for c in KEY:
        t[c] = t[c].astype("int64")
    t["minute"] = pd.to_datetime(t["minute"], errors="coerce").dt.floor("min")
    t["turnover"] = pd.to_numeric(t["turnover"], errors="coerce").fillna(0.0)
    t["ticket_count"] = pd.to_numeric(t["ticket_count"], errors="coerce").fillna(0.0)
    T = t.groupby(KEY + ["minute"], as_index=False)[["turnover", "ticket_count"]].sum()
    if lo is not None:
        A, T = A[A["minute"] >= pd.Timestamp(lo)], T[T["minute"] >= pd.Timestamp(lo)]
    if hi is not None:
        A, T = A[A["minute"] < pd.Timestamp(hi)], T[T["minute"] < pd.Timestamp(hi)]
    j = A.merge(T, on=KEY + ["minute"], how="outer", suffixes=("_agg", "_tickets"))
    for c in ("turnover_agg", "turnover_tickets", "ticket_count_agg", "ticket_count_tickets"):
        j[c] = j[c].fillna(0.0)
    j = j[(j["turnover_agg"] > 0) | (j["turnover_tickets"] > 0)].reset_index(drop=True)
    money_t = float(j["turnover_tickets"].sum())
    ok = (j["turnover_agg"] - j["turnover_tickets"]).abs() <= tolerance * j["turnover_tickets"].clip(lower=1.0)
    j["diff"] = j["turnover_agg"] - j["turnover_tickets"]
    worst = j.reindex(j["diff"].abs().sort_values(ascending=False).index).head(10)
    return {"minutes": int(len(j)), "ratio": float(j["turnover_agg"].sum()) / money_t if money_t > 0 else float("nan"),
            "match_share": float(ok.mean()) if len(j) else float("nan"),
            "money_agg": float(j["turnover_agg"].sum()), "money_tickets": money_t,
            "tickets_agg": float(j["ticket_count_agg"].sum()), "tickets_tickets": float(j["ticket_count_tickets"].sum()),
            "rows": j, "worst": worst.to_dict("records")}


def verdict(spacing: dict, dupes: dict, shape: dict, tickets: Optional[dict] = None) -> List[Tuple[str, str, str]]:
    """(status, check, message) per check: PASS / WARN / FAIL."""
    out = []
    if not spacing.get("rows"):
        out.append(("WARN", "spacing", "no live money rows for this match in the window"))
    elif spacing["modal_seconds"] == 60 and spacing["on_minute_share"] >= 0.99:
        out.append(("PASS", "spacing", "intervals start on the minute, 60 s apart (the training data is per minute)"))
    else:
        out.append(("WARN", "spacing", "intervals mostly {:.0f} s apart, {:.0%} start on the minute; the training data "
                                       "is per minute".format(spacing["modal_seconds"], spacing["on_minute_share"])))
    if dupes["rows"] == 0:
        out.append(("PASS", "duplicates", "one row per selection and interval"))
    else:
        out.append(("FAIL", "duplicates", "{} extra row(s) on {} selection-interval(s): HK${:,.0f} counted more than "
                                          "once".format(dupes["rows"], dupes["keys"], dupes["money"])))
    v = shape.get("verdict")
    detail = "{} of {} selection(s) with {}+ rows only ever rise".format(
        shape.get("rising_only", 0), shape.get("selections", 0), shape.get("min_rows", MIN_SHAPE_ROWS))
    if v == "cumulative":
        out.append(("FAIL", "money shape", detail + ": a running total - every window sum on the desk multiplies "
                                                    "the money"))
    elif v == "per interval":
        out.append(("PASS", "money shape", detail + ": money per interval"))
    else:
        out.append(("WARN", "money shape", detail + ": cannot tell ({})".format(v)))
    if tickets is not None:
        r, share = tickets.get("ratio"), tickets.get("match_share")
        msg = "live table / bet tables = {:.3f} over {} selection-minute(s), {:.0%} within 1%".format(
            r if r is not None else float("nan"), tickets.get("minutes", 0), share if share is not None else 0.0)
        if r is None or not np.isfinite(r):
            out.append(("WARN", "tickets", "no money in either source for the window"))
        elif abs(r - 1.0) <= 0.02 and share >= 0.9:
            out.append(("PASS", "tickets", msg))
        elif abs(r - 1.0) > 0.10:
            out.append(("FAIL", "tickets", msg))
        else:
            out.append(("WARN", "tickets", msg))
    return out


# ================================================================== run
def _for_match(frame: pd.DataFrame, mid: int) -> pd.DataFrame:
    if frame is None or frame.empty or "match_id" not in frame.columns:
        return pd.DataFrame() if frame is None else frame
    return frame[pd.to_numeric(frame["match_id"], errors="coerce") == mid].reset_index(drop=True)


def _latest_odds(odds: pd.DataFrame, as_of) -> pd.DataFrame:
    if odds.empty:
        return odds
    o = odds[pd.to_datetime(odds["effective_datetime"], errors="coerce") <= as_of]
    return o.sort_values("effective_datetime", kind="mergesort").groupby(KEY, as_index=False).last()


def run_probe(settings, source, match_id, as_of=None, minutes: float = 60.0, tickets: bool = False,
              out: Optional[Path] = None, as_db: str = "fbis1_fo_as_db", cs_db: str = "fbis1_fo_cs_db") -> dict:
    """Read one match from ``source`` and write the probe's files; returns the summary."""
    as_of = pd.Timestamp(as_of) if as_of is not None else pd.Timestamp.now()
    mid = int(match_id)
    snap = source.fetch(as_of.to_pydatetime(), match_ids=[mid])
    inv = _for_match(LivePanelBuilder._canon("investments", snap.investments), mid)
    odds = _for_match(LivePanelBuilder._canon("odds", snap.odds), mid)
    history = getattr(snap, "params_history", None)
    raw_params = _for_match(history if history is not None and not history.empty else snap.params, mid)
    since = as_of - pd.Timedelta(minutes=float(minutes))
    if not inv.empty:
        inv = inv[(inv["start_sell_time"] > since) & (inv["start_sell_time"] <= as_of)].reset_index(drop=True)
    latest = _latest_odds(odds, as_of)
    labels = latest[KEY + [c for c in ("pool_name", "line_label", "combination_string", "odds", "true_odds")
                           if c in latest.columns]] if not latest.empty else pd.DataFrame(columns=KEY)
    money = _sorted(inv) if not inv.empty else pd.DataFrame(columns=KEY + ["start_sell_time", "turnover",
                                                                            "ticket_count"])
    if not money.empty and not labels.empty:
        lab = labels.copy()
        for c in KEY:
            lab[c] = pd.to_numeric(lab[c], errors="coerce").astype("int64")
        money = money.drop(columns=[c for c in lab.columns if c not in KEY and c in money.columns]) \
            .merge(lab, on=KEY, how="left")

    spacing, dupes, shape = interval_spacing(money), duplicate_rows(money), money_shape(money)
    bucket = bucket_breakdown(money, as_of)
    T = as_of.floor("{}min".format(settings.panel.bucket_minutes))
    step = pd.Timedelta(minutes=settings.panel.bucket_minutes)
    if not bucket.empty and not money.empty:
        last = money[(money["start_sell_time"] >= T - step) & (money["start_sell_time"] < T)] \
            .groupby(KEY)["turnover"].sum().rename("last_bucket")
        now = money[money["start_sell_time"] >= T].groupby(KEY)["turnover"].sum().rename("this_bucket_so_far")
        bucket = bucket.merge(last.reset_index(), on=KEY, how="left").merge(now.reset_index(), on=KEY, how="left")
        bucket = bucket.rename(columns={"money": "last_5_min"})
        for c in ("last_bucket", "this_bucket_so_far"):
            bucket[c] = bucket[c].fillna(0.0)

    fh: List[dict] = []
    if not raw_params.empty and "EventTime" in raw_params.columns:
        p = raw_params.assign(_t=pd.to_datetime(raw_params["EventTime"], errors="coerce"))
        p = p[p["_t"] <= as_of].sort_values("_t", kind="mergesort")
        if not p.empty:
            fh = first_half_split(p.iloc[-1].to_dict(), implied_first_half(latest))

    cmp = None
    if tickets:
        from src.hkjc import queries
        pools = sorted({int(x) for x in money["pool_id"].unique()}) if not money.empty else []
        # whole minutes only: the window cuts the first and the one in progress is still filling
        lo, hi = since.ceil("min"), as_of.floor("min")
        if pools and hi > lo:
            sql = queries.ticket_money(pools, lo.strftime("%Y-%m-%d %H:%M:%S"), as_db=as_db, cs_db=cs_db,
                                       until=hi.strftime("%Y-%m-%d %H:%M:%S"))
            cmp = compare_ticket_money(money, source.read("bis", sql, parse_dates=["minute"]), lo=lo, hi=hi)
        else:
            cmp = {"minutes": 0, "ratio": float("nan"), "match_share": float("nan"), "rows": pd.DataFrame()}
    checks = verdict(spacing, dupes, shape, cmp)

    folder = Path(out) if out else Path(settings.paths.work) / "diagnostics" / "{}_probe_{}".format(
        time.strftime("%Y%m%d-%H%M%S"), mid)
    folder.mkdir(parents=True, exist_ok=True)
    money.to_csv(folder / "investments_raw.csv", index=False)
    bucket.to_csv(folder / "selections.csv", index=False)
    raw_params.to_csv(folder / "params.csv", index=False)
    pd.DataFrame(fh, columns=["source", "domain", "line", "price", "hkjc_prob", "implied", "full", "split_fh",
                              "split_ft", "as_first_half", "as_second_half", "closer", "note"]) \
        .to_csv(folder / "fh_split.csv", index=False)
    if cmp is not None and isinstance(cmp.get("rows"), pd.DataFrame):
        cmp["rows"].to_csv(folder / "tickets.csv", index=False)
    lines = ["Algo E live money probe - match {} as of {} ({})".format(mid, as_of, _describe(source)),
             "window: the last {:g} minutes, {} money row(s), {} selection(s)".format(
                 float(minutes), spacing["rows"], spacing["selections"]), ""]
    lines += ["[{}] {}: {}".format(s, c, m) for s, c, m in checks]
    if fh:
        lines += ["", "first half (pre-match: full x split vs full x (1 - split), against HKJC's own first-half prices):"]
        for r in fh:
            lines.append("  {:<12} implied {:.3f} | x split {:.3f} | x (1 - split) {:.3f} | closer: {} {}".format(
                r["source"], r["implied"], r["as_first_half"], r["as_second_half"], r["closer"] or "-", r["note"]))
    if not bucket.empty:
        lines += ["", "last 5 minutes, biggest first (selections.csv has every one):"]
        for r in bucket.head(8).to_dict("records"):
            lines.append("  {:<6} {:<8} {:<6} HK${:>12,.0f}  {:>3} row(s) {:>4.0f} ticket(s)  {}".format(
                str(r.get("pool_name", r["pool_id"])), str(r.get("line_label", "") or ""),
                str(r.get("combination_string", "") or ""), r["last_5_min"], r["rows"], r["tickets"], r["pattern"]))
    (folder / "verdict.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    logger.info("probe written to %s", folder)
    return {"folder": str(folder), "match_id": mid, "as_of": str(as_of), "rows": int(spacing["rows"]),
            "spacing": spacing, "duplicates": dupes, "shape": shape, "first_half": fh,
            "tickets": None if cmp is None else {k: v for k, v in cmp.items() if k != "rows"},
            "verdict": checks, "text": lines}


def _describe(source) -> str:
    try:
        return source.describe()
    except Exception:                                                   # noqa: BLE001
        return type(source).__name__
