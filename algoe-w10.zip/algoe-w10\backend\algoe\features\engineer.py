"""
Feature Engineer

One class that turns a day of panel rows into the exact inputs each model
needs. The public methods are named by what they feed:

    features_for_turnover_match_total(day)      level: match x bucket
    features_for_turnover_pool_share(day)       level: match x pool x bucket
    features_for_turnover_selection_share(day)  level: selection x bucket (share inside its pool)
    features_for_turnover_selection(day)        level: selection x bucket (direct turnover)
    features_for_probability(day)               level: settled selection x bucket

All of them read one ``DayData`` built by ``prepare_day``, where each feature
group (catalog.py) is computed once:

    _group_money_history   selection / pool / match / board lags, EWMA, today so far
    _group_events          running score, goal and red-card pulses, time since goal
    _group_lifecycle       minutes to kick-off, match minute, half time, hinge bases
    _group_calendar        weekday, hour, weekend, HK holiday, evening
    _group_price           implied prob, value vs HKJC true and vs market, price moves
    _group_line_position   rank by balance, offset from the main line, line age, moves
    _group_concurrency     live matches, board money, match share and rank of the board
    _group_bet_type        family / segment / side flags - what a pool IS, never its code

KNOWN-AT-T RULE. Every value for bucket T uses money from buckets before T,
prices posted before T, and incidents and parameters stamped before T. The
label is the money inside T. ``tests/test_algoe.py`` tampers with everything
inside one bucket and asserts no feature of that bucket moves.

MISSING AND UNKNOWN. Every column is filled and clipped from its catalog
spec, so no model ever sees NaN. A pool code never seen before is resolved by
the taxonomy's rules; a league never seen before encodes to the global level
with ``league_known = 0``.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Odds age at the bucket start (the W06 value is end-of-bucket); FH pools not forecastable
                after half time; goal pulse per provider then max (no later goals); money today from
                the forecast day; prepare_live for LivePanelBuilder output
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.calendar import HKCalendar
from ..core.logging import get_logger
from ..core.taxonomy import PoolTaxonomy, default_taxonomy, parse_line, side_of
from ..data.panel import (GOAL, CORNER, KEY, RED, REF_DEFAULTS, YELLOW_RED, asof_before, market_consensus,
                          ref_phase, reference_key, score_asof)
from . import catalog as C
from .encoders import EncoderState

logger = get_logger(__name__)

MKEY = ["match_id", "bucket"]
PKEY = ["match_id", "pool_name", "bucket"]
LKEY = ["match_id", "pool_name", "line_id", "bucket"]
STEP = pd.Timedelta(minutes=5)


@dataclass
class FeatureSet:
    """Model-ready inputs for one level. Row i of every array is the same row."""
    level: str
    keys: pd.DataFrame
    X: pd.DataFrame
    y: np.ndarray
    exposure: np.ndarray
    last5: np.ndarray
    group: np.ndarray
    cuts: pd.DataFrame
    kinds: Dict[str, str] = field(default_factory=dict)
    weight: Optional[np.ndarray] = None

    def __len__(self) -> int:
        return len(self.y)

    @property
    def feature_names(self) -> List[str]:
        return list(self.X.columns)

    def columns_for(self, kinds: Sequence[str]) -> List[str]:
        return [c for c in self.X.columns if self.kinds.get(c, "raw") in kinds]

    def subset(self, mask) -> "FeatureSet":
        m = np.asarray(mask, dtype=bool)
        return FeatureSet(self.level, self.keys.loc[m].reset_index(drop=True),
                          self.X.loc[m].reset_index(drop=True), self.y[m], self.exposure[m],
                          self.last5[m], self.group[m], self.cuts.loc[m].reset_index(drop=True),
                          dict(self.kinds), None if self.weight is None else self.weight[m])

    @staticmethod
    def concat(parts: Sequence["FeatureSet"]) -> "FeatureSet":
        parts = [p for p in parts if p is not None and len(p)]
        if not parts:
            raise ValueError("no rows to concatenate")
        offset, groups = 0, []
        for p in parts:
            groups.append(p.group + offset)
            offset += int(p.group.max()) + 1 if len(p.group) else 0
        w = None if any(p.weight is None for p in parts) else np.concatenate([p.weight for p in parts])
        return FeatureSet(parts[0].level, pd.concat([p.keys for p in parts], ignore_index=True),
                          pd.concat([p.X for p in parts], ignore_index=True),
                          np.concatenate([p.y for p in parts]), np.concatenate([p.exposure for p in parts]),
                          np.concatenate([p.last5 for p in parts]), np.concatenate(groups),
                          pd.concat([p.cuts for p in parts], ignore_index=True), dict(parts[0].kinds), w)


@dataclass
class DayData:
    day: pd.Timestamp
    sel: pd.DataFrame
    match: pd.DataFrame
    pool: pd.DataFrame

    @property
    def empty(self) -> bool:
        return self.sel is None or self.sel.empty


def _num(frame: pd.DataFrame, col: str, default: float = np.nan) -> np.ndarray:
    if col not in frame.columns:
        return np.full(len(frame), default, dtype="float64")
    return pd.to_numeric(frame[col], errors="coerce").to_numpy(dtype="float64")


def _ints(frame: pd.DataFrame, cols) -> pd.DataFrame:
    for c in cols:
        if c in frame.columns:
            frame[c] = pd.to_numeric(frame[c], errors="coerce").fillna(-1).astype("int64")
    return frame


def _shift(frame: pd.DataFrame, keys: List[str], value: str, k: int, name: str) -> pd.DataFrame:
    out = frame[keys + ["bucket", value]].rename(columns={value: name})
    return out.assign(bucket=out["bucket"] + k * STEP)


def _share(num: np.ndarray, den: np.ndarray, fill: float = 0.0) -> np.ndarray:
    return np.where(den > 0, num / np.maximum(den, 1e-12), fill)


def _ewmas(lags: np.ndarray):
    """Fast (0.5) and slow (0.2) EWMAs of lag columns ordered newest first."""
    fast, slow = lags[:, -1].copy(), lags[:, -1].copy()
    for j in range(lags.shape[1] - 2, -1, -1):          # oldest to newest
        fast = 0.5 * lags[:, j] + 0.5 * fast
        slow = 0.2 * lags[:, j] + 0.8 * slow
    return fast, slow


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


YELLOW = 78


def _ref(refs: Optional[dict], key: str) -> float:
    """A trailing reference count (data.panel.reference_values); its default when there is none."""
    try:
        v = float((refs or {}).get(key))
    except (TypeError, ValueError):
        v = float("nan")
    return v if np.isfinite(v) and v > 0 else float(REF_DEFAULTS[key])


def _ref_map(refs: Optional[dict], group: str, keys: np.ndarray, default: float = np.nan) -> np.ndarray:
    """refs[group][key] for each key (family|prematch or family|inplay), ``default`` where none."""
    table = (refs or {}).get(group) or {}
    return np.array([float(table.get(k, default)) for k in keys], dtype="float64")


def _board_popularity(frame: pd.DataFrame, pop: np.ndarray) -> Dict[str, np.ndarray]:
    """pop_board_share, pop_gap_top, live_pop_share for each row's (match, bucket), over the distinct
    matches the frame holds at that bucket."""
    inplay = _num(frame, "inplay", 0.0) if "inplay" in frame.columns else \
        (frame["is_inplay"].fillna(False).astype(float).to_numpy() if "is_inplay" in frame.columns
         else np.zeros(len(frame)))
    f = pd.DataFrame({"match_id": frame["match_id"].to_numpy(), "bucket": frame["bucket"].to_numpy(),
                      "pop": np.nan_to_num(np.asarray(pop, dtype="float64")), "ip": np.nan_to_num(inplay)})
    u = f.drop_duplicates(["match_id", "bucket"]).copy()
    u["e"] = np.exp(np.clip(u["pop"].to_numpy(), -20, 20))
    u["e_ip"] = u["e"] * (u["ip"].to_numpy() > 0)
    g = u.groupby("bucket", sort=False)
    tot = g["e"].transform("sum").to_numpy()
    top = g["pop"].transform("max").to_numpy()
    u["pop_board_share"] = u["e"].to_numpy() / np.maximum(tot, 1e-300)
    u["pop_gap_top"] = np.clip(top - u["pop"].to_numpy(), 0, None)
    u["live_pop_share"] = g["e_ip"].transform("sum").to_numpy() / np.maximum(tot, 1e-300)
    m = f[["match_id", "bucket"]].merge(u[["match_id", "bucket", "pop_board_share", "pop_gap_top", "live_pop_share"]],
                                        on=["match_id", "bucket"], how="left")
    return {c: m[c].to_numpy(dtype="float64") for c in ("pop_board_share", "pop_gap_top", "live_pop_share")}


def _incidents(events: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Match_Events as (match_id, type, provider, time, side 1 home / 2 away / NaN)."""
    cols = ["match_id", "type", "p", "t", "side"]
    if events is None or events.empty or "incident_type" not in events.columns:
        return pd.DataFrame(columns=cols)
    ev = events.dropna(subset=["match_id", "incident_datetime", "incident_type"])
    return pd.DataFrame({
        "match_id": pd.to_numeric(ev["match_id"], errors="coerce").fillna(-1).astype("int64").to_numpy(),
        "type": pd.to_numeric(ev["incident_type"], errors="coerce").to_numpy(),
        "p": (pd.to_numeric(ev["provider_id"], errors="coerce").fillna(-1).astype("int64").to_numpy()
              if "provider_id" in ev.columns else np.ones(len(ev), dtype="int64")),
        "t": pd.to_datetime(ev["incident_datetime"]).astype("datetime64[ns]").to_numpy(),
        "side": (pd.to_numeric(ev["home_or_away"], errors="coerce").to_numpy()
                 if "home_or_away" in ev.columns else np.full(len(ev), np.nan))})


def _pulse(m: pd.DataFrame, ev: pd.DataFrame, types, tau: float, side: Optional[int] = None) -> np.ndarray:
    """For each (match, bucket) of ``m``: sum of exp(-age / tau) over the match's incidents of ``types``
    (and ``side``) strictly before the bucket - each provider's sum, then the largest (the score_asof
    rule: choosing a provider by its whole-day count would let later incidents choose it)."""
    out = np.zeros(len(m))
    if ev.empty or not len(m):
        return out
    sub = ev[ev["type"].isin(list(types))]
    if side is not None:
        sub = sub[sub["side"] == side]
    if sub.empty:
        return out
    by_match = {k: [np.sort(g["t"].to_numpy()) for _, g in gm.groupby("p")] for k, gm in sub.groupby("match_id")}
    buckets = m["bucket"].to_numpy(dtype="datetime64[ns]")
    for mid, idx in pd.Series(np.arange(len(m))).groupby(m["match_id"].to_numpy()).groups.items():
        times = by_match.get(mid)
        if not times:
            continue
        idx = np.asarray(list(idx))
        t_b = buckets[idx]
        for t in times:
            age = (t_b[:, None] - t[None, :]).astype("timedelta64[s]").astype("float64") / 60.0
            val = np.where(age > 0, np.exp(-np.clip(age, 0, None) / tau), 0.0).sum(axis=1)
            out[idx] = np.maximum(out[idx], val)
    return out


def _kickoff_value(m: pd.DataFrame, col: str) -> np.ndarray:
    """``col`` as it stood before kick-off: each pre-match bucket its own value, each in-play bucket the
    last pre-match one. A match already in play when the day's rows begin (it crossed midnight) has
    the first value seen that day. Never a later value than the bucket's own."""
    v = _num(m, col)
    pre = ~(m["is_inplay"].fillna(False).astype(bool).to_numpy() if "is_inplay" in m.columns
            else np.zeros(len(m), dtype=bool))
    f = pd.DataFrame({"match_id": m["match_id"].to_numpy(), "bucket": m["bucket"].to_numpy(),
                      "v": v, "pre": np.where(pre & np.isfinite(v), v, np.nan), "_row": np.arange(len(m))})
    f = f.sort_values(["match_id", "bucket"], kind="stable")
    g = f.groupby("match_id", sort=False)
    ko = g["pre"].ffill()
    seen = f["v"].notna()
    first = f["v"].where(seen & (seen.groupby(f["match_id"], sort=False).cumsum() == 1))
    first = first.groupby(f["match_id"], sort=False).ffill()
    out = np.empty(len(m))
    out[f["_row"].to_numpy()] = np.where(ko.notna(), ko, first).astype("float64")
    return out


def _priced(frame: pd.DataFrame) -> np.ndarray:
    """Rows whose price was on the board when the bucket started."""
    odds = _num(frame, "odds")
    ok = np.isfinite(odds) & (odds > 1.0)
    if "priced_before" in frame.columns:
        ok &= frame["priced_before"].fillna(False).astype(bool).to_numpy()
    return ok


class FeatureEngineer:
    """Builds every model's inputs from panel days. Stateless apart from the encoders."""

    def __init__(self, settings, taxonomy: Optional[PoolTaxonomy] = None,
                 calendar: Optional[HKCalendar] = None, encoders: Optional[EncoderState] = None):
        self.settings = settings
        fs = settings.features
        self.taxonomy = taxonomy or default_taxonomy(str(settings.paths.pools_file))
        self.calendar = calendar or HKCalendar(str(settings.paths.holidays))
        self.encoders = encoders or EncoderState()
        self.match_specs = C.match_specs(fs.ko_knots, fs.minute_knots)
        self.pool_specs = C.pool_specs()
        self.sel_specs = C.selection_specs()

    # ================================================================ public
    def features_for_turnover_match_total(self, day: DayData) -> FeatureSet:
        """Exposure is the market index: the model forecasts money per unit of market size."""
        m = day.match
        X = self._finish(m, self.match_specs, encode="league")
        return FeatureSet("match", m[MKEY].reset_index(drop=True), X, m["y"].to_numpy(dtype="float64"),
                          _num(m, "market_index", 1.0), m["last5"].to_numpy(dtype="float64"),
                          np.arange(len(m)), self._cuts(m), self._kinds(self.match_specs))

    def features_for_turnover_board_total(self, day: DayData) -> FeatureSet:
        """One row per bucket: the whole board's money (four-stage level), market index as exposure."""
        m = day.match
        if m is None or m.empty:
            return FeatureSet("board", pd.DataFrame(columns=["bucket"]), pd.DataFrame(), np.zeros(0), np.zeros(0),
                              np.zeros(0), np.zeros(0, dtype=int), pd.DataFrame(), {}, np.zeros(0))
        enc = self._encode(m, "league")
        pop = 0.5 * (enc["team_hi"] + enc["team_lo"]) if "team_hi" in enc else enc.get("league_level", np.zeros(len(m)))
        e = np.exp(np.clip(np.nan_to_num(np.asarray(pop, dtype="float64")), -20, 20))
        f = m.assign(_e=e, _eip=e * (_num(m, "inplay", 0.0) > 0))
        g = f.groupby("bucket", sort=True, observed=True)
        b = g.agg(y=("y", "sum"), last5=("last5", "sum"), _e=("_e", "sum"), _eip=("_eip", "sum")).reset_index()
        const = [s.name for s in C.board_specs() if s.name in m.columns]
        b = b.merge(g[const + ["market_index"]].first().reset_index(), on="bucket", how="left")
        b["board_pop"] = np.log(np.maximum(b["_e"].to_numpy(dtype="float64"), 1e-300))
        b["live_pop_share"] = b["_eip"].to_numpy(dtype="float64") / np.maximum(b["_e"].to_numpy(dtype="float64"), 1e-300)
        specs = C.board_specs()
        X = self._finish(b, specs, encode="none")
        return FeatureSet("board", b[["bucket"]].reset_index(drop=True), X, b["y"].to_numpy(dtype="float64"),
                          _num(b, "market_index", 1.0), b["last5"].to_numpy(dtype="float64"), np.arange(len(b)),
                          self._cuts(b), self._kinds(specs))

    def features_for_turnover_match_share(self, day: DayData) -> FeatureSet:
        """Each match's money against the whole board's in the same bucket (exposure), normalised over the
        board: the match_total features, for a share instead of a level."""
        m = day.match
        X = self._finish(m, self.match_specs, encode="league")
        board = m.groupby("bucket", observed=True)["y"].transform("sum").to_numpy(dtype="float64") if len(m) \
            else np.zeros(0)
        group = m.groupby("bucket", observed=True, sort=False).ngroup().to_numpy() if len(m) else np.zeros(0, dtype=int)
        return FeatureSet("match_share", m[MKEY].reset_index(drop=True), X, m["y"].to_numpy(dtype="float64"), board,
                          m["last5"].to_numpy(dtype="float64"), group, self._cuts(m), self._kinds(self.match_specs))

    def features_for_turnover_pool_share(self, day: DayData) -> FeatureSet:
        p = day.pool
        X = self._finish(p, self.pool_specs, encode="pool")
        group = p.groupby(MKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("pool", p[PKEY].reset_index(drop=True), X, p["y"].to_numpy(dtype="float64"),
                          p["exposure"].to_numpy(dtype="float64"), p["last5"].to_numpy(dtype="float64"),
                          group, self._cuts(p), self._kinds(self.pool_specs))

    def features_for_turnover_selection_share(self, day: DayData) -> FeatureSet:
        s = day.sel[day.sel["forecastable"]].reset_index(drop=True)
        X = self._finish(s, self.sel_specs, encode="pool")
        group = s.groupby(PKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("selection_share", s[KEY + MKEY[:1] + ["pool_name", "bucket"]].reset_index(drop=True),
                          X, s["y"].to_numpy(dtype="float64"), s["pool_y"].to_numpy(dtype="float64"),
                          s["tv1"].to_numpy(dtype="float64"), group, self._cuts(s), self._kinds(self.sel_specs))

    def features_for_turnover_selection(self, day: DayData) -> FeatureSet:
        """Direct model: selection features plus its pool's and match's context."""
        s = day.sel[day.sel["forecastable"]].reset_index(drop=True)
        mcols = [sp.name for sp in self.match_specs if sp.name in day.match.columns and sp.name not in s.columns]
        pcols = [sp.name for sp in self.pool_specs if sp.name in day.pool.columns
                 and sp.name not in s.columns and sp.name not in mcols]
        s = s.merge(day.match[MKEY + mcols + ["league_code"]].rename(columns={"league_code": "_lg"}),
                    on=MKEY, how="left")
        s = s.merge(day.pool[PKEY + pcols], on=PKEY, how="left")
        if "league_code" not in s.columns:
            s["league_code"] = s["_lg"]
        # the match's encoded levels (league, teams, board popularity) are made here, not stored with the
        # day, so they are asked for by name - without them the direct model never saw the league's level
        encoded = [sp for sp in self.match_specs if sp.kind == "encoded" or sp.name in ("league_known", "team_known")]
        specs = C.by_name(self.sel_specs + [sp for sp in self.pool_specs if sp.name in pcols]
                          + [sp for sp in self.match_specs if sp.name in mcols] + encoded)
        spec_list = list(specs.values())
        X = self._finish(s, spec_list, encode="both")
        group = s.groupby(PKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("selection", s[KEY + ["match_id", "pool_name", "bucket"]].reset_index(drop=True),
                          X, s["y"].to_numpy(dtype="float64"), _num(s, "market_index", 1.0),
                          s["tv1"].to_numpy(dtype="float64"), group, self._cuts(s), self._kinds(spec_list))

    def features_for_probability(self, day: DayData, require_outcome: bool = True) -> FeatureSet:
        """Two-way and three-way selections with every belief source, as logits.

        Training / scoring (require_outcome=True): settled rows only; y is the
        soft outcome (r + 1) / 2 for r in {-1, -0.5, +0.5, +1}, pushes dropped,
        weight per settings.probability.weight. Serving (False): every live
        row, y = NaN; ``keys['_row']`` maps back to day.sel positions.
        """
        s = day.sel
        if day.empty or "forecastable" not in s.columns:
            return FeatureSet("probability", pd.DataFrame(), pd.DataFrame(), np.zeros(0), np.zeros(0),
                              np.zeros(0), np.zeros(0, dtype=int), pd.DataFrame(), {}, np.zeros(0))
        # only prices actually on offer: a withdrawn line keeps its last (stale) quote in the panel
        o = self.settings.optimizer
        age = np.expm1(_num(s, "log_odds_age", 0.0))
        inplay = _num(s, "inplay", 0.0) > 0
        live = age <= np.where(inplay, o.max_odds_age_inplay_min, o.max_odds_age_prematch_min)
        keep = s["forecastable"].to_numpy() & live
        if require_outcome:
            keep &= s["outcome"].notna().to_numpy()
        rows = np.flatnonzero(keep)
        s = s.iloc[rows].reset_index(drop=True)
        if s.empty:
            return FeatureSet("probability", pd.DataFrame(), pd.DataFrame(), np.zeros(0), np.zeros(0),
                              np.zeros(0), np.zeros(0, dtype=int), pd.DataFrame(), {}, np.zeros(0))
        X = pd.DataFrame(index=s.index)
        for src in ("hkjc_true", "market", "poisson", "demargin"):
            p = np.clip(_num(s, "p_" + src), 1e-4, 1 - 1e-4)
            ok = np.isfinite(_num(s, "p_" + src))
            X["logit_" + src] = np.where(ok, np.log(p / (1 - p)), 0.0)
            X["has_" + src] = ok.astype("float64")
        X["inplay"] = s["inplay"].to_numpy(dtype="float64")
        X["minute"] = np.clip(_num(s, "minute", 0.0), 0, 130) / 90.0
        X["pre_ko"] = np.clip(_num(s, "pre_ko_min", 0.0), 0, 720) / 360.0
        X["rank_0"] = s["rank_0"].to_numpy(dtype="float64")
        X["log_odds_age"] = np.clip(_num(s, "log_odds_age", 0.0), 0, 7)
        X["log_odds"] = np.log(np.clip(_num(s, "odds", 2.0), 1.001, None))
        X["book_margin"] = np.clip(_num(s, "book_margin", 0.08), -0.2, 0.6)
        for f in C.FAMILIES:
            X["fam_" + f] = (s["family"].to_numpy() == f).astype("float64")
        X["side_home_over"] = s["side_home_over"].to_numpy(dtype="float64")
        # customer insight: where the money went against the price, how big the tickets were, how much
        # money it was, and how the price has been moving
        X["wom_l1"] = np.clip(_num(s, "wom_l1", 0.0), -3, 3)
        X["wom_l6"] = np.clip(_num(s, "wom_l6", 0.0), -3, 3)
        X["line_money_l6"] = np.clip(_num(s, "line_money_l6", 0.0), 0, 25)
        X["s_rel_stake_l1"] = np.clip(_num(s, "s_rel_stake_l1", 0.0), -4, 4)
        X["odds_move_5"] = np.clip(_num(s, "odds_move_5", 0.0), -1, 1)
        X["odds_move_15"] = np.clip(_num(s, "odds_move_15", 0.0), -1, 1)
        X = X.fillna(0.0)
        y = ((_num(s, "outcome") + 1.0) / 2.0)
        mode = self.settings.probability.weight
        if mode == "money":
            w = np.clip(_num(s, "y", 0.0), 0, None) + 1.0
        elif mode == "selection":
            n = s.groupby(KEY, observed=True)["bucket"].transform("size").to_numpy(dtype="float64")
            w = 1.0 / np.maximum(n, 1.0)
        else:
            w = np.ones(len(s))
        keys = s[KEY + ["match_id", "pool_name", "line_id", "bucket"]].loc[:, lambda d: ~d.columns.duplicated()]
        group = s["match_id"].to_numpy()
        fs = FeatureSet("probability", keys.reset_index(drop=True), X.astype("float32"), y,
                        np.ones(len(s)), np.zeros(len(s)), group, self._cuts(s),
                        {c: "raw" for c in X.columns}, w)
        for src in ("hkjc_true", "market", "poisson", "demargin"):
            fs.keys["p_" + src] = _num(s, "p_" + src)
        fs.keys["side"] = s["side"].to_numpy()
        fs.keys["odds"] = _num(s, "odds")
        fs.keys["stake"] = _num(s, "y", 0.0)
        fs.keys["outcome"] = _num(s, "outcome")
        fs.keys["_row"] = rows
        return fs

    # ============================================================ prepare
    # match columns the pool and selection frames carry: the game state their shares answer to
    STATE_COLS = ("inplay", "minute", "pre_ko_min", "since_goal", "phase", "goals_so_far", "abs_score_diff",
                  "goal_p10", "red_p10", "tg_full", "abs_sup", "fav_sign", "fav_lead", "dog_leading", "fav_reds",
                  "dog_reds", "goal_p10_fav", "goal_p10_dog", "tg_shift", "corners_so_far", "corner_diff_fav",
                  "corner_p5", "yellow_p10")

    def prepare_day(self, panel: pd.DataFrame, tail: Optional[pd.DataFrame] = None,
                    events: Optional[pd.DataFrame] = None, market: Optional[pd.DataFrame] = None,
                    day=None, market_index: Optional[float] = None, references: Optional[dict] = None) -> DayData:
        """``market_index`` is the market's size before the day (HistoricalPanel.market_index):
        money features are divided by it, and 1.0 leaves them in reference HK$. ``references`` is
        what a normal board looked like over the weeks before (HistoricalPanel.references): counts
        and margins are read against it."""
        if panel is None or panel.empty:
            return DayData(pd.Timestamp(day) if day is not None else pd.NaT,
                           pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
        idx = float(market_index) if market_index is not None and np.isfinite(market_index) \
            and market_index > 0 else 1.0
        refs = references or {}
        base = self._base(panel)
        day = pd.Timestamp(day).normalize() if day is not None else base["bucket"].min().normalize()
        money = self._money_table(base, tail)
        base = self._group_money_history(base, money, idx)
        match = self._match_frame(base, money, day, idx, refs)
        match = self._group_events(match, events)
        match = self._group_lifecycle(match)
        # each group adds its columns one at a time; a copy between groups keeps the frame in one block
        match = self._group_calendar(match).copy()
        match = self._group_concurrency(match, money, idx, refs)
        base = self._group_price(base, market).copy()
        base = self._group_line_position(base, self._label_tail(tail), idx, refs)
        base = self._group_customer(base, idx)
        base = self._group_bet_type(base)
        base = base.merge(match[MKEY + [c for c in self.STATE_COLS if c in match.columns]], on=MKEY, how="left").copy()
        base = self._side_of_favourite(base)
        # a first-half market is settled once the half is over, whatever the feed still lists
        past_ht = base["phase"].isin(["half_time", "second_half", "extra_time"]).to_numpy()
        fh = (base["segment"].astype(str) == "FH").to_numpy()
        base["forecastable"] = base["forecastable"].to_numpy() & ~(fh & past_ht)
        pool = self._pool_frame(base, match, money, idx, refs)
        match = self._match_price_level(match.copy(), pool, refs)
        base = self._outcome(base.copy())
        base["market_index"] = idx
        match["market_index"] = idx
        match["ref_key"] = reference_key(refs)
        return DayData(day, base, match, pool)

    def prepare_live(self, panel: pd.DataFrame, extra: dict) -> DayData:
        """prepare_day for a LivePanelBuilder result, called exactly as the FeatureStore calls it
        for a historical day (same day, same one-hour tail across midnight, same market index)."""
        current = extra.get("current_bucket")
        day = pd.Timestamp(current).normalize() if current is not None else None
        return self.prepare_day(panel, extra.get("tail"), extra.get("events"), extra.get("market"), day=day,
                                market_index=extra.get("market_index"), references=extra.get("references"))

    # ------------------------------------------------------------- base
    def _base(self, panel: pd.DataFrame) -> pd.DataFrame:
        keep = [c for c in (
            "bucket", "pool_id", "line_id", "combination_id", "match_id", "pool_name", "line_label",
            "combination_string", "odds", "true_odds", "odds_age_min", "priced_before", "forecastable",
            "in_window", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh", "game_state",
            "match_minute", "mins_to_ko", "is_inplay", "minutes_since_goal", "event_window",
            "league_code", "ko_time", "turnover", "tickets", "dividend", "y_frac", "settled", "avg_odds",
            "p__hkjc_true", "p__poisson", "p__demargin", "clock_bin", "home_name", "away_name")
            if c in panel.columns]
        b = panel[keep].copy()
        b = _ints(b, KEY + ["match_id"])
        b["bucket"] = pd.to_datetime(b["bucket"]).astype("datetime64[ns]")
        b = b.drop_duplicates(KEY + ["bucket"]).reset_index(drop=True)
        b["pool_name"] = b["pool_name"].astype("string").fillna("UNKNOWN").str.upper()
        if "forecastable" not in b.columns:
            b["forecastable"] = True
        b["forecastable"] = b["forecastable"].fillna(False).astype(bool)
        b["league_code"] = b["league_code"].astype("string").fillna("unknown") if "league_code" in b.columns \
            else "unknown"
        specs = {p: self.taxonomy.resolve(p) for p in b["pool_name"].unique()}
        b["family"] = b["pool_name"].map({p: s.family for p, s in specs.items()})
        b["segment"] = b["pool_name"].map({p: s.segment for p, s in specs.items()})
        b["market"] = b["pool_name"].map({p: s.market for p, s in specs.items()})
        b["theta_domain"] = b["pool_name"].map({p: s.theta_domain for p, s in specs.items()})
        b = self._label(b)
        b["y"] = np.clip(_num(b, "turnover", 0.0), 0, None)
        b["y"] = np.nan_to_num(b["y"], nan=0.0)
        return b

    @staticmethod
    def _label(b: pd.DataFrame) -> pd.DataFrame:
        """``line`` (float, NaN without a line) and ``side`` (H / A / L / D / score key) from the labels."""
        labels = b["line_label"].astype("string") if "line_label" in b.columns else pd.Series(pd.NA, index=b.index)
        parsed = {lab: parse_line(lab) for lab in labels.dropna().unique()}
        b["line"] = labels.map(parsed).astype("float64")
        comb = b["combination_string"].astype("string").fillna("") if "combination_string" in b.columns \
            else pd.Series("", index=b.index, dtype="string")
        pair = comb + "|" + b["combination_id"].astype("string")
        table = {k: side_of(*k.rsplit("|", 1)) for k in pair.dropna().unique()}
        b["side"] = pair.map(table).fillna("?").astype(str)
        return b

    def _label_tail(self, tail: Optional[pd.DataFrame]) -> Optional[pd.DataFrame]:
        """The previous day's last hour in the base frame's terms, for slot history across midnight."""
        if tail is None or tail.empty:
            return None
        t = tail.copy()
        t = _ints(t, KEY + ["match_id"])
        t["bucket"] = pd.to_datetime(t["bucket"]).astype("datetime64[ns]")
        t["pool_name"] = t["pool_name"].astype("string").fillna("UNKNOWN").str.upper()
        t["y"] = np.clip(np.nan_to_num(_num(t, "turnover", 0.0), nan=0.0), 0, None)
        t["odds"] = _num(t, "odds")
        t["priced_before"] = t["priced_before"].fillna(False).astype(bool) if "priced_before" in t.columns else True
        t = self._label(t)
        return t[KEY + ["match_id", "pool_name", "bucket", "y", "odds", "priced_before", "line", "side"]
                 ].drop_duplicates(KEY + ["bucket"]).reset_index(drop=True)

    def _money_table(self, base: pd.DataFrame, tail: Optional[pd.DataFrame]) -> pd.DataFrame:
        cols = KEY + ["match_id", "pool_name", "bucket", "y", "tickets"]
        cur = base.assign(tickets=_num(base, "tickets", 0.0))[cols]
        cur = cur[cur["y"] > 0]
        if tail is not None and not tail.empty:
            t = tail.copy()
            t = _ints(t, KEY + ["match_id"])
            t["bucket"] = pd.to_datetime(t["bucket"]).astype("datetime64[ns]")
            t["pool_name"] = t["pool_name"].astype("string").str.upper()
            t["y"] = np.clip(_num(t, "turnover", 0.0), 0, None)
            t["tickets"] = _num(t, "tickets", 0.0)
            t = t[t["y"] > 0][cols]
            cur = pd.concat([t, cur], ignore_index=True)
        cur["tickets"] = np.nan_to_num(cur["tickets"].to_numpy(dtype="float64"), nan=0.0)
        return cur.groupby(KEY + ["match_id", "pool_name", "bucket"], observed=True, as_index=False)[
            ["y", "tickets"]].sum()

    # ------------------------------------------------------ money history
    def _group_money_history(self, b: pd.DataFrame, money: pd.DataFrame, idx: float = 1.0) -> pd.DataFrame:
        """Lags tv1..tvN stay in HK$ (the baselines are scored in HK$); the features are in market-index
        units, so a market twice the size reads the same."""
        n = int(self.settings.features.lag_buckets)
        sel_money = money[KEY + ["bucket", "y", "tickets"]]
        for k in range(1, n + 1):
            lag = _shift(sel_money, KEY, "y", k, "tv{}".format(k))
            b = b.merge(lag, on=KEY + ["bucket"], how="left")
            b["tv{}".format(k)] = b["tv{}".format(k)].fillna(0.0)
        tk = _shift(sel_money, KEY, "tickets", 1, "tk1")
        b = b.merge(tk, on=KEY + ["bucket"], how="left")
        b["tk1"] = b["tk1"].fillna(0.0)
        tv = np.column_stack([b["tv{}".format(k)].to_numpy(dtype="float64") for k in range(1, n + 1)])
        tvd = tv / idx
        fast, slow = _ewmas(tvd)
        b["s_log_l1"] = np.log1p(tvd[:, 0])
        b["s_log_l2"] = np.log1p(tvd[:, 1])
        b["s_log_l3"] = np.log1p(tvd[:, 2])
        b["s_log_ewma_fast"] = np.log1p(fast)
        b["s_log_ewma_slow"] = np.log1p(slow)
        b["s_any_l1"] = (tv[:, 0] > 0).astype(float)
        b["s_any_l6"] = (tv.sum(axis=1) > 0).astype(float)
        b["s_log_tickets_l1"] = np.log1p(b["tk1"].to_numpy(dtype="float64") / idx)
        # pool shares of the selection's own lagged money
        pool_money = money.groupby(["match_id", "pool_name", "bucket"], observed=True, as_index=False)[
            ["y", "tickets"]].sum()
        for k, name in ((1, "_pl1"), (2, "_pl2"), (3, "_pl3")):
            b = b.merge(_shift(pool_money, ["match_id", "pool_name"], "y", k, name),
                        on=["match_id", "pool_name", "bucket"], how="left")
            b[name] = b[name].fillna(0.0)
        b = b.merge(_shift(pool_money, ["match_id", "pool_name"], "tickets", 1, "_ptk1"),
                    on=["match_id", "pool_name", "bucket"], how="left")
        # average stake against its pool's in the last bucket: bigger tickets than the pool's usual
        sel_stake = _share(tv[:, 0], b["tk1"].to_numpy(dtype="float64"), np.nan)
        pool_stake = _share(b["_pl1"].to_numpy(dtype="float64"), b["_ptk1"].fillna(0.0).to_numpy(dtype="float64"), np.nan)
        rel = np.log(np.where((sel_stake > 0) & (pool_stake > 0), sel_stake / np.where(pool_stake > 0, pool_stake, 1.0), 1.0))
        b["s_rel_stake_l1"] = np.clip(np.nan_to_num(rel, nan=0.0), -4, 4)
        b = b.drop(columns=["_ptk1"])
        s1 = _share(tv[:, 0], b["_pl1"].to_numpy(dtype="float64"), np.nan)
        s2 = _share(tv[:, 1], b["_pl2"].to_numpy(dtype="float64"), np.nan)
        s3 = _share(tv[:, 2], b["_pl3"].to_numpy(dtype="float64"), np.nan)
        b["_s1"], b["_s2"], b["_s3"] = s1, s2, s3
        wsum = 0.6 * np.isfinite(s1) + 0.25 * np.isfinite(s2) + 0.15 * np.isfinite(s3)
        ew = 0.6 * np.nan_to_num(s1) + 0.25 * np.nan_to_num(s2) + 0.15 * np.nan_to_num(s3)
        b["_sew"] = np.where(wsum > 0, ew / np.maximum(wsum, 1e-9), np.nan)
        line_l1 = b.groupby(LKEY, observed=True)["tv1"].transform("sum").to_numpy(dtype="float64")
        b["s_share_line_l1"] = _share(tv[:, 0], line_l1, 0.5)
        return b

    def _match_frame(self, b: pd.DataFrame, money: pd.DataFrame, day: pd.Timestamp, idx: float = 1.0,
                     refs: Optional[dict] = None) -> pd.DataFrame:
        live = b[b["forecastable"]]
        if live.empty:
            return pd.DataFrame(columns=MKEY + ["y", "last5"])
        first = live.groupby(MKEY, observed=True).first()
        m = live.groupby(MKEY, observed=True).agg(y=("y", "sum"), last5=("tv1", "sum"),
                                                  n_pools=("pool_name", "nunique"),
                                                  n_lines=("line_id", "nunique")).reset_index()
        for c in ("league_code", "is_inplay", "match_minute", "mins_to_ko", "tg", "sup", "ctg", "csup",
                  "goal_split_fh", "corner_split_fh", "game_state", "ko_time", "minutes_since_goal",
                  "event_window", "clock_bin", "home_name", "away_name"):
            if c in first.columns:
                m[c] = first[c].to_numpy()
        for c in ("home_name", "away_name"):
            m[c] = m[c].astype("string").fillna("unknown") if c in m.columns else "unknown"
        mm = money.groupby(MKEY, observed=True, as_index=False)["y"].sum()
        for k in range(1, int(self.settings.features.lag_buckets) + 1):
            m = m.merge(_shift(mm, ["match_id"], "y", k, "ml{}".format(k)), on=MKEY, how="left")
            m["ml{}".format(k)] = m["ml{}".format(k)].fillna(0.0)
        l = np.column_stack([m["ml{}".format(k)].to_numpy(dtype="float64")
                             for k in range(1, int(self.settings.features.lag_buckets) + 1)]) / idx
        ew, _ = _ewmas(l)
        m["m_log_l1"] = np.log1p(l[:, 0])
        m["m_log_l2"] = np.log1p(l[:, 1])
        m["m_log_l3"] = np.log1p(l[:, 2])
        m["m_log_ewma"] = np.log1p(ew)
        m["m_any_l1"] = (l[:, 0] > 0).astype(float)
        m["m_trend"] = m["m_log_l1"] - m["m_log_l2"]
        # money the match took today (from 00:00 of the forecast day), up to the end of the previous bucket
        day0 = pd.Timestamp(day).normalize()
        today = mm[(mm["bucket"] >= day0)].sort_values(MKEY)
        today = today.assign(cum=today.groupby("match_id", observed=True)["y"].cumsum())
        m = m.merge(_shift(today, ["match_id"], "cum", 1, "_today"), on=MKEY, how="left")
        m = m.sort_values(MKEY).reset_index(drop=True)
        m["_today"] = m.groupby("match_id", observed=True)["_today"].ffill().fillna(0.0)
        m["m_log_today"] = np.log1p(m["_today"].to_numpy(dtype="float64") / idx)
        m["log_n_pools"] = np.log1p(m["n_pools"].to_numpy(dtype="float64"))
        m["log_n_lines"] = np.log1p(m["n_lines"].to_numpy(dtype="float64"))
        # against a normal match of the last four weeks (counted the same way), so a bigger board does not
        # read as a bigger match
        m["pools_rel"] = np.log(np.maximum(m["n_pools"].to_numpy(dtype="float64"), 1.0) / _ref(refs, "pools_per_match"))
        m["lines_rel"] = np.log(np.maximum(m["n_lines"].to_numpy(dtype="float64"), 1.0) / _ref(refs, "lines_per_match"))
        m["league_code"] = m["league_code"].astype("string").fillna("unknown")
        return m

    # ------------------------------------------------------------- events
    def _group_events(self, m: pd.DataFrame, events: Optional[pd.DataFrame]) -> pd.DataFrame:
        sc = score_asof(events, m[MKEY])
        m = m.merge(sc, on=MKEY, how="left")
        for c in ("home_goals", "away_goals", "home_corners", "away_corners", "home_reds", "away_reds"):
            m[c] = pd.to_numeric(m[c], errors="coerce").fillna(0).astype("int64")
        m["goals_so_far"] = (m["home_goals"] + m["away_goals"]).astype(float)
        m["abs_score_diff"] = (m["home_goals"] - m["away_goals"]).abs().astype(float)
        fs = self.settings.features
        taus = list(fs.goal_pulse_taus)
        ev = _incidents(events)
        if len(taus) >= 1:
            m["goal_p3"] = np.clip(_pulse(m, ev, (GOAL,), taus[0]), 0, 5)
        if len(taus) >= 2:
            m["goal_p10"] = np.clip(_pulse(m, ev, (GOAL,), taus[1]), 0, 5)
        m["red_p10"] = np.clip(_pulse(m, ev, (RED, YELLOW_RED), fs.red_pulse_tau), 0, 3)
        m["corner_p5"] = np.clip(_pulse(m, ev, (CORNER,), 5.0), 0, 6)
        m["yellow_p10"] = np.clip(_pulse(m, ev, (YELLOW,), 10.0), 0, 6)
        since = _num(m, "minutes_since_goal")
        m["since_goal"] = np.where(np.isfinite(since), np.clip(since, 0, 120), 120.0) / 120.0
        # Against the kick-off favourite: the sign of HKJC's SUP before kick-off (each pre-match bucket
        # its own, in play the last pre-match one - never a later price), neither side under 0.1.
        sgn = _kickoff_value(m, "sup")
        sgn = np.where(np.isfinite(sgn) & (np.abs(sgn) >= 0.1), np.sign(sgn), 0.0)
        m["fav_sign"] = sgn
        diff = (m["home_goals"] - m["away_goals"]).to_numpy(dtype="float64")
        m["fav_lead"] = np.clip(diff * sgn, -3, 3)
        m["dog_leading"] = ((diff * sgn) < 0).astype(float)
        hr, ar = m["home_reds"].to_numpy(dtype="float64"), m["away_reds"].to_numpy(dtype="float64")
        m["fav_reds"] = np.where(sgn > 0, hr, np.where(sgn < 0, ar, 0.0))
        m["dog_reds"] = np.where(sgn > 0, ar, np.where(sgn < 0, hr, 0.0))
        hc, ac = m["home_corners"].to_numpy(dtype="float64"), m["away_corners"].to_numpy(dtype="float64")
        m["corners_so_far"] = hc + ac
        m["corner_diff_fav"] = np.clip((hc - ac) * sgn, -15, 15)
        tau = taus[1] if len(taus) >= 2 else 10.0
        home_p, away_p = _pulse(m, ev, (GOAL,), tau, side=1), _pulse(m, ev, (GOAL,), tau, side=2)
        m["goal_p10_fav"] = np.clip(np.where(sgn > 0, home_p, np.where(sgn < 0, away_p, 0.0)), 0, 5)
        m["goal_p10_dog"] = np.clip(np.where(sgn > 0, away_p, np.where(sgn < 0, home_p, 0.0)), 0, 5)
        return m

    # ---------------------------------------------------------- lifecycle
    def _group_lifecycle(self, m: pd.DataFrame) -> pd.DataFrame:
        fs = self.settings.features
        inplay = m["is_inplay"].fillna(False).astype(bool).to_numpy() if "is_inplay" in m.columns \
            else np.zeros(len(m), dtype=bool)
        minute = np.clip(np.nan_to_num(_num(m, "match_minute"), nan=0.0), 0, 130)
        pre = np.clip(np.nan_to_num(_num(m, "mins_to_ko"), nan=360.0), 0, 720)
        gs = m["game_state"].astype("string").fillna("").str.lower() if "game_state" in m.columns \
            else pd.Series("", index=m.index)
        first = gs.str.contains("first").to_numpy()
        m["inplay"] = inplay.astype(float)
        m["halftime"] = (inplay & first & (np.abs(minute - 45.0) < 1e-6)).astype(float)
        m["stoppage"] = (inplay & (minute > 90)).astype(float)
        m["pre_ko_min"] = np.where(inplay, 0.0, pre)
        m["minute"] = np.where(inplay, minute, 0.0)
        for i, k in enumerate(fs.ko_knots):
            m["ko_h{}".format(i)] = (1 - inplay) * np.maximum(pre - k, 0.0) / 360.0
        for i, k in enumerate(fs.minute_knots):
            m["min_h{}".format(i)] = inplay * np.maximum(minute - k, 0.0) / 90.0
        phase = np.where(~inplay, "prematch",
                         np.where(m["halftime"].to_numpy() > 0, "half_time",
                                  np.where(gs.str.contains("second").to_numpy(), "second_half",
                                           np.where(gs.str.contains("xtra|extra|penalt").to_numpy(),
                                                    "extra_time", "first_half"))))
        m["phase"] = phase
        tg = np.nan_to_num(_num(m, "tg"), nan=2.6)
        sup = np.nan_to_num(_num(m, "sup"), nan=0.0)
        m["tg_full"] = np.where(inplay, m["goals_so_far"].to_numpy(dtype="float64") + tg, tg)
        m["abs_sup"] = np.abs(sup)
        m["balance"] = np.clip(np.abs(sup) / np.maximum(tg, 0.05), 0, 1)
        # how far the game has run from its script: expected full-match goals now minus at kick-off
        ko = _kickoff_value(m.assign(_tgf=m["tg_full"]), "_tgf")
        m["tg_shift"] = np.where(inplay & np.isfinite(ko), m["tg_full"].to_numpy(dtype="float64") - ko, 0.0)
        return m

    def _group_calendar(self, m: pd.DataFrame) -> pd.DataFrame:
        b = pd.to_datetime(m["bucket"])
        hour = (b.dt.hour + b.dt.minute / 60.0).to_numpy()
        dow = b.dt.dayofweek.to_numpy()
        m["weekend"] = (dow >= 5).astype(float)
        m["holiday"] = self.calendar.is_holiday(b).astype(float)
        m["evening"] = ((hour >= 19) & (hour < 24)).astype(float)
        m["hour_s1"], m["hour_c1"] = np.sin(2 * np.pi * hour / 24), np.cos(2 * np.pi * hour / 24)
        m["hour_s2"], m["hour_c2"] = np.sin(4 * np.pi * hour / 24), np.cos(4 * np.pi * hour / 24)
        m["dow_s"], m["dow_c"] = np.sin(2 * np.pi * dow / 7), np.cos(2 * np.pi * dow / 7)
        return m

    def _group_concurrency(self, m: pd.DataFrame, money: pd.DataFrame, idx: float = 1.0,
                           refs: Optional[dict] = None) -> pd.DataFrame:
        m["n_board"] = m.groupby("bucket", observed=True)["match_id"].transform("nunique").astype(float)
        m["n_live"] = m.groupby("bucket", observed=True)["inplay"].transform("sum").astype(float)
        normal = _ref(refs, "board_matches")
        m["board_rel"] = m["n_board"].to_numpy(dtype="float64") / normal
        m["live_rel"] = m["n_live"].to_numpy(dtype="float64") / normal
        board = money.groupby("bucket", observed=True)["y"].sum()
        prev = m["bucket"].map(board.rename(lambda x: x + STEP)).fillna(0.0).to_numpy(dtype="float64")
        m["log_board_l1"] = np.log1p(prev / idx)
        for k in (2, 3):
            lag = m["bucket"].map(board.rename(lambda x, k=k: x + k * STEP)).fillna(0.0).to_numpy(dtype="float64")
            m["log_board_l{}".format(k)] = np.log1p(lag / idx)
        m["log_board_today"] = 0.0
        if len(m):
            # the board's money from 00:00 to the end of the previous bucket (the last bucket with money)
            day0 = pd.to_datetime(m["bucket"]).min().normalize()
            today = board[board.index >= day0].sort_index()
            t = pd.to_datetime(today.index).to_numpy(dtype="datetime64[ns]")
            c = today.cumsum().to_numpy(dtype="float64")
            j = np.searchsorted(t, (pd.to_datetime(m["bucket"]) - STEP).to_numpy(dtype="datetime64[ns]"),
                                side="right") - 1
            done = np.where(j >= 0, c[np.clip(j, 0, None)] if len(c) else 0.0, 0.0)
            m["log_board_today"] = np.log1p(done / idx)
        l1 = m["ml1"].to_numpy(dtype="float64")
        m["match_share_board_l1"] = _share(l1, prev, 0.0)
        rank = m.groupby("bucket", observed=True)["ml1"].rank(ascending=False, method="average")
        m["match_rank_l1"] = (rank / m["n_board"].clip(lower=1.0)).to_numpy(dtype="float64")
        return m

    # --------------------------------------------------------------- price
    def _group_price(self, b: pd.DataFrame, market: Optional[pd.DataFrame]) -> pd.DataFrame:
        od = _num(b, "odds")
        od = np.where(np.isfinite(od) & (od > 1.0), od, np.nan)
        b["imp"] = np.where(np.isfinite(od), 1.0 / od, np.nan)
        b["log_odds"] = np.log(np.where(np.isfinite(od), od, 2.0))
        line_sum = b.groupby(LKEY, observed=True)["imp"].transform("sum").to_numpy(dtype="float64")
        b["book_margin"] = line_sum - 1.0
        p_true = _num(b, "p__hkjc_true")
        p_dem = _num(b, "p__demargin")
        p_ref = np.where(np.isfinite(p_true), p_true, p_dem)
        b["p_hkjc_true"] = p_true
        b["p_poisson"] = _num(b, "p__poisson")
        b["p_demargin"] = p_dem
        b["value_true"] = np.where(np.isfinite(p_ref) & np.isfinite(od), od * p_ref - 1.0, np.nan)
        cons = market_consensus(market, self.settings.panel.bucket_minutes) if market is not None else None
        mk = asof_before(b, cons, "mkt_odds", KEY) if cons is not None and not cons.empty else np.full(len(b), np.nan)
        mk = np.where(np.isfinite(mk) & (mk > 1.0), mk, np.nan)
        b["mkt_odds"] = mk
        mimp = np.where(np.isfinite(mk), 1.0 / mk, np.nan)
        b["_mimp"] = mimp
        msum = b.groupby(LKEY, observed=True)["_mimp"].transform("sum").to_numpy(dtype="float64")
        mcount = b.groupby(LKEY, observed=True)["_mimp"].transform("count").to_numpy(dtype="float64")
        lcount = b.groupby(LKEY, observed=True)["pool_id"].transform("size").to_numpy(dtype="float64")
        full = (mcount == lcount) & (msum > 0)
        b["p_market"] = np.where(full, mimp / np.where(msum > 0, msum, 1.0), np.nan)
        b["value_mkt"] = np.where(np.isfinite(b["p_market"]) & np.isfinite(od), od * b["p_market"] - 1.0, np.nan)
        b["hk_vs_mkt"] = np.where(np.isfinite(mk) & np.isfinite(od), od / mk - 1.0, np.nan)
        b["has_mkt"] = np.isfinite(mk).astype(float)
        # where HKJC's price sits in the market: against the best bookmaker, and between worst and best
        if cons is not None and not cons.empty and "mkt_max" in cons.columns:
            hi = asof_before(b, cons, "mkt_max", KEY)
            lo = asof_before(b, cons, "mkt_min", KEY)
        else:
            hi = lo = np.full(len(b), np.nan)
        ok = np.isfinite(hi) & (hi > 1.0) & np.isfinite(od)
        b["hk_vs_best"] = np.where(ok, od / np.where(ok, hi, 1.0) - 1.0, np.nan)
        span = hi - lo
        b["hk_pos"] = np.where(ok & np.isfinite(lo) & (span > 1e-9),
                               np.clip((od - lo) / np.where(span > 1e-9, span, 1.0), 0, 1), np.where(ok, 0.5, np.nan))
        # where it sits in its own history today: against its first price, and in its last hour's range
        f = pd.DataFrame({c: b[c].to_numpy() for c in KEY})
        f["bucket"], f["o"], f["_row"] = b["bucket"].to_numpy(), od, np.arange(len(b))
        f = f.sort_values(KEY + ["bucket"], kind="stable")
        g = f.groupby(KEY, sort=False, observed=True)["o"]
        first = g.transform("first").to_numpy(dtype="float64")
        n = int(round(60.0 / float(self.settings.panel.bucket_minutes)))
        hi60 = g.rolling(n, min_periods=1).max().reset_index(level=list(range(len(KEY))), drop=True)
        lo60 = g.rolling(n, min_periods=1).min().reset_index(level=list(range(len(KEY))), drop=True)
        o = f["o"].to_numpy(dtype="float64")
        h, l = hi60.reindex(f.index).to_numpy(dtype="float64"), lo60.reindex(f.index).to_numpy(dtype="float64")
        vs_first = np.where(np.isfinite(o) & np.isfinite(first), np.log(o / np.where(first > 1, first, 1.0)), np.nan)
        pos60 = np.where(np.isfinite(o) & (h - l > 1e-9), (o - l) / np.where(h - l > 1e-9, h - l, 1.0), 0.5)
        rows = f["_row"].to_numpy()
        b.loc[:, "odds_vs_first"] = np.nan
        b.loc[:, "odds_pos_60"] = 0.5
        b.iloc[rows, b.columns.get_loc("odds_vs_first")] = vs_first
        b.iloc[rows, b.columns.get_loc("odds_pos_60")] = np.clip(pos60, 0, 1)
        prev = b[KEY + ["bucket", "odds"]].rename(columns={"odds": "_o"})
        for k, name in ((1, "_o1"), (3, "_o3")):
            b = b.merge(prev.assign(bucket=prev["bucket"] + k * STEP).rename(columns={"_o": name}),
                        on=KEY + ["bucket"], how="left")
        o1 = np.where(np.isfinite(_num(b, "_o1")) & (_num(b, "_o1") > 1), _num(b, "_o1"), _num(b, "odds"))
        o3 = np.where(np.isfinite(_num(b, "_o3")) & (_num(b, "_o3") > 1), _num(b, "_o3"), o1)
        cur = _num(b, "odds")
        b["odds_move_5"] = np.where(np.isfinite(cur) & (cur > 1), np.log(np.maximum(cur, 1.001)) -
                                    np.log(np.maximum(o1, 1.001)), 0.0)
        b["odds_move_15"] = np.where(np.isfinite(cur) & (cur > 1), np.log(np.maximum(cur, 1.001)) -
                                     np.log(np.maximum(o3, 1.001)), 0.0)
        # The W06 panel's odds_age_min is measured at the END of the bucket (a line re-priced inside
        # T reads 0), which is inside the bucket being forecast. Age at the START of T is the end
        # age of T-1 plus one bucket; a line with no T-1 row was first priced within the last bucket.
        step_min = float(self.settings.panel.bucket_minutes)
        prev_age = b[KEY + ["bucket", "odds_age_min"]].rename(columns={"odds_age_min": "_age1"}) \
            if "odds_age_min" in b.columns else None
        if prev_age is not None:
            b = b.merge(prev_age.assign(bucket=prev_age["bucket"] + STEP), on=KEY + ["bucket"], how="left")
            age = np.where(np.isfinite(_num(b, "_age1")), _num(b, "_age1") + step_min, step_min / 2.0)
            b = b.drop(columns=["_age1"])
        else:
            age = np.full(len(b), step_min / 2.0)
        b["odds_age_start"] = age
        b["log_odds_age"] = np.log1p(np.clip(age, 0, 1440))
        return b.drop(columns=["_mimp", "_o1", "_o3"])

    # ------------------------------------------------------ line position
    @staticmethod
    def _line_positions(f: pd.DataFrame) -> pd.DataFrame:
        """Each row's line rank in its pool and bucket by price balance - 0 is the best line, the one
        priced closest to even, where the market centres - with that best line and the number of
        priced lines. A line needs two sides priced before the bucket started (a row's odds can be a
        price first posted inside the bucket); ties go to the lower line, so the same rows rank the
        same however they are ordered."""
        ok = _priced(f)
        odds = _num(f, "odds")
        imp = np.where(ok, 1.0 / np.where(ok, odds, 2.0), np.nan)
        keys = [f[c].to_numpy() for c in LKEY]
        s = pd.Series(imp)
        tot = s.groupby(keys).transform("sum").to_numpy()
        cnt = s.groupby(keys).transform("count").to_numpy()
        impn = pd.Series(np.where(tot > 0, imp / np.where(tot > 0, tot, 1.0), np.nan))
        bal = (impn.groupby(keys).transform("max") - impn.groupby(keys).transform("min")).to_numpy()
        priced = cnt >= 2
        lines = pd.DataFrame({c: f[c].to_numpy() for c in LKEY})
        lines["line"] = _num(f, "line")
        lines["_bal"] = np.where(priced, np.nan_to_num(bal, nan=1.0), np.inf)
        lines["_row"] = np.arange(len(f))
        u = lines.drop_duplicates(LKEY).sort_values(PKEY + ["_bal", "line", "line_id"], na_position="last")
        u["rank"] = u.groupby(PKEY, observed=True, sort=False).cumcount()
        u.loc[~np.isfinite(u["_bal"].to_numpy()), "rank"] = -1
        best = u[u["rank"] == 0].set_index(PKEY)[["line", "line_id"]]
        n_lines = u[u["rank"] >= 0].groupby(PKEY, observed=True).size()
        out = lines.merge(u[LKEY + ["rank"]], on=LKEY, how="left").sort_values("_row")
        pk = pd.MultiIndex.from_frame(out[PKEY])
        out["main_line"] = best["line"].reindex(pk).to_numpy()
        out["main_id"] = best["line_id"].reindex(pk).to_numpy()
        out["n_lines"] = n_lines.reindex(pk).fillna(0).to_numpy()
        out["line_balance"] = np.where(priced, np.nan_to_num(bal, nan=1.0), 1.0)
        off = out["line"].to_numpy(dtype="float64") - out["main_line"].to_numpy(dtype="float64")
        out["line_offset"] = np.where(np.isfinite(off), np.clip(off, -8, 8), 0.0)
        out["slot"] = np.round(out["line_offset"].to_numpy() * 4.0) / 4.0
        out["impn"] = impn.to_numpy()
        return out.reset_index(drop=True)

    def _group_line_position(self, b: pd.DataFrame, tail: Optional[pd.DataFrame] = None,
                             idx: float = 1.0, refs: Optional[dict] = None) -> pd.DataFrame:
        pos = self._line_positions(b)
        b["rank"] = pos["rank"].fillna(-1).astype(int).to_numpy()
        b["line_balance"] = pos["line_balance"].to_numpy()
        b["rank_0"] = (b["rank"] == 0).astype(float)
        b["rank_1"] = (b["rank"] == 1).astype(float)
        b["rank_2p"] = (b["rank"] >= 2).astype(float)
        b["line_offset"] = pos["line_offset"].to_numpy()
        b["abs_line_offset"] = np.abs(b["line_offset"])
        b["_slot"] = pos["slot"].to_numpy()
        b["_impn"] = pos["impn"].to_numpy()
        b["_main_id"] = pos["main_id"].to_numpy()
        main = b.loc[b["rank"] == 0, PKEY + ["_main_id"]].drop_duplicates(PKEY)
        prev_main = main.assign(bucket=main["bucket"] + STEP).rename(columns={"_main_id": "_prev_main"})
        b = b.merge(prev_main, on=PKEY, how="left")
        b["main_moved"] = (b["_main_id"].notna() & b["_prev_main"].notna() &
                           (b["_main_id"] != b["_prev_main"])).astype(float)
        b["n_lines_pool"] = np.log1p(pos["n_lines"].to_numpy(dtype="float64"))
        b["lines_pool_rel"] = np.log(np.maximum(pos["n_lines"].to_numpy(dtype="float64"), 1.0) /
                                     _ref(refs, "lines_per_pool"))
        first = b.loc[b["forecastable"]].groupby(KEY, observed=True)["bucket"].min().rename("_first").reset_index()
        b = b.merge(first, on=KEY, how="left")
        age = (b["bucket"] - b["_first"]).dt.total_seconds().to_numpy() / 60.0
        b["line_age"] = np.where(np.isfinite(age), np.clip(age, 0, 600), 0.0) / 600.0

        # Money by slot - offset from the best line and side - whatever line held it, across midnight.
        # When the market moves (2.5 / 3.5 becomes 1.5 / 2.5) the money follows the slot.
        slot_key = ["match_id", "pool_name", "_slot", "side"]
        slots = [b[slot_key + ["bucket", "y"]]]
        present = [b.loc[_priced(b), KEY + ["bucket"]]]
        if tail is not None and not tail.empty:
            tp = self._line_positions(tail)
            slots.append(pd.DataFrame({"match_id": tail["match_id"].to_numpy(), "pool_name": tail["pool_name"].to_numpy(),
                                       "_slot": tp["slot"].to_numpy(), "side": tail["side"].to_numpy(),
                                       "bucket": tail["bucket"].to_numpy(), "y": tail["y"].to_numpy()}))
            present.append(tail.loc[_priced(tail), KEY + ["bucket"]])
        sm = pd.concat(slots, ignore_index=True).groupby(slot_key + ["bucket"], observed=True, as_index=False)["y"].sum()
        for k in (1, 2, 3):
            b = b.merge(_shift(sm, slot_key, "y", k, "_pt{}".format(k)), on=slot_key + ["bucket"], how="left")
            b["_pt{}".format(k)] = b["_pt{}".format(k)].fillna(0.0)
        sl = sm.groupby(["match_id", "pool_name", "_slot", "bucket"], observed=True, as_index=False)["y"].sum()
        b = b.merge(_shift(sl, ["match_id", "pool_name", "_slot"], "y", 1, "_ptl1"),
                    on=["match_id", "pool_name", "_slot", "bucket"], how="left")
        pt = np.column_stack([b["_pt{}".format(k)].to_numpy(dtype="float64") for k in (1, 2, 3)])
        pool_l = np.column_stack([b["_pl{}".format(k)].to_numpy(dtype="float64") for k in (1, 2, 3)])
        n_in_pool = b.groupby(PKEY, observed=True)["forecastable"].transform("sum").to_numpy(dtype="float64")
        flat = 1.0 / np.maximum(n_in_pool, 1.0)
        pshare = np.where(pool_l > 0, pt / np.maximum(pool_l, 1e-12), flat[:, None])
        b["pos_tv1"] = pt[:, 0]                                  # HK$: the slot baseline
        b["pos_log_l1"] = np.log1p(pt[:, 0] / idx)
        b["pos_share_l1"] = pshare[:, 0]
        b["pos_share_l2"] = pshare[:, 1]
        prev = pd.concat(present, ignore_index=True).drop_duplicates()
        prev = prev.assign(bucket=prev["bucket"] + STEP, _was=1.0)
        b = b.merge(prev, on=KEY + ["bucket"], how="left")
        b["line_new"] = 1.0 - b["_was"].fillna(0.0).to_numpy(dtype="float64")

        # shares of the pool, filled flat where the pool took nothing
        b["s_share_pool_l1"] = np.where(np.isfinite(b["_s1"]), b["_s1"], flat)
        b["s_share_pool_l2"] = np.where(np.isfinite(b["_s2"]), b["_s2"], flat)
        b["s_share_pool_ewma"] = np.where(np.isfinite(b["_sew"]), b["_sew"], flat)
        # A line the market has just opened, with no money of its own yet, takes its slot's. One that opened
        # during the last bucket already has some, and its own money is the better guide: on the synthetic
        # world those rows were half the new lines, and the slot's money made their deviance 70% larger.
        new = (b["line_new"].to_numpy() > 0) & ~(b["tv1"].to_numpy(dtype="float64") > 0)
        if new.any():
            ptd = pt / idx
            fast, slow = _ewmas(ptd)
            for k, col in enumerate(("s_log_l1", "s_log_l2", "s_log_l3")):
                b.loc[new, col] = np.log1p(ptd[new, k])
            b.loc[new, "s_log_ewma_fast"] = np.log1p(fast[new])
            b.loc[new, "s_log_ewma_slow"] = np.log1p(slow[new])
            b.loc[new, "s_any_l1"] = (pt[new, 0] > 0).astype(float)
            b.loc[new, "s_any_l6"] = (pt[new].sum(axis=1) > 0).astype(float)
            b.loc[new, "s_share_pool_l1"] = pshare[new, 0]
            b.loc[new, "s_share_pool_l2"] = pshare[new, 1]
            b.loc[new, "s_share_pool_ewma"] = (0.6 * pshare[new, 0] + 0.25 * pshare[new, 1] + 0.15 * pshare[new, 2])
            ptl = b["_ptl1"].fillna(0.0).to_numpy(dtype="float64")
            b.loc[new, "s_share_line_l1"] = np.where(ptl[new] > 0, pt[new, 0] / np.maximum(ptl[new], 1e-12), 0.5)
        # favourite of its line: the shorter price
        b["is_fav"] = (b["_impn"] >= b.groupby(LKEY, observed=True)["_impn"].transform("max") - 1e-12).astype(float)
        return b.drop(columns=["_main_id", "_prev_main", "_first", "_pt1", "_pt2", "_pt3", "_ptl1", "_was",
                               "_impn", "_slot"])

    def _group_customer(self, b: pd.DataFrame, idx: float = 1.0) -> pd.DataFrame:
        """Customer insight for the belief model: where the money went against where the price says
        it should go (weight of money), and how much money that is. Each side's share of its line's
        money is shrunk toward its price-implied share by features.wom_prior, so a line with little
        or no money reads neutral."""
        prior = float(self.settings.features.wom_prior) * idx
        imp = _num(b, "imp")
        bm = _num(b, "book_margin")
        p = np.where(np.isfinite(imp), imp / np.where(bm > -1, bm + 1.0, 1.0), np.nan)
        keys = [b[c].to_numpy() for c in LKEY]
        n = int(self.settings.features.lag_buckets)
        tv = np.column_stack([b["tv{}".format(k)].to_numpy(dtype="float64") for k in range(1, n + 1)])
        for name, s in (("wom_l1", tv[:, 0]), ("wom_l6", tv.sum(axis=1))):
            line = pd.Series(s).groupby(keys).transform("sum").to_numpy()
            share = (s + prior * np.nan_to_num(p, nan=0.5)) / (line + prior)
            b[name] = np.where(np.isfinite(p), np.clip(_logit(share) - _logit(p), -3, 3), 0.0)
            if name == "wom_l6":
                b["line_money_l6"] = np.log1p(line / idx)
        return b

    @staticmethod
    def _side_of_favourite(b: pd.DataFrame) -> pd.DataFrame:
        """side_fav_team: the handicap / 1X2 selection is the kick-off favourite team's."""
        fam = b["family"].astype(str).to_numpy()
        side = b["side"].astype(str).to_numpy()
        sgn = np.nan_to_num(_num(b, "fav_sign", 0.0))
        team_market = np.isin(fam, ["goal_hdc", "goal_1x2", "corner_hdc"])
        b["side_fav_team"] = (team_market & (((side == "H") & (sgn > 0)) | ((side == "A") & (sgn < 0)))).astype(float)
        return b

    def _group_bet_type(self, b: pd.DataFrame) -> pd.DataFrame:
        fam = b["family"].astype(str).to_numpy()
        for f in C.FAMILIES:
            b["fam_" + f] = (fam == f).astype(float)
        seg = b["segment"].astype(str).to_numpy()
        b["first_half"] = (seg == "FH").astype(float)
        b["extra_time"] = (seg == "ET").astype(float)
        side = b["side"].astype(str).to_numpy()
        b["side_home_over"] = (side == "H").astype(float)
        b["side_draw"] = (side == "D").astype(float)
        return b

    def _pool_frame(self, b: pd.DataFrame, m: pd.DataFrame, money: pd.DataFrame, idx: float = 1.0,
                    refs: Optional[dict] = None) -> pd.DataFrame:
        live = b[b["forecastable"]]
        if live.empty:
            return pd.DataFrame(columns=PKEY + ["y", "exposure", "last5"])
        p = live.groupby(PKEY, observed=True).agg(
            y=("y", "sum"), last5=("tv1", "sum"), p_n_lines=("line_id", "nunique"),
            p_balance=("line_balance", "min"), family=("family", "first"), segment=("segment", "first"),
            league_code=("league_code", "first")).reset_index()
        main_margin = live[live["rank"] == 0].groupby(PKEY, observed=True)["book_margin"].first()
        p = p.merge(main_margin.rename("p_margin").reset_index(), on=PKEY, how="left")
        p["p_lines_rel"] = np.log(np.maximum(p["p_n_lines"].to_numpy(dtype="float64"), 1.0) /
                                  _ref(refs, "lines_per_pool"))
        p["p_n_lines"] = np.log1p(p["p_n_lines"].to_numpy(dtype="float64"))
        carry = ["y", "ml1", "ml2", "home_name", "away_name"] + [c for c in self.STATE_COLS if c in m.columns]
        p = p.merge(m[MKEY + [c for c in dict.fromkeys(carry) if c in m.columns]].rename(columns={"y": "exposure"}),
                    on=MKEY, how="left")
        # against the bet type's usual margin and share of the market (trailing references)
        rkey = p["family"].astype(str).to_numpy() + "|" + ref_phase(p["phase"].to_numpy())
        p["p_margin_rel"] = pd.to_numeric(p["p_margin"], errors="coerce").to_numpy(dtype="float64") - \
            _ref_map(refs, "margin", rkey)
        p["p_ref_share"] = np.log(_ref_map(refs, "share", rkey) + 1e-4)
        pm = money.groupby(PKEY, observed=True, as_index=False)["y"].sum()
        mm = money.groupby(MKEY, observed=True, as_index=False)["y"].sum()
        for k, name in ((1, "_p1"), (2, "_p2"), (3, "_p3")):
            p = p.merge(_shift(pm, ["match_id", "pool_name"], "y", k, name), on=PKEY, how="left")
            p[name] = p[name].fillna(0.0)
        p = p.merge(_shift(mm, ["match_id"], "y", 3, "ml3x"), on=MKEY, how="left")
        n_pools = p.groupby(MKEY, observed=True)["pool_name"].transform("size").to_numpy(dtype="float64")
        flat = 1.0 / np.maximum(n_pools, 1.0)
        s1 = _share(p["_p1"].to_numpy(dtype="float64"), p["ml1"].to_numpy(dtype="float64"), np.nan)
        s2 = _share(p["_p2"].to_numpy(dtype="float64"), p["ml2"].to_numpy(dtype="float64"), np.nan)
        s3 = _share(p["_p3"].to_numpy(dtype="float64"), p["ml3x"].fillna(0.0).to_numpy(dtype="float64"), np.nan)
        p["p_share_l1"] = np.where(np.isfinite(s1), s1, flat)
        p["p_share_l2"] = np.where(np.isfinite(s2), s2, flat)
        wsum = 0.6 * np.isfinite(s1) + 0.25 * np.isfinite(s2) + 0.15 * np.isfinite(s3)
        ew = 0.6 * np.nan_to_num(s1) + 0.25 * np.nan_to_num(s2) + 0.15 * np.nan_to_num(s3)
        p["p_share_ewma"] = np.where(wsum > 0, ew / np.maximum(wsum, 1e-9), flat)
        p["p_any_l1"] = (p["_p1"] > 0).astype(float)
        p["p_log_l1"] = np.log1p(p["_p1"].to_numpy(dtype="float64") / idx)
        fam = p["family"].astype(str).to_numpy()
        ip = p["inplay"].fillna(0.0).to_numpy(dtype="float64")
        for f in C.FAMILIES:
            p["fam_" + f] = (fam == f).astype(float)
            p["fam_{}_ip".format(f)] = ((fam == f) & (ip > 0)).astype(float)
        seg = p["segment"].astype(str).to_numpy()
        p["first_half"] = (seg == "FH").astype(float)
        p["extra_time"] = (seg == "ET").astype(float)
        minute = p["minute"].fillna(0.0).to_numpy(dtype="float64")
        p["fh_to_ht"] = np.where(seg == "FH", np.where(ip > 0, np.clip((45.0 - minute) / 45.0, 0, 1), 1.0), 1.0)
        p["pool_key"] = p["pool_name"].astype(str) + "|" + p["phase"].astype(str)
        p["family_phase"] = p["family"].astype(str) + "|" + p["phase"].astype(str)
        return p.drop(columns=["_p1", "_p2", "_p3", "ml3x"])

    @staticmethod
    def _match_price_level(m: pd.DataFrame, p: pd.DataFrame, refs: Optional[dict] = None) -> pd.DataFrame:
        """m_margin: the book margin of the match's best lines, weighted by where its money has been
        going - how dear the match is to bet on overall (H21); m_margin_rel: that minus the market's
        usual margin in the same phase, each bet type weighted by its usual share of the money."""
        if m.empty:
            return m
        if p is None or p.empty or "p_margin" not in p.columns:
            m["m_margin"], m["m_margin_rel"] = np.nan, np.nan
            return m
        margins, shares = (refs or {}).get("margin") or {}, (refs or {}).get("share") or {}
        usual = {}
        for ph in ("prematch", "inplay"):
            keys = [k for k in margins if k.endswith("|" + ph) and shares.get(k, 0) > 0]
            if keys:
                usual[ph] = sum(margins[k] * shares[k] for k in keys) / sum(shares[k] for k in keys)
        m = FeatureEngineer._match_margin(m, p).copy()
        ph = ref_phase(m["phase"].to_numpy()) if "phase" in m.columns else np.full(len(m), "prematch")
        ref = np.array([usual.get(x, np.nan) for x in ph], dtype="float64")
        m["m_margin_rel"] = pd.to_numeric(m["m_margin"], errors="coerce").to_numpy(dtype="float64") - ref
        return m

    @staticmethod
    def _match_margin(m: pd.DataFrame, p: pd.DataFrame) -> pd.DataFrame:
        pm = pd.to_numeric(p["p_margin"], errors="coerce").to_numpy(dtype="float64")
        w = np.clip(pd.to_numeric(p["p_share_ewma"], errors="coerce").fillna(0.0).to_numpy(dtype="float64"), 0, 1) + 1e-3
        ok = np.isfinite(pm)
        agg = pd.DataFrame({"match_id": p["match_id"].to_numpy(), "bucket": p["bucket"].to_numpy(),
                            "_wm": np.where(ok, w * np.nan_to_num(pm), 0.0), "_w": np.where(ok, w, 0.0)})
        agg = agg.groupby(MKEY, observed=True, as_index=False)[["_wm", "_w"]].sum()
        agg["m_margin"] = np.where(agg["_w"] > 0, agg["_wm"] / np.maximum(agg["_w"], 1e-12), np.nan)
        return m.drop(columns=["m_margin"], errors="ignore").merge(agg[MKEY + ["m_margin"]], on=MKEY, how="left")

    # ------------------------------------------------------------ outcome
    @staticmethod
    def _outcome(b: pd.DataFrame) -> pd.DataFrame:
        """Signed settlement {-1,-.5,0,.5,1} read back from the money actually paid."""
        y = _num(b, "y_frac")
        odds = _num(b, "avg_odds")
        odds = np.where(np.isfinite(odds) & (odds > 1.0), odds, _num(b, "odds"))
        settled = b["settled"].fillna(False).astype(bool).to_numpy() if "settled" in b.columns \
            else np.zeros(len(b), dtype=bool)
        ok = settled & np.isfinite(y) & np.isfinite(odds) & (odds > 1.0)
        out = np.full(len(b), np.nan)
        if ok.any():
            o = odds[ok]
            paid = y[ok] * o
            cand = np.stack([o, 0.5 * o + 0.5, np.ones_like(o), 0.5 * np.ones_like(o), np.zeros_like(o)], axis=1)
            gap = np.abs(cand - paid[:, None])
            pick = gap.argmin(axis=1)
            best = gap[np.arange(len(pick)), pick]
            tol = np.maximum(0.02, 0.125 * (o - 1.0))
            res = np.where(best <= tol, np.take([1.0, 0.5, 0.0, -0.5, -1.0], pick), np.nan)
            out[ok] = res
        out = np.where(out == 0.0, np.nan, out)      # pushes carry no information on p
        b["outcome"] = out
        b["_yf"] = np.where(b["forecastable"].to_numpy(), b["y"].to_numpy(dtype="float64"), 0.0)
        b["pool_y"] = b.groupby(PKEY, observed=True)["_yf"].transform("sum").to_numpy(dtype="float64")
        b["inplay"] = b["inplay"].fillna(0.0)
        return b.drop(columns=["_yf"])

    # ------------------------------------------------------------- finish
    def _finish(self, frame: pd.DataFrame, specs: Sequence[C.FeatureSpec], encode: str) -> pd.DataFrame:
        cols: Dict[str, np.ndarray] = {}
        enc = self._encode(frame, encode)
        for s in specs:
            if s.name in enc:
                v = enc[s.name]
            elif s.name in frame.columns:
                v = pd.to_numeric(frame[s.name], errors="coerce").to_numpy(dtype="float64")
            else:
                v = np.full(len(frame), s.fill, dtype="float64")
            v = np.where(np.isfinite(v), v, s.fill)
            if s.lo is not None or s.hi is not None:
                v = np.clip(v, s.lo, s.hi)
            cols[s.name] = v.astype("float32")
        return pd.DataFrame(cols)

    def _encode(self, frame: pd.DataFrame, which: str) -> Dict[str, np.ndarray]:
        out: Dict[str, np.ndarray] = {}
        if which in ("league", "both") and self.encoders.league is not None and "league_code" in frame.columns:
            lv, known = self.encoders.league.transform(frame)
            out["league_level"], out["league_known"] = lv, known
        team = getattr(self.encoders, "team", None)
        if team is not None and "home_name" in frame.columns and "away_name" in frame.columns:
            lg = frame[["league_code"]] if "league_code" in frame.columns else pd.DataFrame(index=frame.index)
            h, hk = team.transform(lg.assign(team=frame["home_name"].astype("string").fillna("unknown")))
            a, ak = team.transform(lg.assign(team=frame["away_name"].astype("string").fillna("unknown")))
            out["team_hi"], out["team_lo"], out["team_known"] = np.maximum(h, a), np.minimum(h, a), np.minimum(hk, ak)
        if {"match_id", "bucket"} <= set(frame.columns):
            # the board as a set of matches (the old NN's match attention): expected popularity - the two
            # teams' levels, else the league's - against everything else on the board at the same time
            pop = 0.5 * (out["team_hi"] + out["team_lo"]) if "team_hi" in out else out.get("league_level")
            if pop is not None:
                out.update(_board_popularity(frame, pop))
        if which in ("pool", "both") and self.encoders.pool is not None:
            if "pool_key" in frame.columns:
                f = frame
            else:
                phase = frame["phase"].astype(str) if "phase" in frame.columns \
                    else pd.Series("prematch", index=frame.index)
                f = pd.DataFrame({"pool_key": frame["pool_name"].astype(str) + "|" + phase,
                                  "family_phase": frame["family"].astype(str) + "|" + phase}, index=frame.index)
            lv, _ = self.encoders.pool.transform(f)
            out["pool_level"] = lv
        return out

    @staticmethod
    def _kinds(specs: Sequence[C.FeatureSpec]) -> Dict[str, str]:
        return {s.name: s.kind for s in specs}

    @staticmethod
    def _cuts(frame: pd.DataFrame) -> pd.DataFrame:
        def lab(col, default):
            if col not in frame.columns:
                return default
            return frame[col].astype("string").fillna("unknown").to_numpy(dtype=object)
        out = pd.DataFrame(index=frame.index)
        out["phase"] = lab("phase", "unknown")
        out["pool"] = lab("pool_name", "match")
        out["family"] = lab("family", "match")
        out["league"] = lab("league_code", "unknown")
        out["event_window"] = lab("event_window", "unknown")
        out["clock_bin"] = lab("clock_bin", "unknown")
        out["day"] = pd.to_datetime(frame["bucket"]).dt.normalize().astype("datetime64[ns]").to_numpy()
        return out.reset_index(drop=True)

    # --------------------------------------------------------- encoders
    def fit_encoders(self, days: Sequence[DayData]) -> EncoderState:
        from .encoders import fit_encoders
        fs = self.settings.features
        self.encoders = fit_encoders([d.match for d in days if not d.empty],
                                     [d.pool for d in days if not d.empty], fs.league_prior, fs.pool_prior,
                                     fs.team_prior)
        return self.encoders

    def fit_encoders_from(self, store, days: Sequence, cutoff=None) -> EncoderState:
        """fit_encoders over many days, one day in memory at a time: the encoders read four columns of
        the match and pool frames, not a season of selection rows.

        With ``cutoff`` (the first day the model is chosen or scored on) the encoders also read every
        cached day in the features.encoder_history_days before it, each day's evidence halving every
        encoder_half_life_days: a league or bet type earns its own level from the day it has data,
        and one that has not played for months drifts back toward its parent."""
        from .encoders import fit_encoders
        fs = self.settings.features
        days = sorted({pd.Timestamp(d).normalize() for d in days})
        if cutoff is not None:
            cutoff = pd.Timestamp(cutoff).normalize()
            lo = cutoff - pd.Timedelta(days=int(fs.encoder_history_days))
            days = sorted({d for d in days if d < cutoff} |
                          {d for d in getattr(store, "available_days", lambda: [])() if lo <= d < cutoff})
        ref = cutoff if cutoff is not None else (days[-1] + pd.Timedelta(days=1) if days else None)
        half = float(fs.encoder_half_life_days)
        match, pool = [], []
        for d in days:
            dd = store.get(d)
            if dd.empty:
                continue
            w = 0.5 ** (max((ref - d).days, 0) / half) if (half > 0 and ref is not None) else 1.0
            match.append(dd.match[[c for c in ("league_code", "y", "market_index", "home_name", "away_name")
                                   if c in dd.match.columns]].assign(_w=w))
            pool.append(dd.pool[[c for c in ("pool_key", "family_phase", "y", "exposure") if c in dd.pool.columns]]
                        .assign(_w=w))
        self.encoders = fit_encoders(match, pool, fs.league_prior, fs.pool_prior, fs.team_prior)
        if days:
            logger.info("encoders fitted on %d day(s) %s..%s (half-life %s days)", len(days), days[0].date(),
                        days[-1].date(), fs.encoder_half_life_days)
        return self.encoders
