"""
Step 00 - selftest (run first on any new machine, and before every package)

The whole chain on a generated world whose truth is known: data check, panel,
features, pricer vs the legacy poisson_betting, turnover and probability
training, train/serve parity (the leak test), a live sweep + focus refresh,
the monitor, and an unseen league and pool code. No Raw_Data, no SQL.

    python scripts/s00_selftest.py              about a minute once the world exists
    python scripts/s00_selftest.py --fresh      regenerate the world first

Exit code 0 only if nothing FAILed. Same as: python -m algoe selftest
"""
from _algoe import run

if __name__ == "__main__":
    run("selftest")
