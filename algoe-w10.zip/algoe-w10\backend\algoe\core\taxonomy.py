"""
Pool Taxonomy

Every model feature and every pricing rule reads a pool through what it IS
(domain, market, segment), never through its code. That is what lets a bet
type that did not exist in the training window still get a forecast and a
price the day it appears.

Resolution order for a pool code:

    1. overrides file   (settings.paths.pool_overrides, JSON)  - desk decisions
    2. known table      (below)                                - verified HKJC pools
    3. spelling rules   (_infer)                               - anything new

A code resolved by rule is marked ``inferred=True`` and logged once at
WARNING, so an unfamiliar pool is never silently priced as something it is
not. A code the rules cannot place becomes market "other": it still counts
in the match's turnover, it is simply not priced or optimised.

HKJC spells the same pool several ways (HILO / HIL, FHLO / FHL, CHLO / CHL,
ETHILO / EHL ...); aliases fold those onto one spec.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

import json
import re
import threading
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Dict, Optional, Tuple

from .logging import get_logger

logger = get_logger(__name__)

SEGMENTS = ("FT", "FH", "ET")
DOMAINS = ("goal", "corner", "other")
MARKETS = ("total", "handicap", "three_way", "handicap_3w", "correct_score",
           "exact_total", "odd_even", "half_full", "next_score", "all_up", "other")
# Markets our Poisson book can price from theta.
PRICEABLE = ("total", "handicap", "three_way", "handicap_3w", "correct_score",
             "exact_total", "odd_even", "half_full")
# Two-way Asian markets: the ones the optimiser searches theta for by default.
ASIAN = ("total", "handicap")


@dataclass(frozen=True)
class PoolSpec:
    code: str
    segment: str            # FT | FH | ET
    domain: str             # goal | corner | other
    market: str             # see MARKETS
    has_line: bool
    inferred: bool = False

    @property
    def family(self) -> str:
        """Coarse group used as a model feature and as a shrinkage parent."""
        if self.market == "all_up":
            return "all_up"
        if self.domain == "corner":
            return "corner_total" if self.market == "total" else (
                "corner_hdc" if self.market == "handicap" else "corner_other")
        if self.domain == "goal":
            return {"total": "goal_total", "handicap": "goal_hdc", "three_way": "goal_1x2",
                    "handicap_3w": "goal_1x2", "correct_score": "goal_exact",
                    "exact_total": "goal_exact", "odd_even": "goal_other",
                    "half_full": "goal_exact", "next_score": "goal_other"}.get(self.market, "goal_other")
        return "other"

    @property
    def priceable(self) -> bool:
        return self.domain in ("goal", "corner") and self.market in PRICEABLE

    @property
    def asian(self) -> bool:
        return self.market in ASIAN

    @property
    def theta_domain(self) -> str:
        """Which theta pair prices it: goal | corner | goal_fh | corner_fh (ET -> FT pair)."""
        base = "corner" if self.domain == "corner" else "goal"
        return base + ("_fh" if self.segment == "FH" else "")

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(family=self.family, priceable=self.priceable, theta_domain=self.theta_domain)
        return d


def _spec(code, segment, domain, market, has_line):
    return PoolSpec(code=code, segment=segment, domain=domain, market=market, has_line=has_line)


KNOWN: Dict[str, PoolSpec] = {s.code: s for s in (
    _spec("HAD", "FT", "goal", "three_way", False),
    _spec("FHAD", "FH", "goal", "three_way", False),
    _spec("HHAD", "FT", "goal", "handicap_3w", True),
    _spec("HDC", "FT", "goal", "handicap", True),
    _spec("FHDC", "FH", "goal", "handicap", True),
    _spec("HILO", "FT", "goal", "total", True),
    _spec("FHLO", "FH", "goal", "total", True),
    _spec("CHLO", "FT", "corner", "total", True),
    _spec("CHDC", "FT", "corner", "handicap", True),
    _spec("FCHLO", "FH", "corner", "total", True),
    _spec("FCHDC", "FH", "corner", "handicap", True),
    _spec("CRS", "FT", "goal", "correct_score", False),
    _spec("FCRS", "FH", "goal", "correct_score", False),
    _spec("TTG", "FT", "goal", "exact_total", False),
    _spec("OOE", "FT", "goal", "odd_even", False),
    _spec("HFT", "FT", "goal", "half_full", False),
    _spec("FTS", "FT", "goal", "next_score", False),
    _spec("NTS", "FT", "goal", "next_score", False),
    _spec("ETHAD", "ET", "goal", "three_way", False),
    _spec("ETHILO", "ET", "goal", "total", True),
    _spec("ETHDC", "ET", "goal", "handicap", True),
    _spec("ETCHLO", "ET", "corner", "total", True),
    _spec("ETCHDC", "ET", "corner", "handicap", True),
    _spec("ETCRS", "ET", "goal", "correct_score", False),
    _spec("ETTTG", "ET", "goal", "exact_total", False),
    _spec("ETHHAD", "ET", "goal", "handicap_3w", True),
    _spec("ETNTS", "ET", "goal", "next_score", False),
    _spec("SGA", "FT", "other", "all_up", False),
)}
# Verified HKJC pools no Poisson book prices: they still carry money.
for _code in ("TQL", "TPS", "FGS", "CHP", "GPF", "GPW", "MSPC", "TSPC", "TNC", "JKC", "DHCP",
              "NGS", "LGS", "AGS", "ETNGS", "ETLGS", "ETAGS", "TESTBTG"):
    KNOWN[_code] = _spec(_code, "ET" if _code.startswith("ET") else "FT", "other", "other", False)

ALIASES = {
    "HIL": "HILO", "FHL": "FHLO", "FHILO": "FHLO", "CHL": "CHLO", "FCHL": "FCHLO",
    "HHA": "HHAD", "FHA": "FHAD", "FCS": "FCRS", "ECS": "ETCRS", "EHL": "ETHILO",
    "ECH": "ETCHLO", "EHA": "ETHAD", "ENT": "ETNTS", "HFTS": "HFT",
}
# NTS1..NTS9 / SGA4..SGA12 are numbered instances of one market.
_NUMBERED = re.compile(r"^(NTS|ETNTS|SGA)\d+$")


def _infer(code: str) -> PoolSpec:
    """Place an unseen pool code by its spelling."""
    c = code
    segment, rest = "FT", c
    if c.startswith("ET"):
        segment, rest = "ET", c[2:]
    elif c.startswith("FH"):
        segment, rest = "FH", c[2:]
    elif c.startswith("FC"):                         # FCHLO, FCHDC, FCRS
        segment, rest = "FH", c[1:]
    domain = "corner" if rest.startswith("CH") or rest.startswith("CN") else "goal"
    body = rest[2:] if domain == "corner" else rest
    if "SGA" in c or "ALLUP" in c:
        return PoolSpec(code, "FT", "other", "all_up", False, inferred=True)
    if body.endswith("LO") or body.endswith("HILO") or body in ("HL", "OU"):
        market, has_line = "total", True
    elif "HHAD" in body or body.startswith("HHA"):
        market, has_line = "handicap_3w", True
    elif body.endswith("DC") or "HDC" in body or body.startswith("AH"):
        market, has_line = "handicap", True
    elif body.endswith("HAD") or body in ("AD", "1X2"):
        market, has_line = "three_way", False
    elif "CRS" in body or body.endswith("RS"):
        market, has_line = "correct_score", False
    elif "TTG" in body or body.endswith("TG"):
        market, has_line = "exact_total", False
    elif "OOE" in body or body.endswith("OE"):
        market, has_line = "odd_even", False
    elif "HFT" in body:
        market, has_line = "half_full", False
    elif "NTS" in body or "FTS" in body or "TS" == body[-2:]:
        market, has_line = "next_score", False
    else:
        return PoolSpec(code, segment, "other", "other", False, inferred=True)
    return PoolSpec(code, segment, domain, market, has_line, inferred=True)


class PoolTaxonomy:
    """Resolve pool codes to specs, learning new codes as they appear."""

    def __init__(self, overrides_path: Optional[str] = None):
        self._lock = threading.Lock()
        self._specs: Dict[str, PoolSpec] = dict(KNOWN)
        self._seen_inferred: Dict[str, PoolSpec] = {}
        self._overrides_path = overrides_path
        if overrides_path:
            self.load_overrides(overrides_path)

    def load_overrides(self, path: str) -> int:
        p = Path(path)
        if not p.exists():
            return 0
        try:
            payload = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("pool overrides %s unreadable: %s", p, exc)
            return 0
        n = 0
        for code, spec in (payload.get("pools") or {}).items():
            code = str(code).strip().upper()
            try:
                self._specs[code] = PoolSpec(
                    code=code, segment=spec.get("segment", "FT"),
                    domain=spec.get("domain", "goal"), market=spec.get("market", "other"),
                    has_line=bool(spec.get("has_line", False)))
                n += 1
            except TypeError as exc:
                logger.warning("pool override %s ignored: %s", code, exc)
        for alias, target in (payload.get("aliases") or {}).items():
            ALIASES[str(alias).strip().upper()] = str(target).strip().upper()
        logger.info("pool overrides: %d spec(s) from %s", n, p)
        return n

    def resolve(self, code) -> PoolSpec:
        raw = "" if code is None else str(code).strip().upper()
        if not raw or raw in ("NAN", "NONE", "<NA>"):
            return PoolSpec("UNKNOWN", "FT", "other", "other", False, inferred=True)
        c = ALIASES.get(raw, raw)
        m = _NUMBERED.match(c)
        if m:
            c = m.group(1)
        spec = self._specs.get(c)
        if spec is not None:
            return spec if spec.code == raw else replace(spec, code=raw)
        with self._lock:
            spec = self._seen_inferred.get(c)
            if spec is None:
                spec = _infer(c)
                self._seen_inferred[c] = spec
                logger.warning(
                    "pool %r is not in the taxonomy; inferred %s/%s/%s (%s). Add it to the "
                    "overrides file to confirm.", raw, spec.segment, spec.domain, spec.market,
                    "priceable" if spec.priceable else "not priced")
        return spec if spec.code == raw else replace(spec, code=raw)

    def family(self, code) -> str:
        return self.resolve(code).family

    def inferred_codes(self) -> Dict[str, dict]:
        """Every code placed by rule this process - what to review and confirm."""
        return {c: s.to_dict() for c, s in self._seen_inferred.items()}

    def table(self, codes) -> Dict[str, PoolSpec]:
        return {str(c): self.resolve(c) for c in codes}


_default: Optional[PoolTaxonomy] = None


def default_taxonomy(overrides_path: Optional[str] = None) -> PoolTaxonomy:
    global _default
    if _default is None or overrides_path:
        _default = PoolTaxonomy(overrides_path)
    return _default


def side_of(combination_string, combination_id=None) -> str:
    """Canonical side of a two-way selection: 'H' (home/over) or 'A' (away/under).

    HKJC writes H/A on handicaps and H/L on totals; older extracts embed the
    line ("H[2.5]"). A blank string falls back on combination_id 1 = H.
    """
    s = "" if combination_string is None else str(combination_string).strip().upper()
    s = re.sub(r"\[.*?\]", "", s)
    if s.startswith("H") or s in ("O", "OVER", "HIGH", "1"):
        return "H"
    if s.startswith("A") or s.startswith("L") or s in ("U", "UNDER", "LOW", "2"):
        return "A"
    if s == "D" or s == "X":
        return "D"
    try:
        cid = int(combination_id)
    except (TypeError, ValueError):
        return "?"
    return {1: "H", 2: "A", 3: "D"}.get(cid, "?")


def parse_line(label) -> Optional[float]:
    """'2.5' / '2/2.5' / '-0.5/-1' / '+1' / 'H[1.5]' -> float; quarter lines averaged."""
    if label is None:
        return None
    s = str(label).strip()
    if not s or s.lower() in ("nan", "none", "<na>"):
        return None
    m = re.search(r"\[(.*?)\]", s)
    if m:
        s = m.group(1)
    s = s.replace(" ", "")
    try:
        if "/" in s:
            parts = [float(p) for p in s.split("/") if p not in ("", "+", "-")]
            return float(sum(parts) / len(parts)) if parts else None
        return float(s)
    except ValueError:
        return None
