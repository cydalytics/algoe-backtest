@echo off
REM Algo E - the full training chain on Raw_Data, CPU only:
REM     panel cache -> feature cache -> turnover models -> probability calibration -> backtest report
REM Days already cached are skipped, so a re-run after new data only builds the new days.
REM Drag the Raw_Data folder onto this file, or pass options that every step understands:
REM     algoe-2-train.bat --start 2026-07-01 --end 2026-09-15
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
set "ARGS=%*"
if not "%~1"=="" if exist "%~1\" (set "ALGOE_DATA_DIR=%~1" & set "ARGS=")
for %%S in (build-panel build-features train-turnover train-probability backtest) do (
    echo.
    echo ================================================================ %%S
    python -m algoe %%S %ARGS%
    if errorlevel 1 (
        echo.
        echo %%S FAILED - stopping. The log is under AlgoE_Work\logs next to Raw_Data.
        pause
        exit /b 1
    )
)
echo.
echo Done. The report is the newest AlgoE_Work\reports\backtest_*\report.html
pause
