"""
Speed tests - incremental reads (the same snapshot as a full read, the newer money minute wins, the sweep's
reconcile and the fall back to full reads), the since= SQL, the light trigger scan, the separate model locks,
the carried forecast at a bucket boundary, the cycle metrics, bench-live

    python tests/test_speed.py                 plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_speed.py

On the frozen simulator of test_algoe.py.

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      Review: the data clock, the reconcile per match and table (true odds, rows on one side, a match
                off the lane, reads that keep failing), money rows at two prices, the forecast handoff
"""

import sys
import tempfile
import threading
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from test_algoe import _FrozenSim  # noqa: E402
from test_w16_desk import T0, _Alive, _engine, _near_sim  # noqa: E402

GROWING = ("odds", "market", "investments")


def _same(a, b, table):
    from src.hkjc.incremental import GROWING as G, _keyed
    _, keys, values = G[table]
    fa, fb = getattr(a, table), getattr(b, table)
    if fa.empty and fb.empty:
        return True
    ka, kb = _keyed(fa, table), _keyed(fb, table)
    cols = keys + [v for v in values if v in ka.columns and v in kb.columns]
    norm = [f[cols].sort_values(keys).reset_index(drop=True) for f in (ka, kb)]
    return len(norm[0]) == len(norm[1]) and norm[0].astype(str).equals(norm[1].astype(str))


def _lane(n=4):
    from src.hkjc.incremental import IncrementalReads
    src = _FrozenSim(T0, n_matches=n)
    mids = sorted(pd.to_numeric(src.snap.active_pools["match_id"]).astype(int).unique().tolist())
    return src, mids, IncrementalReads


def _move_all(src, mids, at):
    """Every match's HILO price moves at ``at``: one new odds row each."""
    for m in mids:
        src.move_price(m, at, 1.01)


def _money_row(src, mid, when, amount):
    inv = src.snap.investments
    row = inv[pd.to_numeric(inv["match_id"], errors="coerce") == mid].iloc[-1].to_dict()
    row["start_sell_time"], row["turnover"] = pd.Timestamp(when), float(amount)
    return row


# ------------------------------------------------------------------ incremental reads
def test_incremental_reads_equal_full_reads_on_the_simulator():
    from src.hkjc.incremental import IncrementalReads
    src = _FrozenSim(T0, n_matches=6)
    mids = sorted(pd.to_numeric(src.snap.active_pools["match_id"]).astype(int).unique().tolist())[:4]
    inc = IncrementalReads(src, overlap_seconds=120)
    first = inc.fetch(T0, mids)
    assert all(_same(first, src.fetch(T0, mids), t) for t in GROWING)
    later = T0 + pd.Timedelta(seconds=30)
    key, _ = src.move_price(mids[0], T0 + pd.Timedelta(seconds=20), 1.05)
    src.add("investments", [_money_row(src, mids[1], T0 + pd.Timedelta(seconds=25), 5000.0)])
    again = inc.fetch(later, mids)
    full = src.fetch(later, mids)
    assert all(_same(again, full, t) for t in GROWING), [t for t in GROWING if not _same(again, full, t)]
    assert inc.stats["incremental"] == 1 and inc.stats["full"] == 1
    assert set(pd.to_numeric(again.active_pools["match_id"]).astype(int)) == set(mids)


def test_incremental_reads_key_money_by_either_naming():
    """Replay names a money row's line and combination line_id / combination_id (SQL: line_no / comb_id): two
    selections in one minute stay two rows."""
    from types import SimpleNamespace
    from src.hkjc.incremental import IncrementalReads
    t = pd.Timestamp("2026-11-20 20:00")
    inv = pd.DataFrame({"match_id": [1, 1, 1], "pool_id": [7, 7, 7], "line_id": [1, 1, 2],
                        "combination_id": [1, 2, 1], "start_sell_time": [t, t, t + pd.Timedelta(minutes=1)],
                        "turnover": [100.0, 200.0, 300.0]})

    class Canonical:
        rows = inv

        def fetch(self, as_of=None, match_ids=None):
            f = self.rows[self.rows["start_sell_time"] <= pd.Timestamp(as_of)]
            empty = pd.DataFrame({"match_id": pd.Series(dtype="int64")})
            return SimpleNamespace(as_of=as_of, active_pools=empty, match_info=empty, params=empty,
                                   params_history=empty, events=empty, odds=pd.DataFrame(), market=pd.DataFrame(),
                                   investments=f.reset_index(drop=True))
    src = Canonical()
    inc = IncrementalReads(src, overlap_seconds=120)
    inc.fetch(t, [1])
    got = inc.fetch(t + pd.Timedelta(minutes=2), [1]).investments
    assert sorted(got["turnover"].tolist()) == [100.0, 200.0, 300.0], got


def test_a_money_minute_read_again_takes_its_newer_value():
    from src.hkjc.incremental import IncrementalReads
    src = _FrozenSim(T0, n_matches=4)
    mid = int(pd.to_numeric(src.snap.active_pools["match_id"]).iloc[0])
    minute = T0.floor("min")
    src.add("investments", [_money_row(src, mid, minute, 1000.0)])
    inc = IncrementalReads(src, overlap_seconds=120)
    inc.fetch(T0, [mid])
    inv = src.snap.investments                                       # the minute fills: 1000 -> 3500
    hit = (pd.to_numeric(inv["match_id"]) == mid) & (pd.to_datetime(inv["start_sell_time"]) == minute) & \
        (inv["turnover"] == 1000.0)
    src.snap.investments.loc[hit, "turnover"] = 3500.0
    snap = inc.fetch(T0 + pd.Timedelta(seconds=15), [mid])
    got = snap.investments
    row = got[(pd.to_datetime(got["start_sell_time"]) == minute) & (pd.to_numeric(got["turnover"]) == 3500.0)]
    assert len(row) == 1 and not (pd.to_numeric(got["turnover"]) == 1000.0).any()


def _sec(k):
    return T0 + pd.Timedelta(seconds=k)


def test_the_sweep_reconciles_and_a_mismatch_falls_back_to_full_reads():
    src, mids, IncrementalReads = _lane()
    inc = IncrementalReads(src, overlap_seconds=60, max_mismatch=0.01)
    inc.fetch(T0, mids)
    for k in (30, 90, 150):                                          # prices move; the fast lane reads them
        _move_all(src, mids, _sec(k))
        inc.fetch(_sec(k + 5), mids)
    assert inc.reconcile(src.fetch(_sec(160))) == 0.0 and not inc.full
    for k in (200, 260):
        _move_all(src, mids, _sec(k))
        inc.fetch(_sec(k + 5), mids)
    odds = inc.cache["odds"]                                         # the read that brought 200s back was lost
    inc.cache["odds"] = odds[pd.to_datetime(odds["effective_datetime"]) != _sec(200)]
    rate = inc.reconcile(src.fetch(_sec(270)))
    assert rate > 0.1 and inc.full and inc.stats["mode"] == "full", inc.stats
    assert inc.stats["tables"]["odds"]["mismatch"] > 0.1 and inc.stats["tables"].get("investments", {}).get(
        "mismatch", 0.0) == 0.0                                      # each table on its own
    before = inc.stats["full"]
    inc.fetch(_sec(285), mids)
    assert inc.stats["full"] == before + 1                           # read whole while it disagrees
    # full reads alone leave nothing read incrementally to judge: that does not count as agreeing...
    assert inc.reconcile(src.fetch(_sec(290))) is None and not inc.full and inc.failures == 1
    _move_all(src, mids, _sec(320))                                  # ...the next reads are incremental again,
    inc.fetch(_sec(325), mids)                                       # and the next sweep judges them
    _move_all(src, mids, _sec(400))
    inc.fetch(_sec(405), mids)
    assert inc.reconcile(src.fetch(_sec(410))) == 0.0 and not inc.full and inc.failures == 0


def test_reads_that_keep_failing_their_reconcile_stay_full():
    src, mids, IncrementalReads = _lane()
    inc = IncrementalReads(src, overlap_seconds=60, max_failures=2)
    inc.fetch(T0, mids)
    t = 0
    for _ in range(2):
        for k in (30, 90):
            _move_all(src, mids, _sec(t + k))
            inc.fetch(_sec(t + k + 5), mids)
        odds = inc.cache["odds"]
        inc.cache["odds"] = odds[pd.to_datetime(odds["effective_datetime"]) != _sec(t + 30)]
        inc.reconcile(src.fetch(_sec(t + 100)))                       # fails: every read full
        if not inc.disabled:
            inc.reconcile(src.fetch(_sec(t + 110)))                   # nothing to judge: incremental on trial
        t += 120
    assert inc.disabled and inc.stats["mode"] == "off" and inc.failures == 2, inc.stats
    full, part = inc.stats["full"], inc.stats["incremental"]
    inc.reconcile(src.fetch(_sec(t + 5)))                             # nothing to judge, but they stay off
    inc.fetch(_sec(t + 10), mids)
    assert inc.stats["full"] == full + 1 and inc.stats["incremental"] == part


def test_incremental_reads_start_from_the_data_clock_not_this_machine():
    """This PC's clock ten minutes ahead of SQL's: a price SQL stamps after a read is still read."""
    src, mids, IncrementalReads = _lane()
    inc = IncrementalReads(src, overlap_seconds=120)
    ahead = pd.Timedelta(minutes=10)
    inc.fetch(T0 + ahead, mids)
    key, price = src.move_price(mids[0], _sec(40), 1.05)
    got = inc.fetch(T0 + ahead + pd.Timedelta(seconds=15), mids).odds
    row = got[(pd.to_numeric(got["pool_id"]) == key[0]) & (pd.to_numeric(got["line_id"]) == key[1])
              & (pd.to_numeric(got["combination_id"]) == key[2]) & (pd.to_datetime(got["effective_datetime"]) == _sec(40))]
    assert len(row) == 1 and float(row["odds"].iloc[0]) == price


def test_the_reconcile_still_sees_a_lost_read_after_a_match_leaves_the_lane():
    src, mids, IncrementalReads = _lane()
    inc = IncrementalReads(src, overlap_seconds=60)
    inc.fetch(T0, mids)
    stay = mids[1:]                                                   # mids[0] finished: off the fast lane
    for k in (30, 90, 150):
        _move_all(src, stay, _sec(k))
        inc.fetch(_sec(k + 5), stay)
    assert mids[0] not in inc.read_at and not (pd.to_numeric(inc.cache["odds"]["match_id"]) == mids[0]).any()
    odds = inc.cache["odds"]
    inc.cache["odds"] = odds[pd.to_datetime(odds["effective_datetime"]) != _sec(30)]
    assert inc.reconcile(src.fetch(_sec(160))) > 0.1 and inc.full


def test_the_reconcile_compares_true_odds_and_rows_only_the_cache_holds():
    for change in ("true_odds", "ghost"):
        src, mids, IncrementalReads = _lane()
        inc = IncrementalReads(src, overlap_seconds=60)
        inc.fetch(T0, mids)
        for k in (30, 90, 150):
            _move_all(src, mids, _sec(k))
            inc.fetch(_sec(k + 5), mids)
        odds = inc.cache["odds"].copy()
        hit = (pd.to_datetime(odds["effective_datetime"]) == _sec(30)).to_numpy()
        if change == "true_odds":                                     # a correction SQL made since the read
            odds.loc[hit, "true_odds"] = pd.to_numeric(odds.loc[hit, "true_odds"]) * 1.1
        else:                                                         # rows SQL no longer has (deleted since)
            ghost = odds[hit].assign(effective_datetime=_sec(31))
            odds = pd.concat([odds, ghost, ghost.assign(effective_datetime=_sec(32))], ignore_index=True)
        inc.cache["odds"] = odds
        assert inc.reconcile(src.fetch(_sec(160))) > 0.1 and inc.full, (change, inc.stats["tables"])


def test_money_rows_of_one_minute_at_two_prices_stay_two_rows():
    """Replay's Match_Investments has a row per selection, minute and price: a re-read keeps both."""
    from types import SimpleNamespace
    from src.hkjc.incremental import IncrementalReads
    t = pd.Timestamp("2026-11-20 20:00")
    inv = pd.DataFrame({"match_id": [1, 1], "pool_id": [7, 7], "line_id": [1, 1], "combination_id": [1, 1],
                        "odds": [1.90, 1.95], "start_sell_time": [t, t], "turnover": [500.0, 800.0]})
    raw = pd.DataFrame({"match_id": [1, 2], "GameState": ["PRE", "PRE"]})

    class Replay:
        def fetch(self, as_of=None, match_ids=None):
            ids = list(match_ids or [])
            empty = pd.DataFrame({"match_id": pd.Series(dtype="int64")})
            return SimpleNamespace(as_of=as_of, active_pools=empty, match_info=empty, params=empty,
                                   params_history=empty, events=empty, odds=pd.DataFrame(), market=pd.DataFrame(),
                                   params_raw=raw[raw["match_id"].isin(ids)].reset_index(drop=True),
                                   investments=inv[inv["match_id"].isin(ids)].reset_index(drop=True))
    inc = IncrementalReads(Replay(), overlap_seconds=120)
    inc.fetch(t, [1])
    snap = inc.fetch(t + pd.Timedelta(minutes=1), [1, 2])             # 1 read again, 2 read for the first time
    assert sorted(snap.investments["turnover"].tolist()) == [500.0, 800.0], snap.investments
    assert sorted(snap.params_raw["match_id"].tolist()) == [1, 2], snap.params_raw
    assert inc.fetch(t, []) is not None


def test_the_same_rows_in_another_order_give_the_same_board():
    """The incremental cache returns rows in the order they were read again, SQL in no set order: the board,
    and so the book and the solver's answer, must not depend on it."""
    import copy
    from algoe.data.panel import LivePanelBuilder
    from algoe.settings import Settings
    snap = _FrozenSim(T0, n_matches=3).fetch(T0)
    shuffled = copy.copy(snap)
    for table in GROWING:
        setattr(shuffled, table, getattr(snap, table).sample(frac=1.0, random_state=7).reset_index(drop=True))
    builder = LivePanelBuilder(Settings())
    a, _ = builder.build(snap, T0, board_at=T0)
    b, _ = builder.build(shuffled, T0, board_at=T0)
    assert len(a) and a.reset_index(drop=True).equals(b.reset_index(drop=True))


class _OfficePandas:
    """pandas before 2.2, as on the office box's Anaconda: a nullable array converts to NumPy as objects (a mask
    of True / False becomes Python bools, and ~True is -2), and NA in a numeric conversion raises."""

    def __enter__(self):
        from pandas._libs import lib
        from pandas._libs import missing as libmissing
        from pandas.core.arrays.masked import BaseMaskedArray
        self.cls, self.saved = BaseMaskedArray, (BaseMaskedArray.to_numpy, BaseMaskedArray.__array__)

        def to_numpy(arr, dtype=None, copy=False, na_value=lib.no_default):
            na = libmissing.NA if na_value is lib.no_default else na_value
            dtype = np.dtype(object if dtype is None else dtype)
            if arr._hasna and dtype != object and na is libmissing.NA:
                raise ValueError("cannot convert to '{}'-dtype NumPy array with missing values".format(dtype))
            data = arr._data.astype(dtype, copy=copy)
            if arr._hasna:
                data[arr._mask] = na
            return data
        BaseMaskedArray.to_numpy = to_numpy
        BaseMaskedArray.__array__ = lambda arr, dtype=None, copy=None: to_numpy(arr, dtype=dtype)
        return self

    def __exit__(self, *exc):
        self.cls.to_numpy, self.cls.__array__ = self.saved
        return False


def test_incremental_reads_take_replay_frames_on_the_office_pandas():
    """Replay frames carry nullable Int64 ids and string columns. On the office box's pandas a mask built on them
    came back as objects, and selftest S14 crashed in the reconcile (KeyError: None of [-2, -2, ...])."""
    from types import SimpleNamespace
    from src.hkjc.incremental import IncrementalReads
    t0, n = pd.Timestamp("2026-11-20 20:00"), 120
    times = [t0 + pd.Timedelta(seconds=5 * i) for i in range(n)]

    def rows(**more):
        return pd.DataFrame({"match_id": pd.array([1, 2, 3, 4] * (n // 4), dtype="Int64"),
                             "pool_id": pd.array([7] * n, dtype="Int64"), "line_id": pd.array([1] * n, dtype="Int64"),
                             "combination_id": pd.array(list(range(n)), dtype="Int64"),
                             "pool_name": pd.array(["HAD"] * n, dtype="string"), **more})
    tables = {"odds": rows(effective_datetime=times, odds=1.9, true_odds=2.0),
              "market": rows(bookmaker=pd.array([12] * n, dtype="Int64"), effective_datetime=times, odds=1.95),
              "investments": rows(start_sell_time=[t.floor("min") for t in times], odds=1.9, turnover=100.0,
                                  ticket_count=pd.array([1, None] * (n // 2), dtype="Int64"))}
    when = {"odds": "effective_datetime", "market": "effective_datetime", "investments": "start_sell_time"}

    class Replay:
        def fetch(self, as_of=None, match_ids=None):
            at, ids = pd.Timestamp(as_of), list(match_ids or [1, 2, 3, 4])
            empty = pd.DataFrame({"match_id": pd.array([], dtype="Int64")})
            cut = {k: f[(f[when[k]] <= at) & f["match_id"].isin(ids)].reset_index(drop=True) for k, f in tables.items()}
            return SimpleNamespace(as_of=at, active_pools=empty, match_info=empty, params=empty,
                                   params_history=empty, events=empty, **cut)
    with _OfficePandas():
        inc = IncrementalReads(Replay(), overlap_seconds=60)
        for k in range(36):                                          # match 1 leaves the lane after 20 reads
            inc.fetch(t0 + pd.Timedelta(seconds=15 * k), [1, 2, 3, 4] if k < 20 else [2, 3, 4])
        rate = inc.reconcile(Replay().fetch(t0 + pd.Timedelta(seconds=15 * 36)))
    assert rate == 0.0 and inc.stats["compared"] > 0 and 1 not in inc.read_at, inc.stats


def test_a_bookmaker_code_read_as_a_float_is_the_same_bookmaker():
    from src.hkjc.incremental import _keyed
    t = pd.Timestamp("2026-11-20 20:00")
    a = pd.DataFrame({"match_id": [1], "pool_id": [7], "line_id": [1], "combination_id": [1], "bookmaker": [12],
                      "effective_datetime": [t], "odds": [1.9]})
    b = a.assign(bookmaker=[12.0])
    ka, kb = _keyed(a, "market"), _keyed(b, "market")
    assert ka["bookmaker"].iloc[0] == kb["bookmaker"].iloc[0]


def test_the_sql_reads_only_what_is_new():
    from src.hkjc import queries as Q
    since = pd.Timestamp("2026-11-20 21:14:05")
    assert "and o.effective_datetime >= '2026-11-20 21:14:05'" in Q.hkjc_odds([1, 2], since)
    assert "and o.effective_datetime >= '2026-11-20 21:14:05'" in Q.market_odds([1], since)
    assert "and i.IntervalTimeStart >= '2026-11-20 21:14:05'" in Q.investments([1], since)
    assert ">=" not in Q.hkjc_odds([1]).split("where e.event_id")[1]
    from src.hkjc.incremental import IncrementalReads
    from src.hkjc.sql_source import SqlSource
    assert IncrementalReads(SqlSource()).native


def test_the_fast_lane_reads_incrementally_and_publishes_the_same_board():
    src, near, _ = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        full = _engine(tmp, _near_sim()[0], sets=("live.incremental_fetch=false",))
        for e in (eng, full):
            e.run_sweep(T0)
            e.run_fast_cycle(T0 + pd.Timedelta(seconds=20))
        key, _ = src.move_price(near, T0 + pd.Timedelta(seconds=25), 1.04)
        full.source.move_price(near, T0 + pd.Timedelta(seconds=25), 1.04)
        for e in (eng, full):
            e.run_fast_cycle(T0 + pd.Timedelta(seconds=35))
        a, b = eng.matches[near], full.matches[near]
        stats = eng.metrics()["reads"]
    assert stats["incremental"] >= 1 and full.metrics()["reads"]["mode"] == "full"
    assert np.allclose(a.book.odds_now, b.book.odds_now) and np.allclose(a.decision.odds_star, b.decision.odds_star)


# ------------------------------------------------------------------ the scan, the locks, the carry, the metrics
def test_the_scan_reads_only_the_matches_off_the_fast_lane():
    src, near, other = _near_sim()
    asked = []
    real = src.fetch

    def spy(as_of=None, match_ids=None):
        asked.append(None if match_ids is None else sorted(match_ids))
        return real(as_of, match_ids)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        eng.source.fetch = spy
        eng._fast_thread = _Alive()
        eng.check_triggers(T0 + pd.Timedelta(seconds=10))
        lane = [m for m in eng.card if eng.lane(eng.matches[m], T0 + pd.Timedelta(seconds=10)) == "fast"]
        scan = dict(eng.last_scan)
    assert asked and near not in asked[-1] and other in asked[-1] and not set(lane) & set(asked[-1]), (asked, lane)
    assert scan["matches"] == len(asked[-1])


def test_the_fast_lanes_belief_does_not_wait_for_the_sweeps_forecast():
    from algoe.realtime.live_engine import LiveEngine
    assert hasattr(LiveEngine, "_forecast") and hasattr(LiveEngine, "_belief")
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, _FrozenSim(T0, n_matches=2))

        class Slow:
            def predict_for_day(self, day):
                return np.full(len(day.sel), 0.5)
        eng.calibrator = Slow()
        day = type("Day", (), {"sel": pd.DataFrame({"p_hkjc_true": [0.4, 0.6]})})()
        done = threading.Event()
        with eng._forecast_lock:                                     # a sweep forecasting the card
            t = threading.Thread(target=lambda: (eng._belief(day), done.set()))
            t.start()
            assert done.wait(2.0), "the belief waited for the forecast"
        t.join(2.0)


def test_a_bucket_boundary_carries_the_last_reads_next_bucket():
    src, near, _ = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        eng.run_fast_cycle(pd.Timestamp("2026-10-26 15:49:40"))
        expected = float(np.nansum(eng.matches[near].rows["next_bucket"].to_numpy(dtype="float64")))
        calls = []
        real = eng._forecast
        eng._forecast = lambda day: calls.append(1) or real(day)
        cyc = eng.run_fast_cycle(pd.Timestamp("2026-10-26 15:50:05"))   # the 15:50 bucket, no sweep yet
        got = float(np.nansum(eng.matches[near].forecast["forecast"].to_numpy(dtype="float64")))
    assert near in cyc["carried"] and not calls, (cyc.get("carried"), len(calls))
    assert abs(got - expected) < 1e-6 and eng.matches[near].bucket == pd.Timestamp("2026-10-26 15:50")


def test_the_sweeps_forecast_that_lands_first_is_not_carried_over():
    src, near, _ = _near_sim()
    b1 = pd.Timestamp("2026-10-26 15:50")
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        eng.run_fast_cycle(pd.Timestamp("2026-10-26 15:49:40"))
        eng._fast_thread = _Alive()                                  # the sweep leaves the match to the fast lane
        eng.run_sweep(pd.Timestamp("2026-10-26 15:50:02"))           # 15:50's forecast lands before the next cycle
        live = eng.matches[near]
        swept = float(live.forecast["forecast"].sum())
        handed = (live.forecast_bucket, live.bucket)
        cyc = eng.run_fast_cycle(pd.Timestamp("2026-10-26 15:50:05"))
        got = float(eng.matches[near].forecast["forecast"].sum())
    assert handed == (b1, pd.Timestamp("2026-10-26 15:45")), handed
    assert near not in cyc["carried"] and abs(got - swept) < 1e-6, (cyc["carried"], got, swept)


def test_a_late_sweep_does_not_overwrite_the_next_buckets_forecast():
    from algoe.realtime.live_engine import MatchLive, _take_forecast
    b0, b1 = pd.Timestamp("2026-10-26 15:45"), pd.Timestamp("2026-10-26 15:50")
    live = MatchLive(1)
    new, old = pd.DataFrame({"forecast": [2.0]}), pd.DataFrame({"forecast": [1.0]})
    _take_forecast(live, new, b1)                                    # the fast lane in the 15:50 bucket
    _take_forecast(live, old, b0)                                    # the 15:45 sweep finishing late
    assert live.forecast is new and live.forecast_bucket == b1


def test_the_status_carries_the_cycle_metrics():
    src, near, _ = _near_sim()
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src)
        eng.run_sweep(T0)
        for k in (20, 35, 50):
            eng.run_fast_cycle(T0 + pd.Timedelta(seconds=k))
        m = eng.metrics()
        from src.api import live_payload
        board = live_payload.board(eng)
    f = m["fast"]
    assert f["cycles"] == 3 and f["p50_s"] is not None and f["p95_s"] >= f["p50_s"] and f["behind_max"] == 0
    assert f["age_p50_s"] >= f["p50_s"] and m["churn"]["decisions"] >= 2 and m["reads"]["incremental"] >= 2
    assert board["metrics"]["fast"]["cycles"] == 3


def test_bench_live_prints_the_cycle_times():
    from algoe import cli
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:     # the run's log stays open
        code = cli.main(["bench-live", "--source", "sim", "--cycles", "3", "--work-dir", str(Path(tmp) / "work"),
                         "--log-level", "ERROR"])
        runs = sorted((Path(tmp) / "work" / "runs").glob("*_bench-live"))
        summary = (runs[-1] / "summary.json").read_text(encoding="utf-8") if runs else ""
    assert code == 0 and '"p95_s"' in summary and '"cycles": 3' in summary, summary[:400]


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<72} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<72} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
