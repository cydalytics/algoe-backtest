:HL["/_next/static/chunks/225zsu95ek8i0.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"jGuOrRyf34RTsz1Dp_UO6"}
