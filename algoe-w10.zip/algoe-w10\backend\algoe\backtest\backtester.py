"""
Backtester

Every lever of Algo E compared on the same held-out days, one method each:

    compare_turnover(days)          every forecast pipeline vs last 5 minutes:
                                    deviance, WAPE (selection / match / active), bias,
                                    Diebold-Mariano on daily loss, days better / worse,
                                    cuts by phase / family / clock / event window / league
    compare_trueprob(days)          every belief source x calibration: log-loss, Brier,
                                    ECE, calibration slope, reliability curve, cuts
    compare_optimizer(days)         theta* vs HKJC's board under the forecast demand and
                                    the calibrated belief: expected lift, days better /
                                    worse, by phase and pool, how far theta moved, which
                                    guard bound it, solve time
    compare_gm(days)                expected margin under the belief vs realised
                                    turnover - dividend, per day
    compare_feature_groups()        drop one feature group at a time, refit, report what
                                    it was worth: the hypothesis test of catalog.py
    check_replication(days)         does HKJC's own theta through our pricer reproduce the
                                    board, and which in-play settlement convention does

``run_all`` runs them in order and writes report.json and report.html.

Days are the test block of the model's own split unless given, so nothing
is scored on a day any model learned from.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Ablation refits on the model's own split; panel days ensured before scoring
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.io import write_json
from ..core.logging import get_logger, log_step
from ..core.taxonomy import ASIAN
from ..evaluation.metrics import calibration_bins
from ..features import catalog as C
from ..features.engineer import FeatureSet
from ..features.store import FeatureStore
from ..models.estimators import GLMEstimator
from ..models.probability import ProbabilityCalibrator
from ..models.turnover import RESPONSES, TurnoverForecaster, TrainingData, labels
from ..optimizer.theta_optimizer import DemandResponse, ThetaOptimizer, build_books
from ..pricing.panel_pricing import price_rows_at_hkjc
from ..pricing.pricer import Conventions
from ..reporting import html as H

logger = get_logger(__name__)


class Backtester:
    def __init__(self, settings, store: FeatureStore, forecaster: Optional[TurnoverForecaster] = None,
                 calibrator: Optional[ProbabilityCalibrator] = None):
        self.settings = settings
        self.store = store
        self.forecaster = forecaster
        self.calibrator = calibrator
        self.report: Dict[str, dict] = {}

    def _test_days(self, days=None) -> List[pd.Timestamp]:
        if days is not None:
            return [pd.Timestamp(d).normalize() for d in days]
        for m in (self.forecaster, self.calibrator):
            split = (getattr(m, "metadata", None) or {}).get("split") if m is not None else None
            if split and split.get("test"):
                return [pd.Timestamp(d) for d in split["test"]]
        raise ValueError("no test days: pass days= or load a trained model")

    # ========================================================= turnover
    def compare_turnover(self, days=None, pipelines: Optional[Sequence[str]] = None) -> dict:
        f = self.forecaster
        days = self._test_days(days)
        pipelines = list(pipelines or f._runnable_pipelines())
        with log_step(logger, "B1", "compare_turnover", "{} pipelines on {} days".format(len(pipelines), len(days))) as step:
            s = f._score_days(days, pipelines, choose_blend=False, cuts=True)
            rows = []
            for p in pipelines:
                a = (s.get(p) or {}).get("all") or {}
                dm = (s.get("_dm") or {}).get(p) or {}
                rows.append({"pipeline": p, "blend": f.blend.get(p, 1.0), "champion": p == f.champion,
                             "deviance": a.get("deviance"), "wape": a.get("wape"), "active_wape": a.get("active_wape"),
                             "match_wape": a.get("match_wape"), "bias": a.get("bias"),
                             "dm_stat": dm.get("stat"), "dm_p": dm.get("p_value"),
                             "days_better": dm.get("days_a_better"), "days_worse": dm.get("days_b_better")})
            rows.sort(key=lambda r: (r["deviance"] is None, r["deviance"] or 0))
            cuts = []
            for key, v in (s.get("_cuts") or {}).items():
                pipe, dim_val = key.split("|", 1)
                dim, val = dim_val.split("=", 1)
                cuts.append({"pipeline": pipe, "dim": dim, "value": val, **v})
            base = next(r for r in rows if r["pipeline"] == "last5")
            champ = next((r for r in rows if r["champion"]), base)
            step["result"] = "champion {} deviance {} vs last5 {}".format(
                champ["pipeline"], H.fmt(champ["deviance"]), H.fmt(base["deviance"]))
        self.report["turnover"] = {"days": [str(d.date()) for d in days], "leaderboard": rows, "cuts": cuts}
        return self.report["turnover"]

    # ============================================================ belief
    def compare_trueprob(self, days=None, methods: Optional[Sequence[str]] = None) -> dict:
        c = self.calibrator
        days = self._test_days(days)
        methods = list(methods or [m for m in c.candidates() if m.startswith("raw:") or m in c.fitted])
        with log_step(logger, "B2", "compare_trueprob", "{} methods on {} days".format(len(methods), len(days))) as step:
            fs = c._collect(days, cap_per_day=10 ** 9)
            if fs is None:
                raise ValueError("no settled selections on the test days")
            rows, curves = [], {}
            for m in methods:
                sc = c._score(fs, m)
                rows.append({"method": m, "champion": m == c.champion, **sc})
                if m in ("raw:hkjc_true", "raw:market", c.champion):
                    curves[m] = calibration_bins(c.predict_true_prob(fs, m), fs.y, fs.weight, 10)
            rows.sort(key=lambda r: (r.get("log_loss") is None, r.get("log_loss") or 0))
            cuts = []
            for dim in ("phase", "family"):
                vals = labels(fs.cuts[dim])
                for v in np.unique(vals):
                    msk = vals == v
                    if msk.sum() < 200:
                        continue
                    sub = fs.subset(msk)
                    for m in ("raw:hkjc_true", c.champion):
                        cuts.append({"dim": dim, "value": v, "method": m, **c._score(sub, m)})
            n_sel = int(fs.keys.drop_duplicates(["pool_id", "line_id", "combination_id"]).shape[0])
            step["result"] = "{:,} settled rows from {:,} selections; noise floor on ECE ~{:.3f}".format(
                len(fs), n_sel, 1 / np.sqrt(max(n_sel, 1)))
        self.report["trueprob"] = {"days": [str(d.date()) for d in days], "leaderboard": rows, "curves": curves,
                                   "cuts": cuts, "selections": n_sel, "noise_floor": 1 / np.sqrt(max(n_sel, 1))}
        return self.report["trueprob"]

    # ========================================================= optimiser
    def compare_optimizer(self, days=None, every: int = 6, max_books_per_day: int = 400,
                          belief: str = "calibrated", workers: Optional[int] = None) -> dict:
        days = self._test_days(days)
        dr = DemandResponse.from_forecaster(self.forecaster, self.settings)
        opt = ThetaOptimizer(self.settings, dr)
        rows, pools = [], []
        with log_step(logger, "B3", "compare_optimizer", "every {}th bucket per match, demand {}, belief {}".format(
                every, dr.mode, belief)) as step:
            started = time.time()
            for d in days:
                dd = self.store.get(d)
                if dd.empty:
                    continue
                demand = self.forecaster.predict_selection_turnover(dd)["forecast"].to_numpy()
                if belief == "calibrated" and self.calibrator is not None:
                    p = self.calibrator.predict_for_day(dd)
                else:
                    p = dd.sel["p_hkjc_true"].to_numpy(dtype="float64")
                live = dd.sel["forecastable"].to_numpy()
                mb = dd.sel.loc[live, ["match_id", "bucket"]].drop_duplicates().sort_values(["match_id", "bucket"])
                mb = mb[mb.groupby("match_id").cumcount() % max(every, 1) == 0].head(max_books_per_day)
                keep = dd.sel.set_index(["match_id", "bucket"]).index.isin(pd.MultiIndex.from_frame(mb))
                books = build_books(dd.sel[keep], dd.match, demand[keep], p[keep], self.settings)
                decisions = opt.optimize_card(books, mode="sweep", budget_seconds=0, workers=workers, key="index")
                phase = dd.match.set_index(["match_id", "bucket"])["phase"]
                for i, bk in enumerate(books):
                    dec = decisions.get(i)
                    if dec is None:
                        continue
                    ph = phase.get((bk.match_id, bk.keys["bucket"].iloc[0]), "unknown")
                    wts = dec.weights if dec.weights is not None else np.ones(1)
                    rows.append({"day": str(d.date()), "match_id": bk.match_id, "bucket": bk.keys["bucket"].iloc[0],
                                 "phase": ph, "status": dec.status, "turnover": dec.turnover,
                                 "egm_board": dec.egm_board, "egm_stage1": dec.egm_stage1 if np.isfinite(dec.egm_stage1)
                                 else dec.egm_star, "egm_star": dec.egm_star, "lift": dec.lift,
                                 "lift_stage2": dec.lift_stage2, "w_moved": int(np.sum(np.abs(wts - 1) > 1e-6)),
                                 "w_max": float(np.max(np.abs(wts - 1))),
                                 "seconds": dec.seconds, "binding": ";".join(dec.binding),
                                 **{"d_" + k: dec.theta_star[k] - dec.theta_now[k] for k in ("goal_tg", "goal_sup",
                                                                                              "corner_tg", "corner_sup")}})
                    for pp in dec.per_pool:
                        pools.append({"day": str(d.date()), "phase": ph, **pp})
            step["result"] = "{} match-buckets in {:.0f}s".format(len(rows), time.time() - started)
        df = pd.DataFrame(rows)
        out = {"days": [str(d.date()) for d in days], "demand": dr.mode, "belief": belief, "every": every}
        if df.empty:
            self.report["optimizer"] = out
            return out
        solved = df[~df["status"].str.startswith("skipped")]
        daily = solved.groupby("day").agg(turnover=("turnover", "sum"), board=("egm_board", "sum"),
                                          star=("egm_star", "sum")).reset_index()
        daily["lift_pct"] = (daily["star"] - daily["board"]) / daily["turnover"].clip(lower=1)
        tot_t = float(solved["turnover"].sum())
        out.update({
            "buckets": int(len(df)), "solved": int(len(solved)),
            "skipped_low_demand": int(df["status"].str.startswith("skipped").sum()),
            "kept_board": int(solved["status"].str.startswith("kept").sum()),
            "turnover": tot_t, "egm_board": float(solved["egm_board"].sum()), "egm_star": float(solved["egm_star"].sum()),
            "lift_pct": float((solved["egm_star"].sum() - solved["egm_board"].sum()) / max(tot_t, 1.0)),
            # stage 1 = theta* alone, stage 2 = what the per-selection weightings added on top
            "lift_stage1_pct": float((solved["egm_stage1"].sum() - solved["egm_board"].sum()) / max(tot_t, 1.0)),
            "lift_stage2_pct": float(solved["lift_stage2"].sum() / max(tot_t, 1.0)),
            "weightings": {"buckets_moved": int((solved["w_moved"] > 0).sum()),
                           "max_move_p95": float(solved["w_max"].quantile(0.95))},
            "days_better": int((daily["lift_pct"] > 1e-9).sum()), "days_worse": int((daily["lift_pct"] < -1e-9).sum()),
            "daily": daily.to_dict("records"),
            "by_phase": [{"phase": ph, "buckets": int(len(g)), "turnover": float(g["turnover"].sum()),
                          "lift_pct": float((g["egm_star"].sum() - g["egm_board"].sum()) / max(g["turnover"].sum(), 1))}
                         for ph, g in solved.groupby("phase")],
            "by_pool": [{"pool": p, "turnover": float(g["turnover"].sum()),
                         "lift_pct": float(g["lift"].sum() / max(g["turnover"].sum(), 1))}
                        for p, g in pd.DataFrame(pools).groupby("pool")] if pools else [],
            "theta_moves": {k: {"mean": float(solved[k].mean()), "mae": float(solved[k].abs().mean()),
                                "p95": float(solved[k].abs().quantile(0.95))}
                            for k in ("d_goal_tg", "d_goal_sup", "d_corner_tg", "d_corner_sup")},
            "binding": solved["binding"].str.split(";").explode().replace("", np.nan).dropna()
                                         .str.replace(r"@(lo|hi)", "", regex=True).value_counts().to_dict(),
            "seconds_per_match": {"mean": float(solved["seconds"].mean()), "p95": float(solved["seconds"].quantile(0.95))},
        })
        self.report["optimizer"] = out
        return out

    # ================================================================ GM
    def compare_gm(self, days=None, method: Optional[str] = None) -> dict:
        days = self._test_days(days)
        c = self.calibrator
        rows = []
        for d in days:
            fs = c.features_for_day(d) if c is not None else None
            if fs is None or not len(fs):
                continue
            for m in ("raw:hkjc_true", method or (c.champion if c else "raw:hkjc_true")):
                sc = c._score(fs, m)
                rows.append({"day": str(pd.Timestamp(d).date()), "method": m,
                             "expected_margin": sc.get("expected_margin"), "realised_margin": sc.get("realised_margin"),
                             "stake": float(fs.keys["stake"].sum())})
        self.report["gm"] = {"daily": rows}
        return self.report["gm"]

    # ================================================== feature groups
    def compare_feature_groups(self, data: Optional[TrainingData] = None, days=None,
                               response: str = "selection_turnover", algo: str = "glm",
                               max_rows: int = 150_000) -> dict:
        """Drop each group, refit, and report the validation deviance it was worth."""
        f = self.forecaster
        if data is None:
            data = f.prepare_training_data(days or [pd.Timestamp(x) for x in f.metadata["split"]["train"] +
                                                    f.metadata["split"]["val"] + f.metadata["split"]["test"]])
        tr, va = data.train[response], data.val[response]
        rng = np.random.default_rng(self.settings.turnover.seed)
        if len(tr) > max_rows:
            tr = tr.subset(rng.random(len(tr)) < max_rows / len(tr))
        if len(va) > max_rows:
            va = va.subset(rng.random(len(va)) < max_rows / len(va))
        spec = RESPONSES[response]
        groups: Dict[str, List[str]] = {}
        hyp: Dict[str, set] = {}
        for sp in f.engineer.match_specs + f.engineer.pool_specs + f.engineer.sel_specs:
            if sp.name in tr.X.columns:
                groups.setdefault(sp.group, [])
                if sp.name not in groups[sp.group]:
                    groups[sp.group].append(sp.name)
                hyp.setdefault(sp.group, set()).add(sp.hypothesis)
        kinds = ("raw", "basis", "flag", "encoded")
        all_cols = tr.columns_for(kinds)

        def fit_score(cols):
            m = GLMEstimator(spec.family, self.settings.turnover.tweedie_power, self.settings.turnover.ridge, cols)
            m.fit(tr.X, tr.y, exposure=tr.exposure if spec.uses_exposure else None)
            mu = m.predict(va.X, va.exposure if spec.uses_exposure else None)
            from ..evaluation.metrics import poisson_deviance
            return poisson_deviance(va.y, mu), m
        with log_step(logger, "B4", "compare_feature_groups", "{} {} - {} groups".format(algo, response, len(groups))) as step:
            full, model = fit_score(all_cols)
            rows = []
            for g, cols in sorted(groups.items()):
                keep = [c for c in all_cols if c not in cols]
                if not keep:
                    continue
                dev, _ = fit_score(keep)
                rows.append({"group": g, "features": len(cols), "hypotheses": ",".join(sorted(hyp[g])),
                             "val_deviance_without": dev, "worth": dev - full,
                             "worth_pct": (dev - full) / full if full else None,
                             "verdict": "supported" if dev > full * 1.002 else ("no effect" if dev > full * 0.998
                                                                                  else "hurts")})
            rows.sort(key=lambda r: -r["worth"])
            coef = model.coefficients()
            signs = []
            for name, expect, h in (("n_live", "-", "H6"), ("goal_p3", "+", "H4"), ("m_log_l1", "+", "H1"),
                                    ("weekend", "+", "H7"), ("value_true", "+", "H15"), ("value_mkt", "+", "H15"),
                                    ("rank_0", "+", "H14"), ("abs_line_offset", "-", "H14"),
                                    ("log_odds_age", "-", "H20"), ("league_level", "+", "H5")):
                if name in coef:
                    v = coef[name]
                    ok = (v < 0) if expect == "-" else (v > 0)
                    signs.append({"feature": name, "hypothesis": h, "expected": expect, "coefficient": v,
                                  "agrees": bool(ok)})
            step["result"] = "full val deviance {:.4g}; most useful group {}".format(
                full, rows[0]["group"] if rows else "-")
        out = {"response": response, "algo": algo, "full_val_deviance": full, "groups": rows, "signs": signs,
               "hypotheses": C.HYPOTHESES}
        self.report.setdefault("feature_groups", {})[response] = out
        return out

    # ======================================================== replication
    def check_replication(self, days=None) -> dict:
        """Our price at HKJC's theta vs the board they posted, per pool x phase and convention."""
        days = self._test_days(days)
        conventions = {"full_match": Conventions("full_match", "full_match"),
                       "rest_of_match": Conventions("rest_of_match", "rest_of_match"),
                       "totals_full_hdc_rest": Conventions("full_match", "rest_of_match")}
        acc: Dict[tuple, list] = {}
        with log_step(logger, "B5", "check_replication", ", ".join(conventions)) as step:
            for d in days:
                dd = self.store.get(d)
                if dd.empty:
                    continue
                s = dd.sel
                o = self.settings.optimizer
                age = np.expm1(s["log_odds_age"].to_numpy(dtype="float64"))
                inplay = s["inplay"].fillna(0).to_numpy(dtype="float64") > 0
                fresh = age <= np.where(inplay, o.max_odds_age_inplay_min, o.max_odds_age_prematch_min)
                live = (s["forecastable"].to_numpy() & s["market"].isin(list(ASIAN)).to_numpy() & fresh)
                imp = 1.0 / s["odds"].to_numpy(dtype="float64")
                s = s.assign(_imp=imp)
                book = s.groupby(["match_id", "pool_name", "line_id", "bucket"])["_imp"].transform("sum").to_numpy()
                posted = imp / np.where(book > 0, book, np.nan)
                phase = labels(s["phase"])
                pool = labels(s["pool_name"])
                for name, conv in conventions.items():
                    p = price_rows_at_hkjc(s, dd.match, conv, live)
                    ok = live & np.isfinite(p) & np.isfinite(posted)
                    err = np.abs(p[ok] - posted[ok])
                    for pl, ph, e in zip(pool[ok], phase[ok], err):
                        acc.setdefault((name, pl, "in-play" if ph != "prematch" else "prematch"), []).append(e)
            rows = [{"convention": k[0], "pool": k[1], "phase": k[2], "n": len(v), "mae_prob": float(np.mean(v)),
                     "p90_prob": float(np.quantile(v, 0.9))} for k, v in acc.items()]
            best = {}
            for r in rows:
                if r["phase"] != "in-play":
                    continue
                key = r["pool"]
                if key not in best or r["mae_prob"] < best[key]["mae_prob"]:
                    best[key] = r
            step["result"] = "in-play best convention per pool: {}".format(
                {k: v["convention"] for k, v in best.items()})
        rows.sort(key=lambda r: (r["pool"], r["phase"], r["mae_prob"]))
        self.report["replication"] = {"rows": rows, "best_in_play": {k: v["convention"] for k, v in best.items()}}
        return self.report["replication"]

    # ============================================================ all
    def run_all(self, out_dir, days=None, optimizer_every: int = 6, feature_groups: bool = True) -> dict:
        days = self._test_days(days)
        started = time.time()
        self.store.panel.ensure(days)
        if self.forecaster is not None:
            self.compare_turnover(days)
            if feature_groups:
                try:
                    from ..data.splits import DaySplit
                    f = self.forecaster
                    split = DaySplit.from_dict(f.metadata["split"])
                    fit_days = list(split.train) + list(split.val) + list(split.test)
                    self.store.panel.ensure(fit_days)
                    data = f.prepare_training_data(fit_days, split=split)
                    # each hypothesis is tested at the level it is about
                    for response in ("match_total", "selection_share"):
                        self.compare_feature_groups(data, response=response)
                except Exception as exc:                                  # noqa: BLE001
                    logger.warning("feature-group ablation skipped: %s: %s", type(exc).__name__, exc, exc_info=True)
        if self.calibrator is not None:
            self.compare_trueprob(days)
            self.compare_gm(days)
        self.check_replication(days)
        if self.forecaster is not None:
            self.compare_optimizer(days, every=optimizer_every)
        self.report["meta"] = {"seconds": round(time.time() - started, 1),
                               "generated": time.strftime("%Y-%m-%d %H:%M"),
                               "turnover_model": getattr(self.forecaster, "version", None),
                               "probability_model": getattr(self.calibrator, "version", None),
                               "settings": self.settings.to_dict()}
        from pathlib import Path
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        write_json(self.report, out / "report.json")
        (out / "report.html").write_text(self.render(), encoding="utf-8")
        for key in ("turnover", "trueprob", "feature_groups"):
            r = self.report.get(key) or {}
            lb = r.get("leaderboard") or r.get("groups")
            if lb:
                pd.DataFrame(lb).to_csv(out / "{}.csv".format(key), index=False)
        logger.info("backtest report: %s", out / "report.html")
        return self.report

    # ========================================================= render
    def render(self) -> str:
        r = self.report
        sec = []
        verdicts = []
        t = r.get("turnover")
        if t:
            lb = t["leaderboard"]
            base = next((x for x in lb if x["pipeline"] == "last5"), {})
            champ = next((x for x in lb if x["champion"]), base)
            good = (champ.get("deviance") or 1e18) < (base.get("deviance") or 0)
            verdicts.append(H.verdict("Turnover: <b>{}</b> deviance {} vs last 5 min {}; match WAPE {} vs {}; "
                                      "better on {} of {} test days.".format(
                                          H.esc(champ["pipeline"]), H.fmt(champ.get("deviance")),
                                          H.fmt(base.get("deviance")), H.fmt(champ.get("match_wape"), "pct"),
                                          H.fmt(base.get("match_wape"), "pct"), champ.get("days_better") or 0,
                                          len(t["days"])), "good" if good else "bad"))
            sec.append("<h2>1. Turnover forecast</h2><p class='muted'>Test days {}. Deviance is the proper score "
                       "for a mean forecast; WAPE is shown because it is what W06 reported.</p>".format(
                           ", ".join(t["days"])))
            sec.append(H.table(lb, [("pipeline", "pipeline", "text"), ("blend", "blend", "num"),
                                    ("deviance", "deviance", "num"), ("wape", "WAPE", "pct"),
                                    ("active_wape", "active WAPE", "pct"), ("match_wape", "match WAPE", "pct"),
                                    ("bias", "bias", "pct"), ("dm_stat", "DM stat", "num"), ("dm_p", "DM p", "p"),
                                    ("days_better", "days better", "int"), ("days_worse", "days worse", "int")],
                               highlight=lambda x: x.get("champion")))
            cuts = pd.DataFrame(t["cuts"])
            if not cuts.empty:
                for dim in ("phase", "family", "clock_bin", "event_window"):
                    sub = cuts[cuts["dim"] == dim]
                    if sub.empty:
                        continue
                    piv = sub.pivot_table(index="value", columns="pipeline", values="match_wape", aggfunc="first")
                    items = []
                    for v, row in piv.iterrows():
                        items.append({"value": v, **{c: row[c] for c in piv.columns}})
                    cols = [("value", dim, "text")] + [(c, c + " match WAPE", "pct") for c in piv.columns]
                    sec.append("<h3>by {}</h3>".format(H.esc(dim)) + H.table(items, cols))
        fgs = r.get("feature_groups") or {}
        if fgs:
            sec.append("<h2>2. Feature hypotheses (drop one group, refit, see what it was worth)</h2>")
            for fg in fgs.values():
                sec.append("<h3>{} {}</h3>".format(H.esc(fg["algo"]), H.esc(fg["response"])))
                sec.append(H.bars([(g["group"], g["worth_pct"]) for g in fg["groups"]], title="validation deviance "
                                  "lost when the group is removed (higher = the group matters)", kind="pct2"))
                sec.append(H.table(fg["groups"], [("group", "group", "text"), ("hypotheses", "tests", "text"),
                                                  ("features", "features", "int"), ("worth_pct", "worth", "pct2"),
                                                  ("verdict", "verdict", "text")]))
                if fg["signs"]:
                    sec.append(H.table(fg["signs"], [("feature", "feature", "text"), ("hypothesis", "H", "text"),
                                                     ("expected", "expected sign", "text"),
                                                     ("coefficient", "coef", "num"), ("agrees", "agrees", "text")]))
            first = next(iter(fgs.values()))
            sec.append("<ul>" + "".join("<li><b>{}</b> {}</li>".format(k, H.esc(v))
                                        for k, v in first["hypotheses"].items()) + "</ul>")
        tp = r.get("trueprob")
        if tp:
            lb = tp["leaderboard"]
            base = next((x for x in lb if x["method"] == "raw:hkjc_true"), {})
            champ = next((x for x in lb if x["champion"]), base)
            verdicts.append(H.verdict("True probability: <b>{}</b> log-loss {} vs 1/true odds {}; calibration slope "
                                      "{} vs {} (1 = calibrated, below 1 = over-confident).".format(
                                          H.esc(champ["method"]), H.fmt(champ.get("log_loss"), "p"),
                                          H.fmt(base.get("log_loss"), "p"), H.fmt(champ.get("slope")),
                                          H.fmt(base.get("slope"))),
                                      "good" if (champ.get("log_loss") or 9) <= (base.get("log_loss") or 0) else "warn"))
            sec.append("<h2>3. True probability</h2><p class='muted'>{:,} settled selections; differences below ~{:.3f} "
                       "in ECE are noise.</p>".format(tp["selections"], tp["noise_floor"]))
            sec.append(H.table(lb, [("method", "method", "text"), ("log_loss", "log-loss", "p"), ("brier", "Brier", "p"),
                                    ("ece", "ECE", "p"), ("slope", "slope", "num"), ("intercept", "intercept", "num"),
                                    ("expected_margin", "expected margin", "pct2"),
                                    ("realised_margin", "realised margin", "pct2")],
                               highlight=lambda x: x.get("champion")))
            sec.append(H.reliability(tp["curves"], title="reliability: predicted (x) vs realised (y)"))
        op = r.get("optimizer")
        if op and op.get("buckets"):
            verdicts.append(H.verdict("Optimiser: expected margin {} -> {} of {} forecast turnover ({:+.2%}); better on "
                                      "{} day(s), worse on {}.".format(
                                          H.fmt(op["egm_board"]), H.fmt(op["egm_star"]), H.fmt(op["turnover"]),
                                          op["lift_pct"], op["days_better"], op["days_worse"]),
                                      "good" if op["lift_pct"] > 0 else "warn"))
            sec.append("<h2>4. Theta optimiser (demand {}, belief {})</h2>".format(H.esc(op["demand"]), H.esc(op["belief"])))
            sec.append(H.table([op], [("buckets", "match-buckets", "int"), ("solved", "solved", "int"),
                                      ("skipped_low_demand", "skipped (low demand)", "int"),
                                      ("kept_board", "kept board", "int"), ("lift_pct", "lift", "pct2"),
                                      ("lift_stage1_pct", "of which TG/SUP", "pct2"),
                                      ("lift_stage2_pct", "of which weightings", "pct2")]))
            if op.get("weightings"):
                sec.append("<p>Weightings moved a price in {} match-bucket(s); 95% of the largest moves were within "
                           "{:.2%} of the theta* price.</p>".format(op["weightings"]["buckets_moved"],
                                                                     op["weightings"]["max_move_p95"]))
            sec.append(H.table(op["by_phase"], [("phase", "phase", "text"), ("buckets", "buckets", "int"),
                                                ("turnover", "turnover", "int"), ("lift_pct", "lift", "pct2")]))
            sec.append(H.table(op["by_pool"], [("pool", "pool", "text"), ("turnover", "turnover", "int"),
                                               ("lift_pct", "lift", "pct2")]))
            sec.append(H.table([{"dim": k, **v} for k, v in op["theta_moves"].items()],
                               [("dim", "theta move", "text"), ("mean", "mean", "num"), ("mae", "mean |move|", "num"),
                                ("p95", "p95 |move|", "num")]))
            sec.append("<p>Guards that bound the answer: {}</p>".format(H.esc(op.get("binding"))))
        rp = r.get("replication")
        if rp:
            sec.append("<h2>5. Pricer replication (HKJC theta through our pricer vs the posted board)</h2>")
            sec.append("<p>Best in-play convention per pool: {}</p>".format(H.esc(rp["best_in_play"])))
            sec.append(H.table(rp["rows"], [("pool", "pool", "text"), ("phase", "phase", "text"),
                                            ("convention", "convention", "text"), ("n", "rows", "int"),
                                            ("mae_prob", "mean |p diff|", "p"), ("p90_prob", "p90", "p")]))
        meta = r.get("meta") or {}
        return H.page("Algo E backtest", "generated {} - turnover model {} - probability model {}".format(
            meta.get("generated", ""), meta.get("turnover_model"), meta.get("probability_model")),
            ["<h2>Verdict</h2>"] + verdicts + sec)
