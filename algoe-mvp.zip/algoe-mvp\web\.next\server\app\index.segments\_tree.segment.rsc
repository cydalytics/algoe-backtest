:HL["/_next/static/chunks/2o6hjhkmp4txu.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"Yo0wh_y8bdCDOj0pB1rrG"}
