"""
Step 04 - train the turnover forecaster

Splits the window by calendar day (train | val | test, never random), fits
every configured model for every response (GLM / GAM / GBM / NN x match_total,
pool_share, selection_share, selection_turnover), composes the pipelines
(direct, three-stage), chooses the champion and its blend toward last 5
minutes on the validation days, scores everything once on the test days, and
saves a versioned bundle. It is promoted only if it beats last 5 minutes and
the current champion on the same validation days.

    python scripts/s04_train_turnover.py --start 2026-07-01 --end 2026-09-15
    python scripts/s04_train_turnover.py --series           + walk-forward series for the workbench
    python scripts/s04_train_turnover.py --serving-refit    refit the champion on the newest days

AlgoE_Work/runs/<stamp>_train-turnover/leaderboard.csv has every pipeline.
Same as: python -m algoe train-turnover
"""
from _algoe import run

if __name__ == "__main__":
    run("train-turnover")
