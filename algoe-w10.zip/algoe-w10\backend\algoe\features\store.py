"""
Feature Store

``prepare_day`` is the expensive part of every experiment, and it depends
only on the panel and the feature settings - never on which model is being
tried. So each day's DayData is built once and kept:

    <work>/features/<key>/<YYYY-MM-DD>.{sel,match,pool}.parquet

``key`` hashes the panel cache space, the feature settings and
FEATURE_VERSION. Change any of them and a new folder is used; nothing stale
is ever read back.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      FEATURE_VERSION 4 (odds age, FH after half time, goal pulse, midnight);
                5 (a pool is forecastable only while open at the bucket start); 6 (probabilities
                cached at float64)
"""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from ..core.io import stable_hash, write_parquet
from ..core.logging import get_logger
from .engineer import DayData, FeatureEngineer

logger = get_logger(__name__)

# Bump when engineer.py changes a column or a number.
FEATURE_VERSION = 6


class FeatureStore:
    def __init__(self, settings, panel, engineer: FeatureEngineer, enabled: bool = True):
        self.settings = settings
        self.panel = panel
        self.engineer = engineer
        self.enabled = enabled
        self.key = stable_hash({"v": FEATURE_VERSION, "space": getattr(panel.cache, "space", "live"),
                                "features": asdict(settings.features)})
        self.root = Path(settings.paths.features) / self.key
        self._memo: dict = {}

    def _paths(self, day):
        stem = "{:%Y-%m-%d}".format(pd.Timestamp(day))
        return {k: self.root / "{}.{}.parquet".format(stem, k) for k in ("sel", "match", "pool")}

    def get(self, day, keep_in_memory: bool = False) -> DayData:
        day = pd.Timestamp(day).normalize()
        if day in self._memo:
            return self._memo[day]
        paths = self._paths(day)
        if self.enabled and all(p.exists() for p in paths.values()):
            dd = DayData(day, *(pd.read_parquet(paths[k]) for k in ("sel", "match", "pool")))
        else:
            panel = self.panel.load_day(day)
            if panel is None:
                dd = DayData(day, pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
            else:
                dd = self.engineer.prepare_day(panel, self.panel.previous_tail(day), self.panel.events_for(day),
                                               self.panel.market_for(day), day=day)
            if self.enabled and not dd.empty:
                for k in ("sel", "match", "pool"):
                    write_parquet(_compact(getattr(dd, k)), paths[k])
        if keep_in_memory:
            self._memo[day] = dd
        return dd

    def has(self, day) -> bool:
        return all(p.exists() for p in self._paths(day).values())


def _compact(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    for c in out.columns:
        # Probabilities stay float64: the belief models read their logits, and float32 rounding near
        # 0 or 1 moves a logit by ~1e-4 - a gap between training (cached) and serving (fresh).
        if pd.api.types.is_float_dtype(out[c]) and c not in ("y", "turnover", "pool_y", "exposure", "last5") \
                and not c.startswith("p_"):
            out[c] = out[c].astype("float32")
        elif out[c].dtype == object:
            out[c] = out[c].astype("string")
    return out
