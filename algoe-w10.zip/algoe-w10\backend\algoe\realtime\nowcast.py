"""
Bucket Nowcaster

Between two 5-minute sweeps the desk still needs to know how much money is
coming for the rest of the bucket, because that is the money the price it
posts NOW will be struck at. The sweep gave a forecast F for the whole
bucket; e minutes in, x has already arrived. Money arrives as a Poisson
stream whose rate is uncertain; with a Gamma prior worth ``m0`` minutes of
watching at the forecast rate, the posterior rate is

    rate = (F / 5 * m0 + x) / (m0 + e)          money per minute
    remaining = rate * (5 - e)

``m0`` large trusts the model, small trusts what is arriving. At e = 0 the
answer is exactly F; with F = 0 it is whatever the stream shows. The same
update is run at match level (many tickets, stable) and at selection level
(sparse); selections are then scaled so they add up to the match's remaining
money, which borrows the match's evidence for thin selections.

``hot`` = rate / (F / 5) is how much faster than forecast the money is
coming. It carries into the next bucket's forecast damped by
``carry`` (0 = ignore, 1 = full), since a surge after a goal fades.

Money comes in tickets, not as a smooth stream: one HK$1M ticket a minute
into a bucket forecast at HK$50k would otherwise read as a rate of HK$340k a
minute and promise HK$1.4M more. The posterior rate is therefore capped at
``max_hot`` x the forecast rate (where there is a forecast), so a single
ticket can raise the rest-of-bucket expectation at most ``max_hot``-fold and
the next bucket at most ``max_hot ** carry``-fold.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      max_hot: a single large ticket is not a rate
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd


@dataclass
class Nowcast:
    remaining: np.ndarray          # expected money for the rest of the bucket, per selection
    next_bucket: np.ndarray        # next bucket's forecast, adjusted by how hot this one is
    hot: np.ndarray                # posterior rate / forecast rate, per selection
    match_hot: np.ndarray          # the same at match level (aligned to rows)
    elapsed: float


class BucketNowcaster:
    def __init__(self, prior_minutes: float = 2.0, bucket_minutes: float = 5.0, carry: float = 0.5,
                 max_hot: float = 4.0):
        self.m0 = max(float(prior_minutes), 1e-6)
        self.T = float(bucket_minutes)
        self.carry = float(carry)
        self.max_hot = float(max_hot)      # <= 0: no cap

    def rate(self, forecast, observed, elapsed: float) -> np.ndarray:
        F = np.clip(np.asarray(forecast, dtype="float64"), 0, None)
        x = np.clip(np.asarray(observed, dtype="float64"), 0, None)
        e = float(np.clip(elapsed, 0.0, self.T))
        r = (F / self.T * self.m0 + x) / (self.m0 + e)
        if self.max_hot > 0:
            r = np.where(F > 0, np.minimum(r, self.max_hot * F / self.T), r)
        return r

    def update(self, forecast, observed, elapsed: float, match_key=None,
               next_forecast: Optional[np.ndarray] = None) -> Nowcast:
        F = np.clip(np.asarray(forecast, dtype="float64"), 0, None)
        x = np.clip(np.asarray(observed, dtype="float64"), 0, None)
        e = float(np.clip(elapsed, 0.0, self.T))
        left = self.T - e
        sel_rate = self.rate(F, x, e)
        base_rate = F / self.T
        hot = np.where(base_rate > 0, sel_rate / np.maximum(base_rate, 1e-12), 1.0)
        remaining = sel_rate * left
        match_hot = np.ones_like(F)
        if match_key is not None and len(F):
            g = pd.DataFrame({"k": np.asarray(match_key), "F": F, "x": x, "r": remaining})
            tot = g.groupby("k", sort=False)[["F", "x", "r"]].transform("sum")
            m_rate = self.rate(tot["F"].to_numpy(), tot["x"].to_numpy(), e)
            m_left = m_rate * left
            scale = np.where(tot["r"].to_numpy() > 0, m_left / np.maximum(tot["r"].to_numpy(), 1e-12), 1.0)
            remaining = remaining * scale
            m_base = tot["F"].to_numpy() / self.T
            match_hot = np.where(m_base > 0, m_rate / np.maximum(m_base, 1e-12), 1.0)
        nxt = F if next_forecast is None else np.clip(np.asarray(next_forecast, dtype="float64"), 0, None)
        next_adj = nxt * np.power(np.clip(match_hot, 0.05, 20.0), self.carry)
        return Nowcast(remaining=remaining, next_bucket=next_adj, hot=hot, match_hot=match_hot, elapsed=e)

    def calibrate_prior(self, forecast, observed_partial, observed_full, elapsed: float,
                        grid=(0.25, 0.5, 1, 2, 3, 5, 8, 12)) -> dict:
        """Pick m0 on history: which prior best predicts the rest of the bucket from its start."""
        F = np.clip(np.asarray(forecast, dtype="float64"), 0, None)
        xp = np.clip(np.asarray(observed_partial, dtype="float64"), 0, None)
        rest = np.clip(np.asarray(observed_full, dtype="float64") - xp, 0, None)
        scores = {}
        keep_m0 = self.m0
        for m0 in grid:
            self.m0 = float(m0)
            pred = self.rate(F, xp, elapsed) * (self.T - elapsed)
            mu = np.maximum(pred, 1.0)
            scores[m0] = float(np.mean(2 * (np.where(rest > 0, rest * np.log(np.maximum(rest, 1e-12) / mu), 0) - (rest - mu))))
        best = min(scores, key=scores.get)
        self.m0 = float(best) if np.isfinite(scores[best]) else keep_m0
        return {"prior_minutes": self.m0, "deviance_by_prior": scores}
