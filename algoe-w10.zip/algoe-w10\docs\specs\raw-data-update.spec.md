# Spec - keep Raw_Data current

W12, 2026-10-26. Folder: `BiWeekly Meetings/W12_2026-10-27_true-odds`.

## 1. Problem

Raw_Data is written by hand with `hkjc_code/1 Data Extraction.ipynb`. Its last run ends on
2026-10-01, so every backtest stops there.

- Six tables are one file per month, `<prefix>_<YYYY-MM>_<next YYYY-MM>.parquet`, queried
  `between 'YYYY-MM-01' and 'next-01'`: HKJC_Odds, Market_Odds, HKJC_Parameters,
  Match_Information, Match_Events, Pool_Details. Match_Investments is one file per day,
  `match_investments_<D>_<D+1>.parquet`, by pool conclude date.
- The loader (`src/backtest/parquet/loader.py`) reads every `*.parquet` in a table folder. A window
  extracted again must overwrite the same file name, and a file being written must not end in
  `.parquet`.
- The per-day caches record a day as built and never look at the raw files again: the panel cache
  (`algoe_panel_cache/<space>/manifest.json`, every space) and the W10 feature store
  (`AlgoE_Work/features/<key>/<day>.*.parquet`, every key). A day extracted again keeps its old
  cache unless it is dropped.
- The workbench's default window is fixed in `src/backtest/parquet/config.py`
  (2026-07-01 .. 2026-09-15), so the page opens on an old cut-off even when the data is newer.

## 2. Outcome

`python -m algoe update-data` (`algoe-update-data.bat`) brings Raw_Data up to now with the
notebook's own queries, drops the cached days it read again, and builds those days' panel and
features. It runs every morning from Task Scheduler and, when the data is older than yesterday,
from `start.bat` in its own window. The workbench opens on a window that ends on the newest day on
disk. `--report` also refreshes the W10 backtest report on the honest champion's out-of-sample
days through yesterday.

## 3. Non-goals

- No change to the notebook's SQL: it is copied as it is; only the window and the file are
  parameters.
- No change to the loader, the panel, the features or the models.
- No de-duplication of rows the notebook's `between` puts into two neighbouring files.

## 4. Rules

| Rule | Detail |
|------|--------|
| Newest day N | Per table: the day of the newest timestamp in its files (parquet statistics; the file name's end if there are none). |
| Restart R | min over tables of N, minus one day (newest 2026-10-01 -> restart 2026-09-30). `--from` overrides. A table with no files stops the run unless `--from` is given. A table more than 3 days behind the others is reported: it holds R back. |
| Monthly tables | Every month from month(R) to this month, each extracted whole (R = 2026-09-30 -> September and October). |
| Match_Investments | Every day from R to today. |
| One file | Query -> `<name>.parquet.tmp` in the same folder -> replace `<name>.parquet`. A failed query or write keeps the old file. |
| Foreign files | A file that is not one of the run's files and may overlap a window (by its name, its rows, or unreadable) stops the run: its rows would be read twice. `--allow-foreign` runs anyway. |
| Caches | After the extraction, days >= R are dropped from every panel space (manifest first) and feature store key; days before R are kept. A file that cannot be deleted is reported. Then days R .. yesterday are built (`--no-build` skips). |
| Status | `Raw_Data/_algoe_update.json`: running while a run lasts; at the end started, finished, ok (files, caches and build all done), error, restart, files written with rows, newest per table, newest_day = min over tables. |
| Lock | `Raw_Data/_algoe_update.lock` holds its owner's token for the whole run (files, caches, build, report), touched every minute; one untouched for 15 minutes is taken over, and only its owner deletes it. `--wait MINUTES` waits for a running update (the nightly waits 120). |
| Report | `--report` runs only when every file was extracted. |
| Stale | No status, a run that did not finish, a failed last run, or newest_day before yesterday. |

## 5. Acceptance criteria

| # | Criterion | Proof |
|---|-----------|-------|
| AC1 | Files ending on 2026-10-01 give restart 2026-09-30, months 2026-09 .. this month, investment days 2026-09-30 .. today. | unit test on fake files |
| AC2 | Each table's SQL is the notebook's, with the window in the notebook's format. | unit test against the notebook's own text, whitespace aside |
| AC3 | A failing query, write or replace leaves the old file byte for byte and no `.parquet` partial. | unit test |
| AC4 | Days >= R leave every panel space manifest and every feature key; earlier days stay. | unit test |
| AC5 | A second run while locked stops with a message; a stale lock is taken over. | unit test |
| AC6 | The status file is written on success and on failure; `start.ps1` starts the update in its own window only when stale and not locked. | unit test on the status; manual check of start.ps1 |
| AC7 | `algoe-schedule-update.bat` creates or replaces a daily task for this user, no admin rights. | manual on the office box (not registered on the dev laptop: it changes the machine) |
| AC8 | The nightly runs update-data first; a failed update does not stop it. | unit test on the step list |
| AC9 | The workbench defaults end on the newest complete day on disk. | unit test on /parquet/defaults |
| AC10 | `--report` runs `backtest --days <first test day>:<yesterday>` with honest champions and skips with a message when a champion is a serving refit. | unit test on the plan |

## 6. Interfaces

- `python -m algoe update-data [--from YYYY-MM-DD] [--dry-run] [--no-build] [--report] [--unattended]`
- `deploy/algoe-update-data.bat` (pauses at the end unless `--unattended`),
  `deploy/algoe-schedule-update.bat [HH:MM]` (default 06:00, before the nightly).
- `src/hkjc/history_queries.py`: one function per table, `sql(start, end) -> str`.
- `algoe/data/raw_update.py`: `plan(data_dir, now, start=None)`, `run(settings, source, plan)`,
  `read_status(data_dir)`, `is_stale(status, today)`.
- `src/backtest/parquet/cache.py`: `drop_days_from(root, first_day)`;
  `algoe/features/store.py`: `drop_days_from(features_root, first_day)`.

## 7. Edge cases

- A table folder with no files: reported, extracted from R like the others.
- A month or day with no rows: an empty file is not written; the old file, if any, is kept.
- Match_Information and Pool_Details hold future kick-offs: they never set N lower than the
  others, and their months are extracted again with the others.
- The investments database per month follows the notebook's `db_buckets`; later months use
  `fbis1_fo_as_db` / `fbis1_fo_cs_db`.
- The run is killed half way: the status says running and the lock stops being touched; 15
  minutes later the next run (or start.bat) takes it over.
- The scheduled update and the nightly start together: the nightly's update waits for the other.

## 8. Risks

- Time on the office SQL: a whole month of odds is extracted again every day. The first run's
  timings are in the status file and the log; measure before tightening the schedule.
- `os.replace` on the S: share: atomic on SMB within one folder; unverified on the office box.
- Group policy may block `schtasks`; then `start.bat` and the manual bat still update.
