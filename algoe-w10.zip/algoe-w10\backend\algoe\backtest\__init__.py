"""Backtester: every lever compared on the same held-out days."""
