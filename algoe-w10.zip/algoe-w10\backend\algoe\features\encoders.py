"""
Hierarchical Encoders

A category the model has seen a thousand times should speak for itself; one
it has seen five times should mostly borrow from its parent; one it has
never seen should BE its parent. Empirical-Bayes shrinkage does exactly that:

    level(c) = (n_c * mean_c + k * level(parent(c))) / (n_c + k)

``k`` is how many observations it takes before a category moves halfway
from its parent (settings.features.league_prior / pool_prior).

    league    parent: global                      (new league -> 0, flag = 0)
    pool      parent: family|phase -> global      (new bet type -> its family)
    team      parent: the match's league -> global (new team -> its league; home and away alike)

Encoders are fitted on days before the first validation day only - the
training days and every earlier cached day within
features.encoder_history_days, evidence halving every
encoder_half_life_days - and saved inside the model artifact, so validation /
test / live rows are encoded with exactly the table the model learned with.
Each refit (the nightly) relearns them, so a new league has its own level
from the first refit after it plays.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Weighted evidence (time decay); league level in market-index units
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class LevelEncoder:
    key: str
    parents: Tuple[str, ...] = ()
    prior: float = 50.0
    global_mean: float = 0.0
    tables: Dict[str, Dict[str, float]] = field(default_factory=dict)
    counts: Dict[str, float] = field(default_factory=dict)

    def fit(self, frame: pd.DataFrame, target: str, weight: Optional[str] = None) -> "LevelEncoder":
        y = pd.to_numeric(frame[target], errors="coerce")
        w = pd.to_numeric(frame[weight], errors="coerce").fillna(0.0) if weight else pd.Series(1.0, index=frame.index)
        ok = y.notna() & (w > 0)
        f = frame.loc[ok].copy()
        f["_y"], f["_w"] = y[ok] * w[ok], w[ok]
        self.global_mean = float(f["_y"].sum() / max(f["_w"].sum(), 1e-12)) if len(f) else 0.0
        chain = list(self.parents)[::-1] + [self.key]     # most general first
        parent_level = pd.Series(self.global_mean, index=f.index)
        self.tables = {}
        for i, col in enumerate(chain):
            cat = f[col].astype("string").fillna("unknown")
            g = f.groupby(cat, observed=True)[["_y", "_w"]].sum()
            prior_val = parent_level.groupby(cat, observed=True).mean()
            level = (g["_y"] + self.prior * prior_val) / (g["_w"] + self.prior)
            self.tables[col] = {str(k): float(v) for k, v in level.items()}
            if col == self.key:
                self.counts = {str(k): float(v) for k, v in g["_w"].items()}
            parent_level = cat.map(self.tables[col]).astype("float64")
        return self

    def transform(self, frame: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """(level - global mean, known flag). Unknown categories fall to the nearest known parent."""
        out = np.full(len(frame), self.global_mean, dtype="float64")
        known = np.zeros(len(frame), dtype="float64")
        chain = list(self.parents)[::-1] + [self.key]
        for col in chain:
            if col not in frame.columns or col not in self.tables:
                continue
            vals = frame[col].astype("string").fillna("unknown").map(self.tables[col])
            hit = vals.notna().to_numpy()
            out = np.where(hit, vals.to_numpy(dtype="float64", na_value=np.nan), out)
            if col == self.key:
                known = hit.astype("float64")
        return out - self.global_mean, known

    def to_state(self) -> dict:
        return {"key": self.key, "parents": list(self.parents), "prior": self.prior,
                "global_mean": self.global_mean, "tables": self.tables, "counts": self.counts}

    @classmethod
    def from_state(cls, s: dict) -> "LevelEncoder":
        return cls(key=s["key"], parents=tuple(s.get("parents") or ()), prior=float(s["prior"]),
                   global_mean=float(s["global_mean"]), tables=dict(s["tables"]),
                   counts=dict(s.get("counts") or {}))


@dataclass
class EncoderState:
    """All encoders a model bundle carries."""
    league: Optional[LevelEncoder] = None
    pool: Optional[LevelEncoder] = None
    team: Optional[LevelEncoder] = None

    @property
    def fitted(self) -> bool:
        return self.league is not None or self.pool is not None

    def to_state(self) -> dict:
        return {"league": self.league.to_state() if self.league else None,
                "pool": self.pool.to_state() if self.pool else None,
                "team": self.team.to_state() if self.team else None}

    @classmethod
    def from_state(cls, s: Optional[dict]) -> "EncoderState":
        s = s or {}
        return cls(league=LevelEncoder.from_state(s["league"]) if s.get("league") else None,
                   pool=LevelEncoder.from_state(s["pool"]) if s.get("pool") else None,
                   team=LevelEncoder.from_state(s["team"]) if s.get("team") else None)


def fit_encoders(match_frames: Sequence[pd.DataFrame], pool_frames: Sequence[pd.DataFrame],
                 league_prior: float, pool_prior: float, team_prior: Optional[float] = None) -> EncoderState:
    """Fit on training days' match-level and pool-level raw frames."""
    state = EncoderState()
    m = pd.concat([f for f in match_frames if f is not None and not f.empty], ignore_index=True) \
        if match_frames else pd.DataFrame()
    if not m.empty and "league_code" in m.columns:
        # money in market-index units, so a league's level does not drift with the market's size
        idx = pd.to_numeric(m["market_index"], errors="coerce").fillna(1.0).to_numpy(dtype="float64") \
            if "market_index" in m.columns else 1.0
        m = m.assign(_t=np.log1p(np.clip(m["y"].to_numpy(dtype="float64") / idx, 0, None)))
        state.league = LevelEncoder("league_code", (), league_prior).fit(m, "_t", "_w" if "_w" in m.columns else None)
        logger.info("league encoder: %d league(s), global log level %.3f",
                    len(state.league.tables.get("league_code", {})), state.league.global_mean)
        if team_prior is not None and {"home_name", "away_name"} <= set(m.columns):
            # every match counts for both its teams, each shrunk to the league it was played in
            cols = ["league_code", "_t"] + (["_w"] if "_w" in m.columns else [])
            long = pd.concat([m[cols].assign(team=m["home_name"].astype("string").fillna("unknown")),
                              m[cols].assign(team=m["away_name"].astype("string").fillna("unknown"))],
                             ignore_index=True)
            long = long[long["team"] != "unknown"]
            if not long.empty:
                state.team = LevelEncoder("team", ("league_code",), team_prior).fit(
                    long, "_t", "_w" if "_w" in long.columns else None)
                logger.info("team encoder: %d team(s)", len(state.team.tables.get("team", {})))
    p = pd.concat([f for f in pool_frames if f is not None and not f.empty], ignore_index=True) \
        if pool_frames else pd.DataFrame()
    if not p.empty and "exposure" in p.columns:
        ex = p["exposure"].to_numpy(dtype="float64")
        ok = ex > 0
        p = p.loc[ok].copy()
        p["_t"] = np.log(np.clip(p["y"].to_numpy(dtype="float64") / ex[ok], 1e-4, 1.0))
        state.pool = LevelEncoder("pool_key", ("family_phase",), pool_prior).fit(p, "_t", "_w" if "_w" in p.columns else None)
        logger.info("pool encoder: %d pool key(s), %d family key(s)",
                    len(state.pool.tables.get("pool_key", {})), len(state.pool.tables.get("family_phase", {})))
    return state
