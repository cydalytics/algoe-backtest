"""
Walk-forward scores

The backtest report scores the champions on their held-out test days and then stops. Every morning, before
the nightly refits them, score-days scores each new day for the champion that served it: a day after the
champion's fit window, so the model never saw it - an honest score. One file a day,
AlgoE_Work/reports/daily/<day>.json, holds the day's rows in the shape of the Backtest tab's day chart
(mixstudy.Compare: last 5 minutes and the model on every row of the day), so the tab carries the chart on
past the report. reports/daily/_nightly.json is the last nightly run, for the desk's data chip.

Yesterday's money is provisional when it is scored (late rows may follow); when its verdict settles the day
is marked suspect, or scored again by the same model if its file was written again.

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      fit_end counts a serving refit's blend days; revisit(): provisional days once they settle
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

NIGHTLY = "_nightly.json"
BASE, MODEL = "last 5 min", "model"


def daily_dir(settings) -> Path:
    return Path(settings.paths.reports) / "daily"


def fit_end(model) -> Optional[pd.Timestamp]:
    """The last day a model saw: its serving refit's fit window and the days it blended and stopped early on,
    else its training and validation days. None when it cannot say (a serving refit without its window may
    have seen any day)."""
    md = getattr(model, "metadata", None) or {}
    sf = md.get("serving_fit")
    if sf:
        # turnover: {"fit": [first, last, n], "blend_days": [...]}; probability: {"days": [first, last, n]}
        window = (sf.get("fit") or sf.get("days")) if isinstance(sf, dict) else None
        if not (window and len(window) >= 2 and window[1]):
            return None
        return max([pd.Timestamp(window[1]).normalize()]
                   + [pd.Timestamp(d).normalize() for d in sf.get("blend_days") or []])
    split = md.get("split") or {}
    seen = [pd.Timestamp(d) for k in ("train", "val") for d in split.get(k) or []]
    return max(seen).normalize() if seen else None


def first_unseen(models: Iterable) -> Optional[pd.Timestamp]:
    """The first day none of ``models`` saw; None when one of them says nothing of its fit."""
    ends = [fit_end(m) for m in models if m is not None]
    if not ends or any(e is None for e in ends):
        return None
    return max(ends) + pd.Timedelta(days=1)


def score_day(forecaster, store, day) -> Optional[dict]:
    """Last 5 minutes and the model on every row of ``day`` (mixstudy.Compare, the day chart's rows)."""
    from ..backtest.mixstudy import Compare, selection_frame
    dd = store.get(day)
    if dd.empty:
        return None
    full = selection_frame(dd, forecaster.predict_selection_turnover(dd), forecastable_only=False)
    if full.empty:
        return None
    label = str(pd.Timestamp(day).date())
    cmp = Compare()
    cmp.add(full, {"day": np.full(len(full), label, dtype=object)},
            {BASE: full["last5"].to_numpy(dtype="float64"), MODEL: full["model"].to_numpy(dtype="float64")})
    return {"day": label, "compare": cmp.rows()}


def scored(folder: Path) -> Dict[str, dict]:
    """{day: its file} for every day scored so far."""
    out = {}
    for f in sorted(Path(folder).glob("????-??-??.json")) if Path(folder).is_dir() else []:
        try:
            out[f.stem] = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
    return out


def to_score(folder: Path, first: pd.Timestamp, last: pd.Timestamp, quality: Dict[str, dict]) -> List[pd.Timestamp]:
    """The days from ``first`` to ``last`` not scored yet whose money is not suspect."""
    done = set(scored(folder))
    out = []
    for d in pd.date_range(pd.Timestamp(first).normalize(), pd.Timestamp(last).normalize(), freq="D"):
        key = str(d.date())
        if key not in done and (quality.get(key) or {}).get("verdict") != "suspect":
            out.append(d)
    return out


def revisit(folder: Path, quality: Dict[str, dict]) -> Dict[str, str]:
    """Days scored while their money was provisional whose verdict has settled since: {day: what to do}. A
    suspect day is "suspect" (marked, and left out of the counts); an ok day whose file was written again
    after its score is "rescore" (by the model that scored it: it is still unseen to that one); an ok day
    as it was is "settled"."""
    out = {}
    for day, doc in scored(folder).items():
        if doc.get("verdict") != "provisional":
            continue
        q = quality.get(day) or {}
        if q.get("verdict") == "suspect":
            out[day] = "suspect"
        elif q.get("verdict") == "ok":
            written = pd.to_datetime(q.get("written_at"), errors="coerce")
            at = pd.to_datetime(doc.get("scored_at"), errors="coerce")
            out[day] = "rescore" if not pd.isna(written) and (pd.isna(at) or written > at) else "settled"
    return out


def write_json_atomic(doc: dict, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(doc, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)
    return path


def better(doc: dict, metric: str = "deviance") -> Optional[bool]:
    """Whether the model beat last 5 minutes on the day (lower is better); None without both."""
    rows = {r["method"]: r for r in doc.get("compare") or [] if r.get("dim") == "day"}
    a, b = (rows.get(BASE) or {}).get(metric), (rows.get(MODEL) or {}).get(metric)
    if a is None or b is None:
        return None
    return bool(b < a)


def read_nightly(folder: Path) -> Optional[dict]:
    try:
        return json.loads((Path(folder) / NIGHTLY).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
