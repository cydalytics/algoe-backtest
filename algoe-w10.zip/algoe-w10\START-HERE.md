# Algo E W12 - office box runbook

Turnover forecasting, probability calibration, the TG/SUP optimizer and the live engine, on
the offline machine. W12 puts the desk (board and cockpit) on the live engine and adds two
checks the desk's numbers depend on: `algoe-6-probe-live.bat` (the live money feed) and
`algoe-3-backtest.bat --only replication` (the first-half split), sections 4 and 6. Everything runs on CPU with no internet. The parquet, the caches and the
trained models stay beside `Raw_Data`; this folder is code only, so unzipping a newer version
over it never touches them.

```
S:\Users\Yeung\20260520 Algo E\
    Raw_Data\               the extraction output; algoe-update-data.bat keeps it current
    algoe_panel_cache\      per-day panel, shared with the W06 workbench
    Backtest_Data\          the workbench's series (train-turnover --series writes here)
    AlgoE_Work\
        features\<key>\     per-day features, one folder per feature version
        models\turnover\    every trained version + CHAMPION.json + history.jsonl
        models\probability\
        reports\            backtest_<stamp>\report.html
        monitor\            health.json, alerts.jsonl, published forecasts
        runs\               one folder per command: settings.json + summary.json
        logs\               <command>-<stamp>.log (text) and .jsonl (structured)
        config\pools.json   confirmations for pool codes placed by rule
        config\holidays.txt HK holidays after 2027, one ISO date per line
```

## 0. What the machine needs

The Python the extraction notebooks use, with `pandas numpy scipy pyarrow` (and `pyodbc` for
the SQL feed). Model libraries - install all five so every pipeline competes:

| Package | Enables | Without it |
|---------|---------|------------|
| `lightgbm` | `gbm`, `glm_gbm` | scikit-learn's GBM stands in (Poisson loss only) |
| `scikit-learn` | the GBM fallback | GBM pipelines are skipped if lightgbm is missing too |
| `xgboost` | `xgb`, `glm_xgb` | the XGBoost pipelines are skipped |
| `catboost` | `cat`, `glm_cat` | the CatBoost pipelines are skipped |
| `torch` (CPU) | `nn`, `glm_nn` | the NN pipelines are skipped (`skipped: nn_* backend not installed`) |

The three tree libraries are the same family and usually within a few per cent of each other once
tuned; which wins on this data is for the leaderboard to say. The selftest passes with any subset,
down to scikit-learn alone.

`python scripts\preflight.py --skip-tick` (from `backend\`) lists what the box has and the wheel
tag its Python needs (for example `cp311-win_amd64`). On a connected Windows machine with the
same Python minor version:

    pip download -d vendor -r backend\requirements-models.txt --only-binary=:all: --platform win_amd64 --python-version 3.11

then copy `vendor\` beside `backend\` on the box and:

    pip install --no-index --find-links vendor -r backend\requirements-models.txt

PyPI's Windows `torch` wheel is the CPU build (about 200 MB); no GPU is needed. Nothing fails
without these: the pipelines a missing library would run are skipped and logged.

## 1. First time

| Step | Run | You want |
|------|-----|----------|
| 1 | `algoe-0-selftest.bat` | `12 PASS, 0 WARN, 0 FAIL` (a WARN on probability is fine). A few minutes the first time (longer with torch: the NN pipelines train too). |
| 2 | `algoe-1-check-data.bat` (drag `Raw_Data` onto it) | No FAIL. Read the pool-code table: codes marked `known False` were placed by rule - confirm them in `config\pools.json` (section 5). |
| 3 | `algoe-2-train.bat --start 2024-06-01 --end 2026-09-14 --workers 3 --set window.val_start=2025-07-01 --set window.test_start=2026-07-01` | Panel, features, turnover, probability, then the backtest report, split by date (section 2a). Start from the "data complete from" month and end on the day check-data's `window end` line gives. The first panel build is the slow part (section 2a); later runs only build new days. |
| 4 | open the newest `AlgoE_Work\reports\backtest_*\report.html` | Turnover champion below last-5-minutes deviance on the test days, days better > days worse; calibrated belief at or below raw log-loss; optimizer lift >= 0 with days better > worse. |
| 5 | `algoe-parity.bat --at "2026-09-10 21:30" --at "2026-09-11 00:05"` | `Identical`. Any difference means the live engine would feed the model inputs it was not trained on - do not go live until it is fixed. |
| 6 | `algoe-4-live.bat --source replay --at "2026-09-10 20:00" --speed 10` | A rehearsal of a real evening from Raw_Data: the board every bucket, focus refreshes, triggers. |
| 7 | `algoe-4-live.bat` | The SQL feed. Ctrl+C stops it. |
| 8 | `algoe-6-probe-live.bat --match <id>` on a match in play | `verdict.txt` with no FAIL (section 4): the live money table means what the engine reads it as. |

Every step also runs as `python -m algoe <command>` from `backend\` (or
`python scripts\sNN_<command>.py`); `python -m algoe <command> -h` lists its options.

## 2a. Choosing the window and the split

`check-data` prints **coverage by month** over every file, and the month the data is complete
from (odds, investments, pools, matches and parameters in every month after it). HKJC parameters
(TG / SUP) begin 2024-05-07, so months before that have odds but cannot be priced or used for
theta features: train from the complete month on. Inside the window the parameters feed can
still have holes (late June 2024 lost 71-100% of TG in the office data): build-features writes
each day's `theta_coverage` (share of match-buckets with HKJC's TG) to
`runs\<stamp>_build-features\features.csv` and warns about days under 50%. Matches without TG /
SUP (corner pools without CTG / CSUP) are forecast but neither priced from theta nor optimised.

Split by date, never by counts, for a long window:

    --set window.val_start=2025-07-01 --set window.test_start=2026-07-01

means train [start, 2025-07-01), validation [2025-07-01, 2026-07-01), test [2026-07-01, end].
A whole year of validation covers every season and tournament once, so the model choice does not
ride on one month; the price is that the test is scored by a model whose training ended a year
earlier. Accept the result on that honest score, then deploy the refit
(`train-turnover --serving-refit`, or the nightly), which adds the validation year to the fit.

What keeps it free of look-ahead:

- train < validation < test by calendar day; no day is in two roles; nothing is shuffled.
- every input at bucket T comes from before T (start-of-bucket prices, previous-bucket money,
  events and parameters strictly before T); `parity` rebuilds a bucket the way live serves it,
  from data cut at T, and proves the inputs are identical.
- everything fitted from data - league and pool encodings, the models, GBM early stopping - is
  fitted on train days; validation only chooses the champion and its blend; test is scored once.
- outcomes, dividends and settlement are labels, never inputs.
- `backtest` refuses a bundle refitted for serving (its fit includes the test days).

Cost on the office box: the panel and features are built once and kept, and a stopped build resumes
where it stopped. The trial week (2026-07-01..07) took about 90 seconds a day in one process, so
2024-06..2026-09 is about 20 hours. `--workers N` builds N months at once (panel and features);
each worker holds one month of raw odds and money in memory, so pick N by RAM, not cores: note
the peak memory of python.exe in Task Manager during a one-worker build, then
N = (free RAM - 4 GB) / that peak. If memory runs short, stop it (Ctrl+C) and rerun with fewer
workers - finished months are kept. Training samples at most
`turnover.max_fit_rows` / `probability.max_fit_rows` rows per response (2 million by default).
build-panel also builds the 30 days before the window: money features are divided by the market's
size before each day (the median daily turnover of the last 28 cached days ending two days
earlier), so a growing market does not shift them, and the window's first day needs those days.
Feature version 7 (2026-10-01) changed the features, not the panel: a panel cache built with the
earlier zip is kept; the features and models are rebuilt (hours, not the panel's day). Feature
version 9 (2026-10-06) does the same. Run the same `algoe-2-train.bat` command: the panel days are
skipped, the features rebuild (the version 7 build took about 15 hours with `--workers 2`; version 9
computes more per day, so allow longer, or more workers if the RAM allows), then both models train
- 25 pipelines - and the backtest runs. It also writes one small JSON of board stats per cached day
under `algoe_panel_cache\<space>\algoe_stats` (a few minutes the first time). The 2026-10-11 zip
changes neither features nor models: unzip it, run `algoe-0-selftest.bat` (12 PASS), then
`algoe-3-backtest.bat --only events` for sections 7, 9, 10 and 11 and the live engine's
`EVENT_SHIFT.json` - nothing is rebuilt or retrained.

**Inputs that do not drift with the market.** Money features are in market-index units (above).
Counts and margins are read against what a normal board looked like over the 28 cached days ending
two days before (the market index's window): matches on the board, pools and lines per match,
lines per pool, and each bet type's usual margin and share of the money, pre-match and in play
apart. So HKJC listing more matches, more bet types or more lines, or charging a different margin
for good, moves `board_rel`, `pools_rel`, `p_margin_rel` ... only until the four weeks catch up,
never out of the range the models learned on. A cached feature day is rebuilt if the days before
it change its references. The `drift` section of the backtest shows whether this holds.

**Pools.** `panel.pools` defaults to `["@line_markets", "@three_way"]`: every goal / corner total
and handicap, the team totals (HILOH / HILOA full-time goals, FHLOH / FHLOA first-half goals,
CHLOH / CHLOA and FCHLOH / FCHLOA corners - one team's count over / under a line), plus 1X2,
chosen by what each code is, so a new line market joins by itself. Correct score, scorer and
next-goal markets are left out - they are several times the rows and nothing here prices them.
`[]` takes every pool. Adding the team totals changed what the rule selects, so the panel cache
built before 2026-10-01 (the trial week) is in an older cache space and is rebuilt once.

**True odds.** If check-data warns that HKJC_Odds has no `true_odds` (the historical extraction
reads `pool_odds_change_c`, which does not join true odds), the models learn their beliefs from
the market, Poisson-from-theta and de-margined odds, and the live engine then ignores the live
feed's true odds so its inputs match. Re-extracting history with true odds (as the real-time
notebook joins `pool_odds_true_change_h`) gives the models HKJC's own belief to learn from.

## 2. What the numbers mean

- **Turnover leaderboard** (`runs\<stamp>_train-turnover\leaderboard.csv`): one row per
  pipeline. `test_deviance` is the Poisson deviance on the held-out days - the number the
  champion is judged on; `test_match_wape` is the error on match totals, the level the
  optimizer's demand is anchored to; `dm_stat_vs_last5` below about -2 means the model is
  reliably better than last 5 minutes, day by day.
- **Turnover baselines**: `last5` is the W06 rule (last bucket's money on the same line id);
  `last5_pos` is last bucket's money in the same slot (offset from the best line, side);
  `last5_hybrid` is the line's own money, and its slot's only for a line that was not priced a
  bucket ago and took nothing of its own (a line the market has just opened). On the office test
  days (2026-07..09) `last5_pos` lost to `last5` every day (deviance 7,518 vs 5,715): money
  follows the line, not its offset, once the line has money of its own. Models are blended toward
  `last5_hybrid` (`turnover.blend_base` = `hybrid`; `line` and `position` are the other two).
- **Pipelines**: `direct:` one model of the selection's money; `three_stage:` the match's money x
  each pool's share x each selection's share; `four_stage:` the whole board's money x each match's
  share of it x pool share x selection share - matches compete for the same money, so a big match
  coming on takes its money from the others.
- **Algorithms**: `glm`, `gam`, `gbm` (LightGBM), `xgb` (XGBoost), `cat` (CatBoost), `nn` (a small
  network) and the anchored `glm_gbm` / `glm_xgb` / `glm_cat` / `glm_nn`: the tree or network fitted
  on top of the GLM's prediction. A tree predicts
  a constant past its last split, so a match bigger than any in training gets the biggest
  training value, not more (on a test world with matches 1.6-7x bigger than any seen, plain
  GBM and NN forecast 75% too little; the anchored ones were within 2-3%). Money features are
  in market-size units, so a market that grows as a whole stays inside the range; one huge
  match does not. The anchored models follow the GLM's trend in the money levels past the
  range (at most `turnover.extrapolation_cap` = 10x beyond the edge); every other input - a
  weekday, a pool count, a price - is held at the edge of what training saw.
- **Biggest matches**: `test_top1_bias` / `test_top1_wape` are the bias and error over the
  biggest 1% of matches by the day's money (the 2026 World Cup knockouts sit in July's test
  days). A large negative `test_top1_bias` is a model stopping at its biggest training value.
- **Champion**: the lowest validation deviance; if that pipeline's level is a plain tree or
  network and its anchored twin (`gbm` -> `glm_gbm`, `xgb` -> `glm_xgb` ...) is within
  `turnover.extrapolation_tolerance` (1%) on validation and its bias is no more than 2 points
  further from zero, the twin is served - the log says which and why.
- **Backtest sections 6-11** (`--only drift,events,elasticity` runs just these; `events` and `mix`
  are one pass and either name runs sections 7, 9, 10 and 11):
  *6. Drift* - each input's PSI on the test days against training (above 0.25 it has moved) and, month
  by month over validation and test, the champion's deviance as a share of last 5 minutes': flat
  means the forecast does not wear as the market and the seasons move. A PSI above 1 on the board
  counts (`p_lines_rel`, `pools_rel` ...) with a flat month table means the board's make-up changed
  (more pool types or lines on some matches) and the accuracy did not.
  *7. Goals, red cards and corners* - for each event, the last full in-play 5 minutes before it and
  the first full 5 minutes after it: the match's money after over before ('money x'), the HiLo,
  handicap, 1X2 and corner shares of the match, the Over share of HiLo and of the corner totals, the
  favourite's share of the handicap - actual, and the champion's forecast for the bucket after.
  Split by the kick-off favourite's strength, whose event it was, the clock, and the score after it.
  Rows with fewer than 30 events are in `events_by_favourite.csv` / `events_by_state.csv`;
  `events_rows.csv` has every event. This is the data's answer to "the favourite scores at 15',
  what happens to the overs".
  *8. What a margin costs* - the change in a pool's money for its main line's margin one point
  lower, by bet type and phase (double machine learning, standard error clustered by match). It is
  "identified" only when the data holds margin variation the other inputs do not explain;
  otherwise the honest answer is that history cannot say, and a controlled test of small margin
  changes is the way to find out.
  *9. Proportions* - how well each forecast gets the split that pricing uses: a match's money across
  bet types and pools, a pool's money across its selections, a bet type's money across its sides
  (Over / Under, favourite / underdog / draw). 'Misallocated' is half the sum of |actual share -
  forecast share|: the share of the money put on the wrong item, 0 = perfect. 'Log-loss' is the
  cross-entropy of the actual split under the forecast one. Compared: last 5 minutes, the usual split
  (the bet types' share over the four weeks before), the model, the model re-tuned at the event.
  *Rows that took nothing*: the selection WAPE split into error on rows that took money, money
  forecast on rows that went quiet (money last bucket, none now) and on rows dead in both - why a
  selection-level WAPE above 80% is normal for 5-minute money (a forecast of zero everywhere scores
  100%). Accuracy here and in section 10 counts every row, as the leaderboard does (a row not on the
  board at the bucket start is forecast at last 5 minutes by every pipeline), so the totals equal
  section 1's; the split is scored on the rows that were on the board.
  The same pass writes the baseline-vs-model data the desk's Backtest tab draws (`compare.csv`:
  match WAPE, selection WAPE, bias and deviance for last 5 minutes, the model and the re-tuned
  model by day, phase, clock, event window, bet type, league and what happened inside the bucket;
  `errors.csv`: how far each match-bucket was off; a match replay of the biggest matches of 12
  test days in report.json).
  *10. When an event happens inside the 5 minutes* - every bucket by what happened inside it (none,
  goal, red card, corner; pre-match apart): match WAPE, bias, deviance and split errors for last 5
  minutes, the model (made at the bucket start, blind to the event) and the model re-tuned from the
  event's minute with the fitted event shift - what the live engine does the moment the event arrives.
  It uses no money from inside the bucket; live, the money arriving after the event corrects it
  further, which needs per-minute data and is not scored here.
  *11. What an event does to the split* - the fitted event shift: per bet type and side, the money
  after a goal, red card or corner against the forecast made before it, by clock, whose event,
  favourite strength and the score after; each cell pulled toward its broader cell by 30
  pseudo-events. Fitted on 45 validation days (the champion never trained on them), applied to the
  test days' events; written to `AlgoE_Work\models\turnover\EVENT_SHIFT.json`, which the live engine
  reads.
- **Probability leaderboard**: `test_log_loss` and `test_ece` (calibration error) for every
  source x method; `raw:hkjc_true` is 1 / HKJC true odds, the W06 assumption (de-margined odds
  where history has no true odds). The rows `stack:trader`, `stack:trader+market` and
  `stack:trader+market+customer` are the three-layer belief; the train-probability log prints
  each layer's test log-loss gain (`belief layers (test log-loss gained): ...`) and its weights
  (`stack layer market: {'gap': ...}` - how far it moves toward the market).
  `test_money_log_loss` / `test_money_ece` weight each settled selection by its stake, which is
  how the optimizer's E[GM] (a sum over money) feels the belief; `test_margin_gap` is the
  expected margin under the belief minus the realised margin, on the money (near 0 is right;
  positive means the belief thinks the book earns more than it does). `stack_money:...` is the
  three-layer stack fitted with stake weights. The champion is chosen on validation by
  `probability.champion_metric` (`log_loss`; `money_log_loss` chooses by money).
  After collecting rows the log prints the market price coverage by bet type / phase / best line:
  the market layer can only correct rows that have a market price. Extra-time pools have no
  Poisson-from-theta (theta is a full-time quantity), so that source is empty there.
  `where <champion> beats raw:hkjc_true` (train-probability log, and a table in the backtest
  report) splits the log-loss gained by game clock, price, quote age, best line, side, phase and
  bet type, biggest share of the total first. A real edge shows pre-match, on the best line and
  on fresh quotes; a gain only late in play (outcomes nearly settled) or on stale quotes is not
  one a price can use - read this before trusting a large gain.
- **Optimizer** (report section): E[GM] at the recommendation minus E[GM] at HKJC's theta, under
  the forecast demand and the calibrated belief, on the test days, split into "of which TG/SUP"
  (stage 1) and "of which weightings" (stage 2), with how far the weightings moved. `binding`
  says which guard stopped it going further (trust band, max step, probability band, market cap,
  weighting band). Demand: the share model's price coefficients are used only if a longer price
  takes more money at evens both with and without a market price. Otherwise - as in the office
  model, where most rows have no market price and the coefficient is negative there, because
  HKJC shortens a price after money arrives (reverse causality, not demand) - the backtest log
  warns and the optimizer uses `optimizer.fixed_elasticity`. Matches without HKJC TG / SUP are
  skipped and counted (`block(s) left alone without HKJC TG / SUP` in the log).
  A match expecting less than `optimizer.min_match_turnover` (HK$500) over the horizon is not
  solved: HKJC's theta stands. A flood on one selection makes it lean against that side - shorten
  it, lengthen the other - but never past the guards: each theta within `theta_band` of HKJC's
  (focus refreshes also within `max_step` of the last answer), each price within `prob_band`
  (5 points of implied probability) of the board, and never below the board's E[GM]. In the unit
  test 100x and 10,000x the money on Over 2.5 both stop at TG +0.17, Over 1.93 -> 1.78, bound by
  the probability band. Inside a bucket, one big ticket raises the expected rest-of-bucket money
  at most `live.nowcast_max_hot` (4x) and the next bucket at most 2x.

## 3. Every day

**Keep Raw_Data current.** `algoe-update-data.bat` extracts Raw_Data again with the queries of
`hkjc_code\1 Data Extraction.ipynb`, from the day before the newest day every table has, up to
now. The monthly tables are extracted a whole month at a time: newest day 1 October means
September and October again. Match_Investments is extracted a day at a time. Each file is
written beside the old one and replaces it only when it is complete, so a failed or killed run
keeps the old file. Then the cached panel and feature days from that day are dropped and built
again, so every backtest reads the new data.

    algoe-update-data.bat --dry-run           what it would extract; changes nothing
    algoe-update-data.bat                     the update
    algoe-update-data.bat --from 2026-09-01   start earlier
    algoe-update-data.bat --report            also refresh the W10 report through yesterday

`--report` scores the champions' unseen days only: from their first test day, after every day
they trained or chose on. It skips with a message when a champion is a serving refit.

Run it every morning, without admin rights, while you are logged on:

    algoe-schedule-update.bat                 every day at 06:00 (algoe-schedule-update.bat 07:15 for another time)

`start.bat` reads `Raw_Data\_algoe_update.json`. If no update has run, the last one did not
finish or failed, or the newest day is before yesterday, it starts the update in its own window
and the desk starts anyway (`start.bat -NoDataUpdate` skips this). The Workbench opens on a
window ending on the newest complete day on disk.

`Raw_Data\_algoe_update.lock` keeps two runs apart for the whole run. Its owner touches it every
minute; a lock left by a killed run is taken over after 15 minutes. The nightly waits up to 2 hours
for a running update. The run stops before it writes anything when a table has no files
(`--from` sets where to start) or when Raw_Data holds a file that may overlap the ones it writes,
whose rows the loader would read twice (move it out, or `--allow-foreign`).

Register the nightly task once (elevated prompt, adjust the folder). It runs the update first:

    schtasks /Create /TN "AlgoE nightly" /SC DAILY /ST 06:30 /TR "\"D:\AlgoE\algoe-w10\algoe-nightly.bat\""

It builds the new days, checks health on the last 7, retrains both models on the 75 days
ending yesterday (chosen and scored honestly, then refitted on the newest days for serving),
and promotes only what beats last 5 minutes and the current champion. Exit code 0 ok,
1 a step failed, 2 finished with alerts.

After it runs, read `AlgoE_Work\monitor\health.json` or run `algoe-5-monitor.bat`:

| Alert | Meaning | Do |
|-------|---------|----|
| `accuracy` | rolling WAPE or deviance worse than last 5 minutes | check the leaderboard of the last nightly run; if the champion is the problem, roll back (section 6) |
| `bias` | forecasts consistently above / below what arrived | often a new season or a feed change; the nightly refit usually absorbs it within days |
| `drift` | a price or money feature's distribution moved (PSI > 0.25) | check `check-data` for a feed change; calendar / clock / event features are not checked, they move by design |
| `novelty` league | a league the encoder has never seen | nothing to do: it is forecast at the global level and learns from its own money within the day; the next refit includes it |
| `novelty` pool | a pool code placed by rule | confirm it in `config\pools.json` (section 5) |

## 4. The desk

The desk's Backtest tab (`algoe-mvp`, `start.bat`, <http://localhost:3000/backtest>) reads these
reports through `/api/algoe/reports` and `/api/algoe/report`: source *Algo E model (W10)*, with an
overview, the baseline-vs-model comparison, the leaderboard, proportions, events and drift / belief
/ margin. It uses the newest copy of every section across `AlgoE_Work\reports\backtest_*`, so a
full run and a later `--only events` run read as one; the folder follows `ALGOE_DATA_DIR` /
`ALGOE_WORK_DIR`, or set it under *Reports* on the page.

**The board and the cockpit read the live engine** (`/api/live/desk`), not the W06-W08 tick.
`start.bat` sets `ALGOE_LIVE=1`, so the engine starts with the API; it needs a turnover and a
probability champion in `AlgoE_Work` (`algoe-2-train.bat`). Without them it falls back to the
MVP rule and the cockpit's `Engine` line says `no W10 model`; with them it names the champion
pipeline and belief method. The W06 tick still runs beside it and still feeds the Backtest tab
and the old `/api/desk`; its last-5-minutes carry forward is only a comparison column now
(`Last 5m` in the book).

- **Opening a match** asks the engine for it at once: the match is re-read from the feed, and
  TG / SUP, odds, the clock, the score and the money already in the bucket are as of that moment,
  not as of the bucket start. On the simulator the cockpit shows the refreshed match 3.6-5.2 s
  after it opens. While it stays open it refreshes every 15 s (`live.focus_interval_seconds`);
  the page keeps it in focus with a heartbeat and releases it when it closes. The header shows
  the TG / SUP row the book is priced on and its age (`TG/SUP 21:47:12 · 3m old`) and whose board
  it is: `live · every 15s` (this match's own read), `bucket sweep` (the whole card at the bucket
  start) or `reading the feed…` (a refresh is running; the numbers are the previous read).
- **The board** is the sweep at the bucket start for every match on the card, so the card is
  ranked on the same five minutes; a match a desk has open carries `open`, and its cockpit has the
  newer read. A match that leaves the panel leaves the board at the next sweep.
- **The 5-minute turnover** is the champion's forecast for the bucket (`F 5m`), nowcast with the
  money already in it (`So far`), and re-run at every candidate price; the inspector's money flow
  adds the rest of the bucket and the next one. Pools the engine does not model are folded under
  `HKJC only` with HKJC's prices alone.
- **First-half pools** carry `FH split unverified` until section 6's check settles how
  `Goal90SecondHalfSplitFH` prices the first half.

The endpoints: `GET /api/live/desk` (the board), `GET /api/live/desk/{id}?open=1` (one match; a
call without `open` is the heartbeat), `POST /api/live/desk/{id}/price` (what-if theta),
`GET /api/live/desk/{id}/curves`, `DELETE /api/live/focus/{id}` (release), `GET /api/live/status`
(running, the matches in focus, the last sweep, the models in use). The engine's own views,
`GET /api/live/board` and `GET /api/live/match/{id}`, are unchanged.

**Checking the live money feed.** The engine reads `ticket_bets_dtl_agg_mem` as money per
minute per selection. Whether the table holds that (rather than a running total, or the same
rows repeated) has only been assumed. On a match in play:

    algoe-6-probe-live.bat --match <match id> [--minutes 60] [--tickets]

It writes `AlgoE_Work\diagnostics\<stamp>_probe_<id>\`: the raw rows, each selection's
last 5 minutes and this bucket so far, the TG / SUP rows, the first-half split check and
`verdict.txt`. `--tickets` also sums the ticket tables (`fbis1_fo_as_db`, `fbis1_fo_cs_db`, or
`--as-db` / `--cs-db`) over the same whole minutes (not the one still filling) to compare against. Exit code 0 PASS, 2 WARN,
1 FAIL. Send the folder back with the verdict: it decides whether the feed needs a fix.

## 5. New things in the feed

- **New league / new bet type**: nothing to configure. Until the next refit it is forecast at
  its parent's level (the global level for a league, its family for a bet type) and learns from
  its own money within the day; every refit (the nightly) relearns the levels from the last two
  years of cached days, so from then on it has its own.
- **New pool code**: the taxonomy places it by its spelling (an FH / FC / ET prefix is the
  segment, CH / CN after it means corners, a body ending in LO is a total, LOH / LOA a home /
  away team total, DC a handicap, HAD a three-way, CRS a correct score...) and logs a warning; the
  engine forecasts and, if it is a line market, prices it. Confirm or correct it in
  `AlgoE_Work\config\pools.json`:

      {"pools": {"NHILO": {"segment": "FT", "domain": "goal", "market": "total", "has_line": true}},
       "aliases": {"HIL": "HILO"}}

- **Holidays**: Hong Kong's general holidays are computed for every year (lunar calendar, Easter,
  Ching Ming, the Sunday rules) - nothing to maintain. A one-off gazetted day goes in
  `AlgoE_Work\config\holidays.txt` as `2027-09-03`; a line starting with `-` removes a day. The
  only dates the computation cannot settle are new moons within minutes of midnight (2057's Chung
  Yeung, 2089's Mid-Autumn): if the gazette disagrees, `-2057-10-06` and `2057-10-07` fix it.

## 6. Models

    python -m algoe models                    every version; * marks the champion
    python -m algoe models history            every promotion and its reason
    python -m algoe models promote --kind turnover --version <version> --reason "roll back"

A bundle is refused if its file does not match its checksum, or if it was trained on another
feature version than the code builds - retrain rather than serve it.

Backtest the honest fit, not the serving refit (the refit has seen the test days; `backtest`
refuses it): `python -m algoe train-turnover --no-promote` then `python -m algoe backtest`.
`backtest --only optimizer` runs some sections (any of `turnover,groups,trueprob,gm,replication,optimizer,
drift,events,mix,elasticity`) - the optimizer alone after a change to demand or belief;
`--only events` after a zip that only changes the event and proportion study (it also refits
`EVENT_SHIFT.json`). The feature-group ablation refits on 90 train days and 45 validation days
spread over the window, not the whole window.

**The first-half split.** Before kick-off the first half is priced at the full match's TG / SUP
x `Goal90SecondHalfSplitFH` (corners: `Corner90SecondHalfSplitFH`), as the notebooks do. The
column averages above 0.5 on the real data, which no first half carries, so it may be the
second half's share. `--only replication` scores no model and needs only days:

    algoe-3-backtest.bat --only replication --days 2026-09-25:2026-10-25

Section 5 of the report prices every first-half row both ways and says which reproduces HKJC's
own first-half board before kick-off (`closer`); the `+fh_second_half` rows are the second
reading. Nothing changes until that is confirmed: flipping the reading changes the features,
so it is a new feature version and a retrain.

## 7. Settings

Every knob is in `backend\algoe\settings.py`, grouped by the layer that reads it. Override
one on any command with `--set section.key=value`, or keep a JSON file and pass
`--settings path` (or set `ALGOE_SETTINGS`):

    {"window": {"val_days": 7, "test_days": 14},
     "optimizer": {"prob_band": 0.03, "budget_seconds": 150},
     "live": {"focus_interval_seconds": 10, "max_focus_matches": 8}}

Compute knobs, if the box is slow: `panel.workers` (`--workers`, months built in parallel),
`optimizer.budget_seconds` (sweep wall clock), `optimizer.workers`, `live.max_focus_matches`,
`live.focus_interval_seconds`, `turnover.fit_rows_per_day`, and `panel.pools` - the default is
the line markets plus 1X2; the W06 list `["HILO","HDC","CHLO","CHDC"]` is smaller and reuses the
cache `3-run.bat` built. `optimizer.pools` (default `["@theta_lines"]`: every full-time and
first-half goal / corner line market, team totals included) is what the optimizer moves theta
for; extra-time pools are forecast but not optimised. `live.nowcast_max_hot` caps how far one
big ticket moves the in-bucket forecast.

After an event: `live.trigger_events` (goal, red, corner) refresh the match at once and keep it on
15-second focus refreshes for `live.trigger_focus_seconds` (goal and red card 180 s, corner, price
move and big money 60 s; a desk heartbeat keeps it longer). With `live.event_shift` (on) and
`models\turnover\EVENT_SHIFT.json` present, the rest of the bucket is forecast from the bucket
forecast shifted for the event (bet type x side, by clock, whose event, favourite strength and the
score), and the nowcast reads the money since the event; the log line says `re-tuned for goal
favourite 15-30' (favourite ahead)`. Without the file the rest of the bucket follows the money
arriving only. The next 5-minute sweep has the event in its features either way.

Optimizer stage 2 (weightings): `optimizer.weightings` (on), `weighting_band` (each within 1 +- 3%),
`weighting_max_step` (1% per focus refresh), `weighting_margin_band` (0 = every line keeps HKJC's
overround; 0.01 lets it move 1%), `weighting_smoothness`, `weighting_ridge`. Volume:
`optimizer.volume_response` (`neutral` = elasticity 1 / margin, `fixed` with `volume_elasticity`,
or `none`) - it only bites when a line's overround moves, i.e. with a margin band above 0.

Turnover models: `turnover.pipelines` (what competes), `turnover.extrapolation_tolerance` (0.01:
serve the anchored twin of a plain gbm / nn winner when it is this close on validation; 0 turns
it off), `turnover.extrapolation_cap` (10: the most an anchored model goes past its edge value).

History the models learn from: `features.encoder_history_days` (730) and
`encoder_half_life_days` (180) for league / team / bet-type levels (`features.team_prior`, 150
match-buckets: about two matches before a team moves halfway from its league); `features.
market_index_days` (28) for the market size money is divided by and for the board references.

Training time grows with the pipelines: 25 compete by default. Once a run has shown which never
come close, a settings file for the nightly can keep the top few (`turnover.pipelines`), and
`turnover.algorithms` then trains only what they use.

## 8. When something fails

Every command logs to `AlgoE_Work\logs\<command>-<stamp>.log`, with a box per step
(`STEP F1 fit encoders ...`) and a `[PASS]` / `[FAIL]` line with its timing; the `.jsonl`
beside it has the same lines with their data. `runs\<stamp>_<command>\summary.json` has the
exit code and the error.

- `no turnover champion yet` - run `algoe-2-train.bat` first.
- `RuntimeWarning: Values in x were outside bounds during a minimize step, clipping to bounds`
  (zips before 2026-10-06 printed thousands during the optimizer backtest) - harmless: SciPy
  stepped past a band and clipped back to it. No longer printed.
- `trained on feature version N but the code builds version M` - the code changed how a
  feature is built; retrain (`algoe-2-train.bat`).
- `window has K day(s) with data; train/val/test needs at least ...` - widen `--start/--end`
  or lower `window.val_days` / `window.test_days`.
- The live board is empty - `check-data` for the day, or the source (`--source sql` needs the
  ODBC connection the desk uses; `python scripts\preflight.py --source sql`).
- `another update is running` - wait for it, or pass `--wait 60`. A lock left by a killed run is
  taken over 15 minutes after its last heartbeat.
- `algoe-update-data.bat` shows FAILED for a file - that file kept its old version and the others
  were updated. The file and the SQL error are in the window, in `Raw_Data\_algoe_update.json` and
  in the log; run it again once SQL answers. `--report` does not run on a part-updated Raw_Data.
- `... may overlap the files this run writes` - a parquet in a table folder that is not the
  notebook's file for its window. Move it out of Raw_Data, then run again.
- The desk's 5-minute turnover looks wrong for a match - run `algoe-6-probe-live.bat --match
  <id>` while it is in play (section 4) and read `verdict.txt` and `selections.csv`; the book's
  `Last 5m` column is the old carry-forward, `F 5m` and `So far` are the engine's.
- A cockpit stays on `reading the feed…` or shows a red error beside the models - the engine
  could not refresh that match; the API window logs `focus refresh of match <id> failed` with the
  reason, the page keeps the previous read, and `GET /api/live/status` says whether the engine is
  running at all.
