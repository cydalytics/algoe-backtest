"""
Live Routes (the W10 engine)

The Algo E live engine behind the desk: the trained turnover forecaster, the
calibrated belief and the theta optimizer, refreshed every bucket for the
whole card and every ~15 s for the matches a trader has open.

    GET    /api/live/status           engine, source, models in use, last sweep and its timings
    GET    /api/live/board            every match: expected turnover, E[GM] lift, theta moves, triggers
    GET    /api/live/match/{id}       one match in full; each call is also a focus heartbeat
    POST   /api/live/focus/{id}       keep a match in focus for ttl seconds
    DELETE /api/live/focus/{id}       release it
    POST   /api/live/start            run the background loop
    POST   /api/live/stop             pause it

The engine is built on first use (or at startup with ALGOE_LIVE=1) from the
settings the command line uses (ALGOE_SETTINGS / ALGOE_DATA_DIR /
ALGOE_WORK_DIR). The source follows ALGOE_SOURCE like the rest of the desk.
Without a trained champion it serves the W06 MVP (last 5 minutes, 1/true
odds) and /status says so.

Change Log:
-----------
2026-10-01      Initialize
"""

import math
import os
import threading
from typing import Optional

from fastapi import APIRouter, HTTPException, Query

router = APIRouter()

_lock = threading.Lock()
_engine = None
_info: dict = {}


def _plain(obj):
    """JSON a browser can parse: numpy / pandas scalars to Python, NaN and inf to null."""
    if isinstance(obj, dict):
        return {str(k): _plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_plain(v) for v in obj]
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        try:
            obj = obj.item()
        except (ValueError, AttributeError):
            pass
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, (int, str, bool)) or obj is None:
        return obj
    return str(obj)


def get_engine(start: bool = True):
    """The one engine for this process, built on first use."""
    global _engine
    with _lock:
        if _engine is None:
            from algoe.cli import Components
            from algoe.monitoring.monitor import Monitor
            from algoe.realtime.live_engine import LiveEngine
            from algoe.settings import Settings

            s = Settings.load()
            if os.environ.get("ALGOE_SOURCE"):
                s.live.source = os.environ["ALGOE_SOURCE"]
            if s.live.source == "replay":
                raise HTTPException(400, "the replay source needs a clock; use `python -m algoe live "
                                         "--source replay --at ...` instead of the API")
            c = Components(s)
            tf = c.forecaster(required=False)
            pc = c.calibrator(required=False)
            _engine = LiveEngine(s, None, tf, pc, Monitor(s))
            _info.update(
                source=s.live.source,
                turnover_model=getattr(tf, "version", None) or "none - last 5 minutes (W06 MVP)",
                turnover_pipeline=getattr(tf, "champion", None),
                probability_model=getattr(pc, "version", None) or "none - 1 / HKJC true odds (W06 MVP)",
                probability_method=getattr(pc, "champion", None),
                work=str(s.paths.work))
        eng = _engine
    if start and (eng._thread is None or not eng._thread.is_alive()):
        eng.start()
    return eng


@router.get("/live/status")
def status():
    eng = get_engine(start=False)
    running = eng._thread is not None and eng._thread.is_alive()
    return _plain({**_info, "running": running, "focused": eng.focused(), "last_sweep": eng.last_sweep})


@router.get("/live/board")
def board():
    return _plain(get_engine().board())


@router.get("/live/match/{match_id}")
def match(match_id: int, heartbeat: bool = Query(True, description="keep the match in focus")):
    eng = get_engine()
    if heartbeat:
        eng.focus_on(match_id)
    view = eng.match_view(match_id)
    if view.get("status") == "unknown":
        raise HTTPException(404, "match {} has not been seen by the live engine yet".format(match_id))
    return _plain(view)


@router.post("/live/focus/{match_id}")
def focus(match_id: int, ttl: Optional[float] = Query(None, description="seconds; default live.focus_ttl_seconds")):
    eng = get_engine()
    eng.focus_on(match_id, ttl)
    eng.trigger(match_id, "opened on the desk", priority=3.0)
    return {"focused": eng.focused()}


@router.delete("/live/focus/{match_id}")
def unfocus(match_id: int):
    eng = get_engine(start=False)
    eng.focus_off(match_id)
    return {"focused": eng.focused()}


@router.post("/live/start")
def start():
    get_engine(start=True)
    return status()


@router.post("/live/stop")
def stop():
    eng = get_engine(start=False)
    eng.stop()
    return status()
