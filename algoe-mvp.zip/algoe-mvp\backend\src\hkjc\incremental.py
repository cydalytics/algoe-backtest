"""
Incremental reads

The fast lane reads its matches every 15 seconds, and their odds, market odds and money grow all match long:
reading each match's whole history every time is most of a cycle on a busy card. IncrementalReads keeps
those three tables per match and asks the source only for the rows since the newest row it holds of each
table (the data's own clock, not this machine's) less an overlap (late rows, a money minute still filling),
merged into the cache with the newer row winning; pools, match information, parameters and incidents are
small and read whole. A table with no row of a match yet is read whole (market odds go by the match's odds,
which come from the same server). Matches that leave the lane leave the cache.

Each sweep's full read reconciles the cache, per match and table, on the rows the incremental reads brought
in and that have settled (older than the newest row on both sides less the overlap): a row on one side only,
or with another value (odds and true odds, market odds, money and tickets), is a mismatch. Above
``max_mismatch`` in any table every read is full; the reconcile after that tries incremental reads again,
and after ``max_failures`` failed reconciles in a row they stay off until a restart. A full read refreshes
the cache either way.

A source whose fetch takes ``since`` (SqlSource, a moment per table) reads only the new rows; any other is
read whole and cut to them, which gives the same snapshot (the simulator test) without the saving.

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      Watermarks from the rows' own times per match and table; reconcile per match and table on the
                incrementally read rows, both sides, true odds and tickets as well; a reconcile with nothing to
                judge does not end the fallback; money keyed on its price where the source has one; matches
                that leave the lane are dropped; the lock is not held over a read
"""

from __future__ import annotations

import inspect
import threading
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from src.core.logging import get_logger

log = get_logger(__name__)

# table -> (its time column, the columns a row is keyed on, the values a reconcile compares). A key column is
# named the SQL way or the canonical way (replay): the first of its names a frame has. "price" tells apart one
# selection's money rows of a minute bet at different odds (replay's Match_Investments); without it a source
# has one row per selection and minute.
GROWING = {
    "odds": ("effective_datetime", ["match_id", "pool_id", "line_id", "combination_id", "effective_datetime"],
             ["odds", "true_odds"]),
    "market": ("effective_datetime", ["match_id", "pool_id", "line_id", "combination_id", "bookmaker",
                                      "effective_datetime"], ["odds"]),
    "investments": ("start_sell_time", ["match_id", "pool_id", "line_no", "comb_id", "price", "start_sell_time"],
                    ["turnover", "ticket_count"]),
}
ALIASES = {"line_no": ("line_no", "line_id"), "comb_id": ("comb_id", "combination_id"), "price": ("odds_id", "odds")}
OPTIONAL = {"price"}
SAME_CLOCK = {"market": "odds"}           # a table with no row of a match yet: read from this one's mark
SMALL = ("active_pools", "match_info", "params", "params_history", "params_raw", "events")


def _ids(frame: pd.DataFrame) -> pd.Series:
    return pd.to_numeric(frame["match_id"], errors="coerce") if "match_id" in frame.columns else \
        pd.Series(index=frame.index, dtype="float64")


def _times(frame: pd.DataFrame, col: str) -> pd.Series:
    return pd.to_datetime(frame[col], errors="coerce") if col in frame.columns else \
        pd.Series(pd.NaT, index=frame.index)


def _rows_of(frame: Optional[pd.DataFrame], ids) -> pd.DataFrame:
    if frame is None or frame.empty:
        return frame if frame is not None else pd.DataFrame()
    return frame[_ids(frame).isin(list(ids)).to_numpy()]


def _code(values: pd.Series) -> pd.Series:
    """A code as a number where every one is (12 and 12.0 alike), else as text."""
    num = pd.to_numeric(values, errors="coerce")
    return num if int(num.notna().sum()) == int(values.notna().sum()) else values.astype(str)


def _keyed(frame: pd.DataFrame, table: str) -> pd.DataFrame:
    """The table's rows with their keys under the GROWING names, normalised (numbers as numbers, times as
    times) for matching."""
    col, keys, _ = GROWING[table]
    out = frame.copy()
    for k in keys:
        name = next((a for a in ALIASES.get(k, (k,)) if a in out.columns), None)
        if name is None:
            if k in OPTIONAL:
                out[k] = np.nan
                continue
            raise KeyError("{} rows have no {} column: they cannot be merged by key".format(table, k))
        out[k] = _times(out, name) if k == col else _code(out[name]) if k == "bookmaker" \
            else pd.to_numeric(out[name], errors="coerce")
    return out


def _newest(frame: Optional[pd.DataFrame], table: str) -> Dict[int, pd.Timestamp]:
    """Per match, the time of its newest row in the table."""
    col = GROWING[table][0]
    if frame is None or frame.empty or col not in frame.columns:
        return {}
    t, m = _times(frame, col), _ids(frame)
    ok = (t.notna() & m.notna()).to_numpy()
    if not ok.any():
        return {}
    s = pd.Series(t[ok].to_numpy(), index=m[ok].astype("int64").to_numpy())
    return {int(k): pd.Timestamp(v) for k, v in s.groupby(level=0).max().items()}


def _between(frame: Optional[pd.DataFrame], table: str, bounds: Dict[int, Tuple]) -> pd.DataFrame:
    """The rows of each match in ``bounds`` with lo < time <= hi (lo None: no lower bound)."""
    if frame is None or frame.empty or not bounds:
        return pd.DataFrame(columns=frame.columns if frame is not None else [])
    col = GROWING[table][0]
    t, m = _times(frame, col), _ids(frame)
    lo = m.map({k: v[0] for k, v in bounds.items()})
    hi = m.map({k: v[1] for k, v in bounds.items()})
    lo, hi = pd.to_datetime(lo, errors="coerce"), pd.to_datetime(hi, errors="coerce")
    keep = hi.notna() & (t <= hi) & (lo.isna() | (t > lo))
    return frame[keep.to_numpy()]


def _count(snap) -> int:
    return sum(len(getattr(snap, t)) for t in GROWING if getattr(snap, t, None) is not None)


class IncrementalReads:
    """A source that reads only what is new for the matches it has read before (see the module)."""

    def __init__(self, base, overlap_seconds: float = 120.0, max_mismatch: float = 0.01, max_failures: int = 3):
        self.base = base
        self.name = getattr(base, "name", "source")
        self.overlap = pd.Timedelta(seconds=float(overlap_seconds))
        self.max_mismatch = float(max_mismatch)
        self.max_failures = int(max_failures)
        fetch = getattr(base, "fetch", None)
        self.native = callable(fetch) and "since" in inspect.signature(fetch).parameters
        self.cache: Dict[str, pd.DataFrame] = {}
        self.read_at: Dict[int, pd.Timestamp] = {}        # match -> when it was last read (this machine's clock)
        self.seen: Dict[Tuple[int, str], Optional[pd.Timestamp]] = {}       # (match, table) -> newest row held
        self.base_seen: Dict[Tuple[int, str], Optional[pd.Timestamp]] = {}  # ... as the last full read left it
        self.full = False                                  # every read full until a reconcile agrees
        self.failures = 0                                  # failed reconciles in a row
        self.disabled = False                              # max_failures reached: full reads until a restart
        self.stats = {"reads": 0, "incremental": 0, "full": 0, "rows_read": 0, "mismatch": None, "tables": {},
                      "compared": 0, "reconciled_at": None, "failures": 0, "mode": "incremental"}
        self._lock = threading.Lock()

    def clone(self) -> "IncrementalReads":
        clone = getattr(self.base, "clone", None)
        return IncrementalReads(clone() if callable(clone) else self.base, self.overlap.total_seconds(),
                                self.max_mismatch, self.max_failures)

    def stats_snapshot(self) -> dict:
        with self._lock:
            return dict(self.stats, tables=dict(self.stats["tables"]))

    # ------------------------------------------------------------------ reading
    def _read(self, as_of, ids: List[int], since: Optional[Dict[str, Optional[pd.Timestamp]]] = None):
        if since is not None and self.native:
            return self.base.fetch(as_of, match_ids=ids, since=since)
        snap = self.base.fetch(as_of, match_ids=ids)
        if since is not None:
            for table, (col, _, _) in GROWING.items():
                frame, cut = getattr(snap, table, None), since.get(table)
                if cut is not None and frame is not None and not frame.empty:
                    setattr(snap, table, frame[(_times(frame, col) >= cut).to_numpy()])
        return snap

    def _since(self, ids: List[int]) -> Dict[str, Optional[pd.Timestamp]]:
        """Per table, the oldest of the matches' newest rows less the overlap; None (the whole table) when a
        match has no row of it yet."""
        out: Dict[str, Optional[pd.Timestamp]] = {}
        for table in GROWING:
            marks = [self.seen.get((m, table)) or self.seen.get((m, SAME_CLOCK.get(table, table))) for m in ids]
            out[table] = None if any(t is None for t in marks) else min(marks) - self.overlap
        return out

    def _evict(self, ids: List[int]) -> None:
        gone = [m for m in self.read_at if m not in set(ids)]
        if not gone:
            return
        for table, frame in list(self.cache.items()):
            if frame is not None and not frame.empty:
                self.cache[table] = frame[~_ids(frame).isin(gone).to_numpy()].reset_index(drop=True)
        for m in gone:
            self.read_at.pop(m, None)
            for table in GROWING:
                self.seen.pop((m, table), None)
                self.base_seen.pop((m, table), None)

    def fetch(self, as_of=None, match_ids=None):
        as_of = pd.Timestamp(as_of) if as_of is not None else pd.Timestamp.now()
        if match_ids is None:
            return self.base.fetch(as_of, match_ids=match_ids)
        ids = sorted({int(m) for m in match_ids})
        if not ids:
            return self.base.fetch(as_of, match_ids=[])
        with self._lock:
            self.stats["reads"] += 1
            self._evict(ids)
            known = [] if (self.full or self.disabled) else [m for m in ids if m in self.read_at]
            fresh = [m for m in ids if m not in known]
            cut = self._since(known) if known else None
        parts = []
        if fresh:
            snap = self._read(as_of, fresh)
            with self._lock:
                self.stats["full"] += 1
                self.stats["rows_read"] += _count(snap)
                self._store(snap, fresh, as_of)
            parts.append((snap, fresh))
        if known:
            snap = self._read(as_of, known, since=cut)
            with self._lock:
                self.stats["incremental"] += 1
                self.stats["rows_read"] += _count(snap)
                try:
                    self._merge(snap, known, as_of)
                    merged = True
                except KeyError as exc:
                    log.warning("incremental reads cannot be merged (%s): every read is full", exc)
                    self.full, merged = True, False
            if not merged:
                snap = self._read(as_of, known)
                with self._lock:
                    self._store(snap, known, as_of)
            parts.append((snap, known))
        with self._lock:
            out = parts[-1][0]
            for name in SMALL:                     # each read's small tables for its own matches (a source may
                pieces = []                        # return every match whatever it is asked)
                for snap, part in parts:
                    frame = getattr(snap, name, None)
                    if isinstance(frame, pd.DataFrame):
                        pieces.append(frame[_ids(frame).isin(part).to_numpy()] if "match_id" in frame.columns
                                      else frame)
                if pieces:
                    setattr(out, name, pd.concat(pieces, ignore_index=True))
            for table in GROWING:
                cached = self.cache.get(table)
                setattr(out, table, _rows_of(cached, ids).reset_index(drop=True) if cached is not None
                        else getattr(out, table))
            self.stats["mode"] = self._mode()
            return out

    def _mode(self) -> str:
        return "off" if self.disabled else "full" if self.full else "incremental"

    def _store(self, snap, ids: List[int], as_of) -> None:
        """A full read of ``ids``: their cached rows replaced, and where the incremental reads start from."""
        for table in GROWING:
            frame = getattr(snap, table, None)
            if frame is None:
                continue
            old = self.cache.get(table)
            keep = old[~_ids(old).isin(ids).to_numpy()] if old is not None and not old.empty else None
            mine = _rows_of(frame, ids)
            self.cache[table] = pd.concat([x for x in (keep, mine) if x is not None], ignore_index=True)
            newest = _newest(mine, table)
            for m in ids:
                self.seen[(m, table)] = self.base_seen[(m, table)] = newest.get(m)
        for m in ids:
            self.read_at[m] = pd.Timestamp(as_of)

    def _merge(self, snap, ids: List[int], as_of) -> None:
        """New rows of ``ids`` into the cache: a row read again (a money minute still filling) takes the new value."""
        for table, (_, keys, _) in GROWING.items():
            new = _rows_of(getattr(snap, table, None), ids)
            if new is None or new.empty:
                continue
            old = self.cache.get(table)
            both = pd.concat([x for x in (old, new) if x is not None], ignore_index=True)
            k = _keyed(both, table)
            self.cache[table] = both[~k.duplicated(keys, keep="last").to_numpy()].reset_index(drop=True)
            for m, t in _newest(new, table).items():
                held = self.seen.get((m, table))
                self.seen[(m, table)] = t if held is None or t > held else held
        for m in ids:
            self.read_at[m] = pd.Timestamp(as_of)

    # ------------------------------------------------------------------ reconcile
    def _bounds(self, table: str, ids: List[int], full: pd.DataFrame) -> Dict[int, Tuple]:
        """Per match, the window of rows the incremental reads brought in (newer than the last full read's) that
        have settled on both sides; the full read's own rows would drown a lost incremental read."""
        newest = _newest(full, table)
        out = {}
        for m in ids:
            held, there = self.seen.get((m, table)), newest.get(m)
            if held is None or there is None:
                continue
            hi, lo = min(held, there) - self.overlap, self.base_seen.get((m, table))
            if lo is None or hi > lo:
                out[m] = (lo, hi)
        return out

    def reconcile(self, full_snap) -> Optional[float]:
        """Compare the cache with a full read (the sweep's) on the rows the incremental reads brought in (see the
        module). Returns the worst table's mismatch rate (None: nothing to compare); above max_mismatch every
        read is full, and the cache takes the full read either way."""
        with self._lock:
            there = set()
            for table in GROWING:
                frame = getattr(full_snap, table, None)
                if frame is not None and not frame.empty:
                    there |= set(_ids(frame).dropna().astype("int64").tolist())
            ids = sorted(m for m in self.read_at if m in there)
            if not ids:
                return None
            tables: Dict[str, dict] = {}
            try:
                for table, (_, keys, values) in GROWING.items():
                    full = _rows_of(getattr(full_snap, table, None), ids)
                    bounds = self._bounds(table, ids, full)
                    if not bounds:
                        continue
                    a = _keyed(_between(full, table, bounds), table).drop_duplicates(keys, keep="last")
                    b = _keyed(_between(_rows_of(self.cache.get(table), ids), table, bounds), table) \
                        .drop_duplicates(keys, keep="last")
                    vals = [v for v in values if v in a.columns and v in b.columns]
                    j = a[keys + vals].merge(b[keys + vals], on=keys, how="outer", suffixes=("", "_cached"),
                                             indicator=True)
                    if not len(j):
                        continue
                    bad = np.array(j["_merge"] != "both", dtype=bool)
                    for v in vals:
                        va = pd.to_numeric(j[v], errors="coerce").to_numpy(dtype="float64")
                        vb = pd.to_numeric(j[v + "_cached"], errors="coerce").to_numpy(dtype="float64")
                        bad |= ~(np.isclose(va, vb, rtol=0.0, atol=1e-9) | (np.isnan(va) & np.isnan(vb)))
                    tables[table] = {"compared": int(len(j)), "mismatch": round(float(bad.mean()), 5)}
            except KeyError as exc:
                log.warning("incremental reads cannot be compared (%s): every read is full", exc)
                tables = {"keys": {"compared": 1, "mismatch": 1.0}}
            rate = max((t["mismatch"] for t in tables.values()), default=None)
            was = self._mode()
            if rate is None:
                # nothing came in incrementally since the last full read: a fallback tries them again, and the
                # next reconcile judges what they bring
                self.full = False
            elif rate > self.max_mismatch:
                self.full, self.failures = True, self.failures + 1
                if self.failures >= self.max_failures and not self.disabled:
                    self.disabled = True
                    log.error("incremental reads failed %d reconciles in a row: every read is full until a restart",
                              self.failures)
            else:
                self.full, self.failures = False, 0
            self.stats.update(mismatch=rate, tables=tables, compared=sum(t["compared"] for t in tables.values()),
                              failures=self.failures, mode=self._mode(),
                              reconciled_at=str(pd.Timestamp(getattr(full_snap, "as_of", None) or pd.Timestamp.now())))
            if rate is not None and rate > self.max_mismatch and was == "incremental":
                log.warning("incremental reads differ from the sweep's full read (%s): every read is full until a "
                            "sweep agrees", tables)
            elif was == "full" and self._mode() == "incremental":
                log.info("incremental reads resume (%s)", tables or "nothing to compare since the last full read")
            self._store(full_snap, ids, getattr(full_snap, "as_of", None) or pd.Timestamp.now())
            return rate
