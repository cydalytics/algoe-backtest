"""Shared launcher for the numbered scripts: puts backend/ on the path and runs one CLI command."""
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))


def run(command: str) -> None:
    from algoe.cli import main
    sys.exit(main([command] + sys.argv[1:]))
