"""
Feature Engineer

One class that turns a day of panel rows into the exact inputs each model
needs. The public methods are named by what they feed:

    features_for_turnover_match_total(day)      level: match x bucket
    features_for_turnover_pool_share(day)       level: match x pool x bucket
    features_for_turnover_selection_share(day)  level: selection x bucket (share inside its pool)
    features_for_turnover_selection(day)        level: selection x bucket (direct turnover)
    features_for_probability(day)               level: settled selection x bucket

All of them read one ``DayData`` built by ``prepare_day``, where each feature
group (catalog.py) is computed once:

    _group_money_history   selection / pool / match / board lags, EWMA, today so far
    _group_events          running score, goal and red-card pulses, time since goal
    _group_lifecycle       minutes to kick-off, match minute, half time, hinge bases
    _group_calendar        weekday, hour, weekend, HK holiday, evening
    _group_price           implied prob, value vs HKJC true and vs market, price moves
    _group_line_position   rank by balance, offset from the main line, line age, moves
    _group_concurrency     live matches, board money, match share and rank of the board
    _group_bet_type        family / segment / side flags - what a pool IS, never its code

KNOWN-AT-T RULE. Every value for bucket T uses money from buckets before T,
prices posted before T, and incidents and parameters stamped before T. The
label is the money inside T. ``tests/test_algoe.py`` tampers with everything
inside one bucket and asserts no feature of that bucket moves.

MISSING AND UNKNOWN. Every column is filled and clipped from its catalog
spec, so no model ever sees NaN. A pool code never seen before is resolved by
the taxonomy's rules; a league never seen before encodes to the global level
with ``league_known = 0``.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Odds age at the bucket start (the W06 value is end-of-bucket); FH pools not forecastable
                after half time; goal pulse per provider then max (no later goals); money today from
                the forecast day; prepare_live for LivePanelBuilder output
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.calendar import HKCalendar
from ..core.logging import get_logger
from ..core.taxonomy import PoolTaxonomy, default_taxonomy, parse_line, side_of
from ..data.panel import KEY, asof_before, market_consensus, score_asof
from . import catalog as C
from .encoders import EncoderState

logger = get_logger(__name__)

MKEY = ["match_id", "bucket"]
PKEY = ["match_id", "pool_name", "bucket"]
LKEY = ["match_id", "pool_name", "line_id", "bucket"]
STEP = pd.Timedelta(minutes=5)


@dataclass
class FeatureSet:
    """Model-ready inputs for one level. Row i of every array is the same row."""
    level: str
    keys: pd.DataFrame
    X: pd.DataFrame
    y: np.ndarray
    exposure: np.ndarray
    last5: np.ndarray
    group: np.ndarray
    cuts: pd.DataFrame
    kinds: Dict[str, str] = field(default_factory=dict)
    weight: Optional[np.ndarray] = None

    def __len__(self) -> int:
        return len(self.y)

    @property
    def feature_names(self) -> List[str]:
        return list(self.X.columns)

    def columns_for(self, kinds: Sequence[str]) -> List[str]:
        return [c for c in self.X.columns if self.kinds.get(c, "raw") in kinds]

    def subset(self, mask) -> "FeatureSet":
        m = np.asarray(mask, dtype=bool)
        return FeatureSet(self.level, self.keys.loc[m].reset_index(drop=True),
                          self.X.loc[m].reset_index(drop=True), self.y[m], self.exposure[m],
                          self.last5[m], self.group[m], self.cuts.loc[m].reset_index(drop=True),
                          dict(self.kinds), None if self.weight is None else self.weight[m])

    @staticmethod
    def concat(parts: Sequence["FeatureSet"]) -> "FeatureSet":
        parts = [p for p in parts if p is not None and len(p)]
        if not parts:
            raise ValueError("no rows to concatenate")
        offset, groups = 0, []
        for p in parts:
            groups.append(p.group + offset)
            offset += int(p.group.max()) + 1 if len(p.group) else 0
        w = None if any(p.weight is None for p in parts) else np.concatenate([p.weight for p in parts])
        return FeatureSet(parts[0].level, pd.concat([p.keys for p in parts], ignore_index=True),
                          pd.concat([p.X for p in parts], ignore_index=True),
                          np.concatenate([p.y for p in parts]), np.concatenate([p.exposure for p in parts]),
                          np.concatenate([p.last5 for p in parts]), np.concatenate(groups),
                          pd.concat([p.cuts for p in parts], ignore_index=True), dict(parts[0].kinds), w)


@dataclass
class DayData:
    day: pd.Timestamp
    sel: pd.DataFrame
    match: pd.DataFrame
    pool: pd.DataFrame

    @property
    def empty(self) -> bool:
        return self.sel is None or self.sel.empty


def _num(frame: pd.DataFrame, col: str, default: float = np.nan) -> np.ndarray:
    if col not in frame.columns:
        return np.full(len(frame), default, dtype="float64")
    return pd.to_numeric(frame[col], errors="coerce").to_numpy(dtype="float64")


def _ints(frame: pd.DataFrame, cols) -> pd.DataFrame:
    for c in cols:
        if c in frame.columns:
            frame[c] = pd.to_numeric(frame[c], errors="coerce").fillna(-1).astype("int64")
    return frame


def _shift(frame: pd.DataFrame, keys: List[str], value: str, k: int, name: str) -> pd.DataFrame:
    out = frame[keys + ["bucket", value]].rename(columns={value: name})
    return out.assign(bucket=out["bucket"] + k * STEP)


def _share(num: np.ndarray, den: np.ndarray, fill: float = 0.0) -> np.ndarray:
    return np.where(den > 0, num / np.maximum(den, 1e-12), fill)


class FeatureEngineer:
    """Builds every model's inputs from panel days. Stateless apart from the encoders."""

    def __init__(self, settings, taxonomy: Optional[PoolTaxonomy] = None,
                 calendar: Optional[HKCalendar] = None, encoders: Optional[EncoderState] = None):
        self.settings = settings
        fs = settings.features
        self.taxonomy = taxonomy or default_taxonomy(str(settings.paths.pools_file))
        self.calendar = calendar or HKCalendar(str(settings.paths.holidays))
        self.encoders = encoders or EncoderState()
        self.match_specs = C.match_specs(fs.ko_knots, fs.minute_knots)
        self.pool_specs = C.pool_specs()
        self.sel_specs = C.selection_specs()

    # ================================================================ public
    def features_for_turnover_match_total(self, day: DayData) -> FeatureSet:
        m = day.match
        X = self._finish(m, self.match_specs, encode="league")
        return FeatureSet("match", m[MKEY].reset_index(drop=True), X, m["y"].to_numpy(dtype="float64"),
                          np.ones(len(m)), m["last5"].to_numpy(dtype="float64"),
                          np.arange(len(m)), self._cuts(m), self._kinds(self.match_specs))

    def features_for_turnover_pool_share(self, day: DayData) -> FeatureSet:
        p = day.pool
        X = self._finish(p, self.pool_specs, encode="pool")
        group = p.groupby(MKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("pool", p[PKEY].reset_index(drop=True), X, p["y"].to_numpy(dtype="float64"),
                          p["exposure"].to_numpy(dtype="float64"), p["last5"].to_numpy(dtype="float64"),
                          group, self._cuts(p), self._kinds(self.pool_specs))

    def features_for_turnover_selection_share(self, day: DayData) -> FeatureSet:
        s = day.sel[day.sel["forecastable"]].reset_index(drop=True)
        X = self._finish(s, self.sel_specs, encode="pool")
        group = s.groupby(PKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("selection_share", s[KEY + MKEY[:1] + ["pool_name", "bucket"]].reset_index(drop=True),
                          X, s["y"].to_numpy(dtype="float64"), s["pool_y"].to_numpy(dtype="float64"),
                          s["tv1"].to_numpy(dtype="float64"), group, self._cuts(s), self._kinds(self.sel_specs))

    def features_for_turnover_selection(self, day: DayData) -> FeatureSet:
        """Direct model: selection features plus its pool's and match's context."""
        s = day.sel[day.sel["forecastable"]].reset_index(drop=True)
        mcols = [sp.name for sp in self.match_specs if sp.name in day.match.columns and sp.name not in s.columns]
        pcols = [sp.name for sp in self.pool_specs if sp.name in day.pool.columns
                 and sp.name not in s.columns and sp.name not in mcols]
        s = s.merge(day.match[MKEY + mcols + ["league_code"]].rename(columns={"league_code": "_lg"}),
                    on=MKEY, how="left")
        s = s.merge(day.pool[PKEY + pcols], on=PKEY, how="left")
        if "league_code" not in s.columns:
            s["league_code"] = s["_lg"]
        specs = C.by_name(self.sel_specs + [sp for sp in self.pool_specs if sp.name in pcols]
                          + [sp for sp in self.match_specs if sp.name in mcols])
        spec_list = list(specs.values())
        X = self._finish(s, spec_list, encode="both")
        group = s.groupby(PKEY, observed=True, sort=False).ngroup().to_numpy()
        return FeatureSet("selection", s[KEY + ["match_id", "pool_name", "bucket"]].reset_index(drop=True),
                          X, s["y"].to_numpy(dtype="float64"), np.ones(len(s)),
                          s["tv1"].to_numpy(dtype="float64"), group, self._cuts(s), self._kinds(spec_list))

    def features_for_probability(self, day: DayData, require_outcome: bool = True) -> FeatureSet:
        """Two-way and three-way selections with every belief source, as logits.

        Training / scoring (require_outcome=True): settled rows only; y is the
        soft outcome (r + 1) / 2 for r in {-1, -0.5, +0.5, +1}, pushes dropped,
        weight per settings.probability.weight. Serving (False): every live
        row, y = NaN; ``keys['_row']`` maps back to day.sel positions.
        """
        s = day.sel
        if day.empty or "forecastable" not in s.columns:
            return FeatureSet("probability", pd.DataFrame(), pd.DataFrame(), np.zeros(0), np.zeros(0),
                              np.zeros(0), np.zeros(0, dtype=int), pd.DataFrame(), {}, np.zeros(0))
        # only prices actually on offer: a withdrawn line keeps its last (stale) quote in the panel
        o = self.settings.optimizer
        age = np.expm1(_num(s, "log_odds_age", 0.0))
        inplay = _num(s, "inplay", 0.0) > 0
        live = age <= np.where(inplay, o.max_odds_age_inplay_min, o.max_odds_age_prematch_min)
        keep = s["forecastable"].to_numpy() & live
        if require_outcome:
            keep &= s["outcome"].notna().to_numpy()
        rows = np.flatnonzero(keep)
        s = s.iloc[rows].reset_index(drop=True)
        if s.empty:
            return FeatureSet("probability", pd.DataFrame(), pd.DataFrame(), np.zeros(0), np.zeros(0),
                              np.zeros(0), np.zeros(0, dtype=int), pd.DataFrame(), {}, np.zeros(0))
        X = pd.DataFrame(index=s.index)
        for src in ("hkjc_true", "market", "poisson", "demargin"):
            p = np.clip(_num(s, "p_" + src), 1e-4, 1 - 1e-4)
            ok = np.isfinite(_num(s, "p_" + src))
            X["logit_" + src] = np.where(ok, np.log(p / (1 - p)), 0.0)
            X["has_" + src] = ok.astype("float64")
        X["inplay"] = s["inplay"].to_numpy(dtype="float64")
        X["minute"] = np.clip(_num(s, "minute", 0.0), 0, 130) / 90.0
        X["pre_ko"] = np.clip(_num(s, "pre_ko_min", 0.0), 0, 720) / 360.0
        X["rank_0"] = s["rank_0"].to_numpy(dtype="float64")
        X["log_odds_age"] = np.clip(_num(s, "log_odds_age", 0.0), 0, 7)
        X["log_odds"] = np.log(np.clip(_num(s, "odds", 2.0), 1.001, None))
        X["book_margin"] = np.clip(_num(s, "book_margin", 0.08), -0.2, 0.6)
        for f in C.FAMILIES:
            X["fam_" + f] = (s["family"].to_numpy() == f).astype("float64")
        X["side_home_over"] = s["side_home_over"].to_numpy(dtype="float64")
        y = ((_num(s, "outcome") + 1.0) / 2.0)
        mode = self.settings.probability.weight
        if mode == "money":
            w = np.clip(_num(s, "y", 0.0), 0, None) + 1.0
        elif mode == "selection":
            n = s.groupby(KEY, observed=True)["bucket"].transform("size").to_numpy(dtype="float64")
            w = 1.0 / np.maximum(n, 1.0)
        else:
            w = np.ones(len(s))
        keys = s[KEY + ["match_id", "pool_name", "line_id", "bucket"]].loc[:, lambda d: ~d.columns.duplicated()]
        group = s["match_id"].to_numpy()
        fs = FeatureSet("probability", keys.reset_index(drop=True), X.astype("float32"), y,
                        np.ones(len(s)), np.zeros(len(s)), group, self._cuts(s),
                        {c: "raw" for c in X.columns}, w)
        for src in ("hkjc_true", "market", "poisson", "demargin"):
            fs.keys["p_" + src] = _num(s, "p_" + src)
        fs.keys["side"] = s["side"].to_numpy()
        fs.keys["odds"] = _num(s, "odds")
        fs.keys["stake"] = _num(s, "y", 0.0)
        fs.keys["outcome"] = _num(s, "outcome")
        fs.keys["_row"] = rows
        return fs

    # ============================================================ prepare
    def prepare_day(self, panel: pd.DataFrame, tail: Optional[pd.DataFrame] = None,
                    events: Optional[pd.DataFrame] = None, market: Optional[pd.DataFrame] = None,
                    day=None) -> DayData:
        if panel is None or panel.empty:
            return DayData(pd.Timestamp(day) if day is not None else pd.NaT,
                           pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
        base = self._base(panel)
        day = pd.Timestamp(day).normalize() if day is not None else base["bucket"].min().normalize()
        money = self._money_table(base, tail)
        base = self._group_money_history(base, money)
        match = self._match_frame(base, money, day)
        match = self._group_events(match, events)
        match = self._group_lifecycle(match)
        match = self._group_calendar(match)
        match = self._group_concurrency(match, money)
        base = self._group_price(base, market)
        base = self._group_line_position(base)
        base = self._group_bet_type(base)
        base = base.merge(match[MKEY + ["inplay", "minute", "pre_ko_min", "since_goal", "phase"]],
                          on=MKEY, how="left")
        # a first-half market is settled once the half is over, whatever the feed still lists
        past_ht = base["phase"].isin(["half_time", "second_half", "extra_time"]).to_numpy()
        fh = (base["segment"].astype(str) == "FH").to_numpy()
        base["forecastable"] = base["forecastable"].to_numpy() & ~(fh & past_ht)
        pool = self._pool_frame(base, match, money)
        base = self._outcome(base)
        return DayData(day, base, match, pool)

    def prepare_live(self, panel: pd.DataFrame, extra: dict) -> DayData:
        """prepare_day for a LivePanelBuilder result, called exactly as the FeatureStore calls it
        for a historical day (same day, same one-hour tail across midnight)."""
        current = extra.get("current_bucket")
        day = pd.Timestamp(current).normalize() if current is not None else None
        return self.prepare_day(panel, extra.get("tail"), extra.get("events"), extra.get("market"), day=day)

    # ------------------------------------------------------------- base
    def _base(self, panel: pd.DataFrame) -> pd.DataFrame:
        keep = [c for c in (
            "bucket", "pool_id", "line_id", "combination_id", "match_id", "pool_name", "line_label",
            "combination_string", "odds", "true_odds", "odds_age_min", "priced_before", "forecastable",
            "in_window", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh", "game_state",
            "match_minute", "mins_to_ko", "is_inplay", "minutes_since_goal", "event_window",
            "league_code", "ko_time", "turnover", "tickets", "dividend", "y_frac", "settled", "avg_odds",
            "p__hkjc_true", "p__poisson", "p__demargin", "clock_bin") if c in panel.columns]
        b = panel[keep].copy()
        b = _ints(b, KEY + ["match_id"])
        b["bucket"] = pd.to_datetime(b["bucket"]).astype("datetime64[ns]")
        b = b.drop_duplicates(KEY + ["bucket"]).reset_index(drop=True)
        b["pool_name"] = b["pool_name"].astype("string").fillna("UNKNOWN").str.upper()
        if "forecastable" not in b.columns:
            b["forecastable"] = True
        b["forecastable"] = b["forecastable"].fillna(False).astype(bool)
        b["league_code"] = b["league_code"].astype("string").fillna("unknown") if "league_code" in b.columns \
            else "unknown"
        specs = {p: self.taxonomy.resolve(p) for p in b["pool_name"].unique()}
        b["family"] = b["pool_name"].map({p: s.family for p, s in specs.items()})
        b["segment"] = b["pool_name"].map({p: s.segment for p, s in specs.items()})
        b["market"] = b["pool_name"].map({p: s.market for p, s in specs.items()})
        b["theta_domain"] = b["pool_name"].map({p: s.theta_domain for p, s in specs.items()})
        labels = b["line_label"].astype("string") if "line_label" in b.columns else pd.Series(pd.NA, index=b.index)
        parsed = {lab: parse_line(lab) for lab in labels.dropna().unique()}
        b["line"] = labels.map(parsed).astype("float64")
        comb = b["combination_string"].astype("string").fillna("") if "combination_string" in b.columns \
            else pd.Series("", index=b.index, dtype="string")
        pair = comb + "|" + b["combination_id"].astype("string")
        table = {k: side_of(*k.rsplit("|", 1)) for k in pair.dropna().unique()}
        b["side"] = pair.map(table).fillna("?").astype(str)
        b["y"] = np.clip(_num(b, "turnover", 0.0), 0, None)
        b["y"] = np.nan_to_num(b["y"], nan=0.0)
        return b

    def _money_table(self, base: pd.DataFrame, tail: Optional[pd.DataFrame]) -> pd.DataFrame:
        cols = KEY + ["match_id", "pool_name", "bucket", "y", "tickets"]
        cur = base.assign(tickets=_num(base, "tickets", 0.0))[cols]
        cur = cur[cur["y"] > 0]
        if tail is not None and not tail.empty:
            t = tail.copy()
            t = _ints(t, KEY + ["match_id"])
            t["bucket"] = pd.to_datetime(t["bucket"]).astype("datetime64[ns]")
            t["pool_name"] = t["pool_name"].astype("string").str.upper()
            t["y"] = np.clip(_num(t, "turnover", 0.0), 0, None)
            t["tickets"] = _num(t, "tickets", 0.0)
            t = t[t["y"] > 0][cols]
            cur = pd.concat([t, cur], ignore_index=True)
        cur["tickets"] = np.nan_to_num(cur["tickets"].to_numpy(dtype="float64"), nan=0.0)
        return cur.groupby(KEY + ["match_id", "pool_name", "bucket"], observed=True, as_index=False)[
            ["y", "tickets"]].sum()

    # ------------------------------------------------------ money history
    def _group_money_history(self, b: pd.DataFrame, money: pd.DataFrame) -> pd.DataFrame:
        n = int(self.settings.features.lag_buckets)
        sel_money = money[KEY + ["bucket", "y", "tickets"]]
        for k in range(1, n + 1):
            lag = _shift(sel_money, KEY, "y", k, "tv{}".format(k))
            b = b.merge(lag, on=KEY + ["bucket"], how="left")
            b["tv{}".format(k)] = b["tv{}".format(k)].fillna(0.0)
        tk = _shift(sel_money, KEY, "tickets", 1, "tk1")
        b = b.merge(tk, on=KEY + ["bucket"], how="left")
        b["tk1"] = b["tk1"].fillna(0.0)
        tv = np.column_stack([b["tv{}".format(k)].to_numpy(dtype="float64") for k in range(1, n + 1)])
        fast, slow = tv[:, -1].copy(), tv[:, -1].copy()
        for j in range(n - 2, -1, -1):              # oldest to newest
            fast = 0.5 * tv[:, j] + 0.5 * fast
            slow = 0.2 * tv[:, j] + 0.8 * slow
        b["s_log_l1"] = np.log1p(tv[:, 0])
        b["s_log_l2"] = np.log1p(tv[:, 1])
        b["s_log_l3"] = np.log1p(tv[:, 2])
        b["s_log_ewma_fast"] = np.log1p(fast)
        b["s_log_ewma_slow"] = np.log1p(slow)
        b["s_any_l1"] = (tv[:, 0] > 0).astype(float)
        b["s_any_l6"] = (tv.sum(axis=1) > 0).astype(float)
        b["s_log_tickets_l1"] = np.log1p(b["tk1"].to_numpy(dtype="float64"))
        b["s_log_avg_stake_l1"] = np.log1p(_share(tv[:, 0], b["tk1"].to_numpy(dtype="float64")))
        # pool shares of the selection's own lagged money
        pool_money = money.groupby(["match_id", "pool_name", "bucket"], observed=True, as_index=False)["y"].sum()
        for k, name in ((1, "_pl1"), (2, "_pl2"), (3, "_pl3")):
            b = b.merge(_shift(pool_money, ["match_id", "pool_name"], "y", k, name),
                        on=["match_id", "pool_name", "bucket"], how="left")
            b[name] = b[name].fillna(0.0)
        s1 = _share(tv[:, 0], b["_pl1"].to_numpy(dtype="float64"), np.nan)
        s2 = _share(tv[:, 1], b["_pl2"].to_numpy(dtype="float64"), np.nan)
        s3 = _share(tv[:, 2], b["_pl3"].to_numpy(dtype="float64"), np.nan)
        b["_s1"], b["_s2"], b["_s3"] = s1, s2, s3
        wsum = 0.6 * np.isfinite(s1) + 0.25 * np.isfinite(s2) + 0.15 * np.isfinite(s3)
        ew = 0.6 * np.nan_to_num(s1) + 0.25 * np.nan_to_num(s2) + 0.15 * np.nan_to_num(s3)
        b["_sew"] = np.where(wsum > 0, ew / np.maximum(wsum, 1e-9), np.nan)
        line_l1 = b.groupby(LKEY, observed=True)["tv1"].transform("sum").to_numpy(dtype="float64")
        b["s_share_line_l1"] = _share(tv[:, 0], line_l1, 0.5)
        return b

    def _match_frame(self, b: pd.DataFrame, money: pd.DataFrame, day: pd.Timestamp) -> pd.DataFrame:
        live = b[b["forecastable"]]
        if live.empty:
            return pd.DataFrame(columns=MKEY + ["y", "last5"])
        first = live.groupby(MKEY, observed=True).first()
        m = live.groupby(MKEY, observed=True).agg(y=("y", "sum"), last5=("tv1", "sum"),
                                                  n_pools=("pool_name", "nunique"),
                                                  n_lines=("line_id", "nunique")).reset_index()
        for c in ("league_code", "is_inplay", "match_minute", "mins_to_ko", "tg", "sup", "ctg", "csup",
                  "goal_split_fh", "corner_split_fh", "game_state", "ko_time", "minutes_since_goal",
                  "event_window", "clock_bin"):
            if c in first.columns:
                m[c] = first[c].to_numpy()
        mm = money.groupby(MKEY, observed=True, as_index=False)["y"].sum()
        for k in range(1, int(self.settings.features.lag_buckets) + 1):
            m = m.merge(_shift(mm, ["match_id"], "y", k, "ml{}".format(k)), on=MKEY, how="left")
            m["ml{}".format(k)] = m["ml{}".format(k)].fillna(0.0)
        l = np.column_stack([m["ml{}".format(k)].to_numpy(dtype="float64")
                             for k in range(1, int(self.settings.features.lag_buckets) + 1)])
        ew = l[:, -1].copy()
        for j in range(l.shape[1] - 2, -1, -1):
            ew = 0.5 * l[:, j] + 0.5 * ew
        m["m_log_l1"] = np.log1p(l[:, 0])
        m["m_log_l2"] = np.log1p(l[:, 1])
        m["m_log_l3"] = np.log1p(l[:, 2])
        m["m_log_ewma"] = np.log1p(ew)
        m["m_any_l1"] = (l[:, 0] > 0).astype(float)
        m["m_trend"] = m["m_log_l1"] - m["m_log_l2"]
        # money the match took today (from 00:00 of the forecast day), up to the end of the previous bucket
        day0 = pd.Timestamp(day).normalize()
        today = mm[(mm["bucket"] >= day0)].sort_values(MKEY)
        today = today.assign(cum=today.groupby("match_id", observed=True)["y"].cumsum())
        m = m.merge(_shift(today, ["match_id"], "cum", 1, "_today"), on=MKEY, how="left")
        m = m.sort_values(MKEY).reset_index(drop=True)
        m["_today"] = m.groupby("match_id", observed=True)["_today"].ffill().fillna(0.0)
        m["m_log_today"] = np.log1p(m["_today"].to_numpy(dtype="float64"))
        m["log_n_pools"] = np.log1p(m["n_pools"].to_numpy(dtype="float64"))
        m["log_n_lines"] = np.log1p(m["n_lines"].to_numpy(dtype="float64"))
        m["league_code"] = m["league_code"].astype("string").fillna("unknown")
        return m

    # ------------------------------------------------------------- events
    def _group_events(self, m: pd.DataFrame, events: Optional[pd.DataFrame]) -> pd.DataFrame:
        sc = score_asof(events, m[MKEY])
        m = m.merge(sc, on=MKEY, how="left")
        for c in ("home_goals", "away_goals", "home_corners", "away_corners", "home_reds", "away_reds"):
            m[c] = pd.to_numeric(m[c], errors="coerce").fillna(0).astype("int64")
        m["goals_so_far"] = (m["home_goals"] + m["away_goals"]).astype(float)
        m["abs_score_diff"] = (m["home_goals"] - m["away_goals"]).abs().astype(float)
        taus = list(self.settings.features.goal_pulse_taus)
        m["goal_p3"], m["goal_p10"], m["red_p10"] = 0.0, 0.0, 0.0
        if events is not None and not events.empty and "incident_type" in events.columns:
            ev = events.dropna(subset=["match_id", "incident_datetime", "incident_type"]).copy()
            ev["match_id"] = pd.to_numeric(ev["match_id"], errors="coerce").fillna(-1).astype("int64")
            ev["incident_type"] = pd.to_numeric(ev["incident_type"], errors="coerce")
            ev["p"] = pd.to_numeric(ev["provider_id"], errors="coerce").fillna(-1).astype("int64") \
                if "provider_id" in ev.columns else 1
            ev["t"] = pd.to_datetime(ev["incident_datetime"]).astype("datetime64[ns]")
            # Each provider's pulse, then the largest per bucket - the score_asof rule. Choosing one
            # provider per match by its whole-day count would let later goals pick the provider.
            goals = {k: [np.sort(gg["t"].to_numpy()) for _, gg in g.groupby("p")]
                     for k, g in ev[ev["incident_type"] == 27].groupby("match_id")}
            reds = {k: [np.sort(gg["t"].to_numpy()) for _, gg in g.groupby("p")]
                    for k, g in ev[ev["incident_type"].isin([57, 79])].groupby("match_id")}
            buckets = m["bucket"].to_numpy(dtype="datetime64[ns]")
            mids = m["match_id"].to_numpy()
            gp = {tau: np.zeros(len(m)) for tau in taus}
            rp = np.zeros(len(m))
            for mid, idx in pd.Series(np.arange(len(m))).groupby(mids).groups.items():
                idx = np.asarray(list(idx))
                t_b = buckets[idx]
                for store, arr, tau_list in ((goals, None, taus), (reds, rp, [self.settings.features.red_pulse_tau])):
                    for t in store.get(mid) or []:
                        age = (t_b[:, None] - t[None, :]).astype("timedelta64[s]").astype("float64") / 60.0
                        past = age > 0
                        for tau in tau_list:
                            val = np.where(past, np.exp(-np.clip(age, 0, None) / tau), 0.0).sum(axis=1)
                            if arr is None:
                                gp[tau][idx] = np.maximum(gp[tau][idx], val)
                            else:
                                arr[idx] = np.maximum(arr[idx], val)
            if len(taus) >= 1:
                m["goal_p3"] = np.clip(gp[taus[0]], 0, 5)
            if len(taus) >= 2:
                m["goal_p10"] = np.clip(gp[taus[1]], 0, 5)
            m["red_p10"] = np.clip(rp, 0, 3)
        since = _num(m, "minutes_since_goal")
        m["since_goal"] = np.where(np.isfinite(since), np.clip(since, 0, 120), 120.0) / 120.0
        return m

    # ---------------------------------------------------------- lifecycle
    def _group_lifecycle(self, m: pd.DataFrame) -> pd.DataFrame:
        fs = self.settings.features
        inplay = m["is_inplay"].fillna(False).astype(bool).to_numpy() if "is_inplay" in m.columns \
            else np.zeros(len(m), dtype=bool)
        minute = np.clip(np.nan_to_num(_num(m, "match_minute"), nan=0.0), 0, 130)
        pre = np.clip(np.nan_to_num(_num(m, "mins_to_ko"), nan=360.0), 0, 720)
        gs = m["game_state"].astype("string").fillna("").str.lower() if "game_state" in m.columns \
            else pd.Series("", index=m.index)
        first = gs.str.contains("first").to_numpy()
        m["inplay"] = inplay.astype(float)
        m["halftime"] = (inplay & first & (np.abs(minute - 45.0) < 1e-6)).astype(float)
        m["stoppage"] = (inplay & (minute > 90)).astype(float)
        m["pre_ko_min"] = np.where(inplay, 0.0, pre)
        m["minute"] = np.where(inplay, minute, 0.0)
        for i, k in enumerate(fs.ko_knots):
            m["ko_h{}".format(i)] = (1 - inplay) * np.maximum(pre - k, 0.0) / 360.0
        for i, k in enumerate(fs.minute_knots):
            m["min_h{}".format(i)] = inplay * np.maximum(minute - k, 0.0) / 90.0
        phase = np.where(~inplay, "prematch",
                         np.where(m["halftime"].to_numpy() > 0, "half_time",
                                  np.where(gs.str.contains("second").to_numpy(), "second_half",
                                           np.where(gs.str.contains("xtra|extra|penalt").to_numpy(),
                                                    "extra_time", "first_half"))))
        m["phase"] = phase
        tg = np.nan_to_num(_num(m, "tg"), nan=2.6)
        sup = np.nan_to_num(_num(m, "sup"), nan=0.0)
        m["tg_full"] = np.where(inplay, m["goals_so_far"].to_numpy(dtype="float64") + tg, tg)
        m["abs_sup"] = np.abs(sup)
        m["balance"] = np.clip(np.abs(sup) / np.maximum(tg, 0.05), 0, 1)
        return m

    def _group_calendar(self, m: pd.DataFrame) -> pd.DataFrame:
        b = pd.to_datetime(m["bucket"])
        hour = (b.dt.hour + b.dt.minute / 60.0).to_numpy()
        dow = b.dt.dayofweek.to_numpy()
        m["weekend"] = (dow >= 5).astype(float)
        m["holiday"] = self.calendar.is_holiday(b).astype(float)
        m["evening"] = ((hour >= 19) & (hour < 24)).astype(float)
        m["hour_s1"], m["hour_c1"] = np.sin(2 * np.pi * hour / 24), np.cos(2 * np.pi * hour / 24)
        m["hour_s2"], m["hour_c2"] = np.sin(4 * np.pi * hour / 24), np.cos(4 * np.pi * hour / 24)
        m["dow_s"], m["dow_c"] = np.sin(2 * np.pi * dow / 7), np.cos(2 * np.pi * dow / 7)
        return m

    def _group_concurrency(self, m: pd.DataFrame, money: pd.DataFrame) -> pd.DataFrame:
        m["n_board"] = m.groupby("bucket", observed=True)["match_id"].transform("nunique").astype(float)
        m["n_live"] = m.groupby("bucket", observed=True)["inplay"].transform("sum").astype(float)
        board = money.groupby("bucket", observed=True)["y"].sum()
        prev = m["bucket"].map(board.rename(lambda x: x + STEP)).fillna(0.0).to_numpy(dtype="float64")
        m["log_board_l1"] = np.log1p(prev)
        l1 = m["ml1"].to_numpy(dtype="float64")
        m["match_share_board_l1"] = _share(l1, prev, 0.0)
        rank = m.groupby("bucket", observed=True)["ml1"].rank(ascending=False, method="average")
        m["match_rank_l1"] = (rank / m["n_board"].clip(lower=1.0)).to_numpy(dtype="float64")
        return m

    # --------------------------------------------------------------- price
    def _group_price(self, b: pd.DataFrame, market: Optional[pd.DataFrame]) -> pd.DataFrame:
        od = _num(b, "odds")
        od = np.where(np.isfinite(od) & (od > 1.0), od, np.nan)
        b["imp"] = np.where(np.isfinite(od), 1.0 / od, np.nan)
        b["log_odds"] = np.log(np.where(np.isfinite(od), od, 2.0))
        line_sum = b.groupby(LKEY, observed=True)["imp"].transform("sum").to_numpy(dtype="float64")
        b["book_margin"] = line_sum - 1.0
        p_true = _num(b, "p__hkjc_true")
        p_dem = _num(b, "p__demargin")
        p_ref = np.where(np.isfinite(p_true), p_true, p_dem)
        b["p_hkjc_true"] = p_true
        b["p_poisson"] = _num(b, "p__poisson")
        b["p_demargin"] = p_dem
        b["value_true"] = np.where(np.isfinite(p_ref) & np.isfinite(od), od * p_ref - 1.0, np.nan)
        cons = market_consensus(market, self.settings.panel.bucket_minutes) if market is not None else None
        mk = asof_before(b, cons, "mkt_odds", KEY) if cons is not None and not cons.empty else np.full(len(b), np.nan)
        mk = np.where(np.isfinite(mk) & (mk > 1.0), mk, np.nan)
        b["mkt_odds"] = mk
        mimp = np.where(np.isfinite(mk), 1.0 / mk, np.nan)
        b["_mimp"] = mimp
        msum = b.groupby(LKEY, observed=True)["_mimp"].transform("sum").to_numpy(dtype="float64")
        mcount = b.groupby(LKEY, observed=True)["_mimp"].transform("count").to_numpy(dtype="float64")
        lcount = b.groupby(LKEY, observed=True)["pool_id"].transform("size").to_numpy(dtype="float64")
        full = (mcount == lcount) & (msum > 0)
        b["p_market"] = np.where(full, mimp / np.where(msum > 0, msum, 1.0), np.nan)
        b["value_mkt"] = np.where(np.isfinite(b["p_market"]) & np.isfinite(od), od * b["p_market"] - 1.0, np.nan)
        b["hk_vs_mkt"] = np.where(np.isfinite(mk) & np.isfinite(od), od / mk - 1.0, np.nan)
        b["has_mkt"] = np.isfinite(mk).astype(float)
        prev = b[KEY + ["bucket", "odds"]].rename(columns={"odds": "_o"})
        for k, name in ((1, "_o1"), (3, "_o3")):
            b = b.merge(prev.assign(bucket=prev["bucket"] + k * STEP).rename(columns={"_o": name}),
                        on=KEY + ["bucket"], how="left")
        o1 = np.where(np.isfinite(_num(b, "_o1")) & (_num(b, "_o1") > 1), _num(b, "_o1"), _num(b, "odds"))
        o3 = np.where(np.isfinite(_num(b, "_o3")) & (_num(b, "_o3") > 1), _num(b, "_o3"), o1)
        cur = _num(b, "odds")
        b["odds_move_5"] = np.where(np.isfinite(cur) & (cur > 1), np.log(np.maximum(cur, 1.001)) -
                                    np.log(np.maximum(o1, 1.001)), 0.0)
        b["odds_move_15"] = np.where(np.isfinite(cur) & (cur > 1), np.log(np.maximum(cur, 1.001)) -
                                     np.log(np.maximum(o3, 1.001)), 0.0)
        # The W06 panel's odds_age_min is measured at the END of the bucket (a line re-priced inside
        # T reads 0), which is inside the bucket being forecast. Age at the START of T is the end
        # age of T-1 plus one bucket; a line with no T-1 row was first priced within the last bucket.
        step_min = float(self.settings.panel.bucket_minutes)
        prev_age = b[KEY + ["bucket", "odds_age_min"]].rename(columns={"odds_age_min": "_age1"}) \
            if "odds_age_min" in b.columns else None
        if prev_age is not None:
            b = b.merge(prev_age.assign(bucket=prev_age["bucket"] + STEP), on=KEY + ["bucket"], how="left")
            age = np.where(np.isfinite(_num(b, "_age1")), _num(b, "_age1") + step_min, step_min / 2.0)
            b = b.drop(columns=["_age1"])
        else:
            age = np.full(len(b), step_min / 2.0)
        b["odds_age_start"] = age
        b["log_odds_age"] = np.log1p(np.clip(age, 0, 1440))
        return b.drop(columns=["_mimp", "_o1", "_o3"])

    # ------------------------------------------------------ line position
    def _group_line_position(self, b: pd.DataFrame) -> pd.DataFrame:
        live = b["forecastable"].to_numpy()
        imp = _num(b, "imp")
        b["_impn"] = imp / np.where(b["book_margin"].to_numpy(dtype="float64") > -1,
                                    b["book_margin"].to_numpy(dtype="float64") + 1.0, 1.0)
        g = b.loc[live].groupby(LKEY, observed=True)["_impn"]
        lines = (g.max() - g.min()).rename("line_balance").reset_index()
        lines["line_balance"] = lines["line_balance"].fillna(1.0)
        lines["rank"] = lines.groupby(PKEY, observed=True)["line_balance"].rank(method="first").fillna(0).astype(int) - 1
        b = b.merge(lines, on=LKEY, how="left")
        b["rank"] = b["rank"].fillna(-1).astype(int)
        b["line_balance"] = b["line_balance"].fillna(1.0)
        b["rank_0"] = (b["rank"] == 0).astype(float)
        b["rank_1"] = (b["rank"] == 1).astype(float)
        b["rank_2p"] = (b["rank"] >= 2).astype(float)
        main = b.loc[b["rank"] == 0, PKEY + ["line", "line_id"]].drop_duplicates(PKEY).rename(
            columns={"line": "_main_line", "line_id": "_main_id"})
        b = b.merge(main, on=PKEY, how="left")
        off = _num(b, "line") - _num(b, "_main_line")
        b["line_offset"] = np.where(np.isfinite(off), np.clip(off, -8, 8), 0.0)
        b["abs_line_offset"] = np.abs(b["line_offset"])
        prev_main = main.assign(bucket=main["bucket"] + STEP).rename(columns={"_main_id": "_prev_main"})
        b = b.merge(prev_main[PKEY + ["_prev_main"]], on=PKEY, how="left")
        b["main_moved"] = (b["_main_id"].notna() & b["_prev_main"].notna() &
                           (b["_main_id"] != b["_prev_main"])).astype(float)
        nl = b.loc[b["forecastable"]].groupby(PKEY, observed=True)["line_id"].nunique().rename("_nl").reset_index()
        b = b.merge(nl, on=PKEY, how="left")
        b["n_lines_pool"] = np.log1p(b["_nl"].fillna(0).to_numpy(dtype="float64"))
        first = b.loc[b["forecastable"]].groupby(KEY, observed=True)["bucket"].min().rename("_first").reset_index()
        b = b.merge(first, on=KEY, how="left")
        age = (b["bucket"] - b["_first"]).dt.total_seconds().to_numpy() / 60.0
        b["line_age"] = np.where(np.isfinite(age), np.clip(age, 0, 600), 0.0) / 600.0
        # money in the same (pool, rank, side) slot one bucket earlier, whatever line held it
        pos = b.loc[b["rank"] >= 0, ["match_id", "pool_name", "rank", "side", "bucket", "y"]]
        pos = pos.groupby(["match_id", "pool_name", "rank", "side", "bucket"], observed=True, as_index=False)["y"].sum()
        b = b.merge(_shift(pos, ["match_id", "pool_name", "rank", "side"], "y", 1, "_pos1"),
                    on=["match_id", "pool_name", "rank", "side", "bucket"], how="left")
        b["pos_share_l1"] = _share(b["_pos1"].fillna(0.0).to_numpy(dtype="float64"),
                                   b["_pl1"].to_numpy(dtype="float64"), 0.0)
        # shares of the pool, filled flat where the pool took nothing
        n_in_pool = b.groupby(PKEY, observed=True)["forecastable"].transform("sum").to_numpy(dtype="float64")
        flat = 1.0 / np.maximum(n_in_pool, 1.0)
        b["s_share_pool_l1"] = np.where(np.isfinite(b["_s1"]), b["_s1"], flat)
        b["s_share_pool_l2"] = np.where(np.isfinite(b["_s2"]), b["_s2"], flat)
        b["s_share_pool_ewma"] = np.where(np.isfinite(b["_sew"]), b["_sew"], flat)
        # favourite of its line: the shorter price
        b["is_fav"] = (b["_impn"] >= b.groupby(LKEY, observed=True)["_impn"].transform("max") - 1e-12).astype(float)
        return b.drop(columns=["_main_line", "_main_id", "_prev_main", "_nl", "_first", "_pos1", "_impn"])

    def _group_bet_type(self, b: pd.DataFrame) -> pd.DataFrame:
        fam = b["family"].astype(str).to_numpy()
        for f in C.FAMILIES:
            b["fam_" + f] = (fam == f).astype(float)
        seg = b["segment"].astype(str).to_numpy()
        b["first_half"] = (seg == "FH").astype(float)
        b["extra_time"] = (seg == "ET").astype(float)
        side = b["side"].astype(str).to_numpy()
        b["side_home_over"] = (side == "H").astype(float)
        b["side_draw"] = (side == "D").astype(float)
        return b

    def _pool_frame(self, b: pd.DataFrame, m: pd.DataFrame, money: pd.DataFrame) -> pd.DataFrame:
        live = b[b["forecastable"]]
        if live.empty:
            return pd.DataFrame(columns=PKEY + ["y", "exposure", "last5"])
        p = live.groupby(PKEY, observed=True).agg(
            y=("y", "sum"), last5=("tv1", "sum"), p_n_lines=("line_id", "nunique"),
            p_balance=("line_balance", "min"), family=("family", "first"), segment=("segment", "first"),
            league_code=("league_code", "first")).reset_index()
        main_margin = live[live["rank"] == 0].groupby(PKEY, observed=True)["book_margin"].first()
        p = p.merge(main_margin.rename("p_margin").reset_index(), on=PKEY, how="left")
        p["p_n_lines"] = np.log1p(p["p_n_lines"].to_numpy(dtype="float64"))
        p = p.merge(m[MKEY + ["y", "inplay", "minute", "pre_ko_min", "phase", "ml1", "ml2"]].rename(
            columns={"y": "exposure"}), on=MKEY, how="left")
        pm = money.groupby(PKEY, observed=True, as_index=False)["y"].sum()
        mm = money.groupby(MKEY, observed=True, as_index=False)["y"].sum()
        for k, name in ((1, "_p1"), (2, "_p2"), (3, "_p3")):
            p = p.merge(_shift(pm, ["match_id", "pool_name"], "y", k, name), on=PKEY, how="left")
            p[name] = p[name].fillna(0.0)
        p = p.merge(_shift(mm, ["match_id"], "y", 3, "ml3x"), on=MKEY, how="left")
        n_pools = p.groupby(MKEY, observed=True)["pool_name"].transform("size").to_numpy(dtype="float64")
        flat = 1.0 / np.maximum(n_pools, 1.0)
        s1 = _share(p["_p1"].to_numpy(dtype="float64"), p["ml1"].to_numpy(dtype="float64"), np.nan)
        s2 = _share(p["_p2"].to_numpy(dtype="float64"), p["ml2"].to_numpy(dtype="float64"), np.nan)
        s3 = _share(p["_p3"].to_numpy(dtype="float64"), p["ml3x"].fillna(0.0).to_numpy(dtype="float64"), np.nan)
        p["p_share_l1"] = np.where(np.isfinite(s1), s1, flat)
        p["p_share_l2"] = np.where(np.isfinite(s2), s2, flat)
        wsum = 0.6 * np.isfinite(s1) + 0.25 * np.isfinite(s2) + 0.15 * np.isfinite(s3)
        ew = 0.6 * np.nan_to_num(s1) + 0.25 * np.nan_to_num(s2) + 0.15 * np.nan_to_num(s3)
        p["p_share_ewma"] = np.where(wsum > 0, ew / np.maximum(wsum, 1e-9), flat)
        p["p_any_l1"] = (p["_p1"] > 0).astype(float)
        p["p_log_l1"] = np.log1p(p["_p1"].to_numpy(dtype="float64"))
        fam = p["family"].astype(str).to_numpy()
        ip = p["inplay"].fillna(0.0).to_numpy(dtype="float64")
        for f in C.FAMILIES:
            p["fam_" + f] = (fam == f).astype(float)
            p["fam_{}_ip".format(f)] = ((fam == f) & (ip > 0)).astype(float)
        seg = p["segment"].astype(str).to_numpy()
        p["first_half"] = (seg == "FH").astype(float)
        p["extra_time"] = (seg == "ET").astype(float)
        minute = p["minute"].fillna(0.0).to_numpy(dtype="float64")
        p["fh_to_ht"] = np.where(seg == "FH", np.where(ip > 0, np.clip((45.0 - minute) / 45.0, 0, 1), 1.0), 1.0)
        p["pool_key"] = p["pool_name"].astype(str) + "|" + p["phase"].astype(str)
        p["family_phase"] = p["family"].astype(str) + "|" + p["phase"].astype(str)
        return p.drop(columns=["_p1", "_p2", "_p3", "ml3x"])

    # ------------------------------------------------------------ outcome
    @staticmethod
    def _outcome(b: pd.DataFrame) -> pd.DataFrame:
        """Signed settlement {-1,-.5,0,.5,1} read back from the money actually paid."""
        y = _num(b, "y_frac")
        odds = _num(b, "avg_odds")
        odds = np.where(np.isfinite(odds) & (odds > 1.0), odds, _num(b, "odds"))
        settled = b["settled"].fillna(False).astype(bool).to_numpy() if "settled" in b.columns \
            else np.zeros(len(b), dtype=bool)
        ok = settled & np.isfinite(y) & np.isfinite(odds) & (odds > 1.0)
        out = np.full(len(b), np.nan)
        if ok.any():
            o = odds[ok]
            paid = y[ok] * o
            cand = np.stack([o, 0.5 * o + 0.5, np.ones_like(o), 0.5 * np.ones_like(o), np.zeros_like(o)], axis=1)
            gap = np.abs(cand - paid[:, None])
            pick = gap.argmin(axis=1)
            best = gap[np.arange(len(pick)), pick]
            tol = np.maximum(0.02, 0.125 * (o - 1.0))
            res = np.where(best <= tol, np.take([1.0, 0.5, 0.0, -0.5, -1.0], pick), np.nan)
            out[ok] = res
        out = np.where(out == 0.0, np.nan, out)      # pushes carry no information on p
        b["outcome"] = out
        b["_yf"] = np.where(b["forecastable"].to_numpy(), b["y"].to_numpy(dtype="float64"), 0.0)
        b["pool_y"] = b.groupby(PKEY, observed=True)["_yf"].transform("sum").to_numpy(dtype="float64")
        b["inplay"] = b["inplay"].fillna(0.0)
        return b.drop(columns=["_yf"])

    # ------------------------------------------------------------- finish
    def _finish(self, frame: pd.DataFrame, specs: Sequence[C.FeatureSpec], encode: str) -> pd.DataFrame:
        cols: Dict[str, np.ndarray] = {}
        enc = self._encode(frame, encode)
        for s in specs:
            if s.name in enc:
                v = enc[s.name]
            elif s.name in frame.columns:
                v = pd.to_numeric(frame[s.name], errors="coerce").to_numpy(dtype="float64")
            else:
                v = np.full(len(frame), s.fill, dtype="float64")
            v = np.where(np.isfinite(v), v, s.fill)
            if s.lo is not None or s.hi is not None:
                v = np.clip(v, s.lo, s.hi)
            cols[s.name] = v.astype("float32")
        return pd.DataFrame(cols)

    def _encode(self, frame: pd.DataFrame, which: str) -> Dict[str, np.ndarray]:
        out: Dict[str, np.ndarray] = {}
        if which in ("league", "both") and self.encoders.league is not None and "league_code" in frame.columns:
            lv, known = self.encoders.league.transform(frame)
            out["league_level"], out["league_known"] = lv, known
        if which in ("pool", "both") and self.encoders.pool is not None:
            if "pool_key" in frame.columns:
                f = frame
            else:
                phase = frame["phase"].astype(str) if "phase" in frame.columns \
                    else pd.Series("prematch", index=frame.index)
                f = pd.DataFrame({"pool_key": frame["pool_name"].astype(str) + "|" + phase,
                                  "family_phase": frame["family"].astype(str) + "|" + phase}, index=frame.index)
            lv, _ = self.encoders.pool.transform(f)
            out["pool_level"] = lv
        return out

    @staticmethod
    def _kinds(specs: Sequence[C.FeatureSpec]) -> Dict[str, str]:
        return {s.name: s.kind for s in specs}

    @staticmethod
    def _cuts(frame: pd.DataFrame) -> pd.DataFrame:
        def lab(col, default):
            if col not in frame.columns:
                return default
            return frame[col].astype("string").fillna("unknown").to_numpy(dtype=object)
        out = pd.DataFrame(index=frame.index)
        out["phase"] = lab("phase", "unknown")
        out["pool"] = lab("pool_name", "match")
        out["family"] = lab("family", "match")
        out["league"] = lab("league_code", "unknown")
        out["event_window"] = lab("event_window", "unknown")
        out["clock_bin"] = lab("clock_bin", "unknown")
        out["day"] = pd.to_datetime(frame["bucket"]).dt.normalize().astype("datetime64[ns]").to_numpy()
        return out.reset_index(drop=True)

    # --------------------------------------------------------- encoders
    def fit_encoders(self, days: Sequence[DayData]) -> EncoderState:
        from .encoders import fit_encoders
        fs = self.settings.features
        self.encoders = fit_encoders([d.match for d in days if not d.empty],
                                     [d.pool for d in days if not d.empty], fs.league_prior, fs.pool_prior)
        return self.encoders
