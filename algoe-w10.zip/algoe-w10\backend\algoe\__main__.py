import sys

from .cli import main

# Windows starts optimizer worker processes by re-importing this module as __mp_main__;
# they must not run the command again.
if __name__ == "__main__":
    sys.exit(main())
