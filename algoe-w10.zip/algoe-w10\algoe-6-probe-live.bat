@echo off
REM Algo E - live money probe: one match's money rows from the live feed (ticket_bets_dtl_agg_mem),
REM checked the way the models were trained to read money - one row per selection and minute,
REM money per interval and not a running total - plus the first-half split against HKJC's own
REM first-half prices. Writes AlgoE_Work\diagnostics\<stamp>_probe_<match>\ - read verdict.txt first.
REM     algoe-6-probe-live.bat --match 1234567              the last 60 minutes
REM     algoe-6-probe-live.bat --match 1234567 --tickets    also the bet tables, same minutes
REM The match id is the number in the desk's address: http://localhost:3000/match/<id>
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe probe-live %*
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo All checks passed.) else if "%CODE%"=="2" (echo Finished with warnings - read verdict.txt.) else (echo A check FAILED - do not trust the live money on the desk until it is fixed. Send verdict.txt back.)
pause
exit /b %CODE%
