"""
Step 11 - model versions

    python scripts/s11_models.py                          every version, * = champion
    python scripts/s11_models.py history                  every promotion and why
    python scripts/s11_models.py promote --kind turnover --version 20261001-020606-three_stage-gbm_gbm_gbm
                                                          roll back (or forward) by hand

Same as: python -m algoe models
"""
from _algoe import run

if __name__ == "__main__":
    run("models")
