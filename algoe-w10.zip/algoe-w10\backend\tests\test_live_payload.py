"""
Live payload tests - the W10 engine's state in the shapes the desk draws

    python tests/test_live_payload.py            plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_live_payload.py

Built on the simulator frozen at one moment (test_algoe._FrozenSim): no models, no SQL. The
routes are exercised in-process when FastAPI's TestClient (httpx) is installed.

Change Log:
-----------
2026-10-26      Initialize
"""

import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from contract import (BOARD, BOARD_MATCH, COCKPIT, CURVE, EXPECTED_GM, FAMILY, LINE, LIVE_BOARD_MATCH,  # noqa: E402
                      LIVE_COCKPIT, LIVE_FLOW, LIVE_FRESHNESS, LIVE_MODELS, LIVE_SELECTION, MATCH_HEADER, OPTIMIZER,
                      POOL, SELECTION, STATUSES, THETA_BLOCK, WHATIF, WHATIF_SEL)
from test_algoe import _FrozenSim, _frozen_engine  # noqa: E402

T0 = pd.Timestamp("2026-10-26 15:47:00")


def _engine(tmp):
    src = _FrozenSim(T0)
    bare, _ = src.match("FirstHalf")
    src.drop_params(bare)
    eng = _frozen_engine(tmp, src)
    eng.run_sweep(T0)
    mid, _ = src.match("Prematch")
    eng.request_focus(mid)
    eng.run_focus(mid, T0 + pd.Timedelta(minutes=1))
    return eng, mid, bare


def _selections(ck):
    return [s for f in ck["book"]["families"] for p in f["pools"] for line in p["lines"] for s in line["selections"]]


def test_cockpit_carries_every_field_the_desk_reads():
    from src.api import live_payload
    with tempfile.TemporaryDirectory() as tmp:
        eng, mid, _ = _engine(tmp)
        ck = live_payload.cockpit(eng, mid)
    assert set(COCKPIT) <= set(ck) and set(LIVE_COCKPIT) <= set(ck)
    assert set(MATCH_HEADER) <= set(ck["match"]) and set(THETA_BLOCK) <= set(ck["theta"])
    assert set(LIVE_FRESHNESS) <= set(ck["freshness"]) and set(LIVE_MODELS) <= set(ck["models"])
    assert set(LIVE_FLOW) <= set(ck["flow"]) and set(OPTIMIZER) <= set(ck["optimizer"])
    assert ck["freshness"]["mode"] == "focus" and ck["freshness"]["refreshing"] is False
    assert ck["freshness"]["board_at"] == (T0 + pd.Timedelta(minutes=1)).isoformat()
    assert ck["models"]["fallback"]                                     # no model trained in this test
    sels = _selections(ck)
    for s in sels:
        assert set(SELECTION) <= set(s) and set(LIVE_SELECTION) <= set(s), s["key"]
        assert s["status"] in STATUSES
    modelled = [s for s in sels if s["modelled"]]
    assert modelled and all(s["t_hat"] == s["forecast"] for s in modelled)
    assert any(s["in_book"] and s["sell_odds_star"] is not None for s in modelled)
    other = [f for f in ck["book"]["families"] if f["family"] == "HKJC only"]
    assert other and all(not s["modelled"] and s["t_hat"] is None and s["hkjc_odds"]
                         for p in other[0]["pools"] for line in p["lines"] for s in line["selections"])
    for f in ck["book"]["families"]:
        assert set(FAMILY) <= set(f)
        for p in f["pools"]:
            assert set(POOL) <= set(p)
            for line in p["lines"]:
                assert set(LINE) <= set(line)
    assert ck["theta"]["layers"]["Current"]["goal_tg"] is not None and len(ck["theta"]["dims"]) == 8
    assert ck["match"]["home"] and ck["match"]["phase"] == "prematch"
    teams = (ck["match"]["home"], ck["match"]["away"])
    assert not [s["sel_label"] for s in sels if any(t in s["sel_label"] for t in teams)]   # the header names the teams
    had = {s["sel_label"] for s in sels if s["pool_code"] == "HAD"}
    assert "Home" in had and had <= {"Home", "Draw", "Away"}, had


def test_board_lists_every_match_on_the_panel():
    from src.api import live_payload
    with tempfile.TemporaryDirectory() as tmp:
        eng, mid, bare = _engine(tmp)
        board = live_payload.board(eng)
    assert set(BOARD) <= set(board)
    ids = {m["match_id"] for m in board["matches"]}
    assert mid in ids and bare in ids
    for m in board["matches"]:
        assert set(BOARD_MATCH) <= set(m) and set(LIVE_BOARD_MATCH) <= set(m), m["match_id"]
    row = next(m for m in board["matches"] if m["match_id"] == bare)
    assert row["status"] == "no book" and not row["solved"] and row["pending"] is False
    assert any("no book" in a["text"] for a in row["alerts"])
    assert board["progress"]["total"] == len(board["matches"])
    opened = next(m for m in board["matches"] if m["match_id"] == mid)
    assert opened["mode"] == "sweep" and opened["focused"] is True     # the sweep's row; its cockpit is live
    assert row["focused"] is False


def test_what_if_and_curves_price_on_the_last_book():
    from src.api import live_payload
    with tempfile.TemporaryDirectory() as tmp:
        eng, mid, _ = _engine(tmp)
        ck = live_payload.cockpit(eng, mid)
        tg = ck["theta"]["layers"]["Current"]["goal_tg"]
        what = live_payload.what_if(eng, mid, {"goal_tg": tg + 0.2})
        curves = live_payload.curves(eng, mid)
        assert live_payload.cockpit(eng, 999) is None and live_payload.what_if(eng, 999, {}) is None
    assert set(WHATIF) <= set(what) and set(EXPECTED_GM) <= set(what["expected"])
    assert abs(what["theta"]["goal_tg"] - (tg + 0.2)) < 1e-9
    assert what["selections"] and all(set(WHATIF_SEL) <= set(s) for s in what["selections"])
    teams = (ck["match"]["home"], ck["match"]["away"])
    assert not [s["sel_label"] for s in what["selections"] if any(t in s["sel_label"] for t in teams)]
    assert any(abs((s["sell_odds_what"] or 0) - (s["sell_odds"] or 0)) > 1e-6 for s in what["selections"])
    assert what["expected"]["gm"] != what["baseline"]["gm"]
    goal = curves["curves"]["goal_tg"]
    assert set(CURVE) <= set(goal) and len(goal["x"]) == len(goal["gm"]) == 13
    assert min(goal["x"]) <= goal["now"] <= max(goal["x"])


def test_routes_serve_the_live_desk():
    try:
        from fastapi.testclient import TestClient
    except Exception:                                                   # noqa: BLE001
        return                                                          # no httpx on this box
    from src.api import main as api
    from src.api.routes import live
    with tempfile.TemporaryDirectory() as tmp:
        eng, mid, _ = _engine(tmp)
        eng.start = lambda poll_seconds=1.0: None                         # the test drives the engine itself
        old = live._engine
        live._engine = eng
        try:
            client = TestClient(api.app)
            ck = client.get("/api/live/desk/{}".format(mid), params={"open": 1}).json()
            assert ck["freshness"]["refreshing"] is True                # asked just now, not refreshed since
            eng.run_focus(mid, T0 + pd.Timedelta(minutes=1, seconds=15))
            ck = client.get("/api/live/desk/{}".format(mid)).json()
            assert ck["freshness"]["refreshing"] is False and mid in eng.focused()
            board = client.get("/api/live/desk").json()
            assert {m["match_id"] for m in board["matches"]} >= {mid}
            tg = ck["theta"]["layers"]["Current"]["goal_tg"]
            what = client.post("/api/live/desk/{}/price".format(mid), json={"theta": {"goal_tg": tg + 0.1}}).json()
            assert abs(what["theta"]["goal_tg"] - (tg + 0.1)) < 1e-9
            assert client.get("/api/live/desk/{}/curves".format(mid)).status_code == 200
            assert client.get("/api/live/desk/999").status_code == 404
            assert client.delete("/api/live/focus/{}".format(mid)).json()["focused"] == []
        finally:
            live._engine = old


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<48} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<48} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
