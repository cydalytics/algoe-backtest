"""
Live Engine

Keeps a TG/SUP recommendation for every active match, refreshed at two
speeds, because the desk cannot wait five minutes after a goal and the box
cannot re-solve a hundred matches every fifteen seconds.

    SWEEP (every bucket boundary, all matches; its own thread)
        fetch everything -> panel (same code as training) -> features
        -> bucket forecast F per selection (champion turnover pipeline)
        -> belief p per selection (champion calibration)
        -> optimise every match with enough expected money, richest first,
           inside a time budget, in parallel
        Every match on the panel is listed, with or without a book to solve.
    FOCUS (every ~15 s, only the matches the desk has open or a trigger fired on;
           its own thread and its own source, so a sweep never holds it up)
        fetch THAT match only -> the board as it stands now: the newest odds and
           true odds, HKJC's newest TG/SUP, the clock and the score at the refresh
           (LivePanelBuilder.build(board_at=)), not at the bucket start
        -> nowcast: remaining = rate x (5 - elapsed), rate from F and what has
           arrived (realtime/nowcast.py); the next bucket carries the surge
        -> belief from those prices
        -> re-optimise that match from its last answer (warm start, one start,
           each dimension limited to max_step from the last recommendation)
        The bucket forecast F stays the sweep's: it is the one built on the inputs
        the model was trained on.

    TRIGGERS refresh a match at once and keep it on focus refreshes for
    trigger_focus_seconds: a goal, red card or corner (or its cancellation), a
    main-line price moving more than trigger_odds_move, or one minute's money
    exceeding trigger_big_bet_multiple times what the forecast expected for a minute.

    AFTER AN EVENT inside the bucket, the rest of the bucket is forecast from the
    bucket forecast shifted by the fitted EventShift (models/event_shift.py: what
    a goal / red card / corner at this clock, by this side, with this favourite and
    this score does to each bet type and side), and the nowcast's evidence is the
    money since the event, not since the bucket started. The next sweep sees the
    event in its features.

A UI heartbeat keeps a match in focus (``focus_on``); without one the focus
lapses after focus_ttl_seconds, so a forgotten tab does not cost CPU forever.
``request_focus`` is the desk opening a match: it wakes the focus thread at once.

Everything the engine publishes is also appended to the monitor's forecast
log, where the next sweep joins the money that actually arrived.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Days built with prepare_live; a price-move trigger resets after its refresh, a big-money
                trigger fires once per minute
2026-10-11      Corners and VAR cancellations trigger too; a trigger keeps its match on focus refreshes
                (it used to refresh once); the rest of the bucket after an event is re-tuned with the
                fitted event shift and nowcast from the money since the event
2026-10-26      Focus prices on the board at the refresh (board_at), not at the bucket start; a focus
                thread with its own source beside the sweep thread; request_focus; every match on the
                panel listed; header, every selection's prices and flow, the book and the trader's
                extras (quotes, incidents, price history) kept per match
"""

from __future__ import annotations

import heapq
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import KEY, LivePanelBuilder
from ..features.engineer import FeatureEngineer, _kickoff_value
from ..models.event_shift import (PRIORITY, EventShift, clock_label, incident_table, main_provider, side_groups,
                                  state_label, strength_label, who_label)
from ..optimizer.theta_optimizer import (DemandResponse, MatchBook, MatchDecision, ThetaOptimizer, build_books,
                                         desk_weightings, publish_odds)
from ..pricing.pricer import repair_theta
from .nowcast import BucketNowcaster

logger = get_logger(__name__)


@dataclass
class MatchLive:
    match_id: int
    bucket: Optional[pd.Timestamp] = None
    forecast: Optional[pd.DataFrame] = None       # KEY + forecast for the current bucket (from the sweep)
    decision: Optional[MatchDecision] = None
    view: Optional[pd.DataFrame] = None           # per book selection: odds now / star, belief, demand
    refreshed_at: Optional[pd.Timestamp] = None
    mode: str = "sweep"
    triggers: List[str] = field(default_factory=list)
    last_events: tuple = ()                       # incident counts by code, the main provider's
    event: Optional[dict] = None                  # the event the rest of this bucket is re-tuned for
    last_main_odds: Dict[tuple, float] = field(default_factory=dict)
    last_big_minute: Optional[pd.Timestamp] = None
    observed: float = 0.0
    remaining: float = 0.0
    hot: float = 1.0
    weights: Dict[tuple, float] = field(default_factory=dict)    # last stage-2 weighting per selection
    header: dict = field(default_factory=dict)    # teams, league, kick-off, phase, clock, score, corners, reds
    rows: Optional[pd.DataFrame] = None           # every selection of the bucket, in the book or not
    book: Optional[MatchBook] = None              # the last book solved: what-ifs and curves price on it
    extras: dict = field(default_factory=dict)    # focus refreshes: quotes, incidents, price history, all prices
    board_at: Optional[pd.Timestamp] = None       # when the prices, TG/SUP and score in use were read
    params_at: Optional[pd.Timestamp] = None      # the TG/SUP row in use
    requested_at: Optional[float] = None          # wall clock of the desk's last request for a refresh
    refresh_started: Optional[float] = None       # wall clock the last finished focus refresh started
    error: Optional[str] = None                   # why the last focus refresh failed, until one succeeds
    failed_at: Optional[pd.Timestamp] = None      # the last failed focus refresh: the retry waits an interval
    board_row: Optional[dict] = None              # the match as the last sweep priced it: its row on the board

    @property
    def refreshing(self) -> bool:
        """The desk asked for a refresh that has not finished yet."""
        return self.requested_at is not None and (self.refresh_started is None
                                                  or self.refresh_started < self.requested_at)

    def summary(self) -> dict:
        d, h, rows = self.decision, self.header, self.rows
        listed = rows is not None and len(rows) > 0
        age = (self.board_at - self.params_at).total_seconds() / 60.0 \
            if self.board_at is not None and self.params_at is not None else None
        return {"match_id": self.match_id, "bucket": str(self.bucket), "mode": self.mode,
                "refreshed_at": str(self.refreshed_at), "triggers": list(self.triggers),
                "status": d.status if d else ("no book" if rows is not None else "pending"),
                "lift": d.lift if d else 0.0,
                "lift_bps": d.lift_bps if d else 0.0, "turnover": d.turnover if d else 0.0,
                "theta_now": d.theta_now if d else {}, "theta_star": d.theta_star if d else {},
                "observed_in_bucket": self.observed, "remaining_in_bucket": self.remaining,
                "hot": self.hot, "binding": d.binding if d else [],
                "event_in_bucket": (self.event or {}).get("labels"),
                "home": h.get("home"), "away": h.get("away"), "league": h.get("league"),
                "league_code": h.get("league_code"), "kickoff": h.get("kickoff"), "phase": h.get("phase"),
                "minute": h.get("minute"), "in_play": h.get("in_play"), "score": h.get("score"),
                "corners": h.get("corners"), "board_at": _stamp(self.board_at), "params_at": _stamp(self.params_at),
                "theta_age_min": age, "gm_now": d.egm_board if d else None, "gm_star": d.egm_star if d else None,
                "expected": float(np.nansum(rows["forecast"])) if listed else 0.0,
                "last_bucket": float(np.nansum(rows["last_bucket"])) if listed else 0.0,
                "tickets_last_bucket": float(np.nansum(rows["tickets_last_bucket"])) if listed else 0.0,
                "selections": int(len(rows)) if rows is not None else 0,
                "pools": int(rows["pool_id"].nunique()) if listed else 0,
                "open": int(rows["forecastable"].sum()) if listed else 0,
                "in_book": int(rows["in_book"].sum()) if listed else 0,
                "refreshing": self.refreshing, "error": self.error}


class LiveEngine:
    def __init__(self, settings, source=None, forecaster=None, calibrator=None, monitor=None, clock=None,
                 focus_source=None):
        self.settings = settings
        self.source = source if source is not None else _default_source(settings)
        self.focus_source = focus_source if focus_source is not None else _second_source(self.source)
        self.forecaster = forecaster
        self.calibrator = calibrator
        self.monitor = monitor
        self.engineer = forecaster.engineer if forecaster is not None else FeatureEngineer(settings)
        self.builder = LivePanelBuilder(settings)
        # money features are in market-index units; with no cached day to size the market, the model's own
        self.builder.market_index_fallback = (getattr(forecaster, "metadata", None) or {}).get("market_index_last")
        # The historical extraction has no HKJC true odds while the live feed does: a model trained without
        # them must see the price inputs it learned on (de-margined odds, Poisson), not new ones.
        coverage = (getattr(forecaster, "metadata", None) or {}).get("true_odds_coverage")
        if coverage is not None and np.isfinite(coverage) and coverage < 0.5:
            self.builder.ignore_true_odds = True
            logger.warning("the turnover model was trained with HKJC true odds on %.0f%% of rows; live true odds are "
                           "ignored so its inputs match. Re-extract history with true odds to use them.",
                           100 * coverage)
        self.optimizer = ThetaOptimizer(settings, DemandResponse.from_forecaster(forecaster, settings))
        self.nowcaster = forecaster.nowcaster if forecaster is not None else BucketNowcaster(
            settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes,
            max_hot=settings.live.nowcast_max_hot)
        self.event_shift: Optional[EventShift] = None
        if settings.live.event_shift:
            path = EventShift.default_path(settings)
            self.event_shift = EventShift.load(path)
            if self.event_shift is None:
                logger.info("no event shift at %s: after an event the rest of the bucket follows the money arriving "
                            "only (algoe-3-backtest.bat --only events fits it)", path)
            else:
                logger.info("event shift: %d cell(s), fitted %s on %s", len(self.event_shift.cells),
                            self.event_shift.meta.get("fitted"), self.event_shift.meta.get("turnover_model"))
        self.clock = clock or (lambda: pd.Timestamp.now())
        self.matches: Dict[int, MatchLive] = {}
        self.card: set = set()                        # the matches on the last sweep's panel
        self.focus: Dict[int, float] = {}
        self._queue: List[Tuple[float, float, int, str]] = []    # (-priority, wall time asked, match, reason)
        self._lock = threading.RLock()
        self._model_lock = threading.Lock()           # one model prediction at a time across the two threads
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._focus_thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.last_sweep: dict = {}

    # ============================================================ interest
    def focus_on(self, match_id: int, ttl: Optional[float] = None) -> None:
        with self._lock:
            self.focus[int(match_id)] = time.time() + (ttl or self.settings.live.focus_ttl_seconds)

    def focus_off(self, match_id: int) -> None:
        with self._lock:
            self.focus.pop(int(match_id), None)

    def focused(self) -> List[int]:
        now = time.time()
        with self._lock:
            for m in [m for m, t in self.focus.items() if t < now]:
                self.focus.pop(m, None)
            return sorted(self.focus)

    def trigger(self, match_id: int, reason: str, priority: float = 1.0, focus: Optional[str] = None) -> None:
        """Refresh the match at the next focus step; ``focus`` (goal / red / corner / price / money) also keeps
        it on focus refreshes for live.trigger_focus_seconds[focus]."""
        with self._lock:
            heapq.heappush(self._queue, (-priority, time.time(), int(match_id), reason))
            live = self.matches.setdefault(int(match_id), MatchLive(int(match_id)))
            live.triggers = (live.triggers + [reason])[-5:]
            ttl = float(self.settings.live.trigger_focus_seconds.get(focus, 0.0)) if focus else 0.0
            if ttl > 0:
                self.focus[int(match_id)] = max(self.focus.get(int(match_id), 0.0), time.time() + ttl)
        self._wake.set()
        logger.info("trigger match %s: %s", match_id, reason)

    def request_focus(self, match_id: int, reason: str = "opened on the desk", ttl: Optional[float] = None) -> float:
        """The desk opened the match: keep it in focus and refresh it now. Returns the wall time of the
        request; the match reads ``refreshing`` until a refresh that started after it has finished."""
        mid, now = int(match_id), time.time()
        self.focus_on(mid, ttl)
        with self._lock:
            self.matches.setdefault(mid, MatchLive(mid)).requested_at = now
        self.trigger(mid, reason, priority=3.0)
        return now

    def models(self) -> dict:
        """What is serving: the champions, or the W06 MVP rule where there is none."""
        tf, pc = self.forecaster, self.calibrator
        return {"turnover": getattr(tf, "version", None), "turnover_pipeline": getattr(tf, "champion", None),
                "probability": getattr(pc, "version", None), "probability_method": getattr(pc, "champion", None),
                "fallback": [name for name, m in (("turnover: last 5 minutes", tf),
                                                  ("belief: 1 / HKJC true odds", pc)) if m is None]}

    # ================================================================ sweep
    def run_sweep(self, as_of=None) -> dict:
        as_of = pd.Timestamp(as_of or self.clock())
        started = time.time()
        snap = self.source.fetch(as_of)
        t_fetch = time.time() - started
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            with self._lock:
                self.card = set()
            self.last_sweep = {"as_of": str(as_of), "matches": 0, "note": "no active matches"}
            return self.last_sweep
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        t_feat = time.time() - started - t_fetch
        forecast = self._forecast(day)
        belief = self._belief(day)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        with self._lock:
            prev = {m: l.decision.theta_star for m, l in self.matches.items() if l.decision is not None}
            wprev = {m: l.weights for m, l in self.matches.items() if l.weights}
        books = build_books(day.sel[now_rows], day.match, forecast[now_rows], belief[now_rows], self.settings,
                            theta_prev=prev, weights_prev=wprev)
        t_prep = time.time() - started - t_fetch - t_feat
        decisions = self.optimizer.optimize_card(books, mode="sweep")
        t_opt = time.time() - started - t_fetch - t_feat - t_prep
        sel_now = day.sel[now_rows].reset_index(drop=True)
        F, p = forecast[now_rows], belief[now_rows]
        fc_now = pd.DataFrame({**{k: sel_now[k].to_numpy() for k in KEY + ["match_id", "pool_name"]},
                               "forecast": F, "belief": p, "odds": sel_now["odds"].to_numpy(dtype="float64")})
        # at the bucket start the whole bucket is still to come
        rows = _rows(sel_now, F, np.zeros(len(sel_now)), F, F, p)
        info = self.builder._canon("matches", snap.match_info).drop_duplicates("match_id")
        params_at = _params_at(panel, current)
        by_book = {bk.match_id: bk for bk in books}
        mids = sel_now["match_id"].astype("int64").to_numpy()
        listed = sorted(set(mids.tolist()))
        with self._lock:
            self.card = set(listed)
            for mid in listed:
                live = self.matches.setdefault(mid, MatchLive(mid))
                mine = fc_now[fc_now["match_id"] == mid].reset_index(drop=True)
                bk, dec = by_book.get(mid), decisions.get(mid)
                # the board ranks the whole card on this sweep's bucket; a focus read prices another horizon
                swept = MatchLive(mid, bucket=current, mode="sweep", refreshed_at=as_of, decision=dec,
                                  rows=_with_book(rows[mids == mid].reset_index(drop=True), bk, dec),
                                  header=_header(info, day.match, mid, current), board_at=current,
                                  params_at=params_at.get(mid), remaining=float(np.nansum(F[mids == mid])))
                live.board_row = swept.summary()
                if live.mode == "focus" and live.refreshed_at is not None and live.refreshed_at > as_of:
                    # a focus refresh has read a newer board than this sweep: keep it, take the bucket forecast
                    live.forecast = mine
                    continue
                live.bucket, live.mode, live.refreshed_at = current, "sweep", as_of
                live.board_at, live.params_at = current, swept.params_at
                live.forecast = mine
                live.decision, live.book = dec, bk
                live.view = _view(bk, dec) if bk is not None else None
                live.weights = _weights_by_key(bk, dec) if bk is not None else {}
                live.rows = swept.rows
                live.header = swept.header
                live.observed, live.remaining, live.hot = 0.0, swept.remaining, 1.0
                live.last_events = self._event_signature(extra["events"], mid)
                live.event = None
                live.last_main_odds = _main_odds(bk) if bk is not None else {}
        if self.monitor is not None:
            self.monitor.log_forecasts(current, fc_now, model=getattr(self.forecaster, "version", None))
        self.last_sweep = {"as_of": str(as_of), "bucket": str(current), "matches": len(books), "listed": len(listed),
                           "solved": sum(1 for d in decisions.values() if d.status.startswith("solved")),
                           "lift": float(sum(d.lift for d in decisions.values())),
                           "lift_weightings": float(sum(d.lift_stage2 for d in decisions.values())),
                           "turnover": float(sum(d.turnover for d in decisions.values())),
                           "seconds": {"fetch": round(t_fetch, 2), "features": round(t_feat, 2),
                                       "books": round(t_prep, 2), "optimise": round(t_opt, 2),
                                       "total": round(time.time() - started, 2)}}
        logger.info("sweep %s: %d match(es), %d with a book, E[GM] lift %.0f on %.0f expected, %.1fs (%s)",
                    current.strftime("%H:%M"), len(listed), len(books), self.last_sweep["lift"],
                    self.last_sweep["turnover"], self.last_sweep["seconds"]["total"], self.last_sweep["seconds"])
        return self.last_sweep

    def _forecast(self, day) -> np.ndarray:
        if self.forecaster is None:
            return day.sel["tv1"].to_numpy(dtype="float64")
        with self._model_lock:
            return self.forecaster.predict_selection_turnover(day)["forecast"].to_numpy(dtype="float64")

    def _belief(self, day) -> np.ndarray:
        raw = day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        if self.calibrator is None:
            return raw
        with self._model_lock:
            p = self.calibrator.predict_for_day(day)
        return np.where(np.isfinite(p), p, raw)

    # ================================================================ focus
    def run_focus(self, match_id: int, as_of=None) -> Optional[MatchLive]:
        """Refresh one match on the board as it stands now: the newest prices, TG/SUP and score, the rest of
        the bucket nowcast from the money already in, re-optimised from the last answer."""
        as_of = pd.Timestamp(as_of or self.clock())
        mid = int(match_id)
        started = time.time()
        with self._lock:
            live = self.matches.setdefault(mid, MatchLive(mid))
        try:
            return self._focus(live, mid, as_of, started)
        except Exception as exc:
            with self._lock:
                # the desk's request is answered with the error; the next try waits an interval
                live.error = "{}: {}".format(type(exc).__name__, exc)
                live.refresh_started, live.failed_at = started, as_of
            raise

    def _focus(self, live: MatchLive, mid: int, as_of: pd.Timestamp, started: float) -> MatchLive:
        with self._lock:
            forecast, bucket, decision, weights = live.forecast, live.bucket, live.decision, live.weights
        snap = _only(self.focus_source.fetch(as_of, match_ids=[mid]), mid)
        current = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        events = self.builder._canon("events", snap.events)
        has_event = self.event_shift is not None and self._event_since(events, mid, current, as_of)
        # The bucket forecast is the sweep's. A match the sweep has not forecast for this bucket, or an event
        # inside it (its labels read the state at the bucket start), needs the bucket-start board as well.
        start = None
        own_forecast = forecast is None or bucket != current
        if own_forecast or has_event:
            panel0, extra0 = self.builder.build(snap, as_of)
            if not panel0.empty:
                start = self.engineer.prepare_live(panel0, extra0)
        board, bx = self.builder.build(snap, as_of, board_at=as_of)
        day = self.engineer.prepare_live(board, bx) if not board.empty else None
        edge = bx["current_bucket"]
        now_rows = (day.sel["bucket"] == edge).to_numpy() if day is not None and not day.empty else None
        sel_now = day.sel[now_rows].reset_index(drop=True) if now_rows is not None else pd.DataFrame()
        if sel_now.empty:
            with self._lock:
                live.refresh_started, live.failed_at = started, as_of
                live.error = "no priced selection on the board at {:%H:%M:%S}".format(as_of)
            return live
        if own_forecast and start is not None:
            s_rows = (start.sel["bucket"] == current).to_numpy()
            mine = start.sel.loc[s_rows, KEY + ["match_id", "pool_name"]].reset_index(drop=True) \
                .assign(forecast=self._forecast(start)[s_rows])
        elif own_forecast:
            mine = None
        else:
            mine = forecast
        F = sel_now[KEY].merge(mine[KEY + ["forecast"]], on=KEY, how="left")["forecast"].fillna(0.0) \
            .to_numpy(dtype="float64") if mine is not None else np.zeros(len(sel_now))
        lag = self.settings.live.data_lag_seconds
        observed = _observed(snap.investments, sel_now, current, as_of)
        elapsed = max((as_of - current).total_seconds() - lag, 0.0) / 60.0
        ev = self._event_in_bucket(events, start.match, mid, current, as_of) \
            if has_event and start is not None else None
        if ev is not None:
            # the rest of the bucket comes after the event: its forecast shifted for it, and the evidence is the
            # money since the event (the feed floors a bet to its minute)
            groups = side_groups(sel_now["family"].to_numpy(dtype=object), sel_now["side"].to_numpy(dtype=object),
                                 np.nan_to_num(pd.to_numeric(sel_now.get("fav_sign", 0.0), errors="coerce")))
            F_post = F * self.event_shift.multipliers(groups, ev["labels"])
            since = pd.Timestamp(ev["time"]).floor("min")
            x_post = _observed(snap.investments, sel_now, since, as_of)
            e_post = max((as_of - since).total_seconds() - lag, 0.0) / 60.0
            nc = self.nowcaster.update(F_post, x_post, e_post, match_key=sel_now["match_id"].to_numpy(),
                                       next_forecast=F_post,
                                       left=max(self.settings.panel.bucket_minutes - elapsed, 0.0))
        else:
            nc = self.nowcaster.update(F, observed, elapsed, match_key=sel_now["match_id"].to_numpy(), next_forecast=F)
        horizon = nc.remaining + nc.next_bucket
        belief = self._belief(day)[now_rows]
        prev = {mid: decision.theta_star} if decision is not None else None
        books = build_books(sel_now, day.match, horizon, belief, self.settings, theta_prev=prev,
                            weights_prev={mid: weights} if weights else None)
        bk = books[0] if books else None
        dec = self.optimizer.optimize_match(bk, mode="focus") if bk is not None else None
        rows = _with_book(_rows(sel_now, F, observed, nc.remaining, nc.next_bucket, belief), bk, dec)
        info = self.builder._canon("matches", snap.match_info).drop_duplicates("match_id")
        shift = bx.get("board_shift", pd.Timedelta(0))
        p_at = _params_at(board, edge).get(mid)
        extras = _extras(self.builder, snap, mid, as_of)
        with self._lock:
            if live.refreshed_at is not None and live.refreshed_at > as_of:
                # a sweep that read a newer board landed while this refresh ran: it stays
                live.refresh_started, live.error = started, None
                logger.info("focus %s @%s: a newer board (%s) landed meanwhile; not published", mid,
                            as_of.strftime("%H:%M:%S"), live.refreshed_at)
                return live
            live.bucket, live.mode, live.refreshed_at = current, "focus", as_of
            live.board_at, live.params_at = bx.get("board_at", as_of), (p_at - shift) if p_at is not None else None
            if own_forecast and mine is not None:
                live.forecast = mine
            live.decision, live.book = dec, bk
            live.view = _view(bk, dec).assign(bucket=current) if bk is not None else None
            live.weights = _weights_by_key(bk, dec) if bk is not None else {}
            live.rows = rows
            live.header = _header(info, day.match, mid, edge)
            live.extras = extras
            live.observed = float(observed.sum())
            live.remaining = float(nc.remaining.sum())
            live.hot = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
            # the board this refresh priced on is the reference the next price-move trigger reads against
            live.last_main_odds = _main_odds(bk) if bk is not None else {}
            live.last_events = self._event_signature(events, mid)
            live.event = ev
            live.refresh_started = started
            live.error, live.failed_at = None, None
        logger.info("focus %s @%s: observed %.0f, remaining %.0f (hot x%.2f)%s, lift %.1f, %s in %.2fs",
                    mid, as_of.strftime("%H:%M:%S"), live.observed, live.remaining, live.hot,
                    "" if ev is None else ", re-tuned for {} {} {} ({})".format(
                        ev["labels"]["event"], ev["labels"]["who"], ev["labels"]["clock"], ev["labels"]["state"]),
                    dec.lift if dec is not None else 0.0, dec.status if dec is not None else "no book",
                    time.time() - started)
        return live

    # ============================================================ triggers
    def check_triggers(self, as_of=None) -> List[Tuple[int, str]]:
        """Cheap scan of the whole card for events, price jumps and big bets since the last look."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        snap = self.source.fetch(as_of)
        fired = []
        ev = self.builder._canon("events", snap.events)
        odds = self.builder._canon("odds", snap.odds)
        inv = self.builder._canon("investments", snap.investments)
        for mid, live in list(self.matches.items()):
            sig = self._event_signature(ev, mid)
            if sig and sig != live.last_events:
                kind, what = self._newest_incident(ev, mid)
                fired.append((mid, what, kind))
                live.last_events = sig                      # one trigger per change, not one per scan
            if live.last_main_odds and not odds.empty:
                o = odds[odds["match_id"] == mid].sort_values("effective_datetime").groupby(
                    ["pool_id", "line_id", "combination_id"]).last()["odds"]
                for k, v0 in live.last_main_odds.items():
                    v1 = o.get(k)
                    if v1 is not None and v0 > 0 and abs(v1 / v0 - 1.0) > lv.trigger_odds_move:
                        fired.append((mid, "main-line price moved {:+.0%}".format(v1 / v0 - 1.0), "price"))
                        break
            since = as_of.floor("min") - pd.Timedelta(minutes=1)
            if live.forecast is not None and not inv.empty and live.last_big_minute != since:
                minute = inv[(inv["match_id"] == mid) & (inv["start_sell_time"] >= since)]
                per_min = float(live.forecast["forecast"].sum()) / self.settings.panel.bucket_minutes
                if per_min > 0 and float(minute["turnover"].sum()) > lv.trigger_big_bet_multiple * per_min:
                    live.last_big_minute = since
                    fired.append((mid, "big money: {:.0f} in a minute vs {:.0f} expected".format(
                        float(minute["turnover"].sum()), per_min), "money"))
        for mid, reason, key in fired:
            self.trigger(mid, reason, priority=2.0, focus=key)
        return [(mid, reason) for mid, reason, _ in fired]

    # ============================================================ events
    def _event_kinds(self) -> List[str]:
        return [k for k in PRIORITY if k in self.settings.live.trigger_events]

    def _event_signature(self, events: Optional[pd.DataFrame], mid: int) -> tuple:
        """The match's incident counts by code (events and their cancellations), from its main provider:
        any change - a goal, a corner, a VAR cancellation - is a new state of the match."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return ()
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds)]
        if inc.empty:
            return ()
        return tuple(int(((inc["kind"] == k) & (inc["sign"] == s)).sum()) for k in kinds for s in (1.0, -1.0))

    def _newest_incident(self, events: pd.DataFrame, mid: int) -> Tuple[str, str]:
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(self._event_kinds())]
        if inc.empty:
            return "goal", "event"
        last = inc.iloc[-1]
        name = {"goal": "goal", "red": "red card", "corner": "corner"}[last["kind"]]
        return str(last["kind"]), name if last["sign"] > 0 else name + " cancelled"

    def _event_since(self, events: Optional[pd.DataFrame], mid: int, current, as_of) -> bool:
        """Any goal, red card or corner (or a cancellation) of the match's main provider in [current, as_of]."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return False
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds) & (inc["t"] >= pd.Timestamp(current)) & (inc["t"] <= pd.Timestamp(as_of))]
        return not inc.empty

    def _event_in_bucket(self, events: Optional[pd.DataFrame], match: pd.DataFrame, mid: int, current,
                         as_of) -> Optional[dict]:
        """The goal / red card / corner since the bucket started (the rarest kind there is, net of
        cancellations), with the labels the event shift is kept by; None without one."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return None
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds) & (inc["t"] >= pd.Timestamp(current)) & (inc["t"] <= pd.Timestamp(as_of))]
        if inc.empty:
            return None
        net = inc.groupby("kind")["sign"].sum()
        kind = next((k for k in PRIORITY if net.get(k, 0.0) > 0), None)
        if kind is None:
            return None
        last = inc[(inc["kind"] == kind) & (inc["sign"] > 0)].iloc[-1]
        m = match[pd.to_numeric(match["match_id"], errors="coerce") == mid].sort_values("bucket").reset_index(drop=True)
        if m.empty:
            return None
        sup_ko = _kickoff_value(m, "sup") if "sup" in m.columns else np.full(len(m), np.nan)
        at = m.index[pd.to_datetime(m["bucket"]) <= pd.Timestamp(current)]
        i = int(at[-1]) if len(at) else len(m) - 1
        row = m.iloc[i]
        sgn = float(np.nan_to_num(pd.to_numeric(row.get("fav_sign", 0.0), errors="coerce")))
        goals = inc[(inc["kind"] == "goal")]
        hg = float(np.nan_to_num(pd.to_numeric(row.get("home_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 1, "sign"].sum())
        ag = float(np.nan_to_num(pd.to_numeric(row.get("away_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 2, "sign"].sum())
        minute = float(np.nan_to_num(pd.to_numeric(row.get("minute", 0.0), errors="coerce"))) + \
            (pd.Timestamp(last["t"]) - pd.Timestamp(current)).total_seconds() / 60.0
        labels = {"event": kind, "clock": clock_label([minute])[0],
                  "who": who_label([sgn], [last["side"] == 1], [last["side"] == 2])[0],
                  "strength": strength_label([sgn], [sup_ko[i]])[0], "state": state_label([sgn], [hg], [ag])[0]}
        return {"kind": kind, "time": pd.Timestamp(last["t"]), "side": last["side"], "labels": labels}

    # ================================================================ loop
    def _sweep_step(self, as_of=None) -> Optional[dict]:
        as_of = pd.Timestamp(as_of or self.clock())
        bucket = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        if not self.last_sweep or self.last_sweep.get("bucket") != str(bucket):
            return self.run_sweep(as_of)
        return None

    def _focus_step(self, as_of=None) -> List[int]:
        """Refresh what is due one match at a time, choosing again after each: a match the desk opens while
        others are refreshing waits for one refresh, not for all of them."""
        done: List[int] = []
        while len(done) < self.settings.live.max_focus_matches:
            at = pd.Timestamp(as_of or self.clock())
            mid = self._next_due(at, done)
            if mid is None:
                break
            done.append(mid)
            try:
                # the board is read now, after the choice: a request that came in meanwhile is covered
                self.run_focus(mid, as_of)
            except Exception as exc:                                   # noqa: BLE001
                logger.exception("focus refresh of match %s failed: %s", mid, exc)
        return done

    def _next_due(self, as_of: pd.Timestamp, done: List[int]) -> Optional[int]:
        """The desk's requests and triggers first, first come first served within a priority (a request a
        refresh has since covered is dropped), then the focused match whose last refresh or failed try is
        the oldest past the interval."""
        with self._lock:
            while self._queue:
                _, pushed, mid, _ = heapq.heappop(self._queue)
                live = self.matches.get(mid)
                if live is not None and live.refresh_started is not None and live.refresh_started >= pushed:
                    continue
                return mid
            pick, oldest = None, None
            for mid in self.focused():
                if mid in done:
                    continue
                live = self.matches.get(mid)
                last = live.refreshed_at if live else None
                if live is not None and live.failed_at is not None and (last is None or live.failed_at > last):
                    last = live.failed_at
                if last is None:
                    return mid
                age = (as_of - last).total_seconds()
                if age >= self.settings.live.focus_interval_seconds and (oldest is None or age > oldest):
                    pick, oldest = mid, age
            return pick

    def step(self, as_of=None) -> dict:
        """One scheduler tick on one thread: sweep at a new bucket, then the focus refreshes that are due."""
        as_of = pd.Timestamp(as_of or self.clock())
        return {"sweep": self._sweep_step(as_of), "focus": self._focus_step(as_of)}

    def start(self, poll_seconds: float = 1.0) -> None:
        """The sweep (and the trigger scan) on one thread, focus refreshes on another, so a sweep that takes
        minutes on a full card never holds up the match a trader has just opened."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def sweep_loop():
            logger.info("live engine started (source %s)", type(self.source).__name__)
            last_scan = 0.0
            while not self._stop.is_set():
                try:
                    if time.time() - last_scan > self.settings.live.focus_interval_seconds:
                        self.check_triggers()
                        last_scan = time.time()
                    self._sweep_step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live sweep step failed: %s", exc)
                self._stop.wait(poll_seconds)
            logger.info("live engine stopped")

        def focus_loop():
            while not self._stop.is_set():
                try:
                    self._focus_step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live focus step failed: %s", exc)
                self._wake.wait(poll_seconds)
                self._wake.clear()

        self._thread = threading.Thread(target=sweep_loop, name="algoe-live", daemon=True)
        self._focus_thread = threading.Thread(target=focus_loop, name="algoe-focus", daemon=True)
        self._thread.start()
        self._focus_thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        for t in (self._thread, self._focus_thread):
            if t:
                t.join(timeout=10)

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ================================================================ read
    def board(self) -> dict:
        """The last sweep's card, each match as that sweep priced it (the cockpit carries the newer focus
        reads), with whether a refresh is asked for, failed or triggered. A match a desk opened that no
        sweep has priced yet shows its own read."""
        focused = self.focused()
        with self._lock:
            rows = []
            for m in self.matches.values():
                if m.match_id in self.card and m.board_row is not None:
                    r = dict(m.board_row)
                elif m.board_row is None and m.match_id in focused:
                    r = m.summary()
                else:
                    continue
                r.update(refreshing=m.refreshing, error=m.error, triggers=list(m.triggers))
                rows.append(r)
        rows.sort(key=lambda r: -r["turnover"])
        return {"last_sweep": self.last_sweep, "focused": focused, "matches": rows}

    def price_at(self, match_id: int, theta: Dict[str, float]) -> Optional[dict]:
        """What-if: the match's last book at another theta (the dimensions not given stay at HKJC's), priced,
        its demand re-run and its E[GM] scored the way the optimiser scores a candidate."""
        with self._lock:
            live = self.matches.get(int(match_id))
            bk = live.book if live is not None else None
        if bk is None:
            return None
        th = repair_theta({**bk.theta_now, **{k: float(v) for k, v in (theta or {}).items()}})
        odds, p = self.optimizer.prices(bk, th)
        odds = np.where(np.isfinite(odds), odds, bk.odds_now)
        T = self.optimizer.demand_at(bk, odds)
        return {"theta": th, "keys": bk.keys[KEY].reset_index(drop=True), "odds": odds, "model_prob": p,
                "demand": T, "gm": self.optimizer.expected_gm(bk, odds, T), "turnover": float(np.nansum(T)),
                "gm_board": self.optimizer.expected_gm(bk, bk.odds_now), "turnover_board": bk.total_demand,
                "belief": bk.p_true, "odds_now": bk.odds_now, "legs": bk.n}

    def curves(self, match_id: int, points: int = 13) -> Optional[dict]:
        """E[GM] along each dimension across the trust band around HKJC's theta, the others held at theta*."""
        with self._lock:
            live = self.matches.get(int(match_id))
            bk, dec = (live.book, live.decision) if live is not None else (None, None)
        if bk is None:
            return None
        star = dict(dec.theta_star) if dec is not None else repair_theta(bk.theta_now)
        band = self.settings.optimizer.theta_band
        out = {}
        for dim, now in bk.theta_now.items():
            if dim not in band or now is None or not np.isfinite(now):
                continue
            xs = np.linspace(now - band[dim], now + band[dim], int(points))
            if dim.endswith("_tg"):
                xs = np.maximum(xs, 0.0)
            gm = []
            for x in xs:
                odds, _ = self.optimizer.prices(bk, repair_theta({**star, dim: float(x)}))
                odds = np.where(np.isfinite(odds), odds, bk.odds_now)
                gm.append(self.optimizer.expected_gm(bk, odds, self.optimizer.demand_at(bk, odds)))
            out[dim] = {"x": [float(x) for x in xs], "gm": gm, "now": float(now), "star": float(star.get(dim, now))}
        return {"match_id": int(match_id), "turnover": bk.total_demand, "curves": out}

    def match_view(self, match_id: int) -> dict:
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None:
                return {"match_id": int(match_id), "status": "unknown"}
            view = live.view.to_dict("records") if live.view is not None else []
            rows = live.rows.to_dict("records") if live.rows is not None else []
            extras = {k: (v.to_dict("records") if isinstance(v, pd.DataFrame) else v) for k, v in live.extras.items()}
            return {**live.summary(), "header": dict(live.header), "rows": rows, "selections": view,
                    "per_pool": live.decision.per_pool if live.decision else [], "extras": extras,
                    "theta_hkjc": dict(live.book.theta_now) if live.book is not None else {},
                    "requested_at": live.requested_at, "models": self.models()}


# ---------------------------------------------------------------- helpers
def _default_source(settings):
    if settings.live.source == "replay":
        from ..data.replay import ReplaySource
        return ReplaySource(settings)
    from src.hkjc.source import get_source
    return get_source(settings.live.source)


def _second_source(source):
    """The focus thread's source: a SQL source on its own connections (a pyodbc connection belongs to one
    thread); replay, capture and simulated sources only read, and are shared."""
    clone = getattr(source, "clone", None)
    return clone() if callable(clone) else source


def _only(snap, mid: int):
    """Keep one match's rows; the simulator ignores match_ids, SQL and replay honour it."""
    for name in ("active_pools", "match_info", "params", "params_history", "events", "odds", "market", "investments"):
        frame = getattr(snap, name, None)
        if frame is not None and not frame.empty and "match_id" in frame.columns:
            setattr(snap, name, frame[pd.to_numeric(frame["match_id"], errors="coerce") == mid])
        elif frame is not None and not frame.empty and name == "match_info":
            col = next((c for c in ("MatchId", "match_id") if c in frame.columns), None)
            if col:
                setattr(snap, name, frame[pd.to_numeric(frame[col], errors="coerce") == mid])
    return snap


def _observed(investments: pd.DataFrame, sel: pd.DataFrame, bucket, as_of) -> np.ndarray:
    """Money each selection has taken since the bucket started."""
    if investments is None or investments.empty:
        return np.zeros(len(sel))
    inv = LivePanelBuilder._canon("investments", investments)
    inv = inv[(inv["start_sell_time"] >= bucket) & (inv["start_sell_time"] <= as_of)]
    if inv.empty:
        return np.zeros(len(sel))
    for c in KEY:
        inv[c] = pd.to_numeric(inv[c], errors="coerce").fillna(-1).astype("int64")
    got = inv.groupby(KEY)["turnover"].sum()
    idx = pd.MultiIndex.from_frame(sel[KEY].astype("int64"))
    return got.reindex(idx).fillna(0.0).to_numpy(dtype="float64")


def _main_odds(book) -> Dict[tuple, float]:
    if book is None or book.keys is None:
        return {}
    out = {}
    for i in np.flatnonzero(book.is_main):
        k = book.keys.iloc[i]
        out[(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"]))] = float(book.odds_now[i])
    return out


def _view(book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    v = book.keys.copy() if book.keys is not None else pd.DataFrame(index=range(book.n))
    v["line"] = book.rows.line
    v["side"] = book.rows.side
    v["odds_now"] = book.odds_now
    v["belief"] = book.p_true
    v["model_prob"] = book.p_now if book.p_now is not None else np.nan
    v["demand"] = book.demand
    if dec is not None and dec.odds_star is not None:
        v["odds_star"] = dec.odds_star
        v["odds_star_ladder"] = publish_odds(dec.odds_star)
        v["demand_star"] = dec.demand_star
        # stage 2: our weighting on top of theta*, and the price in the desk's terms
        # (sell = fair(theta*) / (1 + margin) x desk_weighting)
        v["weighting"] = dec.weights if dec.weights is not None else 1.0
        v["desk_weighting"] = desk_weightings(book, dec)
    return v


def _weights_by_key(book, dec: Optional[MatchDecision]) -> Dict[tuple, float]:
    if dec is None or dec.weights is None or book.keys is None:
        return {}
    k = book.keys
    return {(int(a), int(b), int(c)): float(w) for a, b, c, w in zip(k["pool_id"], k["line_id"],
                                                                     k["combination_id"], dec.weights)}


def _stamp(value) -> Optional[str]:
    if value is None:
        return None
    t = pd.Timestamp(value)
    return None if pd.isna(t) else str(t)


def _text(value) -> Optional[str]:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return None
    out = str(value).strip()
    return out or None


def _number(value) -> Optional[float]:
    v = pd.to_numeric(value, errors="coerce")
    return float(v) if v is not None and np.isfinite(v) else None


def _rows(sel: pd.DataFrame, forecast, observed, remaining, next_bucket, belief) -> pd.DataFrame:
    """Every selection of the bucket with its prices and its money: what the desk's book draws."""
    def col(name, default=np.nan):
        return sel[name].to_numpy() if name in sel.columns else np.full(len(sel), default)

    out = pd.DataFrame({c: col(c) for c in KEY + ["match_id"]})
    for c in ("pool_name", "line_label", "combination_string", "market", "segment", "theta_domain", "family", "side"):
        out[c] = pd.Series(col(c, None), dtype="object").where(pd.notna(col(c, None)), None)
    for c in ("line", "odds", "true_odds", "p_hkjc_true", "p_market", "mkt_odds", "odds_age_min"):
        out[c] = pd.to_numeric(pd.Series(col(c)), errors="coerce").to_numpy(dtype="float64")
    out["belief"] = np.asarray(belief, dtype="float64")
    out["forecast"] = np.asarray(forecast, dtype="float64")
    out["observed"] = np.asarray(observed, dtype="float64")
    out["remaining"] = np.asarray(remaining, dtype="float64")
    out["next_bucket"] = np.asarray(next_bucket, dtype="float64")
    out["last_bucket"] = pd.to_numeric(pd.Series(col("tv1", 0.0)), errors="coerce").fillna(0.0).to_numpy()
    out["tickets_last_bucket"] = pd.to_numeric(pd.Series(col("tk1", 0.0)), errors="coerce").fillna(0.0).to_numpy()
    out["is_main"] = pd.to_numeric(pd.Series(col("rank_0", 0.0)), errors="coerce").fillna(0.0).to_numpy() > 0
    out["forecastable"] = pd.Series(col("forecastable", True)).fillna(False).astype(bool).to_numpy()
    for c in KEY + ["match_id"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").astype("int64")
    return out


def _with_book(rows: pd.DataFrame, book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    """The book's prices on the rows it holds: the model's probability at HKJC's theta, theta*'s odds."""
    out = rows.copy()
    out["in_book"] = False
    for c in ("model_prob", "odds_star", "odds_star_ladder", "demand", "demand_star", "weighting", "desk_weighting"):
        out[c] = np.nan
    if book is None or book.keys is None or out.empty:
        return out
    v = _view(book, dec)
    keep = [c for c in ("model_prob", "odds_star", "odds_star_ladder", "demand", "demand_star", "weighting",
                        "desk_weighting") if c in v.columns]
    v = v[KEY + keep].copy()
    for c in KEY:
        v[c] = pd.to_numeric(v[c], errors="coerce").astype("int64")
    v["in_book"] = True
    merged = out.drop(columns=["in_book"] + keep).merge(v, on=KEY, how="left")
    merged["in_book"] = merged["in_book"].fillna(False).astype(bool)
    return merged[list(out.columns)]


def _header(info: pd.DataFrame, match: pd.DataFrame, mid: int, bucket) -> dict:
    """Teams, league and kick-off from the match information; phase, clock and score from the bucket's row."""
    h: dict = {}
    if info is not None and not info.empty and "match_id" in info.columns:
        r = info[pd.to_numeric(info["match_id"], errors="coerce") == mid]
        if len(r):
            r = r.iloc[0]
            h.update(home=_text(r.get("home_name")), away=_text(r.get("away_name")),
                     league=_text(r.get("league_name")) or _text(r.get("league_code")),
                     league_code=_text(r.get("league_code")), kickoff=_stamp(r.get("ko_time")))
    if match is not None and not match.empty:
        m = match[pd.to_numeric(match["match_id"], errors="coerce") == mid]
        at = m[pd.to_datetime(m["bucket"]) == pd.Timestamp(bucket)]
        m = at if len(at) else m.sort_values("bucket")
        if len(m):
            r = m.iloc[-1]

            def count(name):
                return int(np.nan_to_num(_number(r.get(name)) or 0.0))
            for side in ("home", "away"):
                if not h.get(side):
                    h[side] = _text(r.get(side + "_name"))
            h.update(phase=_text(r.get("phase")) or "prematch", minute=_number(r.get("minute")),
                     in_play=bool((_number(r.get("inplay")) or 0.0) > 0),
                     score=[count("home_goals"), count("away_goals")],
                     corners=[count("home_corners"), count("away_corners")],
                     reds=[count("home_reds"), count("away_reds")],
                     splits={"goal": _number(r.get("goal_split_fh")), "corner": _number(r.get("corner_split_fh"))})
    return h


def _params_at(panel: pd.DataFrame, bucket) -> Dict[int, pd.Timestamp]:
    """Per match, the EventTime of the TG/SUP row the bucket's rows carry."""
    if panel is None or panel.empty or "event_time" not in panel.columns:
        return {}
    rows = panel[pd.to_datetime(panel["bucket"]) == pd.Timestamp(bucket)]
    t = pd.to_datetime(rows["event_time"], errors="coerce")
    got = t.groupby(pd.to_numeric(rows["match_id"], errors="coerce")).max().dropna()
    return {int(k): pd.Timestamp(v) for k, v in got.items()}


def _extras(builder: LivePanelBuilder, snap, mid: int, as_of, history: int = 40) -> dict:
    """What a trader reads beside the book, from the focus refresh's own read: the external quotes, the
    incidents, HKJC's recent price track and every pool's latest price (the pools the panel leaves out too)."""
    as_of = pd.Timestamp(as_of)
    out: dict = {}
    odds = builder._canon("odds", snap.odds)
    if not odds.empty:
        odds = odds[(pd.to_numeric(odds["match_id"], errors="coerce") == mid)
                    & (pd.to_datetime(odds["effective_datetime"]) <= as_of)].sort_values("effective_datetime",
                                                                                      kind="mergesort")
        cols = [c for c in KEY + ["pool_name", "line_label", "combination_string", "odds", "true_odds",
                                  "effective_datetime"] if c in odds.columns]
        out["latest"] = odds.groupby(KEY, as_index=False).last()[cols]
        out["history"] = odds.groupby(KEY).tail(history)[[c for c in KEY + ["effective_datetime", "odds", "true_odds"]
                                                          if c in odds.columns]].reset_index(drop=True)
    market = builder._canon("market", snap.market)
    if not market.empty:
        market = market[(pd.to_numeric(market["match_id"], errors="coerce") == mid)
                        & (pd.to_datetime(market["effective_datetime"]) <= as_of)]
        if not market.empty:
            by = KEY + [c for c in ("bookmaker",) if c in market.columns]
            q = market.sort_values("effective_datetime", kind="mergesort").groupby(by, as_index=False).last()
            q["age_sec"] = (as_of - pd.to_datetime(q["effective_datetime"])).dt.total_seconds().round()
            out["quotes"] = q[[c for c in KEY + ["bookmaker", "bookmaker_str", "odds", "age_sec"] if c in q.columns]]
    events = builder._canon("events", snap.events)
    if not events.empty:
        e = events[(pd.to_numeric(events["match_id"], errors="coerce") == mid)
                   & (pd.to_datetime(events["incident_datetime"]) <= as_of)]
        out["incidents"] = e.sort_values("incident_datetime", ascending=False, kind="mergesort").head(60)[
            [c for c in ("incident_datetime", "incident_type", "home_or_away", "provider_id") if c in e.columns]]
    return out
