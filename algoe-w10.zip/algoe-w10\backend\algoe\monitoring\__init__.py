"""Forecast log, realised join, rolling health, drift and alerts."""
