"""
In-play cycle tests - every in-play match in one pass, the same answer a focus refresh gives, what is
published from the sweep, the cycle and a focus refresh, and 40 in-play matches inside the budget

    python tests/test_inplay.py                plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_inplay.py

On the frozen simulator of test_algoe.py, without trained models (forecast = last bucket, belief = HKJC).

Change Log:
-----------
2026-10-29      Initialize
"""

import json
import sys
import tempfile
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd  # noqa: E402

from test_algoe import _FrozenSim  # noqa: E402

T0 = pd.Timestamp("2026-10-26 15:47:00")


def _engine(tmp, src, publish="off", workers=1):
    from algoe.realtime.live_engine import LiveEngine
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
    s.set("optimizer.workers={}".format(workers))
    s.publish.mode = publish
    return LiveEngine(s, source=src)


def _in_play(eng):
    return sorted(m for m, live in eng.matches.items() if live.header.get("in_play") and live.decision is not None)


def test_the_cycle_covers_every_in_play_match_like_a_focus_refresh():
    src = _FrozenSim(T0, n_matches=8)
    at = T0 + pd.Timedelta(seconds=40)
    with tempfile.TemporaryDirectory() as a_dir, tempfile.TemporaryDirectory() as b_dir:
        a, b = _engine(a_dir, src), _engine(b_dir, src)
        a.run_sweep(T0)
        b.run_sweep(T0)
        playing = _in_play(a)
        assert len(playing) >= 3, playing
        got = a.run_inplay_cycle(at)
        assert got["matches"] >= len(playing) and got["solved"] == got["books"] and not got["behind"]
        key = ["pool_id", "line_id", "combination_id"]
        for mid in playing:
            b.run_focus(mid, at)
            ba, bb = a.matches[mid].book, b.matches[mid].book
            fa = ba.keys[key].assign(d=ba.demand, p=ba.p_true, o=ba.odds_now).sort_values(key).reset_index(drop=True)
            fb = bb.keys[key].assign(d=bb.demand, p=bb.p_true, o=bb.odds_now).sort_values(key).reset_index(drop=True)
            assert fa.equals(fb) and ba.theta_now == bb.theta_now and ba.theta_prev == bb.theta_prev, mid
            assert a.matches[mid].board_at == b.matches[mid].board_at == at
            # the same book; the rows come in another order, which can move SLSQP's path a little
            da, db = a.matches[mid].decision, b.matches[mid].decision
            assert max(abs(da.theta_star[k] - db.theta_star[k]) for k in da.theta_star) < 0.01, mid
            assert abs(da.egm_star - db.egm_star) <= 0.005 * abs(db.egm_star) + 1e-6, mid
        pre = [m for m, live in a.matches.items() if not live.header.get("in_play")]
        assert all(a.matches[m].refreshed_at == T0 for m in pre)          # the cycle leaves pre-match alone


def test_publishing_from_the_sweep_the_cycle_and_a_focus_refresh():
    from src.hkjc.kafka_messages import parse_prices_message
    src = _FrozenSim(T0, n_matches=8)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        assert eng.publishing and type(eng.publisher.transport).__name__ == "FileTransport"
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=5)
        eng.run_sweep(T0)
        out = Path(tmp) / "publish" / "out"
        sent = [json.loads(line) for f in out.glob("*.jsonl") for line in f.read_text(encoding="utf-8").splitlines()]
        assert sent, "the sweep published nothing"
        assert all(m["TgsupParameters"]["DrawFactor"] == 0.0 for m in sent)           # the simulator's 1.0
        swept = {m["EventId"] for m in sent}
        pre = next(m for m, live in eng.matches.items() if not live.header.get("in_play") and live.decision)
        n0 = len(sent)
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=40)
        eng.run_focus(pre, T0 + pd.Timedelta(seconds=35))
        after = sum(len(f.read_text(encoding="utf-8").splitlines()) for f in out.glob("*.jsonl"))
        assert after == n0, "a pre-match match opened on the desk was published"
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=50)
        cyc = eng.run_inplay_cycle(T0 + pd.Timedelta(seconds=45))
        assert cyc["published"] >= 1
        lines = [json.loads(line) for f in out.glob("*.jsonl") for line in f.read_text(encoding="utf-8").splitlines()]
        inplay_ids = {m["EventId"] for m in lines[n0:]}
        assert inplay_ids and inplay_ids <= set(_in_play(eng))
        replies = eng.publisher.poll()
        assert replies and all(info["ours"] for _, info in replies)
        for reply, info in replies:
            eng.on_engine_prices(reply, info)
        mid = replies[-1][0].event_id
        assert eng.matches[mid].engine is not None and len(eng.matches[mid].engine["rows"]) > 0
        assert swept and parse_prices_message((Path(tmp) / "publish" / "in").glob("*.jsonl").__next__()
                                              .read_text(encoding="utf-8").splitlines()[0], eng.publisher.mapping)


def test_a_refused_production_mode_runs_the_desk_as_off():
    from algoe.pricing.pricer import DIMS
    src = _FrozenSim(T0, n_matches=4)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="live")                   # no ALGOE_PUBLISH=live, no confirmation file
        assert eng.publisher is None and "ALGOE_PUBLISH" in eng.publish_refused
        assert tuple(eng.optimizer.allowed) == tuple(DIMS) and eng.inplay_source is None
        assert eng.publish_status()["mode"] == "off" and not eng.publishing


def test_publishing_while_the_desk_reads_never_deadlocks():
    """A desk read holds the engine and asks the publisher; a dry-run send asks the engine (the mock reads the
    match). Sending under the publisher's lock deadlocked the two (found on the dry-run server, 2026-10-29)."""
    import threading
    src = _FrozenSim(T0, n_matches=8)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run")
        eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=5)
        eng.publisher.p.min_interval_seconds = 0.001
        eng.run_sweep(T0)
        mid = next(m for m, live in eng.matches.items() if live.decision is not None and live.book is not None)
        stop, errors = threading.Event(), []

        def desk():
            try:
                while not stop.is_set():
                    eng.match_view(mid)
                    eng.board()
            except Exception as exc:                                   # noqa: BLE001
                errors.append(exc)

        def publish():
            try:
                for i in range(40):
                    eng.publisher.clock = lambda i=i: T0 + pd.Timedelta(seconds=6 + i)
                    eng._publish(mid, "sweep")
            except Exception as exc:                                   # noqa: BLE001
                errors.append(exc)
        a, b = threading.Thread(target=desk, daemon=True), threading.Thread(target=publish, daemon=True)
        a.start()
        b.start()
        b.join(timeout=60)
        stop.set()
        a.join(timeout=10)
        assert not b.is_alive() and not a.is_alive(), "publishing and the desk deadlocked"
        assert not errors, errors


def test_forty_in_play_matches_inside_the_budget():
    """The whole loop on 40 in-play matches: refresh, solve, round, message, send and the mock's reply."""
    src = _FrozenSim(T0, n_matches=54)
    with tempfile.TemporaryDirectory() as tmp:
        eng = _engine(tmp, src, publish="dry_run", workers=0)
        try:
            eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=2)
            eng.run_sweep(T0)
            playing = _in_play(eng)
            eng._warm_pool()
            eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=21)
            eng.run_inplay_cycle(T0 + pd.Timedelta(seconds=20))
            eng.publisher.clock = lambda: T0 + pd.Timedelta(seconds=36)
            began = time.time()
            got = eng.run_inplay_cycle(T0 + pd.Timedelta(seconds=35))
            took = time.time() - began
        finally:
            eng.stop()
    print("      {} in play, {} books, {} solved, {} published, {:.1f}s: {}".format(
        len(playing), got["books"], got["solved"], got["published"], took, got["seconds"]))
    assert len(playing) >= 40, len(playing)
    assert got["solved"] == got["books"] and not got["behind"], got
    assert got["published"] >= 0.8 * got["books"], got
    assert took < 10.0, got["seconds"]


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
