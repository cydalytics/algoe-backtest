@echo off
REM Step 4: sample-solve TG/SUP on already-cached days. Slow. Does not rebuild panels.
setlocal
cd /d "%~dp0"
set "DATA=%~1"
if not defined DATA set "DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data"
echo Solving TG/SUP on cached days. Turnover and belief scores stay as they are.
python -m backtest.run run --data-dir "%DATA%" --out-dir "out" ^
    --start 2026-07-01 --end 2026-09-15 --optimize
echo.
echo Open out\report.html ??? section 4 is the solver.
pause
