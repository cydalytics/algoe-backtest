"""
Algo E unit tests - fast, no Raw_Data, no SQL, no network

    python tests/test_algoe.py              plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_algoe.py    the same checks under pytest
    set ALGOE_SLOW=1                        also run the whole selftest (about two minutes)

Each test guards one behaviour the desk depends on:

    pricer            our score-grid pricer == legacy poisson_betting; quarter lines settle half
    estimators        the GLM recovers known Poisson rates; every bundle survives save / load
    unknowns          an unseen pool key encodes at its parent; an unseen pool code is placed by rule
    pools / splits    panel pools by market rule (a new line market joins by itself); a date split
                      keeps train < val < test with no day in two roles
    validation        sentinel odds become null, negative money clips, missing names fill, duplicates count;
                      a pool closing exactly at a bucket start is off the board for that bucket
    nowcast           the rest-of-bucket forecast moves with the money already in
    settings          a typo in a key or an impossible value is refused, not silently ignored
    model store       a tampered bundle, or one built on other features, is never served
    monitor           PSI is ~0 on the training distribution even for a zero-inflated feature
    leakage           a goal after the bucket start does not change that bucket's goal pulse
    cli               every command parses

Change Log:
-----------
2026-10-01      Initialize
"""

import os
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


# ------------------------------------------------------------------- pricer
def test_pricer_matches_legacy():
    from src.backtest.parquet import poisson_betting as pb
    from algoe.pricing.pricer import marginals, score_grid, two_way
    for tg, sup in ((1.4, -0.9), (2.6, 0.0), (3.4, 0.7)):
        m = marginals(score_grid(tg, sup, 10))
        for line in (1.5, 2.25, 2.5, 2.75, 3.0):
            ours = float(two_way(m.total_values, m.total_probs, line)[0][0])
            assert abs(ours - 1.0 / pb.calculate_over_under_odds(tg, sup, line)["Over"]) < 1e-9
        for h in (-1.25, -0.5, 0.0, 0.25, 0.75):
            ours = float(two_way(m.diff_values, m.diff_probs, -h)[0][0])
            assert abs(ours - 1.0 / pb.calculate_asian_handicap_odds(tg, sup, h)["Home"]) < 1e-9


def test_quarter_lines_settle_half():
    from algoe.pricing.pricer import settle_matrix, two_way
    r = settle_matrix(np.array([2.0, 3.0]), np.array([2.25, 2.75]))
    assert r[0].tolist() == [-0.5, 1.0]       # over 2.25: two goals lose half, three win
    assert r[1].tolist() == [-1.0, 0.5]       # over 2.75: two lose, three win half
    p1, p2, at_risk = two_way(np.array([2.0, 3.0]), np.array([0.0, 1.0]), 2.25)
    assert abs(p1[0] - 1.0) < 1e-12 and abs(p2[0]) < 1e-12


# --------------------------------------------------------------- estimators
def _poisson_data(n=20000, seed=3):
    rng = np.random.default_rng(seed)
    x = rng.normal(size=n)
    y = rng.poisson(np.exp(0.5 + 0.8 * x))
    return pd.DataFrame({"x": x}), y.astype("float64")


def test_glm_recovers_poisson_rates():
    from algoe.models.estimators import GLMEstimator
    X, y = _poisson_data()
    m = GLMEstimator("poisson", ridge=1e-8).fit(X, y)
    grid = pd.DataFrame({"x": [-1.0, 0.0, 1.0]})
    truth = np.exp(0.5 + 0.8 * grid["x"].to_numpy())
    assert np.all(np.abs(m.predict(grid) / truth - 1.0) < 0.05)


def test_estimator_state_round_trip():
    from algoe.models.estimators import GAMEstimator, GLMEstimator, load_estimator
    X, y = _poisson_data(6000)
    grid = pd.DataFrame({"x": np.linspace(-2, 2, 9)})
    for est in (GLMEstimator("poisson", ridge=1e-6), GAMEstimator("poisson", n_knots=6, lambdas=(1.0,))):
        est.fit(X, y)
        again = load_estimator(est.to_state())
        assert np.allclose(est.predict(grid), again.predict(grid))


# ----------------------------------------------------------------- unknowns
def test_encoder_unknown_falls_to_parent():
    from algoe.features.encoders import LevelEncoder
    train = pd.DataFrame({"pool_key": ["A|pre"] * 50 + ["B|pre"] * 50 + ["C|live"] * 50,
                          "family_phase": ["goal|pre"] * 100 + ["goal|live"] * 50,
                          "t": [1.0] * 50 + [3.0] * 50 + [10.0] * 50})
    enc = LevelEncoder("pool_key", ("family_phase",), prior=10.0).fit(train, "t")
    test = pd.DataFrame({"pool_key": ["A|pre", "Z|pre", "Z|nowhere"],
                         "family_phase": ["goal|pre", "goal|pre", "corner|nowhere"]})
    level, known = enc.transform(test)
    parent = enc.tables["family_phase"]["goal|pre"] - enc.global_mean
    assert known.tolist() == [1.0, 0.0, 0.0]
    assert abs(level[1] - parent) < 1e-12          # unseen key: its family level
    assert abs(level[2]) < 1e-12                   # unseen everything: the global level


def test_taxonomy_places_unknown_codes():
    from algoe.core.taxonomy import PoolTaxonomy
    tax = PoolTaxonomy()
    known = tax.resolve("HILO")
    new = tax.resolve("NHILO")
    assert "HILO" not in tax.inferred_codes()
    assert "NHILO" in tax.inferred_codes()
    assert new.family == known.family and new.priceable
    odd = tax.resolve("ZZ9")                        # nonsense must not raise
    assert isinstance(odd.priceable, bool)


def test_pool_rules_select_by_market():
    from algoe.core.taxonomy import PoolTaxonomy, resolve_pools
    tax = PoolTaxonomy()
    codes = ["HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "CRS", "TTG", "AGS", "NTS3", "NHILO"]
    lines = resolve_pools(["@line_markets", "@three_way"], codes, tax)
    assert set(lines) == {"HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "NHILO"}   # a new total joins by itself
    assert set(resolve_pools(["HILO", "CRS"], codes, tax)) == {"HILO", "CRS"}
    assert resolve_pools([], codes, tax) == sorted(codes)                           # [] = every pool
    try:
        resolve_pools(["@lines"], codes, tax)
        raise AssertionError("accepted an unknown rule")
    except ValueError:
        pass


def test_team_totals_are_line_markets():
    from algoe.core.taxonomy import PoolTaxonomy, resolve_pools
    tax = PoolTaxonomy()
    h, a, c, f = tax.resolve("HILOH"), tax.resolve("HILOA"), tax.resolve("CHLOA"), tax.resolve("FHLOH")
    assert (h.market, a.market, c.market, f.market) == ("home_total", "away_total", "away_total", "home_total")
    assert c.domain == "corner" and f.theta_domain == "goal_fh" and h.priceable
    assert tax.resolve("ZHILOA").market == "away_total"            # an unseen team total is placed by rule
    codes = ["HILO", "HILOH", "HILOA", "FCHLOH", "ETHILOH", "CRS", "MSPC3"]
    assert set(resolve_pools(["@line_markets"], codes, tax)) == {"HILO", "HILOH", "HILOA", "FCHLOH", "ETHILOH"}
    assert "ETHILOH" not in resolve_pools(["@theta_lines"], codes, tax)   # no extra-time theta to move
    assert tax.resolve("MSPC3").market == "other" and "MSPC3" not in tax.inferred_codes()   # numbered, known


def test_team_totals_price_one_teams_goals():
    from math import exp
    from algoe.pricing.pricer import BookPricer, BookRows, MatchState
    rows = BookRows(["goal", "goal"], ["home_total", "away_total"], [1.5, 0.5], ["H", "H"])
    p, _ = BookPricer().probabilities(rows, {"goal_tg": 2.8, "goal_sup": 0.6})
    assert abs(p[0] - (1 - exp(-1.7) * 2.7)) < 1e-6                # home goals ~ Poisson((TG + SUP) / 2)
    assert abs(p[1] - (1 - exp(-1.1))) < 1e-6                      # away goals ~ Poisson((TG - SUP) / 2)
    # in play at 1-0 with 1.0 goals left (SUP 0.2): home over 1.5 needs one more home goal
    st = MatchState(home_goals=1, phase="second_half", minute=60, ht_home_goals=1, ht_away_goals=0)
    p, _ = BookPricer().probabilities(rows, {"goal_tg": 1.0, "goal_sup": 0.2}, st)
    assert abs(p[0] - (1 - exp(-0.6))) < 1e-6 and abs(p[1] - (1 - exp(-0.4))) < 1e-6


def test_hk_holidays_for_any_year():
    from datetime import date
    from algoe.core.hk_holidays import hk_general_holidays, lunar_date, new_moon_jde, sun_apparent_longitude
    assert abs(new_moon_jde(-283) - 2443192.65118) < 1e-4                 # Meeus example 49.a
    assert abs(sun_apparent_longitude(2448908.5) - 199.906061) < 2e-4      # Meeus example 25.b
    h26 = set(hk_general_holidays(2026))
    for d in ("2026-02-17", "2026-04-03", "2026-04-04", "2026-04-06", "2026-04-07", "2026-05-25",
              "2026-06-19", "2026-09-26", "2026-10-19", "2026-12-26"):
        assert date.fromisoformat(d) in h26, d                             # the gazetted 2026 days
    assert not {date(2026, 5, 19), date(2026, 9, 25), date(2026, 10, 7)} & h26
    assert {date(2023, 1, 25), date(2023, 10, 2)} <= set(hk_general_holidays(2023))   # 4th day of LNY; Sunday rule
    assert date(2012, 10, 2) in hk_general_holidays(2012)    # day following Mid-Autumn on National Day
    assert len(hk_general_holidays(2125)) >= 17
    try:
        import holidays
        from holidays.calendars import _ChineseLunisolar
    except ImportError:
        return
    cal = _ChineseLunisolar()
    # new moons a few seconds (2057) or minutes (2089) from midnight, and a 2025 table entry the gazette
    # does not follow (the Birthday of the Buddha was Monday 5 May)
    skip = {(2025, "buddha"), (2057, "chung_yeung"), (2089, "mid_autumn")}
    for y in range(1950, 2100):
        for name, fn, (m, d) in (("lny", cal.lunar_new_year_date, (1, 1)), ("buddha", cal.buddha_birthday_date, (4, 8)),
                                 ("tuen_ng", cal.dragon_boat_date, (5, 5)), ("mid_autumn", cal.mid_autumn_date, (8, 15)),
                                 ("chung_yeung", cal.double_ninth_date, (9, 9))):
            if (y, name) not in skip:
                assert fn(y)[0] == lunar_date(y, m, d), (y, name)
    for y in range(2009, 2046):          # python-holidays dates Ching Ming by a 4-year rule, right until 2045
        ref = holidays.HK(years=y, categories=holidays.HK.supported_categories)
        cm = min(d for d, n in ref.items() if n.startswith("Ching Ming"))
        assert cm in hk_general_holidays(y), y


def _line_move_panel(money_scale: float = 1.0) -> pd.DataFrame:
    """One HILO pool in play: 2.5 (main) and 3.5 at 20:00 and 20:05; at 20:10 the market has moved to
    1.5 (main, a new line) and 2.5."""
    rows = []
    t0 = pd.Timestamp("2026-07-01 20:00")
    books = {0: [(1, "2.5", 1.9, 1.9), (2, "3.5", 3.0, 1.35)], 1: [(1, "2.5", 1.9, 1.9), (2, "3.5", 3.0, 1.35)],
             2: [(3, "1.5", 1.9, 1.9), (1, "2.5", 3.0, 1.35)]}
    money = {(1, 1, "H"): 1000.0, (1, 1, "L"): 800.0, (1, 2, "H"): 100.0, (1, 2, "L"): 100.0}
    for k, lines in books.items():
        for line_id, label, o_h, o_l in lines:
            for comb, side, o in ((1, "H", o_h), (2, "L", o_l)):
                rows.append({"bucket": t0 + pd.Timedelta(minutes=5 * k), "pool_id": 10, "line_id": line_id,
                             "combination_id": comb, "match_id": 1, "pool_name": "HILO", "line_label": label,
                             "combination_string": side, "odds": o, "priced_before": True, "forecastable": True,
                             "turnover": money.get((k, line_id, side), 0.0) * money_scale, "tickets": 10.0 * money_scale,
                             "is_inplay": True, "match_minute": 20.0 + 5 * k, "mins_to_ko": -20.0 - 5 * k,
                             "tg": 1.5, "sup": 0.2, "league_code": "ENG", "game_state": "FirstHalf"})
    return pd.DataFrame(rows)


def test_a_new_line_inherits_its_slots_money():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        sel = FeatureEngineer(s).prepare_day(_line_move_panel(), day="2026-07-01").sel
    at = sel[sel["bucket"] == pd.Timestamp("2026-07-01 20:10")].set_index(["line_id", "combination_id"])
    new_over, old_over = at.loc[(3, 1)], at.loc[(1, 1)]
    assert new_over["rank_0"] == 1 and new_over["line_new"] == 1 and old_over["line_new"] == 0
    # the new main line took over the slot of the old main line (offset 0, over): HK$1000 of HK$2000
    assert new_over["pos_tv1"] == 1000.0 and abs(new_over["s_share_pool_l1"] - 0.5) < 1e-9
    assert new_over["s_log_l1"] > 0                                  # not the zero a line-id lag would give
    # 2.5 is now one goal above the best line: its own history stays, its slot is where 3.5 was
    assert abs(old_over["s_share_pool_l1"] - 0.5) < 1e-9 and abs(old_over["pos_share_l1"] - 0.05) < 1e-9


def test_a_line_opened_during_the_last_bucket_keeps_its_own_money():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    panel = _line_move_panel()
    extra = []
    for k, priced, money in ((1, False, 300.0), (2, True, 0.0)):        # 4.5 opens during 20:05, takes HK$300
        for comb, side, o in ((1, "H", 6.0), (2, "L", 1.1)):
            row = panel.iloc[0].to_dict()
            row.update(bucket=pd.Timestamp("2026-07-01 20:00") + pd.Timedelta(minutes=5 * k), line_id=4,
                       combination_id=comb, line_label="4.5", combination_string=side, odds=o,
                       priced_before=priced, turnover=money if side == "H" else 0.0,
                       match_minute=20.0 + 5 * k, mins_to_ko=-20.0 - 5 * k)
            extra.append(row)
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        sel = FeatureEngineer(s).prepare_day(pd.concat([panel, pd.DataFrame(extra)], ignore_index=True),
                                             day="2026-07-01").sel
    at = sel[sel["bucket"] == pd.Timestamp("2026-07-01 20:10")].set_index(["line_id", "combination_id"])
    over = at.loc[(4, 1)]
    assert over["line_new"] == 1 and over["tv1"] == 300.0 and over["pos_tv1"] == 0.0
    # its own HK$300, not its empty slot (4.5 is three goals above the best line; nothing was there)
    assert over["s_any_l1"] == 1 and over["s_log_l1"] > 0


def test_references_are_trailing_medians_two_days_back():
    from algoe.data.panel import reference_values
    stats = {"2026-07-0{}".format(d): {"board_matches": float(d), "pools_per_match": 10.0, "lines_per_match": 3.0,
                                       "lines_per_pool": 2.0, "margin": {"goal_hdc|prematch": 0.06},
                                       "share": {"goal_hdc|prematch": 0.5} if d % 2 else {}} for d in range(1, 10)}
    r = reference_values(stats, "2026-07-09", window=4)                 # days 4..7: never yesterday or today
    assert r["days"] == 4 and r["board_matches"] == 5.5 and r["margin"]["goal_hdc|prematch"] == 0.06
    assert r["share"]["goal_hdc|prematch"] == 0.25                       # a day without it took none (0)
    assert reference_values(stats, "2026-07-02") == {}


def test_kickoff_value_never_reads_a_later_price():
    from algoe.features.engineer import _kickoff_value
    t = pd.date_range("2026-07-01 19:40", periods=6, freq="5min")
    m = pd.DataFrame({"match_id": 1, "bucket": t, "is_inplay": [False, False, False, True, True, True],
                      "sup": [0.3, -0.2, 0.5, 1.0, 1.2, np.nan]})
    shuffled = m.iloc[[3, 0, 5, 1, 4, 2]].reset_index(drop=True)
    v = pd.Series(_kickoff_value(shuffled, "sup"), index=shuffled["bucket"]).sort_index()
    assert v.tolist() == [0.3, -0.2, 0.5, 0.5, 0.5, 0.5]          # pre-match its own; in play the last pre-match
    late = pd.DataFrame({"match_id": 2, "bucket": t[:3], "is_inplay": True, "sup": [np.nan, 0.4, 0.9]})
    v = _kickoff_value(late, "sup")                                  # in play since midnight: the first seen
    assert np.isnan(v[0]) and v[1:].tolist() == [0.4, 0.4]


def test_game_state_is_read_against_the_kickoff_favourite():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    ev = pd.DataFrame({"match_id": 1, "provider_id": 1, "incident_type": [13, 27, 57], "home_or_away": [1, 2, 1],
                       "incident_datetime": pd.to_datetime(["2026-07-01 20:01", "2026-07-01 20:02",
                                                            "2026-07-01 20:03"])})
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        dd = FeatureEngineer(s).prepare_day(_line_move_panel(), events=ev, day="2026-07-01")
    m = dd.match.set_index("bucket").loc[pd.Timestamp("2026-07-01 20:05")]
    # SUP +0.2: the home side is the favourite; the away side scored, the home side had a man sent off
    assert m["fav_sign"] == 1 and m["fav_lead"] == -1 and m["dog_leading"] == 1
    assert m["fav_reds"] == 1 and m["dog_reds"] == 0 and m["corners_so_far"] == 1 and m["corner_diff_fav"] == 1
    assert m["goal_p10_dog"] > 0 and m["goal_p10_fav"] == 0
    for frame in (dd.pool, dd.sel):                                  # the shares see the state, not only the match
        at = frame[frame["bucket"] == pd.Timestamp("2026-07-01 20:05")]
        assert len(at) and (at["fav_lead"] == -1).all() and (at["fav_reds"] == 1).all()


def test_board_popularity_shares_the_board():
    from algoe.features.engineer import _board_popularity
    f = pd.DataFrame({"match_id": [1, 2, 3, 1, 2], "inplay": [1, 0, 0, 1, 1],
                      "bucket": pd.to_datetime(["2026-07-01 20:00"] * 3 + ["2026-07-01 20:05"] * 2)})
    out = _board_popularity(f, np.array([np.log(3.0), 0.0, 0.0, np.log(3.0), 0.0]))
    assert np.allclose(out["pop_board_share"], [0.6, 0.2, 0.2, 0.75, 0.25])
    assert np.allclose(out["pop_gap_top"], [0.0, np.log(3.0), np.log(3.0), 0.0, np.log(3.0)])
    assert np.allclose(out["live_pop_share"], [0.6, 0.6, 0.6, 1.0, 1.0])


def test_price_position_in_the_market_and_its_own_hour():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    mk = pd.DataFrame({"pool_id": 10, "line_id": 1, "combination_id": 1, "bookmaker": [12, 9], "odds": [1.80, 2.00],
                       "effective_datetime": pd.Timestamp("2026-07-01 20:01")})
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        sel = FeatureEngineer(s).prepare_day(_line_move_panel(), market=mk, day="2026-07-01").sel
    over = sel[(sel["line_id"] == 1) & (sel["combination_id"] == 1)].set_index("bucket")
    at5 = over.loc[pd.Timestamp("2026-07-01 20:05")]                   # HKJC 1.90 against books at 1.80 and 2.00
    assert np.isclose(at5["hk_vs_best"], 1.9 / 2.0 - 1) and np.isclose(at5["hk_pos"], 0.5)
    at10 = over.loc[pd.Timestamp("2026-07-01 20:10")]                  # out to 3.00: the top of its hour
    assert np.isclose(at10["odds_vs_first"], np.log(3.0 / 1.9)) and at10["odds_pos_60"] == 1.0


def test_a_new_team_takes_its_leagues_level():
    from algoe.features.encoders import fit_encoders
    m = pd.DataFrame({"league_code": ["EPL"] * 4 + ["MLS"] * 2, "market_index": 1.0,
                      "home_name": ["Big", "Big", "Small", "Small", "X", "Y"],
                      "away_name": ["Small", "Mid", "Mid", "Big", "Y", "X"],
                      "y": [1e6, 8e5, 2e5, 9e5, 1e4, 1e4]})
    team = fit_encoders([m], [], 1.0, 1.0, team_prior=1.0).team
    big, known_big = team.transform(pd.DataFrame({"league_code": ["EPL"], "team": ["Big"]}))
    new, known_new = team.transform(pd.DataFrame({"league_code": ["EPL"], "team": ["Newcomer"]}))
    assert known_big[0] == 1 and known_new[0] == 0 and big[0] > new[0]
    assert abs(new[0] - (team.tables["league_code"]["EPL"] - team.global_mean)) < 1e-12


def test_money_features_do_not_move_with_the_market_size():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        fe = FeatureEngineer(s)
        small = fe.prepare_day(_line_move_panel(1.0), day="2026-07-01", market_index=1.0)
        big = fe.prepare_day(_line_move_panel(2.0), day="2026-07-01", market_index=2.0)
    for col in ("s_log_l1", "s_log_ewma_fast", "pos_log_l1", "s_share_pool_l1", "s_rel_stake_l1", "wom_l1"):
        assert np.allclose(small.sel[col].to_numpy(dtype=float), big.sel[col].to_numpy(dtype=float)), col
    for col in ("m_log_l1", "m_log_today", "log_board_l1"):
        assert np.allclose(small.match[col].to_numpy(dtype=float), big.match[col].to_numpy(dtype=float)), col
    assert np.allclose(big.sel["tv1"], 2 * small.sel["tv1"])         # the labels and baselines stay in HK$


def test_live_panel_keeps_the_pools_training_kept():
    from algoe.data.panel import LivePanelBuilder
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        names = ["HILO", "CRS", "AGS", "HAD", "NHILO"]
        odds = pd.DataFrame({"pool_id": range(5), "pool_name": names})
        inv = pd.DataFrame({"pool_id": range(5), "pool_name": names, "turnover": [1.0] * 5})
        o, i = LivePanelBuilder(s)._in_scope(odds, inv)
        assert sorted(o["pool_name"]) == sorted(i["pool_name"]) == ["HAD", "HILO", "NHILO"]


def test_split_by_dates_never_mixes_time():
    from algoe.core.exceptions import ConfigError
    from algoe.data.splits import DaySplit
    from algoe.settings import Settings
    days = list(pd.date_range("2024-06-01", "2026-09-15"))
    sp = DaySplit.from_dates(days, "2025-07-01", "2026-07-01")
    assert sp.train[-1] == pd.Timestamp("2025-06-30") and sp.val[0] == pd.Timestamp("2025-07-01")
    assert sp.val[-1] == pd.Timestamp("2026-06-30") and sp.test[0] == pd.Timestamp("2026-07-01")
    assert max(sp.train) < min(sp.val) and max(sp.val) < min(sp.test)
    assert len(sp.train) + len(sp.val) + len(sp.test) == len(days)
    s = Settings()
    for item in ('window.start="2024-06-01"', 'window.end="2026-09-15"', 'window.val_start="2025-07-01"',
                 'window.test_start="2026-07-01"'):
        s.set(item)
    s.check()
    assert DaySplit.for_window(days, s.window) == sp
    s.set('window.test_start="2025-01-01"')                     # test before val: refused
    try:
        s.check()
        raise AssertionError("accepted test_start before val_start")
    except ConfigError:
        pass


# --------------------------------------------------------------- validation
def test_validation_nulls_sentinels_and_fills():
    from algoe.core.validation import validate
    from algoe.data.panel import PANEL_CONTRACT
    t = pd.Timestamp("2026-07-01 20:00")
    f = pd.DataFrame({"bucket": [t, t, t], "match_id": [1, 1, 1], "pool_id": [10, 10, 10],
                      "line_id": [1, 1, 1], "combination_id": [1, 2, 2],
                      "pool_name": ["HILO", None, None], "odds": [1.9, 9999.0, 2.0],
                      "turnover": [100.0, -5.0, 50.0]})
    out, rep = validate(f, PANEL_CONTRACT)
    assert rep.duplicate_keys >= 1
    row = out[out["combination_id"] == 2].iloc[0]
    assert pd.isna(out.loc[out["odds"] > 1000, "odds"]).all() if (out["odds"] > 1000).any() else True
    assert (out["turnover"] >= 0).all()
    assert str(row["pool_name"]) == "UNKNOWN"
    assert not (pd.to_numeric(out["odds"], errors="coerce") == 9999.0).any()


def test_pool_closing_on_the_boundary_leaves_the_board():
    from algoe.data.panel import mark_forecastable
    T = pd.Timestamp("2026-07-10 21:20")
    f = pd.DataFrame({"bucket": [T] * 3, "is_inplay": [True] * 3, "mins_to_ko": [-110.0] * 3,
                      "priced_before": [True] * 3, "odds": [1.9] * 3,
                      "close_time": [T, T + pd.Timedelta(minutes=2), pd.NaT]})
    # closed at 21:20:00 exactly: no money can arrive in [21:20, 21:25); closing at 21:22: still open at T
    assert mark_forecastable(f, 360)["forecastable"].tolist() == [False, True, True]


def test_live_pool_close_times():
    from types import SimpleNamespace
    from algoe.data.panel import LivePanelBuilder
    T = pd.Timestamp("2026-07-10 21:20")
    odds = pd.DataFrame({"pool_id": [1, 2, 3, 4], "match_id": [9, 9, 9, 8],
                         "pool_name": ["HILO", "HDC", "ETHILO", "HILO"],
                         "effective_datetime": [T - pd.Timedelta(minutes=m) for m in (30, 30, 30, 3)]})
    none = pd.DataFrame(columns=["pool_id", "start_sell_time"])

    def close_of(ap, finished=None):
        out = LivePanelBuilder._pools(SimpleNamespace(active_pools=ap), odds, none, 5, T, finished)
        return dict(zip(out["pool_id"].astype(int), out["close_time"]))

    # nothing has a close time yet (every pool open) - must not raise, everything stays open
    ap = pd.DataFrame({"match_id": [9, 9, 9, 8], "pool_id": [1, 2, 3, 4], "close_time": [pd.NaT] * 4})
    assert all(pd.isna(v) for v in close_of(ap).values())
    # a close the source lists is used; a pool it no longer lists closes after its last price
    ap2 = pd.DataFrame({"match_id": [9, 9, 9], "pool_id": [1, 2, 3], "close_time": [T, pd.NaT, pd.NaT]})
    c = close_of(ap2)
    assert c[1] == T and pd.isna(c[2]) and c[4] == T - pd.Timedelta(minutes=2)
    # full-time result published: the 90-minute pools close now, extra time stays open
    c = close_of(ap, finished={9})
    assert c[1] == T and c[2] == T and pd.isna(c[3]) and pd.isna(c[4])


# ----------------------------------------------------------------- nowcast
def test_nowcast_moves_with_the_money():
    from algoe.realtime.nowcast import BucketNowcaster
    nc = BucketNowcaster(prior_minutes=2.0, bucket_minutes=5.0)
    assert abs(nc.update([100.0], [0.0], 0.0).remaining[0] - 100.0) < 1e-9    # nothing seen: the forecast
    hot = nc.update([100.0], [100.0], 1.0)            # a whole bucket's money in the first minute
    assert abs(hot.remaining[0] - (100 / 5 * 2 + 100) / 3 * 4) < 1e-9 and hot.hot[0] > 1
    cold = nc.update([100.0], [0.0], 4.0)             # four quiet minutes
    assert cold.remaining[0] < 20.0 and cold.hot[0] < 1
    whale = nc.update([100.0], [100000.0], 1.0, next_forecast=np.array([100.0]))   # one ticket, 1000 x the bucket
    assert whale.remaining[0] <= 4.0 * 100 / 5 * 4 + 1e-9 and whale.next_bucket[0] <= 100 * 4.0 ** 0.5 + 1e-9
    # after an event 3 minutes in: one minute of evidence since it, two minutes of the bucket left
    post = nc.update([100.0], [50.0], 1.0, left=2.0)
    assert abs(post.remaining[0] - (100 / 5 * 2 + 50) / 3 * 2) < 1e-9


# -------------------------------------------------------- mix and events
def _event_rows(n_events=400, seed=3):
    """EventShift rows with known effects: after a goal Over money runs at 0.6x the forecast, Under at 1.8x."""
    rng = np.random.default_rng(seed)
    rows = []
    truth = {"goal_total:over": 0.6, "goal_total:under": 1.8}
    for e in range(n_events):
        w = rng.uniform(0, 1)
        for g, m in truth.items():
            f = rng.uniform(500, 1500)
            rows.append({"event_id": "e{}".format(e), "group": g, "event": "goal", "clock": "15-30'",
                         "who": "favourite", "strength": "slight favourite", "state": "favourite ahead",
                         "y": f * (w + (1 - w) * m) * rng.uniform(0.9, 1.1), "f": f, "w": w})
    return pd.DataFrame(rows), truth


def test_event_shift_recovers_known_effects_and_shrinks_thin_cells():
    from algoe.models.event_shift import EventShift
    rows, truth = _event_rows()
    # one red card: its cell has a single event, so it borrows almost everything from "no shift"
    rows = pd.concat([rows, pd.DataFrame([{"event_id": "r1", "group": "goal_total:over", "event": "red",
                                           "clock": "60-75'", "who": "underdog", "strength": "slight favourite",
                                           "state": "level", "y": 5000.0, "f": 1000.0, "w": 0.0}])],
                     ignore_index=True)
    s = EventShift(prior_events=30).fit(rows)
    lab = {"event": "goal", "clock": "15-30'", "who": "favourite", "strength": "slight favourite",
           "state": "favourite ahead"}
    for g, m in truth.items():
        assert abs(s.lookup(g, lab) / m - 1) < 0.06, (g, s.lookup(g, lab), m)    # 400 events vs 30 at 1
    # a narrower cell with a different effect: favourite goals at 75'+ are Over-heavy
    late = rows[(rows["event"] == "goal")].copy()
    late["event_id"] = late["event_id"] + "L"
    late["clock"] = "75'+"
    late.loc[late["group"] == "goal_total:over", "y"] *= 2.0
    s2 = EventShift(prior_events=30).fit(pd.concat([rows, late], ignore_index=True))
    l75, l15 = dict(lab, clock="75'+"), lab
    assert s2.lookup("goal_total:over", l75) > 1.5 * s2.lookup("goal_total:over", l15)
    red = s.lookup("goal_total:over", {"event": "red", "clock": "60-75'", "who": "underdog",
                                       "strength": "slight favourite", "state": "level"})
    assert abs(red - (5 + 30) / 31) < 1e-9, red    # raw 5x, one event against 30 pseudo-events at 1, once
    # an unseen cell takes its deepest fitted parent; an unseen group gets no shift
    other = dict(lab, state="level")
    assert abs(s.lookup("goal_total:over", other) - s.cells["goal_total:over|goal|15-30'|favourite|slight favourite"][0]) < 1e-12
    assert s.lookup("corner_hdc:favourite", lab) == 1.0
    with tempfile.TemporaryDirectory() as tmp:
        back = EventShift.load(s.save(Path(tmp) / "EVENT_SHIFT.json"))
        assert abs(back.lookup("goal_total:under", lab) - s.lookup("goal_total:under", lab)) < 1e-6


def test_side_groups_read_against_the_favourite():
    from algoe.models.event_shift import side_groups
    g = side_groups(["goal_total", "goal_total", "goal_hdc", "goal_hdc", "goal_1x2", "goal_hdc", "goal_other"],
                    ["H", "A", "H", "A", "D", "H", "H"], [1, 1, -1, -1, 1, 0, 1])
    assert list(g) == ["goal_total:over", "goal_total:under", "goal_hdc:underdog", "goal_hdc:favourite",
                       "goal_1x2:draw", "goal_hdc:home", "goal_other:all"]


def _mix_frame():
    """One match-bucket: HILO over / under and HDC home / away; actual vs forecast known."""
    return pd.DataFrame({"match_id": [1] * 4, "bucket": [pd.Timestamp("2026-07-01 20:00")] * 4,
                         "pool_name": ["HILO", "HILO", "HDC", "HDC"],
                         "family": ["goal_total", "goal_total", "goal_hdc", "goal_hdc"],
                         "group": ["goal_total:over", "goal_total:under", "goal_hdc:favourite", "goal_hdc:underdog"],
                         "phase": ["in play"] * 4, "y": [60.0, 20.0, 20.0, 0.0], "last5": [0.0, 0.0, 0.0, 0.0],
                         "model": [40.0, 40.0, 10.0, 10.0]})


def test_misallocated_money_and_share_log_loss():
    from algoe.backtest.mixstudy import SMOOTH, MixScores
    f = _mix_frame()
    ms = MixScores()
    ms.add(f, {"bet type": {"model": f["model"].to_numpy()}, "selection": {"model": f["model"].to_numpy()}},
           {"phase": f["phase"].to_numpy()})
    r = {(x["level"], x["dim"]): x for x in ms.rows()}
    # bet types: actual HiLo 80% / HDC 20%, forecast 80% / 20% -> nothing misallocated
    assert abs(r[("bet type", "all")]["misallocated"]) < 1e-12
    # selections: HILO actual 75/25 vs 50/50 -> 25% of 80; HDC actual 100/0 vs 50/50 -> 50% of 20
    assert abs(r[("selection", "all")]["misallocated"] - (0.25 * 80 + 0.5 * 20) / 100) < 1e-12
    q = (1 - SMOOTH) * 0.5 + SMOOTH / 2
    ll = (80 * -(0.75 * np.log(q) + 0.25 * np.log(q)) + 20 * -np.log(q)) / 100
    assert abs(r[("selection", "all")]["share_log_loss"] - ll) < 1e-9


def test_zero_rows_split_the_wape():
    from algoe.backtest.mixstudy import ZeroSplit
    f = pd.DataFrame({"y": [10.0, 0.0, 0.0, 5.0], "last5": [8.0, 4.0, 0.0, 0.0], "model": [9.0, 2.0, 1.0, 5.0]})
    z = ZeroSplit()
    z.add(f, {"model": f["model"].to_numpy(), "last 5 min": f["last5"].to_numpy()})
    r = {x["method"]: x for x in z.rows()}["model"]
    assert abs(r["wape"] - (1 + 2 + 1 + 0) / 15) < 1e-12
    assert abs(r["wape_money_rows"] + r["wape_quiet_rows"] + r["wape_dead_rows"] - r["wape"]) < 1e-12
    assert abs(r["zero_rows"] - 0.5) < 1e-12 and abs(r["forecast_on_zero_rows"] - 3 / 17) < 1e-12


def _event_day():
    """A favourite (home, SUP +1.0) scores 3 minutes into the 20:25 bucket; a corner at 20:31."""
    from algoe.features.engineer import DayData
    b = pd.date_range("2026-07-01 20:15", periods=5, freq="5min")
    m = pd.DataFrame({"match_id": 7, "bucket": b, "inplay": [0, 1, 1, 1, 1], "minute": [0, 5, 10, 15, 20],
                      "sup": [1.0] * 5, "fav_sign": [1.0] * 5, "home_goals": [0, 0, 0, 1, 1], "away_goals": 0,
                      "home_reds": 0, "away_reds": 0, "home_corners": [0, 0, 0, 0, 1], "away_corners": 0})
    ev = pd.DataFrame({"match_id": [7, 7], "incident_datetime": [pd.Timestamp("2026-07-01 20:28"),
                                                                 pd.Timestamp("2026-07-01 20:31")],
                       "incident_type": [27, 13], "home_or_away": [1, 1], "provider_id": [1, 1]})
    return DayData(pd.Timestamp("2026-07-01"), pd.DataFrame(), m, pd.DataFrame()), ev


def test_events_inside_a_bucket_are_found_and_labelled():
    from algoe.backtest.mixstudy import event_buckets
    from algoe.models.event_shift import incident_table
    dd, ev = _event_day()
    out = event_buckets(dd, incident_table(ev), pd.Timedelta(minutes=5)).set_index("event")
    g = out.loc["goal"]
    assert g["bucket"] == pd.Timestamp("2026-07-01 20:25") and abs(g["k"] - 3.0) < 1e-9 and abs(g["w"] - 0.6) < 1e-9
    assert (g["who"], g["strength"], g["state"], g["clock"]) == ("favourite", "strong favourite (|SUP| >= 0.75)",
                                                                 "favourite ahead", "0-15'")
    c = out.loc["corner"]
    assert c["bucket"] == pd.Timestamp("2026-07-01 20:30") and abs(c["k"] - 1.0) < 1e-9


def test_retune_moves_only_the_event_bucket():
    from algoe.backtest.mixstudy import retune
    from algoe.models.event_shift import EventShift
    s = EventShift()
    s.cells = {"goal_total:over|goal": (0.5, 100), "goal_total:under|goal": (2.0, 100)}
    f = pd.DataFrame({"match_id": [1, 1, 1], "bucket": pd.to_datetime(["2026-07-01 20:25"] * 2 + ["2026-07-01 20:30"]),
                      "group": ["goal_total:over", "goal_total:under", "goal_total:over"], "model": [100.0] * 3})
    evb = pd.DataFrame({"match_id": [1], "bucket": [pd.Timestamp("2026-07-01 20:25")], "event_id": ["x"], "w": [0.6],
                        "event": ["goal"], "clock": ["15-30'"], "who": ["favourite"], "strength": ["slight favourite"],
                        "state": ["favourite ahead"]})
    tuned, mult = retune(f, evb, s)
    assert np.allclose(tuned, [100 * (0.6 + 0.4 * 0.5), 100 * (0.6 + 0.4 * 2.0), 100.0])
    assert np.allclose(mult, [0.5, 2.0, 1.0])


def test_a_live_trigger_keeps_its_match_on_focus_and_reads_the_event():
    from algoe.realtime.live_engine import LiveEngine
    from algoe.settings import Settings
    dd, ev = _event_day()
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        eng = LiveEngine(s, source=object())
        eng.trigger(7, "goal", focus="goal")
        eng.trigger(8, "main-line price moved +6%")
        assert eng.focused() == [7]
        before = eng._event_signature(ev.iloc[:1], 7)
        cancelled = pd.DataFrame({"match_id": [7, 7], "incident_datetime": [pd.Timestamp("2026-07-01 20:28"),
                                                                            pd.Timestamp("2026-07-01 20:29")],
                                  "incident_type": [27, 6], "home_or_away": [1, 1], "provider_id": [1, 1]})
        assert before and eng._event_signature(cancelled, 7) != before        # a VAR cancellation is a new state
        got = eng._event_in_bucket(ev, dd.match, 7, pd.Timestamp("2026-07-01 20:25"), pd.Timestamp("2026-07-01 20:29"))
        assert got["kind"] == "goal" and got["labels"]["who"] == "favourite"
        assert got["labels"]["state"] == "favourite ahead" and got["labels"]["clock"] == "0-15'"   # minute 10 + 3
        assert eng._event_in_bucket(cancelled, dd.match, 7, pd.Timestamp("2026-07-01 20:25"),
                                    pd.Timestamp("2026-07-01 20:29")) is None


# --------------------------------------------------------------- optimizer
def _stress_book(demand_scale=1.0, spike=1.0):
    """One pre-match book: HILO 2.25/2.5/2.75, HDC -0.25/-0.5/-0.75, HILOH 1.5, CHLO 9.5/10.5,
    priced at HKJC's theta with the posted margin; ``spike`` multiplies the money on Over 2.5."""
    from algoe.optimizer.theta_optimizer import MatchBook
    from algoe.pricing.pricer import BookPricer, BookRows, MatchState, repair_theta, theta_from_params
    spec = ([("HILO", "goal", "total", ln, s) for ln in (2.25, 2.5, 2.75) for s in "HL"]
            + [("HDC", "goal", "handicap", ln, s) for ln in (-0.25, -0.5, -0.75) for s in "HA"]
            + [("HILOH", "goal", "home_total", 1.5, s) for s in "HL"]
            + [("CHLO", "corner", "total", ln, s) for ln in (9.5, 10.5) for s in "HL"])
    pool, dom, mkt, line, side = (np.array(c) for c in zip(*spec))
    rows = BookRows(dom, mkt, line.astype("float64"), side)
    th = repair_theta(theta_from_params(2.6, 0.4, 10.0, 1.0))
    p_now, risk = BookPricer().probabilities(rows, th, MatchState())
    margin = np.where(pool == "CHLO", 0.10, 0.075)
    n = len(spec)
    demand = np.full(n, 2000.0 * demand_scale)
    demand[2] *= spike                                   # Over 2.5
    _, group = np.unique(pool, return_inverse=True)
    nan = np.full(n, np.nan)
    return MatchBook(match_id=1, rows=rows, pool=pool, group=group.astype(int), margin=margin, demand=demand,
                     p_true=p_now.copy(), p_ref=nan, p_mkt=nan, odds_now=BookPricer.sell_odds(p_now, margin),
                     odds_mkt=nan, is_main=np.ones(n, bool), state=MatchState(), theta_now=th,
                     p_now=p_now, risk=risk)


def test_optimizer_with_no_money_and_with_a_flood():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    opt = ThetaOptimizer(s)
    o = s.optimizer
    quiet = opt.optimize_match(_stress_book(demand_scale=0.0))
    assert quiet.status.startswith("skipped") and quiet.theta_star == quiet.theta_now
    for spike in (1.0, 100.0, 1e4):
        bk = _stress_book(spike=spike)
        d = opt.optimize_match(bk)
        th, th0 = d.theta_star, d.theta_now
        assert d.egm_star >= d.egm_board - 1e-9, (spike, d.status)
        for dim, band in o.theta_band.items():
            assert abs(th[dim] - th0[dim]) <= band + 1e-6, (spike, dim, th[dim], th0[dim])
        assert abs(th["goal_sup"]) <= th["goal_tg"] + 1e-9 and th["goal_fh_tg"] <= th["goal_tg"] + 1e-9
        odds = d.odds_star
        assert np.all(np.isfinite(odds)) and odds.min() >= o.min_odds and odds.max() <= o.max_odds
        assert np.max(np.abs(1 / odds - 1 / bk.odds_now)) <= o.prob_band + 1e-3, spike
        if spike >= 100:
            # a flood on Over 2.5 shortens Over (raises TG), never the other way
            assert th["goal_tg"] >= th0["goal_tg"] - 1e-6 and odds[2] <= bk.odds_now[2] + 1e-9, spike
        # stage 2: weightings inside the band, each line's overround kept, the ladder free of arbitrage
        w = d.weights
        assert w is not None and np.all(np.abs(w - 1) <= o.weighting_band + 1e-9) and d.lift_stage2 >= -1e-9
        stage1 = odds / w
        for pool, line in {(p, ln) for p, ln in zip(bk.pool, bk.rows.line)}:
            m = (bk.pool == pool) & (bk.rows.line == line)
            assert abs(np.sum(1 / odds[m]) - np.sum(1 / stage1[m])) < 1e-6, (spike, pool, line)
        over = np.array([odds[(bk.pool == "HILO") & (bk.rows.line == ln) & (bk.rows.side == "H")][0]
                         for ln in (2.25, 2.5, 2.75)])
        under = np.array([odds[(bk.pool == "HILO") & (bk.rows.line == ln) & (bk.rows.side == "L")][0]
                          for ln in (2.25, 2.5, 2.75)])
        assert np.all(np.diff(over) >= -1e-9) and np.all(np.diff(under) <= 1e-9), spike


def test_a_reverse_causal_share_model_falls_back_to_a_fixed_elasticity():
    from types import SimpleNamespace
    from algoe.optimizer.theta_optimizer import DemandResponse
    from algoe.settings import Settings
    # the office share model (2026-10-03): positive at evens only with HKJC true odds and a market price,
    # which most rows do not have - without them a longer price takes less money (reverse causality)
    office = {"imp": -0.8054, "log_odds": -0.8491, "value_true": 2.6759, "value_mkt": -0.3664, "hk_vs_mkt": 1.0386}
    fc = SimpleNamespace(models={("glm", "selection_share"): SimpleNamespace(coefficients=lambda: office)},
                         metadata={"true_odds_coverage": 0.0})
    s = Settings()
    dr = DemandResponse.from_forecaster(fc, s)
    assert dr.mode == "fixed" and dr.elasticity == s.optimizer.fixed_elasticity
    fc.metadata["true_odds_coverage"] = 1.0           # a history with true odds makes value_true live
    assert DemandResponse.from_forecaster(fc, s).mode == "share_model"


def test_a_block_without_hkjc_parameters_is_left_alone():
    from algoe.optimizer.theta_optimizer import build_books
    from algoe.pricing.panel_pricing import price_rows_at_hkjc
    from algoe.pricing.pricer import Conventions
    from algoe.settings import Settings
    T = pd.Timestamp("2026-07-01 20:00")
    sel = pd.DataFrame({"match_id": 1, "bucket": T, "pool_id": [1, 1, 2, 2], "line_id": 1,
                        "combination_id": [1, 2, 1, 2], "pool_name": ["HILO", "HILO", "CHLO", "CHLO"],
                        "market": "total", "theta_domain": ["goal", "goal", "corner", "corner"],
                        "line": [2.5, 2.5, 9.5, 9.5], "side": ["H", "L", "H", "L"],
                        "odds": [1.9, 1.9, 1.85, 1.95], "forecastable": True})
    match = pd.DataFrame({"match_id": [1], "bucket": [T], "tg": [2.6], "sup": [0.3], "ctg": [np.nan],
                          "csup": [np.nan], "phase": ["prematch"]})
    stats = {}
    books = build_books(sel, match, np.full(4, 1000.0), np.full(4, 0.5), Settings(), stats=stats)
    assert len(books) == 1 and set(books[0].pool) == {"HILO"} and stats == {"no_params_corner": 1}
    p = price_rows_at_hkjc(sel, match, Conventions())          # no corner theta: no default 9.6 either
    assert np.isfinite(p[:2]).all() and np.isnan(p[2:]).all()


def test_hybrid_last5_takes_the_slot_only_for_a_new_line_with_no_money():
    from algoe.models.turnover import _hybrid_last5
    sel = pd.DataFrame({"tv1": [100.0, 0.0, 50.0], "pos_tv1": [40.0, 1000.0, 1000.0], "line_new": [0.0, 1.0, 1.0]})
    assert _hybrid_last5(sel).tolist() == [100.0, 1000.0, 50.0]


def _tweedie_world(rng, n, lo, hi):
    """Money as compound Poisson-Gamma tickets; log money memory x1 in [lo, hi], market index as exposure."""
    x1, x2, e = rng.uniform(lo, hi, n), rng.uniform(-3, 3, n), rng.uniform(0.5, 2.0, n)
    mu = e * np.exp(1.0 + 0.9 * x1 + 0.4 * np.sin(x2))
    k = rng.poisson(mu / 50.0)
    y = np.array([rng.gamma(2.0, 25.0, size=c).sum() if c else 0.0 for c in k])
    return pd.DataFrame({"x1": x1, "x2": x2}), y, e, mu


def test_anchored_models_extrapolate_where_trees_stop():
    from algoe.models.estimators import available_algorithms, load_estimator, make_estimator
    from algoe.settings import Settings
    rng = np.random.default_rng(3)
    Xtr, ytr, etr, _ = _tweedie_world(rng, 12000, 0, 3)
    Xva, yva, eva, _ = _tweedie_world(rng, 3000, 0, 3)
    Xin, _, ein, min_ = _tweedie_world(rng, 4000, 0, 3)
    Xout, _, eout, mout = _tweedie_world(rng, 4000, 3.5, 5)          # matches 1.6x - 7x bigger than any seen
    s = Settings()
    have = available_algorithms()
    algos = [a for a in ("gbm", "glm_gbm", "xgb", "glm_xgb", "cat", "glm_cat", "nn", "glm_nn") if have[a]]
    bias = {}
    for algo in algos:
        est = make_estimator(algo, "tweedie", 1.5, s, features=["x1", "x2"], features_glm=["x1", "x2"])
        est.fit(Xtr, ytr, exposure=etr, X_val=Xva, y_val=yva, exposure_val=eva)
        est = load_estimator(est.to_state())                         # what the model store gives back
        bias[algo] = (est.predict(Xin, exposure=ein).sum() / min_.sum() - 1,
                      est.predict(Xout, exposure=eout).sum() / mout.sum() - 1)
    for algo, (inside, outside) in bias.items():
        assert abs(inside) < 0.06, (algo, inside)                   # inside the range every model is right
        if algo.startswith("glm_"):
            # the anchor carries the trend past it; 12k heavy-tailed rows give the GLM slope a standard
            # error near 0.03, which two log units of extrapolation turn into about +-10%
            assert abs(outside) < 0.2, (algo, outside)
        else:
            assert outside < -0.5, (algo, outside)                  # a tree / clipped network stops at the edge
    # only the money level carries the trend: another input past its range is held at the edge
    est = make_estimator("glm_gbm", "tweedie", 1.5, s, features=["x1", "x2"], features_glm=["x1", "x2"],
                         extrapolate=["x1"]).fit(Xtr, ytr, exposure=etr)
    at = pd.DataFrame({"x1": [2.0, 2.0, 4.0], "x2": [3.0, 10.0, 3.0]})
    p = est.predict(at, exposure=np.ones(3))
    assert abs(p[1] / p[0] - 1) < 1e-9 and p[2] > 3 * p[0]


def test_trees_carry_exposure_exactly():
    from algoe.models.estimators import available_algorithms, load_estimator, make_estimator
    from algoe.settings import Settings
    rng = np.random.default_rng(5)
    X = pd.DataFrame({"x": rng.uniform(size=6000)})
    e = rng.uniform(1, 1000, 6000)
    y = rng.poisson(e * 0.3).astype(float)                            # one rate, exposures over 3 decades
    have = available_algorithms()
    for algo in [a for a in ("gbm", "xgb", "cat") if have[a]]:
        for family in ("poisson", "tweedie"):
            est = make_estimator(algo, family, 1.5, Settings(), features=["x"]).fit(X, y, exposure=e)
            p = load_estimator(est.to_state()).predict(X, e)
            assert abs(p.sum() / y.sum() - 1) < 0.02 and np.max(np.abs(p / (0.3 * e) - 1)) < 0.1, (algo, family)


def test_champion_prefers_the_anchored_twin_within_tolerance():
    from algoe.models.turnover import TurnoverForecaster, _biggest
    from algoe.settings import Settings
    tf = TurnoverForecaster.__new__(TurnoverForecaster)
    tf.settings = Settings()

    def dev(d, bias=0.0):
        return {"all": {"deviance": d, "bias": bias}}
    scores = {"last5": dev(100.0), "three_stage:gbm+gbm+gbm": dev(50.0, -0.01),
              "three_stage:glm_gbm+gbm+gbm": dev(50.4, -0.02)}
    assert tf._pick_champion(scores) == "three_stage:glm_gbm+gbm+gbm"     # 0.8% worse: as good, and extrapolates
    scores["three_stage:glm_gbm+gbm+gbm"] = dev(52.0, -0.02)
    assert tf._pick_champion(scores) == "three_stage:gbm+gbm+gbm"         # 4% worse: the plain winner stays
    scores["three_stage:glm_gbm+gbm+gbm"] = dev(50.2, -0.18)
    assert tf._pick_champion(scores) == "three_stage:gbm+gbm+gbm"         # close deviance, level 18% short: stays
    tot = np.column_stack([np.arange(1.0, 201.0), 0.5 * np.arange(1.0, 201.0)])
    big = _biggest(tot)
    assert big["top1_matches"] == 10 and abs(big["top1_bias"] + 0.5) < 1e-12 and big["top1_smallest"] == 191.0


def test_margin_effect_recovers_a_known_elasticity_under_confounding():
    from types import SimpleNamespace
    from algoe.backtest.diagnostics import margin_effect
    rng = np.random.default_rng(11)
    days = ["2026-07-{:02d}".format(d) for d in range(1, 21)]
    store, sets = {}, {}
    for i, d in enumerate(days):
        n = 1500
        pop = rng.normal(size=n)                                  # popular matches take more AND get lower margins
        margin = 0.07 - 0.006 * pop + 0.006 * rng.normal(size=n)
        log_money = 2.0 + 1.0 * pop - 8.0 * margin + 0.3 * rng.normal(size=n)   # true theta = -8
        store[d] = SimpleNamespace(day=d, empty=False, pool=pd.DataFrame({"p_margin": margin}),
                                   match=pd.DataFrame({"market_index": [1.0]}))
        sets[d] = _PoolRows(pd.DataFrame({"p_margin": margin, "pop": pop}), np.expm1(log_money),
                            pd.DataFrame({"match_id": rng.integers(0, 300, n) + 1000 * i}),
                            pd.DataFrame({"family": "goal_hdc", "phase": "prematch"}, index=range(n)))
    engineer = SimpleNamespace(features_for_turnover_pool_share=lambda dd: sets[dd.day])
    rows = margin_effect(SimpleNamespace(engineer=engineer), SimpleNamespace(get=store.get), days)["rows"]
    assert rows and all(r["identified"] for r in rows)
    for r in rows:
        assert abs(r["theta"] + 8.0) < 1.5, r                    # margin alone, uncontrolled, gives about -90


class _PoolRows:
    """What margin_effect reads of a pool FeatureSet."""

    def __init__(self, X, y, keys, cuts):
        self.X, self.y, self.keys, self.cuts = X, y, keys, cuts

    def __len__(self):
        return len(self.y)


def test_volume_response_keeps_the_boards_margin():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    bk = _stress_book()

    def gm(opt, k):
        odds = bk.odds_now * k                       # every price k x: a dearer (k < 1) or cheaper board
        return opt.expected_gm(bk, odds, opt.demand_at(bk, odds))
    neutral = ThetaOptimizer(s)
    g = {k: gm(neutral, k) for k in (0.97, 0.99, 1.0, 1.01, 1.03)}
    assert g[1.0] >= max(g.values()) - 1e-6          # HKJC's margin is the volume-optimal one
    s.optimizer.volume_response = "none"
    fixed = ThetaOptimizer(s)
    assert gm(fixed, 0.97) > gm(fixed, 1.0)          # without a volume response a dearer board looks free


# ---------------------------------------------------------------- settings
def test_settings_reject_unknown_keys():
    from algoe.core.exceptions import ConfigError
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.data_dir="C:\\\\data\\\\Raw_Data"')
    assert s.paths.data_dir.endswith("Raw_Data")
    for bad in ("optimizer.not_a_knob=1", "nosection.key=1"):
        try:
            s.set(bad)
            raise AssertionError("accepted " + bad)
        except ConfigError:
            pass
    s.set("turnover.tweedie_power=3")
    try:
        s.check()
        raise AssertionError("accepted tweedie_power=3")
    except ConfigError:
        pass


# ------------------------------------------------------------- model store
def test_model_store_guards():
    from algoe.core.exceptions import RegistryError
    from algoe.registry.model_store import ModelStore
    with tempfile.TemporaryDirectory() as tmp:
        sel = lambda v: {"selection": {"metric": "deviance", "days": ["2026-07-10"], "deviance": v}}  # noqa: E731
        v4 = ModelStore(tmp, "turnover", feature_version=4)
        v4.save("a", {"w": 1}, sel(10.0))
        v4.promote("a", "first")
        assert v4.load("a")[0] == {"w": 1}
        try:
            ModelStore(tmp, "turnover", feature_version=5).load("a")
            raise AssertionError("served a bundle built on other features")
        except RegistryError:
            pass
        v5 = ModelStore(tmp, "turnover", feature_version=5)
        v5.save("b", {"w": 2}, sel(50.0))
        assert v5.promote_if_better("b", "deviance", 50.0, 100.0)       # old champion is stale
        v5.save("c", {"w": 3}, sel(60.0))
        assert not v5.promote_if_better("c", "deviance", 60.0, 100.0)   # same features, worse
        with open(Path(tmp) / "turnover" / "b" / "bundle.pkl", "ab") as fh:
            fh.write(b"tampered")
        try:
            v5.load("b")
            raise AssertionError("served a tampered bundle")
        except RegistryError:
            pass


# ----------------------------------------------------------------- monitor
def test_psi_is_zero_on_same_distribution():
    from algoe.monitoring.monitor import Monitor
    from algoe.settings import Settings
    rng = np.random.default_rng(5)

    def sample(n, zero_share):
        v = rng.exponential(3.0, size=n)
        v[rng.random(n) < zero_share] = 0.0
        return pd.DataFrame({"money": np.log1p(v)})
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        mon = Monitor(s)
        ref = mon.feature_reference(sample(50000, 0.7))
        same = mon.drift(ref, sample(20000, 0.7))["features"][0]["psi"]
        moved = mon.drift(ref, sample(20000, 0.4))["features"][0]["psi"]
        assert same < 0.02, same
        assert moved > 0.1, moved


# ----------------------------------------------------------------- leakage
def test_goal_pulse_ignores_later_events():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        fe = FeatureEngineer(s)
        T = pd.Timestamp("2026-07-01 20:05")
        m = pd.DataFrame({"match_id": [1, 1], "bucket": [T, T + pd.Timedelta(minutes=5)]})
        # provider 1 has more goals before T, provider 2 more over the whole match: choosing a
        # provider by its whole-match count would let the goals after T change the pulse at T
        at = [pd.Timestamp("2026-07-01 " + h) for h in ("20:01", "20:03", "20:04", "20:07", "20:08")]
        ev = pd.DataFrame({"match_id": [1] * 5, "home_or_away": [1, 2, 1, 2, 1], "incident_type": [27] * 5,
                           "provider_id": [1, 1, 2, 2, 2], "incident_datetime": at})
        full = fe._group_events(m.copy(), ev)
        known_at_T = fe._group_events(m.copy(), ev[ev["incident_datetime"] < T])
        cols = ["goal_p3", "goal_p10", "goals_so_far"]
        assert np.allclose(full.loc[0, cols].to_numpy(dtype=float), known_at_T.loc[0, cols].to_numpy(dtype=float))


# --------------------------------------------------------------------- cli
def test_cli_parses_every_command():
    from algoe.cli import build_parser
    p = build_parser()
    for cmd in ("selftest", "check-data", "build-panel", "build-features", "train-turnover", "train-probability",
                "backtest", "parity", "live", "monitor", "models", "nightly"):
        assert callable(p.parse_args([cmd]).func), cmd


def test_selftest_passes():
    if os.environ.get("ALGOE_SLOW") != "1":
        return
    from algoe.selftest import run_selftest
    ck, _ = run_selftest()
    assert not ck.failed, ck.table()


# ------------------------------------------------------------------ runner
if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<48} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<48} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
