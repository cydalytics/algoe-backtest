"""
Process pool tests - workers leave when the process that made the pool is killed outright

    python tests/test_pool.py                  plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_pool.py

start.ps1 stops the API with Stop-Process -Force. A killed parent never shuts its pool down, and on Windows
the workers then waited on their queue for ever (32 idle workers, 3.5 GB, after four dry-run servers on
2026-10-29).

Change Log:
-----------
2026-10-29      Initialize
"""

import os
import subprocess
import sys
import tempfile
import textwrap
import time
import traceback
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

PARENT = textwrap.dedent("""
    import os, sys, time
    sys.path.insert(0, {backend!r})
    from algoe.core.pool import process_pool

    def pid(_):
        time.sleep(0.2)
        return os.getpid()

    if __name__ == "__main__":
        pool = process_pool(2)
        pids = set()
        while len(pids) < 2:
            pids |= set(pool.map(pid, range(4)))
        print(",".join(str(p) for p in sorted(pids)), flush=True)
        time.sleep(120)
""")


def _alive(pid: int) -> bool:
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.OpenProcess.restype = ctypes.c_void_p
    k32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
    handle = k32.OpenProcess(0x1000, 0, pid)                     # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    code = ctypes.c_uint32()
    k32.GetExitCodeProcess(ctypes.c_void_p(handle), ctypes.byref(code))
    k32.CloseHandle(ctypes.c_void_p(handle))
    return code.value == 259                                     # STILL_ACTIVE


def test_workers_leave_when_their_parent_is_killed():
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "parent.py"
        script.write_text(PARENT.format(backend=str(BACKEND)), encoding="utf-8")
        parent = subprocess.Popen([sys.executable, str(script)], stdout=subprocess.PIPE, text=True)
        workers = []
        try:
            workers = [int(p) for p in parent.stdout.readline().strip().split(",") if p]
            assert len(workers) == 2 and all(_alive(p) for p in workers), workers
            parent.kill()                                        # TerminateProcess: no shutdown, no atexit
            parent.wait(10)
            deadline = time.time() + 15
            while time.time() < deadline and any(_alive(p) for p in workers):
                time.sleep(0.25)
            left = [p for p in workers if _alive(p)]
            assert not left, "workers still running after their parent was killed: {}".format(left)
        finally:
            if parent.poll() is None:
                parent.kill()
            for p in workers:                                    # a failed run leaves no orphan behind
                if _alive(p):
                    subprocess.run(["taskkill", "/PID", str(p), "/F"] if os.name == "nt" else ["kill", "-9", str(p)],
                                   capture_output=True)


def test_a_worker_whose_parent_lives_keeps_working():
    from algoe.core.pool import process_pool
    with process_pool(2) as pool:
        assert sorted(pool.map(abs, [-3, -1, 2])) == [1, 2, 3]
        time.sleep(1.0)                                          # the watch thread runs and stays quiet
        assert sorted(pool.map(abs, [-5, 4])) == [4, 5]


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
