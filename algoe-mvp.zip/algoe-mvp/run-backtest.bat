@echo off
REM Command-line backtest: Raw_Data -> Backtest_Data, day by day, with a full log.
REM
REM   run-backtest.bat                                   full window 2026-07-01 .. 2026-09-15
REM   run-backtest.bat --start 2026-07-01 --end 2026-07-03 --warmup-days 1
REM                                                      quick 3-day check first
REM   run-backtest.bat --data-dir "D:\somewhere\Raw_Data"
REM
REM Output: S:\Users\Yeung\20260520 Algo E\Backtest_Data  (next to Raw_Data)
REM Log:    Backtest_Data\logs\run_<time>.log   One line per day: Backtest_Data\daily_summary.csv
cd /d "%~dp0backend"
python -m src.backtest.parquet.cli run %*
echo.
echo Finished. Files are in Backtest_Data next to Raw_Data.
pause
