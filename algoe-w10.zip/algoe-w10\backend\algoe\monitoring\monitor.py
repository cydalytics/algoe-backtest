"""
Monitor

A model that was good on its test days can go stale: a new season, a new
league, a change in how HKJC posts lines. The monitor watches three things
and writes an alert the moment one of them moves:

    accuracy     every forecast the live engine publishes is logged; once the
                 bucket closes the money that actually arrived is joined on,
                 and rolling WAPE / deviance / bias are compared with what last
                 5 minutes would have scored on the same rows
    inputs       each feature's distribution against the one the model was
                 trained on (population stability index, per feature)
    novelty      leagues the encoder has never seen and pool codes the
                 taxonomy had to infer

    <work>/monitor/forecasts/<day>/<HHMM>.parquet   what was published
    <work>/monitor/scored/<day>.parquet             forecast joined with actual
    <work>/monitor/alerts.jsonl                     one line per alert
    <work>/monitor/health.json                      the latest summary

The same checks run offline over history (scripts/s09_monitor.py), so the
first live day is not the first time anyone looks.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      PSI against the stored share of each training bin (repeated deciles merged); drift can
                skip features
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.io import write_json, write_parquet
from ..core.logging import get_logger
from ..data.panel import KEY
from ..evaluation.metrics import poisson_deviance, psi, wape

logger = get_logger(__name__)


class Monitor:
    def __init__(self, settings):
        self.settings = settings
        self.root = Path(settings.paths.monitor)
        self.root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------ logging
    def log_forecasts(self, bucket, frame: pd.DataFrame, model: Optional[str] = None) -> Path:
        b = pd.Timestamp(bucket)
        out = frame.copy()
        out["bucket"] = b
        out["model"] = model or "unknown"
        out["logged_at"] = pd.Timestamp.now()
        return write_parquet(out, self.root / "forecasts" / "{:%Y-%m-%d}".format(b) / "{:%H%M}.parquet".format(b))

    def join_realised(self, day, store) -> Optional[pd.DataFrame]:
        """Logged forecasts of ``day`` joined with the money that arrived (from the feature store)."""
        folder = self.root / "forecasts" / "{:%Y-%m-%d}".format(pd.Timestamp(day))
        parts = sorted(folder.glob("*.parquet")) if folder.exists() else []
        if not parts:
            return None
        fc = pd.concat([pd.read_parquet(p) for p in parts], ignore_index=True)
        dd = store.get(day)
        if dd.empty:
            return None
        act = dd.sel[KEY + ["bucket", "y", "tv1"]]
        fc["bucket"] = pd.to_datetime(fc["bucket"]).astype("datetime64[ns]")
        for c in KEY:
            fc[c] = pd.to_numeric(fc[c], errors="coerce").astype("int64")
        joined = fc.merge(act, on=KEY + ["bucket"], how="left")
        joined["y"] = joined["y"].fillna(0.0)
        joined["tv1"] = joined["tv1"].fillna(0.0)
        write_parquet(joined, self.root / "scored" / "{:%Y-%m-%d}.parquet".format(pd.Timestamp(day)))
        return joined

    # ------------------------------------------------------------- health
    def health_from_frames(self, frames: Dict[str, pd.DataFrame]) -> dict:
        """frames: day -> rows with y, forecast, tv1 (last 5), match_id, bucket."""
        m = self.settings.monitor
        daily = []
        for day, f in sorted(frames.items()):
            if f is None or f.empty:
                continue
            y, p, l5 = (f[c].to_numpy(dtype="float64") for c in ("y", "forecast", "tv1"))
            daily.append({"day": str(pd.Timestamp(day).date()), "rows": int(len(f)), "turnover": float(y.sum()),
                          "wape_model": wape(y, p), "wape_last5": wape(y, l5),
                          "deviance_model": poisson_deviance(y, p), "deviance_last5": poisson_deviance(y, l5),
                          "bias_model": (float(p.sum()) / float(y.sum()) - 1) if y.sum() > 0 else None})
        alerts = []
        recent = daily[-m.rolling_days:]
        if recent:
            y = sum(d["turnover"] for d in recent)
            dev_m = np.mean([d["deviance_model"] for d in recent])
            dev_l = np.mean([d["deviance_last5"] for d in recent])
            wm = np.mean([d["wape_model"] for d in recent if d["wape_model"] is not None] or [np.nan])
            wl = np.mean([d["wape_last5"] for d in recent if d["wape_last5"] is not None] or [np.nan])
            if np.isfinite(wm) and np.isfinite(wl) and wm > m.wape_alert_ratio * wl:
                alerts.append(self._alert("accuracy", "rolling {}d WAPE {:.1%} is worse than last 5 min {:.1%} x {:.2f}"
                                          .format(len(recent), wm, wl, m.wape_alert_ratio), {"wape": wm, "last5": wl}))
            if dev_m > dev_l:
                alerts.append(self._alert("accuracy", "rolling {}d deviance {:.4g} is worse than last 5 min {:.4g}"
                                          .format(len(recent), dev_m, dev_l), {"deviance": dev_m, "last5": dev_l}))
            b = [d["bias_model"] for d in recent if d["bias_model"] is not None]
            if b and abs(np.mean(b)) > m.bias_alert:
                alerts.append(self._alert("bias", "rolling bias {:+.1%} beyond +-{:.0%}".format(np.mean(b), m.bias_alert),
                                          {"bias": float(np.mean(b))}))
            logger.info("monitor: %d day(s), recent WAPE %.1f%% vs last5 %.1f%% on %.0f turnover", len(recent),
                        100 * wm if np.isfinite(wm) else float("nan"), 100 * wl if np.isfinite(wl) else float("nan"), y)
        return {"daily": daily, "alerts": alerts}

    # -------------------------------------------------------------- drift
    @staticmethod
    def feature_reference(X: pd.DataFrame, max_rows: int = 200_000, seed: int = 7) -> Dict[str, dict]:
        """Decile bins of each training feature and the share of training rows in each bin.

        The shares are stored, not assumed to be 10% each: a zero-inflated or discrete feature
        has repeated deciles, and after merging them one bin can hold most of the rows."""
        if len(X) > max_rows:
            X = X.sample(max_rows, random_state=seed)
        ref = {}
        for c in X.columns:
            v = X[c].to_numpy(dtype="float64")
            v = v[np.isfinite(v)]
            if len(v) < 100 or np.unique(v).size <= 2:
                continue
            edges = np.unique(np.quantile(v, np.linspace(0, 1, 11)))
            if len(edges) < 3:
                continue
            ref[c] = {"edges": edges.tolist(), "p": (np.histogram(v, _open(edges))[0] / len(v)).tolist()}
        return ref

    def drift(self, reference: Dict[str, dict], X: pd.DataFrame, skip: Optional[set] = None) -> dict:
        """PSI of each feature in X against its training bins; ``skip`` names are not checked."""
        rows, alerts = [], []
        for c, r in reference.items():
            if c not in X.columns or (skip and c in skip):
                continue
            if isinstance(r, dict):
                e, pe = np.asarray(r["edges"], dtype="float64"), np.asarray(r["p"], dtype="float64")
            else:
                # older bundles stored the deciles only: the expected share is known only if they are distinct
                e, pe = np.asarray(r, dtype="float64"), None
                if len(np.unique(e)) != len(e):
                    continue
            if len(e) < 3:
                continue
            v = X[c].to_numpy(dtype="float64")
            v = v[np.isfinite(v)]
            if len(v) < 200:
                continue
            pa = np.histogram(v, _open(e))[0] / len(v)
            if pe is None:
                pe = np.full(len(pa), 1.0 / len(pa))
            pa, pe = np.clip(pa, 1e-4, None), np.clip(pe, 1e-4, None)
            val = float(np.sum((pa - pe) * np.log(pa / pe)))
            rows.append({"feature": c, "psi": val})
            if val > self.settings.monitor.psi_alert:
                alerts.append(self._alert("drift", "{} drifted: PSI {:.2f} (alert above {:.2f})".format(
                    c, val, self.settings.monitor.psi_alert), {"feature": c, "psi": val}))
        rows.sort(key=lambda r: -r["psi"])
        return {"features": rows, "alerts": alerts}

    # ------------------------------------------------------------ novelty
    def novelty(self, day_data, encoders, taxonomy) -> dict:
        out = {"new_leagues": [], "inferred_pools": taxonomy.inferred_codes() if taxonomy else {}}
        if encoders is not None and encoders.league is not None and day_data is not None and not day_data.empty:
            known = set(encoders.league.tables.get("league_code", {}))
            seen = set(day_data.match["league_code"].astype(str).unique())
            out["new_leagues"] = sorted(seen - known)
        alerts = []
        if out["new_leagues"]:
            alerts.append(self._alert("novelty", "league(s) never seen in training: {} - forecast at the global level, "
                                      "match effect learns within the day".format(out["new_leagues"]),
                                      {"leagues": out["new_leagues"]}))
        if out["inferred_pools"]:
            alerts.append(self._alert("novelty", "pool code(s) placed by rule: {} - confirm in {}".format(
                sorted(out["inferred_pools"]), self.settings.paths.pools_file), {"pools": out["inferred_pools"]}))
        out["alerts"] = alerts
        return out

    # ------------------------------------------------------------- output
    def _alert(self, kind: str, message: str, data: Optional[dict] = None) -> dict:
        a = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "kind": kind, "message": message, "data": data or {}}
        with (self.root / "alerts.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(a, default=str) + "\n")
        logger.warning("ALERT [%s] %s", kind, message)
        return a

    def write_health(self, payload: dict) -> Path:
        return write_json(payload, self.root / "health.json")


def _open(edges: np.ndarray) -> np.ndarray:
    """Bin edges with open ends, so values outside the training range land in the end bins."""
    e = np.asarray(edges, dtype="float64").copy()
    e[0], e[-1] = -np.inf, np.inf
    return e
