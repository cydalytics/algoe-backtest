var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/backtest/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__20q_dsq._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_backtest_[[___path]]_route_actions_0eswlt1.js")
R.m(32226)
module.exports=R.m(32226).exports
