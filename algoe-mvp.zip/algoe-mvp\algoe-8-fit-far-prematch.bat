@echo off
REM Algo E - the far pre-match curve: how much money a match takes per 5 minutes days before kick-off,
REM against the hour before the turnover models' 6-hour window. The desk forecasts every match on sale
REM outside that window with it. Fitted on Raw_Data, scored on the last week of kick-offs against last
REM 5 minutes, and saved to AlgoE_Work\models\turnover\FAR_PREMATCH.json only when it beats it.
REM     algoe-8-fit-far-prematch.bat               the last 42 days of Match_Investments
REM     algoe-8-fit-far-prematch.bat --days 90     a longer history
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe fit-far-prematch %*
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Saved. Restart the desk to use it.) else if "%CODE%"=="2" (echo Not saved: it does not beat last 5 minutes - the desk keeps its current curve.) else (echo FAILED - read the lines above.)
pause
exit /b %CODE%
