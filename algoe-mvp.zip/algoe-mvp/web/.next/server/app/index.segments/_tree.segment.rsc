:HL["/_next/static/chunks/1koq9gehzs59m.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"mY8ZV-5tVFMciYraNUH46"}
