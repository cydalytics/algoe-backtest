"""
Match_Investments day quality

A day file holds the money of the pools concluded that day. One extracted before that day's bets were all
loaded (the red day on the Backtest tab came from a 12 KB file) reads like any other, and a model scored on
it loses for a reason that is not the model's. raw_update checks each day it writes and check-data checks
every day on disk:

    pools   the pools with money in the file against the pools G2_pool_details concluded that day (the pool
            types the extract leaves out excluded): under half of them, or under three quarters of the usual
            share, is suspect; so is money per concluded pool under a quarter of the usual
    money   without the pool count (check-data where the Pool_Details file of the day has no conclude_date or
            cannot be read, and no count from the extract): money and rows against the median of the 28 days
            before of the same kind, weekday or weekend; under a quarter is suspect

A day newer than D-2 is provisional (late bets and late conclusions still land), otherwise ok or suspect. A
re-extract with under 95% of the money on disk, or judged suspect where the file on disk is not, does not
replace the file (--force does): the file stays and the verdict is the file's. Raw_Data/_algoe_quality.json
keeps every checked day's numbers, verdict, reasons and when its file was last written; panels, fits and
scores leave suspect days out.

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      A suspect re-extract does not replace a file that is not; an unreadable Pool_Details file
                leaves only the days it covers without the pool count
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from src.core.logging import get_logger

logger = get_logger(__name__)

QUALITY = "_algoe_quality.json"
TRAILING_DAYS = 28
MIN_USUAL_DAYS = 3                  # fewer days of the same kind before it: no usual level to judge against
FINAL_AFTER_DAYS = 2
RETRY_DAYS = 30
SHARE_FLOOR = 0.5
SHARE_OF_USUAL = 0.75
MONEY_OF_USUAL = 0.25
KEEP_OLD_BELOW = 0.95
EXCLUDED_POOL_TYPES = ("SGA", "TQL", "MSP")      # the investment extract's own filter

_DAY_FILE = re.compile(r"^match_investments_(\d{4}-\d{2}-\d{2})_\d{4}-\d{2}-\d{2}\.parquet$")
_NAME_DATE = re.compile(r"(\d{4})-?(\d{2})-?(\d{2})")


# ------------------------------------------------------------------ numbers
def frame_stats(frame: Optional[pd.DataFrame]) -> dict:
    """Rows, money and pools with money of a day's rows."""
    if frame is None or not len(frame):
        return {"rows": 0, "money": 0.0, "pools": 0}
    money = float(pd.to_numeric(frame["turnover"], errors="coerce").fillna(0.0).sum()) \
        if "turnover" in frame.columns else 0.0
    pools = int(frame["pool_id"].nunique()) if "pool_id" in frame.columns else 0
    return {"rows": int(len(frame)), "money": money, "pools": pools}


def file_stats(path) -> Optional[dict]:
    """frame_stats of a day file on disk (two columns read) with its size and time; None if unreadable."""
    import pyarrow.parquet as pq
    path = Path(path)
    try:
        pf = pq.ParquetFile(path)
        names = pf.schema_arrow.names
        frame = pf.read(columns=[c for c in ("pool_id", "turnover") if c in names]).to_pandas()
        rows = pf.metadata.num_rows
        st = path.stat()
    except Exception:                                                    # noqa: BLE001
        return None
    out = frame_stats(frame)
    out.update(rows=int(rows), bytes=int(st.st_size), mtime=float(st.st_mtime))
    return out


def concluded_pools(pool_details: Optional[pd.DataFrame], day) -> Optional[int]:
    """Pools G2_pool_details concluded on ``day`` (the extract's pool types); None without conclude_date."""
    if pool_details is None or "conclude_date" not in pool_details.columns:
        return None
    t = pd.to_datetime(pool_details["conclude_date"], errors="coerce")
    d = pd.Timestamp(day).normalize()
    mask = (t >= d) & (t <= d + pd.Timedelta(days=1))           # the extract's BETWEEN day AND day + 1
    if "pool_type" in pool_details.columns:
        mask &= ~pool_details["pool_type"].astype(str).str.upper().isin(EXCLUDED_POOL_TYPES)
    return int(pool_details.loc[mask, "pool_id"].nunique())


def _weekend(day) -> bool:
    return pd.Timestamp(day).dayofweek >= 5


def _usual(day: pd.Timestamp, history: Dict[str, dict]) -> dict:
    """Medians over the TRAILING_DAYS before ``day`` of the same kind (weekday / weekend), suspect days out."""
    lo = day - pd.Timedelta(days=TRAILING_DAYS)
    same = []
    for k, r in history.items():
        try:
            t = pd.Timestamp(k)
        except ValueError:
            continue
        if lo <= t < day and _weekend(t) == _weekend(day) and (r or {}).get("verdict") != "suspect" \
                and (r or {}).get("rows"):
            same.append(r)
    if len(same) < MIN_USUAL_DAYS:
        return {}
    out = {"days": len(same), "money": float(np.median([float(r.get("money") or 0.0) for r in same])),
           "rows": float(np.median([float(r.get("rows") or 0.0) for r in same]))}
    paid = [r for r in same if r.get("pools_expected")]
    if len(paid) >= MIN_USUAL_DAYS:
        out["share"] = float(np.median([float(r.get("pools") or 0) / float(r["pools_expected"]) for r in paid]))
        out["per_pool"] = float(np.median([float(r.get("money") or 0.0) / float(r["pools_expected"]) for r in paid]))
    return out


def judge(day, stats: dict, history: Dict[str, dict], today, expected: Optional[int] = None) -> dict:
    """The verdict on one day from its numbers, the days before it and the pools concluded (if known)."""
    d = pd.Timestamp(day).normalize()
    usual = _usual(d, history or {})
    kind = "weekend" if _weekend(d) else "weekday"
    reasons: List[str] = []
    rows, money, pools = int(stats.get("rows") or 0), float(stats.get("money") or 0.0), int(stats.get("pools") or 0)
    if expected:
        share = pools / float(expected)
        floor = max(SHARE_FLOOR, SHARE_OF_USUAL * usual["share"]) if usual.get("share") else SHARE_FLOOR
        if share < floor:
            reasons.append("money on {} of the {} pools concluded ({:.0%}, usual {})".format(
                pools, expected, share, "{:.0%}".format(usual["share"]) if usual.get("share") else "n/a"))
        if usual.get("per_pool") and money / float(expected) < MONEY_OF_USUAL * usual["per_pool"]:
            reasons.append("HK${:,.0f} a concluded pool, usual HK${:,.0f} on a {}".format(
                money / float(expected), usual["per_pool"], kind))
    elif expected is None and usual:            # (no pool concluded: no money is the right answer)
        if usual["money"] > 0 and money < MONEY_OF_USUAL * usual["money"]:
            reasons.append("HK${:,.0f}, usual HK${:,.0f} on a {}".format(money, usual["money"], kind))
        if usual["rows"] > 0 and rows < MONEY_OF_USUAL * usual["rows"]:
            reasons.append("{:,} rows, usual {:,.0f} on a {}".format(rows, usual["rows"], kind))
    if rows == 0 and (expected or (expected is None and usual.get("rows"))):
        reasons.append("no rows")
    today = pd.Timestamp(today).normalize()
    verdict = "suspect" if reasons else (
        "provisional" if d > today - pd.Timedelta(days=FINAL_AFTER_DAYS) else "ok")
    return {"day": str(d.date()), "verdict": verdict, "reasons": reasons, "rows": rows, "money": money,
            "pools": pools, "pools_expected": int(expected) if expected is not None else None,
            "usual_money": usual.get("money"), "usual_rows": usual.get("rows"), "usual_share": usual.get("share")}


def keeps_old(new: dict, old: Optional[dict], force: bool = False) -> bool:
    """A re-extract with under KEEP_OLD_BELOW of the money on disk does not replace the file."""
    return not force and old is not None and float(old.get("money") or 0.0) > 0 \
        and float(new.get("money") or 0.0) < KEEP_OLD_BELOW * float(old["money"])


# ------------------------------------------------------------------ the file
class QualityBook:
    """Raw_Data/_algoe_quality.json: {"days": {YYYY-MM-DD: record}, "checked": when}."""

    def __init__(self, data_dir):
        self.path = Path(data_dir) / QUALITY
        self.data = read_quality(data_dir)
        self.data.setdefault("days", {})

    @property
    def days(self) -> Dict[str, dict]:
        return self.data["days"]

    def record(self, rec: dict, written: bool = False) -> dict:
        old = self.days.get(rec["day"]) or {}
        rec = dict(rec, checked_at=str(pd.Timestamp.now().floor("s")))
        rec["written_at"] = rec["checked_at"] if written else old.get("written_at")
        self.days[rec["day"]] = rec
        return rec

    def save(self) -> Path:
        self.data["checked"] = str(pd.Timestamp.now().floor("s"))
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(self.data, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, self.path)
        return self.path


def read_quality(data_dir) -> dict:
    """The per-day verdicts ({} before the first checked run)."""
    try:
        return json.loads((Path(data_dir) / QUALITY).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def suspect_days(data_dir) -> List[pd.Timestamp]:
    """Match_Investments days the quality check found incomplete: left out of panels, fits and scores."""
    days = read_quality(data_dir).get("days") or {}
    return sorted(pd.Timestamp(d) for d, r in days.items() if (r or {}).get("verdict") == "suspect")


def retry_days(data_dir, now, before=None) -> List[pd.Timestamp]:
    """Suspect and provisional days of the last RETRY_DAYS (before ``before``): extracted again every run."""
    lo = pd.Timestamp(now).normalize() - pd.Timedelta(days=RETRY_DAYS)
    hi = pd.Timestamp(before).normalize() if before is not None else pd.Timestamp(now).normalize() + pd.Timedelta(days=1)
    days = read_quality(data_dir).get("days") or {}
    return sorted(pd.Timestamp(d) for d, r in days.items()
                  if (r or {}).get("verdict") in ("suspect", "provisional") and lo <= pd.Timestamp(d) < hi)


# ------------------------------------------------------------------ every day on disk
def investment_days(data_dir) -> Dict[pd.Timestamp, Path]:
    folder = Path(data_dir) / "Match_Investments"
    out = {}
    for f in sorted(folder.glob("*.parquet")) if folder.is_dir() else []:
        m = _DAY_FILE.match(f.name)
        if m:
            out[pd.Timestamp(m.group(1))] = f
    return out


def _span(name: str) -> Optional[Tuple[pd.Timestamp, pd.Timestamp]]:
    """The first and last date a file name carries (YYYY-MM-DD or YYYYMMDD), or None."""
    found = []
    for y, m, d in _NAME_DATE.findall(name):
        try:
            found.append(pd.Timestamp(int(y), int(m), int(d)))
        except ValueError:
            continue
    return (min(found), max(found)) if found else None


def _pool_details(data_dir) -> Tuple[Optional[pd.DataFrame], List[Optional[Tuple[pd.Timestamp, pd.Timestamp]]]]:
    """conclude_date, pool_type and pool_id of every Pool_Details file that has them, and the spans of those
    that do not or cannot be read (a span None: its name does not say which days, so any day)."""
    import pyarrow.parquet as pq
    folder = Path(data_dir) / "Pool_Details"
    parts, gaps = [], []
    for f in sorted(folder.glob("*.parquet")) if folder.is_dir() else []:
        try:
            with open(f, "rb") as fh:                          # closed even when the file is not parquet
                pf = pq.ParquetFile(fh)
                names = pf.schema_arrow.names
                if "conclude_date" not in names:
                    gaps.append(_span(f.name))
                    continue
                parts.append(pf.read(columns=[c for c in ("pool_id", "pool_type", "conclude_date")
                                              if c in names]).to_pandas())
        except Exception as exc:                                         # noqa: BLE001
            logger.warning("Pool_Details %s not read (%s): the days it covers are judged without it", f.name, exc)
            gaps.append(_span(f.name))
    return (pd.concat(parts, ignore_index=True) if parts else None), gaps


def _uncounted(day, gaps) -> bool:
    """A Pool_Details file that may hold pools concluded on ``day`` was not read: their count is unknown."""
    d = pd.Timestamp(day).normalize()
    return any(g is None or g[0] - pd.Timedelta(days=2) <= d <= g[1] + pd.Timedelta(days=2) for g in gaps)


def check_days(data_dir, today=None, days: Optional[Iterable] = None) -> List[dict]:
    """Every Match_Investments day file on disk (or ``days`` of them) judged, oldest first, and saved.
    Numbers already in the book for an unchanged file (same size and time) are reused."""
    today = pd.Timestamp(today if today is not None else pd.Timestamp.now()).normalize()
    book = QualityBook(data_dir)
    files = investment_days(data_dir)
    want = sorted(files) if days is None else sorted(pd.Timestamp(d).normalize() for d in days
                                                     if pd.Timestamp(d).normalize() in files)
    details, gaps = _pool_details(data_dir)
    out = []
    for d in want:
        path = files[d]
        key = str(d.date())
        old = book.days.get(key) or {}
        st = path.stat()
        if old.get("bytes") == st.st_size and old.get("mtime") == float(st.st_mtime) and old.get("rows") is not None:
            stats = {k: old.get(k) for k in ("rows", "money", "pools", "bytes", "mtime")}
        else:
            stats = file_stats(path) or {"rows": 0, "money": 0.0, "pools": 0, "bytes": st.st_size,
                                         "mtime": float(st.st_mtime)}
        # the count from Pool_Details; where a file of it was not read, the one SQL gave at the extract (or none:
        # the day is judged on its money and rows against the days before it)
        expected = concluded_pools(details, d) if details is not None and not _uncounted(d, gaps) \
            else old.get("pools_expected")
        rec = judge(d, stats, book.days, today, expected)
        rec.update(bytes=stats.get("bytes"), mtime=stats.get("mtime"))
        out.append(book.record(rec))
    book.save()
    return out
