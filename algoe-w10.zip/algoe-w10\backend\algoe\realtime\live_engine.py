"""
Live Engine

Keeps a TG/SUP recommendation for every active match, refreshed at two
speeds, because the desk cannot wait five minutes after a goal and the box
cannot re-solve a hundred matches every fifteen seconds.

    SWEEP (every bucket boundary, all matches)
        fetch everything -> panel (same code as training) -> features
        -> bucket forecast F per selection (champion turnover pipeline)
        -> belief p per selection (champion calibration)
        -> optimise every match with enough expected money, richest first,
           inside a time budget, in parallel
    FOCUS (every ~15 s, only the matches the desk has open or a trigger fired on)
        fetch THAT match only -> latest odds, parameters, score, and the money
        already taken in the current bucket
        -> nowcast: remaining = rate x (5 - elapsed), rate from F and what has
           arrived (realtime/nowcast.py); the next bucket carries the surge
        -> belief re-read from the latest true odds
        -> re-optimise that match from its last answer (warm start, one start,
           each dimension limited to max_step from the last recommendation)

    TRIGGERS put a match into focus immediately: a goal or red card, a main-line
    price moving more than trigger_odds_move, or one minute's money exceeding
    trigger_big_bet_multiple times what the forecast expected for a minute.

A UI heartbeat keeps a match in focus (``focus_on``); without one the focus
lapses after focus_ttl_seconds, so a forgotten tab does not cost CPU forever.

Everything the engine publishes is also appended to the monitor's forecast
log, where the next sweep joins the money that actually arrived.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Days built with prepare_live; a price-move trigger resets after its refresh, a big-money
                trigger fires once per minute
"""

from __future__ import annotations

import heapq
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import KEY, LivePanelBuilder
from ..features.engineer import FeatureEngineer
from ..optimizer.theta_optimizer import DemandResponse, MatchDecision, ThetaOptimizer, build_books, publish_odds
from .nowcast import BucketNowcaster

logger = get_logger(__name__)


@dataclass
class MatchLive:
    match_id: int
    bucket: Optional[pd.Timestamp] = None
    forecast: Optional[pd.DataFrame] = None       # KEY + forecast for the current bucket (from the sweep)
    decision: Optional[MatchDecision] = None
    view: Optional[pd.DataFrame] = None           # per selection: odds now / star, belief, forecast, observed, remaining
    refreshed_at: Optional[pd.Timestamp] = None
    mode: str = "sweep"
    triggers: List[str] = field(default_factory=list)
    last_events: int = 0
    last_main_odds: Dict[tuple, float] = field(default_factory=dict)
    last_big_minute: Optional[pd.Timestamp] = None
    observed: float = 0.0
    remaining: float = 0.0
    hot: float = 1.0

    def summary(self) -> dict:
        d = self.decision
        return {"match_id": self.match_id, "bucket": str(self.bucket), "mode": self.mode,
                "refreshed_at": str(self.refreshed_at), "triggers": list(self.triggers),
                "status": d.status if d else "pending", "lift": d.lift if d else 0.0,
                "lift_bps": d.lift_bps if d else 0.0, "turnover": d.turnover if d else 0.0,
                "theta_now": d.theta_now if d else {}, "theta_star": d.theta_star if d else {},
                "observed_in_bucket": self.observed, "remaining_in_bucket": self.remaining,
                "hot": self.hot, "binding": d.binding if d else []}


class LiveEngine:
    def __init__(self, settings, source=None, forecaster=None, calibrator=None, monitor=None, clock=None):
        self.settings = settings
        self.source = source if source is not None else _default_source(settings)
        self.forecaster = forecaster
        self.calibrator = calibrator
        self.monitor = monitor
        self.engineer = forecaster.engineer if forecaster is not None else FeatureEngineer(settings)
        self.builder = LivePanelBuilder(settings)
        # The historical extraction has no HKJC true odds while the live feed does: a model trained without
        # them must see the price inputs it learned on (de-margined odds, Poisson), not new ones.
        coverage = (getattr(forecaster, "metadata", None) or {}).get("true_odds_coverage")
        if coverage is not None and np.isfinite(coverage) and coverage < 0.5:
            self.builder.ignore_true_odds = True
            logger.warning("the turnover model was trained with HKJC true odds on %.0f%% of rows; live true odds are "
                           "ignored so its inputs match. Re-extract history with true odds to use them.",
                           100 * coverage)
        self.optimizer = ThetaOptimizer(settings, DemandResponse.from_forecaster(forecaster, settings))
        self.nowcaster = forecaster.nowcaster if forecaster is not None else BucketNowcaster(
            settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes,
            max_hot=settings.live.nowcast_max_hot)
        self.clock = clock or (lambda: pd.Timestamp.now())
        self.matches: Dict[int, MatchLive] = {}
        self.focus: Dict[int, float] = {}
        self._queue: List[Tuple[float, int, str]] = []
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.last_sweep: dict = {}

    # ============================================================ interest
    def focus_on(self, match_id: int, ttl: Optional[float] = None) -> None:
        with self._lock:
            self.focus[int(match_id)] = time.time() + (ttl or self.settings.live.focus_ttl_seconds)

    def focus_off(self, match_id: int) -> None:
        with self._lock:
            self.focus.pop(int(match_id), None)

    def focused(self) -> List[int]:
        now = time.time()
        with self._lock:
            for m in [m for m, t in self.focus.items() if t < now]:
                self.focus.pop(m, None)
            return sorted(self.focus)

    def trigger(self, match_id: int, reason: str, priority: float = 1.0) -> None:
        with self._lock:
            heapq.heappush(self._queue, (-priority, int(match_id), reason))
            live = self.matches.setdefault(int(match_id), MatchLive(int(match_id)))
            live.triggers = (live.triggers + [reason])[-5:]
        logger.info("trigger match %s: %s", match_id, reason)

    # ================================================================ sweep
    def run_sweep(self, as_of=None) -> dict:
        as_of = pd.Timestamp(as_of or self.clock())
        started = time.time()
        snap = self.source.fetch(as_of)
        t_fetch = time.time() - started
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            self.last_sweep = {"as_of": str(as_of), "matches": 0, "note": "no active matches"}
            return self.last_sweep
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        t_feat = time.time() - started - t_fetch
        forecast = self._forecast(day)
        belief = self._belief(day)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        prev = {m: l.decision.theta_star for m, l in self.matches.items() if l.decision is not None}
        books = build_books(day.sel[now_rows], day.match, forecast[now_rows], belief[now_rows], self.settings,
                            theta_prev=prev)
        t_prep = time.time() - started - t_fetch - t_feat
        decisions = self.optimizer.optimize_card(books, mode="sweep")
        t_opt = time.time() - started - t_fetch - t_feat - t_prep
        sel_now = day.sel[now_rows]
        fc_now = pd.DataFrame({**{k: sel_now[k].to_numpy() for k in KEY + ["match_id", "pool_name"]},
                               "forecast": forecast[now_rows], "belief": belief[now_rows],
                               "odds": sel_now["odds"].to_numpy(dtype="float64")})
        with self._lock:
            for bk in books:
                live = self.matches.setdefault(bk.match_id, MatchLive(bk.match_id))
                live.bucket, live.mode, live.refreshed_at = current, "sweep", as_of
                live.forecast = fc_now[fc_now["match_id"] == bk.match_id].reset_index(drop=True)
                live.decision = decisions.get(bk.match_id)
                live.view = _view(bk, live.decision)
                live.observed, live.remaining, live.hot = 0.0, float(bk.total_demand), 1.0
                live.last_events = self._n_goal_red(extra["events"], bk.match_id)
                live.last_main_odds = _main_odds(bk)
        if self.monitor is not None:
            self.monitor.log_forecasts(current, fc_now, model=getattr(self.forecaster, "version", None))
        self.last_sweep = {"as_of": str(as_of), "bucket": str(current), "matches": len(books),
                           "solved": sum(1 for d in decisions.values() if d.status == "solved"),
                           "lift": float(sum(d.lift for d in decisions.values())),
                           "turnover": float(sum(d.turnover for d in decisions.values())),
                           "seconds": {"fetch": round(t_fetch, 2), "features": round(t_feat, 2),
                                       "books": round(t_prep, 2), "optimise": round(t_opt, 2),
                                       "total": round(time.time() - started, 2)}}
        logger.info("sweep %s: %d match(es), E[GM] lift %.0f on %.0f expected, %.1fs (%s)", current.strftime("%H:%M"),
                    len(books), self.last_sweep["lift"], self.last_sweep["turnover"],
                    self.last_sweep["seconds"]["total"], self.last_sweep["seconds"])
        return self.last_sweep

    def _forecast(self, day) -> np.ndarray:
        if self.forecaster is None:
            return day.sel["tv1"].to_numpy(dtype="float64")
        return self.forecaster.predict_selection_turnover(day)["forecast"].to_numpy(dtype="float64")

    def _belief(self, day) -> np.ndarray:
        if self.calibrator is None:
            return day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        p = self.calibrator.predict_for_day(day)
        raw = day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        return np.where(np.isfinite(p), p, raw)

    # ================================================================ focus
    def run_focus(self, match_id: int, as_of=None) -> Optional[MatchLive]:
        """Refresh one match mid-bucket: nowcast the rest of the bucket and re-optimise."""
        as_of = pd.Timestamp(as_of or self.clock())
        mid = int(match_id)
        started = time.time()
        snap = self.source.fetch(as_of, match_ids=[mid])
        snap = _only(snap, mid)
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            return self.matches.get(mid)
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        sel_now = day.sel[now_rows].reset_index(drop=True)
        live = self.matches.setdefault(mid, MatchLive(mid))
        # the bucket forecast comes from the sweep; a match first seen here forecasts on its own
        if live.forecast is None or live.bucket != current:
            F = self._forecast(day)[now_rows]
        else:
            F = sel_now[KEY].merge(live.forecast[KEY + ["forecast"]], on=KEY, how="left")["forecast"] \
                .fillna(0.0).to_numpy(dtype="float64")
        observed = _observed(snap.investments, sel_now, current, as_of)
        elapsed = max((as_of - current).total_seconds() - self.settings.live.data_lag_seconds, 0.0) / 60.0
        nc = self.nowcaster.update(F, observed, elapsed, match_key=sel_now["match_id"].to_numpy(), next_forecast=F)
        horizon = nc.remaining + nc.next_bucket
        belief = self._belief(day)[now_rows]
        prev = {mid: live.decision.theta_star} if live.decision is not None else None
        books = build_books(sel_now, day.match, horizon, belief, self.settings, theta_prev=prev)
        if not books:
            return live
        bk = books[0]
        dec = self.optimizer.optimize_match(bk, mode="focus")
        with self._lock:
            live.bucket, live.mode, live.refreshed_at = current, "focus", as_of
            live.decision = dec
            live.view = _view(bk, dec)
            live.observed = float(observed.sum())
            live.remaining = float(nc.remaining.sum())
            live.hot = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
            # the move that triggered this refresh has now been priced in
            live.last_main_odds = _main_odds(bk)
            events_now = self._n_goal_red(extra["events"], mid)
            if events_now > live.last_events:
                live.triggers = (live.triggers + ["event x{}".format(events_now - live.last_events)])[-5:]
            live.last_events = events_now
        logger.info("focus %s @%s: observed %.0f, remaining %.0f (hot x%.2f), lift %.1f, %s in %.2fs",
                    mid, as_of.strftime("%H:%M:%S"), live.observed, live.remaining, live.hot, dec.lift, dec.status,
                    time.time() - started)
        return live

    # ============================================================ triggers
    def check_triggers(self, as_of=None) -> List[Tuple[int, str]]:
        """Cheap scan of the whole card for events, price jumps and big bets since the last look."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        snap = self.source.fetch(as_of)
        fired = []
        ev = self.builder._canon("events", snap.events)
        odds = self.builder._canon("odds", snap.odds)
        inv = self.builder._canon("investments", snap.investments)
        for mid, live in list(self.matches.items()):
            if "goal" in lv.trigger_events or "red" in lv.trigger_events:
                n = self._n_goal_red(ev, mid)
                if n > live.last_events:
                    fired.append((mid, "goal/red card"))
            if live.last_main_odds and not odds.empty:
                o = odds[odds["match_id"] == mid].sort_values("effective_datetime").groupby(
                    ["pool_id", "line_id", "combination_id"]).last()["odds"]
                for k, v0 in live.last_main_odds.items():
                    v1 = o.get(k)
                    if v1 is not None and v0 > 0 and abs(v1 / v0 - 1.0) > lv.trigger_odds_move:
                        fired.append((mid, "main-line price moved {:+.0%}".format(v1 / v0 - 1.0)))
                        break
            since = as_of.floor("min") - pd.Timedelta(minutes=1)
            if live.forecast is not None and not inv.empty and live.last_big_minute != since:
                minute = inv[(inv["match_id"] == mid) & (inv["start_sell_time"] >= since)]
                per_min = float(live.forecast["forecast"].sum()) / self.settings.panel.bucket_minutes
                if per_min > 0 and float(minute["turnover"].sum()) > lv.trigger_big_bet_multiple * per_min:
                    live.last_big_minute = since
                    fired.append((mid, "big money: {:.0f} in a minute vs {:.0f} expected".format(
                        float(minute["turnover"].sum()), per_min)))
        for mid, reason in fired:
            self.trigger(mid, reason, priority=2.0)
        return fired

    @staticmethod
    def _n_goal_red(events: pd.DataFrame, mid: int) -> int:
        if events is None or events.empty or "incident_type" not in events.columns:
            return 0
        e = events[pd.to_numeric(events["match_id"], errors="coerce") == mid]
        t = pd.to_numeric(e["incident_type"], errors="coerce")
        if "provider_id" in e.columns and len(e):
            best = e.assign(t=t)[t.isin([27, 57, 79])].groupby("provider_id").size()
            return int(best.max()) if len(best) else 0
        return int(t.isin([27, 57, 79]).sum())

    # ================================================================ loop
    def step(self, as_of=None) -> dict:
        """One scheduler tick: sweep at a new bucket, then focus refreshes that are due."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        done = {"sweep": None, "focus": []}
        bucket = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        if not self.last_sweep or self.last_sweep.get("bucket") != str(bucket):
            done["sweep"] = self.run_sweep(as_of)
        due = []
        with self._lock:
            while self._queue:
                _, mid, reason = heapq.heappop(self._queue)
                if mid not in due:
                    due.append(mid)
        for mid in self.focused():
            live = self.matches.get(mid)
            last = live.refreshed_at if live else None
            if last is None or (as_of - last).total_seconds() >= lv.focus_interval_seconds:
                if mid not in due:
                    due.append(mid)
        for mid in due[: lv.max_focus_matches]:
            try:
                self.run_focus(mid, as_of)
                done["focus"].append(mid)
            except Exception as exc:                                   # noqa: BLE001
                logger.exception("focus refresh of match %s failed: %s", mid, exc)
        return done

    def start(self, poll_seconds: float = 1.0) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def loop():
            logger.info("live engine started (source %s)", type(self.source).__name__)
            last_scan = 0.0
            while not self._stop.is_set():
                try:
                    if time.time() - last_scan > self.settings.live.focus_interval_seconds:
                        self.check_triggers()
                        last_scan = time.time()
                    self.step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live step failed: %s", exc)
                self._stop.wait(poll_seconds)
            logger.info("live engine stopped")
        self._thread = threading.Thread(target=loop, name="algoe-live", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=10)

    # ================================================================ read
    def board(self) -> dict:
        with self._lock:
            rows = [m.summary() for m in self.matches.values()]
        rows.sort(key=lambda r: -r["turnover"])
        return {"last_sweep": self.last_sweep, "focused": self.focused(), "matches": rows}

    def match_view(self, match_id: int) -> dict:
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None:
                return {"match_id": int(match_id), "status": "unknown"}
            view = live.view.to_dict("records") if live.view is not None else []
            return {**live.summary(), "selections": view,
                    "per_pool": live.decision.per_pool if live.decision else []}


# ---------------------------------------------------------------- helpers
def _default_source(settings):
    if settings.live.source == "replay":
        from ..data.replay import ReplaySource
        return ReplaySource(settings)
    from src.hkjc.source import get_source
    return get_source(settings.live.source)


def _only(snap, mid: int):
    """Keep one match's rows; the simulator ignores match_ids, SQL and replay honour it."""
    for name in ("active_pools", "match_info", "params", "params_history", "events", "odds", "market", "investments"):
        frame = getattr(snap, name, None)
        if frame is not None and not frame.empty and "match_id" in frame.columns:
            setattr(snap, name, frame[pd.to_numeric(frame["match_id"], errors="coerce") == mid])
        elif frame is not None and not frame.empty and name == "match_info":
            col = next((c for c in ("MatchId", "match_id") if c in frame.columns), None)
            if col:
                setattr(snap, name, frame[pd.to_numeric(frame[col], errors="coerce") == mid])
    return snap


def _observed(investments: pd.DataFrame, sel: pd.DataFrame, bucket, as_of) -> np.ndarray:
    """Money each selection has taken since the bucket started."""
    if investments is None or investments.empty:
        return np.zeros(len(sel))
    inv = LivePanelBuilder._canon("investments", investments)
    inv = inv[(inv["start_sell_time"] >= bucket) & (inv["start_sell_time"] <= as_of)]
    if inv.empty:
        return np.zeros(len(sel))
    for c in KEY:
        inv[c] = pd.to_numeric(inv[c], errors="coerce").fillna(-1).astype("int64")
    got = inv.groupby(KEY)["turnover"].sum()
    idx = pd.MultiIndex.from_frame(sel[KEY].astype("int64"))
    return got.reindex(idx).fillna(0.0).to_numpy(dtype="float64")


def _main_odds(book) -> Dict[tuple, float]:
    if book.keys is None:
        return {}
    out = {}
    for i in np.flatnonzero(book.is_main):
        k = book.keys.iloc[i]
        out[(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"]))] = float(book.odds_now[i])
    return out


def _view(book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    v = book.keys.copy() if book.keys is not None else pd.DataFrame(index=range(book.n))
    v["line"] = book.rows.line
    v["side"] = book.rows.side
    v["odds_now"] = book.odds_now
    v["belief"] = book.p_true
    v["demand"] = book.demand
    if dec is not None and dec.odds_star is not None:
        v["odds_star"] = dec.odds_star
        v["odds_star_ladder"] = publish_odds(dec.odds_star)
        v["demand_star"] = dec.demand_star
    return v
