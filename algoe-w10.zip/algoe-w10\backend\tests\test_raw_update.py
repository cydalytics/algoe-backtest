"""
Raw_Data update tests - the plan, the notebook's SQL, one file at a time, the caches, the lock, the status

    python tests/test_raw_update.py            plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_raw_update.py

No SQL: a fake reader stands in for the HKJC servers.

Change Log:
-----------
2026-10-26      Initialize
"""

import json
import os
import sys
import tempfile
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

NOW = pd.Timestamp("2026-10-26 19:00")
# table -> (folder, file prefix, the column the notebook's window is on)
MONTHLY = {"odds": ("HKJC_Odds", "hkjc_odds", "effective_datetime"),
           "market": ("Market_Odds", "market_odds", "effective_datetime"),
           "params": ("HKJC_Parameters", "hkjc_parameters", "EventTime"),
           "matches": ("Match_Information", "match_information", "KOTime"),
           "events": ("Match_Events", "match_events", "incident_datetime"),
           "pools": ("Pool_Details", "pool_details", "kickoff_date")}


def _frame(col, lo, hi, n=6):
    return pd.DataFrame({"match_id": range(n), "pool_id": range(n), col: pd.date_range(lo, hi, periods=n)})


def _raw(root: Path, newest="2026-10-01 00:00"):
    """Raw_Data as the notebook leaves it: August and September files, investments to 30 September."""
    for folder, prefix, col in MONTHLY.values():
        (root / folder).mkdir(parents=True)
        _frame(col, "2026-08-01", "2026-08-31 23:00").to_parquet(root / folder / "{}_2026-08_2026-09.parquet".format(prefix))
        _frame(col, "2026-09-01", newest).to_parquet(root / folder / "{}_2026-09_2026-10.parquet".format(prefix))
    inv = root / "Match_Investments"
    inv.mkdir()
    for d in pd.date_range("2026-09-28", "2026-09-30"):
        hi = d + pd.Timedelta(hours=23) if d < pd.Timestamp("2026-09-30") else pd.Timestamp(newest)
        _frame("start_sell_time", d, hi).to_parquet(
            inv / "match_investments_{:%Y-%m-%d}_{:%Y-%m-%d}.parquet".format(d, d + pd.Timedelta(days=1)))
    return root


class FakeReader:
    """Rows for any job, stamped inside its window and never after NOW; ``fail`` names jobs that raise."""

    def __init__(self, fail=(), empty=()):
        self.fail, self.empty, self.asked = set(fail), set(empty), []

    def read(self, job):
        self.asked.append(job.path.name)
        if job.path.name in self.fail:
            raise RuntimeError("SQL Server went away")
        if job.path.name in self.empty:
            return pd.DataFrame()
        col = MONTHLY[job.table][2] if job.table in MONTHLY else "start_sell_time"
        hi = min(job.end - pd.Timedelta(minutes=1), NOW - pd.Timedelta(hours=1))
        return _frame(col, job.start, max(hi, job.start))


# ------------------------------------------------------------------ the plan
def test_plan_restarts_the_day_before_the_newest():
    from src.backtest.parquet.raw_update import plan
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        (root / "HKJC_Odds" / "odds_by_hand.parquet").write_bytes(
            (root / "HKJC_Odds" / "hkjc_odds_2026-09_2026-10.parquet").read_bytes())
        p = plan(root, now=NOW)
        forced = plan(root, now=NOW, start="2026-09-15")
    assert p.restart == pd.Timestamp("2026-09-30"), p.restart
    assert all(v == pd.Timestamp("2026-10-01") for v in p.newest_day.values()), p.newest_day
    monthly = sorted(j.path.name for j in p.jobs if j.table == "odds")
    assert monthly == ["hkjc_odds_2026-09_2026-10.parquet", "hkjc_odds_2026-10_2026-11.parquet"], monthly
    for table, (folder, prefix, _) in MONTHLY.items():
        names = {j.path.name for j in p.jobs if j.table == table}
        assert names == {"{}_2026-09_2026-10.parquet".format(prefix), "{}_2026-10_2026-11.parquet".format(prefix)}, table
    days = sorted(j.path.name for j in p.jobs if j.table == "investments")
    assert days[0] == "match_investments_2026-09-30_2026-10-01.parquet" and len(days) == 27, days[:2]
    assert days[-1] == "match_investments_2026-10-26_2026-10-27.parquet"
    assert [Path(f).name for f in p.foreign] == ["odds_by_hand.parquet"]     # read twice if left in place
    assert forced.restart == pd.Timestamp("2026-09-15") and len([j for j in forced.jobs if j.table == "investments"]) == 42


def test_the_sql_is_the_notebooks():
    from src.hkjc import history_queries as Q
    a, b = "2026-09-01", "2026-10-01"
    assert "from [dbo].[pool_event_leg_c] e with(nolock)" in Q.month_sql("odds", a, b)
    assert "where o.effective_datetime between '2026-09-01' and '2026-10-01' and e.is_deleted = 0" in Q.month_sql("odds", a, b)
    assert "left join [dbo].[pool_odds_external_change_c] o with(nolock)" in Q.month_sql("market", a, b)
    assert "where o.effective_datetime between '2026-09-01' and '2026-10-01'" in Q.month_sql("market", a, b)
    assert "select * from [QFM].[dbo].[algo_param]" in Q.month_sql("params", a, b)
    assert "where EventTime between '2026-09-01' and '2026-10-01'" in Q.month_sql("params", a, b)
    assert "where m.start_datetime between '2026-09-01' and '2026-10-01'" in Q.month_sql("matches", a, b)
    assert "WHERE [incident_datetime] between '2026-09-01' and '2026-10-01'" in Q.month_sql("events", a, b)
    assert "FROM [bis1_fbuser_db].[dbo].[G2_pool_details]" in Q.month_sql("pools", a, b)
    assert "WHERE [kickoff_date] between '2026-09-01' and '2026-10-01'" in Q.month_sql("pools", a, b)
    setup = Q.investments_setup_sql("2026-09-30", "2026-10-01")
    assert "and conclude_date between '2026-09-30' and '2026-10-01'" in setup
    assert "[fbis1_fo_as_db]..c_account_ord_fo_selections" in setup and "[fbis1_fo_cs_db].dbo.c_cash_ord_sales_payout" in setup
    assert Q.investments_databases("2025-08-15") == ("fbis_fo_as_202507_202508", "fbis_fo_cs_202507_202508")
    assert Q.investments_databases("2026-10-26") == ("fbis1_fo_as_db", "fbis1_fo_cs_db")
    assert Q.CONNECTION["odds"] == "qfm" and Q.CONNECTION["params"] == "bis" and Q.CONNECTION["investments"] == "bis"
    assert set(Q.PARSE_DATES) == set(MONTHLY) | {"investments"}


# --------------------------------------------------------------- the files
def test_a_failed_query_keeps_the_old_file():
    from src.backtest.parquet.raw_update import plan, run
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        old = root / "HKJC_Odds" / "hkjc_odds_2026-09_2026-10.parquet"
        before = old.read_bytes()
        p = plan(root, now=NOW)
        out = run(p, FakeReader(fail={"hkjc_odds_2026-09_2026-10.parquet"},
                                empty={"match_events_2026-10_2026-11.parquet"}))
        after = old.read_bytes()
        left = sorted(x.name for x in root.rglob("*") if x.name.endswith(".tmp"))
        oct_odds = (root / "HKJC_Odds" / "hkjc_odds_2026-10_2026-11.parquet").exists()
        no_events = not (root / "Match_Events" / "match_events_2026-10_2026-11.parquet").exists()
        status = json.loads((root / "_algoe_update.json").read_text(encoding="utf-8"))
    assert before == after and not left and oct_odds and no_events
    bad = [r for r in out["files"] if not r["ok"]]
    assert [r["file"] for r in bad] == ["HKJC_Odds/hkjc_odds_2026-09_2026-10.parquet"] and "went away" in bad[0]["error"]
    assert out["ok"] is False and status["ok"] is False and status["restart"] == "2026-09-30"


def test_a_good_run_writes_the_status_and_the_newest_day():
    from src.backtest.parquet.raw_update import is_stale, newest_complete_day, plan, read_status, run
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        out = run(plan(root, now=NOW), FakeReader())
        status = read_status(root)
        end = newest_complete_day(root, today=pd.Timestamp("2026-10-27"))
        none = read_status(Path(tmp) / "nowhere")
    assert out["ok"] and status["ok"] and status["newest_day"] == "2026-10-26", status.get("newest_day")
    assert status["files_written"] == len([r for r in out["files"] if r["rows"]]) and end == pd.Timestamp("2026-10-26")
    assert not is_stale(status, today=pd.Timestamp("2026-10-27"))
    assert is_stale(status, today=pd.Timestamp("2026-10-28"))         # newest is before yesterday
    assert is_stale(dict(status, ok=False), today=pd.Timestamp("2026-10-27"))
    assert none is None and is_stale(None, today=pd.Timestamp("2026-10-27"))


def test_the_lock_stops_a_second_run_and_a_stale_one_is_taken_over():
    from src.backtest.parquet.raw_update import Lock, UpdateLocked
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        with Lock(root):
            try:
                with Lock(root):
                    raise AssertionError("two updates ran at once")
            except UpdateLocked as exc:
                assert "running" in str(exc)
        assert not (root / "_algoe_update.lock").exists()
        (root / "_algoe_update.lock").write_text("pid 1", encoding="utf-8")
        old = time.time() - 7 * 3600
        os.utime(root / "_algoe_update.lock", (old, old))
        with Lock(root):
            pass


# -------------------------------------------------------------- the caches
def test_cached_days_from_the_restart_are_dropped_from_every_space():
    from src.backtest.parquet.cache import drop_days_from
    days = ["2026-09-28", "2026-09-29", "2026-09-30", "2026-10-01", "2026-10-02"]
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "algoe_panel_cache"
        for space in ("aaaa11112222", "bbbb33334444"):
            (root / space / "panel").mkdir(parents=True)
            (root / space / "scores" / "v3").mkdir(parents=True)
            (root / space / "opt_v2").mkdir(parents=True)
            for d in days:
                (root / space / "panel" / "{}.parquet".format(d)).write_bytes(b"x")
                (root / space / "scores" / "v3" / "{}.pkl".format(d)).write_bytes(b"x")
                (root / space / "opt_v2" / "{}.parquet".format(d)).write_bytes(b"x")
            (root / space / "manifest.json").write_text(json.dumps(
                {"engine": 1, "days": {d: {"rows": 5} for d in days}}), encoding="utf-8")
        n = drop_days_from(root, "2026-09-30")
        kept = {s.name: sorted(json.loads((s / "manifest.json").read_text(encoding="utf-8"))["days"])
                for s in root.iterdir()}
        files = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.suffix != ".json")
    assert n == 6, n                                                    # three days in each of two spaces
    assert all(v == ["2026-09-28", "2026-09-29"] for v in kept.values()), kept
    assert all(any(d in f for d in ("2026-09-28", "2026-09-29")) for f in files), files


def test_the_sql_matches_the_notebook_text():
    """Every query, whitespace aside, is the notebook's; skipped where hkjc_code is not beside the repo."""
    import re
    from src.hkjc import history_queries as Q
    nb = Path(__file__).resolve().parents[4] / "hkjc_code" / "1 Data Extraction.ipynb"
    if not nb.exists():
        return
    blocks = re.findall(r'f"""(.*?)"""', nb.read_text(encoding="utf-8"), flags=re.S)
    fill = {"{start_yyyymm}": "2026-09", "{end_yyyymm}": "2026-10", "{start_date}": "2026-09-30",
            "{end_date}": "2026-10-01", "{as_db}": "fbis1_fo_as_db", "{cs_db}": "fbis1_fo_cs_db"}

    def norm(s):
        for k, v in fill.items():
            s = s.replace(k, v)
        return " ".join(s.split())
    theirs = [norm(b) for b in blocks]
    ours = {t: norm(Q.month_sql(t, "2026-09-01", "2026-10-01")) for t in Q.MONTHLY}
    ours["investments setup"] = norm(Q.investments_setup_sql("2026-09-30", "2026-10-01"))
    ours["investments select"] = norm(Q.INVESTMENTS_SELECT)
    missing = [name for name, sql in ours.items() if sql not in theirs]
    assert not missing, missing


def test_a_failed_write_or_replace_keeps_the_old_file():
    from src.backtest.parquet import raw_update as U
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "HKJC_Odds" / "hkjc_odds_2026-10_2026-11.parquet"
        path.parent.mkdir()
        _frame("effective_datetime", "2026-10-01", "2026-10-02").to_parquet(path)
        before = path.read_bytes()
        new = _frame("effective_datetime", "2026-10-01", "2026-10-20")
        real = os.replace
        for broken in ("write", "replace"):
            try:
                if broken == "write":
                    U.write_atomic(new.assign(effective_datetime=object()), path)   # pyarrow cannot write it
                else:
                    os.replace = lambda a, b: (_ for _ in ()).throw(PermissionError("share went away"))
                    U.write_atomic(new, path)
                raise AssertionError("no error on a broken " + broken)
            except AssertionError:
                raise
            except Exception:                                           # noqa: BLE001
                pass
            finally:
                os.replace = real
            assert path.read_bytes() == before, broken
            assert not list(path.parent.glob("*.tmp")), broken


def test_a_table_with_no_files_or_a_foreign_overlap_stops_the_run():
    from src.backtest.parquet.raw_update import ForeignFiles, plan
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")
        for f in (root / "Market_Odds").glob("*.parquet"):
            f.unlink()
        try:
            plan(root, now=NOW)
            raise AssertionError("a table with no files was planned from the others")
        except ValueError as exc:
            assert "Market_Odds" in str(exc) and "--from" in str(exc)
        assert plan(root, now=NOW, start="2026-09-30").restart == pd.Timestamp("2026-09-30")
        root2 = _raw(Path(tmp) / "Raw_Data2")
        (root2 / "HKJC_Odds" / "notes.parquet").write_bytes(b"not a parquet file")   # bounds unknown
        p = plan(root2, now=NOW)
        assert "HKJC_Odds/notes.parquet" in p.foreign
        try:
            p.check_foreign()
            raise AssertionError("ran with a file whose rows would be read twice")
        except ForeignFiles as exc:
            assert "notes.parquet" in str(exc)
        p.check_foreign(allow=True)


def test_a_file_without_statistics_is_read_by_its_name():
    from src.backtest.parquet import raw_update as U
    path = Path("HKJC_Odds") / "hkjc_odds_2026-09_2026-10.parquet"
    real = U._file_time_bounds
    U._file_time_bounds = lambda p, c: None
    try:
        assert U._bounds(path, "odds") == (pd.Timestamp("2026-09-01"), pd.Timestamp("2026-10-01"))
    finally:
        U._file_time_bounds = real


def test_the_lock_beats_while_held_and_only_its_owner_frees_it():
    from src.backtest.parquet.raw_update import LOCK, Lock, UpdateLocked
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        lock = root / LOCK
        with Lock(root, beat_seconds=0.05):
            first = lock.stat().st_mtime
            old = time.time() - 3600
            os.utime(lock, (old, old))
            time.sleep(0.3)
            assert lock.stat().st_mtime > old + 3000, "no heartbeat"      # a long run stays fresh
            lock.write_text("someone else", encoding="utf-8")             # taken over by another run
        assert lock.exists() and lock.read_text(encoding="utf-8") == "someone else"   # not ours to delete
        lock.unlink()
        assert first > 0
        holder = Lock(root, beat_seconds=60)
        holder.__enter__()
        t0 = time.time()
        try:
            with Lock(root, wait_seconds=0.4):
                raise AssertionError("got a lock that was held")
        except UpdateLocked:
            assert time.time() - t0 >= 0.35                               # it waited before giving up
        holder.__exit__(None, None, None)
        with Lock(root, wait_seconds=0.4):
            pass


def test_dropping_days_rewrites_the_manifest_first_and_reports_files_it_cannot_delete():
    import stat
    from src.backtest.parquet.cache import drop_days_from
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "algoe_panel_cache"
        (root / "s1" / "panel").mkdir(parents=True)
        for d in ("2026-09-29", "2026-09-30", "2026-10-01"):
            (root / "s1" / "panel" / "{}.parquet".format(d)).write_bytes(b"x")
        (root / "s1" / "manifest.json").write_text(json.dumps(
            {"days": {d: {"rows": 0 if d == "2026-10-01" else 5} for d in ("2026-09-29", "2026-09-30", "2026-10-01")}}),
            encoding="utf-8")
        stuck = root / "s1" / "panel" / "2026-09-30.parquet"
        os.chmod(stuck, stat.S_IREAD)                                     # Windows: cannot be deleted
        try:
            out = drop_days_from(root, "2026-09-30", report=True)
            days = json.loads((root / "s1" / "manifest.json").read_text(encoding="utf-8"))["days"]
        finally:
            os.chmod(stuck, stat.S_IWRITE | stat.S_IREAD)
    assert sorted(days) == ["2026-09-29"], days                           # the empty day is gone too
    assert out["dropped"] == 2 and [Path(f).name for f in out["kept"]] == ["2026-09-30.parquet"], out


# --------------------------------------------------------- the workbench
def test_the_workbench_opens_on_the_newest_day():
    from src.api.routes import parquet as routes
    from src.backtest.parquet.raw_update import write_status
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "Raw_Data"
        root.mkdir()
        write_status(root, {"ok": True, "newest_day": "2026-10-20"})
        old = os.environ.get("ALGOE_DATA_DIR")
        os.environ["ALGOE_DATA_DIR"] = str(root)
        try:
            d = routes.defaults()
        finally:
            if old is None:
                os.environ.pop("ALGOE_DATA_DIR", None)
            else:
                os.environ["ALGOE_DATA_DIR"] = old
    assert d["end"] == "2026-10-20" and d["data_dir"] == str(root), (d["end"], d["data_dir"])


def test_before_any_update_the_newest_day_comes_from_the_investment_files():
    from src.backtest.parquet.raw_update import newest_complete_day
    with tempfile.TemporaryDirectory() as tmp:
        root = _raw(Path(tmp) / "Raw_Data")                               # the notebook's files, no status yet
        assert newest_complete_day(root, today=pd.Timestamp("2026-10-27")) == pd.Timestamp("2026-09-30")


def test_the_update_command_end_to_end_with_a_fake_server():
    """python -m algoe update-data on a fake SQL reader: the files, the caches, the status, the exit code."""
    from algoe import cli
    from src.backtest.parquet import raw_update as U
    real = U.SqlReader
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:    # the run's log stays open
        root = _raw(Path(tmp) / "Raw_Data")
        work = Path(tmp) / "work"
        (Path(tmp) / "algoe_panel_cache" / "s1" / "panel").mkdir(parents=True)
        (Path(tmp) / "algoe_panel_cache" / "s1" / "panel" / "2026-10-05.parquet").write_bytes(b"x")
        (Path(tmp) / "algoe_panel_cache" / "s1" / "manifest.json").write_text(
            json.dumps({"days": {"2026-10-05": {"rows": 3}, "2026-09-01": {"rows": 3}}}), encoding="utf-8")
        common = ["--data-dir", str(root), "--work-dir", str(work), "--log-level", "ERROR"]
        try:
            U.SqlReader = lambda: FakeReader()
            ok = cli.main(["update-data", "--no-build"] + common)
            status_ok = U.read_status(root)
            kept = json.loads((Path(tmp) / "algoe_panel_cache" / "s1" / "manifest.json").read_text(encoding="utf-8"))
            reported = []
            cli_report_window = cli._report_window
            cli._report_window = lambda *a, **k: reported.append(1) or (None, None, "not reached")
            U.SqlReader = lambda: FakeReader(fail={"hkjc_odds_2026-10_2026-11.parquet"})
            bad = cli.main(["update-data", "--no-build", "--report"] + common)
            cli._report_window = cli_report_window
            status_bad = U.read_status(root)
        finally:
            U.SqlReader = real
    assert ok == 0 and status_ok["ok"] and status_ok["caches"]["panel"] == 1 and not status_ok.get("running")
    assert sorted(kept["days"]) == ["2026-09-01"]                         # 5 October dropped, 1 September kept
    assert bad == 1 and status_bad["ok"] is False and not reported        # no report on half-updated data


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
