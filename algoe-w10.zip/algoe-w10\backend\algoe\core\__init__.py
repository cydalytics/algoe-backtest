"""Cross-cutting building blocks: logging, validation, taxonomy, calendar, io."""
