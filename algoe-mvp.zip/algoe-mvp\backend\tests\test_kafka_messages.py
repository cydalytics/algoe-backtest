"""
Kafka message tests - the publish message and the engine's reply, on the samples

    python tests/test_kafka_messages.py        plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_kafka_messages.py

The fixtures are transcribed from the screenshots of 2026-10-29: params_message.json byte for byte,
prices_message.json up to HHAD +2, where the screenshot ends. Replace them with the raw text when
the Kafka owner sends it.

Change Log:
-----------
2026-10-29      Initialize
"""

import copy
import json
import math
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "kafka"
SAMPLE_THETA = {"goal_tg": 1.5, "goal_sup": 0.13, "corner_tg": 8.0, "corner_sup": 0.3}
SAMPLE_WEIGHTS = [("HAD", float("nan"), "H", 1.05), ("HAD", float("nan"), "A", 0.95), ("HAD", float("nan"), "D", 1.0),
                  ("HILO", 2.5, "H", 1.08), ("HILO", 2.5, "L", 0.92)]


def _km():
    from src.hkjc import kafka_messages
    return kafka_messages


def _sample_message(**kw):
    km = _km()
    args = dict(event_id=50063165, msg_id="MMSG_100", ts=pd.Timestamp("2026-07-22 17:20:12"), theta=SAMPLE_THETA,
                draw_factor=1.07, weights_rows=SAMPLE_WEIGHTS, game_state="FirstHalf", mapping=km.load_mapping())
    args.update(kw)
    return km.build_params_message(**args)


def _reply():
    return json.loads((FIXTURES / "prices_message.json").read_text(encoding="utf-8"))


# ---------------------------------------------------------------- publish
def test_params_message_is_the_sample_byte_for_byte():
    msg, notes = _sample_message()
    assert _km().encode(msg) == (FIXTURES / "params_message.json").read_text(encoding="utf-8").strip()
    assert notes == []


def test_unknown_pool_and_label_are_listed_not_sent():
    rows = SAMPLE_WEIGHTS + [("CRS", float("nan"), "1:0", 1.02), ("HILO", 3.5, "X", 1.01)]
    msg, notes = _sample_message(weights_rows=rows)
    assert [p["PoolType"] for p in msg["PoolWeightings"]] == [0, 1]
    assert any("CRS" in n for n in notes) and any("'X'" in n for n in notes)


def test_unknown_game_state_refuses_the_message():
    km = _km()
    try:
        _sample_message(game_state="Penalties")
    except km.MappingError as exc:
        assert "Penalties" in str(exc)
    else:
        raise AssertionError("an unmapped GameState must refuse the message")


def test_production_needs_confirmed_entries():
    km = _km()
    try:
        _sample_message(require_confirmed=True)
    except km.MappingError as exc:
        text = str(exc)
        assert "HAD" in text and "FirstHalf" in text and "draw_factor" in text
    else:
        raise AssertionError("the shipped mapping is unconfirmed: shadow / live must refuse it")
    mapping = km.load_mapping()
    for entry in list(mapping.pool_types.values()) + list(mapping.game_states.values()):
        entry["confirmed"] = True
    mapping.draw_factor["confirmed"] = mapping.tg_in_play["confirmed"] = True
    msg, _ = _sample_message(mapping=mapping, require_confirmed=True)
    assert msg["GameState"] == 2


def test_rounding_and_no_negative_zero():
    theta = {"goal_tg": 2.6449, "goal_sup": -0.004, "corner_tg": 9.999, "corner_sup": 0.125}
    msg, _ = _sample_message(theta=theta, draw_factor=1.0, weights_rows=[("HAD", float("nan"), "H", 1.0149)])
    p = msg["TgsupParameters"]
    assert (p["GoalTg"], p["CornerTg"], p["CornerSup"], p["DrawFactor"]) == (2.64, 10.0, 0.12, 0.0)
    assert '"GoalSup":0.0' in _km().encode(msg) and "-0.0" not in _km().encode(msg)
    assert msg["PoolWeightings"][0]["Selections"] == [{"SelectionId": 0, "Weight": 1.01}]


def test_non_finite_values_are_refused():
    km = _km()
    for kw in ({"theta": dict(SAMPLE_THETA, goal_sup=float("nan"))}, {"draw_factor": None},
               {"weights_rows": [("HAD", float("nan"), "H", float("inf"))]},
               {"weights_rows": [("HAD", float("nan"), "H", 0.0)]}):
        try:
            _sample_message(**kw)
        except km.MessageError:
            continue
        raise AssertionError("refused nothing for {}".format(kw))


def test_tg_in_play_full_match_conversion_round_trips():
    km = _km()
    mapping = km.load_mapping()
    theta = {"goal_tg": 1.2, "goal_sup": 0.3, "corner_tg": 4.0, "corner_sup": -0.6}
    assert km.engine_theta(theta, 30.0, True, mapping) == {"GoalTg": 1.2, "GoalSup": 0.3, "CornerTg": 4.0,
                                                            "CornerSup": -0.6}
    mapping.tg_in_play["semantics"] = "full_match"
    sent = km.engine_theta(theta, 30.0, True, mapping)
    assert math.isclose(sent["GoalTg"], 1.8) and math.isclose(sent["CornerSup"], -0.9)
    back = km.theta_from_engine(sent, 30.0, True, mapping)
    assert all(math.isclose(back[k], theta[k]) for k in theta)
    assert km.engine_theta(theta, 0.0, False, mapping)["GoalTg"] == 1.2       # pre-match: the same either way


def test_draw_factor_scale_round_trips():
    km = _km()
    mapping = km.load_mapping()
    assert km.engine_draw_factor(1.07, mapping) == 0.07
    assert math.isclose(km.draw_factor_from_engine(0.07, mapping), 1.07)


# ----------------------------------------------------------------- reply
def test_parse_reads_every_selection_of_the_sample():
    km = _km()
    r = km.parse_prices_message((FIXTURES / "prices_message.json").read_text(encoding="utf-8"), km.load_mapping())
    assert (r.server_app_id, r.event_id, r.game_state, r.stage) == ("E-HV11-01", 50075870, "FirstHalf", "FirstHalf90")
    assert r.clock_seconds == 42 and r.clock_set is True and r.calculation_id == 0
    assert r.event_time == pd.Timestamp("2026-10-27 16:24:45.639")          # UTC 08:24 is Hong Kong 16:24
    frame = r.frame()
    assert frame["pool_type"].nunique() == 7 and len(frame.groupby(["pool_id", "line_id"])) == 34 and len(frame) == 73
    h = frame[(frame["pool_type"] == "HAD") & (frame["label"] == "H")].iloc[0]
    assert (h["pool_id"], h["line_id"], h["combination_id"], h["weight"]) == (1934250001, 0, 1, 1.05)
    assert h["true_odds"] == 2.95003 and h["sell_odds"] == 1.001 and not h["offered"]
    q = frame[(frame["pool_type"] == "HILO") & (frame["line_label"] == "2.5/3")]
    assert set(q["line_value"]) == {2.75} and q["offered"].all()
    fhad = frame[frame["pool_type"] == "FHAD"]
    assert math.isclose(fhad["margin"].iloc[0], (1.0 / fhad["sell_odds"]).sum(), abs_tol=1e-4)


def test_parse_errors_name_the_field():
    km = _km()
    mapping = km.load_mapping()
    bad = _reply()
    del bad["MapResult"]["Pools"][2]["Lines"][1]["Combinations"][0]["TrueOdds"]
    worse = _reply()
    worse["MapResult"]["Pools"][0]["PoolId"] = "1934250001x"
    for raw, path in ((bad, "MapResult.Pools[2].Lines[1].Combinations[0].TrueOdds"),
                      (worse, "MapResult.Pools[0].PoolId"), ("{not json", "not JSON")):
        try:
            km.parse_prices_message(raw if isinstance(raw, str) else json.dumps(raw), mapping)
        except km.MessageError as exc:
            assert path in str(exc), str(exc)
        else:
            raise AssertionError("no error for {}".format(path))


def test_parse_accepts_a_null_price_as_unpriced():
    km = _km()
    raw = _reply()
    raw["MapResult"]["Pools"][1]["Lines"][0]["Combinations"][0]["TrueOdds"] = None
    frame = km.parse_prices_message(raw, km.load_mapping()).frame()
    row = frame[(frame["pool_type"] == "FHAD") & (frame["label"] == "H")].iloc[0]
    assert math.isnan(row["true_odds"])


# --------------------------------------------------------------- mapping
def test_the_office_copy_overrides_the_shipped_mapping():
    km = _km()
    shipped = km.load_mapping()
    with tempfile.TemporaryDirectory() as tmp:
        cfg = Path(tmp) / "config"
        cfg.mkdir()
        mine = json.loads(Path(shipped.source).read_text(encoding="utf-8"))
        mine["pool_types"]["HDC"] = {"code": 7, "confirmed": True}
        mine["selections"]["HDC"] = {"H": 0, "A": 1}
        (cfg / "kafka_mapping.json").write_text(json.dumps(mine), encoding="utf-8")
        office = km.load_mapping(work_dir=tmp)
        assert office.pool_types["HDC"]["code"] == 7 and office.source.startswith(tmp)
        clash = copy.deepcopy(mine)
        clash["pool_types"]["HDC"]["code"] = 0                                # HAD's code
        (cfg / "kafka_mapping.json").write_text(json.dumps(clash), encoding="utf-8")
        try:
            km.load_mapping(work_dir=tmp)
        except km.MappingError as exc:
            assert "HDC" in str(exc) and "HAD" in str(exc)
        else:
            raise AssertionError("two pools on one PoolType must be refused")


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
