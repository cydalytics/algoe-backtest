@echo off
REM Algo E - the live engine on the office SQL feed (Ctrl+C to stop).
REM Sweeps the whole card every 5 minutes and refreshes matches in focus every ~15 s.
REM     algoe-4-live.bat                                        SQL feed
REM     algoe-4-live.bat --source sql --focus 1234567           keep one match in focus
REM     algoe-4-live.bat --source replay --at "2026-09-10 20:00" --speed 10
REM                                                             rehearse an evening from Raw_Data
REM Models are read from AlgoE_Work next to Raw_Data, so ALGOE_DATA_DIR must point there.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
if "%~1"=="" (set "ARGS=--source sql") else (set "ARGS=%*")
python -m algoe live %ARGS%
pause
