# Algo E W10 / W12 / W14 - architecture

## The loop

Every 5-minute bucket, for every live match: **forecast** the money each selection will take,
**believe** a win probability for each selection that does not come from HKJC's own theta,
**search** the eight TG/SUP parameters, re-running demand at every candidate price, and
**score** each candidate by expected gross margin `E[GM] = sum demand x (1 - offer x belief)`.
Between buckets, for the matches a trader has open, the same loop runs every ~15 s with the
money already in the bucket, on the board as it stands at that moment (W12): HKJC's newest
TG/SUP, prices, clock and score, not the bucket start's.

The desk (W12) reads this loop: the board and the cockpit come from the live engine through
`/api/live/desk`, and the W06-W08 tick's last-5-minutes forecast is only a comparison column.
The board is the last sweep's card, every match as that sweep priced it, so the card is ranked
on one horizon; a focus refresh, which prices the rest of the bucket and the next, updates the
cockpit only.

Publishing (W14) closes the loop through HKJC's own pricing engine: with `publish.mode` on, the
decisions go out over Kafka as the engine's params message (GoalTg, GoalSup, CornerTg, CornerSup,
the draw factor, weightings per selection), every match at the sweep and every in-play match every
15 s from a batched in-play cycle; the engine's reply (true odds and sell prices per selection) is
read back against the book the message was decided on. The optimiser then moves the four full-match
dimensions the engine takes, and the first half follows by HKJC's own ratio. Off, nothing of this
runs and the desk is the W12 desk. The rules are in `docs/specs/kafka-publish.spec.md`.

## Folders

```
backend/
    algoe/                      the library (this document)
        core/                   settings-free plumbing: exceptions, logging, validation, taxonomy, calendar, io,
                                process pools whose workers leave with their parent
        settings.py             every tunable number, one dataclass per layer
        data/                   panels (historical, live), day splits, synthetic world, replay source
        features/               catalog (features + hypotheses), engineer, encoders, feature store
        models/                 estimators, TurnoverForecaster, ProbabilityCalibrator
        pricing/                score-grid pricer, in-play conventions, panel pricing
        optimizer/              ThetaOptimizer, demand response, books
        realtime/               LiveEngine, nowcaster; publisher, engine_reply, mock_engine (W14)
        backtest/               Backtester
        evaluation/             metrics, train/serve parity, the live money probe (probe-live)
        monitoring/             Monitor
        registry/               ModelStore
        reporting/              HTML report pieces
        cli.py, __main__.py     python -m algoe <command>
        selftest.py             the whole chain on a world with known truth
    scripts/sNN_*.py            one numbered wrapper per CLI command, in pipeline order
    src/                        the W06-W08 desk (API, SQL / capture / sim sources, parquet engine)
        api/routes/live.py      the engine behind the API: /api/live/desk (board, cockpit, what-if,
                                curves), focus requests and releases, status
        api/live_payload.py     the engine's views in the desk's shapes (pure; no algoe import)
        hkjc/kafka_messages.py  the params and prices messages, the mapping to the engine's numbers
        hkjc/kafka_transport.py memory, file and Kafka transports; Kafka settings from the environment
    tests/test_algoe.py         unit tests (pytest or plain python)
deploy/algoe-*.bat              office-box launchers
docs/                           this, RUNBOOK, FEATURES, HKJC_CODE_REVIEW
package-algoe.ps1               builds dist/algoe-w10 (selftest-gated)
```

**Layering** (an import may only point down): `realtime`, `backtest`, `cli` -> `optimizer` ->
`pricing`; `models` -> `features` -> `data` -> `core`. `algoe` wraps the W06 parquet engine
(`src/backtest/parquet`: loader, per-day panel cache); that engine never imports `algoe`, so the
workbench keeps working unchanged. The desk API (`src/api/routes/live.py`) is the one place `src`
imports `algoe`.

## Data flow

```
TRAINING                                              SERVING (live engine)
Raw_Data parquet                                      SQL / capture / sim / replay snapshot
  -> HistoricalPanel (W06 per-day cache)                -> LivePanelBuilder  (same W06 build_day,
       + contract validation                                 same start odds across midnight,
                                                            same contract, same one-hour tail)
  -> FeatureEngineer.prepare_day(panel, tail, ...)      -> FeatureEngineer.prepare_live(panel, extra)
  -> FeatureStore (per day, per feature version)            (calls prepare_day the same way)
  -> features_for_* -> estimators                       -> features_for_* -> champion models
                                                        -> build_books -> ThetaOptimizer
                                                        -> board / match view / monitor log
                                                        -> src/api/live_payload -> the desk
```

**The board of the moment** (focus, W12). A panel bucket is built from what was known strictly
before it starts, so a focus refresh at 21:47:30 built the plain way prices on the 21:45 board.
`board_snapshot` moves every wall-clock column of the snapshot forward by the time to the next
boundary (2.5 minutes here) and builds that boundary's bucket: the same code as training reads
the odds, TG/SUP, clock and score as they stood at 21:47:30, and the money lags end there; the
belief and the book are priced on that board. The bucket forecast F stays the bucket start's -
the sweep's, or the focus thread's own bucket-start build when the sweep has not forecast the
match for this bucket - shifted after an event inside the bucket, and the nowcast updates it
with the money since 21:45 as before. A row posted at the refresh moment itself is on the board:
the shift puts it a microsecond before the boundary. In the last bucket of a day the boundary
after the refresh is tomorrow, where the moved bucket would read tomorrow's calendar, money today
and references; there the focus keeps the bucket-start board and its `board_at` says so.
Selftest S9 checks that a focus refresh prices on the TG/SUP row posted inside the bucket, with
every book price at its newest and F unchanged.

**Raw_Data stays current** (W12): `update-data` (`src/backtest/parquet/raw_update.py`, the
notebook's SQL in `src/hkjc/history_queries.py`) extracts again from the day before the newest
day every table has, writes each file beside the old one and replaces it when complete, then
drops the cached panel and feature days from that day (`cache.drop_days_from`,
`store.drop_days_from`): neither cache looks at the raw files once a day is built.

**Publishing** (W14):

```
sweep / in-play cycle / trigger refresh -> MatchDecision + MatchBook (+ rows, header, draw factor)
  -> Publisher.consider     mode, kill switch, scope; board age, order and cadence; finished; draw factor
       ThetaOptimizer.quantize          theta* and weightings at the engine's precision, every guard again
       ThetaOptimizer.quantize_board    HKJC's theta as it is, or the hand-back theta: shadow to
                                        production, a revert, a kept board
       kafka_messages.build_params_message   the mapping's numbers; production: confirmed entries only
  -> transport.send, after the publisher's lock      file + mock engine | Kafka (acks=all, key EventId)
reply consumer, thread algoe-kafka-in
  -> Publisher.on_reply     parse; production ServerAppID filter; the message it answers (EventTime
                            read on our clock); per-target state
  -> LiveEngine.on_engine_prices   joined to that message's rows; gm_engine, replication gap, weight
                            echo, clock / state, revert guard, the price-move trigger (live only), a
                            feedback row in the audit
```

Each message keeps the book, rows, header and decision it was decided on, so its reply is judged
on the same board even after a newer refresh. The anchor (`optimizer.anchor_layer`) and the
hand-back theta handle the one feedback the engine may impose: Current reading back our own
message (`current_follows`).

**One row** = (bucket T, pool_id, line_id, combination_id): the price known at the start of T
and the money that arrived in `[T, T+5)`. A row is `forecastable` only if it was priced before
T and inside the pre-match window or in play; rows that merely took money are labels, never
feature rows.

**Parity is tested, not assumed.** `evaluation/parity.py` builds one bucket through both
columns above - the serving path from Raw_Data replayed as of the bucket start, so it cannot
see inside the bucket - and compares every model input of all five feature sets row by row.
Identical inputs mean no train/serve skew and no leak. The selftest runs it on every build;
`python -m algoe parity --at ...` runs it on the real data. It found six real problems during
W10, all fixed: odds age measured at the end of the bucket (a leak); the event provider chosen
with later goals (a leak); first-half pools kept alive after half time; a live selling start
rounded up a bucket, so lines looked five minutes younger; start odds lost across midnight;
money-today and lags split at midnight differently from training.

## The classes and their verbs

Method names follow `verb_[algorithm]_[response or source]`, so a reader can find any piece
from its name.

**`FeatureEngineer`** (`features/engineer.py`)
`prepare_day`, `prepare_live`; `features_for_turnover_match_total`,
`features_for_turnover_pool_share`, `features_for_turnover_selection_share`,
`features_for_turnover_selection`, `features_for_probability`; `fit_encoders`.
Features are grouped (money history, events, lifecycle, calendar, concurrency, price, line
position, bet type, popularity), each with the hypothesis it tests (`features/catalog.py`,
listed in `FEATURES.md`).

**`TurnoverForecaster`** (`models/turnover.py`)
`train_{glm,gam,gbm,nn}_{match_total,pool_share,selection_share,selection_turnover}`,
`train_naive_profile`; `predict_match_total`, `predict_pool_share`, `predict_selection_share`,
`predict_selection_turnover`, `predict_remaining_bucket`; `evaluate_match_total`,
`evaluate_pool_share`, `evaluate_selection_share`, `evaluate_selection_turnover`;
`train_all`, `refit_for_serving`, `write_backtest_series`, `save`, `load`.

**`ProbabilityCalibrator`** (`models/probability.py`)
`train_{platt,beta,isotonic}_{hkjc_true,market,...}`, `train_logit_pool`, `train_contextual`,
`train_stack` (trader -> market -> customer layers);
`predict_true_prob`, `predict_for_day`; `train_all`, `refit_for_serving`, `save`, `load`.

**`ThetaOptimizer`** (`optimizer/theta_optimizer.py`)
`prices`, `demand_at` (selection split + pool volume), `expected_gm`, `optimize_match` (stage 1
theta, stage 2 weightings), `optimize_card`; `build_books` turns a bucket's rows into one
`MatchBook` per match; `desk_weightings` states a decision in the desk's
`fair / (1 + margin) x weighting` terms.

**`Backtester`** (`backtest/backtester.py`)
`compare_turnover`, `compare_trueprob`, `compare_optimizer`, `compare_gm`,
`compare_feature_groups`, `check_replication`, `run_all`, `render`.

**`LiveEngine`** (`realtime/live_engine.py`)
`run_sweep`, `run_focus`, `check_triggers`, `step`, `start`, `stop`, `focus_on`, `focus_off`,
`trigger`, `board`, `match_view`.

**`Monitor`** (`monitoring/monitor.py`) `log_forecasts`, `join_realised`, `health_from_frames`,
`feature_reference`, `drift`, `novelty`, `write_health`.
**`ModelStore`** (`registry/model_store.py`) `save`, `load`, `champion`, `promote`,
`promote_if_better`, `list`.

## Modelling decisions

**Turnover.** The response is decomposed as
`selection money = match total x pool share x selection share` (the three-stage pipelines),
as `board total x match share x pool share x selection share` (four-stage: the matches on the
board share one pot, the GBM-friendly form of a cross-match attention), and also modelled directly
(`direct:` pipelines); each piece has its own features and loss: Tweedie / Poisson deviance with a
log link for money, multinomial-style shares with exposure. Estimators: penalised-IRLS GLM
(scale-invariant ridge), GAM (P-splines), GBM (LightGBM, or sklearn's HistGradientBoosting),
XGBoost, CatBoost, NN (torch), and each tree or network anchored on the GLM. Every model carries
log(exposure) as an offset: LightGBM through `init_score`, XGBoost through `base_margin`,
CatBoost through the Pool's `baseline` - exact for any Tweedie power (fitting the rate y /
exposure with exposure as the weight is exact only for Poisson). Each pipeline may be blended
toward last 5 minutes, with the weight chosen on
validation days. Days are split by calendar (train | val | test, never random); the champion is
the lowest validation deviance, reported once on test with WAPE (selection, match, active
selections), bias, bias on the biggest 1% of matches, Diebold-Mariano against last 5 minutes
and days better / worse. A bundle is promoted only if it beats last 5 minutes and the current
champion on the same validation days.

**Market size.** Money features are divided by a market index - the median daily turnover of
the last 28 cached days ending two days before the day - and the match-total and direct models
carry the index as exposure (forecast = index x model). A market that grows or shrinks does
not shift the inputs, a tree never extrapolates in HK$, and the labels and baselines stay in
HK$. Two days, not one: the live engine starts the day before the nightly has built yesterday,
and both paths must divide by the same number (parity checks it).

**Bigger than anything seen.** The index handles the market as a whole, not one match bigger
than any in training (a World Cup final): a tree predicts a constant past its last split, and
a network's output there is an accident of its activations (its inputs are held to the training
range, so it saturates like a tree). The anchored models (`glm_gbm`, `glm_nn`) fit the GBM or
network on top of the GLM's linear predictor: inside the training range the inner model learns
what the GLM misses; past it the money levels (`m_log_*`, `p_log_*`, `s_log_*`, `pos_log_*`,
`log_board_*`) carry the GLM's log-linear trend, capped at 10x the value at the edge, while every
other input is held at its edge (a weekday or pool count the GLM never saw says nothing about
size). On a test world with matches 1.6-7x bigger than any in training, plain GBM and NN forecast
75% too little and the anchored models were within 2-3%, with the same deviance inside the range.
The champion rule serves the anchored twin of a plain tree / network winner when it is within 1%
on validation and its bias is no more than 2 points worse. Within a day the match effect (a
match's own money so far) also pulls any forecast toward a big match after its first buckets; the
anchor fixes the first buckets too.

**References instead of absolute counts.** Board size, pools and lines per match, lines per pool,
and each bet type's margin and share of the money (pre-match / in play) are kept per cached day
(`HistoricalPanel.day_stats`, a JSON beside the panel cache) and their medians over the 28 days
ending two days before the day are the references (`reference_values`). Counts enter as log ratios
to them (`pools_rel`, `board_rel` ...), margins as differences (`p_margin_rel`, `m_margin_rel`), and
`p_ref_share` is the bet type's usual share. Training and live read the same days the same way.

**Who is playing, and how the game is going.** Teams are target-encoded like leagues (shrunk to
the league they play in), so a big club's match is big before its own money arrives. The game state
is read against the kick-off favourite (the sign of HKJC's SUP before kick-off, never a later value):
the favourite's lead, the underdog in front, red cards for each, goal pulses by side, corners and
their difference, a corner and a yellow pulse, and how far expected goals have moved since kick-off.
These reach the pool and selection shares too - the bet-type mix and the overs answer to the score,
not only the match's money - with `side_fav_team` marking the favourite's handicap / 1X2 side.

**Prices against the market and themselves.** Beside HKJC against the market median, its odds
against the best bookmaker's and its place between the market's worst and best price, its odds
against its first price of the day, and its place in its own last hour's range.

**The board as a set.** Each match's share of the board's expected popularity (league and team
levels), how far the most popular other match is above it, and how much of the board's popularity
is in play: what a match competes against at that moment (borrowed from the earlier network's
attention across matches).

**Diagnostics** (`backtest/diagnostics.py`, backtest sections 6 and 8): PSI of every input against
training and the champion's lead month by month; and the money a margin point costs, by double
machine learning (margin and money each predicted from the other inputs, cross-fitted by day; the
slope of the residuals, with a match-clustered standard error, and the residual margin spread that
identifies it). On a test world where popular matches get lower margins, the naive slope was -90 and
the DML estimate -8 against a true -8.

**Mix study** (`backtest/mixstudy.py`, sections 7, 9, 10, 11; one pass over the validation sample,
one over the test days): every goal, red card and corner found inside a bucket from the match
frame's counts, its minute from the main provider's incidents; the split before and after each
event (section 7); proportion metrics - misallocated money (half the L1 distance between the actual
and the forecast split) and share log-loss - for the bet-type, pool, selection and side splits
against last 5 minutes and the usual split (section 9), with the selection WAPE split into rows that
took money and rows that took none; buckets with an event inside them scored three ways - last 5
minutes, the model, and the model re-tuned from the event's minute (section 10).

**Event shift** (`models/event_shift.py`, section 11, `models/turnover/EVENT_SHIFT.json`): per bet
type x side (Over / Under, favourite / underdog / draw, home / away without a favourite), the money
after an event against the forecast made before it, fitted from buckets with an event k minutes in
as `y = F x (w + (1 - w) M)`, w = k / 5. Cells by event -> clock -> whose -> favourite strength ->
score after; the broadest pulled toward 1 and each narrower one's ratio to its parent pulled toward
1, both by 30 pseudo-events, so a cell holding its parent's events adds nothing and one red card is
counted once. Fitted on validation days, scored on test days, read by the live engine.

**Lines that move.** Each line's rank in its pool is set by how balanced its prices are (rank 0 =
the best line, where the market centres); every selection has a slot - offset from the best line
in quarter goals, and side. Memory is kept per slot as well as per line id (`pos_*`), across
midnight, so when the market re-centres in play (2.5 / 3.5 becomes 1.5 / 2.5) the new line
inherits its slot's money instead of starting from zero (`line_new` marks it). The model is
blended toward `last5_hybrid`: a line's own last bucket, its slot's only for a line not priced a
bucket ago that took nothing of its own (`turnover.blend_base`). The slot alone (`last5_pos`)
lost to the line's own money on every office test day: once a line has money, money follows
the line, not its offset.

**Unknowns.** Leagues and pools are target-encoded with empirical-Bayes shrinkage to their
parent (league -> global; pool x phase -> family x phase -> global), so an unseen league or
pool code gets its parent's level, never an error or a random code. The encoders read every
cached day in the two years before the validation days, evidence halving every 180 days, and
every refit relearns them: a new league or bet type has its own level from the first refit after
it appears, and one that has not played for months drifts back toward its parent. Pool codes the
taxonomy has never seen are placed by their spelling (`core/taxonomy.py`) and confirmed in
`config/pools.json`. Within a day, a match's own money updates a shrunk match effect, so a new
league learns in hours.

**Calendar.** Hong Kong's general holidays are computed for any year (`core/hk_holidays.py`: the
Chinese calendar from new moons and solar terms in UTC+8, Easter, Ching Ming, the Sunday and
coincidence rules); the holidays file adds a one-off day or removes one.

**Belief.** Settled selections only, with the soft outcome `(r+1)/2` for quarter lines and
pushes dropped; live prices only (a withdrawn line keeps a stale quote). Every source (HKJC
true odds, external market median, Poisson from HKJC's theta with the in-play score shift,
de-margined odds) x every method (raw, Platt, beta, isotonic, logit pool, contextual), fitted
on train days, chosen on validation log-loss, renormalised within each line. The stacked model
builds the final belief in three layers, each fitted on top of the one before (its logit is the
next layer's offset), so each layer's gain is reported on its own: trader (HKJC's sources,
calibrated by phase, bet type and price level), market (how far to move toward the bookmakers'
consensus, by phase, bet type and quote age), customer (weight of money - a side's share of its
line's money against its price -, ticket size against its pool's, liquidity, recent price moves).
Interactions use the best HKJC source a row has (true odds, else Poisson, else de-margined).
Every method is also scored by money (stake-weighted log-loss and ECE, expected minus realised
margin), because the optimiser's E[GM] is a sum over money; a stake-weighted stack competes, and
`probability.champion_metric` can choose by money. Poisson-from-theta is empty for extra-time
pools (theta is full time) and cached per day beside the features.

**Pricing and in-play.** One score grid per (TG, SUP) collapsed to total / difference
marginals, one effective-probability formula for whole, half and quarter lines. In play,
HKJC's `Goal90CurrentTG` is goals still to come, so full-match lines are priced on the grid
shifted by the current score; `check_replication` confirms this convention reproduces HKJC's
own board for every pool.

**Optimizer.** `price_mode = delta`: our offer is HKJC's posted odds moved by our model's
relative price change, `O(theta) = O_now x p(theta_now) / p(theta)`, so the lift measures the
theta decision alone. Demand at a candidate price comes from the turnover model's own price
terms, renormalised within each pool - only if those terms make a longer price take more money
at evens with and without a market price. History does not always measure demand: HKJC shortens
a price after money arrives, so a share model fitted on rows without HKJC true odds or a market
price can learn that longer prices take less (the office model: -0.43 at evens without a market
price). Then the optimiser uses a fixed elasticity instead and says so. A block without HKJC's
TG / SUP (or CTG / CSUP) is left alone rather than priced at a default theta.
Guards: a trust band around HKJC's theta, a max step
from the previous recommendation, coherence (first half inside the full match, |SUP| <= TG),
a per-selection probability band, and the external market as a cap on main-line offers.
theta_now is always a candidate, so a recommendation is never worse than HKJC's theta under
the model. Books are split into independent blocks (goal / corner x FT / FH) so each
evaluation prices only what the moved dimensions touch.

A pool's total money follows its price level: `exp(-e x change in log overround)`, with
`e = 1 / margin` by default (`volume_response = neutral`) - the elasticity at which HKJC's own
margin is the volume-optimal one. The history cannot measure this elasticity cleanly (margins are
policy, and big matches carry both lower margins and more money), so the default assumes HKJC
prices its margin well rather than letting the optimiser chase margin; `fixed` or `none`
override it.

Stage 2 is the local layer: with theta* fixed, a weighting per selection
(`O = O(theta*) x w`, the desk's `fair / (1 + margin) x weighting`), each within +-3%, each line
keeping HKJC's overround, no cross-line arbitrage (an over is never shorter than the over of a
lower line; handicaps likewise), neighbouring lines' weightings on the same side penalised for
differing and every weighting for leaving 1, max 1% per focus refresh. It is solved pool by pool
and kept only where it beats theta* alone; the backtest reports the two lifts separately.

## Real time and compute

| Loop | When | What | Cost (synthetic card of 9-12 matches) |
|------|------|------|------|
| sweep | every bucket boundary, thread `algoe-live` | the whole card: forecast, belief, theta* for every match with expected money above `optimizer.min_match_turnover`, richest first, inside `optimizer.budget_seconds`, in a process pool; every match on the card gets a row on the board, solved or not | 4.7-5.9 s |
| focus | every `live.focus_interval_seconds` (15 s) for matches open on the desk (heartbeat, 3-minute TTL; the cockpit's first read asks at once) or hit by a trigger (`live.trigger_focus_seconds`: goal / red 180 s, corner / price / money 60 s); thread `algoe-focus` with its own source (its own SQL connection) | one match per step - a desk request or trigger first, then the most overdue - so a new request waits for one refresh, not a queue; re-fetch that match on the board of the moment (above); after an event inside the bucket, shift the bucket forecast by the event shift and nowcast from the money since the event; re-optimise from the last answer with one start and a max step | 0.6-1.9 s per match; open to refreshed cockpit 3.6-5.2 s on the simulator |
| triggers | every focus interval, whole card, cheap, on the sweep thread | a goal, red card or corner, or a cancellation (the main provider's incident counts changed); main-line price move > `live.trigger_odds_move`; one minute's money > `live.trigger_big_bet_multiple` x the forecast minute | tens of ms |
| in-play cycle (W14, publishing on) | every `publish.inplay_seconds` (15 s), thread `algoe-inplay` with its own source | every in-play match on the card in one pass: one fetch, one board of the moment, one feature and belief pass, the books, then each solved from its last answer on the engine's persistent process pool inside `publish.inplay_budget_seconds`, the matches the last cycle did not reach first; a match not reached keeps its answer, marked behind; each published | 2.8-3.4 s for 8 matches on the simulator; 40 in 8.1 s (capacity test) |
| replies (W14) | thread `algoe-kafka-in`, the transport polled every 0.25 s | each reply matched to its message and read on its book (Data flow) | ms per reply |

The threads share the models under a lock and write each match's latest answer under the
engine lock; none replaces an answer read from a newer board. A failed focus refresh keeps
the last answer, reports why, and is tried again an interval later, not on every poll. The
publisher has its own lock, always taken after the engine's and never before it; messages are
built under it and handed to the transport after it, because the dry-run mock engine reads the
match back through the engine (a send under the lock deadlocked a desk read, 2026-10-29). The
in-play pool lives as long as the engine (a new pool costs seconds on Windows) and its workers
leave when the process does, however it is stopped (`core/pool.py`).

**Nowcast** (`realtime/nowcast.py`): with bucket forecast F and money x after e minutes, the
rate is `(F/5 x m0 + x) / (m0 + e)` - a Gamma-Poisson update where the forecast counts as m0
minutes of evidence - applied at match level and spread over its selections, so
`remaining = rate x (5 - e)`. The next bucket's forecast is scaled by how hot this one runs.
Money arrives in tickets, not as a smooth stream, so the rate is capped at
`live.nowcast_max_hot` (4) x the forecast rate: one HK$1M ticket a minute into a HK$50k bucket
raises the rest of the bucket to HK$160k, not HK$1.36M, and the next bucket at most 2x. After an
event at minute k the prior is the shifted forecast F x M, the evidence the money since the event
over the minutes since it, and the remaining minutes 5 - e (`update(..., left=)`).

**Guards on theta\***: within `optimizer.theta_band` of HKJC's theta (focus: also within
`max_step` of the last answer), TG >= |SUP| and first half <= full time, every price within
`prob_band` of the board, main lines no longer than the market, and never below the board's
E[GM]. A match expecting less than `min_match_turnover` is not solved. The optimizer moves theta
for `optimizer.pools` (default `@theta_lines`: every FT / FH goal and corner line market, team
totals included); `test_optimizer_with_no_money_and_with_a_flood` pins the behaviour at zero money
and at 100x / 10,000x on one selection.

## Validation, logging, traceability

- **Contracts** (`core/validation.py`): every panel (historical and live) passes the same
  column rules - type coercion, sentinels (odds 9999) to null, ranges clipped or nulled, required
  fills (unknown pool name -> `UNKNOWN`), duplicate keys counted - and a report is logged.
- **Logging** (`core/logging.py`): every stage is a boxed `STEP` with a `[PASS]`/`[FAIL]` line
  and its timing, to the console, a text log and a JSON-lines log with the data behind each line.
- **Runs**: every CLI command writes `AlgoE_Work/runs/<stamp>_<command>/` with the resolved
  settings and a summary (exit code, error, headline numbers).
- **Versions**: `FEATURE_VERSION` keys the feature store and is stamped on every model;
  the store refuses a bundle whose checksum or feature version does not match, and a champion
  on older features cannot block a promotion.

## Tests

| Layer | Where | Runs |
|-------|-------|------|
| unit | `backend/tests/test_algoe.py` | pricer vs legacy, quarter-line settlement, team totals vs closed-form Poisson, HK holidays for any year (vs the gazette and, where installed, a century of python-holidays tables), a new line inheriting its slot's money, money features unchanged when the market doubles, GLM recovers rates, save / load, unseen encodings and pool codes, pool rules, date split, validation, pool close times, nowcast (incl. one big ticket), optimizer at zero money and under a flood (stage 2: band, overround kept, ladder arbitrage-free), volume response keeps HKJC's margin, settings, model store guards, PSI, goal-pulse time consistency, CLI parsing |
| unit (W12) | `backend/tests/test_algoe.py`, `test_live_payload.py` | focus on the board of the moment and one match per focus step, the probe's checks (spacing, duplicates, running totals, the bucket's rows, the first-half split implied by FCRS / FHLO), the first-half split read both ways, replication without a model, the desk payloads (board, cockpit, what-if, curves) |
| unit (W14) | `test_kafka_messages.py`, `test_kafka_transport.py`, `test_kafka_check.py`, `test_publisher.py`, `test_publish_optimizer.py`, `test_inplay.py`, `test_engine_reply.py`, `test_pool.py` | the two messages byte for byte against the samples, the mapping gate, transports and kafka-check on a stand-in confluent_kafka, the production gate, MsgIds across restarts, the kill switch, scope, shadow (HKJC's theta as read, no weightings, fresh reads only), reply matching (late replies, other servers, clock offset), the hand-back theta, rounding with the guards again, the in-play cycle against a focus refresh and 40 matches in budget, the reply read on its message's book, workers leaving a killed parent |
| system | `python -m algoe selftest` | 13 checks on a generated world, including train/serve parity, a live sweep + focus on the board of the moment, and publishing on the mock engine (S13) |
| real data | `python -m algoe parity`, `probe-live`, `backtest --only replication` | train/serve parity on Raw_Data; the live money feed; which first-half split reading reproduces HKJC's board |
| desk | `backend/tests/test_optimizer.py`, `contract.py` | every field the UI reads: `--desk live` (default) the board and cockpit on the engine, `--desk mvp` the W06 desk; `--expect-publish dry_run` also wants the engine's prices on the cockpit |

## Extending

- **A new feature**: add it in the engineer's group method, add a `FeatureSpec` (group,
  hypothesis, fill, clip) to `features/catalog.py`, bump `FEATURE_VERSION`, run the selftest
  (parity must stay identical) and the backtest (`compare_feature_groups` says what it is worth).
- **A new estimator**: subclass `Estimator` (`fit`, `predict`, `to_state`, `from_state`), register it,
  add `train_<algo>_<response>` methods and a pipeline name; it joins the leaderboard.
- **A new response or pipeline**: a `ResponseSpec` (builder, family, exposure) and a pipeline
  string such as `three_stage:gbm+glm+gbm`.
- **A new pool code or league**: nothing to code (see RUNBOOK section 5).
