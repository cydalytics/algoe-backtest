"""
Panel Pricing

Price every selection row of a panel day at HKJC's own theta for its
bucket, with the running score applied. Used three ways:

    belief source   "poisson" = HKJC's TG/SUP through our pricer
    replication     how close that price is to the odds HKJC actually posted,
                    per pool and phase, under each in-play convention
    optimiser       the starting point (theta_now) and the book it reprices

One score grid per (match, bucket, domain); every line of that match-bucket
is priced off it.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..core.taxonomy import ASIAN
from .pricer import BookPricer, BookRows, Conventions, MatchState, theta_from_params

logger = get_logger(__name__)

MATCH_STATE_COLS = ("home_goals", "away_goals", "home_corners", "away_corners")


def state_of(row) -> MatchState:
    phase = str(row.get("phase", "prematch") or "prematch")
    def i(col):
        v = row.get(col, 0)
        try:
            return int(v) if v == v else 0
        except (TypeError, ValueError):
            return 0
    minute = row.get("minute", 0.0)
    try:
        minute = float(minute) if minute == minute else 0.0
    except (TypeError, ValueError):
        minute = 0.0
    return MatchState(home_goals=i("home_goals"), away_goals=i("away_goals"), home_corners=i("home_corners"),
                      away_corners=i("away_corners"), minute=minute, phase=phase)


def hkjc_theta(row, state: MatchState) -> Dict[str, float]:
    return theta_from_params(row.get("tg"), row.get("sup"), row.get("ctg"), row.get("csup"),
                             row.get("goal_split_fh", 0.45), row.get("corner_split_fh", 0.47), state)


def price_rows_at_hkjc(sel: pd.DataFrame, match: pd.DataFrame, conventions: Conventions,
                       mask: Optional[np.ndarray] = None) -> np.ndarray:
    """Effective probability per ``sel`` row at HKJC's theta for its bucket (NaN if unpriceable).

    ``sel`` needs match_id, bucket, theta_domain, market, line, side; ``match``
    the running score and theta columns per (match_id, bucket).
    """
    out = np.full(len(sel), np.nan)
    if sel.empty or match is None or match.empty:
        return out
    pricer = BookPricer(conventions)
    work = sel[["match_id", "bucket", "theta_domain", "market", "line", "side"]].copy()
    work["_pos"] = np.arange(len(sel))
    if mask is not None:
        work = work[np.asarray(mask, dtype=bool)]
    priceable = work["market"].isin(list(ASIAN) + ["three_way", "handicap_3w"])
    work = work[priceable & work["theta_domain"].isin(["goal", "goal_fh", "corner", "corner_fh"])]
    if work.empty:
        return out
    cols = ["match_id", "bucket", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh", "phase",
            "minute"] + list(MATCH_STATE_COLS)
    ctx = match[[c for c in cols if c in match.columns]].drop_duplicates(["match_id", "bucket"])
    work = work.merge(ctx, on=["match_id", "bucket"], how="left")
    cache: Dict[tuple, tuple] = {}
    for (mid, b), g in work.groupby(["match_id", "bucket"], sort=False):
        r = g.iloc[0]
        # a block without HKJC's TG / SUP stays unpriced; theta_from_params would fill a default
        known = {blk: all(np.isfinite(pd.to_numeric(r.get(c), errors="coerce")) for c in cols)
                 for blk, cols in (("goal", ("tg", "sup")), ("corner", ("ctg", "csup")))}
        corner = g["theta_domain"].astype(str).str.startswith("corner").to_numpy()
        g = g[np.where(corner, known["corner"], known["goal"])]
        if g.empty:
            continue
        st = state_of(r)
        th = hkjc_theta(r, st)
        book = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(),
                        g["line"].to_numpy(dtype="float64"), g["side"].to_numpy())
        p, _ = pricer.probabilities(book, th, st)
        out[g["_pos"].to_numpy()] = p
    return out
