@echo off
REM Algo E - Kafka check on the TEST topics, the first step before publishing (RUNBOOK, Publishing):
REM the brokers answer and the login works; with --send, one params message and the pricing engine's reply.
REM     algoe-7-kafka-check.bat                                brokers, login, the two test topics
REM     algoe-7-kafka-check.bat --send --event-id 1234567      one message for that match, then its reply
REM The settings come from the environment: a filled copy of kafka.example.cmd kept as
REM %USERPROFILE%\algoe-kafka.cmd (outside this folder, out of git) is read here and by start.bat.
REM Secrets are never printed.
setlocal
cd /d "%~dp0backend"
set PYTHONUTF8=1
if exist "%USERPROFILE%\algoe-kafka.cmd" call "%USERPROFILE%\algoe-kafka.cmd"
if not defined ALGOE_DATA_DIR set "ALGOE_DATA_DIR=S:\Users\Yeung\20260520 Algo E\Raw_Data"
python -m algoe kafka-check %*
set CODE=%ERRORLEVEL%
echo.
if "%CODE%"=="0" (echo Kafka check passed.) else if "%CODE%"=="2" (echo Sent but no reply came back, or a test topic is missing. Send the lines above to the Kafka owner.) else (echo Kafka check FAILED - read the lines above. Do not turn publishing on.)
pause
exit /b %CODE%
