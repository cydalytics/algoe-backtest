"""
Raw_Data update

Brings the parquet "1 Data Extraction.ipynb" writes up to now with the notebook's own queries
(src/hkjc/history_queries.py), one file at a time:

    newest day N    per table, the day of the newest timestamp in its files
    restart R       min over tables of N, minus one day (newest 1 Oct -> restart 30 Sep)
    monthly tables  every month from month(R) to this month, each extracted whole
    investments     every day from R to today

A file is written as <name>.parquet.tmp beside the old one and then replaces it: a failed query or
a killed run keeps the old file, and the loader, which reads *.parquet, never sees a partial one.
A table with no files, or a file that is not one of these and may overlap them (its rows would be
read twice), stops the run. Raw_Data/_algoe_update.json says what the last run did;
Raw_Data/_algoe_update.lock keeps a second run out while its owner beats on it. The caller drops
the cached days from R on (cache.drop_days_from) once files are written.

Change Log:
-----------
2026-10-26      Initialize
2026-10-27      from the review: a table with no files or an overlapping foreign file stops the run; the
                lock has an owner token, a heartbeat, a wait and a 15-minute staleness; run(write=False)
                leaves the status to the caller; the newest day before any update comes from the
                Match_Investments file names
"""

from __future__ import annotations

import json
import os
import re
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional

import pandas as pd

from src.hkjc import history_queries as Q

from .config import SUBDIRS
from .loader import _file_time_bounds, files_for

STATUS = "_algoe_update.json"
LOCK = "_algoe_update.lock"
STALE_LOCK_MINUTES = 15.0
LAG_WARN_DAYS = 3
TABLES = Q.MONTHLY + ("investments",)
# tables whose window column runs ahead of the clock (kick-offs still to come)
AHEAD = ("matches", "pools")


class ForeignFiles(RuntimeError):
    pass

_NAME = re.compile(r"^(?P<prefix>[a-z_]+?)_(?P<a>\d{4}-\d{2}(?:-\d{2})?)_(?P<b>\d{4}-\d{2}(?:-\d{2})?)\.parquet$")


@dataclass
class Job:
    table: str
    path: Path
    start: pd.Timestamp
    end: pd.Timestamp

    @property
    def rel(self) -> str:
        return "{}/{}".format(self.path.parent.name, self.path.name)


@dataclass
class Plan:
    data_dir: Path
    now: pd.Timestamp
    newest: Dict[str, Optional[pd.Timestamp]]
    restart: pd.Timestamp
    jobs: List[Job]
    foreign: List[str]

    @property
    def newest_day(self) -> Dict[str, Optional[pd.Timestamp]]:
        return {t: (v.normalize() if v is not None else None) for t, v in self.newest.items()}

    def describe(self) -> List[str]:
        days = self.newest_day
        out = ["Raw_Data {}".format(self.data_dir),
               "newest day on disk: " + ", ".join("{} {}".format(SUBDIRS[t], d.date() if d is not None else "none")
                                                   for t, d in days.items()),
               "restart {} (the day before the newest day every table has)".format(self.restart.date())]
        months = sorted({j.start for j in self.jobs if j.table != "investments"})
        if months:
            out.append("monthly tables, extracted whole: {} ({} files)".format(
                ", ".join(m.strftime("%Y-%m") for m in months), sum(1 for j in self.jobs if j.table != "investments")))
        inv = [j for j in self.jobs if j.table == "investments"]
        if inv:
            out.append("Match_Investments: {} .. {} ({} files)".format(inv[0].start.date(), inv[-1].start.date(), len(inv)))
        behind = self.lagging()
        if behind:
            out.append("WARNING {} {} behind the other tables and hold(s) the restart back: every run extracts them "
                       "again from there. If a feed has stopped, extract with --from.".format(
                           ", ".join(SUBDIRS[t] for t in behind), "is" if len(behind) == 1 else "are"))
        for f in self.foreign:
            out.append("STOP {} is not one of these files and may overlap them: its rows would be read twice. Move it "
                       "out of Raw_Data (or pass --allow-foreign).".format(f))
        return out

    def lagging(self) -> List[str]:
        """Tables whose newest day is more than LAG_WARN_DAYS behind the newest of the others."""
        days = {t: d for t, d in self.newest_day.items() if d is not None and t not in AHEAD}
        if len(days) < 2:
            return []
        top = max(days.values())
        return sorted(t for t, d in days.items() if (top - d).days > LAG_WARN_DAYS)

    def check_foreign(self, allow: bool = False) -> None:
        if self.foreign and not allow:
            raise ForeignFiles("{} file(s) in Raw_Data may overlap the files this run writes, and the loader would "
                               "read their rows twice: {}. Move them out, or pass --allow-foreign.".format(
                                   len(self.foreign), ", ".join(self.foreign)))


def _named_window(path: Path, table: str):
    """[start, end) from a file named the notebook's way for this table, else None."""
    m = _NAME.match(path.name)
    if not m or m.group("prefix") != Q.FILE_PREFIX[table]:
        return None

    def day(s):
        return pd.Timestamp(s if len(s) > 7 else s + "-01")
    return day(m.group("a")), day(m.group("b"))


def _bounds(path: Path, table: str):
    """(first, last) timestamp of a file: parquet statistics, else the window in its name."""
    b = _file_time_bounds(path, Q.WINDOW_COLUMN[table])
    if b is not None:
        return b
    return _named_window(path, table)


def _overlaps(path: Path, table: str, restart: pd.Timestamp) -> bool:
    """A notebook file by the window in its name (its rows may spill a second past it), any other by
    its rows; a file whose rows cannot be read may overlap anything."""
    w = _named_window(path, table)
    if w is not None:
        return w[1] > restart
    b = _bounds(path, table)
    return b is None or b[1] >= restart


def newest_timestamps(data_dir) -> Dict[str, Optional[pd.Timestamp]]:
    out: Dict[str, Optional[pd.Timestamp]] = {}
    for table in TABLES:
        best = None
        for path in files_for(Path(data_dir), table):
            b = _bounds(path, table)
            if b is not None and (best is None or b[1] > best):
                best = pd.Timestamp(b[1])
        out[table] = best
    return out


def _file(data_dir: Path, table: str, a: pd.Timestamp, b: pd.Timestamp, fmt: str) -> Path:
    return data_dir / SUBDIRS[table] / "{}_{}_{}.parquet".format(Q.FILE_PREFIX[table], a.strftime(fmt), b.strftime(fmt))


def plan(data_dir, now=None, start=None, overlap_days: int = 1) -> Plan:
    data_dir = Path(data_dir)
    now = pd.Timestamp(now) if now is not None else pd.Timestamp.now()
    newest = newest_timestamps(data_dir)
    empty = [SUBDIRS[t] for t, v in newest.items() if v is None]
    if start is not None:
        restart = pd.Timestamp(start).normalize()
    elif empty:
        raise ValueError("{} in {} has no file to start from: pass --from YYYY-MM-DD (the first day to extract; "
                         "the notebook started on 2024-05-01)".format(", ".join(empty), data_dir))
    else:
        restart = min(v.normalize() for v in newest.values()) - pd.Timedelta(days=int(overlap_days))
    restart = min(restart, now.normalize())
    jobs: List[Job] = []
    for m in pd.date_range(restart.to_period("M").to_timestamp(), now, freq="MS"):
        nxt = m + pd.offsets.MonthBegin(1)
        for table in Q.MONTHLY:
            jobs.append(Job(table, _file(data_dir, table, m, nxt, "%Y-%m"), m, nxt))
    for d in pd.date_range(restart, now.normalize(), freq="D"):
        nxt = d + pd.Timedelta(days=1)
        jobs.append(Job("investments", _file(data_dir, "investments", d, nxt, "%Y-%m-%d"), d, nxt))
    ours = {j.path for j in jobs}
    foreign = []
    for table in TABLES:
        for path in files_for(data_dir, table):
            if path not in ours and _overlaps(path, table, restart):
                foreign.append("{}/{}".format(path.parent.name, path.name))
    return Plan(data_dir, now, newest, restart, jobs, sorted(foreign))


def write_atomic(frame: pd.DataFrame, path: Path) -> None:
    """<name>.parquet.tmp, then replace: the loader never reads a half-written file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        frame.to_parquet(tmp, index=False)
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def run(p: Plan, reader, progress: Optional[Callable[[int, int, dict], None]] = None, write: bool = True) -> dict:
    """Every job of the plan, in order; a failed job keeps its old file and the others go on.
    Returns the status; ``write=False`` leaves writing it to a caller with more steps to finish."""
    started = pd.Timestamp.now()
    files = []
    for k, job in enumerate(p.jobs, 1):
        t0 = time.time()
        rec = {"file": job.rel, "rows": 0, "ok": True, "error": None}
        try:
            frame = reader.read(job)
            if frame is not None and len(frame):
                write_atomic(frame, job.path)
                rec["rows"] = int(len(frame))
        except Exception as exc:                                        # noqa: BLE001
            rec.update(ok=False, error="{}: {}".format(type(exc).__name__, exc))
        rec["seconds"] = round(time.time() - t0, 1)
        files.append(rec)
        if progress is not None:
            progress(k, len(p.jobs), rec)
    newest = newest_timestamps(p.data_dir)
    known = [v for v in newest.values() if v is not None]
    failed = [r for r in files if not r["ok"]]
    status = {"ok": not failed, "started": str(started), "finished": str(pd.Timestamp.now()),
              "host": socket.gethostname(), "restart": str(p.restart.date()),
              "files_written": sum(1 for r in files if r["rows"]), "files_failed": len(failed),
              "error": failed[0]["error"] if failed else None,
              "newest": {t: (str(v) if v is not None else None) for t, v in newest.items()},
              "newest_day": str(min(known).date()) if known else None, "files": files}
    if write:
        write_status(p.data_dir, status)
    return status


# ------------------------------------------------------------------ status
def write_status(data_dir, status: dict) -> None:
    path = Path(data_dir) / STATUS
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(status, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def read_status(data_dir) -> Optional[dict]:
    path = Path(data_dir) / STATUS
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def is_stale(status: Optional[dict], today=None) -> bool:
    """No status, a run that did not finish, a failed last run, or a newest day before yesterday."""
    if not status or status.get("running") or not status.get("ok") or not status.get("newest_day"):
        return True
    today = pd.Timestamp(today if today is not None else pd.Timestamp.now()).normalize()
    return pd.Timestamp(status["newest_day"]) < today - pd.Timedelta(days=1)


_INVESTMENT_DAY = re.compile(r"^match_investments_(\d{4}-\d{2}-\d{2})_\d{4}-\d{2}-\d{2}\.parquet$")


def newest_complete_day(data_dir, today=None) -> Optional[pd.Timestamp]:
    """The last day a backtest window can end on: the newest day on disk, at most yesterday. Before any
    update has written a status, the newest Match_Investments day file stands in for it."""
    status = read_status(data_dir)
    newest = status.get("newest_day") if status else None
    if not newest:
        days = [m.group(1) for f in files_for(Path(data_dir), "investments") for m in [_INVESTMENT_DAY.match(f.name)] if m]
        newest = max(days) if days else None
    if not newest:
        return None
    today = pd.Timestamp(today if today is not None else pd.Timestamp.now()).normalize()
    return min(pd.Timestamp(newest).normalize(), today - pd.Timedelta(days=1))


# -------------------------------------------------------------------- lock
class UpdateLocked(RuntimeError):
    pass


class Lock:
    """Raw_Data/_algoe_update.lock for the length of a run.

    The file holds the owner's token, and the owner touches it every ``beat_seconds``, so a lock not
    touched for STALE_LOCK_MINUTES belongs to a run that was killed and is taken over. Only the owner
    deletes it. ``wait_seconds`` waits for a running update instead of giving up at once.
    """

    def __init__(self, data_dir, wait_seconds: float = 0.0, beat_seconds: float = 60.0,
                 stale_minutes: float = STALE_LOCK_MINUTES):
        self.path = Path(data_dir) / LOCK
        self.wait_seconds, self.beat_seconds = float(wait_seconds), float(beat_seconds)
        self.stale_seconds = float(stale_minutes) * 60.0
        self.token = "{} pid {} on {} at {}".format(uuid.uuid4().hex, os.getpid(), socket.gethostname(),
                                                   pd.Timestamp.now())
        self._stop = threading.Event()
        self._beat: Optional[threading.Thread] = None

    def __enter__(self) -> "Lock":
        deadline = time.time() + self.wait_seconds
        while not self._take():
            if time.time() >= deadline:
                age = time.time() - self._mtime()
                raise UpdateLocked("another update is running ({}, last seen {:.0f} s ago); wait for it, or delete "
                                   "{} if that run was killed".format(self._holder(), age, self.path))
            time.sleep(min(1.0, max(self.wait_seconds / 20.0, 0.05)))
        self._beat = threading.Thread(target=self._beating, name="algoe-update-lock", daemon=True)
        self._beat.start()
        return self

    def __exit__(self, *exc) -> None:
        self._stop.set()
        if self._beat is not None:
            self._beat.join(timeout=5)
        if self._holder() == self.token:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass

    def _take(self) -> bool:
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, self.token.encode())
            os.close(fd)
            return True
        except FileExistsError:
            pass
        if time.time() - self._mtime() < self.stale_seconds:
            return False
        # a killed run's lock: replace it in one step, then make sure this run is the one holding it
        tmp = self.path.with_name("{}.{}.tmp".format(self.path.name, uuid.uuid4().hex[:8]))
        tmp.write_text(self.token, encoding="utf-8")
        os.replace(tmp, self.path)
        time.sleep(0.05)
        return self._holder() == self.token

    def _beating(self) -> None:
        while not self._stop.wait(self.beat_seconds):
            if self._holder() != self.token:
                return
            try:
                os.utime(self.path, None)
            except OSError:
                return

    def _mtime(self) -> float:
        try:
            return self.path.stat().st_mtime
        except OSError:
            return 0.0

    def _holder(self) -> str:
        try:
            return self.path.read_text(encoding="utf-8").strip()
        except OSError:
            return ""


# ------------------------------------------------------------------ reader
class SqlReader:
    """The notebook's queries on the live desk's SQL connections (src.hkjc.sql_source)."""

    def __init__(self, source=None):
        if source is None:
            from src.hkjc.sql_source import SqlSource
            source = SqlSource()
        self.source = source

    def read(self, job: Job) -> pd.DataFrame:
        conn = self.source._connect(Q.CONNECTION[job.table])
        a, b = job.start.strftime("%Y-%m-%d"), job.end.strftime("%Y-%m-%d")
        if job.table == "investments":
            return Q.read_investments_day(conn, a, b)
        return Q.read_month(conn, job.table, a, b)
