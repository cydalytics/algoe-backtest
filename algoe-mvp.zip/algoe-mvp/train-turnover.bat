@echo off
REM Two-level statistical turnover model from Raw_Data, CPU only, numpy only.
REM Writes Backtest_Data\Turnover\glm so the backtest can compare it with last 5 min.
REM Double-click, or drag the Raw_Data folder onto this file.
cd /d "%~dp0backend"
set DATA=%~1
if "%DATA%"=="" set DATA=S:\Users\Yeung\20260520 Algo E\Raw_Data
python -m src.backtest.parquet.glm_turnover train --data-dir "%DATA%"
echo.
echo Done. In the backtest page: Run, then Open cached. "glm" is next to Last 5 min.
pause
