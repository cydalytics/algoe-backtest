"""
HKJC SQL - history

The queries "1 Data Extraction.ipynb" builds Raw_Data with, kept as they are so they can be diffed
against the notebook. Only the window is a parameter, in the notebook's own format: 'YYYY-MM-01'
for the six monthly tables, 'YYYY-MM-DD' for Match_Investments, which is one file per day of pool
conclude dates. The notebook's quirks stay: the market-odds query joins the two name CTEs the
wrong way round (loader.resolve_market_swap repairs it after load), the cash bets go into #acc and
the two are combined with UNION.

Connections as in the notebook: odds, market odds, match information and events on qfm;
parameters, investments and pool details on bis.

Change Log:
-----------
2026-10-26      Initialize (port of notebook 1)
"""

import pandas as pd

MONTHLY = ("odds", "market", "params", "matches", "events", "pools")

CONNECTION = {"odds": "qfm", "market": "qfm", "matches": "qfm", "events": "qfm",
              "params": "bis", "pools": "bis", "investments": "bis"}

FILE_PREFIX = {"odds": "hkjc_odds", "market": "market_odds", "params": "hkjc_parameters",
               "matches": "match_information", "events": "match_events", "pools": "pool_details",
               "investments": "match_investments"}

# the column each table's window is on, as the notebook writes it
WINDOW_COLUMN = {"odds": "effective_datetime", "market": "effective_datetime", "params": "EventTime",
                 "matches": "KOTime", "events": "incident_datetime", "pools": "kickoff_date",
                 "investments": "start_sell_time"}

PARSE_DATES = {"odds": ["effective_datetime"], "market": ["effective_datetime"],
               "params": ["EventTime", "CreateTime"],
               "matches": ["Season_StartDate", "Season_EndDate", "KOTime"],
               "events": ["incident_datetime", "last_modified_datetime"],
               "pools": ["start_selling_time", "pool_status_update", "time_last_update", "close_time",
                         "close_date", "kickoff_date"],
               "investments": ["start_sell_time"]}

_BET_TYPES = """    SELECT * FROM (VALUES 
        (0, 'None'),
        (1, 'HAD'),
        (2, 'FHAD'),
        (3, 'HILO'),
        (4, 'FHLO'),
        (5, 'CHLO'),
        (6, 'HDC'),
        (7, 'HHAD'),
        (8, 'HFT'),
        (9, 'CRS'),
        (10, 'FCRS'),
        (11, 'OOE'),
        (12, 'TTG'),
        (13, 'FTS'),
        (14, 'TQL'),
        (15, 'NTS'),
        (16, 'TPS'),
        (17, 'FGS'),
        (18, 'CHP'),
        (19, 'GPF'),
        (20, 'GPW'),
        (31, 'DHCP'),
        (32, 'JKC'),
        (33, 'TNC'),
        (34, 'TSPC'),
        (35, 'MSPC'),
        (36, 'ETNTS'),
        (37, 'ETHAD'),
        (38, 'ETHILO'),
        (39, 'ETCHLO'),
        (40, 'ETHDC'),
        (41, 'ETCRS'),
        (42, 'ETTTG'),
        (43, 'TESTBTG'),
        (44, 'SGA'),
        (45, 'FCHLO'),
        (46, 'FHDC'),
        (47, 'FCHDC'),
        (48, 'CHDC'),
        (49, 'ETCHDC'),
        (50, 'ETHHAD'),
        (51, 'NGS'),
        (52, 'LGS'),
        (53, 'AGS'),
        (54, 'ETNGS'),
        (55, 'ETLGS'),
        (56, 'ETAGS')
    ) AS v(EnumValue, EnumString)"""

_BOOKMAKERS = """    SELECT * FROM (VALUES 
        (0, 'None'),
        (1, 'BM10BET'),
        (2, 'BetISN'),
        (3, 'Bwin'),
        (4, 'Centrebet'),
        (5, 'Coral'),
        (6, 'IBCBET'),
        (7, 'Ladbrokes'),
        (8, 'PaddyPower'),
        (9, 'Sbobet_com'),
        (10, 'SNAI'),
        (11, 'WilliamHill'),
        (12, 'Bet365'),
        (13, 'PinnacleSports'),
        (14, 'HKJC'),
        (15, 'BM12Bet'),
        (16, 'BM188Bet'),
        (17, 'BM1XBet'),
        (18, 'BM855Crown'),
        (19, 'Bet855'),
        (20, 'BetCityRU'),
        (21, 'BETDAQ'),
        (22, 'Betway'),
        (23, 'BoyleSports'),
        (24, 'DafaBet'),
        (25, 'Easybets'),
        (26, 'Fonbet'),
        (27, 'MacauSlot'),
        (28, 'Mansion88'),
        (29, 'Marathonbet'),
        (30, 'Matchbook'),
        (31, 'Nextbet'),
        (32, 'Olimpbet'),
        (33, 'PokerStars'),
        (34, 'Singbet'),
        (35, 'Skybet'),
        (36, 'Sportingbet'),
        (37, 'Sporttery'),
        (38, 'TheGreek'),
        (39, 'TonyBet'),
        (40, 'TouTou'),
        (41, 'Unibet'),
        (42, 'V9BET'),
        (43, 'Victor')
    ) AS v(EnumValue, EnumString)"""

_ODDS = """
    	WITH EnumDataCTE (EnumValue, EnumString) AS (
""" + _BET_TYPES + """
)
    select 
        e.event_id [match_id], 
        p.bet_type_code,
		bt.EnumString,
        e.pool_id,
        l.line_id,
        l.line_label, 
        c.combination_id,
        c.combination_string, 
        o.odds, 
        o.effective_datetime
    from [dbo].[pool_event_leg_c] e with(nolock) 
        inner join [dbo].[pool_c] p with(nolock) on e.pool_id = p.pool_id 
        left join [dbo].[pool_line_c] l with(nolock) on l.pool_id = e.pool_id and l.is_deleted = 0  
        left join [dbo].[pool_combination_c] c with(nolock) on c.pool_id = e.pool_id and c.line_id = l.line_id  and c.is_deleted = 0
        left join [dbo].[pool_odds_change_c] o with(nolock) on o.pool_id = c.pool_id and o.line_id = c.line_id and o.combination_id = c.combination_id and o.is_deleted = 0
		left join EnumDataCTE bt on bt.EnumValue  = p.bet_type_code            
        where o.effective_datetime between '{start}' and '{end}' and e.is_deleted = 0
    """

_MARKET = """

WITH EnumDataCTE (EnumValue, EnumString) AS (
""" + _BET_TYPES + """
),

 BookmakerNameCTE (EnumValue, EnumString) AS (
""" + _BOOKMAKERS + """
)

   
   select 
        e.event_id [match_id], 
        p.bet_type_code,
        e.pool_id,
        l.line_id,
        l.line_label, 
        c.combination_id,
        c.combination_string, 
        o.bookmaker,
        o.odds, 
        o.effective_datetime
        , ed.EnumString bookmaker_str
        ,bn.EnumString bet_type_code_str
    from [dbo].[pool_event_leg_c] e with(nolock) 
        inner join [dbo].[pool_c] p with(nolock) on e.pool_id = p.pool_id 
        left join [dbo].[pool_line_c] l with(nolock) on l.pool_id = e.pool_id  
        left join [dbo].[pool_combination_c] c with(nolock) on c.pool_id = e.pool_id and c.line_id = l.line_id 
        left join [dbo].[pool_odds_external_change_c] o with(nolock) on o.pool_id = c.pool_id and o.line_id = c.line_id and o.combination_id = c.combination_id 
        left join BookmakerNameCTE ed on ed.EnumValue = p.bet_type_code
        left join EnumDataCTE bn on bn.EnumValue = o.bookmaker
    where o.effective_datetime between '{start}' and '{end}'
    and e.is_deleted = 0 and p.is_deleted = 0
    and l.is_deleted = 0 and c.is_deleted = 0 and o.is_deleted = 0

    """

_PARAMS = """
        select * from [QFM].[dbo].[algo_param]
        where EventTime between '{start}' and '{end}'
        order by EventLevel2ID, EventTime
    """


def _result(alias: str, result_type: int, stage_id: int, comment: str) -> str:
    return """							OUTER APPLY (
							-- {comment}
								select top 1 event_id,home_result_score, away_result_score
								from [dbo].[event_level2_result_c] r WITH (NOLOCK) 
								where r.event_id = m.event_id
								and r.result_type = {rt} and r.stage_id = {st}
								order by r.last_modified_datetime desc
							) AS {alias} 
""".format(comment=comment, rt=result_type, st=stage_id, alias=alias)


_MATCHES = """

    select 
							m.event_id [MatchId]
							,m.frontend_id [FrontendID]
							,m.parent_event_id [LeagueId]
							,CASE WHEN h.event_id IS NOT NULL THEN h.full_name_en ELSE c.full_name_en END [LeagueName]
							,CASE WHEN h.event_id IS NOT NULL THEN h.code ELSE c.code END [LeagueCode]
							,m.venue_id [VenueId]
							,venue.full_name_en [VenueName]
							,venue.code3 [Country]
							,CASE WHEN h.event_id IS NOT NULL THEN h.season ELSE c.season END [Season]
							,home.full_name_en [HomeName]
							,home.name_profile_id [HomeId]
							,away.full_name_en [AwayName]
							,away.name_profile_id [AwayId]
							,m.start_datetime [KOTime]
							,ISNULL(scoreft.home_result_score,-1) [HomeScoreFT]
							,ISNULL(scoreft.away_result_score,-1) [AwayScoreFT]
							,ISNULL(scoreht.home_result_score,-1) [HomeScoreHT]
							,ISNULL(scoreht.away_result_score,-1) [AwayScoreHT]
							,ISNULL(cornerft.home_result_score,-1) [HomeCornerFT]
							,ISNULL(cornerft.away_result_score,-1) [AwayCornerFT]
							,ISNULL(cornerht.home_result_score,-1) [HomeCornerHT]
							,ISNULL(cornerht.away_result_score,-1) [AwayCornerHT]
							,ISNULL(ycft.home_result_score,-1) [HomeYellowFT]
							,ISNULL(ycft.away_result_score,-1) [AwayYellowFT]
							,ISNULL(ycht.home_result_score,-1) [HomeYellowHT]
							,ISNULL(ycht.away_result_score,-1) [AwayYellowHT]
							,CASE 
								WHEN yrcft.home_result_score IS NULL AND rcft.home_result_score IS NULL THEN -1
								ELSE ISNULL(yrcft.home_result_score,0) + ISNULL(rcft.home_result_score,0)
							END [HomeRedFT]
							,CASE 
								WHEN yrcft.away_result_score IS NULL AND rcft.away_result_score IS NULL THEN -1
								ELSE ISNULL(yrcft.away_result_score,0) + ISNULL(rcft.away_result_score,0)
							END [AwayRedFT]
							,CASE 
								WHEN yrcht.home_result_score IS NULL AND rcht.home_result_score IS NULL THEN -1
								ELSE ISNULL(yrcht.home_result_score,0) + ISNULL(rcht.home_result_score,0)
							END [HomeRedHT]
							,CASE 
								WHEN yrcht.away_result_score IS NULL AND rcht.away_result_score IS NULL THEN -1
								ELSE ISNULL(yrcht.away_result_score,0) + ISNULL(rcht.away_result_score,0)
							END [AwayRedHT]
							,CASE 
								WHEN EXISTS (
									SELECT 1
									FROM [dbo].[event_op_status_change_c] b with(nolock)
									WHERE b.event_id = m.event_id         
									AND b.event_operation_status in (38,39,40,41,42,43)
								) 
								THEN CAST(1 AS bit)
								ELSE CAST(0 AS bit)
							END AS IsVoid
							from [dbo].[event_level2_profile_c] m WITH (NOLOCK)
							LEFT JOIN [dbo].[event_level1_profile_c] c WITH (NOLOCK) on m.parent_event_id =c.event_id -- Get cold event league code & league name
							LEFT JOIN [dbo].[event_level1_profile_h] h WITH (NOLOCK) on m.parent_event_id =h.event_id -- Get hot event league code & league name
							OUTER APPLY (
							-- Get latest version home team name 
								select top 1 full_name_en,name_profile_id 
								from [dbo].[event_participant] p WITH (NOLOCK) 
								where p.name_profile_id = m.home_participant_id
								order by p.name_profile_version desc
							) AS home 
							OUTER APPLY (
							-- Get latest version away team name
								select top 1 full_name_en,name_profile_id 
								from [dbo].[event_participant] p WITH (NOLOCK) 
								where p.name_profile_id = m.away_participant_id
								order by p.name_profile_version desc
							) AS away 
							OUTER APPLY (
							-- Get latest version venue
								select top 1 full_name_en,name_profile_id, code3
								from [dbo].[event_location] l WITH (NOLOCK) 
								where l.name_profile_id = m.venue_id
								order by l.name_profile_version desc
							) AS venue 
""" + "".join(_result(*r) for r in (
    ("scoreft", 1, 5, "Get FT score"), ("scoreht", 1, 3, "Get HT score"),
    ("cornerft", 2, 5, "Get FT corner"), ("cornerht", 2, 3, "Get HT corner"),
    ("ycft", 3, 5, "Get FT yellow card"), ("ycht", 3, 3, "Get HT yellow card"),
    ("yrcft", 4, 5, "Get FT yellow red card"), ("yrcht", 4, 3, "Get HT yellow red card"),
    ("rcft", 5, 5, "Get FT red card"), ("rcht", 5, 3, "Get HT red card"))) + """							OUTER APPLY (
							-- Get operation status
								select top 1 event_id, event_operation_status
								from [dbo].[event_op_status_change_c] ss WITH (NOLOCK) 
								where ss.event_id = m.event_id
								order by ss.status_last_modified_datetime desc
							) AS s 
							where m.start_datetime between '{start}' and '{end}'
							and (m.frontend_id is not null and m.frontend_id !='')

            
        
    """

_EVENTS = """
        SELECT * FROM [dbo].[event_level2_incident_c] 
        WHERE [incident_datetime] between '{start}' and '{end}'
    """

_POOLS = """
        SELECT *  FROM [bis1_fbuser_db].[dbo].[G2_pool_details] 
        WHERE [kickoff_date] between '{start}' and '{end}'
    """

_MONTH_SQL = {"odds": _ODDS, "market": _MARKET, "params": _PARAMS, "matches": _MATCHES, "events": _EVENTS,
              "pools": _POOLS}


def month_sql(table: str, start: str, end: str) -> str:
    """One monthly table's query for [start, end] ('YYYY-MM-01' strings, as the notebook writes them)."""
    return _MONTH_SQL[table].format(start=start, end=end)


# The archived bet databases by month; later months are in the current ones (the notebook's list).
DB_BUCKETS = (
    "202204_202208", "202209_202210", "202211_202212",
    "202301_202302", "202303_202304", "202305_202306", "202307_202308", "202309_202310", "202311_202312",
    "202401_202402", "202403_202404", "202405_202406", "202407_202408", "202409_202410", "202411_202412",
    "202501_202502", "202503_202504", "202505_202506", "202507_202508", "202509_202510", "202511_202512",
    "202601_202602",
)


def investments_databases(day) -> tuple:
    """(account, cash) bet databases holding ``day``'s month."""
    target = pd.Timestamp(day).strftime("%Y%m")
    for bucket in DB_BUCKETS:
        lo, hi = bucket.split("_")
        if lo <= target <= hi:
            return "fbis_fo_as_{}".format(bucket), "fbis_fo_cs_{}".format(bucket)
    return "fbis1_fo_as_db", "fbis1_fo_cs_db"


_INVESTMENTS_SETUP = """
    CREATE TABLE #id
    ( 
    pool_id bigint,
    pool_name nvarchar(10),
    pool_type nvarchar(3),
    match_id bigint,
    frontend_id nvarchar(6),
    tournament nvarchar(100),
    h_team nvarchar(100),
    a_team nvarchar(100),
    ht_home_score int,
    ht_away_score int,
    ft_home_score int,
    ft_away_score int,
    kickoff_date datetime,
    );
    insert into #id
    select pool_id,pool_name, pool_type, match_id, frontend_id, tournament, h_team, a_team, ht_home_score, ht_away_score
    ,ft_home_score,ft_away_score, kickoff_date
    from G2_pool_details with(nolock)
    where/* match_id in @MatchId
    and*/ pool_type not in ( 'SGA','TQL','MSP')
    and conclude_date between '{start}' and '{end}'
    
    CREATE TABLE #odds
    (
    	pool_id bigint,
    	comb_id int,
    	line_no nvarchar(10),
    	odds_id bigint,
    	sell_time_min datetime,
    	odds_combination nvarchar(100),
    	odds decimal(18,2),
    )
    INSERT INTO #odds
    select d.pool_id,d.comb_id, d.line_no,d.odds_id,time_changed [sell_time_min], max(odds_combination) [odds_combination], max( d.odds )[odds] 
    from
    [bis2_fo_fb_db].[dbo].[odds_detail] d
    inner join [{as_db}]..c_account_ord_fo_selections s on d.odds_id = s.odds_id and d.pool_id = s.pool_id and d.comb_id = s.comb_id and d.line_no = s.line_no
    where  d.pool_id in (select pool_id from #id)
    group by time_changed,d.pool_id,d.comb_id,d.line_no,d.odds_id
    
    
    
    CREATE TABLE #acc
    (
    	pool_id bigint, 
    	comb_id int,
    	line_no nvarchar(10),
    	odds_id bigint,
    	turnover decimal(18,2),
    	dividend decimal(18,2),
    	es_dividend decimal(18,2),
    	dt datetime,
    	ticket_count int,
    );
    insert into #acc
    select  b.pool_id,b.comb_id,b.line_no,b.odds_id, sum(a.turnover), sum(a.dividend), sum(b.es_dividend)
    , DATEADD(minute, DATEDIFF(minute, 0, a.sell_time), 0) [sell_time_min]
    , count(b.bet_id)
    from [{as_db}].dbo.c_account_ord_sales_payout a with(nolock),  [{as_db}]..c_account_ord_fo_selections b with(nolock)
    where a.ord_sales_id = b.ord_sales_id  and b.pool_id in (select pool_id from #id)
    group by DATEADD(minute, DATEDIFF(minute, 0, a.sell_time), 0) ,b.pool_id,b.comb_id,b.line_no,b.odds_id;
    
    CREATE TABLE #cs
    (
    	pool_id bigint, 
    	comb_id int,
    	line_no nvarchar(10),
    	odds_id bigint,
    	turnover decimal(18,2),
    	dividend decimal(18,2),
    	es_dividend decimal(18,2),
    	dt datetime,
    	ticket_count int,
    );
    insert into #acc
    select  b.pool_id,b.comb_id,b.line_no,b.odds_id, sum(a.turnover), sum(a.dividend), 0
    ,DATEADD(minute, DATEDIFF(minute, 0, a.sell_time), 0) [sell_time_min]
    , count(b.bet_id)
    
    from [{cs_db}].dbo.c_cash_ord_sales_payout a with(nolock)
    ,  [{cs_db}]..c_cash_ord_fo_selections b with(nolock)
    where a.ord_sales_id = b.ord_sales_id  and b.pool_id in (select pool_id from #id)
    group by  DATEADD(minute, DATEDIFF(minute, 0, a.sell_time), 0) ,b.pool_id,b.comb_id,b.line_no,b.odds_id;
    
    select a.pool_id, a.comb_id, a.line_no, a.odds_id, a.dt
    , sum(a.turnover) [turnover], sum(a.dividend) [dividend], sum(a.es_dividend)[es_dividend], sum(a.ticket_count)[ticket_count] into #tmp 
    from (
    select * from #acc
    union 
    select * from #cs
    ) a 
    group by a.pool_id, a.comb_id, a.line_no, a.odds_id,a.dt;
    """

INVESTMENTS_SELECT = """
    select a.*,t.dt [start_sell_time],t.comb_id,o.line_no,t.odds_id,t.turnover,t.dividend,t.es_dividend,o.odds_combination, o.odds,t.ticket_count
    from #id a
    left join #odds o on a.pool_id = o.pool_id 
    left join #tmp t on o.pool_id=t.pool_id and o.comb_id=t.comb_id and o.line_no=t.line_no and o.odds_id=t.odds_id
    where t.dt is not null
    """


def investments_setup_sql(start: str, end: str) -> str:
    """The temp tables for pools concluded in [start, end] ('YYYY-MM-DD'), on ``start``'s databases."""
    as_db, cs_db = investments_databases(start)
    return _INVESTMENTS_SETUP.format(start=start, end=end, as_db=as_db, cs_db=cs_db)


def read_month(conn, table: str, start: str, end: str) -> pd.DataFrame:
    return pd.read_sql(month_sql(table, start, end), conn, parse_dates=PARSE_DATES[table])


def read_investments_day(conn, start: str, end: str) -> pd.DataFrame:
    """The notebook's three steps on one connection: temp tables, the select, the drop. The drop also
    runs first and tolerates missing tables, so a run that failed half way cannot block the next."""
    _drop_temp(conn)
    cursor = conn.cursor()
    cursor.execute(investments_setup_sql(start, end))
    conn.commit()
    try:
        return pd.read_sql(INVESTMENTS_SELECT, conn, parse_dates=PARSE_DATES["investments"])
    finally:
        _drop_temp(conn)


def _drop_temp(conn) -> None:
    for name in ("#acc", "#cs", "#id", "#tmp", "#odds"):
        try:
            cursor = conn.cursor()
            cursor.execute("IF OBJECT_ID('tempdb..{0}') IS NOT NULL DROP TABLE {0};".format(name))
            conn.commit()
        except Exception:                                               # noqa: BLE001
            pass
