﻿<#
.SYNOPSIS
    Start Algo E - the API and the web server together.

.DESCRIPTION
    Runs FastAPI on 8001 and the Next server on 3000, waits until both
    answer, and opens the board. Closing this window stops both.

    The browser only ever talks to 3000; the web server proxies /api
    through to 8001. So 8001 does not need to be reachable from anywhere
    except this machine, and a colleague on the LAN can open the board at
    http://<this-machine>:3000 without any further configuration.

    The board and the cockpit read the W10 live engine, which starts with
    the API: its champion models come from AlgoE_Work beside
    ALGOE_DATA_DIR, and without one it serves last 5 minutes and says so.

.PARAMETER Source
    sim     internally consistent fake data - no database needed
    capture a previously recorded snapshot on disk
    sql     the live SQL Server, through the notebook's queries
            ("hkjc" and "live" mean the same thing)

.PARAMETER ApiPort / WebPort
    Override if something already owns 8001 or 3000.

.PARAMETER NoDataUpdate
    Do not start algoe-update-data.bat, even when Raw_Data is older than
    yesterday. Without it, stale data is brought up to date in its own
    window while the desk starts.

.EXAMPLE
    .\start.ps1                  # whatever config.py defaults to
    .\start.ps1 -Source sql      # live
    .\start.ps1 -Source sim      # demo with no database
#>

[CmdletBinding()]
param(
    [ValidateSet("sim", "capture", "sql", "hkjc", "live")]
    [string]$Source,
    [int]$ApiPort = 8001,
    [int]$WebPort = 3000,
    [switch]$NoBrowser,
    [switch]$NoDataUpdate
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot

function Fail($text) { Write-Host "`n$text`n" -ForegroundColor Red; exit 1 }
function Note($text) { Write-Host "    $text" -ForegroundColor DarkGray }

# --- prerequisites ---------------------------------------------------------
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { Fail "python is not on PATH." }
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) { Fail "node is not on PATH." }

function Test-PortFree($port) {
    -not (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
}
if (-not (Test-PortFree $ApiPort)) { Fail "port $ApiPort is already in use. Use -ApiPort." }
if (-not (Test-PortFree $WebPort)) { Fail "port $WebPort is already in use. Use -WebPort." }

if ($Source) { $env:ALGOE_SOURCE = $Source }
# Start the live engine with the API, so the first sweep of the card is under way before anyone
# opens a match. Its models are read from AlgoE_Work next to Raw_Data, as the algoe-*.bat do.
$env:ALGOE_LIVE = "1"
if (-not $env:ALGOE_DATA_DIR) { $env:ALGOE_DATA_DIR = "S:\Users\Yeung\20260520 Algo E\Raw_Data" }
$env:ALGOE_API_PORT = $ApiPort
# The web server reads this at start-up to know where to proxy /api.
$env:ALGOE_API_URL = "http://127.0.0.1:$ApiPort"
$env:PORT = $WebPort
$env:HOSTNAME = "0.0.0.0"

Write-Host "`nAlgo E" -ForegroundColor Cyan
Note ("source   {0}" -f ($(if ($Source) { $Source } else { "as configured" })))
Note "engine   W10 live, models from AlgoE_Work beside $env:ALGOE_DATA_DIR"
Note "api      http://127.0.0.1:$ApiPort"
Note "board    http://localhost:$WebPort"

# --- Raw_Data freshness ------------------------------------------------------
# Older than yesterday, or never updated: algoe-update-data.bat runs in its own window.
$updater = Join-Path $root "algoe-update-data.bat"
if (-not $NoDataUpdate -and (Test-Path $updater) -and (Test-Path $env:ALGOE_DATA_DIR)) {
    $statusFile = Join-Path $env:ALGOE_DATA_DIR "_algoe_update.json"
    $lockFile = Join-Path $env:ALGOE_DATA_DIR "_algoe_update.lock"
    $stale = $true
    $newest = "unknown (never updated by algoe-update-data.bat)"
    if (Test-Path $statusFile) {
        try {
            $status = Get-Content -LiteralPath $statusFile -Raw | ConvertFrom-Json
            if ($status.newest_day) { $newest = $status.newest_day }
            if ($status.ok -and $status.newest_day) {
                $day = [datetime]::ParseExact($status.newest_day, "yyyy-MM-dd", $null)
                $stale = $day -lt (Get-Date).Date.AddDays(-1)
            }
        }
        catch { }
    }
    # a running update touches its lock every minute; one untouched for 15 minutes was killed
    $running = (Test-Path $lockFile) -and ((Get-Item $lockFile).LastWriteTime -gt (Get-Date).AddMinutes(-15))
    if ($running) {
        Note "data     an update is already running"
    }
    elseif ($stale) {
        Note "data     newest day $newest - updating Raw_Data in its own window"
        Start-Process -FilePath $env:ComSpec -ArgumentList "/c", "`"`"$updater`"`""
    }
    else {
        Note "data     newest day $newest"
    }
}

# --- start -----------------------------------------------------------------
$jobs = @()
try {
    Write-Host "`nStarting the API..." -ForegroundColor Cyan
    $api = Start-Process -PassThru -NoNewWindow -FilePath "python" `
        -ArgumentList "-m", "uvicorn", "src.api.main:app",
                      "--host", "127.0.0.1", "--port", $ApiPort `
        -WorkingDirectory (Join-Path $root "backend")
    $jobs += $api

    # The first tick builds every score grid, so the API answers /health
    # well before it can answer /desk. Wait on health, not on the board.
    $ready = $false
    foreach ($attempt in 1..60) {
        Start-Sleep -Milliseconds 1000
        if ($api.HasExited) { Fail "the API exited on start-up (see above)." }
        try {
            $null = Invoke-RestMethod "http://127.0.0.1:$ApiPort/api/health" -TimeoutSec 3
            $ready = $true
            break
        }
        catch { }
    }
    if (-not $ready) { Fail "the API did not come up within 60s." }
    Note "api ready"

    Write-Host "Starting the board..." -ForegroundColor Cyan
    $web = Start-Process -PassThru -NoNewWindow -FilePath "node" `
        -ArgumentList "server.js" -WorkingDirectory (Join-Path $root "web")
    $jobs += $web

    $ready = $false
    foreach ($attempt in 1..30) {
        Start-Sleep -Milliseconds 1000
        if ($web.HasExited) { Fail "the web server exited on start-up." }
        try {
            $null = Invoke-WebRequest "http://127.0.0.1:$WebPort/" -TimeoutSec 3 -UseBasicParsing
            $ready = $true
            break
        }
        catch { }
    }
    if (-not $ready) { Fail "the web server did not come up within 30s." }
    Note "board ready"

    Write-Host "`n  Open http://localhost:$WebPort" -ForegroundColor Green
    Write-Host "  Ctrl+C to stop`n" -ForegroundColor DarkGray
    if (-not $NoBrowser) { Start-Process "http://localhost:$WebPort" }

    while ($true) {
        Start-Sleep -Seconds 2
        foreach ($p in $jobs) {
            if ($p.HasExited) {
                Write-Host "`na process exited - shutting down" -ForegroundColor Yellow
                return
            }
        }
    }
}
finally {
    Write-Host "Stopping..." -ForegroundColor DarkGray
    foreach ($p in $jobs) {
        if ($p -and -not $p.HasExited) {
            Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
        }
    }
}
