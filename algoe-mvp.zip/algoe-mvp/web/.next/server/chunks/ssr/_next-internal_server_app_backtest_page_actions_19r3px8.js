module.exports=[62997,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_backtest_page_actions_19r3px8.js.map