# Spec - publish TG/SUP and weightings to HKJC's pricing engine

W14, 2026-10-29. Folder: `BiWeekly Meetings/W14_2026-11-10_optimizer`.

## 1. Problem

HKJC's pricing engine (ServerAppID `E-HV11-01`) takes TG/SUP, a draw factor and per-selection
weightings for a match from a Kafka message and answers with every pool's true odds and sell
price (`CalcCurrentPrice`). Algo E has to set those parameters: every match every 5 minutes, and
every in-play match every 15 seconds.

- The live engine computes theta* and weightings but only shows them. Its focus refresh covers the
  matches the desk has open (at most 12), one at a time, 0.6-1.9 s each; `optimize_card` starts a
  process pool per call, which costs seconds on Windows.
- The optimiser moves 8 dimensions. The engine takes 4 (plus the draw factor) and derives the first
  half itself.
- `optimizer.draw_factor` is never read: the pricer prices goals with a draw factor of 1.0, and the
  panel does not carry `Goal90DrawFactor`.
- The desk shows our own prices. Once the engine prices our parameters, its prices are the real
  ones.

## 2. Outcome

- `publish.mode` (`ALGOE_PUBLISH`): `off` (default, exactly the W12 desk), `dry_run`, `test`,
  `shadow`, `live`.
- With publishing on, the sweep publishes every match with a decision and an in-play cycle
  refreshes and publishes every in-play match every 15 s, on a process pool kept for the engine's
  life.
- Replies are stored per match; the desk shows the engine's true and sell odds beside ours, E[GM] on
  the engine's prices, the replication gap, and the publish state. A kill switch on the board stops
  publishing.
- Everything runs end to end here on a file sink and a mock engine; the office runs `kafka-check`,
  then the test topic, then shadow.

## 3. Non-goals

- No change to the models or their training.
- No way for the desk to raise the mode or to turn production publishing on.
- No pricing of pools Algo E does not model: they are shown from the engine's reply only.
- No change to how the backtests price, unless a setting asks for it.

## 4. What the samples show

Transcribed from the two screenshots (2026-10-29) into `backend/tests/fixtures/kafka/`:
`params_message.json` (one message, byte for byte) and `prices_message.json` (the screenshot ends
after HHAD +2; the rest is not visible). The two samples are different events (50063165 and
50075870). The fits below assume the reply answers the sample's values (GoalTg 1.5, GoalSup 0.13,
CornerTg 8.0, CornerSup 0.3, DrawFactor 0.07): its HAD weights are the sample's.

| Fact | Evidence | Status |
|------|----------|--------|
| Publish: `EventId` int, `MsgId` `"MMSG_<n>"`, `Timestamp` `YYYY-MM-DDTHH:MM:SS` with no zone, `TgsupParameters` {GoalTg, GoalSup, CornerTg, CornerSup, DrawFactor}, `PoolWeightings` [{PoolType int, LineValue, Selections [{SelectionId int, Weight}]}], `GameState` int | sample | read |
| Numbers carry at most 2 decimals | sample | read; precision unconfirmed |
| Cadence in the sample: 17:20:12, 17:25:12, 17:30:12, 17:35:12, then every 10 s from 18:30:40; content unchanged; GameState 2 throughout | sample | read |
| Reply: `ServerAppID`, `EventId`, `MapResult` {EventID, GameState text, GameStageReference, CalculationID, GameClock {TimeInSecond, Minutes, Seconds, IsClockSet}, EventTime UTC `...Z`, PoolLinesShortDesc, Pools [{PoolId, PoolType text, InstanceNo, Lines [{LineId, LineLabel, LineValues, Combinations [{CombinationID, CombinationLabel, TrueOdds, CalcCurrentPrice, Weight}], Margin}]}]} | sample | read |
| The reply carries no MsgId | sample | read |
| PoolType text, CombinationID and CombinationLabel are our `pool_name`, `combination_id`, `combination_string` (HAD 1 H, 2 A, 3 D; HILO 1 H, 2 L) | sample vs Raw_Data | read |
| LineValues numeric; a quarter line is its mean (`"2.5/3"` 2.75); HDC is the home handicap (`"0/-0.5"` -0.25), as `panel.hdc_sign = home` | sample | read |
| TrueOdds are fair (sum of 1/TrueOdds = 1 per line); Margin = sum of 1/CalcCurrentPrice per line | sample | read |
| Weight 0.0 = no weight sent | every pool but HAD | inferred |
| CalcCurrentPrice 1.001 = not offered; 1.0 = floored | all of HAD (the weighted pool) and the short HHAD sides at 1.001 with ordinary true odds | inferred |
| PoolType 0 = HAD; SelectionId = CombinationID - 1 | the published HAD weights 1.05 / 0.95 / 1.0 come back on H / A / D | inferred |
| PoolType 1 = HILO | two selections at 2.5 fit HILO, but HILO 2.5 comes back with Weight 0.0 | contradicted |
| DrawFactor = `Goal90DrawFactor` - 1 | 0.07 as a multiplier is 0.36 off on HAD; 1.07 fits the full-match goal pools within 1.3 % (1.0: 2.9 %) | inferred |
| In play the engine decays TG by the clock itself | CHLO fits a negative binomial of mean 7.933 = 8.0 x (90 - 0.7) / 90 to 0.00003; with mean 8.0 the best is 0.008 | inferred, one reply |
| Corners are negative binomial, variance / mean 1.52 | same fit; our pricer is Poisson: 5.7 % off | inferred |
| Goals: our grid is 0.1-0.7 % off at the best fit; the first half is 0.43 x GoalTg at 0:42 (our in-play rule: 0.496) | fit | inferred |

## 5. Rules

| Rule | Detail |
|------|--------|
| Modes | `off`: nothing built or sent. `dry_run`: file sink `AlgoE_Work/publish/out/`, the mock engine answers into `publish/in/`. `test`: theta* to the test topics. `shadow`: HKJC's own theta as read, rounded to the engine's precision and nothing else (no search, no weights), to the production topics, only from a board read within `publish.shadow_max_board_age_seconds` (20); theta* to the test topics (`publish.shadow_test_copy`). `live`: theta* to production. |
| Production | `shadow` and `live` write to production and need `ALGOE_PUBLISH` set to that mode and `AlgoE_Work/publish/CONFIRM-PRODUCTION.txt` holding a line `allow: <mode>`. Anything less refuses to start (mode off, reason in the status) and the desk runs as with publishing off (all 8 dimensions, no in-play cycle). The desk can lower the mode (stop) and never raise it. |
| Mapping gate | `shadow` and `live` only send values whose mapping entry is `confirmed` (pool types, game states, draw factor, TG semantics). A pool type's `confirmed` covers its PoolType code and its SelectionIds. `dry_run` and `test` send unconfirmed entries and mark them in the audit. |
| Kafka settings | A test topic that is also a production topic refuses every Kafka mode and `kafka-check`. `kafka-check` reads replies in its own consumer group (`<group>-check`, or `--group`). The user name, password, keytab and principal are shown as set or not set only. |
| Cadence | The sweep (every bucket) publishes every match with a decision. With publishing on, an in-play cycle refreshes every in-play match every `publish.inplay_seconds` (15) and publishes each. A goal or red card still refreshes at once and publishes if in play. At most one message per match every `publish.min_interval_seconds` (10). A pre-match match opened on the desk is refreshed for display, not published. |
| In-play cycle | One fetch, one board of the moment, one feature pass, the sweep's bucket forecasts plus nowcast and event shift, one belief pass, `build_books`, then `optimize_card(mode="focus")` on a pool kept for the engine's life, inside `publish.inplay_budget_seconds`, richest first; matches not reached go first next cycle. The focus thread no longer refreshes in-play matches on its interval (requests and triggers still go first). The pool's workers end when the process that made it is gone (`start.ps1` stops the API with `Stop-Process -Force`, which never shuts the pool down). |
| What is sent | No book: nothing. Before the first message for a match, a kept-board decision sends nothing. After it, every cycle sends the current decision, HKJC's theta included (the only way the engine learns we went back). A decision on an older board than the last message's is never sent. HKJC's theta is the hand-back theta: Current as read, or, while Current follows our message (see Anchor), Current from the last read that did not (in play scaled by (90 - minute) / (90 - its minute)). |
| Dimensions | With publishing on the optimiser moves `publish.free_dims` (goal_tg, goal_sup, corner_tg, corner_sup). A first-half dimension that is not free follows its full-match one by HKJC's own ratio for the bucket (fh / ft in theta_now). Backtests keep all 8 by default. |
| Draw factor | From the newest `Goal90DrawFactor` of the match in the snapshot, converted by the mapping (`offset` -1.0). Not optimised. Missing: the match is not published. |
| TG in play | Mapping `tg_in_play`: `remaining` sends our theta as it is (HKJC's Current layer); `full_match` sends theta / ((90 - minute) / 90). Pre-match the two are the same. |
| Rounding | TG/SUP and the draw factor to `rounding.theta` decimals, weights to `rounding.weight` (2 / 2). theta* is priced again after rounding: bands, abs bounds and abs(SUP) <= TG hold; a line whose rounded weights break its overround (beyond `publish.weight_overround_tolerance`) or the line ladder goes back to 1.0. If E[GM] at the rounded values is below the board's, HKJC's theta is sent. |
| Weights | Only for pools the mapping names. Every selection of a (pool, line) ever weighted is sent, at 1.0 if no longer moved, while the match is under Algo E (an omitted weight might keep its value). |
| Guards | Before every send: finite values; each dimension inside its band and absolute bounds; abs(SUP) <= TG; weights inside the band; board read no older than `publish.max_board_age_seconds`; match not finished; match in scope; kill switch off. A refusal is audited with its reason. |
| Scope | `publish.scope_leagues`, `publish.scope_matches` (empty = all) and `publish.scope_percent` of the rest by a stable hash of the match id (A/B and 25 / 50 / 100 % rollout). |
| MsgId | `<publish.msg_id_prefix>_<n>`. The counter is reserved in blocks in `AlgoE_Work/publish/state.json` (atomic write), so a restart never repeats an id. Timestamp: the decision's as_of, Hong Kong time, no zone. |
| Kill switch | `POST /api/live/publish/stop` (or the board button) writes `AlgoE_Work/publish/STOPPED`; nothing is sent while it exists, across restarts. `resume` deletes it and returns to the configured mode. A message already being handed to the transport when the stop lands still goes (at most one per sending thread); the audit shows it. |
| Replies | Matched to our newest message for the EventId sent in the last `publish.reply_timeout_seconds` x 3; otherwise stored as "not ours". A reply computed more than `publish.reply_order_slack_seconds` (2) before our newest message was sent cannot answer it: it answers the newest earlier message sent before it (the last 4 per target are kept), else it is not ours. When it was computed is its EventTime on the engine's clock, read on ours by the 10th percentile of the receive delays of the last 200 replies to our matches (one odd stamp cannot set it); the rule waits for 20 replies, so a box whose clock is off still matches, and once it applies a reply with no EventTime answers nothing. The engine answers every match on one topic: a reply for a match Algo E has not sent to that target is counted (`other_events`) and not read. A message whose delivery failed, or that the kill switch held back, leaves the match's pending and history, so no reply passes for its answer. Nothing is sent before the reply consumer holds its partitions, and it keeps no group offsets: every start reads from the newest reply. A production reply from a ServerAppID outside `publish.server_app_ids` (`E-HV11-01`; empty = any) is audited and dropped. Each reply is read against the book, rows, header and decision of the message it answers. Shadow's two targets keep their own state; the match shows the worse. Stored per match: received time, EventTime, ServerAppID, the MsgId answered, every selection's true odds, sell odds, weight and margin, joined to the book by (pool_id, line_id, combination_id), else (pool, line value, label). |
| E[GM] on the engine | `gm_engine` = E[GM] with our belief and our demand at the engine's sell prices (not-offered selections take no money). |
| Revert guard | `publish.revert_guard` (on): `gm_engine < gm_board - publish.revert_tolerance` flags the match; for `publish.revert_minutes` it sends the hand-back theta and weights 1.0. A late reply (answering an earlier message) never reverts. |
| Replication gap | Per selection: 1 / TrueOdds against our pricer at the published theta. Per pool the largest and the mean. First-half pools under both split readings, pre-match. Above `publish.gap_alert` an alert. |
| Weight echo | Every weight sent must come back as the reply's Weight for that selection; otherwise "mapping mismatch" (the pool type or selection id is wrong). |
| Triggers | When the engine answers our message, the main-line reference of the price-move trigger becomes the engine's sell prices: a board move we caused does not refresh the match again. |
| Clock and state | The reply's GameClock against our clock (more than `publish.clock_tolerance_seconds` off) and its GameState against our phase: a mismatch is flagged. |
| No reply | No reply within `publish.reply_timeout_seconds`: the match reads "no response", counted in the health. |
| Anchor | `optimizer.anchor_layer`: `current` (default), `basis` / `model` (the snapshot's Goal90/Corner90 Basis or Model layer; in play scaled by (90 - minute) / 90), `first_seen` (HKJC's theta at the last refresh before our first message, scaled the same way). The trust band is drawn around it; HKJC's posted theta stays the start and the fallback. After each message the next read of Current is compared with what we sent: "Current follows our message" is counted. |
| Audit | `AlgoE_Work/publish/audit/<YYYYMMDD-HH>.jsonl.gz`, one row per message out, refusal and reply in (summaries: theta now / star / sent, weights moved, E[GM] board / star / sent / engine, gap, delivery, latency), and a `feedback` row per reply read on the book (gm_engine against the board, gap, echo, revert, notes). Raw replies only with `publish.audit_raw`. Files older than `publish.audit_days` are deleted. |

## 6. Acceptance criteria

| # | Criterion | Proof |
|---|-----------|-------|
| AC1 | `build_params_message` on the sample's inputs returns the sample byte for byte. | unit test on the fixture |
| AC2 | `parse_prices_message` reads the reply sample: 7 pools, 34 lines, 73 selections, each with its ids, true odds, sell, weight, margin, offered. A missing or mistyped field raises with its path. | unit test on the fixture |
| AC3 | Unknown pool types and labels are left out of the message and listed; an unknown game state refuses the message. | unit test |
| AC4 | Rounded theta* keeps every guard; a line whose rounded weights break the overround or ladder goes back to 1.0; E[GM] below the board sends HKJC's theta. | unit test |
| AC5 | MsgIds never repeat after a restart. | unit test |
| AC6 | `live` and `shadow` refuse without both the env mode and the confirmation file; the desk's resume never raises the mode; the kill switch survives a restart. | unit test |
| AC7 | Scope: allowlists and a stable percentage. | unit test |
| AC8 | The mock engine answers in the exact reply format; the full loop (publish, reply, engine prices, gm_engine, gap, echo) runs in memory. | unit test |
| AC9 | With FT dims only, first-half theta follows full-match theta by HKJC's ratio; with all 8 the result is unchanged. | unit test |
| AC10 | The in-play cycle covers every in-play match; one match through the cycle gives the decision a focus refresh gives. | unit test |
| AC11 | 40 in-play matches per cycle in under 10 s on this laptop, simulator. | timed test |
| AC12 | Revert guard, trigger suppression, clock / state check and the no-reply state each fire on a constructed case. | unit test |
| AC13 | `/api/live/publish/status|stop|resume`; the cockpit's selections carry the engine fields; contract, tsc, lint and build pass; the board strip and kill switch work in the browser. | contract + browser |
| AC14 | `kafka-check` refuses without the env, never prints a secret, lists each broker at the address it gives, sends nothing to a topic it cannot see or to a broker that gives localhost, reads replies without keeping a group offset, and in test mode sends one message to the test topic and prints the first reply computed after it (newer than the match's newest reply before the send, and not computed before the send by its clock against the box's). | unit test (no broker here) |
| AC15 | Selftest S13 runs the loop on the mock engine with the replication gap and both first-half readings. | selftest |
| AC16 | Off is the W12 desk: the existing tests and the selftest pass unchanged. | test run |
| AC17 | Shadow sends production HKJC's theta rounded and no weights, round after round, even when theta* weights went to the test topic and HKJC's theta is off the engine's grid; a board older than `publish.shadow_max_board_age_seconds` goes to the test topic only. | unit test |
| AC18 | A reply computed before our newest message answers the one before it, or none; a production reply from another ServerAppID is dropped; a reply is read against its message's book; each reply read leaves a feedback row in the audit. | unit test |
| AC19 | Test topics equal to production topics refuse to start; `kafka-check` uses its own consumer group and never prints the user name, password, keytab or principal. | unit test |
| AC20 | While Current follows our theta*, it is counted, and a revert or a kept board sends the hand-back theta. | unit test |
| AC21 | A refused production mode runs the desk as off (all 8 dimensions, no in-play source); first-half weights stop at half time. | unit test |

## 7. Interfaces

- `backend/src/hkjc/kafka_messages.py` (no algoe import): `load_mapping(path=None)`,
  `build_params_message(event_id, msg_id, ts, theta, draw_factor, weights_rows, game_state, mapping)`
  returning `(message, notes)`, `encode(message)`, `parse_prices_message(raw, mapping)`,
  `MessageError`, `MappingError`.
- `backend/src/hkjc/kafka_mapping.json`: the shipped mapping; `AlgoE_Work/config/kafka_mapping.json`
  overrides it when present (the office's confirmed copy survives a code update).
- `backend/src/hkjc/kafka_transport.py`: `MemoryTransport`, `FileTransport(root, responder=None)`,
  `KafkaTransport(config)` (imports `confluent_kafka` on first use), `kafka_config_from_env()`; each
  has `send(topic, key, value)`, `poll(timeout)`, `flush()`, `close()`.
- `backend/algoe/realtime/mock_engine.py`: `MockEngine(settings, mapping, lookup).reply(message)`.
- `backend/algoe/realtime/publisher.py`: `PublishPolicy`, `Publisher` (`consider`, `on_reply`,
  `stop`, `resume`, `status`), the consumer thread.
- `LiveEngine.run_inplay_cycle(as_of=None)`, `LiveEngine.on_engine_prices(reply)`.
- `ThetaOptimizer(settings, demand, free_dims=None)`, `optimize_card(..., executor=None, first=None)`,
  `quantize(book, decision, theta_decimals, weight_decimals)`, `quantize_board(book, theta_decimals, hold=None)`.
- Settings: `publish.*` (new section), `optimizer.anchor_layer`.
- API: `GET /api/live/publish/status`, `POST /api/live/publish/stop`, `POST /api/live/publish/resume`;
  selection fields `engine_true_odds`, `engine_sell_odds`, `engine_weight`, `engine_margin`,
  `engine_at`, `engine_state`; cockpit `publish` block; board row `publish`, board `publish` strip.
- CLI `python -m algoe kafka-check [--send]`, `deploy/algoe-7-kafka-check.bat`,
  `deploy/kafka.example.cmd`, `backend/requirements-kafka.txt`.
- Environment, office box only: `ALGOE_PUBLISH`; `ALGOE_KAFKA_BOOTSTRAP`,
  `ALGOE_KAFKA_TOPIC_PARAMS`, `ALGOE_KAFKA_TOPIC_PRICES`, `ALGOE_KAFKA_TEST_TOPIC_PARAMS`,
  `ALGOE_KAFKA_TEST_TOPIC_PRICES`, `ALGOE_KAFKA_GROUP`, `ALGOE_KAFKA_SECURITY_PROTOCOL`,
  `ALGOE_KAFKA_SASL_MECHANISM`, `ALGOE_KAFKA_USERNAME`, `ALGOE_KAFKA_PASSWORD`,
  `ALGOE_KAFKA_KEYTAB`, `ALGOE_KAFKA_PRINCIPAL`, `ALGOE_KAFKA_CA_FILE`. Secrets are read from the
  environment only and never logged; no endpoint or topic is in the code or the zips.

## 8. Edge cases

- A reply for a match we never published, or after the window: stored as not ours.
- Two replies for one message: the newer EventTime wins.
- A reply for a match no longer on the card: audited, not stored.
- A pool type the mapping does not name comes back: shown in the cockpit from the reply only.
- The engine answers a selection with 1.001: not offered; E[GM] gives it no money.
- The broker is down: sends fail and are audited; the desk shows "no response"; the loop goes on.
- The kill switch is pressed during a cycle: the messages already built are not sent.
- Half time: the first half is settled; FH weights are not sent; the clock check allows the break.
- The sweep and the in-play cycle refresh the same match: the newer board wins, and only it is sent.

## 9. Open questions (for the Kafka / engine owner)

| # | Question | Blocks |
|---|----------|--------|
| O1 | The PoolType numbers for every pool (HAD = 0 inferred; HILO = 1 contradicted by the reply). | weights other than HAD |
| O2 | The SelectionId per label for each pool (HAD H 0, A 1, D 2 inferred). | weights |
| O3 | The GameState numbers (2 seen, read as FirstHalf). | every message in shadow / live |
| O4 | DrawFactor scale (inferred `Goal90DrawFactor` - 1). Goals only? | shadow / live |
| O5 | In play, does the engine want the full-match TG (it seems to decay it by the clock) or the goals still to come? | test results in play |
| O6 | How the engine derives the first half from the full match (0.43 x GoalTg seen at 0:42). | first-half E[GM] |
| O7 | Corner distribution (negative binomial 1.52 seen) and the goal model. | replication |
| O8 | What a weight multiplies (we assume the sell price); is an omitted weight 1.0 or the last one; which pools accept weights; why HAD came back at 1.001 with weights. | weights |
| O9 | Precision accepted for TG/SUP and weights (the sample has 2 decimals; our weights are within 1 +- 0.03). | rounding |
| O10 | Is the reply a proposal or the live price? Does our message overwrite algo_param Current? | live; the anchor |
| O11 | Who wins when a trader changes TG/SUP while we publish every 15 s; how a match is handed back. | live |
| O12 | Correlation: the reply has no MsgId; CalculationID? Expected delay, a rejection's format, replies we did not trigger. | reply matching |
| O13 | Rate and size limits; a message every cycle when nothing changed; pause on suspension? | cadence |
| O14 | Bootstrap servers, topics (test and production), security protocol, SASL mechanism, CA, consumer group. | test |
| O15 | Shadow writes HKJC's own theta to production: can that undo a trader's newer change? Or should shadow log only? | shadow on production |
| O16 | Can a params message name the state it was decided on (a CalculationID or version), so the engine refuses a write based on an older one? Between our read and our send (up to 20 s in shadow, about 15 s in play) a trader may change TG/SUP, and after a goal that matters most. | shadow / live on production |

## 10. Risks

- The engine's rules (first-half derivation, corner distribution, weight meaning, in-play TG) differ
  from our pricer's; theta* is only as good as that match. The replication gap measures it.
- Capacity on a busy night on the office box: the cycle's timings are in `/api/live/publish/status`.
- Feedback once live: the anchor, the belief and the training data (section 5 of the plan).
- Organisational approval for live publishing, and who is responsible for prices we change.
