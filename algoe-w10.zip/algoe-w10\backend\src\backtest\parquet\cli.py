"""Command-line backtest: Raw_Data -> Backtest_Data, one day at a time, with a full log.

No web page. Every step prints what it read, what it computed and what file it
wrote, with a timestamp and the time since start, so a slow step looks slow
rather than hung. The same lines go to Backtest_Data/logs/run_<time>.log.

For each day, in date order:

    1  read     Raw_Data for the day (a month is read once, then reused)
    2  panel    one row per selection per 5-minute bucket, prices at the START
                of the bucket
    3  features what was known at T, for the turnover model
    4  forecast last 5 min, and the model fitted on earlier days only
    5  write    Backtest_Data/index, Turnover/*, True_Prob/*, one file each
    6  score    turnover and true-probability scores for the day
    7  train    after the warm-up, refit on the days so far and explain the fit

Files, next to Raw_Data:

    Backtest_Data/index/YYYY-MM-DD.parquet                       row identity
    Backtest_Data/Turnover/actual/YYYY-MM-DD.parquet             money in the bucket
    Backtest_Data/Turnover/last5min/YYYY-MM-DD.parquet           baseline: previous bucket
    Backtest_Data/Turnover/glm/YYYY-MM-DD.parquet                trained model
    Backtest_Data/Turnover/ma3, ema, zero, oracle/...            other references
    Backtest_Data/True_Prob/actual/YYYY-MM-DD.parquet            settled result
    Backtest_Data/True_Prob/inverse_hkjc_true_odds/...           1 / HKJC true odds
    Backtest_Data/True_Prob/poisson, demargin (+ calibrated)/... other beliefs
    Backtest_Data/Features_glm2/YYYY-MM-DD.sel|match.parquet     model inputs
    Backtest_Data/models/glm_after_YYYY-MM-DD.json               every refit, in full
    Backtest_Data/daily_summary.csv                              one line per day
    Backtest_Data/logs/run_<time>.log                            this log

    python -m src.backtest.parquet.cli run --data-dir "S:\\Users\\Yeung\\20260520 Algo E\\Raw_Data"
    python -m src.backtest.parquet.cli selftest
"""
from __future__ import annotations

import argparse
import csv
import json
import platform
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from . import book
from .adapter import DEFAULT_CALIBRATORS, _Calibration, to_facts
from .beliefs import SOURCES
from .cache import day_list
from .config import Config
from .glm_turnover import (
    MATCH_FEATURES, SHARE_FEATURES, TwoLevel, _sample_groups, _with_match_y,
    build_day_features, poisson_dev,
)
from .loader import load_static, load_window
from .panel import MonthCache, build_day, start_odds
from .raw_turnover import KEY, _int_keys, backtest_root, wape

MODEL = "glm"
RAW_FOLDERS = ("Match_Investments", "HKJC_Odds", "Market_Odds", "HKJC_Parameters",
               "Match_Events", "Pool_Details", "Match_Information")

TEXT = {
    "m_log_l1": "match money, last 5 min (log)", "m_log_l2": "match money, 5-10 min ago (log)",
    "m_log_l3": "match money, 10-15 min ago (log)", "m_any_l1": "match took money last 5 min",
    "m_log_today": "match money so far today (log)", "inplay": "in play",
    "halftime": "half-time", "pre_ko_clip": "minutes to kick-off", "minute_clip": "match minute",
    "goal_p3": "goal pulse, 3-min decay", "goal_p10": "goal pulse, 10-min decay",
    "red_p10": "red-card pulse", "goals_so_far": "goals so far", "n_live": "matches live",
    "log_board_l1": "all matches' money, last 5 min (log)",
    "match_share_board_l1": "this match's share of the board, last 5 min",
    "weekend": "weekend", "holiday": "HK holiday", "tg": "TG", "abs_sup": "|SUP|",
    "n_pools_open": "pools open", "n_lines_open": "lines open",
    "s_share_l1": "own share of match money, last 5 min", "s_share_l2": "own share, 5-10 min ago",
    "s_share_l3": "own share, 10-15 min ago", "s_share_ewma": "own share, weighted",
    "s_log_l1": "own money last 5 min (log)", "s_any_l1": "own money last 5 min > 0",
    "pos_share_l1": "share of the same line position, last 5 min",
    "pos_share_l2": "share of the same line position, 5-10 min ago",
    "best_moved": "best line just moved", "line_age": "minutes since the line opened",
    "rank_0": "best line", "rank_1": "2nd line", "rank_2": "3rd line", "rank_3p": "4th line or further",
    "n_lines": "lines in the pool", "imp": "1 / HKJC odds", "log_odds": "log HKJC odds",
    "true_imp": "1 / HKJC true odds", "hk_vs_mkt": "HKJC minus market implied prob",
    "has_mkt": "market price known", "odds_move_5": "odds change, last 5 min",
    "odds_move_15": "odds change, last 15 min", "near_main": "line within 0.5 of TG/SUP",
    "abs_line_gap": "|line - TG/SUP|", "first_half": "first-half bet",
}


# ------------------------------------------------------------------- log
class Log:
    def __init__(self, path: Path):
        self.t0 = time.time()
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.fh = path.open("a", encoding="utf-8")

    def __call__(self, msg: str = "") -> None:
        el = int(time.time() - self.t0)
        stamp = "[{} +{:02d}:{:02d}:{:02d}]".format(time.strftime("%H:%M:%S"), el // 3600, el % 3600 // 60, el % 60)
        for line in str(msg).splitlines() or [""]:
            out = "{} {}".format(stamp, line)
            print(out, flush=True)
            self.fh.write(out + "\n")
        self.fh.flush()

    def section(self, title: str) -> None:
        self("=" * 100)
        self(title)
        self("=" * 100)

    def step(self, n, title: str) -> float:
        self("")
        self("-- step {}: {}".format(n, title))
        return time.time()

    def done(self, t: float, what: str = "done") -> None:
        self("   {} in {:.1f}s".format(what, time.time() - t))


def _money(v) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "n/a"
    return "{:,.0f}".format(v)


def _pct(v) -> str:
    return "n/a" if v is None or not np.isfinite(v) else "{:.1%}".format(v)


def _table(log: Log, head: Sequence[str], rows: List[Sequence], widths: Optional[Sequence[int]] = None) -> None:
    widths = widths or [max(len(str(h)), *(len(str(r[i])) for r in rows)) if rows else len(str(h))
                        for i, h in enumerate(head)]
    fmt = "   " + "  ".join("{:<%d}" % w if i == 0 else "{:>%d}" % w for i, w in enumerate(widths))
    log(fmt.format(*head))
    log("   " + "  ".join("-" * w for w in widths))
    for r in rows:
        log(fmt.format(*[str(x) for x in r]))


# ------------------------------------------------------------ scoring
def turnover_scores(y, pred, last5, match_id, bucket) -> dict:
    y = np.asarray(y, dtype="float64")
    out = {"actual": float(y.sum())}
    g = pd.DataFrame({"m": match_id, "b": bucket, "y": y})
    for name, p in (("last5", last5), ("model", pred)):
        p = np.asarray(p, dtype="float64")
        g[name] = p
        out["sum_" + name] = float(p.sum())
        out["bias_" + name] = float(p.sum() / y.sum() - 1) if y.sum() > 0 else None
        out["wape_sel_" + name] = wape(y, p)
        out["dev_" + name] = poisson_dev(y, p)
    agg = g.groupby(["m", "b"], observed=True)[["y", "last5", "model"]].sum()
    out["wape_match_last5"] = wape(agg["y"], agg["last5"])
    out["wape_match_model"] = wape(agg["y"], agg["model"])
    return out


def prob_scores(facts: pd.DataFrame) -> Dict[str, dict]:
    """Settled rows only. Each row is one selection in one bucket; weight = its money."""
    from src.backtest.settle import outcome_y
    res = pd.to_numeric(facts.get("result"), errors="coerce")
    ok = res.notna()
    if not ok.any():
        return {}
    y = res[ok].map(outcome_y)
    keep = y.notna()
    y = y[keep].to_numpy(dtype="float64")
    w = pd.to_numeric(facts.loc[ok, "t_actual"], errors="coerce").fillna(0.0)[keep].to_numpy(dtype="float64")
    out = {}
    for label, col in (("inverse_hkjc_true_odds", "p__hkjc_true__raw"), ("poisson", "p__poisson__raw"),
                       ("demargin", "p__demargin__raw")):
        if col not in facts.columns:
            continue
        p = pd.to_numeric(facts.loc[ok, col], errors="coerce")[keep].to_numpy(dtype="float64")
        good = np.isfinite(p)
        if not good.any():
            continue
        pp = np.clip(p[good], 1e-6, 1 - 1e-6)
        yy, ww = y[good], w[good]
        ll = -(yy * np.log(pp) + (1 - yy) * np.log(1 - pp))
        bins = np.clip((pp * 10).astype(int), 0, 9)
        ece = 0.0
        for b in range(10):
            s = bins == b
            if s.any():
                ece += s.mean() * abs(pp[s].mean() - yy[s].mean())
        wsum = ww.sum()
        out[label] = {
            "rows": int(good.sum()), "logloss": float(ll.mean()), "brier": float(((pp - yy) ** 2).mean()),
            "ece": float(ece), "mean_p": float(pp.mean()), "mean_outcome": float(yy.mean()),
            "money_logloss": float((ll * ww).sum() / wsum) if wsum > 0 else None,
        }
    return out


# ------------------------------------------------------------ explain a fit
def _coef_rows(glm: dict, names: Sequence[str], top: int = 12) -> List[Sequence]:
    """Effect of one standard deviation of each input, as a multiplier."""
    beta = glm["beta"][1:]
    order = np.argsort(-np.abs(beta))[:top]
    rows = []
    for i in order:
        n = names[i]
        mult = float(np.exp(beta[i]))
        rows.append([TEXT.get(n, n)[:48], n[:20], "{:+.3f}".format(beta[i]),
                     "x{:.2f}".format(mult), "{:.3g}".format(glm["std"][i])])
    return rows


def explain_fit(log: Log, m: TwoLevel, info: dict) -> None:
    mg, sg = m.match_glm, m.share_glm
    log("   training window : {} day(s) fitted, {} day(s) held back to choose the blend".format(
        info["fit_days"], info["inner_days"]))
    log("   training days   : {} .. {}".format(info["first_day"], info["last_day"]))
    log("")
    log("   LEVEL 1  match total per 5 min  (Tweedie GLM, power {}, log link, ridge)".format(mg["power"]))
    log("   rows (match-buckets) {:,}   iterations {}   deviance {:.1f} -> {:.1f}   explained {}".format(
        mg["rows"], len(mg["trace"]), mg["null_deviance"], mg["deviance"], _pct(mg["explained"])))
    log("   IRLS trace: " + "  ".join("{}:{:.1f}".format(t["iter"], t["deviance"]) for t in mg["trace"][:12]))
    log("   biggest effects (per 1 std of the input; x1.20 = 20% more money):")
    _table(log, ["input", "column", "beta", "effect", "1 std ="], _coef_rows(mg, MATCH_FEATURES))
    if m.league:
        lg = sorted(m.league.items(), key=lambda kv: -kv[1])
        log("   league random effect, shrunk to 1 ({} leagues). Highest and lowest:".format(len(lg)))
        log("     " + "  ".join("{} x{:.2f}".format(k, v) for k, v in lg[:6]))
        log("     " + "  ".join("{} x{:.2f}".format(k, v) for k, v in lg[-6:]))
    log("")
    log("   LEVEL 2  how the match's money splits  (Poisson GLM, offset = log match total)")
    log("   rows (selection-buckets on the board at T) {:,}   iterations {}   explained {}".format(
        sg["rows"], len(sg["trace"]), _pct(sg["explained"])))
    _table(log, ["input", "column", "beta", "effect", "1 std ="], _coef_rows(sg, SHARE_FEATURES))
    if m.pool:
        log("   bet-type random effect, shrunk to its family (|pre = before kick-off, |ip = in play):")
        items = sorted(m.pool.items(), key=lambda kv: -kv[1])
        for i in range(0, len(items), 6):
            log("     " + "  ".join("{} x{:.2f}".format(k, v) for k, v in items[i:i + 6]))
    log("")
    log("   BLEND  forecast = w x model + (1 - w) x last 5 min, w chosen on the held-back days")
    log("   by Poisson deviance (lower is better; it scores the mean, which expected margin needs):")
    sc = info.get("inner_scores") or {}
    if sc:
        _table(log, ["w", "deviance"], [[k, "{:,.1f}".format(v)] for k, v in sc.items()])
    log("   chosen w = {}{}".format(m.alpha, "  (0 means the model did not beat last 5 min)" if m.alpha == 0 else ""))


def refit(store: List[dict], inner_days: int) -> (TwoLevel, dict):
    inner_n = min(inner_days, max(len(store) - 1, 0))
    fit = store[:len(store) - inner_n] or store
    inner = store[len(store) - inner_n:] if inner_n else []
    m = TwoLevel()
    m.fit(pd.concat([d["match"] for d in fit], ignore_index=True),
          pd.concat([d["sel"] for d in fit], ignore_index=True))
    scores = {}
    if inner:
        m.alpha = 1.0
        scores = m.pick_alpha(pd.concat([d["sel"] for d in inner], ignore_index=True),
                              pd.concat([d["match"] for d in inner], ignore_index=True))
    return m, {"fit_days": len(fit), "inner_days": len(inner), "inner_scores": scores,
               "first_day": fit[0]["day"], "last_day": fit[-1]["day"]}


def save_model(path: Path, m: TwoLevel, info: dict) -> None:
    def glm(g, names):
        return {"power": g["power"], "rows": g["rows"], "deviance": g["deviance"],
                "null_deviance": g["null_deviance"], "explained": g["explained"], "trace": g["trace"],
                "coef_per_std": dict(zip(["intercept"] + list(names), np.round(g["beta"], 6).tolist())),
                "input_mean": dict(zip(names, np.round(g["mean"], 6).tolist())),
                "input_std": dict(zip(names, np.round(g["std"], 6).tolist()))}
    payload = {"info": info, "blend_weight": m.alpha, "level1_match_total": glm(m.match_glm, MATCH_FEATURES),
               "level2_share": glm(m.share_glm, SHARE_FEATURES), "league_effect": m.league,
               "pool_effect": m.pool, "feature_text": TEXT}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=float), encoding="utf-8")


# ------------------------------------------------------------ helpers
def _attach_model(facts: pd.DataFrame, keyed: pd.DataFrame) -> np.ndarray:
    """Model forecast for each index row, by selection and bucket; last 5 min where absent."""
    parts = facts["label_key"].astype(str).str.split(":", n=3, expand=True)
    left = pd.DataFrame({
        "match_id": pd.to_numeric(parts[0], errors="coerce"),
        "pool_name": parts[1].astype("string").str.upper(),
        "line_id": pd.to_numeric(parts[2], errors="coerce"),
        "combination_id": pd.to_numeric(parts[3], errors="coerce"),
        "bucket": pd.to_datetime(facts["as_of"]).astype("datetime64[ns]"),
        "_pos": np.arange(len(facts)),
    })
    left = _int_keys(left)
    k = _int_keys(keyed.copy())
    k["bucket"] = pd.to_datetime(k["bucket"]).astype("datetime64[ns]")
    m = left.merge(k.drop_duplicates(KEY + ["bucket"]), on=KEY + ["bucket"], how="left").sort_values("_pos")
    v = m["value"].to_numpy(dtype="float64")
    last5 = pd.to_numeric(facts["t5m"], errors="coerce").fillna(0.0).to_numpy(dtype="float64")
    return np.where(np.isfinite(v), v, last5), int(np.isfinite(v).sum())


def check_raw(log: Log, data_dir: Path) -> None:
    rows = []
    for sub in RAW_FOLDERS:
        p = data_dir / sub
        files = sorted(p.glob("*.parquet")) if p.is_dir() else []
        size = sum(f.stat().st_size for f in files) / 1e6
        rows.append([sub, "yes" if p.is_dir() else "MISSING", len(files), "{:,.1f}".format(size),
                     files[0].name[:34] if files else "", files[-1].name[:34] if files else ""])
    _table(log, ["folder", "found", "files", "MB", "first file", "last file"], rows)
    if any(r[1] == "MISSING" for r in rows[:2]):
        raise SystemExit("Match_Investments and HKJC_Odds are required in {}".format(data_dir))


# ------------------------------------------------------------ run
def run(cfg: Config, calibrators: Sequence[str] = ("raw",) + tuple(DEFAULT_CALIBRATORS[1:]),
        warmup_days: int = 14, inner_days: int = 7, refit_every: int = 7,
        per_day: int = 60000, seed: int = 7) -> dict:
    root = backtest_root(cfg)
    root.mkdir(parents=True, exist_ok=True)
    log = Log(root / "logs" / "run_{}.log".format(time.strftime("%Y%m%d_%H%M%S")))
    cache = SimpleNamespace(cfg=cfg, root=root.parent)
    days = day_list(cfg.start_date, cfg.end_date)
    calibrators = list(dict.fromkeys(["raw"] + [c for c in calibrators if c != "raw"]))

    log.section("ALGO E  command-line backtest")
    log("python   {}   pandas {}   numpy {}   {}".format(platform.python_version(), pd.__version__,
                                                          np.__version__, platform.platform()))
    log("raw data {}".format(cfg.data_dir))
    log("writing  {}".format(root))
    log("log file {}".format(log.path))
    log("window   {} .. {}  ({} days)".format(cfg.start_date, cfg.end_date, len(days)))
    log("pools    {}".format(", ".join(cfg.pools) if cfg.pools else "all"))
    log("pre-match window {} min before kick-off; in-play always included".format(cfg.prematch_window_min))
    log("model    '{}': warm-up {} days (writes last 5 min), then refit every {} days on all earlier days,"
        .format(MODEL, warmup_days, refit_every))
    log("         last {} of them held back to choose the blend with last 5 min".format(inner_days))
    log("")
    log("Raw_Data folders:")
    check_raw(log, Path(cfg.data_dir))
    from .loader import has_true_odds
    if has_true_odds(Path(cfg.data_dir)):
        log("HKJC_Odds has a true_odds column: 1 / HKJC true odds will be scored")
    else:
        log("WARNING  HKJC_Odds has NO true_odds column. True_Prob/inverse_hkjc_true_odds will be empty,")
        log("         and p_true falls back to Poisson on TG/SUP, then to de-margined public odds.")

    t = log.step(0, "Pool_Details and Match_Information (read once)")
    pools_df, matches_df = load_static(cfg.data_dir, days[0], days[-1] + pd.Timedelta(days=1))
    log("   pools {:,}   matches {:,}".format(len(pools_df), len(matches_df)))
    log.done(t)

    summary_path = root / "daily_summary.csv"
    summary_cols = ["day", "status", "rows", "modelled_rows", "matches", "actual", "last5", "model",
                    "wape_match_last5", "wape_match_model", "wape_sel_last5", "wape_sel_model",
                    "dev_last5", "dev_model", "bias_last5", "bias_model", "blend_w",
                    "settled_rows", "ece_inv_true_odds", "logloss_inv_true_odds", "ece_demargin",
                    "seconds"]
    # one run, one summary: a rerun starts the file again
    sfh = summary_path.open("w", newline="", encoding="utf-8")
    writer = csv.DictWriter(sfh, fieldnames=summary_cols)
    writer.writeheader()
    sfh.flush()
    log("   {} started (one line per day, open it in Excel any time)".format(summary_path))

    rng = np.random.default_rng(seed)
    model: Optional[TwoLevel] = None
    model_info: dict = {}
    store: List[dict] = []
    since = 0
    prev_odds = None
    book_carry = None
    cal = _Calibration(SOURCES, calibrators)
    written_days: List[str] = []
    totals = {"y": 0.0, "l": 0.0, "m": 0.0, "ml": 0.0, "mm": 0.0, "n": 0, "dl": 0.0, "dm": 0.0}

    by_month: Dict[pd.Timestamp, List[pd.Timestamp]] = {}
    for d in days:
        by_month.setdefault(d.to_period("M").start_time, []).append(d)
    k_day = 0
    for m_start, want in by_month.items():
        m_end = m_start + pd.offsets.MonthBegin(1)
        log.section("MONTH {:%Y-%m}: reading Raw_Data once for {} day(s)".format(m_start, len(want)))
        t = log.step(1, "read Raw_Data {:%Y-%m-%d} .. {:%Y-%m-%d} (plus {} day(s) look-back for prices)".format(
            min(want), m_end - pd.Timedelta(days=1), cfg.lookback_days))
        mc = MonthCache(cfg, min(want), m_end)
        log("   HKJC_Odds {:,} rows   Match_Investments {:,} rows   HKJC_Parameters {:,}   Match_Events {:,}"
            .format(len(mc.odds), len(mc.inv), len(mc.params), len(mc.events)))
        log("   selections seen {:,}   money buckets {:,}".format(len(mc.keys), len(mc.agg)))
        try:
            market = load_window(cfg.data_dir, "market", min(want) - pd.Timedelta(days=cfg.lookback_days), m_end)
            log("   Market_Odds {:,} rows".format(len(market)))
        except Exception as exc:                                          # noqa: BLE001
            market = pd.DataFrame()
            log("   Market_Odds not read ({}); HKJC-vs-market feature is 0".format(exc))
        log.done(t, "month read")

        for day in want:
            k_day += 1
            key = "{:%Y-%m-%d}".format(day)
            t_day = time.time()
            log.section("DAY {}  ({} of {})".format(key, k_day, len(days)))

            t = log.step(2, "panel: selection x 5-min bucket, prices at the start of each bucket")
            base = build_day(cfg, day, mc, pools_df, matches_df, prices=False)
            if base is None or base.empty:
                log("   no rows for this day (no live pools). Nothing written.")
                writer.writerow({"day": key, "status": "empty", "seconds": round(time.time() - t_day, 1)})
                sfh.flush()
                continue
            end_odds = pd.to_numeric(base["odds"], errors="coerce").to_numpy()
            base = start_odds(cfg, base, prev_odds)
            moved = int((~np.isclose(pd.to_numeric(base["odds"], errors="coerce").to_numpy(), end_odds,
                                     equal_nan=True)).sum())
            fresh = int((~base["priced_before"].astype(bool)).sum())
            log("   rows {:,}   matches {:,}   pools {:,}   money today {}".format(
                len(base), base["match_id"].nunique(), base["pool_id"].nunique(), _money(base["turnover"].sum())))
            log("   {:,} rows use an earlier price than the one posted inside the bucket".format(moved))
            log("   {:,} rows are lines first priced inside their bucket (not on the board at T)".format(fresh))
            tru = pd.to_numeric(base.get("true_odds"), errors="coerce")
            src = base["p_source"].astype(str).value_counts(normalize=True) if "p_source" in base.columns else {}
            log("   true odds on {:.1%} of rows; p_true source: {}".format(
                float((tru > 1).mean()) if tru is not None else 0.0,
                "  ".join("{} {:.0%}".format(k, v) for k, v in dict(src).items())))
            log.done(t)

            t = log.step(3, "features known at T")
            sel, match, prev_odds = build_day_features(cfg, day, mc, pools_df, matches_df, market,
                                                       prev_odds, base=base)
            mod = sel["modelled"].to_numpy(dtype=bool)
            log("   selection rows {:,}: modelled {:,}   not modelled {:,} (first priced inside T, or"
                " outside the pre-match window; these keep last 5 min)".format(
                    len(sel), int(mod.sum()), int((~mod).sum())))
            log("   match-buckets {:,}   with a market price {:.0%} of modelled rows".format(
                len(match), float(sel.loc[mod, "has_mkt"].mean()) if mod.any() else 0.0))
            fdir = root / "Features_glm2"
            fdir.mkdir(parents=True, exist_ok=True)
            sel.to_parquet(fdir / "{}.sel.parquet".format(key), index=False)
            match.to_parquet(fdir / "{}.match.parquet".format(key), index=False)
            log("   wrote {}".format(fdir / "{}.sel.parquet".format(key)))
            log("   wrote {}".format(fdir / "{}.match.parquet".format(key)))
            log.done(t)

            t = log.step(4, "forecast")
            last5 = sel["last5"].to_numpy(dtype="float64")
            if model is None:
                pred = np.clip(last5, 0, None)
                log("   warm-up day {} of {}: no model yet, '{}' = last 5 min".format(len(store) + 1, warmup_days, MODEL))
                status = "warmup"
            else:
                pred = model.predict(sel, match)
                log("   model fitted on {} .. {}, blend w = {} (w x model + (1 - w) x last 5 min)".format(
                    model_info["first_day"], model_info["last_day"], model.alpha))
                status = "scored"
            keyed = sel[KEY + ["bucket"]].copy()
            keyed["value"] = pred.astype("float32")
            log.done(t)

            t = log.step(5, "write Backtest_Data files (row i is the same selection-bucket in every file)")
            stated, book_carry = book.restate_lags(base, book_carry)
            facts = to_facts(book._keep(stated))
            facts["t_hat__persistence"] = pd.to_numeric(facts["t5m"], errors="coerce").fillna(0.0)
            facts["t_hat__{}".format(MODEL)], hit = _attach_model(facts, keyed)
            cal.transform(facts)
            cal.observe(facts)
            facts = facts.drop(columns=[c for c in facts.columns if c.startswith("p_src__")])
            book._write_day(cache, day, facts)
            log("   index rows {:,} (rows that took money, had money last bucket, or settled);"
                " model matched {:,}".format(len(facts), hit))
            log("   {}".format(book._index_path(cache, day)))
            for fam in ("turnover", "true_prob"):
                for name in book._folder_names(cache, fam):
                    p = book._series_path(cache, fam, name, day)
                    if not p.exists():
                        continue
                    if p.stat().st_mtime >= t_day:
                        log("   {}".format(p))
                    else:
                        # left by an earlier run with a different row order
                        p.unlink()
                        log("   removed stale {} (not in this run's row order)".format(p))
            written_days.append(key)
            meta = book._read_meta(cache)
            have = set(meta.get("days") or []) if meta.get("version") == book.VERSION else set()
            have.add(key)
            book._write_meta(cache, {"version": book.VERSION, "calibrators": calibrators,
                                     "days": sorted(have), "source": "cli"})
            log.done(t)

            t = log.step(6, "score the day")
            sc = turnover_scores(sel["y"].to_numpy(), pred, last5, sel["match_id"].to_numpy(), sel["bucket"].to_numpy())
            log("   TURNOVER  every selection-bucket of the day ({:,} rows)".format(len(sel)))
            _table(log, ["", "actual", "last 5 min", MODEL], [
                ["total money", _money(sc["actual"]), _money(sc["sum_last5"]), _money(sc["sum_model"])],
                ["bias", "", _pct(sc["bias_last5"]), _pct(sc["bias_model"])],
                ["WAPE per match-bucket", "", _pct(sc["wape_match_last5"]), _pct(sc["wape_match_model"])],
                ["WAPE per selection", "", _pct(sc["wape_sel_last5"]), _pct(sc["wape_sel_model"])],
                ["Poisson deviance", "", "{:,.1f}".format(sc["dev_last5"]), "{:,.1f}".format(sc["dev_model"])],
            ])
            g = pd.DataFrame({"m": sel["match_id"].to_numpy(), "y": sel["y"].to_numpy(dtype="float64"),
                              "l": last5, "p": pred}).groupby("m")[["y", "l", "p"]].sum() \
                .sort_values("y", ascending=False).head(5)
            if len(g):
                log("   top matches by money today:")
                _table(log, ["match", "actual", "last 5 min", MODEL], [
                    [int(i), _money(r.y), _money(r.l), _money(r.p)] for i, r in g.iterrows()])
            ps = prob_scores(facts)
            if ps:
                log("   TRUE PROB  settled rows (result known)")
                _table(log, ["belief", "rows", "log-loss", "Brier", "ECE", "mean p", "outcome"], [
                    [k, "{:,}".format(v["rows"]), "{:.4f}".format(v["logloss"]), "{:.4f}".format(v["brier"]),
                     _pct(v["ece"]), "{:.3f}".format(v["mean_p"]), "{:.3f}".format(v["mean_outcome"])]
                    for k, v in ps.items()])
            else:
                log("   TRUE PROB  no settled rows yet for this day")
            if status == "scored":
                totals["y"] += sc["actual"]
                totals["l"] += sc["wape_sel_last5"] * sc["actual"]
                totals["m"] += sc["wape_sel_model"] * sc["actual"]
                totals["ml"] += sc["wape_match_last5"] * sc["actual"]
                totals["mm"] += sc["wape_match_model"] * sc["actual"]
                totals["dl"] += sc["dev_last5"] * len(sel)
                totals["dm"] += sc["dev_model"] * len(sel)
                totals["n"] += len(sel)
            inv = ps.get("inverse_hkjc_true_odds", {})
            writer.writerow({
                "day": key, "status": status, "rows": len(sel), "modelled_rows": int(mod.sum()),
                "matches": int(sel["match_id"].nunique()), "actual": round(sc["actual"], 2),
                "last5": round(sc["sum_last5"], 2), "model": round(sc["sum_model"], 2),
                "wape_match_last5": round(sc["wape_match_last5"], 5), "wape_match_model": round(sc["wape_match_model"], 5),
                "wape_sel_last5": round(sc["wape_sel_last5"], 5), "wape_sel_model": round(sc["wape_sel_model"], 5),
                "dev_last5": round(sc["dev_last5"], 3), "dev_model": round(sc["dev_model"], 3),
                "bias_last5": sc["bias_last5"], "bias_model": sc["bias_model"],
                "blend_w": None if model is None else model.alpha,
                "settled_rows": inv.get("rows"), "ece_inv_true_odds": inv.get("ece"),
                "logloss_inv_true_odds": inv.get("logloss"),
                "ece_demargin": ps.get("demargin", {}).get("ece"),
                "seconds": round(time.time() - t_day, 1),
            })
            sfh.flush()
            log("   appended {}".format(summary_path))
            log.done(t)

            t = log.step(7, "train")
            store.append({"day": key, "sel": _with_match_y(_sample_groups(sel, per_day, rng), match),
                          "match": match})
            since += 1
            if len(store) < warmup_days:
                log("   warm-up: {} of {} days stored; the first fit happens after day {}".format(
                    len(store), warmup_days, warmup_days))
            elif model is not None and since < refit_every:
                log("   keep the current fit; next refit in {} day(s)".format(refit_every - since))
            else:
                log("   refit on {} day(s) ({:,} match-buckets, {:,} selection rows sampled as whole match-buckets)"
                    .format(len(store), sum(len(d["match"]) for d in store), sum(len(d["sel"]) for d in store)))
                model, model_info = refit(store, inner_days)
                since = 0
                explain_fit(log, model, model_info)
                mp = root / "models" / "glm_after_{}.json".format(key)
                save_model(mp, model, model_info)
                log("   wrote {}".format(mp))
            log.done(t)
            log("DAY {} finished in {:.1f}s".format(key, time.time() - t_day))
        mc = None
        market = None

    sfh.close()
    log.section("SUMMARY over scored days (after warm-up)")
    rep = {"days_written": written_days, "log": str(log.path), "summary_csv": str(summary_path)}
    if totals["y"] > 0:
        rep.update({
            "wape_match_last5": totals["ml"] / totals["y"], "wape_match_model": totals["mm"] / totals["y"],
            "wape_sel_last5": totals["l"] / totals["y"], "wape_sel_model": totals["m"] / totals["y"],
            "dev_last5": totals["dl"] / totals["n"], "dev_model": totals["dm"] / totals["n"],
        })
        _table(log, ["", "last 5 min", MODEL], [
            ["WAPE per match-bucket", _pct(rep["wape_match_last5"]), _pct(rep["wape_match_model"])],
            ["WAPE per selection", _pct(rep["wape_sel_last5"]), _pct(rep["wape_sel_model"])],
            ["Poisson deviance", "{:,.1f}".format(rep["dev_last5"]), "{:,.1f}".format(rep["dev_model"])],
        ])
    else:
        log("no day was scored: the window is shorter than the {}-day warm-up".format(warmup_days))
    log("")
    log("files are in {}".format(root))
    log("one line per day: {}".format(summary_path))
    log("every refit, in full: {}".format(root / "models"))
    (root / "summary.json").write_text(json.dumps(rep, indent=2, default=float), encoding="utf-8")
    return rep


# ------------------------------------------------------------ selftest
def selftest() -> None:
    import shutil
    import tempfile
    from .selftest import make_fixture

    tmp = Path(tempfile.mkdtemp(prefix="algoe_cli_"))
    try:
        raw = tmp / "Raw_Data"
        make_fixture(raw, days=6, matches_per_day=5, start="2026-07-01")
        cfg = Config(data_dir=raw, start_date="2026-07-01", end_date="2026-07-06", pools=[],
                     prematch_window_min=180)
        rep = run(cfg, warmup_days=3, inner_days=1, refit_every=2, per_day=20000)
        root = backtest_root(cfg)
        need = [root / "index" / "2026-07-06.parquet",
                root / "Turnover" / "actual" / "2026-07-06.parquet",
                root / "Turnover" / "last5min" / "2026-07-06.parquet",
                root / "Turnover" / MODEL / "2026-07-06.parquet",
                root / "True_Prob" / "actual" / "2026-07-06.parquet",
                root / "True_Prob" / "inverse_hkjc_true_odds" / "2026-07-06.parquet",
                root / "daily_summary.csv", root / "summary.json"]
        missing = [str(p) for p in need if not p.exists()]
        if missing:
            raise SystemExit("[cli selftest] FAIL: missing {}".format(missing))
        if not list((root / "models").glob("glm_after_*.json")):
            raise SystemExit("[cli selftest] FAIL: no model file")
        n = len(pd.read_parquet(root / "index" / "2026-07-06.parquet"))
        for p in need[1:6]:
            if len(pd.read_parquet(p)) != n:
                raise SystemExit("[cli selftest] FAIL: {} is not aligned with the index".format(p))
        csv_rows = pd.read_csv(root / "daily_summary.csv")
        if len(csv_rows) != 6 or (csv_rows["status"] == "scored").sum() == 0:
            raise SystemExit("[cli selftest] FAIL: daily_summary.csv {}".format(csv_rows["status"].tolist()))
        # the web page reads the same files
        facts, _ = book.load_compare(SimpleNamespace(cfg=cfg, root=root.parent, has_day=lambda d: False),
                                     cfg.start_date, cfg.end_date, ["raw", "shrink", "isotonic"])
        if "t_hat__{}".format(MODEL) not in facts.columns:
            raise SystemExit("[cli selftest] FAIL: the backtest page would not see '{}'".format(MODEL))
        print("[cli selftest] PASS  match WAPE last5 {:.1%}  {} {:.1%}".format(
            rep["wape_match_last5"], MODEL, rep["wape_match_model"]), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["run", "selftest"])
    p.add_argument("--data-dir", default=r"S:\Users\Yeung\20260520 Algo E\Raw_Data")
    p.add_argument("--start", default="2026-07-01")
    p.add_argument("--end", default="2026-09-15")
    p.add_argument("--warmup-days", type=int, default=14)
    p.add_argument("--inner-days", type=int, default=7)
    p.add_argument("--refit-every", type=int, default=7)
    p.add_argument("--per-day", type=int, default=60000, help="selection rows kept per day for training")
    p.add_argument("--prematch-window-min", type=int, default=360)
    p.add_argument("--out-dir", default="",
                   help="write Backtest_Data here instead of next to Raw_Data, e.g. a local D:\\ folder;"
                        " a network share is slower for every file")
    a = p.parse_args(argv)
    if a.command == "selftest":
        selftest()
        return
    if a.out_dir:
        import os
        os.environ["ALGOE_BACKTEST_DATA"] = str(Path(a.out_dir))
    cfg = Config(data_dir=Path(a.data_dir), start_date=a.start, end_date=a.end, pools=[],
                 prematch_window_min=a.prematch_window_min)
    run(cfg, warmup_days=a.warmup_days, inner_days=a.inner_days, refit_every=a.refit_every,
        per_day=a.per_day)


if __name__ == "__main__":
    main()
