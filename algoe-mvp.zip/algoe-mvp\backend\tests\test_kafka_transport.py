"""
Kafka transport tests - memory, file and Kafka transports, the environment, the mock engine

    python tests/test_kafka_transport.py       plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_kafka_transport.py

No broker: the Kafka transport is checked for what it does without one.

Change Log:
-----------
2026-10-29      Initialize
"""

import json
import math
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

KEY = ["pool_id", "line_id", "combination_id"]


def _match_rows():
    """One match as the live engine keeps it (MatchLive.rows): HAD, two HILO lines, HDC, FHLO, CHLO."""
    spec = [  # pool_id, line_id, pool, label, domain, market, line_label, line, side
        (11, 1, "HAD", "H", "goal", "three_way", None, np.nan, "H"),
        (11, 1, "HAD", "A", "goal", "three_way", None, np.nan, "A"),
        (11, 1, "HAD", "D", "goal", "three_way", None, np.nan, "D"),
        (12, 1, "HILO", "H", "goal", "total", "2.5", 2.5, "H"),
        (12, 1, "HILO", "L", "goal", "total", "2.5", 2.5, "A"),
        (12, 2, "HILO", "H", "goal", "total", "2.5/3", 2.75, "H"),
        (12, 2, "HILO", "L", "goal", "total", "2.5/3", 2.75, "A"),
        (13, 1, "HDC", "H", "goal", "handicap", "0/-0.5", -0.25, "H"),
        (13, 1, "HDC", "A", "goal", "handicap", "0/-0.5", -0.25, "A"),
        (14, 1, "FHLO", "H", "goal_fh", "total", "1.5", 1.5, "H"),
        (14, 1, "FHLO", "L", "goal_fh", "total", "1.5", 1.5, "A"),
        (15, 1, "CHLO", "H", "corner", "total", "13.5", 13.5, "H"),
        (15, 1, "CHLO", "L", "corner", "total", "13.5", 13.5, "A"),
    ]
    rows = pd.DataFrame(spec, columns=["pool_id", "line_id", "pool_name", "combination_string", "theta_domain",
                                       "market", "line_label", "line", "side"])
    rows["combination_id"] = rows.groupby(["pool_id", "line_id"]).cumcount() + 1
    rows["match_id"] = 777
    return rows


HEADER = {"phase": "first_half", "minute": 30.0, "in_play": True, "score": [1, 0], "corners": [3, 2],
          "splits": {"goal": 0.45, "corner": 0.46}, "game_state": "FirstHalf"}
THETA = {"goal_tg": 1.4, "goal_sup": 0.2, "corner_tg": 6.5, "corner_sup": 0.4}


# ---------------------------------------------------------------- memory
def test_memory_transport_answers_with_its_responder():
    from src.hkjc.kafka_transport import MemoryTransport
    t = MemoryTransport(responder=lambda v: v.upper())
    t.send("params", 7, "abc", tag="M1")
    got = t.poll()
    assert [(r.value, r.key) for r in got] == [("ABC", "7")] and t.poll() == []
    assert [(d.tag, d.ok) for d in t.deliveries()] == [("M1", True)] and t.deliveries() == []
    t.fail = "broker down"
    t.send("params", 7, "abc", tag="M2")
    assert [(d.tag, d.ok, d.error) for d in t.deliveries()] == [("M2", False, "broker down")]


# ------------------------------------------------------------------ file
def test_file_transport_writes_wire_lines_and_reads_each_reply_once():
    from src.hkjc.kafka_transport import FileTransport
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "in").mkdir()
        day = pd.Timestamp.now().strftime("%Y%m%d")
        (Path(tmp) / "in" / "{}.jsonl".format(day)).write_text('{"old": 1}\n', encoding="utf-8")
        t = FileTransport(tmp, responder=lambda v: '{"reply": %s}' % v)
        t.send("params", 1, '{"a":1}', tag="M1")
        t.send("params", 1, '{"a":2}', tag="M2")
        out = (Path(tmp) / "out" / "{}.jsonl".format(day)).read_text(encoding="utf-8")
        assert out == '{"a":1}\n{"a":2}\n'
        assert [json.loads(r.value)["reply"]["a"] for r in t.poll()] == [1, 2]       # not the earlier run's
        assert t.poll() == []
        with open(Path(tmp) / "in" / "{}.jsonl".format(day), "a", encoding="utf-8") as fh:
            fh.write('{"half"')
        assert t.poll() == []                                                         # a line being written
        with open(Path(tmp) / "in" / "{}.jsonl".format(day), "a", encoding="utf-8") as fh:
            fh.write(': 1}\n')
        assert [r.value for r in t.poll()] == ['{"half": 1}']
        assert [d.tag for d in t.deliveries()] == ["M1", "M2"]


# ----------------------------------------------------------------- kafka
def test_kafka_transport_without_the_library_says_how_to_install():
    from src.hkjc import kafka_transport as kt
    saved = sys.modules.get("confluent_kafka")
    sys.modules["confluent_kafka"] = None
    try:
        t = kt.KafkaTransport(kt.KafkaConfig({"bootstrap": "b:9092"}), ["prices"])
        try:
            t.send("params", 1, "{}")
        except kt.TransportError as exc:
            assert "requirements-kafka.txt" in str(exc)
        else:
            raise AssertionError("no error without confluent_kafka")
    finally:
        if saved is None:
            sys.modules.pop("confluent_kafka", None)
        else:
            sys.modules["confluent_kafka"] = saved


def test_kafka_config_from_env_lists_what_is_missing_and_hides_secrets():
    from src.hkjc import kafka_transport as kt
    env = {"ALGOE_KAFKA_BOOTSTRAP": "broker-a:9093,broker-b:9093", "ALGOE_KAFKA_SASL_MECHANISM": "SCRAM-SHA-512",
           "ALGOE_KAFKA_SECURITY_PROTOCOL": "SASL_SSL", "ALGOE_KAFKA_USERNAME": "algoe",
           "ALGOE_KAFKA_PASSWORD": "s3cret-value", "ALGOE_KAFKA_TOPIC_PARAMS": "p", "ALGOE_KAFKA_TOPIC_PRICES": "q",
           "ALGOE_KAFKA_EXTRA": '{"socket.timeout.ms": 9000}'}
    c = kt.kafka_config_from_env(env)
    assert c.missing(["production"]) == []
    assert c.missing(["test"]) == ["ALGOE_KAFKA_TEST_TOPIC_PARAMS", "ALGOE_KAFKA_TEST_TOPIC_PRICES"]
    shown = json.dumps(c.describe())
    assert "s3cret-value" not in shown and c.describe()["ALGOE_KAFKA_PASSWORD"] == "(set)"
    conf = c.librdkafka()
    assert (conf["sasl.username"], conf["acks"], conf["socket.timeout.ms"]) == ("algoe", "all", 9000)
    cons = c.librdkafka(consumer=True)
    assert cons["auto.offset.reset"] == "latest" and "acks" not in cons
    no_pw = kt.kafka_config_from_env({k: v for k, v in env.items() if k != "ALGOE_KAFKA_PASSWORD"})
    assert no_pw.missing(["production"]) == ["ALGOE_KAFKA_PASSWORD"]
    try:
        kt.kafka_config_from_env({"ALGOE_KAFKA_EXTRA": "[1, 2"})
    except kt.TransportError:
        pass
    else:
        raise AssertionError("bad ALGOE_KAFKA_EXTRA accepted")


def test_the_login_is_never_shown_and_a_test_topic_may_not_be_a_production_topic():
    import tempfile
    from algoe.realtime.publisher import build_transport
    from algoe.settings import Settings
    from src.hkjc import kafka_transport as kt
    from src.hkjc.kafka_messages import load_mapping
    env = {"ALGOE_KAFKA_BOOTSTRAP": "b:9093", "ALGOE_KAFKA_SASL_MECHANISM": "GSSAPI", "ALGOE_KAFKA_USERNAME": "svc-u7",
           "ALGOE_KAFKA_PASSWORD": "pw-9", "ALGOE_KAFKA_KEYTAB": r"C:\keys\svc-k7.keytab",
           "ALGOE_KAFKA_PRINCIPAL": "svc-p7@HKJC", "ALGOE_KAFKA_TOPIC_PARAMS": "p.params",
           "ALGOE_KAFKA_TOPIC_PRICES": "p.prices", "ALGOE_KAFKA_TEST_TOPIC_PARAMS": "p.params",
           "ALGOE_KAFKA_TEST_TOPIC_PRICES": "t.prices"}
    c = kt.kafka_config_from_env(env)
    shown = json.dumps(c.describe())
    assert not any(s in shown for s in ("svc-u7", "pw-9", "svc-k7", "svc-p7")), shown
    assert c.overlap() == ["p.params"]
    assert kt.kafka_config_from_env(dict(env, ALGOE_KAFKA_TEST_TOPIC_PARAMS="t.params")).overlap() == []
    with tempfile.TemporaryDirectory() as tmp:
        for mode in ("test", "shadow", "live"):
            try:
                build_transport(Settings(), load_mapping(), mode, tmp, None, env=env)
            except kt.TransportError as exc:
                assert "p.params" in str(exc) and "production" in str(exc), exc
            else:
                raise AssertionError("{}: a test topic that is a production topic was accepted".format(mode))


# ----------------------------------------------------------- mock engine
def _mock(rows=None, header=None, **kw):
    from algoe.realtime.mock_engine import MockEngine
    from algoe.settings import Settings
    from src.hkjc.kafka_messages import load_mapping
    rows = _match_rows() if rows is None else rows
    lookup = (lambda mid: (rows, header or HEADER) if mid == 777 else None)
    return MockEngine(Settings(), load_mapping(), lookup, clock=lambda: pd.Timestamp("2026-10-29 20:15:30.25"), **kw)


def _message(weights):
    from src.hkjc.kafka_messages import build_params_message, encode, load_mapping
    msg, _ = build_params_message(777, "ALGOE_1", pd.Timestamp("2026-10-29 20:15:30"), THETA, 1.06, weights,
                                  "FirstHalf", load_mapping(), minute=30.0, in_play=True)
    return encode(msg)


def test_mock_engine_replies_in_the_engine_format_with_our_prices():
    from algoe.pricing.pricer import BookPricer, BookRows, Conventions, MatchState, theta_from_params
    from algoe.settings import Settings
    from src.hkjc.kafka_messages import load_mapping, parse_prices_message
    weights = [("HAD", np.nan, "H", 1.02), ("HAD", np.nan, "A", 0.98), ("HAD", np.nan, "D", 1.0)]
    reply = _mock().reply(_message(weights))
    r = parse_prices_message(reply, load_mapping())
    assert (r.server_app_id, r.event_id, r.game_state, r.clock_seconds) == ("ALGOE-MOCK", 777, "FirstHalf", 1800)
    assert r.event_time == pd.Timestamp("2026-10-29 20:15:30.250")
    f = r.frame()
    rows = _match_rows()
    assert sorted(map(tuple, f[KEY].to_numpy().tolist())) == sorted(map(tuple, rows[KEY].to_numpy().tolist()))
    st = MatchState(home_goals=1, away_goals=0, home_corners=3, away_corners=2, minute=30.0, phase="first_half")
    th = theta_from_params(1.4, 0.2, 6.5, 0.4, 0.45, 0.46, st)
    o = Settings().optimizer
    p, _ = BookPricer(Conventions(o.settle_total, o.settle_handicap, draw_factor=1.06)).probabilities(
        BookRows(rows["theta_domain"], rows["market"], rows["line"].to_numpy(dtype="float64"), rows["side"]), th, st)
    merged = rows.assign(p=p).merge(f, on=KEY)
    assert np.allclose(merged["true_odds"], 1.0 / merged["p"], rtol=1e-5)
    had = merged[merged["pool_name"] == "HAD"].set_index("label")
    assert had.loc["H", "weight"] == 1.02 and had.loc["A", "weight"] == 0.98
    assert (merged.loc[merged["pool_name"] != "HAD", "weight"] == 0.0).all()
    assert (merged["sell_odds"] <= merged["true_odds"]).all()
    for _, g in merged.groupby(["pool_id", "line_id"]):
        assert math.isclose(g["margin"].iloc[0], (1.0 / g["sell_odds"]).sum(), abs_tol=1e-4)


def test_mock_engine_negative_binomial_corners_and_silence_on_unknown_matches():
    from src.hkjc.kafka_messages import load_mapping, parse_prices_message
    m = load_mapping()
    poisson = parse_prices_message(_mock().reply(_message([])), m).frame()
    wide = parse_prices_message(_mock(corner_dispersion=1.5).reply(_message([])), m).frame()
    over = lambda f: float(f[(f["pool_type"] == "CHLO") & (f["label"] == "H")]["true_odds"].iloc[0])  # noqa: E731
    assert over(wide) < over(poisson)                       # 13.5 is above the 11.5 expected: a wider count
    #                                                         makes the over likelier
    msg = json.loads(_message([]))
    msg["EventId"] = 1
    assert _mock().reply(json.dumps(msg)) is None


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
