"""
Step 08 - the live engine

Every 5-minute bucket: the whole card (forecast, belief, theta* for every
match with enough money, richest first, inside the time budget). Every ~15 s:
the matches in focus (opened on the desk, or a trigger fired - goal, red
card, a main-line price jump, a big bet): the money already in this bucket
updates the remaining-bucket forecast, and theta* is re-optimised from its
last answer.

    python scripts/s08_live.py --source sql                   the office feed
    python scripts/s08_live.py --source sql --focus 1234567   keep one match in focus
    python scripts/s08_live.py --source replay --at "2026-09-10 20:00" --speed 10
                                                              rehearse an evening from Raw_Data
    python scripts/s08_live.py --source sim --once            one sweep on the simulator

Same as: python -m algoe live
"""
from _algoe import run

if __name__ == "__main__":
    run("live")
