"""Audit what the optimizer wrote to Backtest_Data/Optimizer.

Reads the solved files and checks, bucket by bucket:

  1. TG/SUP stayed within 1 of HKJC's.
  2. Every selection's 1/odds stayed within 5 points of the board.
  3. Expected margin is recomputed from the prices and matches what was stored.
  4. The solved price is never worse than HKJC's own TG/SUP priced the same way.
     If it is, the solver missed; that is a bug, not a result.
  5. How often the lift against the board is positive, zero, or negative.

Positive in almost every bucket is expected, and it is not proof of a good
optimizer. Turnover is held fixed when the price moves, so shading the busy
side is always "free". Checks 1 to 4 are what say the maths is right.

    python -m src.backtest.parquet.check_optimizer --dir "S:\\Users\\Yeung\\20260520 Algo E\\Backtest_Data\\Optimizer"
    python -m src.backtest.parquet.check_optimizer selftest
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import List, Optional, Sequence

import numpy as np
import pandas as pd

THETA_BAND = 1.0
PROB_BAND = 0.05
TOL = 1e-6


def _read(folder: Path) -> pd.DataFrame:
    files = sorted(folder.glob("*.parquet"))
    if not files:
        return pd.DataFrame()
    return pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)


def audit(buckets: pd.DataFrame, prices: pd.DataFrame) -> dict:
    out = {"buckets": int(len(buckets)), "price_rows": int(len(prices)), "problems": []}
    if buckets.empty:
        out["problems"].append("no solved buckets")
        return out

    # 1. theta band around HKJC
    worst_theta = 0.0
    theta_bad = 0
    for dom in ("goal", "corner"):
        for part in ("tg", "sup"):
            a, b = "opt_{}_{}".format(part, dom), "hkjc_{}_{}".format(part, dom)
            if a not in buckets.columns or b not in buckets.columns:
                continue
            gap = (pd.to_numeric(buckets[a], errors="coerce")
                   - pd.to_numeric(buckets[b], errors="coerce")).abs()
            worst_theta = max(worst_theta, float(gap.max(skipna=True) or 0.0))
            theta_bad += int((gap > THETA_BAND + TOL).sum())
    out["worst_theta_gap"] = worst_theta
    out["theta_band_breaks"] = theta_bad
    if theta_bad:
        out["problems"].append("{} bucket(s) moved TG/SUP more than {} from HKJC".format(
            theta_bad, THETA_BAND))

    # 5. sign of lift against the board
    lift = (pd.to_numeric(buckets["egm_opt"], errors="coerce")
            - pd.to_numeric(buckets["egm_actual_odds"], errors="coerce"))
    to = pd.to_numeric(buckets["turnover_forecast"], errors="coerce")
    out["lift_positive"] = int((lift > TOL).sum())
    out["lift_zero"] = int((lift.abs() <= TOL).sum())
    out["lift_negative"] = int((lift < -TOL).sum())
    total_to = float(to.sum())
    out["lift_pct_of_turnover"] = float(lift.sum() / total_to) if total_to else None
    per = (lift / to.where(to > 0)).dropna()
    out["lift_pct_p50"] = float(per.median()) if len(per) else None
    out["lift_pct_p99"] = float(per.quantile(0.99)) if len(per) else None
    if "used_board" in buckets.columns:
        out["kept_board"] = int(buckets["used_board"].fillna(False).astype(bool).sum())

    if prices.empty:
        out["problems"].append("no price rows, so checks 2 to 4 were skipped")
        return out

    p = prices.copy()
    for c in ("turnover", "p_true", "odds_actual", "odds_opt", "odds_hkjc_theta"):
        p[c] = pd.to_numeric(p[c], errors="coerce")
    ok = (p["odds_actual"] > 1) & (p["odds_opt"] > 1)

    # 2. probability band around the board
    gap = (1.0 / p.loc[ok, "odds_opt"] - 1.0 / p.loc[ok, "odds_actual"]).abs()
    out["worst_prob_gap"] = float(gap.max()) if len(gap) else None
    out["prob_band_breaks"] = int((gap > PROB_BAND + TOL).sum())
    if out["prob_band_breaks"]:
        out["problems"].append("{} price(s) more than {:.0%} from the board".format(
            out["prob_band_breaks"], PROB_BAND))

    # 3 and 4 need whole buckets. The price sample can stop mid-bucket, so
    # only buckets whose selection count matches are compared.
    if "match_id" not in p.columns:
        out["problems"].append("price rows carry no match_id; re-solve with this build for checks 3 and 4")
        return out
    p["gm_opt"] = p["turnover"] * (1.0 - p["odds_opt"] * p["p_true"])
    p["gm_board"] = p["turnover"] * (1.0 - p["odds_actual"] * p["p_true"])
    p["gm_hkjc"] = p["turnover"] * (1.0 - p["odds_hkjc_theta"] * p["p_true"])
    key = ["match_id", "bucket"]
    got = p.groupby(key, observed=True).agg(
        n=("turnover", "size"), gm_opt=("gm_opt", "sum"),
        gm_board=("gm_board", "sum"), gm_hkjc=("gm_hkjc", "sum"),
        hkjc_in_band=("odds_hkjc_theta",
                      lambda s: bool(np.all(np.abs(
                          1.0 / s.to_numpy() - 1.0 / p.loc[s.index, "odds_actual"].to_numpy())
                          <= PROB_BAND + TOL)))).reset_index()
    b = buckets[key + ["n_selections", "egm_opt", "egm_actual_odds"]].copy()
    b["bucket"] = pd.to_datetime(b["bucket"])
    got["bucket"] = pd.to_datetime(got["bucket"])
    m = got.merge(b, on=key, how="inner")
    m = m[m["n"] == m["n_selections"]]
    out["buckets_recomputed"] = int(len(m))
    if len(m):
        scale = np.maximum(m["egm_opt"].abs(), 1.0)
        drift = ((m["gm_opt"] - m["egm_opt"]).abs() / scale)
        out["recompute_worst_rel"] = float(drift.max())
        bad = int((drift > 1e-4).sum())
        if bad:
            out["problems"].append("{} bucket(s) whose stored margin does not match its prices".format(bad))
        # 4. never worse than HKJC's TG/SUP, where HKJC's own price was allowed
        eligible = m[m["hkjc_in_band"]]
        worse = eligible[eligible["gm_opt"] < eligible["gm_hkjc"] - 1e-6 * np.maximum(eligible["gm_hkjc"].abs(), 1.0)]
        out["buckets_worse_than_hkjc_theta"] = int(len(worse))
        out["buckets_hkjc_theta_checked"] = int(len(eligible))
        if len(worse):
            out["problems"].append("{} bucket(s) solved worse than HKJC's own TG/SUP".format(len(worse)))
    return out


def _print(res: dict) -> None:
    def pct(v):
        return "n/a" if v is None else "{:.2%}".format(v)
    print("solved buckets        {:,}".format(res["buckets"]))
    print("price rows            {:,}".format(res["price_rows"]))
    if "worst_theta_gap" in res:
        print("1. TG/SUP vs HKJC     worst gap {:.3f}  (limit {})  breaks {}".format(
            res["worst_theta_gap"], THETA_BAND, res["theta_band_breaks"]))
    if res.get("worst_prob_gap") is not None:
        print("2. 1/odds vs board    worst gap {:.4f}  (limit {})  breaks {}".format(
            res["worst_prob_gap"], PROB_BAND, res["prob_band_breaks"]))
    if res.get("buckets_recomputed") is not None:
        print("3. margin recomputed  {:,} buckets, worst relative diff {:.2e}".format(
            res["buckets_recomputed"], res.get("recompute_worst_rel", 0.0)))
    if res.get("buckets_hkjc_theta_checked") is not None:
        print("4. worse than HKJC    {:,} of {:,} checkable buckets".format(
            res["buckets_worse_than_hkjc_theta"], res["buckets_hkjc_theta_checked"]))
    if "lift_positive" in res:
        print("5. lift vs board      positive {:,}  zero {:,}  negative {:,}".format(
            res["lift_positive"], res["lift_zero"], res["lift_negative"]))
        print("   lift / turnover    total {}  median {}  99th pct {}".format(
            pct(res.get("lift_pct_of_turnover")), pct(res.get("lift_pct_p50")),
            pct(res.get("lift_pct_p99"))))
        if res.get("kept_board") is not None:
            print("   kept board price   {:,} bucket(s) had no allowed TG/SUP".format(res["kept_board"]))
    if res["problems"]:
        print("\nPROBLEMS")
        for p in res["problems"]:
            print("  - " + p)
    else:
        print("\nPASS  checks 1 to 4 hold")


def run(folder: Path) -> dict:
    res = audit(_read(folder / "buckets"), _read(folder / "prices"))
    _print(res)
    return res


def _fail(msg: str) -> None:
    raise SystemExit("[check_optimizer selftest] FAIL: " + msg)


def selftest() -> None:
    """Run the real solver on synthetic buckets, then audit what it wrote."""
    from .config import Config
    from .optimize import OptimizerStage
    from .pricing import Book, score_matrix, over_under, asian_handicap

    rng = np.random.default_rng(3)
    cfg = Config(optimize=True, optimize_every=1, optimize_max_buckets=500, optimize_starts=3)
    stage = OptimizerStage(cfg)
    rows = []
    t0 = pd.Timestamp("2026-07-01 19:00")
    for m in range(6):
        tg = float(rng.uniform(2.1, 3.1))
        sup = float(rng.uniform(-0.6, 0.6))
        mat = score_matrix(tg, sup)
        for k in range(8):
            bucket = t0 + pd.Timedelta(minutes=5 * k)
            for pool, line, kind in (("HILO", 2.5, "ou"), ("HILO", 3.0, "ou"), ("HDC", -0.5, "ah")):
                fair = over_under(mat, line) if kind == "ou" else asian_handicap(mat, line)
                for side, cs, cid in ((0, "H", 1), (1, "L" if kind == "ou" else "A", 2)):
                    odds = fair[side] / 1.06
                    rows.append({
                        "match_id": 100 + m, "bucket": bucket, "pool_name": pool,
                        "line_label": str(line), "combination_string": cs, "combination_id": cid,
                        "odds": odds * float(rng.uniform(0.98, 1.02)),
                        "p_true": 1.0 / fair[side],
                        # money piled onto one side, so the solver has a reason to move
                        "f_persist": float(rng.uniform(5e3, 5e4) * (6 if side == 0 else 1)),
                        "turnover": 0.0, "realized_gm": 0.0, "settled": False,
                        "tg": tg, "sup": sup, "ctg": 9.5, "csup": 0.0,
                        "is_inplay": False, "clock_bin": "pre 60-15m",
                        "sell_book_sum": 1.06, "p_sell": 1.0 / odds,
                    })
    stage.update(pd.DataFrame(rows))
    buckets = pd.DataFrame(stage.rows)
    prices = pd.DataFrame(stage.prices)
    if buckets.empty:
        _fail("solver wrote no buckets")
    res = audit(buckets, prices)
    _print(res)
    if res["problems"]:
        _fail("; ".join(res["problems"]))
    if res.get("buckets_recomputed", 0) == 0:
        _fail("no bucket could be recomputed")
    if res["lift_positive"] == 0:
        _fail("one-sided money never moved the price")
    print("[check_optimizer selftest] PASS", flush=True)


def main(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", nargs="?", default="check", choices=["check", "selftest"])
    p.add_argument("--dir", default=r"S:\Users\Yeung\20260520 Algo E\Backtest_Data\Optimizer")
    a = p.parse_args(argv)
    if a.command == "selftest":
        selftest()
        return
    run(Path(a.dir))


if __name__ == "__main__":
    main()
