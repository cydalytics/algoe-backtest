"""
Live Engine

Keeps a TG/SUP recommendation for every active match, refreshed at two
speeds, because the desk cannot wait five minutes after a goal and the box
cannot re-solve a hundred matches every fifteen seconds.

    SWEEP (every bucket boundary, all matches)
        fetch everything -> panel (same code as training) -> features
        -> bucket forecast F per selection (champion turnover pipeline)
        -> belief p per selection (champion calibration)
        -> optimise every match with enough expected money, richest first,
           inside a time budget, in parallel
    FOCUS (every ~15 s, only the matches the desk has open or a trigger fired on)
        fetch THAT match only -> latest odds, parameters, score, and the money
        already taken in the current bucket
        -> nowcast: remaining = rate x (5 - elapsed), rate from F and what has
           arrived (realtime/nowcast.py); the next bucket carries the surge
        -> belief re-read from the latest true odds
        -> re-optimise that match from its last answer (warm start, one start,
           each dimension limited to max_step from the last recommendation)

    TRIGGERS refresh a match at once and keep it on focus refreshes for
    trigger_focus_seconds: a goal, red card or corner (or its cancellation), a
    main-line price moving more than trigger_odds_move, or one minute's money
    exceeding trigger_big_bet_multiple times what the forecast expected for a minute.

    AFTER AN EVENT inside the bucket, the rest of the bucket is forecast from the
    bucket forecast shifted by the fitted EventShift (models/event_shift.py: what
    a goal / red card / corner at this clock, by this side, with this favourite and
    this score does to each bet type and side), and the nowcast's evidence is the
    money since the event, not since the bucket started. The next sweep sees the
    event in its features.

A UI heartbeat keeps a match in focus (``focus_on``); without one the focus
lapses after focus_ttl_seconds, so a forgotten tab does not cost CPU forever.

Everything the engine publishes is also appended to the monitor's forecast
log, where the next sweep joins the money that actually arrived.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Days built with prepare_live; a price-move trigger resets after its refresh, a big-money
                trigger fires once per minute
2026-10-11      Corners and VAR cancellations trigger too; a trigger keeps its match on focus refreshes
                (it used to refresh once); the rest of the bucket after an event is re-tuned with the
                fitted event shift and nowcast from the money since the event
"""

from __future__ import annotations

import heapq
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import KEY, LivePanelBuilder
from ..features.engineer import FeatureEngineer, _kickoff_value
from ..models.event_shift import (PRIORITY, EventShift, clock_label, incident_table, main_provider, side_groups,
                                  state_label, strength_label, who_label)
from ..optimizer.theta_optimizer import (DemandResponse, MatchDecision, ThetaOptimizer, build_books,
                                         desk_weightings, publish_odds)
from .nowcast import BucketNowcaster

logger = get_logger(__name__)


@dataclass
class MatchLive:
    match_id: int
    bucket: Optional[pd.Timestamp] = None
    forecast: Optional[pd.DataFrame] = None       # KEY + forecast for the current bucket (from the sweep)
    decision: Optional[MatchDecision] = None
    view: Optional[pd.DataFrame] = None           # per selection: odds now / star, belief, forecast, observed, remaining
    refreshed_at: Optional[pd.Timestamp] = None
    mode: str = "sweep"
    triggers: List[str] = field(default_factory=list)
    last_events: tuple = ()                       # incident counts by code, the main provider's
    event: Optional[dict] = None                  # the event the rest of this bucket is re-tuned for
    last_main_odds: Dict[tuple, float] = field(default_factory=dict)
    last_big_minute: Optional[pd.Timestamp] = None
    observed: float = 0.0
    remaining: float = 0.0
    hot: float = 1.0
    weights: Dict[tuple, float] = field(default_factory=dict)    # last stage-2 weighting per selection

    def summary(self) -> dict:
        d = self.decision
        return {"match_id": self.match_id, "bucket": str(self.bucket), "mode": self.mode,
                "refreshed_at": str(self.refreshed_at), "triggers": list(self.triggers),
                "status": d.status if d else "pending", "lift": d.lift if d else 0.0,
                "lift_bps": d.lift_bps if d else 0.0, "turnover": d.turnover if d else 0.0,
                "theta_now": d.theta_now if d else {}, "theta_star": d.theta_star if d else {},
                "observed_in_bucket": self.observed, "remaining_in_bucket": self.remaining,
                "hot": self.hot, "binding": d.binding if d else [],
                "event_in_bucket": (self.event or {}).get("labels")}


class LiveEngine:
    def __init__(self, settings, source=None, forecaster=None, calibrator=None, monitor=None, clock=None):
        self.settings = settings
        self.source = source if source is not None else _default_source(settings)
        self.forecaster = forecaster
        self.calibrator = calibrator
        self.monitor = monitor
        self.engineer = forecaster.engineer if forecaster is not None else FeatureEngineer(settings)
        self.builder = LivePanelBuilder(settings)
        # money features are in market-index units; with no cached day to size the market, the model's own
        self.builder.market_index_fallback = (getattr(forecaster, "metadata", None) or {}).get("market_index_last")
        # The historical extraction has no HKJC true odds while the live feed does: a model trained without
        # them must see the price inputs it learned on (de-margined odds, Poisson), not new ones.
        coverage = (getattr(forecaster, "metadata", None) or {}).get("true_odds_coverage")
        if coverage is not None and np.isfinite(coverage) and coverage < 0.5:
            self.builder.ignore_true_odds = True
            logger.warning("the turnover model was trained with HKJC true odds on %.0f%% of rows; live true odds are "
                           "ignored so its inputs match. Re-extract history with true odds to use them.",
                           100 * coverage)
        self.optimizer = ThetaOptimizer(settings, DemandResponse.from_forecaster(forecaster, settings))
        self.nowcaster = forecaster.nowcaster if forecaster is not None else BucketNowcaster(
            settings.live.nowcast_prior_minutes, settings.panel.bucket_minutes,
            max_hot=settings.live.nowcast_max_hot)
        self.event_shift: Optional[EventShift] = None
        if settings.live.event_shift:
            path = EventShift.default_path(settings)
            self.event_shift = EventShift.load(path)
            if self.event_shift is None:
                logger.info("no event shift at %s: after an event the rest of the bucket follows the money arriving "
                            "only (algoe-3-backtest.bat --only events fits it)", path)
            else:
                logger.info("event shift: %d cell(s), fitted %s on %s", len(self.event_shift.cells),
                            self.event_shift.meta.get("fitted"), self.event_shift.meta.get("turnover_model"))
        self.clock = clock or (lambda: pd.Timestamp.now())
        self.matches: Dict[int, MatchLive] = {}
        self.focus: Dict[int, float] = {}
        self._queue: List[Tuple[float, int, str]] = []
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.last_sweep: dict = {}

    # ============================================================ interest
    def focus_on(self, match_id: int, ttl: Optional[float] = None) -> None:
        with self._lock:
            self.focus[int(match_id)] = time.time() + (ttl or self.settings.live.focus_ttl_seconds)

    def focus_off(self, match_id: int) -> None:
        with self._lock:
            self.focus.pop(int(match_id), None)

    def focused(self) -> List[int]:
        now = time.time()
        with self._lock:
            for m in [m for m, t in self.focus.items() if t < now]:
                self.focus.pop(m, None)
            return sorted(self.focus)

    def trigger(self, match_id: int, reason: str, priority: float = 1.0, focus: Optional[str] = None) -> None:
        """Refresh the match at the next step; ``focus`` (goal / red / corner / price / money) also keeps it on
        focus refreshes for live.trigger_focus_seconds[focus]."""
        with self._lock:
            heapq.heappush(self._queue, (-priority, int(match_id), reason))
            live = self.matches.setdefault(int(match_id), MatchLive(int(match_id)))
            live.triggers = (live.triggers + [reason])[-5:]
            ttl = float(self.settings.live.trigger_focus_seconds.get(focus, 0.0)) if focus else 0.0
            if ttl > 0:
                self.focus[int(match_id)] = max(self.focus.get(int(match_id), 0.0), time.time() + ttl)
        logger.info("trigger match %s: %s", match_id, reason)

    # ================================================================ sweep
    def run_sweep(self, as_of=None) -> dict:
        as_of = pd.Timestamp(as_of or self.clock())
        started = time.time()
        snap = self.source.fetch(as_of)
        t_fetch = time.time() - started
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            self.last_sweep = {"as_of": str(as_of), "matches": 0, "note": "no active matches"}
            return self.last_sweep
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        t_feat = time.time() - started - t_fetch
        forecast = self._forecast(day)
        belief = self._belief(day)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        prev = {m: l.decision.theta_star for m, l in self.matches.items() if l.decision is not None}
        wprev = {m: l.weights for m, l in self.matches.items() if l.weights}
        books = build_books(day.sel[now_rows], day.match, forecast[now_rows], belief[now_rows], self.settings,
                            theta_prev=prev, weights_prev=wprev)
        t_prep = time.time() - started - t_fetch - t_feat
        decisions = self.optimizer.optimize_card(books, mode="sweep")
        t_opt = time.time() - started - t_fetch - t_feat - t_prep
        sel_now = day.sel[now_rows]
        fc_now = pd.DataFrame({**{k: sel_now[k].to_numpy() for k in KEY + ["match_id", "pool_name"]},
                               "forecast": forecast[now_rows], "belief": belief[now_rows],
                               "odds": sel_now["odds"].to_numpy(dtype="float64")})
        with self._lock:
            for bk in books:
                live = self.matches.setdefault(bk.match_id, MatchLive(bk.match_id))
                live.bucket, live.mode, live.refreshed_at = current, "sweep", as_of
                live.forecast = fc_now[fc_now["match_id"] == bk.match_id].reset_index(drop=True)
                live.decision = decisions.get(bk.match_id)
                live.view = _view(bk, live.decision)
                live.weights = _weights_by_key(bk, live.decision)
                live.observed, live.remaining, live.hot = 0.0, float(bk.total_demand), 1.0
                live.last_events = self._event_signature(extra["events"], bk.match_id)
                live.event = None
                live.last_main_odds = _main_odds(bk)
        if self.monitor is not None:
            self.monitor.log_forecasts(current, fc_now, model=getattr(self.forecaster, "version", None))
        self.last_sweep = {"as_of": str(as_of), "bucket": str(current), "matches": len(books),
                           "solved": sum(1 for d in decisions.values() if d.status.startswith("solved")),
                           "lift": float(sum(d.lift for d in decisions.values())),
                           "lift_weightings": float(sum(d.lift_stage2 for d in decisions.values())),
                           "turnover": float(sum(d.turnover for d in decisions.values())),
                           "seconds": {"fetch": round(t_fetch, 2), "features": round(t_feat, 2),
                                       "books": round(t_prep, 2), "optimise": round(t_opt, 2),
                                       "total": round(time.time() - started, 2)}}
        logger.info("sweep %s: %d match(es), E[GM] lift %.0f on %.0f expected, %.1fs (%s)", current.strftime("%H:%M"),
                    len(books), self.last_sweep["lift"], self.last_sweep["turnover"],
                    self.last_sweep["seconds"]["total"], self.last_sweep["seconds"])
        return self.last_sweep

    def _forecast(self, day) -> np.ndarray:
        if self.forecaster is None:
            return day.sel["tv1"].to_numpy(dtype="float64")
        return self.forecaster.predict_selection_turnover(day)["forecast"].to_numpy(dtype="float64")

    def _belief(self, day) -> np.ndarray:
        if self.calibrator is None:
            return day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        p = self.calibrator.predict_for_day(day)
        raw = day.sel["p_hkjc_true"].to_numpy(dtype="float64")
        return np.where(np.isfinite(p), p, raw)

    # ================================================================ focus
    def run_focus(self, match_id: int, as_of=None) -> Optional[MatchLive]:
        """Refresh one match mid-bucket: nowcast the rest of the bucket and re-optimise."""
        as_of = pd.Timestamp(as_of or self.clock())
        mid = int(match_id)
        started = time.time()
        snap = self.source.fetch(as_of, match_ids=[mid])
        snap = _only(snap, mid)
        panel, extra = self.builder.build(snap, as_of)
        if panel.empty:
            return self.matches.get(mid)
        current = extra["current_bucket"]
        day = self.engineer.prepare_live(panel, extra)
        now_rows = (day.sel["bucket"] == current).to_numpy()
        sel_now = day.sel[now_rows].reset_index(drop=True)
        live = self.matches.setdefault(mid, MatchLive(mid))
        # the bucket forecast comes from the sweep; a match first seen here forecasts on its own
        if live.forecast is None or live.bucket != current:
            F = self._forecast(day)[now_rows]
        else:
            F = sel_now[KEY].merge(live.forecast[KEY + ["forecast"]], on=KEY, how="left")["forecast"] \
                .fillna(0.0).to_numpy(dtype="float64")
        lag = self.settings.live.data_lag_seconds
        observed = _observed(snap.investments, sel_now, current, as_of)
        elapsed = max((as_of - current).total_seconds() - lag, 0.0) / 60.0
        ev = self._event_in_bucket(extra.get("events"), day.match, mid, current, as_of) \
            if self.event_shift is not None else None
        if ev is not None:
            # the rest of the bucket comes after the event: its forecast shifted for it, and the evidence is the
            # money since the event (the feed floors a bet to its minute)
            groups = side_groups(sel_now["family"].to_numpy(dtype=object), sel_now["side"].to_numpy(dtype=object),
                                 np.nan_to_num(pd.to_numeric(sel_now.get("fav_sign", 0.0), errors="coerce")))
            F_post = F * self.event_shift.multipliers(groups, ev["labels"])
            since = pd.Timestamp(ev["time"]).floor("min")
            x_post = _observed(snap.investments, sel_now, since, as_of)
            e_post = max((as_of - since).total_seconds() - lag, 0.0) / 60.0
            nc = self.nowcaster.update(F_post, x_post, e_post, match_key=sel_now["match_id"].to_numpy(),
                                       next_forecast=F_post,
                                       left=max(self.settings.panel.bucket_minutes - elapsed, 0.0))
        else:
            nc = self.nowcaster.update(F, observed, elapsed, match_key=sel_now["match_id"].to_numpy(), next_forecast=F)
        horizon = nc.remaining + nc.next_bucket
        belief = self._belief(day)[now_rows]
        prev = {mid: live.decision.theta_star} if live.decision is not None else None
        books = build_books(sel_now, day.match, horizon, belief, self.settings, theta_prev=prev,
                            weights_prev={mid: live.weights} if live.weights else None)
        if not books:
            return live
        bk = books[0]
        dec = self.optimizer.optimize_match(bk, mode="focus")
        with self._lock:
            live.bucket, live.mode, live.refreshed_at = current, "focus", as_of
            live.decision = dec
            live.view = _view(bk, dec)
            live.weights = _weights_by_key(bk, dec)
            live.observed = float(observed.sum())
            live.remaining = float(nc.remaining.sum())
            live.hot = float(np.nanmedian(nc.match_hot)) if len(nc.match_hot) else 1.0
            # the move that triggered this refresh has now been priced in
            live.last_main_odds = _main_odds(bk)
            live.last_events = self._event_signature(extra["events"], mid)
            live.event = ev
        logger.info("focus %s @%s: observed %.0f, remaining %.0f (hot x%.2f)%s, lift %.1f, %s in %.2fs",
                    mid, as_of.strftime("%H:%M:%S"), live.observed, live.remaining, live.hot,
                    "" if ev is None else ", re-tuned for {} {} {} ({})".format(
                        ev["labels"]["event"], ev["labels"]["who"], ev["labels"]["clock"], ev["labels"]["state"]),
                    dec.lift, dec.status, time.time() - started)
        return live

    # ============================================================ triggers
    def check_triggers(self, as_of=None) -> List[Tuple[int, str]]:
        """Cheap scan of the whole card for events, price jumps and big bets since the last look."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        snap = self.source.fetch(as_of)
        fired = []
        ev = self.builder._canon("events", snap.events)
        odds = self.builder._canon("odds", snap.odds)
        inv = self.builder._canon("investments", snap.investments)
        for mid, live in list(self.matches.items()):
            sig = self._event_signature(ev, mid)
            if sig and sig != live.last_events:
                kind, what = self._newest_incident(ev, mid)
                fired.append((mid, what, kind))
                live.last_events = sig                      # one trigger per change, not one per scan
            if live.last_main_odds and not odds.empty:
                o = odds[odds["match_id"] == mid].sort_values("effective_datetime").groupby(
                    ["pool_id", "line_id", "combination_id"]).last()["odds"]
                for k, v0 in live.last_main_odds.items():
                    v1 = o.get(k)
                    if v1 is not None and v0 > 0 and abs(v1 / v0 - 1.0) > lv.trigger_odds_move:
                        fired.append((mid, "main-line price moved {:+.0%}".format(v1 / v0 - 1.0), "price"))
                        break
            since = as_of.floor("min") - pd.Timedelta(minutes=1)
            if live.forecast is not None and not inv.empty and live.last_big_minute != since:
                minute = inv[(inv["match_id"] == mid) & (inv["start_sell_time"] >= since)]
                per_min = float(live.forecast["forecast"].sum()) / self.settings.panel.bucket_minutes
                if per_min > 0 and float(minute["turnover"].sum()) > lv.trigger_big_bet_multiple * per_min:
                    live.last_big_minute = since
                    fired.append((mid, "big money: {:.0f} in a minute vs {:.0f} expected".format(
                        float(minute["turnover"].sum()), per_min), "money"))
        for mid, reason, key in fired:
            self.trigger(mid, reason, priority=2.0, focus=key)
        return [(mid, reason) for mid, reason, _ in fired]

    # ============================================================ events
    def _event_kinds(self) -> List[str]:
        return [k for k in PRIORITY if k in self.settings.live.trigger_events]

    def _event_signature(self, events: Optional[pd.DataFrame], mid: int) -> tuple:
        """The match's incident counts by code (events and their cancellations), from its main provider:
        any change - a goal, a corner, a VAR cancellation - is a new state of the match."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return ()
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds)]
        if inc.empty:
            return ()
        return tuple(int(((inc["kind"] == k) & (inc["sign"] == s)).sum()) for k in kinds for s in (1.0, -1.0))

    def _newest_incident(self, events: pd.DataFrame, mid: int) -> Tuple[str, str]:
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(self._event_kinds())]
        if inc.empty:
            return "goal", "event"
        last = inc.iloc[-1]
        name = {"goal": "goal", "red": "red card", "corner": "corner"}[last["kind"]]
        return str(last["kind"]), name if last["sign"] > 0 else name + " cancelled"

    def _event_in_bucket(self, events: Optional[pd.DataFrame], match: pd.DataFrame, mid: int, current,
                         as_of) -> Optional[dict]:
        """The goal / red card / corner since the bucket started (the rarest kind there is, net of
        cancellations), with the labels the event shift is kept by; None without one."""
        kinds = self._event_kinds()
        if not kinds or events is None or events.empty or "incident_type" not in events.columns:
            return None
        inc = main_provider(incident_table(events[pd.to_numeric(events["match_id"], errors="coerce") == mid]))
        inc = inc[inc["kind"].isin(kinds) & (inc["t"] >= pd.Timestamp(current)) & (inc["t"] <= pd.Timestamp(as_of))]
        if inc.empty:
            return None
        net = inc.groupby("kind")["sign"].sum()
        kind = next((k for k in PRIORITY if net.get(k, 0.0) > 0), None)
        if kind is None:
            return None
        last = inc[(inc["kind"] == kind) & (inc["sign"] > 0)].iloc[-1]
        m = match[pd.to_numeric(match["match_id"], errors="coerce") == mid].sort_values("bucket").reset_index(drop=True)
        if m.empty:
            return None
        sup_ko = _kickoff_value(m, "sup") if "sup" in m.columns else np.full(len(m), np.nan)
        at = m.index[pd.to_datetime(m["bucket"]) <= pd.Timestamp(current)]
        i = int(at[-1]) if len(at) else len(m) - 1
        row = m.iloc[i]
        sgn = float(np.nan_to_num(pd.to_numeric(row.get("fav_sign", 0.0), errors="coerce")))
        goals = inc[(inc["kind"] == "goal")]
        hg = float(np.nan_to_num(pd.to_numeric(row.get("home_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 1, "sign"].sum())
        ag = float(np.nan_to_num(pd.to_numeric(row.get("away_goals", 0.0), errors="coerce"))) + \
            float(goals.loc[goals["side"] == 2, "sign"].sum())
        minute = float(np.nan_to_num(pd.to_numeric(row.get("minute", 0.0), errors="coerce"))) + \
            (pd.Timestamp(last["t"]) - pd.Timestamp(current)).total_seconds() / 60.0
        labels = {"event": kind, "clock": clock_label([minute])[0],
                  "who": who_label([sgn], [last["side"] == 1], [last["side"] == 2])[0],
                  "strength": strength_label([sgn], [sup_ko[i]])[0], "state": state_label([sgn], [hg], [ag])[0]}
        return {"kind": kind, "time": pd.Timestamp(last["t"]), "side": last["side"], "labels": labels}

    # ================================================================ loop
    def step(self, as_of=None) -> dict:
        """One scheduler tick: sweep at a new bucket, then focus refreshes that are due."""
        as_of = pd.Timestamp(as_of or self.clock())
        lv = self.settings.live
        done = {"sweep": None, "focus": []}
        bucket = as_of.floor("{}min".format(self.settings.panel.bucket_minutes))
        if not self.last_sweep or self.last_sweep.get("bucket") != str(bucket):
            done["sweep"] = self.run_sweep(as_of)
        due = []
        with self._lock:
            while self._queue:
                _, mid, reason = heapq.heappop(self._queue)
                if mid not in due:
                    due.append(mid)
        for mid in self.focused():
            live = self.matches.get(mid)
            last = live.refreshed_at if live else None
            if last is None or (as_of - last).total_seconds() >= lv.focus_interval_seconds:
                if mid not in due:
                    due.append(mid)
        for mid in due[: lv.max_focus_matches]:
            try:
                self.run_focus(mid, as_of)
                done["focus"].append(mid)
            except Exception as exc:                                   # noqa: BLE001
                logger.exception("focus refresh of match %s failed: %s", mid, exc)
        return done

    def start(self, poll_seconds: float = 1.0) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def loop():
            logger.info("live engine started (source %s)", type(self.source).__name__)
            last_scan = 0.0
            while not self._stop.is_set():
                try:
                    if time.time() - last_scan > self.settings.live.focus_interval_seconds:
                        self.check_triggers()
                        last_scan = time.time()
                    self.step()
                except Exception as exc:                                # noqa: BLE001
                    logger.exception("live step failed: %s", exc)
                self._stop.wait(poll_seconds)
            logger.info("live engine stopped")
        self._thread = threading.Thread(target=loop, name="algoe-live", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=10)

    # ================================================================ read
    def board(self) -> dict:
        with self._lock:
            rows = [m.summary() for m in self.matches.values()]
        rows.sort(key=lambda r: -r["turnover"])
        return {"last_sweep": self.last_sweep, "focused": self.focused(), "matches": rows}

    def match_view(self, match_id: int) -> dict:
        with self._lock:
            live = self.matches.get(int(match_id))
            if live is None:
                return {"match_id": int(match_id), "status": "unknown"}
            view = live.view.to_dict("records") if live.view is not None else []
            return {**live.summary(), "selections": view,
                    "per_pool": live.decision.per_pool if live.decision else []}


# ---------------------------------------------------------------- helpers
def _default_source(settings):
    if settings.live.source == "replay":
        from ..data.replay import ReplaySource
        return ReplaySource(settings)
    from src.hkjc.source import get_source
    return get_source(settings.live.source)


def _only(snap, mid: int):
    """Keep one match's rows; the simulator ignores match_ids, SQL and replay honour it."""
    for name in ("active_pools", "match_info", "params", "params_history", "events", "odds", "market", "investments"):
        frame = getattr(snap, name, None)
        if frame is not None and not frame.empty and "match_id" in frame.columns:
            setattr(snap, name, frame[pd.to_numeric(frame["match_id"], errors="coerce") == mid])
        elif frame is not None and not frame.empty and name == "match_info":
            col = next((c for c in ("MatchId", "match_id") if c in frame.columns), None)
            if col:
                setattr(snap, name, frame[pd.to_numeric(frame[col], errors="coerce") == mid])
    return snap


def _observed(investments: pd.DataFrame, sel: pd.DataFrame, bucket, as_of) -> np.ndarray:
    """Money each selection has taken since the bucket started."""
    if investments is None or investments.empty:
        return np.zeros(len(sel))
    inv = LivePanelBuilder._canon("investments", investments)
    inv = inv[(inv["start_sell_time"] >= bucket) & (inv["start_sell_time"] <= as_of)]
    if inv.empty:
        return np.zeros(len(sel))
    for c in KEY:
        inv[c] = pd.to_numeric(inv[c], errors="coerce").fillna(-1).astype("int64")
    got = inv.groupby(KEY)["turnover"].sum()
    idx = pd.MultiIndex.from_frame(sel[KEY].astype("int64"))
    return got.reindex(idx).fillna(0.0).to_numpy(dtype="float64")


def _main_odds(book) -> Dict[tuple, float]:
    if book.keys is None:
        return {}
    out = {}
    for i in np.flatnonzero(book.is_main):
        k = book.keys.iloc[i]
        out[(int(k["pool_id"]), int(k["line_id"]), int(k["combination_id"]))] = float(book.odds_now[i])
    return out


def _view(book, dec: Optional[MatchDecision]) -> pd.DataFrame:
    v = book.keys.copy() if book.keys is not None else pd.DataFrame(index=range(book.n))
    v["line"] = book.rows.line
    v["side"] = book.rows.side
    v["odds_now"] = book.odds_now
    v["belief"] = book.p_true
    v["demand"] = book.demand
    if dec is not None and dec.odds_star is not None:
        v["odds_star"] = dec.odds_star
        v["odds_star_ladder"] = publish_odds(dec.odds_star)
        v["demand_star"] = dec.demand_star
        # stage 2: our weighting on top of theta*, and the price in the desk's terms
        # (sell = fair(theta*) / (1 + margin) x desk_weighting)
        v["weighting"] = dec.weights if dec.weights is not None else 1.0
        v["desk_weighting"] = desk_weightings(book, dec)
    return v


def _weights_by_key(book, dec: Optional[MatchDecision]) -> Dict[tuple, float]:
    if dec is None or dec.weights is None or book.keys is None:
        return {}
    k = book.keys
    return {(int(a), int(b), int(c)): float(w) for a, b, c, w in zip(k["pool_id"], k["line_id"],
                                                                     k["combination_id"], dec.weights)}
