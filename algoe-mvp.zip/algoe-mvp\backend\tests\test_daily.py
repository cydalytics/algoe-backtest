"""
Daily automation tests - which days a model saw, score-days (walk-forward), the nightly's order and record,
the report's walk-forward days, the desk's data chip, the daily task

    python tests/test_daily.py                 plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_daily.py

Change Log:
-----------
2026-11-20      Initialize
2026-11-21      Review: a refit's blend days, provisional days revisited, changed days not counted
"""

import json
import os
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

DEPLOY = Path(__file__).resolve().parents[2] / "deploy"


def _days(a, b):
    return [str(d.date()) for d in pd.date_range(a, b)]


REFIT = SimpleNamespace(version="tv1", champion="c1",
                        metadata={"serving_fit": {"refit": True, "fit": ["2026-08-01", "2026-10-14", 75]}})


def _settings(tmp):
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.work_dir="{}"'.format((Path(tmp) / "work").as_posix()))
    s.set('paths.data_dir="{}"'.format((Path(tmp) / "Raw_Data").as_posix()))
    (Path(tmp) / "Raw_Data").mkdir(exist_ok=True)
    return s


# ------------------------------------------------------------------ the days a model saw
def test_a_model_says_which_days_it_saw():
    from algoe.evaluation.walkforward import fit_end, first_unseen
    prob = SimpleNamespace(metadata={"serving_fit": {"refit": True, "days": ["2026-08-02", "2026-10-15", 75]}})
    honest = SimpleNamespace(metadata={"split": {"train": _days("2026-05-01", "2026-06-30"),
                                                 "val": _days("2026-07-01", "2026-07-31"),
                                                 "test": _days("2026-08-01", "2026-08-31")}})
    vague = SimpleNamespace(metadata={"serving_fit": True})
    assert fit_end(REFIT) == pd.Timestamp("2026-10-14") and fit_end(prob) == pd.Timestamp("2026-10-15")
    assert fit_end(honest) == pd.Timestamp("2026-07-31") and fit_end(vague) is None
    assert first_unseen([REFIT, prob]) == pd.Timestamp("2026-10-16") and first_unseen([REFIT, vague]) is None


def test_a_serving_refit_saw_the_days_it_blended_on():
    from algoe.cli import _report_window
    from algoe.evaluation.walkforward import fit_end
    blended = SimpleNamespace(metadata={"serving_fit": {"refit": True, "fit": ["2026-08-01", "2026-10-04", 65],
                                                        "blend_days": _days("2026-10-05", "2026-10-14")}})
    assert fit_end(blended) == pd.Timestamp("2026-10-14")
    assert _report_window([blended], pd.Timestamp("2026-10-25"))[0] == pd.Timestamp("2026-10-15")


def test_the_report_window_takes_a_serving_refit_after_its_fit():
    from algoe.cli import _report_window
    assert _report_window([REFIT], pd.Timestamp("2026-10-25")) == (pd.Timestamp("2026-10-15"),
                                                                   pd.Timestamp("2026-10-25"), None)
    start, _, why = _report_window([REFIT], pd.Timestamp("2026-10-14"))
    assert start is None and "after" in why


# ------------------------------------------------------------------ score-days
def test_score_days_scores_each_new_day_once_and_never_a_suspect_one():
    from algoe import cli
    from algoe.evaluation import walkforward as W
    from src.backtest.parquet.quality import QUALITY

    class Panel:
        def __init__(self):
            self.asked = []

        def ensure(self, days):
            self.asked.append(list(days))

    class Parts:
        panel = Panel()
        store = object()

        def __init__(self, settings):
            pass

        def forecaster(self, version=None, required=True):
            return REFIT

    def fake_score(tf, store, d):
        day = str(d.date())
        return {"day": day, "compare": [
            {"dim": "day", "value": day, "method": W.BASE, "deviance": 2.0},
            {"dim": "day", "value": day, "method": W.MODEL, "deviance": 1.0 if d.day % 2 else 3.0}]}
    real_parts, real_score = cli.Components, W.score_day
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:     # the run's log stays open
        s = _settings(tmp)
        (Path(s.paths.data_dir) / QUALITY).write_text(json.dumps({"days": {"2026-10-17": {"verdict": "suspect"}}}),
                                                      encoding="utf-8")
        common = ["--data-dir", s.paths.data_dir, "--work-dir", str(Path(tmp) / "work"), "--log-level", "ERROR"]
        cli.Components, W.score_day = Parts, fake_score
        try:
            first = cli.main(["score-days", "--end", "2026-10-20", "--days", "14"] + common)
            files = sorted(f.stem for f in W.daily_dir(s).glob("????-??-??.json"))
            again = cli.main(["score-days", "--end", "2026-10-20", "--days", "14"] + common)
            docs = W.scored(W.daily_dir(s))
        finally:
            cli.Components, W.score_day = real_parts, real_score
    assert first == 0 and again == 0
    assert files == ["2026-10-15", "2026-10-16", "2026-10-18", "2026-10-19", "2026-10-20"], files
    assert Parts.panel.asked[1:] == [], Parts.panel.asked                  # the second run had nothing to score
    d = docs["2026-10-15"]
    assert d["turnover_model"] == "tv1" and d["fit_end"] == "2026-10-14" and W.better(d) is True
    assert W.better(docs["2026-10-16"]) is False


def test_score_days_revisits_the_days_it_scored_while_provisional():
    from algoe import cli
    from algoe.evaluation import walkforward as W
    from src.backtest.parquet.quality import QUALITY

    class Panel:
        def ensure(self, days):
            pass

    class Parts:
        panel = Panel()
        store = object()

        def __init__(self, settings):
            pass

        def forecaster(self, version=None, required=True):
            return REFIT
    scored = []

    def fake_score(tf, store, d):
        scored.append((tf.version, str(d.date())))
        day = str(d.date())
        return {"day": day, "compare": [
            {"dim": "day", "value": day, "method": W.BASE, "deviance": 2.0},
            {"dim": "day", "value": day, "method": W.MODEL, "deviance": 1.0 + len(scored)}]}
    real_parts, real_score = cli.Components, W.score_day
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:     # the run's log stays open
        s = _settings(tmp)
        q = Path(s.paths.data_dir) / QUALITY

        def verdicts(**days):
            q.write_text(json.dumps({"days": {d.replace("_", "-"): v for d, v in days.items()}}), encoding="utf-8")
        common = ["--data-dir", s.paths.data_dir, "--work-dir", str(Path(tmp) / "work"), "--log-level", "ERROR"]
        cli.Components, W.score_day = Parts, fake_score
        try:
            verdicts(**{"2026_10_19": {"verdict": "provisional"}, "2026_10_20": {"verdict": "provisional"}})
            cli.main(["score-days", "--end", "2026-10-20", "--days", "2"] + common)
            first = W.scored(W.daily_dir(s))
            # the 20th extracted again after its score
            later = str(pd.Timestamp(first["2026-10-20"]["scored_at"]) + pd.Timedelta(microseconds=1))
            verdicts(**{"2026_10_19": {"verdict": "suspect"},
                        "2026_10_20": {"verdict": "ok", "written_at": later}})
            scored.clear()
            cli.main(["score-days", "--end", "2026-10-20", "--days", "2"] + common)
            docs = W.scored(W.daily_dir(s))
        finally:
            cli.Components, W.score_day = real_parts, real_score
    assert first["2026-10-19"]["verdict"] == first["2026-10-20"]["verdict"] == "provisional"
    assert scored == [("tv1", "2026-10-20")], scored                       # scored again, by the same model
    assert docs["2026-10-19"]["verdict"] == "suspect" and docs["2026-10-20"]["verdict"] == "ok"
    assert docs["2026-10-20"].get("rescored_at") and pd.Timestamp(docs["2026-10-20"]["scored_at"]) >= pd.Timestamp(later)


# ------------------------------------------------------------------ the nightly
def test_the_nightly_scores_the_new_days_before_it_refits():
    from algoe.cli import _nightly_steps, build_parser
    names = [s[0] for s in _nightly_steps(build_parser().parse_args(["nightly"]))]
    assert names.index("build-features") < names.index("score-days") < names.index("train-turnover"), names


def test_the_nightly_records_its_run():
    from algoe import cli
    from algoe.evaluation.walkforward import daily_dir, read_nightly
    real = cli.main
    with tempfile.TemporaryDirectory() as tmp:
        s = _settings(tmp)
        args = cli.build_parser().parse_args(["nightly", "--end", "2026-10-20"])
        cli.main = lambda argv, _nested=False: 2 if argv[0] == "monitor" else 0
        try:
            code = cli.cmd_nightly(args, s, SimpleNamespace(summary={}))
        finally:
            cli.main = real
        rec = read_nightly(daily_dir(s))
    assert code == 2 and rec["exit_code"] == 2 and rec["window"][1] == "2026-10-20"
    assert [x["step"] for x in rec["steps"]][:5] == ["update-data", "build-panel", "build-features", "score-days",
                                                     "monitor"], rec["steps"]


# ------------------------------------------------------------------ the Backtest tab and the desk
def test_the_report_carries_the_walk_forward_days():
    from src.api.routes import algoe_reports
    from src.backtest.parquet.quality import QUALITY

    def rows(day, a, b):
        return [{"dim": "day", "value": day, "method": "last 5 min", "deviance": a},
                {"dim": "day", "value": day, "method": "model", "deviance": b}]
    with tempfile.TemporaryDirectory() as tmp:
        raw, work = Path(tmp) / "Raw_Data", Path(tmp) / "AlgoE_Work"
        raw.mkdir()
        rep = work / "reports" / "backtest_20261012-060000"
        rep.mkdir(parents=True)
        (rep / "report.json").write_text(json.dumps({
            "meta": {"generated": "2026-10-12 06:10"},
            "mix": {"test_days": ["2026-10-01", "2026-10-02"], "compare": rows("2026-10-01", 2.0, 1.0)}}),
            encoding="utf-8")
        daily = work / "reports" / "daily"
        daily.mkdir()
        for day, b, at in (("2026-10-02", 1.0, "2026-10-03 06:20"), ("2026-10-15", 1.0, "2026-10-16 06:20"),
                           ("2026-10-16", 3.0, "2026-10-17 06:20")):
            (daily / "{}.json".format(day)).write_text(json.dumps(
                {"day": day, "scored_at": at, "turnover_model": "tv1", "compare": rows(day, 2.0, b)}), encoding="utf-8")
        (raw / QUALITY).write_text(json.dumps({"days": {"2026-10-16": {"verdict": "ok",
                                                                       "written_at": "2026-10-18 06:05:00"}}}),
                                   encoding="utf-8")
        wf = algoe_reports.report(ids=None, work=str(work), data=str(raw))["walkforward"]
    assert wf["days"] == ["2026-10-15", "2026-10-16"] and wf["since"] == "2026-10-15", wf  # the report has 10-02
    assert wf["better"] == 1 and wf["scored"] == 1 and wf["models"] == ["tv1"]   # 10-16 changed: drawn, not counted
    assert wf["changed"] == ["2026-10-16"] and {r["value"] for r in wf["compare"]} == {"2026-10-15", "2026-10-16"}


def test_the_board_says_how_current_the_data_is():
    from algoe.evaluation.walkforward import NIGHTLY, daily_dir
    from src.api.live_payload import data_health
    from src.backtest.parquet.quality import QUALITY
    from src.backtest.parquet.raw_update import STATUS
    with tempfile.TemporaryDirectory() as tmp:
        s = _settings(tmp)
        raw = Path(s.paths.data_dir)
        (raw / STATUS).write_text(json.dumps({"ok": True, "newest_day": "2026-10-24",
                                              "finished": "2026-10-26 06:12:00"}), encoding="utf-8")
        (raw / QUALITY).write_text(json.dumps({"days": {"2026-10-10": {"verdict": "suspect"},
                                                        "2026-08-01": {"verdict": "suspect"}}}), encoding="utf-8")
        daily_dir(s).mkdir(parents=True)
        (daily_dir(s) / NIGHTLY).write_text(json.dumps({"finished": "2026-10-26 06:40:00", "exit_code": 1,
                                                        "steps": [{"step": "build-panel", "exit_code": 1}]}),
                                            encoding="utf-8")
        old = data_health(s, now="2026-10-26")
        (raw / STATUS).write_text(json.dumps({"ok": True, "newest_day": "2026-10-25"}), encoding="utf-8")
        fresh = data_health(s, now="2026-10-26")
    assert old["newest_day"] == "2026-10-24" and old["stale"] and old["suspect"] == ["2026-10-10"], old
    assert old["nightly"]["exit_code"] == 1 and old["nightly"]["failed"] == ["build-panel"]
    assert fresh["stale"] is False


# ------------------------------------------------------------------ the daily task
def test_the_daily_task_is_algoe_nightly_every_morning():
    if os.name != "nt":
        return
    out = subprocess.run(["cmd", "/c", str(DEPLOY / "algoe-schedule-daily.bat"), "--dry-run", "07:15"],
                         capture_output=True, text=True, timeout=60)
    line = out.stdout.strip()
    assert out.returncode == 0 and line.startswith('schtasks /Create /F /SC DAILY /ST 07:15 /TN "AlgoE daily" /TR "\\"')
    assert line.endswith('algoe-nightly.bat\\""'), line


def test_start_registers_the_daily_task_unless_told_not_to():
    text = (DEPLOY / "start.ps1").read_text(encoding="utf-8-sig")
    assert "[switch]$NoSchedule" in text and "algoe-schedule-daily.bat" in text
    assert 'schtasks.exe /Query /TN "AlgoE daily"' in text and "--quiet" in text
    if os.name != "nt":
        return
    check = ("$e = $null; $null = [System.Management.Automation.Language.Parser]::ParseFile('{}', [ref]$null, "
             "[ref]$e); $e.Count").format(DEPLOY / "start.ps1")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", check], capture_output=True, text=True, timeout=120)
    assert out.stdout.strip() == "0", out.stdout + out.stderr


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<72} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<72} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
