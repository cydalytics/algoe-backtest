"""
Step 07 - train / serve parity on the real data

Builds one bucket twice - the way training reads it (cached day) and the way
the live engine serves it (Raw_Data replayed as of the bucket start) - and
compares every model input row by row. The serving path cannot see inside
the bucket, so any difference is a skew or a leak. Run it after any change
to the panel, the features or the data feed, before trusting a model live.

    python scripts/s07_parity.py --at "2026-09-10 21:30" --at "2026-09-11 00:05"

Exit code 1 if anything differs. Same as: python -m algoe parity
"""
from _algoe import run

if __name__ == "__main__":
    run("parity")
