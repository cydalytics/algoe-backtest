"""Feature engineering: one catalog, one engineer, hierarchical encoders."""
