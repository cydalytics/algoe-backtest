# Features and the hypotheses they test

Generated from `backend/algoe/features/catalog.py` (feature version 4) and the backtest's
feature-group ablation on the synthetic world (`compare_feature_groups`: drop the group,
refit the GLM, compare validation deviance - positive = the group helps). Re-generate after
the first real-data backtest; the synthetic verdicts only show the machinery works.

## Hypotheses

| id | hypothesis | groups | ablation (synthetic) |
|----|------------|--------|---------|
| H1 | Match money is autocorrelated: recent match totals predict the next bucket (+). | memory_match | match_total -5.3% (hurts) |
| H2 | Pre-match money ramps up towards kick-off (hyperbolic in minutes to KO). | lifecycle | match_total +12.1% (supported); selection_share +0.3% (supported) |
| H3 | In-play money follows the clock: rises through the match, dips at half time. | lifecycle | match_total +12.1% (supported); selection_share +0.3% (supported) |
| H4 | Goals and red cards cause a demand spike that decays over ~5-15 minutes (+). | events | match_total +10.4% (supported); selection_share +0.1% (no effect) |
| H5 | Some leagues / matches draw far more money; a shrunk league level and the match's own running level carry it (+). | popularity | match_total +11.8% (supported); selection_share +0.0% (no effect) |
| H6 | Concurrent matches split attention: more live matches -> less per match (-). | concurrency | match_total +3.4% (supported) |
| H7 | Weekend, evening and holiday buckets take more money (+). | calendar | match_total +2.2% (supported) |
| H8 | Close, high-scoring games take more in-play money; a settled blowout takes less. | competitiveness, events | match_total +10.4% (supported); match_total -0.3% (hurts); selection_share +0.1% (no effect) |
| H9 | More pools / lines open -> more money on the match (+). | breadth | match_total -36.0% (hurts) |
| H11 | Pool shares depend on phase (FH pools die at half time, totals gain late). | bet_type, lifecycle, popularity | match_total +11.8% (supported); match_total +12.1% (supported); selection_share +0.0% (no effect); selection_share +0.3% (supported); selection_share -0.0% (no effect) |
| H12 | Recent pool shares persist (+). | memory_pool | - |
| H14 | The main (most balanced) line takes most of a pool; share decays with distance (-). | line_position | selection_share +2.3% (supported) |
| H15 | Within a line the side whose price is more generous (vs HKJC's own true odds or the market) takes more money (+): this is the price elasticity the optimiser uses. | price | selection_share +5.2% (supported) |
| H16 | Punters prefer some sides (overs, favourites) independent of price. | bet_type | selection_share -0.0% (no effect) |
| H17 | A price that has just shortened signals money that keeps coming (herding). | price | selection_share +5.2% (supported) |
| H18 | A selection's recent share of its pool persists (+). | memory_selection | selection_share +4.8% (supported) |
| H19 | When the main line moves, the money follows the position, not the old line id. | line_position, memory_selection | selection_share +2.3% (supported); selection_share +4.8% (supported) |
| H20 | Stale prices (no update for a long time) take little money (-). | price | selection_share +5.2% (supported) |

## Expected signs (GLM coefficients, synthetic)

| feature | hypothesis | expected | coefficient | agrees |
|---|---|---|---|---|
| n_live | H6 | - | -0.0152 | yes |
| goal_p3 | H4 | + | +1.2109 | yes |
| m_log_l1 | H1 | + | -0.1776 | **no** |
| weekend | H7 | + | +0.0141 | yes |
| league_level | H5 | + | +0.2106 | yes |
| value_true | H15 | + | +0.0971 | yes |
| value_mkt | H15 | + | -0.6847 | **no** |
| rank_0 | H14 | + | +0.0604 | yes |
| abs_line_offset | H14 | - | +0.0208 | **no** |
| log_odds_age | H20 | - | -0.8255 | yes |

Where a sign disagrees, the feature is usually collinear with a sibling (for example
`m_log_l1` with the match EWMA) or, in the synthetic world, shifted by the new pool code
launched mid-window (the breadth group: pool and line counts jump for every match, and a
linear model extrapolates; the GBM champion does not). These are the checks to read first
on real data.

## Match level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `m_log_l1` | memory_match | raw | H1 | 0 | [0, 20] | log1p match money T-1 |
| `m_log_l2` | memory_match | raw | H1 | 0 | [0, 20] |  |
| `m_log_l3` | memory_match | raw | H1 | 0 | [0, 20] |  |
| `m_log_ewma` | memory_match | raw | H1 | 0 | [0, 20] | log1p EWMA of 6 lags |
| `m_any_l1` | memory_match | flag | H1 | 0.0 |  |  |
| `m_trend` | memory_match | raw | H1 | 0 | [-15, 15] | log1p l1 - log1p l2 |
| `m_log_today` | memory_match | raw | H1 | 0 | [0, 25] | log1p money so far today |
| `inplay` | lifecycle | flag | H3 | 0.0 |  |  |
| `halftime` | lifecycle | flag | H3 | 0.0 |  |  |
| `stoppage` | lifecycle | flag | H3 | 0.0 |  | minute > 90 |
| `pre_ko_min` | lifecycle | raw | H2 | 360 | [0, 720] | minutes to KO, pre-match |
| `minute` | lifecycle | raw | H3 | 0 | [0, 130] | match minute in play |
| `ko_h0` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 0, 0) |
| `ko_h1` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 5, 0) |
| `ko_h2` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 10, 0) |
| `ko_h3` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 15, 0) |
| `ko_h4` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 30, 0) |
| `ko_h5` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 45, 0) |
| `ko_h6` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 60, 0) |
| `ko_h7` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 90, 0) |
| `ko_h8` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 120, 0) |
| `ko_h9` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 180, 0) |
| `ko_h10` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 240, 0) |
| `ko_h11` | lifecycle | basis | H2 | 0.0 | [0.0, ] | max(x - 360, 0) |
| `min_h0` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 5, 0) |
| `min_h1` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 15, 0) |
| `min_h2` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 30, 0) |
| `min_h3` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 40, 0) |
| `min_h4` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 45, 0) |
| `min_h5` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 50, 0) |
| `min_h6` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 60, 0) |
| `min_h7` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 70, 0) |
| `min_h8` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 80, 0) |
| `min_h9` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 88, 0) |
| `min_h10` | lifecycle | basis | H3 | 0.0 | [0.0, ] | max(x - 95, 0) |
| `goal_p3` | events | raw | H4 | 0 | [0, 5] | sum exp(-age/3) over goals |
| `goal_p10` | events | raw | H4 | 0 | [0, 5] |  |
| `red_p10` | events | raw | H4 | 0 | [0, 3] |  |
| `goals_so_far` | events | raw | H8 | 0 | [0, 12] |  |
| `abs_score_diff` | events | raw | H8 | 0 | [0, 10] |  |
| `since_goal` | events | raw | H4 | 1 | [0, 1] | min(minutes since goal, 120)/120 |
| `league_level` | popularity | encoded | H5 | 0 | [-10, 10] | shrunk league log-money level vs global |
| `league_known` | popularity | flag | H5 | 0.0 |  |  |
| `n_live` | concurrency | raw | H6 | 0 | [0, 200] | matches in play now |
| `n_board` | concurrency | raw | H6 | 0 | [0, 500] | matches on the board now |
| `log_board_l1` | concurrency | raw | H6 | 0 | [0, 25] |  |
| `match_share_board_l1` | concurrency | raw | H6 | 0 | [0, 1] |  |
| `match_rank_l1` | concurrency | raw | H6 | 0.5 | [0, 1] | rank by money / n_board |
| `weekend` | calendar | flag | H7 | 0.0 |  |  |
| `holiday` | calendar | flag | H7 | 0.0 |  |  |
| `evening` | calendar | flag | H7 | 0.0 |  | HK 19:00-23:59 |
| `hour_s1` | calendar | raw | H7 | 0.0 |  |  |
| `hour_c1` | calendar | raw | H7 | 0.0 |  |  |
| `hour_s2` | calendar | raw | H7 | 0.0 |  |  |
| `hour_c2` | calendar | raw | H7 | 0.0 |  |  |
| `dow_s` | calendar | raw | H7 | 0.0 |  |  |
| `dow_c` | calendar | raw | H7 | 0.0 |  |  |
| `tg_full` | competitiveness | raw | H8 | 2.6 | [0, 12] | expected full-match goals: scored + still to come |
| `abs_sup` | competitiveness | raw | H8 | 0 | [0, 6] |  |
| `balance` | competitiveness | raw | H8 | 0 | [0, 1] | /sup/ / tg |
| `log_n_pools` | breadth | raw | H9 | 0 | [0, 5] |  |
| `log_n_lines` | breadth | raw | H9 | 0 | [0, 7] |  |

## Pool level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `p_share_l1` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_share_l2` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_share_ewma` | memory_pool | raw | H12 | 0 | [0, 1] |  |
| `p_any_l1` | memory_pool | flag | H12 | 0.0 |  |  |
| `p_log_l1` | memory_pool | raw | H12 | 0 | [0, 20] |  |
| `p_n_lines` | breadth | raw | H9 | 0 | [0, 5] | log1p lines open in the pool |
| `p_balance` | line_position | raw | H14 | 0.5 | [0, 1] | min /pH - pA/ over the pool's lines |
| `p_margin` | price | raw | H15 | 0.08 | [-0.2, 0.6] | book margin of the main line |
| `pool_level` | popularity | encoded | H11 | 0 | [-10, 10] | shrunk log share of this pool (by phase), parent = family |
| `first_half` | bet_type | flag | H11 | 0.0 |  |  |
| `extra_time` | bet_type | flag | H11 | 0.0 |  |  |
| `fh_to_ht` | lifecycle | raw | H11 | 1 | [0, 1] | first-half pool: share of FH left |
| `inplay` | lifecycle | flag | H11 | 0.0 |  |  |
| `minute` | lifecycle | raw | H11 | 0 | [0, 130] |  |
| `pre_ko_min` | lifecycle | raw | H11 | 360 | [0, 720] |  |
| `fam_goal_total` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_total_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_hdc` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_hdc_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_1x2` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_1x2_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_exact` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_exact_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_goal_other_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_total` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_total_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_hdc` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_hdc_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_corner_other_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_all_up` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_all_up_ip` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_other` | bet_type | flag | H11 | 0.0 |  |  |
| `fam_other_ip` | bet_type | flag | H11 | 0.0 |  |  |

## Selection level

| feature | group | kind | hyp. | fill | range | description |
|---|---|---|---|---|---|---|
| `s_log_l1` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_l2` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_l3` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_ewma_fast` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_log_ewma_slow` | memory_selection | raw | H18 | 0 | [0, 20] |  |
| `s_any_l1` | memory_selection | flag | H18 | 0.0 |  |  |
| `s_any_l6` | memory_selection | flag | H18 | 0.0 |  |  |
| `s_share_pool_l1` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_pool_l2` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_pool_ewma` | memory_selection | raw | H18 | 0 | [0, 1] |  |
| `s_share_line_l1` | memory_selection | raw | H18 | 0.5 | [0, 1] |  |
| `pos_share_l1` | memory_selection | raw | H19 | 0 | [0, 1] | money in the same (pool, rank, side) position at T-1 / pool money T-1 |
| `s_log_tickets_l1` | memory_selection | raw | H18 | 0 | [0, 12] |  |
| `s_log_avg_stake_l1` | memory_selection | raw | H18 | 0 | [0, 15] |  |
| `imp` | price | raw | H15 | 0.5 | [0, 1] | 1 / odds |
| `log_odds` | price | raw | H15 | 0.7 | [0, 7] |  |
| `value_true` | price | raw | H15 | -0.07 | [-1, 2] | odds x p(HKJC true) - 1: punter value on HKJC's own belief |
| `value_mkt` | price | raw | H15 | 0 | [-1, 2] | odds x p(market) - 1 |
| `hk_vs_mkt` | price | raw | H15 | 0 | [-0.5, 0.5] | odds / market odds - 1 |
| `has_mkt` | price | flag | H15 | 0.0 |  |  |
| `odds_move_5` | price | raw | H17 | 0 | [-1, 1] | log odds now - 5 min ago |
| `odds_move_15` | price | raw | H17 | 0 | [-1, 1] |  |
| `log_odds_age` | price | raw | H20 | 0 | [0, 7] | log1p minutes since price update |
| `rank_0` | line_position | flag | H14 | 0.0 |  | main line |
| `rank_1` | line_position | flag | H14 | 0.0 |  |  |
| `rank_2p` | line_position | flag | H14 | 0.0 |  |  |
| `line_offset` | line_position | raw | H14 | 0 | [-8, 8] | line - main line |
| `abs_line_offset` | line_position | raw | H14 | 0 | [0, 8] |  |
| `line_balance` | line_position | raw | H14 | 0 | [0, 1] | /pH - pA/ on this line |
| `main_moved` | line_position | flag | H19 | 0.0 |  |  |
| `line_age` | line_position | raw | H19 | 1 | [0, 1] | min(minutes priced, 600)/600 |
| `n_lines_pool` | line_position | raw | H14 | 0 | [0, 5] | log1p lines in pool |
| `side_home_over` | bet_type | flag | H16 | 0.0 |  |  |
| `side_draw` | bet_type | flag | H16 | 0.0 |  |  |
| `is_fav` | bet_type | flag | H16 | 0.0 |  | shorter-priced side of its line |
| `first_half` | bet_type | flag | H11 | 0.0 |  |  |
| `inplay` | lifecycle | flag | H3 | 0.0 |  |  |
| `minute` | lifecycle | raw | H3 | 0 | [0, 130] |  |
| `since_goal` | events | raw | H4 | 1 | [0, 1] |  |
| `fam_goal_total` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_hdc` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_1x2` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_exact` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_goal_other` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_total` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_hdc` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_corner_other` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_all_up` | bet_type | flag | H16 | 0.0 |  |  |
| `fam_other` | bet_type | flag | H16 | 0.0 |  |  |
| `pool_level` | popularity | encoded | H11 | 0 | [-10, 10] |  |

Kinds: `raw` numeric (clipped to its range, missing -> fill); `basis` hinge / spline terms of a
clock; `flag` 0/1; `encoded` empirical-Bayes level of a category shrunk to its parent (an
unseen value gets its parent's level). Every value is finite by construction: missing,
infinite or out-of-range inputs become the fill or the bound, never NaN.
