"""
Engine Reply

What the pricing engine's reply says about the parameters we sent, read against
our own book:

    join_reply(frame, rows)       the reply's selections on our rows: by (pool_id, line_id,
                                  combination_id), else by (pool, line value, label)
    engine_gm(book, joined, opt)  E[GM] with our belief and our demand at the engine's sell
                                  prices; a selection it does not offer takes no money
    replication_gap(...)          1 / TrueOdds against our pricer at what we sent (theta and the
                                  draw factor), per selection and pool; the first half under both
                                  readings of the split before kick-off
    weight_echo(frame, sent)      every weight we sent must come back as that selection's Weight
    clock_check(reply, header)    the reply's GameState and clock against ours

A large replication gap means our model of the engine's pricing does not hold
for those pools, so theta* cannot be trusted there; a weight that does not come
back means the mapping's PoolType or SelectionId is wrong.

Change Log:
-----------
2026-10-29      Initialize
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from src.hkjc.kafka_messages import draw_factor_from_engine

from ..pricing.pricer import BookPricer, Conventions, repair_theta, theta_from_params

KEY = ["pool_id", "line_id", "combination_id"]
ENGINE = {"true_odds": "engine_true_odds", "sell_odds": "engine_sell_odds", "weight": "engine_weight",
          "margin": "engine_margin", "offered": "engine_offered"}


def _line_key(v) -> float:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return 0.0
    return round(v, 2) + 0.0 if np.isfinite(v) else 0.0


def join_reply(frame: pd.DataFrame, rows: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """Our rows with the engine's prices beside them, and how each was matched."""
    keep = [c for c in KEY + ["pool_name", "combination_string", "line", "line_label"] if c in rows.columns]
    r = rows[keep].copy()
    for c in KEY:
        r[c] = pd.to_numeric(r[c], errors="coerce").astype("int64")
    r = r.drop_duplicates(KEY).reset_index(drop=True)
    f = frame.rename(columns=ENGINE).copy()
    for c in KEY:
        f[c] = pd.to_numeric(f[c], errors="coerce").astype("int64")
    vals = list(ENGINE.values())
    out = r.merge(f[KEY + vals].drop_duplicates(KEY), on=KEY, how="left")
    out["joined_by"] = np.where(out["engine_true_odds"].notna() | out["engine_sell_odds"].notna(), "id", None)
    used = set(map(tuple, out.loc[out["joined_by"] == "id", KEY].to_numpy().tolist()))
    rest = f[[tuple(k) not in used for k in f[KEY].to_numpy().tolist()]]
    need = out["joined_by"].isna()
    if need.any() and len(rest):
        lab = pd.DataFrame({"_pool": rest["pool_type"].astype(str).str.upper().to_numpy(),
                            "_line": [_line_key(v) for v in rest["line_value"]],
                            "_lab": rest["label"].astype(str).str.strip().to_numpy(),
                            **{c: rest[c].to_numpy() for c in vals}}).drop_duplicates(["_pool", "_line", "_lab"])
        ask = pd.DataFrame({"_i": np.flatnonzero(need.to_numpy()),
                            "_pool": out.loc[need, "pool_name"].astype(str).str.upper().to_numpy(),
                            "_line": [_line_key(v) for v in out.loc[need, "line"]],
                            "_lab": out.loc[need, "combination_string"].astype(str).str.strip().to_numpy()})
        got = ask.merge(lab, on=["_pool", "_line", "_lab"], how="inner")
        for c in vals:
            out.loc[got["_i"].to_numpy(), c] = got[c].to_numpy()
        out.loc[got["_i"].to_numpy(), "joined_by"] = "label"
    out["engine_offered"] = out["engine_offered"].fillna(False).astype(bool)
    by_id, by_label = int((out["joined_by"] == "id").sum()), int((out["joined_by"] == "label").sum())
    return out, {"reply": int(len(f)), "by_id": by_id, "by_label": by_label,
                 "unmatched": int(len(f) - by_id - by_label), "ours_unpriced": int(out["joined_by"].isna().sum())}


def _on_book(book, joined: pd.DataFrame, cols) -> pd.DataFrame:
    k = book.keys[KEY].astype("int64").reset_index(drop=True)
    return k.merge(joined[KEY + list(cols)].drop_duplicates(KEY), on=KEY, how="left")


def engine_gm(book, joined: pd.DataFrame, opt, only: Optional[np.ndarray] = None) -> Optional[float]:
    """E[GM] at the engine's sell prices with our belief and our demand response; None without prices."""
    if book is None or joined is None or book.keys is None:
        return None
    m = _on_book(book, joined, ["engine_sell_odds", "engine_offered"])
    odds = m["engine_sell_odds"].to_numpy(dtype="float64")
    offered = m["engine_offered"].fillna(False).astype(bool).to_numpy()
    odds = np.where(offered & np.isfinite(odds) & (odds > 1.0), odds, np.nan)
    if only is not None:
        odds = np.where(np.asarray(only, dtype=bool), odds, np.nan)
    sold = np.isfinite(odds)
    if not sold.any():
        return None
    T = opt.demand_at(book, np.where(sold, odds, book.odds_now))
    return opt.expected_gm(book, np.where(sold, odds, 1.0), np.where(sold, T, 0.0))


def replication_gap(book, joined: pd.DataFrame, sent: dict, header: dict, opt, mapping=None,
                    alert: float = 0.02) -> Optional[dict]:
    """|1 / engine TrueOdds - our probability| at the theta and draw factor we sent."""
    if book is None or joined is None or not sent or not sent.get("theta"):
        return None
    m = _on_book(book, joined, ["engine_true_odds"])
    with np.errstate(divide="ignore", invalid="ignore"):
        p_eng = 1.0 / m["engine_true_odds"].to_numpy(dtype="float64")
    df = float(book.draw_factor or 1.0)
    if mapping is not None and (sent.get("engine") or {}).get("DrawFactor") is not None:
        df = draw_factor_from_engine(sent["engine"]["DrawFactor"], mapping)
    o = opt.settings.optimizer
    pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap, draw_factor=df))
    theta = repair_theta(sent["theta"])
    p_ours, _ = pricer.probabilities(book.rows, theta, book.state)
    gap = np.abs(p_eng - p_ours)
    ok = np.isfinite(gap)
    if not ok.any():
        return None
    pools = {}
    for pool in np.unique(book.pool[ok]):
        g = gap[ok & (book.pool == pool)]
        pools[str(pool)] = {"max": float(g.max()), "mean": float(g.mean()), "n": int(len(g))}
    worst = max(pools, key=lambda k: pools[k]["max"])
    fh = {}
    first = np.char.endswith(book.rows.theta_domain.astype(str), "_fh") & ok
    if first.any() and not book.state.in_play:
        splits = header.get("splits") or {}
        for reading in ("as_first_half", "as_second_half"):
            th = theta_from_params(theta["goal_tg"], theta["goal_sup"], theta["corner_tg"], theta["corner_sup"],
                                   splits.get("goal") or 0.45, splits.get("corner") or 0.47, book.state, reading)
            p_r, _ = pricer.probabilities(book.rows, repair_theta(th), book.state)
            fh[reading] = float(np.nanmean(np.abs(p_eng[first] - p_r[first])))
    top = float(gap[ok].max())
    by_row = book.keys[KEY].astype("int64").reset_index(drop=True).assign(engine_gap=gap)
    return {"max": top, "mean": float(gap[ok].mean()), "n": int(ok.sum()), "pools": pools, "worst_pool": worst,
            "alert": bool(top > alert), "first_half": fh, "by_row": by_row}


def weight_echo(frame: pd.DataFrame, sent_weights: Dict[tuple, float]) -> List[str]:
    """The weights we sent that the engine does not show back, each named."""
    if not sent_weights:
        return []
    got = {(str(p).upper(), _line_key(lv), str(lab).strip()): w
           for p, lv, lab, w in zip(frame["pool_type"], frame["line_value"], frame["label"], frame["weight"])}
    bad = []
    for (pool, line, label), w in sent_weights.items():
        e = got.get((str(pool).upper(), _line_key(line), str(label).strip()))
        where = "{} {:g} {}".format(pool, _line_key(line), label)
        if e is None:
            bad.append("{}: sent {:g}, the engine has no such selection".format(where, w))
        elif not np.isfinite(e) or abs(float(e) - float(w)) > 1e-6:
            bad.append("{}: sent {:g}, engine {:g}".format(where, w, e))
    return bad


def clock_check(reply, header: dict, tolerance: float) -> List[str]:
    """The reply's GameState and clock against our read of the match."""
    notes = []
    ours, theirs = str(header.get("game_state") or "").strip(), str(getattr(reply, "game_state", "") or "").strip()
    if ours and theirs and ours.lower() != theirs.lower():
        notes.append("state: we read {}, the engine {}".format(ours, theirs))
    secs = getattr(reply, "clock_seconds", None)
    if header.get("in_play") and getattr(reply, "clock_set", False) and secs is not None and np.isfinite(secs) \
            and str(header.get("phase") or "") != "half_time":     # HKJC holds the clock at 45:00 at the break
        m = float(header.get("minute") or 0.0)
        if abs(float(secs) - m * 60.0) > tolerance:
            notes.append("clock: ours {:.1f}', the engine's {:.1f}'".format(m, float(secs) / 60.0))
    return notes
