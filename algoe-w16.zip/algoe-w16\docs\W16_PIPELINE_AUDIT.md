# W16 pipeline audit

Every pipeline the desk depends on, checked for what it does, whether it is right, and what proves it.
Item 6 of the W16 brief ("evaluate every pipeline and its logic, including slow in-play updates").
Evidence is a test name (backend/tests), a selftest step, or a command run on this machine; **office**
marks what only the office box (real SQL, real money) can settle.

## 1. Why in play felt slow, and what changed

| Cause | Finding | Fix | Evidence |
|---|---|---|---|
| The trigger scan | Every 15 s it read the **whole card** from SQL (7 queries over every match's whole history), on the sweep thread. | Reads only the matches off the fast lane, every 60 s (`live.scan_seconds`); the fast lane reads its own. | `test_the_scan_reads_only_the_matches_off_the_fast_lane` |
| Whole-history reads | The fast lane re-read each match's odds, market odds and money from the first row every 15 s; the odds query also looks up the true odds for every row. | Incremental reads (`src/hkjc/incremental.py`): per match and table, rows since the newest row held (the data's own clock) less 2 min, merged by key; each sweep's full read reconciles them per match and table (both sides, true odds and tickets too); full reads while they differ, off after three failed reconciles in a row. | `test_incremental_reads_equal_full_reads_on_the_simulator`, `test_the_sweep_reconciles_and_a_mismatch_falls_back_to_full_reads`, `test_reads_that_keep_failing_their_reconcile_stay_full`, selftest S14 (incremental = full on 5 books, mismatch 0.0000) |
| One model lock | The sweep's turnover forecast of the whole card held the only model lock; the fast lane's belief, every cycle, waited behind it. | A lock per model. | `test_the_fast_lanes_belief_does_not_wait_for_the_sweeps_forecast` |
| Bucket boundary | At each new bucket the fast lane rebuilt the bucket-start panel and ran the turnover model inside its cycle, at the same moment as the sweep. | It carries each match's forecast of the new bucket from its last read until the sweep's lands. | `test_a_bucket_boundary_carries_the_last_reads_next_bucket` |
| Who refreshes what | Before W16 only the in-play cycle ran every 15 s, and only with publishing on; pre-match matches near kick-off waited for the 5-minute sweep. | The fast lane: in play and the last 90 minutes, every 15 s, publishing on or off. | `test_the_fast_lane_covers_in_play_and_the_last_90_minutes`, `test_the_fast_lane_runs_with_publishing_off` |
| Measuring it | Only the last cycle's timings were visible. | p50 / p95 cycle seconds, the SQL read, behind, data age at publish, the weightings' churn (`/api/live/status` `metrics`, the publishing strip); `bench-live`. | `test_the_status_carries_the_cycle_metrics`, `test_bench_live_prints_the_cycle_times`; S14 p50 3.99 s, p95 4.64 s (5 matches, replay) |

**Office:** `python -m algoe bench-live --source sql --cycles 20` on a busy evening gives the real
p50 / p95 and the SQL read time; the simulator cannot.

## 2. Money and the bucket

| Check | Finding | Test / fix | Evidence |
|---|---|---|---|
| How money enters the bucket | `_observed` sums each selection's rows with `start_sell_time` from the bucket start to the read; elapsed minutes subtract `live.data_lag_seconds` (default 0). | Unchanged. Ticket credibility added (`live.nowcast_ticket_k` 3: one ticket counts as a quarter of its money). | `test_one_big_ticket_moves_the_rest_of_the_bucket_less_with_ticket_credibility` |
| Feed lag | A lag of the money table would read as no money in the last minute and pull the nowcast down. | Set `live.data_lag_seconds` once measured. | **office:** `algoe-6-probe-live.bat --match <id>` prints the newest minute against the clock |
| Per minute or cumulative | `ticket_bets_dtl_agg_mem` is read as one row per selection and minute; a cumulative table would count money many times. | The probe checks for running totals. | **office:** `probe-live` (`--tickets`) |
| ReadOnly replica empty | The in-memory money table may not exist on the readable secondary: money 0 everywhere, as in the office screenshots. | `probe-live --intent both`; `ALGOE_SQL_INTENT_BIS2=readwrite` with DE's agreement; the board says `live money feed empty` after 3 reads expecting HK$20K with none. | `test_the_probe_compares_the_live_money_on_both_intents`, `test_an_empty_money_feed_is_flagged_after_three_reads`; **office** run |
| Money check false alarms | The scan's check counted far-curve forecasts and fast-lane matches it did not read. | Counts model-window rows of the matches it read only. | `test_the_scans_money_check_counts_only_the_model_window` |
| Solve horizon | The sweep prices the whole bucket's forecast; the fast lane and a cockpit read price the nowcast rest of the bucket and the next one (money already in was struck at the old price). | The cockpit says which (`horizon`). | `test_the_cockpit_shows_the_buckets_money` |

## 3. The live engine

| Check | Finding | Test / fix | Evidence |
|---|---|---|---|
| Sweep `board_at` | The sweep stamps its rows with the bucket start: its panel is the bucket as it started (the training rule: bucket T uses what was known at T), so the stamp is right; the fast lane stamps the read. | As designed. | S8 parity identical at 00:00, 22:45, 22:50 |
| Sweep vs fast lane | A sweep that read after the fast lane installed its own decision, weightings and board row over the fast lane's. | The sweep hands a fast-lane match only its forecast. | `test_the_sweep_leaves_a_fast_lane_match_to_the_fast_lane` |
| Sweep vs focus | A focus refresh newer than the sweep keeps its read. | Unchanged (W12). | `test_publishing_while_the_desk_reads_never_deadlocks`, S9 |
| A dead solver worker | One crashed worker broke the shared process pool for good: every later sweep and cycle failed. | The card finishes in-process; the pool is replaced. | `test_a_broken_pool_finishes_the_card_here`, `test_the_engine_replaces_a_broken_pool` |
| The budget | Each fast-lane book is solved or marked behind and solved first next cycle; the cycle stays inside 15 s. | Unchanged; the default lane is now tested. | `test_the_default_fast_lane_keeps_its_cycle_inside_fast_seconds`, `test_forty_in_play_matches_inside_the_budget` (8.3 s) |
| Every match on sale | Four gates left most pre-match matches unsolved (6 h window, 90 min odds age, no TG/SUP row, HK$500). | Far curve, old odds kept live, implied θ (desk only), little money held. | `test_a_far_match_on_sale_is_solved`, `test_a_match_without_hkjc_tgsup_is_priced_at_implied_theta_and_never_published`, `test_prematch_lines_with_old_odds_stay_in_the_live_book`, `test_a_match_with_little_money_is_solved_and_held` |
| A match with no book | The board said "no priceable line market" for a match whose TG/SUP row was missing. | Names the missing block. | `test_a_match_without_a_book_says_why` |
| θ age alert | Raised on pre-match rows days old (HKJC moves pre-match TG/SUP rarely). | In play only (`live.theta_age_alert_inplay_min` 2). | `test_the_theta_age_alert_is_for_matches_in_play` |

## 4. The optimizer

| Check | Finding | Test / fix | Evidence |
|---|---|---|---|
| Stage 1 bands | θ* inside `theta_band` around HKJC's θ, within `prob_band` (0.05) of HKJC's implied probabilities, never below the board's E[GM]. | Unchanged. | `test_optimizer_with_no_money_and_with_a_flood` |
| Market cap | A main-line offer never beats the best external price (stage 1); no weighted price passes the best of market / HKJC / θ* on any line with a market price (stage 2). | Stage 2's guard on every line. | `test_the_weighting_market_guard_covers_every_line` |
| Stage 2 overround | Each line keeps its overround: what one side gains in implied probability the others give up. | Shown per line on the desk. | `test_partial_adjustment_moves_halfway_and_keeps_each_lines_overround`, `test_the_cockpit_shows_each_selections_weighting` |
| Stage 2 step cap | The cap could be bypassed: a gate failure, a held match and a budget drop all reset weightings to 1 at once. | Chained weightings unwind at the cap; the constraints come before it (a pool whose last weightings break one is reset, `weighting_reset`). | `test_stale_weightings_unwind_at_the_cap_through_optimize_match`, `test_a_little_money_hold_keeps_the_last_weightings`, `test_a_match_the_sweep_does_not_reach_keeps_its_last_weightings`, `test_last_weightings_that_break_the_market_guard_go_back_to_theta_star` |
| Sensitivity | Stage 2 moved fully on every refresh. | Step cap 0.01 / 0.02, half way, 0.5 bp deadband, ticket credibility. | `test_stage2_steps_at_most_the_sweep_cap_from_the_last_weights`, `test_a_deadband_keeps_the_last_weights` |
| Backtest churn | Measured between sampled decisions each from 1, so it cannot show the live damping. | Labelled as such; the live chain's churn is a live metric. | report `weightings.stage2`; `metrics.churn` |

## 5. Publishing

| Check | Finding | Test / fix | Evidence |
|---|---|---|---|
| In-play TG | algo_param TG / SUP in play are read as the rest-of-match expectancy (`θ = remaining` on the board). | Unchanged. | S13 replication gap 0.0000 on our pricing |
| First-half split | Which reading of the split the engine uses is the office check `--only replication`; the desk tags first-half pools `FH split unverified`. | Unchanged. | S13 `as_first_half` 0.0000 vs `as_second_half` 0.0936 on the mock; **office** |
| Quantize | θ and weightings are rounded to the engine's precision; a match never sent before is not sent when rounding loses the gain. | Unchanged. | `test_publisher.py` |
| Implied θ | Never published (a message carries all four values; an implied block has no HKJC value). A match that turns implied after we published says our message stays on the engine. | Explicit reason. | `test_a_started_match_that_turns_implied_says_our_message_stays` |
| Pre-match fast lane | Published with `update: "refresh"`. | New. | `test_a_fast_lane_match_before_kick_off_is_published_as_refresh` |

## 6. History, data quality, the daily job

| Check | Finding | Test / fix | Evidence |
|---|---|---|---|
| The red day | A Match_Investments day extracted before its bets were loaded (12 KB) looked like any other day, and the model lost on it. | Each day checked before it is written: pools with money vs pools concluded, money vs the usual day; suspect days left out of panels, fits and scores; a smaller extract never replaces a file. | `test_quality.py` (14 tests) |
| Old days | Days on disk before the check had no verdict. | `check-data` judges and saves every day. | `test_check_data_gives_every_day_on_disk_a_verdict`; **office:** `algoe-1-check-data.bat`, then `algoe-update-data.bat --days 2026-09-27:2026-09-28` |
| Archived bet databases | The list of archives ended at 2026-02; later months read the current databases. | `sys.databases` lists them; the list is the fallback. | `test_bet_databases_are_found_in_sys_databases` |
| Stale data | Nothing ran unless someone registered a task by hand (the nightly needed an elevated prompt). | `start.ps1` registers `AlgoE daily` (no admin); the nightly scores each new day walk-forward before it refits. | `test_daily.py` (9 tests); score-days on the selftest champion scored 2026-07-08..10 |
| Reports and refits | A serving refit was refused by `--report` and `backtest` even for days after its fit. | Accepted for days after its recorded fit window. | `test_the_report_window_takes_a_serving_refit_after_its_fit` |

## 7. Clocks

| Check | Finding | Open |
|---|---|---|
| Time zones | Every time is naive Hong Kong local: SQL timestamps, the engine's clock, bucket floors. | none found |
| Clock offset | The office box's clock against the SQL server's is not checked. A skew of a minute moves the bucket's elapsed time. Incremental reads no longer depend on it: they start from the newest row's own time. | **office:** compare `SELECT GETDATE()` with the box's clock once; set `live.data_lag_seconds` if they differ |
| The pricing engine's clock | Its replies carry its clock; `engine_reply.clock_check` compares it with ours. | unchanged |

## 8. What only the office can settle

1. `algoe-6-probe-live.bat --match <a match in play> --intent both`: whether ReadOnly sees the money table,
   and whether it is per minute.
2. `algoe-1-check-data.bat`: the verdicts on every day; 2026-09-27/28 expected suspect, then
   `algoe-update-data.bat --days 2026-09-27:2026-09-28`.
3. `algoe-8-fit-far-prematch.bat`: the far curve's held-out WAPE against last 5 minutes.
4. `python -m algoe bench-live --source sql --cycles 20` on a busy evening.
5. `schtasks /Query /TN "AlgoE daily"` after the first `start.bat`.

## 9. Cross-model review (R2)

The optimizer, live engine, incremental reads, data quality and walk-forward diffs went to two reviewers on
other model families (GPT, Gemini), each blind to the other. Every finding was checked against the code:
fixed with a test that fails on the code before the fix (all 22 did), or kept as designed with the reason.

| Finding | Raised by | Verdict | Fix and test |
|---|---|---|---|
| A chained unwind scoring below the board went out as weightings of 1 (a jump on the wire), then back | GPT, Gemini | fixed | `quantize` sends chained weightings while they keep every guard. `test_a_chained_unwind_goes_out_rather_than_jump_to_one` |
| A sweep forecast that landed before the fast lane's first cycle of the bucket was replaced by the carried one; a late sweep could overwrite the next bucket's | Gemini | fixed | `MatchLive.forecast_bucket`. `test_the_sweeps_forecast_that_lands_first_is_not_carried_over`, `test_a_late_sweep_does_not_overwrite_the_next_buckets_forecast` |
| Incremental reads started from this PC's clock: a PC ahead of SQL (or a lagging replica) skipped rows | GPT, Gemini | fixed | The newest row's own time per match and table. `test_incremental_reads_start_from_the_data_clock_not_this_machine` |
| The reconcile used one cut for all matches ever read, never dropped finished ones, pooled the tables, ignored true odds, tickets and rows only the cache held, and a full-vs-full compare ended the fallback | GPT, Gemini | fixed | Per match and table on the incrementally read rows, outer join, finished matches dropped, three failures and off. `test_the_reconcile_still_sees_a_lost_read_after_a_match_leaves_the_lane`, `test_the_reconcile_compares_true_odds_and_rows_only_the_cache_holds`, `test_reads_that_keep_failing_their_reconcile_stay_full` |
| Replay money rows of one selection and minute at two prices collapsed to one | Gemini | fixed | Keyed on the price where the source has one. `test_money_rows_of_one_minute_at_two_prices_stay_two_rows` |
| `params_raw` dropped for a match read for the first time; an empty request raised; `12` and `12.0` were different bookmakers | Gemini | fixed | `test_money_rows_of_one_minute_at_two_prices_stay_two_rows`, `test_a_bookmaker_code_read_as_a_float_is_the_same_bookmaker` |
| A capped repair of last weightings that break a constraint was refused on score, so the pool reset to 1 | Gemini | fixed | Any capped answer that keeps the constraints mends it. `test_a_last_tilt_past_the_band_is_mended_inside_the_cap_not_reset` |
| One pool whose board breaks a guard (stage 1) dropped every other pool's weightings | Gemini | fixed | Stage 2 is held to stage 1's own violation. `test_one_pools_broken_board_does_not_drop_the_other_pools_weightings` |
| The deadband could hold a stale tilt for good | Gemini | fixed | A move that unwinds the tilt passes it. `test_a_stale_tilt_unwinds_through_the_deadband` |
| The cap is measured after the overround refit, so a weighting can move more than the cap when stage 1 moves | GPT | kept | The cap bounds the tilt between a line's sides, which the refit keeps; the refit only meets the overround on the new prices, a constraint. Written in `_stage2`'s docstring |
| A serving refit's blend days counted as unseen: walk-forward scored days the model validated on | Gemini | fixed | `fit_end` takes `blend_days`. `test_a_serving_refit_saw_the_days_it_blended_on` |
| Yesterday is scored while provisional and never again | Gemini | fixed | score-days revisits it: marked suspect, or scored again by the same version; changed and suspect days are drawn but not counted. `test_score_days_revisits_the_days_it_scored_while_provisional`, `test_the_report_carries_the_walk_forward_days` |
| 96% of the money on a quarter of the pools passed the money guard and replaced a good file | GPT | fixed | The extract is judged before it is written. `test_a_suspect_re_extract_does_not_replace_a_file_that_is_not` |
| An unreadable Pool_Details file read as days with no pools (no check); one file without `conclude_date` switched the pool count off for every day | GPT, Gemini | fixed | Only the days a file covers lose the count, and they fall back to the extract's count or the money check. `test_an_unreadable_pool_file_is_not_a_day_without_pools`, `test_a_pool_file_without_conclude_date_leaves_only_its_own_days_uncounted` |
| A suspect day still fed the market index, references and the next day's lag history | Gemini | fixed | `test_a_suspect_day_feeds_no_market_index_and_no_lag_history` |
| Archive databases offline or restoring were listed | Gemini | fixed | `state = 0`. `test_bet_databases_are_found_in_sys_databases` |
| `--days` backwards, in the future or not dates ran an empty plan or crashed | Gemini | fixed | `test_days_must_run_forward_and_not_past_today` |
| `metrics()` copied deques other threads append to | Gemini | fixed | Copied under the engine lock; the read holds no lock over SQL |
| The same rows in another order gave the book another row order, and the solver (20 iterations a refresh) another answer: up to 0.15% on a price, E[GM] within 0.07%. The incremental cache reorders rows as it reads them again, so this would jitter the fast lane cycle to cycle | selftest S14, run past the overlap | fixed | `LivePanelBuilder` puts the live odds, market odds and money in time, then selection order. `test_the_same_rows_in_another_order_give_the_same_board`; S14 identical books and decisions over 12 cycles |
| The scan updates trigger fields without the lock | Gemini | kept | The scan and the fast lane now touch different matches; a race costs one duplicate trigger at worst |
| A pending revert is skipped while the match is implied | Gemini | kept | A revert sends all four values and an implied block has none of HKJC's; the message stays and the reason says so (section 5) |
| Days next to a day that changed keep features built from its old file | Gemini | open | As before W16: `build-features` over the window rebuilds them |
