"""Metrics shared by training, backtest and monitoring."""
