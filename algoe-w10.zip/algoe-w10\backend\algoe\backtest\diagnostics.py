"""
Backtest diagnostics - the questions a leaderboard does not answer

    drift(...)            do the test days' inputs look like training's (PSI per feature), and does the
                          champion's lead over last 5 minutes hold month by month as the market moves
    margin_effect(...)    what a pool's margin costs it in money: partially linear double machine
                          learning, cross-fitted by day, standard error clustered by match

Both read cached feature days and the trained models only; nothing is refitted except the nuisance
regressions of margin_effect. Events before / after and inside the bucket are in mixstudy.py.

Change Log:
-----------
2026-10-06      Initialize
2026-10-11      event_response moved to mixstudy.py (corners, the score after, events inside the bucket)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..data.panel import ref_phase
from ..evaluation.metrics import poisson_deviance

logger = get_logger(__name__)


def spread(days, n: int) -> tuple:
    """At most ``n`` of ``days``, evenly spread, in order."""
    days = list(days)
    if n <= 0 or len(days) <= n:
        return tuple(days)
    idx = sorted({int(round(i)) for i in np.linspace(0, len(days) - 1, n)})
    return tuple(days[i] for i in idx)


# ================================================================== drift
def drift(forecaster, store, monitor, test_days: Sequence, val_days: Sequence = (), sample: int = 30,
          val_sample: int = 120) -> dict:
    from ..models.turnover import RESPONSES
    ref = (forecaster.metadata or {}).get("feature_reference") or {}
    pick = spread(test_days, sample)
    features = []
    for response, spec in RESPONSES.items():
        if response not in ref:
            continue
        parts = []
        for d in pick:
            dd = store.get(d)
            if dd.empty:
                continue
            fs = getattr(forecaster.engineer, spec.builder)(dd)
            if len(fs):
                parts.append(fs.X)
        if not parts:
            continue
        X = pd.concat(parts, ignore_index=True)
        if len(X) > 200_000:
            X = X.sample(200_000, random_state=7)
        for r in monitor.drift(ref[response], X)["features"]:
            features.append({"response": response, **r})
    features.sort(key=lambda r: -r["psi"])
    months: Dict[str, dict] = {}
    for role, ds in (("validation", spread(val_days, val_sample)), ("test", list(test_days))):
        for d in ds:
            dd = store.get(d)
            if dd.empty:
                continue
            pred = forecaster.predict_selection_turnover(dd)
            y = pred["actual"].to_numpy(dtype="float64")
            key = "{:%Y-%m}".format(pd.Timestamp(d))
            e = months.setdefault(key, {"month": key, "role": role, "days": 0, "rows": 0, "money": 0.0,
                                        "_dm": 0.0, "_dl": 0.0, "_idx": []})
            e["days"] += 1
            e["rows"] += len(y)
            e["money"] += float(y.sum())
            e["_dm"] += poisson_deviance(y, pred["forecast"].to_numpy(dtype="float64")) * len(y)
            e["_dl"] += poisson_deviance(y, pred["last5"].to_numpy(dtype="float64")) * len(y)
            if "market_index" in dd.match.columns and len(dd.match):
                e["_idx"].append(float(dd.match["market_index"].iloc[0]))
    rows = []
    for e in sorted(months.values(), key=lambda r: r["month"]):
        rows.append({"month": e["month"], "role": e["role"], "days": e["days"],
                     "money_per_day": e["money"] / max(e["days"], 1),
                     "market_index": float(np.median(e["_idx"])) if e["_idx"] else None,
                     "deviance_vs_last5": e["_dm"] / e["_dl"] if e["_dl"] > 0 else None})
    return {"features": features[:30], "months": rows, "sample_days": len(pick)}


# ========================================================== margin effect
def _regressor(seed: int):
    try:
        import lightgbm as lgb
        return lgb.LGBMRegressor(n_estimators=200, learning_rate=0.1, num_leaves=31, min_child_samples=100,
                                 subsample=0.8, subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1)
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from sklearn.ensemble import HistGradientBoostingRegressor
        return HistGradientBoostingRegressor(max_iter=200, learning_rate=0.1, random_state=seed)
    except Exception:                                       # noqa: BLE001
        return None


def _residual(X: np.ndarray, v: np.ndarray, fold: np.ndarray, seed: int) -> np.ndarray:
    """v minus its cross-fitted prediction from X (each fold predicted by a model fitted on the others)."""
    out = np.full(len(v), np.nan)
    frame = pd.DataFrame(X, columns=["x{}".format(i) for i in range(X.shape[1])])   # same names in and out
    for k in np.unique(fold):
        test, train = fold == k, fold != k
        model = _regressor(seed)
        if model is None:                                   # no tree library: a ridge regression
            A = np.column_stack([np.ones(train.sum()), X[train]])
            beta = np.linalg.lstsq(A.T @ A + 1e-3 * np.eye(A.shape[1]), A.T @ v[train], rcond=None)[0]
            pred = np.column_stack([np.ones(test.sum()), X[test]]) @ beta
        else:
            model.fit(frame[train], v[train])
            pred = model.predict(frame[test])
        out[test] = v[test] - pred
    return out


def margin_effect(forecaster, store, days: Sequence, folds: int = 2, max_rows: int = 300_000, seed: int = 7,
                  min_rows: int = 2000, min_matches: int = 50) -> dict:
    """theta = d log(pool money) / d margin of its main line, by bet type and phase, two ways: given the
    pool's own recent money (the response to a margin change) and without it (across pools). Money is in
    market-index units. Only margin variation the other features do not predict identifies theta; its
    spread is reported, and with almost none the answer is 'cannot tell'. Observational: if HKJC moves a
    margin because of the money it expects, theta is biased - an experiment is the clean answer."""
    eng = forecaster.engineer
    parts = []
    for d in days:
        dd = store.get(d)
        if dd.empty or dd.pool is None or dd.pool.empty:
            continue
        fs = eng.features_for_turnover_pool_share(dd)
        if not len(fs) or "p_margin" not in fs.X.columns:
            continue
        if len(dd.pool) != len(fs):
            continue
        idx = float(dd.match["market_index"].iloc[0]) if "market_index" in dd.match.columns and len(dd.match) else 1.0
        # the margin as read, not the feature (which fills a pool without a priced main line)
        t = pd.to_numeric(dd.pool["p_margin"], errors="coerce").to_numpy(dtype="float64")
        X = fs.X.copy()
        X["_y"] = np.log1p(np.clip(fs.y, 0, None) / max(idx, 1e-12))
        X["_t"] = t
        X["_day"] = str(pd.Timestamp(d).date())
        X["_match"] = fs.keys["match_id"].to_numpy()
        X["_family"] = fs.cuts["family"].astype(str).to_numpy()
        X["_phase"] = ref_phase(fs.cuts["phase"].astype(str).to_numpy())
        parts.append(X[np.isfinite(t) & (t > -0.05) & (t < 0.5)])
    if not parts:
        return {"rows": []}
    data = pd.concat(parts, ignore_index=True)
    controls = [c for c in data.columns if not c.startswith("_") and c not in ("p_margin", "p_margin_rel")]
    memory = {c for c in controls if c.startswith(("p_share", "p_log", "p_any"))}
    specs = {"given its own recent money": controls,
             "across pools (no money memory)": [c for c in controls if c not in memory]}
    rows = []
    for (fam, ph), g in data.groupby(["_family", "_phase"]):
        if len(g) < min_rows or g["_match"].nunique() < min_matches:
            continue
        if len(g) > max_rows:
            g = g.sample(max_rows, random_state=seed)
        day_codes = {d: i % folds for i, d in enumerate(sorted(g["_day"].unique()))}
        fold = g["_day"].map(day_codes).to_numpy()
        for spec, cols in specs.items():
            Xc = g[cols].to_numpy(dtype="float64")
            y_res = _residual(Xc, g["_y"].to_numpy(dtype="float64"), fold, seed)
            t_res = _residual(Xc, g["_t"].to_numpy(dtype="float64"), fold, seed)
            ok = np.isfinite(y_res) & np.isfinite(t_res)
            y_res, t_res, clusters = y_res[ok], t_res[ok], g["_match"].to_numpy()[ok]
            den = float(np.sum(t_res ** 2))
            if den <= 0:
                continue
            theta = float(np.sum(t_res * y_res) / den)
            eps = y_res - theta * t_res
            score = pd.Series(t_res * eps).groupby(clusters).sum().to_numpy()
            se = float(np.sqrt(np.sum(score ** 2)) / den)
            sd = float(np.std(t_res))
            rows.append({"family": fam, "phase": ph, "spec": spec, "rows": int(ok.sum()),
                         "matches": int(len(np.unique(clusters))), "theta": theta, "se": se,
                         "ci_lo": theta - 1.96 * se, "ci_hi": theta + 1.96 * se,
                         "margin_residual_sd": sd, "margin_mean": float(g["_t"].mean()),
                         # money change for a margin one point lower (e.g. 106% -> 105%)
                         "money_per_point_lower": float(np.exp(-0.01 * theta) - 1.0),
                         "identified": bool(sd >= 0.002 and abs(theta) > 2 * se)})
    rows.sort(key=lambda r: (r["family"], r["phase"], r["spec"]))
    return {"rows": rows, "days": len(days)}
