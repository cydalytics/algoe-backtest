"""
Book Pricer

Turns an 8-dimensional theta plus the match state into an effective
probability for every selection, then into fair and sell odds.

    theta dims   goal_tg goal_sup goal_fh_tg goal_fh_sup
                 corner_tg corner_sup corner_fh_tg corner_fh_sup

WHAT THETA MEANS IN PLAY. HKJC's Goal90CurrentTG averages 1.7 against 3.0
for the Basis layer: in play it is the goals STILL TO COME, and it decays
to zero by full time. A full-match total line therefore settles on
(goals already scored + goals to come). Two conventions are supported per
market, because the extraction notebooks do not say which one HKJC uses for
in-play handicaps:

    full_match      line settles on the whole match: score shift applied
    rest_of_match   line settles on goals from now on: no shift

Pre-match the two are identical. The replication check in the backtest
measures both against the odds HKJC actually posted.

EFFECTIVE PROBABILITY. For a two-way Asian line the price is set by

    E[payout] = O (P_fw + P_hw / 2) + P_push + (P_hw + P_hl) / 2 = 1

so the effective probability of a side is (P_fw + P_hw/2) / num with
num = 1 - P_push - (P_hw + P_hl)/2. Both sides sum to one. This is the same
number poisson_betting.py prices (integer lines drop pushes, quarter lines
split into two half-stakes) written as one formula. ``num`` is also the
share of a stake that is actually at risk, which the optimiser uses to make
expected margin exact on lines that can push.

SPEED. Totals and handicaps only need the distribution of (home + away) and
(home - away), so the score grid is collapsed once per theta into two 1-D
marginals and every line of the book is then a vector operation. That is
what makes an SLSQP solve per match affordable inside a 15-second focus
refresh.

Change Log:
-----------
2026-09-30      Initialize (unifies poisson_betting, parquet pricing, desk grids)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from typing import Dict, Optional, Sequence, Tuple

import numpy as np

DIMS = ("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup",
        "corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup")
DOMAIN_DIMS = {
    "goal": ("goal_tg", "goal_sup"), "goal_fh": ("goal_fh_tg", "goal_fh_sup"),
    "corner": ("corner_tg", "corner_sup"), "corner_fh": ("corner_fh_tg", "corner_fh_sup"),
}
MAX_GOALS = 12
MAX_CORNERS = 28
EPS = 1e-12


@dataclass
class MatchState:
    """Where the match stands. Every field has a pre-match default."""
    home_goals: int = 0
    away_goals: int = 0
    home_corners: int = 0
    away_corners: int = 0
    minute: float = 0.0
    phase: str = "prematch"      # prematch | first_half | half_time | second_half | extra_time | finished
    ht_home_goals: Optional[int] = None
    ht_away_goals: Optional[int] = None
    ht_home_corners: Optional[int] = None
    ht_away_corners: Optional[int] = None

    @property
    def in_play(self) -> bool:
        return self.phase not in ("prematch", "finished")

    @property
    def ht_done(self) -> bool:
        return self.phase in ("half_time", "second_half", "extra_time", "finished")

    def score(self, domain: str) -> Tuple[int, int]:
        if domain.startswith("corner"):
            return int(self.home_corners), int(self.away_corners)
        return int(self.home_goals), int(self.away_goals)


@dataclass(frozen=True)
class Conventions:
    settle_total: str = "full_match"
    settle_handicap: str = "full_match"
    draw_factor: float = 1.0
    corner_dispersion: float = 1.0     # variance / mean; 1.0 = Poisson, 1.3 = project spec NB

    def settle(self, market: str) -> str:
        return self.settle_handicap if market in ("handicap", "handicap_3w") else self.settle_total


# ------------------------------------------------------------ distributions
_K = np.arange(64, dtype="float64")
_LOG_FACT = np.concatenate([[0.0], np.cumsum(np.log(np.arange(1, 64, dtype="float64")))])


def pmf(mean: float, n: int, dispersion: float = 1.0) -> np.ndarray:
    """P(X = k), k = 0..n. Poisson, or negative binomial when dispersion > 1."""
    mean = max(float(mean), 0.0)
    if mean <= EPS:
        out = np.zeros(n + 1)
        out[0] = 1.0
        return out
    if dispersion <= 1.0 + 1e-9:
        return np.exp(_K[:n + 1] * np.log(mean) - mean - _LOG_FACT[:n + 1])
    out = np.empty(n + 1)
    r = mean / (dispersion - 1.0)
    p = r / (r + mean)
    out[0] = p ** r
    for k in range(1, n + 1):
        out[k] = out[k - 1] * (k - 1 + r) / k * (1.0 - p)
    return out


def score_grid(total: float, sup: float, n: int, draw_factor: float = 1.0,
               dispersion: float = 1.0) -> np.ndarray:
    """Joint (home, away) distribution. Supremacy is clamped to +-total, not the rates.

    Clamping the two rates separately would turn an incoherent supremacy into
    a certainty that one side never scores; clamping supremacy keeps the total
    and degrades to one-sided-but-possible.
    """
    total = max(float(total), 0.0)
    sup = min(max(float(sup), -total), total)
    home, away = (total + sup) / 2.0, (total - sup) / 2.0
    grid = np.outer(pmf(home, n, dispersion), pmf(away, n, dispersion))
    if draw_factor and abs(draw_factor - 1.0) > 1e-9 and draw_factor > 0:
        idx = np.diag_indices_from(grid)
        grid[idx] *= draw_factor
    s = grid.sum()
    return grid / s if s > 0 else grid


@lru_cache(maxsize=16)
def _index(n: int):
    i, j = np.indices((n + 1, n + 1))
    return (i + j).ravel(), (i - j + n).ravel()


@dataclass
class Marginals:
    """1-D distributions of (home + away) and (home - away) for one grid."""
    total_values: np.ndarray
    total_probs: np.ndarray
    diff_values: np.ndarray
    diff_probs: np.ndarray
    grid: np.ndarray

    def shifted(self, dh: int, da: int) -> "Marginals":
        return Marginals(self.total_values + (dh + da), self.total_probs,
                         self.diff_values + (dh - da), self.diff_probs, self.grid)


def marginals(grid: np.ndarray) -> Marginals:
    n = grid.shape[0] - 1
    tot_idx, diff_idx = _index(n)
    w = grid.ravel()
    tp = np.bincount(tot_idx, weights=w, minlength=2 * n + 1)
    dp = np.bincount(diff_idx, weights=w, minlength=2 * n + 1)
    return Marginals(np.arange(2 * n + 1, dtype="float64"), tp,
                     np.arange(-n, n + 1, dtype="float64"), dp, grid)


# ------------------------------------------------------------- line maths
def _compare(values: np.ndarray, line: np.ndarray) -> np.ndarray:
    """+1 / 0 / -1 per (line, value): value above, on, below the line."""
    d = values[None, :] - line[:, None]
    return np.where(d > 1e-9, 1.0, np.where(d < -1e-9, -1.0, 0.0))


def settle_matrix(values: np.ndarray, lines: np.ndarray) -> np.ndarray:
    """Result of the over/home side for each (line, value), in {-1,-.5,0,.5,1}."""
    lines = np.asarray(lines, dtype="float64")
    quarter = np.abs(np.mod(np.abs(lines) * 4.0, 2.0) - 1.0) < 1e-9
    lo = np.where(quarter, lines - 0.25, lines)
    hi = np.where(quarter, lines + 0.25, lines)
    return 0.5 * (_compare(values, lo) + _compare(values, hi))


def two_way(values: np.ndarray, probs: np.ndarray, lines) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Effective probabilities (side 1, side 2) and the at-risk share per line.

    Side 1 wins when the metric is above the line (over / home covers).
    """
    r = settle_matrix(values, np.atleast_1d(lines))
    fw = (r > 0.75) @ probs
    hw = ((r > 0.25) & (r < 0.75)) @ probs
    push = (np.abs(r) < 0.25) @ probs
    hl = ((r < -0.25) & (r > -0.75)) @ probs
    fl = (r < -0.75) @ probs
    num = 1.0 - push - 0.5 * (hw + hl)
    ok = num > EPS
    p1 = np.where(ok, (fw + 0.5 * hw) / np.where(ok, num, 1.0), 0.5)
    p2 = np.where(ok, (fl + 0.5 * hl) / np.where(ok, num, 1.0), 0.5)
    return p1, p2, np.clip(num, 0.0, 1.0)


# ------------------------------------------------------------------ theta
def theta_from_params(tg, sup, ctg=None, csup=None, split_fh: float = 0.45,
                      split_fh_corner: float = 0.47, state: Optional[MatchState] = None) -> Dict[str, float]:
    """HKJC's parameters for a bucket as the 8-dim theta.

    First-half values follow the notebooks (full value x SecondHalfSplitFH)
    before kick-off. In play the Current layer is what is left of the match,
    so the first half's share of it is the share of the remaining clock that
    is still first half.
    """
    def num(v, default):
        try:
            v = float(v)
        except (TypeError, ValueError):
            return default
        return v if np.isfinite(v) else default

    tg, sup = num(tg, 2.6), num(sup, 0.0)
    ctg, csup = num(ctg, 9.6), num(csup, 0.0)
    sfh = num(split_fh, 0.45)
    sfh = sfh if 0.05 < sfh < 0.95 else 0.45
    sfc = num(split_fh_corner, 0.47)
    sfc = sfc if 0.05 < sfc < 0.95 else 0.47
    if state is not None and state.in_play:
        m = float(state.minute or 0.0)
        frac = 0.0 if state.ht_done else float(np.clip((45.0 - m) / max(90.0 - m, 1.0), 0.0, 1.0))
        g_fh = c_fh = frac
    else:
        g_fh, c_fh = sfh, sfc
    return {"goal_tg": tg, "goal_sup": sup, "goal_fh_tg": tg * g_fh, "goal_fh_sup": sup * g_fh,
            "corner_tg": ctg, "corner_sup": csup, "corner_fh_tg": ctg * c_fh,
            "corner_fh_sup": csup * c_fh}


def repair_theta(theta: Dict[str, float]) -> Dict[str, float]:
    """Make a theta priceable: TG >= |SUP|, FH <= FT, second half coherent."""
    out = {d: float(theta.get(d, 0.0)) for d in DIMS}
    for tg, sup, ftg, fsup in (("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup"),
                               ("corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup")):
        out[tg] = max(out[tg], 0.0)
        out[sup] = float(np.clip(out[sup], -out[tg], out[tg]))
        out[ftg] = float(np.clip(out[ftg], 0.0, out[tg]))
        out[fsup] = float(np.clip(out[fsup], -out[ftg], out[ftg]))
        rest = out[tg] - out[ftg]
        out[fsup] = float(np.clip(out[fsup], out[sup] - rest, out[sup] + rest))
    return out


# ------------------------------------------------------------------- book
@dataclass
class BookRows:
    """The priceable selections of one match, as aligned arrays."""
    theta_domain: np.ndarray       # goal | goal_fh | corner | corner_fh
    market: np.ndarray             # total | handicap | three_way | ...
    line: np.ndarray               # float (NaN when the market has no line)
    side: np.ndarray               # H | A | D (three-way) | score keys for exact markets
    n: int = field(init=False)

    def __post_init__(self):
        self.theta_domain = np.asarray(self.theta_domain, dtype=object)
        self.market = np.asarray(self.market, dtype=object)
        self.line = np.asarray(self.line, dtype="float64")
        self.side = np.asarray(self.side, dtype=object)
        self.n = len(self.line)
        self._groups = None

    def groups(self):
        """(domain, market, is_first_half) -> row positions, computed once."""
        if self._groups is None:
            g: Dict[tuple, list] = {}
            for i in range(self.n):
                g.setdefault((self.theta_domain[i], self.market[i]), []).append(i)
            self._groups = {k: np.asarray(v) for k, v in g.items()}
        return self._groups


class BookPricer:
    """Prices a BookRows at any theta. Stateless apart from the conventions."""

    def __init__(self, conventions: Optional[Conventions] = None):
        self.conv = conventions or Conventions()

    def _dist(self, domain: str, theta: Dict[str, float], state: MatchState, cache: dict) -> Marginals:
        m = cache.get(domain)
        if m is None:
            tg_dim, sup_dim = DOMAIN_DIMS[domain]
            corner = domain.startswith("corner")
            grid = score_grid(theta.get(tg_dim, 0.0), theta.get(sup_dim, 0.0),
                              MAX_CORNERS if corner else MAX_GOALS,
                              1.0 if corner else self.conv.draw_factor,
                              self.conv.corner_dispersion if corner else 1.0)
            m = marginals(grid)
            cache[domain] = m
        return m

    def probabilities(self, book: BookRows, theta: Dict[str, float],
                      state: Optional[MatchState] = None) -> Tuple[np.ndarray, np.ndarray]:
        """(effective probability, at-risk share) per row. NaN where unpriceable."""
        state = state or MatchState()
        p = np.full(book.n, np.nan)
        risk = np.ones(book.n)
        cache: Dict[str, Marginals] = {}
        for (domain, market), idx in book.groups().items():
            if domain not in DOMAIN_DIMS:
                continue
            dist = self._dist(domain, theta, state, cache)
            dh = da = 0
            if state.in_play and self.conv.settle(market) == "full_match":
                if domain.endswith("_fh") and state.ht_done:
                    continue                      # first-half market already settled
                dh, da = state.score(domain)
                dist = dist.shifted(dh, da)
            sides = book.side[idx]
            if market == "total":
                p1, p2, num = two_way(dist.total_values, dist.total_probs, book.line[idx])
                p[idx] = np.where(sides == "H", p1, p2)
                risk[idx] = num
            elif market in ("home_total", "away_total"):
                # one team's count: the grid's marginal, plus what that team has already scored
                home = market == "home_total"
                q = dist.grid.sum(axis=1) if home else dist.grid.sum(axis=0)
                v = np.arange(len(q), dtype="float64") + (dh if home else da)
                p1, p2, num = two_way(v, q, book.line[idx])
                p[idx] = np.where(sides == "H", p1, p2)
                risk[idx] = num
            elif market == "handicap":
                # home covers when (home - away) + handicap > 0, i.e. diff > -handicap
                p1, p2, num = two_way(dist.diff_values, dist.diff_probs, -book.line[idx])
                p[idx] = np.where(sides == "H", p1, p2)
                risk[idx] = num
            elif market in ("three_way", "handicap_3w"):
                lines = np.nan_to_num(book.line[idx], nan=0.0) if market == "handicap_3w" \
                    else np.zeros(len(idx))
                v, q = dist.diff_values, dist.diff_probs
                for k, i in enumerate(idx):
                    adj = v + lines[k]
                    h, d, a = q[adj > 1e-9].sum(), q[np.abs(adj) <= 1e-9].sum(), q[adj < -1e-9].sum()
                    p[i] = {"H": h, "D": d, "A": a}.get(str(sides[k]), np.nan)
            elif market == "odd_even":
                odd = float(dist.total_probs[(dist.total_values.astype(int) % 2) == 1].sum())
                p[idx] = np.where(sides == "O", odd, np.where(sides == "E", 1.0 - odd, np.nan))
            elif market == "exact_total":
                for k, i in enumerate(idx):
                    key = str(sides[k])
                    try:
                        if key.endswith("+"):
                            p[i] = float(dist.total_probs[dist.total_values >= int(key[:-1])].sum())
                        else:
                            p[i] = float(dist.total_probs[dist.total_values == int(key)].sum())
                    except ValueError:
                        p[i] = np.nan
            elif market == "correct_score":
                grid = dist.grid
                dh, da = (state.score(domain) if state.in_play and
                          self.conv.settle(market) == "full_match" else (0, 0))
                for k, i in enumerate(idx):
                    key = str(sides[k])
                    if ":" not in key:
                        continue
                    try:
                        h, a = (int(x) for x in key.split(":", 1))
                    except ValueError:
                        continue
                    h, a = h - dh, a - da
                    p[i] = float(grid[h, a]) if 0 <= h < grid.shape[0] and 0 <= a < grid.shape[1] else 0.0
        return p, risk

    @staticmethod
    def fair_odds(p: np.ndarray, cap: float = 999.0) -> np.ndarray:
        p = np.asarray(p, dtype="float64")
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.where(p > EPS, np.minimum(1.0 / p, cap), np.nan)

    @staticmethod
    def sell_odds(p: np.ndarray, margin: np.ndarray, weighting: Optional[np.ndarray] = None,
                  lo: float = 1.001, hi: float = 999.0) -> np.ndarray:
        """Fair odds cut by the pool margin, unrounded (the solver needs it smooth)."""
        p = np.asarray(p, dtype="float64")
        w = 1.0 if weighting is None else np.asarray(weighting, dtype="float64")
        with np.errstate(divide="ignore", invalid="ignore"):
            o = np.where(p > EPS, 1.0 / p / (1.0 + np.asarray(margin, dtype="float64")) * w, np.nan)
        return np.clip(o, lo, hi)


def ladder(odds: float) -> float:
    """Round down to the price ladder the feed quotes on (publish time only)."""
    if not np.isfinite(odds) or odds <= 0:
        return 0.0
    step = 0.01 if odds < 4 else 0.05 if odds < 10 else 0.5 if odds < 30 else 1.0 if odds < 100 else 5.0
    return max(1.01, round(float(np.floor(odds / step + 1e-9) * step), 2))


def state_from_row(game_state, minute, home_goals=0, away_goals=0, home_corners=0,
                   away_corners=0, mins_to_ko=None) -> MatchState:
    """MatchState from HKJC_Parameters GameState + the clock + the running score."""
    gs = "" if game_state is None else str(game_state).strip().lower()
    try:
        m = float(minute) if minute is not None and np.isfinite(float(minute)) else 0.0
    except (TypeError, ValueError):
        m = 0.0
    if "second" in gs:
        phase = "second_half"
    elif "xtra" in gs or "extra" in gs or "penalty" in gs:
        phase = "extra_time"
    elif "first" in gs:
        phase = "half_time" if m >= 45.0 and _at_break(m) else "first_half"
    elif gs in ("prematch", "", "none", "nan", "<na>"):
        phase = "first_half" if (mins_to_ko is not None and np.isfinite(mins_to_ko) and mins_to_ko < 0) \
            else "prematch"
    else:
        phase = "prematch"

    def i(v):
        try:
            v = int(v)
            return v if v >= 0 else 0
        except (TypeError, ValueError):
            return 0
    return MatchState(home_goals=i(home_goals), away_goals=i(away_goals),
                      home_corners=i(home_corners), away_corners=i(away_corners),
                      minute=m, phase=phase)


def _at_break(minute: float) -> bool:
    # HKJC holds the clock at 45:00 through the interval with GameState still
    # FirstHalf; a clock at exactly 45 is the break, stoppage time runs past it.
    return abs(minute - 45.0) < 1e-6
