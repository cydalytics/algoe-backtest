# Algo E W10 - office box runbook

Turnover forecasting, probability calibration, the TG/SUP optimizer and the live engine, on
the offline machine. Everything runs on CPU with no internet. The parquet, the caches and the
trained models stay beside `Raw_Data`; this folder is code only, so unzipping a newer version
over it never touches them.

```
S:\Users\Yeung\20260520 Algo E\
    Raw_Data\               the extraction output (read only)
    algoe_panel_cache\      per-day panel, shared with the W06 workbench
    Backtest_Data\          the workbench's series (train-turnover --series writes here)
    AlgoE_Work\
        features\<key>\     per-day features, one folder per feature version
        models\turnover\    every trained version + CHAMPION.json + history.jsonl
        models\probability\
        reports\            backtest_<stamp>\report.html
        monitor\            health.json, alerts.jsonl, published forecasts
        runs\               one folder per command: settings.json + summary.json
        logs\               <command>-<stamp>.log (text) and .jsonl (structured)
        config\pools.json   confirmations for pool codes placed by rule
        config\holidays.txt HK holidays after 2027, one ISO date per line
```

## 0. What the machine needs

The Python the extraction notebooks use, with `pandas numpy scipy pyarrow` (and `pyodbc` for
the SQL feed). Optional, each adds pipelines to the leaderboard:

    pip install --no-index --find-links vendor -r backend\requirements-models.txt

`lightgbm` (or `scikit-learn` as the fallback) enables the GBM pipelines, which were the
champion on the synthetic world. Without them GBM is skipped and the GLM / GAM pipelines
compete; nothing fails. `torch` enables the NN challenger.

## 1. First time

| Step | Run | You want |
|------|-----|----------|
| 1 | `algoe-0-selftest.bat` | `11 PASS, 0 WARN, 0 FAIL` (a WARN on probability is fine). About two minutes the first time. |
| 2 | `algoe-1-check-data.bat` (drag `Raw_Data` onto it) | No FAIL. Read the pool-code table: codes marked `known False` were placed by rule - confirm them in `config\pools.json` (section 5). |
| 3 | `algoe-2-train.bat --start 2024-06-01 --end 2026-09-14 --workers 3 --set window.val_start=2025-07-01 --set window.test_start=2026-07-01` | Panel, features, turnover, probability, then the backtest report, split by date (section 2a). Start from the "data complete from" month and end on the day check-data's `window end` line gives. The first panel build is the slow part (section 2a); later runs only build new days. |
| 4 | open the newest `AlgoE_Work\reports\backtest_*\report.html` | Turnover champion below last-5-minutes deviance on the test days, days better > days worse; calibrated belief at or below raw log-loss; optimizer lift >= 0 with days better > worse. |
| 5 | `algoe-parity.bat --at "2026-09-10 21:30" --at "2026-09-11 00:05"` | `Identical`. Any difference means the live engine would feed the model inputs it was not trained on - do not go live until it is fixed. |
| 6 | `algoe-4-live.bat --source replay --at "2026-09-10 20:00" --speed 10` | A rehearsal of a real evening from Raw_Data: the board every bucket, focus refreshes, triggers. |
| 7 | `algoe-4-live.bat` | The SQL feed. Ctrl+C stops it. |

Every step also runs as `python -m algoe <command>` from `backend\` (or
`python scripts\sNN_<command>.py`); `python -m algoe <command> -h` lists its options.

## 2a. Choosing the window and the split

`check-data` prints **coverage by month** over every file, and the month the data is complete
from (odds, investments, pools, matches and parameters in every month after it). HKJC parameters
(TG / SUP) begin 2024-05-07, so months before that have odds but cannot be priced or used for
theta features: train from the complete month on.

Split by date, never by counts, for a long window:

    --set window.val_start=2025-07-01 --set window.test_start=2026-07-01

means train [start, 2025-07-01), validation [2025-07-01, 2026-07-01), test [2026-07-01, end].
A whole year of validation covers every season and tournament once, so the model choice does not
ride on one month; the price is that the test is scored by a model whose training ended a year
earlier. Accept the result on that honest score, then deploy the refit
(`train-turnover --serving-refit`, or the nightly), which adds the validation year to the fit.

What keeps it free of look-ahead:

- train < validation < test by calendar day; no day is in two roles; nothing is shuffled.
- every input at bucket T comes from before T (start-of-bucket prices, previous-bucket money,
  events and parameters strictly before T); `parity` rebuilds a bucket the way live serves it,
  from data cut at T, and proves the inputs are identical.
- everything fitted from data - league and pool encodings, the models, GBM early stopping - is
  fitted on train days; validation only chooses the champion and its blend; test is scored once.
- outcomes, dividends and settlement are labels, never inputs.
- `backtest` refuses a bundle refitted for serving (its fit includes the test days).

Cost on the office box: the panel and features are built once and kept, and a stopped build resumes
where it stopped. The trial week (2026-07-01..07) took about 90 seconds a day in one process, so
2024-06..2026-09 is about 20 hours. `--workers N` builds N months at once (panel and features);
each worker holds one month of raw odds and money in memory, so pick N by RAM, not cores: note
the peak memory of python.exe in Task Manager during a one-worker build, then
N = (free RAM - 4 GB) / that peak. If memory runs short, stop it (Ctrl+C) and rerun with fewer
workers - finished months are kept. Training samples at most
`turnover.max_fit_rows` / `probability.max_fit_rows` rows per response (2 million by default).

**Pools.** `panel.pools` defaults to `["@line_markets", "@three_way"]`: every goal / corner total
and handicap, the team totals (HILOH / HILOA full-time goals, FHLOH / FHLOA first-half goals,
CHLOH / CHLOA and FCHLOH / FCHLOA corners - one team's count over / under a line), plus 1X2,
chosen by what each code is, so a new line market joins by itself. Correct score, scorer and
next-goal markets are left out - they are several times the rows and nothing here prices them.
`[]` takes every pool. Adding the team totals changed what the rule selects, so the panel cache
built before 2026-10-01 (the trial week) is in an older cache space and is rebuilt once.

**True odds.** If check-data warns that HKJC_Odds has no `true_odds` (the historical extraction
reads `pool_odds_change_c`, which does not join true odds), the models learn their beliefs from
the market, Poisson-from-theta and de-margined odds, and the live engine then ignores the live
feed's true odds so its inputs match. Re-extracting history with true odds (as the real-time
notebook joins `pool_odds_true_change_h`) gives the models HKJC's own belief to learn from.

## 2. What the numbers mean

- **Turnover leaderboard** (`runs\<stamp>_train-turnover\leaderboard.csv`): one row per
  pipeline. `test_deviance` is the Poisson deviance on the held-out days - the number the
  champion is judged on; `test_match_wape` is the error on match totals, the level the
  optimizer's demand is anchored to; `dm_stat_vs_last5` below about -2 means the model is
  reliably better than last 5 minutes, day by day.
- **Probability leaderboard**: `test_log_loss` and `test_ece` (calibration error) for every
  source x method; `raw:hkjc_true` is 1 / HKJC true odds, the W06 assumption.
- **Optimizer** (report section): E[GM] at theta* minus E[GM] at HKJC's theta, under the
  forecast demand and the calibrated belief, on the test days. `binding` says which guard
  stopped it going further (trust band, max step, probability band, market cap).
  A match expecting less than `optimizer.min_match_turnover` (HK$500) over the horizon is not
  solved: HKJC's theta stands. A flood on one selection makes it lean against that side - shorten
  it, lengthen the other - but never past the guards: each theta within `theta_band` of HKJC's
  (focus refreshes also within `max_step` of the last answer), each price within `prob_band`
  (5 points of implied probability) of the board, and never below the board's E[GM]. In the unit
  test 100x and 10,000x the money on Over 2.5 both stop at TG +0.17, Over 1.93 -> 1.78, bound by
  the probability band. Inside a bucket, one big ticket raises the expected rest-of-bucket money
  at most `live.nowcast_max_hot` (4x) and the next bucket at most 2x.

## 3. Every day

Register the nightly task once (elevated prompt, adjust the folder):

    schtasks /Create /TN "AlgoE nightly" /SC DAILY /ST 06:30 /TR "\"D:\AlgoE\algoe-w10\algoe-nightly.bat\""

It builds the new days, checks health on the last 7, retrains both models on the 75 days
ending yesterday (chosen and scored honestly, then refitted on the newest days for serving),
and promotes only what beats last 5 minutes and the current champion. Exit code 0 ok,
1 a step failed, 2 finished with alerts.

After it runs, read `AlgoE_Work\monitor\health.json` or run `algoe-5-monitor.bat`:

| Alert | Meaning | Do |
|-------|---------|----|
| `accuracy` | rolling WAPE or deviance worse than last 5 minutes | check the leaderboard of the last nightly run; if the champion is the problem, roll back (section 6) |
| `bias` | forecasts consistently above / below what arrived | often a new season or a feed change; the nightly refit usually absorbs it within days |
| `drift` | a price or money feature's distribution moved (PSI > 0.25) | check `check-data` for a feed change; calendar / clock / event features are not checked, they move by design |
| `novelty` league | a league the encoder has never seen | nothing to do: it is forecast at the global level and learns from its own money within the day; the next refit includes it |
| `novelty` pool | a pool code placed by rule | confirm it in `config\pools.json` (section 5) |

## 4. The desk

`/api/live` serves the live engine beside the W06 desk. Start the API with the engine running:

    set ALGOE_LIVE=1
    set ALGOE_SOURCE=sql
    python -m uvicorn src.api.main:app --port 8001

`GET /api/live/board` (every match), `GET /api/live/match/{id}` (one match; each call keeps it
in focus for 3 minutes), `POST /api/live/focus/{id}`, `GET /api/live/status` (models in use,
last sweep timings).

## 5. New things in the feed

- **New league**: nothing to configure.
- **New pool code**: the taxonomy places it by its spelling (an FH / FC / ET prefix is the
  segment, CH / CN after it means corners, a body ending in LO is a total, LOH / LOA a home /
  away team total, DC a handicap, HAD a three-way, CRS a correct score...) and logs a warning; the
  engine forecasts and, if it is a line market, prices it. Confirm or correct it in
  `AlgoE_Work\config\pools.json`:

      {"pools": {"NHILO": {"segment": "FT", "domain": "goal", "market": "total", "has_line": true}},
       "aliases": {"HIL": "HILO"}}

- **Holidays after 2027**: one ISO date per line in `AlgoE_Work\config\holidays.txt`.

## 6. Models

    python -m algoe models                    every version; * marks the champion
    python -m algoe models history            every promotion and its reason
    python -m algoe models promote --kind turnover --version <version> --reason "roll back"

A bundle is refused if its file does not match its checksum, or if it was trained on another
feature version than the code builds - retrain rather than serve it.

Backtest the honest fit, not the serving refit (the refit has seen the test days; `backtest`
refuses it): `python -m algoe train-turnover --no-promote` then `python -m algoe backtest`.

## 7. Settings

Every knob is in `backend\algoe\settings.py`, grouped by the layer that reads it. Override
one on any command with `--set section.key=value`, or keep a JSON file and pass
`--settings path` (or set `ALGOE_SETTINGS`):

    {"window": {"val_days": 7, "test_days": 14},
     "optimizer": {"prob_band": 0.03, "budget_seconds": 150},
     "live": {"focus_interval_seconds": 10, "max_focus_matches": 8}}

Compute knobs, if the box is slow: `panel.workers` (`--workers`, months built in parallel),
`optimizer.budget_seconds` (sweep wall clock), `optimizer.workers`, `live.max_focus_matches`,
`live.focus_interval_seconds`, `turnover.fit_rows_per_day`, and `panel.pools` - the default is
the line markets plus 1X2; the W06 list `["HILO","HDC","CHLO","CHDC"]` is smaller and reuses the
cache `3-run.bat` built. `optimizer.pools` (default `["@theta_lines"]`: every full-time and
first-half goal / corner line market, team totals included) is what the optimizer moves theta
for; extra-time pools are forecast but not optimised. `live.nowcast_max_hot` caps how far one
big ticket moves the in-bucket forecast.

## 8. When something fails

Every command logs to `AlgoE_Work\logs\<command>-<stamp>.log`, with a box per step
(`STEP F1 fit encoders ...`) and a `[PASS]` / `[FAIL]` line with its timing; the `.jsonl`
beside it has the same lines with their data. `runs\<stamp>_<command>\summary.json` has the
exit code and the error.

- `no turnover champion yet` - run `algoe-2-train.bat` first.
- `trained on feature version N but the code builds version M` - the code changed how a
  feature is built; retrain (`algoe-2-train.bat`).
- `window has K day(s) with data; train/val/test needs at least ...` - widen `--start/--end`
  or lower `window.val_days` / `window.test_days`.
- The live board is empty - `check-data` for the day, or the source (`--source sql` needs the
  ODBC connection the desk uses; `python scripts\preflight.py --source sql`).
