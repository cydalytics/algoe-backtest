"""
Step 14 - the far pre-match curve

How much money a match takes per 5 minutes days before kick-off, against the hour before the turnover
models' 6-hour window: fitted on the last Match_Investments days, scored on the last week of kick-offs
against last 5 minutes, saved to AlgoE_Work/models/turnover/FAR_PREMATCH.json only when it beats it.
The live desk forecasts every match on sale outside the window with it.

    python scripts/s14_fit_far_prematch.py [--days 42] [--holdout-days 7] [--force]

Exit code 2 when it does not beat last 5 minutes (nothing saved). Same as: python -m algoe fit-far-prematch
"""
from _algoe import run

if __name__ == "__main__":
    run("fit-far-prematch")
