"""
Kafka Messages

The two messages between Algo E and HKJC's pricing engine (E-HV11-01), in the
shape the samples show (docs/specs/kafka-publish.spec.md section 4):

    params  out, one per match   EventId, MsgId, Timestamp (Hong Kong, no zone),
                                 TgsupParameters {GoalTg, GoalSup, CornerTg, CornerSup,
                                 DrawFactor}, PoolWeightings [{PoolType, LineValue,
                                 Selections [{SelectionId, Weight}]}], GameState
    prices  in, one per match    ServerAppID, EventId, MapResult {GameState, GameClock,
                                 EventTime (UTC), Pools [{PoolId, PoolType, Lines
                                 [{LineId, LineValues, Combinations [{CombinationID,
                                 CombinationLabel, TrueOdds, CalcCurrentPrice, Weight}],
                                 Margin}]}]}

The two sides do not name things alike: PoolType and GameState are numbers
going out and text coming back, and a selection is a SelectionId going out and
a CombinationID coming back. Those numbers, the draw factor's scale and what
TG means in play are kept in a mapping file, never in the code
(kafka_mapping.json beside this file; AlgoE_Work/config/kafka_mapping.json
overrides it). Every entry says whether the engine's owner has confirmed it,
and shadow and live send confirmed entries only.

The checks are written out rather than left to a schema library; an error
names the path of the field that failed.

Change Log:
-----------
2026-10-29      Initialize
"""

import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

SHIPPED = Path(__file__).resolve().with_name("kafka_mapping.json")
OFFICE = Path("config") / "kafka_mapping.json"
FULL_MATCH, REMAINING = "full_match", "remaining"
ROWS = ("pool_id", "pool_type", "instance_no", "line_id", "line_label", "line_value", "combination_id", "label",
        "true_odds", "sell_odds", "weight", "margin", "offered")


class MessageError(ValueError):
    """A message that cannot be built or read; the text names the field."""


class MappingError(ValueError):
    """A value the mapping cannot name, or an entry production may not use yet."""


# ================================================================ mapping
@dataclass
class Mapping:
    pool_types: Dict[str, dict]
    selections: Dict[str, Dict[str, int]]
    game_states: Dict[str, dict]
    draw_factor: dict
    tg_in_play: dict
    rounding: Dict[str, int]
    msg_id_format: str = "{prefix}_{seq}"
    timestamp_format: str = "%Y-%m-%dT%H:%M:%S"
    no_price_at_or_below: float = 1.001
    reply_utc_offset_hours: float = 8.0
    version: str = ""
    source: str = ""

    def pool_code(self, pool: str) -> Optional[int]:
        entry = self.pool_types.get(str(pool).upper())
        return None if entry is None or entry.get("code") is None else int(entry["code"])

    def selection_id(self, pool: str, label) -> Optional[int]:
        table = self.selections.get(str(pool).upper()) or {}
        sid = table.get(str(label).strip())
        return None if sid is None else int(sid)

    def game_state(self, text) -> Tuple[str, dict]:
        """(the mapping's name, its entry) for the feed's GameState text, matched case-blind."""
        key = "" if text is None else str(text).strip()
        if key in self.game_states:
            return key, self.game_states[key]
        for name, entry in self.game_states.items():
            if name.lower() == key.lower():
                return name, entry
        raise MappingError("GameState {!r} has no engine code in {}".format(text, self.source or "the mapping"))

    def msg_id(self, prefix: str, seq: int) -> str:
        return self.msg_id_format.format(prefix=prefix, seq=int(seq))

    def summary(self) -> dict:
        """What the status page shows: the source and which entries are still unconfirmed."""
        loose = ["pool_types.{}".format(k) for k, v in self.pool_types.items() if not v.get("confirmed")]
        loose += ["game_states.{}".format(k) for k, v in self.game_states.items() if not v.get("confirmed")]
        loose += [k for k in ("draw_factor", "tg_in_play") if not getattr(self, k).get("confirmed")]
        return {"source": self.source, "version": self.version, "unconfirmed": loose,
                "pool_types": {k: v.get("code") for k, v in self.pool_types.items()},
                "tg_in_play": self.tg_in_play.get("semantics"), "draw_factor_offset": self.draw_factor.get("offset")}


def load_mapping(path=None, work_dir=None) -> Mapping:
    """``path``, else <work_dir>/config/kafka_mapping.json when it exists, else the shipped file."""
    if path is None and work_dir is not None and (Path(work_dir) / OFFICE).exists():
        path = Path(work_dir) / OFFICE
    p = Path(path) if path is not None else SHIPPED
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise MappingError("cannot read the Kafka mapping {}: {}".format(p, exc))
    m = Mapping(pool_types={str(k).upper(): dict(v) for k, v in (raw.get("pool_types") or {}).items()},
                selections={str(k).upper(): {str(a): b for a, b in (v or {}).items()}
                            for k, v in (raw.get("selections") or {}).items()},
                game_states={str(k): dict(v) for k, v in (raw.get("game_states") or {}).items()},
                draw_factor=dict(raw.get("draw_factor") or {"offset": 0.0}),
                tg_in_play=dict(raw.get("tg_in_play") or {"semantics": REMAINING}),
                rounding={"theta": 2, "draw_factor": 2, "weight": 2, **(raw.get("rounding") or {})},
                msg_id_format=str(raw.get("msg_id_format", "{prefix}_{seq}")),
                timestamp_format=str(raw.get("timestamp_format", "%Y-%m-%dT%H:%M:%S")),
                no_price_at_or_below=float(raw.get("no_price_at_or_below", 1.001)),
                reply_utc_offset_hours=float(raw.get("reply_utc_offset_hours", 8.0)),
                version=str(raw.get("version", "")), source=str(p))
    _check_mapping(m)
    return m


def _check_mapping(m: Mapping) -> None:
    where = m.source or "the mapping"

    def codes(table: Dict[str, dict], what: str) -> None:
        seen: Dict[int, str] = {}
        for name, entry in table.items():
            code = entry.get("code")
            if code is None:
                continue
            if isinstance(code, bool) or not isinstance(code, int):
                raise MappingError("{} {}: code must be a whole number, got {!r} ({})".format(what, name, code, where))
            if code in seen:
                raise MappingError("{} {} and {} share code {} ({})".format(what, seen[code], name, code, where))
            seen[code] = name
    codes(m.pool_types, "pool_types")
    codes(m.game_states, "game_states")
    for pool, table in m.selections.items():
        ids = list(table.values())
        if any(isinstance(i, bool) or not isinstance(i, int) for i in ids) or len(set(ids)) != len(ids):
            raise MappingError("selections {}: SelectionIds must be distinct whole numbers ({})".format(pool, where))
    if m.tg_in_play.get("semantics") not in (REMAINING, FULL_MATCH):
        raise MappingError("tg_in_play.semantics must be {} or {} ({})".format(REMAINING, FULL_MATCH, where))
    if not _finite(m.draw_factor.get("offset")):
        raise MappingError("draw_factor.offset must be a number ({})".format(where))
    for key, value in m.rounding.items():
        if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 6:
            raise MappingError("rounding.{} must be 0..6 decimals ({})".format(key, where))


# ============================================================ conversions
def _finite(v) -> bool:
    try:
        return v is not None and not isinstance(v, bool) and math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def _round(v: float, decimals: int) -> float:
    return round(float(v), int(decimals)) + 0.0          # + 0.0: no "-0.0" on the wire


def _share(minute: float, mapping: Mapping) -> float:
    t = mapping.tg_in_play
    total = float(t.get("match_minutes", 90))
    return max((total - float(minute or 0.0)) / total, float(t.get("min_remaining_share", 1.0 / total)))


def engine_theta(theta: Dict[str, float], minute: float, in_play: bool, mapping: Mapping) -> Dict[str, float]:
    """Our full-match TG / SUP as the engine reads them (unrounded)."""
    scale = 1.0 / _share(minute, mapping) if in_play and mapping.tg_in_play.get("semantics") == FULL_MATCH else 1.0
    return {"GoalTg": float(theta["goal_tg"]) * scale, "GoalSup": float(theta["goal_sup"]) * scale,
            "CornerTg": float(theta["corner_tg"]) * scale, "CornerSup": float(theta["corner_sup"]) * scale}


def theta_from_engine(params: Dict[str, float], minute: float, in_play: bool, mapping: Mapping) -> Dict[str, float]:
    """The inverse of engine_theta: the engine's TgsupParameters in our terms."""
    scale = _share(minute, mapping) if in_play and mapping.tg_in_play.get("semantics") == FULL_MATCH else 1.0
    return {"goal_tg": float(params["GoalTg"]) * scale, "goal_sup": float(params["GoalSup"]) * scale,
            "corner_tg": float(params["CornerTg"]) * scale, "corner_sup": float(params["CornerSup"]) * scale}


def engine_draw_factor(value, mapping: Mapping) -> float:
    """The feed's Goal90DrawFactor (a multiplier on the draw cells) on the engine's scale, rounded."""
    if not _finite(value):
        raise MessageError("DrawFactor: the feed has no Goal90DrawFactor for the match ({!r})".format(value))
    return _round(float(value) + float(mapping.draw_factor.get("offset", 0.0)), mapping.rounding["draw_factor"])


def draw_factor_from_engine(value, mapping: Mapping) -> float:
    return float(value) - float(mapping.draw_factor.get("offset", 0.0))


# ================================================================ publish
def build_params_message(event_id, msg_id: str, ts, theta: Dict[str, float], draw_factor, weights_rows: Iterable,
                         game_state, mapping: Mapping, minute: float = 0.0, in_play: bool = False,
                         require_confirmed: bool = False) -> Tuple[dict, List[str]]:
    """The params message for one match, and notes on what was left out.

    ``theta`` is ours (goal_tg, goal_sup, corner_tg, corner_sup); ``draw_factor`` the feed's
    Goal90DrawFactor; ``weights_rows`` (pool, line value, label, weight) per selection, a line value
    of NaN for pools without lines; ``game_state`` the feed's GameState text. A selection the mapping
    cannot name is left out and noted; a GameState it cannot name refuses the message.
    """
    notes: List[str] = []
    loose: List[str] = []
    r = mapping.rounding
    for dim in ("goal_tg", "goal_sup", "corner_tg", "corner_sup"):
        if dim not in theta or not _finite(theta[dim]):
            raise MessageError("TgsupParameters: {} is {!r}".format(dim, theta.get(dim)))
    sent = engine_theta(theta, minute, in_play, mapping)
    if any(not math.isfinite(v) for v in sent.values()):
        raise MessageError("TgsupParameters: not finite after the in-play conversion: {}".format(sent))
    params = {k: _round(v, r["theta"]) for k, v in sent.items()}
    params["DrawFactor"] = engine_draw_factor(draw_factor, mapping)
    name, state = mapping.game_state(game_state)
    if state.get("code") is None:
        raise MappingError("GameState {!r} has no engine code in {}".format(game_state, mapping.source))
    if not state.get("confirmed"):
        loose.append("game_states.{}".format(name))
    if not mapping.draw_factor.get("confirmed"):
        loose.append("draw_factor")
    if in_play and not mapping.tg_in_play.get("confirmed"):
        loose.append("tg_in_play")

    lines: Dict[tuple, Dict[int, float]] = {}
    order: List[tuple] = []
    for row in weights_rows or []:
        pool, line, label, weight = (row["pool"], row["line_value"], row["label"], row["weight"]) \
            if isinstance(row, dict) else row
        if not _finite(weight) or float(weight) <= 0:
            raise MessageError("PoolWeightings: {} {} {} has weight {!r}".format(pool, line, label, weight))
        code = mapping.pool_code(pool)
        if code is None:
            note = "pool {} has no PoolType in the mapping: its weights are not sent".format(pool)
            if note not in notes:
                notes.append(note)
            continue
        sid = mapping.selection_id(pool, label)
        if sid is None:
            notes.append("pool {} line {}: selection {!r} has no SelectionId in the mapping".format(pool, line, label))
            continue
        lv = _round(line, 2) if _finite(line) else 0.0
        key = (code, lv)
        if key not in lines:
            lines[key] = {}
            order.append(key)
            if not mapping.pool_types[str(pool).upper()].get("confirmed"):
                tag = "pool_types.{}".format(str(pool).upper())
                if tag not in loose:
                    loose.append(tag)
        if sid in lines[key]:
            raise MessageError("PoolWeightings: {} line {} selection {!r} given twice".format(pool, line, label))
        lines[key][sid] = _round(weight, r["weight"])
    if require_confirmed and loose:
        raise MappingError("not confirmed by the engine's owner, so not for production: {} ({})".format(
            ", ".join(loose), mapping.source))
    first = {k: i for i, k in enumerate(order)}
    order.sort(key=lambda k: (k[0], first[k]))
    ts = pd.Timestamp(ts)
    message = {"EventId": int(event_id), "MsgId": str(msg_id), "Timestamp": ts.strftime(mapping.timestamp_format),
               "TgsupParameters": params,
               "PoolWeightings": [{"PoolType": code, "LineValue": lv,
                                   "Selections": [{"SelectionId": sid, "Weight": w}
                                                  for sid, w in sorted(lines[(code, lv)].items())]}
                                  for code, lv in order],
               "GameState": int(state["code"])}
    return message, notes


def encode(message: dict) -> str:
    """The wire text: compact JSON, keys in the order built."""
    return json.dumps(message, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


# ================================================================== reply
@dataclass
class PricesReply:
    server_app_id: str
    event_id: int
    game_state: str
    stage: Optional[str]
    calculation_id: Optional[int]
    clock_seconds: Optional[float]
    clock_set: bool
    event_time: Optional[pd.Timestamp]
    short_desc: Optional[str]
    rows: List[dict] = field(default_factory=list)

    def frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.rows, columns=list(ROWS))


def _need(obj, key: str, path: str, kind: str, required: bool = True):
    if not isinstance(obj, dict):
        raise MessageError("{}: expected an object".format(path or "message"))
    where = "{}.{}".format(path, key) if path else key
    if key not in obj:
        if required:
            raise MessageError("{}: missing".format(where))
        return None
    v = obj[key]
    if kind == "int":
        if isinstance(v, bool) or not isinstance(v, int):
            raise MessageError("{}: expected a whole number, got {!r}".format(where, v))
    elif kind == "num":
        if v is None:
            return float("nan")
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            raise MessageError("{}: expected a number, got {!r}".format(where, v))
        v = float(v)
    elif kind == "str":
        if v is not None and not isinstance(v, str):
            raise MessageError("{}: expected text, got {!r}".format(where, v))
    elif kind == "list":
        if not isinstance(v, list):
            raise MessageError("{}: expected a list".format(where))
    elif kind == "obj":
        if not isinstance(v, dict):
            raise MessageError("{}: expected an object".format(where))
    elif kind == "bool":
        if not isinstance(v, bool):
            raise MessageError("{}: expected true or false, got {!r}".format(where, v))
    return v


def _event_time(text, offset_hours: float) -> Optional[pd.Timestamp]:
    """The reply's EventTime (UTC, ``...Z``) as Hong Kong local time, which is what the desk keeps."""
    if not text:
        return None
    try:
        t = pd.Timestamp(text)
    except (ValueError, TypeError):
        raise MessageError("MapResult.EventTime: not a time: {!r}".format(text))
    if t.tzinfo is not None:
        t = t.tz_convert("UTC").tz_localize(None) + pd.Timedelta(hours=offset_hours)
    return t


def parse_prices_message(raw, mapping: Mapping) -> PricesReply:
    """The engine's reply as a header and one row per selection."""
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError as exc:
            raise MessageError("the reply is not JSON: {}".format(exc))
    event_id = _need(raw, "EventId", "", "int")
    res = _need(raw, "MapResult", "", "obj")
    inner = _need(res, "EventID", "MapResult", "int", required=False)
    if inner is not None and inner != event_id:
        raise MessageError("MapResult.EventID {} is not EventId {}".format(inner, event_id))
    clock = _need(res, "GameClock", "MapResult", "obj", required=False) or {}
    secs = _need(clock, "TimeInSecond", "MapResult.GameClock", "num", required=False) if clock else None
    out = PricesReply(
        server_app_id=_need(raw, "ServerAppID", "", "str") or "",
        event_id=int(event_id),
        game_state=_need(res, "GameState", "MapResult", "str") or "",
        stage=_need(res, "GameStageReference", "MapResult", "str", required=False),
        calculation_id=_need(res, "CalculationID", "MapResult", "int", required=False),
        clock_seconds=secs,
        clock_set=bool(_need(clock, "IsClockSet", "MapResult.GameClock", "bool", required=False)) if clock else False,
        event_time=_event_time(_need(res, "EventTime", "MapResult", "str", required=False),
                               mapping.reply_utc_offset_hours),
        short_desc=_need(res, "PoolLinesShortDesc", "MapResult", "str", required=False))
    floor = mapping.no_price_at_or_below
    for i, pool in enumerate(_need(res, "Pools", "MapResult", "list")):
        pp = "MapResult.Pools[{}]".format(i)
        pid = _need(pool, "PoolId", pp, "int")
        ptype = _need(pool, "PoolType", pp, "str") or ""
        inst = _need(pool, "InstanceNo", pp, "int", required=False)
        for j, line in enumerate(_need(pool, "Lines", pp, "list")):
            lp = "{}.Lines[{}]".format(pp, j)
            lid = _need(line, "LineId", lp, "int")
            label = _need(line, "LineLabel", lp, "str", required=False)
            value = _need(line, "LineValues", lp, "num", required=False)
            margin = _need(line, "Margin", lp, "num", required=False)
            for k, comb in enumerate(_need(line, "Combinations", lp, "list")):
                cp = "{}.Combinations[{}]".format(lp, k)
                sell = _need(comb, "CalcCurrentPrice", cp, "num")
                weight = _need(comb, "Weight", cp, "num", required=False)
                out.rows.append({
                    "pool_id": pid, "pool_type": ptype.upper(), "instance_no": inst, "line_id": lid,
                    "line_label": label, "line_value": float("nan") if value is None else value,
                    "combination_id": _need(comb, "CombinationID", cp, "int"),
                    "label": (_need(comb, "CombinationLabel", cp, "str") or "").strip(),
                    "true_odds": _need(comb, "TrueOdds", cp, "num"), "sell_odds": sell,
                    "weight": float("nan") if weight is None else weight,
                    "margin": float("nan") if margin is None else margin,
                    "offered": bool(math.isfinite(sell) and sell > floor + 1e-9)})
    return out


def mapping_path_for(work_dir) -> str:
    """Which file load_mapping(work_dir=...) reads: for the status page and kafka-check."""
    office = Path(work_dir) / OFFICE if work_dir else None
    return str(office) if office is not None and office.exists() else str(SHIPPED)
