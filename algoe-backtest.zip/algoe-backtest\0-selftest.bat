@echo off
REM Verify the code on synthetic data in a temp folder. Ignores out\facts.
setlocal
cd /d "%~dp0"
echo Selftest uses synthetic data in a temp folder. Copied out\facts is ignored.
python -m backtest.run selftest
pause
