"""
Implied theta

HKJC posts odds for a match before it writes a TG/SUP row for it (algo_param starts later). Without a theta
the optimiser has nothing to move, so the live desk fits one to the board: the TG and SUP (goals; TC and
CSUP for corners) at which our pricer's probabilities come closest, in squares, to the board's de-margined
probabilities, line by line. First halves follow the full match by the default split.

It is the board's theta in our pricer's terms, not HKJC's internal one: a match priced on it is optimised
on the desk and never published.

Change Log:
-----------
2026-11-19      Initialize
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from .pricer import BookPricer, BookRows, Conventions, MatchState, theta_from_params

FIT_MARKETS = ("total", "handicap", "three_way")
BOUNDS = {"goal": ((0.2, 7.0), (-4.0, 4.0)), "corner": ((3.0, 20.0), (-8.0, 8.0))}
GRID = {"goal": ((1.4, 2.0, 2.6, 3.2, 3.8), (-1.5, -0.75, 0.0, 0.75, 1.5)),
        "corner": ((6.0, 8.0, 9.5, 11.0, 13.0), (-3.0, -1.5, 0.0, 1.5, 3.0))}
# a fit further than this (root mean square, in probability) from the board is not the board's theta
MAX_RMSE = 0.05


def demargined(rows: BookRows, odds: np.ndarray) -> np.ndarray:
    """Each row's implied probability over its line's book, so a line's sides add up to 1. A line with a
    single priced side gives NaN."""
    o = np.asarray(odds, dtype="float64")
    imp = np.where(np.isfinite(o) & (o > 1.0), 1.0 / np.where(o > 1.0, o, 2.0), np.nan)
    line = np.where(np.isfinite(rows.line), np.round(rows.line * 4.0) / 4.0, -999.0)
    key = np.char.add(np.char.add(np.char.add(rows.theta_domain.astype(str), "|"), rows.market.astype(str)),
                      np.char.add("|", line.astype(str)))
    out = np.full(len(o), np.nan)
    for k in np.unique(key):
        i = np.flatnonzero((key == k) & np.isfinite(imp))
        if len(i) >= 2:
            out[i] = imp[i] / imp[i].sum()
    return out


def implied_theta(rows: BookRows, odds: np.ndarray, block: str = "goal", state: Optional[MatchState] = None,
                  conventions: Optional[Conventions] = None) -> Optional[Tuple[float, float, float]]:
    """(TG, SUP, rmse) of ``block`` ("goal" / "corner") fitted to the board; None when the block has no
    full-match line with both sides priced, or the fit stays further than MAX_RMSE from the board."""
    if block not in BOUNDS:
        raise ValueError("block must be goal or corner, got {!r}".format(block))
    state = state or MatchState()
    q_all = demargined(rows, odds)
    m = (rows.theta_domain.astype(str) == block) & np.isin(rows.market.astype(str), FIT_MARKETS) & np.isfinite(q_all)
    if m.sum() < 2:
        return None
    sub = BookRows(rows.theta_domain[m], rows.market[m], rows.line[m], rows.side[m])
    q = q_all[m]
    pricer = BookPricer(conventions or Conventions())

    def theta(x):
        if block == "goal":
            return theta_from_params(x[0], x[1], None, None, state=state)
        return theta_from_params(None, None, x[0], x[1], state=state)

    def loss(x) -> float:
        p, _ = pricer.probabilities(sub, theta(x), state)
        d = np.where(np.isfinite(p), p - q, 1.0)
        return float(np.mean(d ** 2))

    (tlo, thi), (slo, shi) = BOUNDS[block]
    best = min(((loss((t, s)), (t, s)) for t in GRID[block][0] for s in GRID[block][1] if abs(s) <= t),
               key=lambda r: r[0])
    x = np.array(best[1], dtype="float64")
    try:
        from scipy.optimize import minimize
        res = minimize(loss, x, method="L-BFGS-B", bounds=[(tlo, thi), (slo, shi)],
                       options={"maxiter": 200, "ftol": 1e-12})
        if np.all(np.isfinite(res.x)) and res.fun <= best[0]:
            x = np.asarray(res.x, dtype="float64")
    except Exception:                                                   # noqa: BLE001
        pass
    rmse = float(np.sqrt(loss(x)))
    if not np.isfinite(rmse) or rmse > MAX_RMSE:
        return None
    return float(x[0]), float(np.clip(x[1], -x[0], x[0])), rmse
