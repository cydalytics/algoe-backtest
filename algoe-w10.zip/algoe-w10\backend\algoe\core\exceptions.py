"""
Exceptions

One class per layer so a caller can catch exactly the failure it can
handle. Every class inherits from AlgoEError.

Change Log:
-----------
2026-09-30      Initialize
"""


class AlgoEError(Exception):
    """Base class for every Algo E error."""


class ConfigError(AlgoEError):
    """A setting is missing, unknown or out of range."""


class DataError(AlgoEError):
    """Input data is missing, unreadable or fails its contract."""


class FeatureError(AlgoEError):
    """A feature set could not be built."""


class EstimatorUnavailable(AlgoEError):
    """An optional backend (LightGBM, torch, ...) is not installed."""


class ModelError(AlgoEError):
    """A model could not be trained, loaded or scored."""


class OptimizerError(AlgoEError):
    """A theta search could not produce a feasible answer."""


class RegistryError(AlgoEError):
    """A model artifact is missing or does not match its metadata."""
