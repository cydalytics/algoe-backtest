"""
Step 06 - backtest every lever on the held-out days

compare_turnover (every pipeline vs last 5, with cuts and Diebold-Mariano),
compare_feature_groups (each hypothesis group dropped and refitted),
compare_trueprob (every belief), compare_gm (expected vs realised margin),
check_replication (which in-play settlement convention reproduces HKJC's
board) and compare_optimizer (theta* vs HKJC's theta under forecast demand and
calibrated belief). Writes AlgoE_Work/reports/backtest_<stamp>/report.html.

    python scripts/s06_backtest.py                       the champions' own test days
    python scripts/s06_backtest.py --optimizer-every 3   optimise every 3rd bucket (slower)

Same as: python -m algoe backtest
"""
from _algoe import run

if __name__ == "__main__":
    run("backtest")
