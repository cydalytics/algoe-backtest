"""Turnover model trained from Raw_Data, written straight into Backtest_Data.

Features follow ``2 Features Extract Part 1.ipynb``: for each selection at the
start of a 5-minute bucket T, what was known at T, and the label is the
turnover in (T, T+5min]. The notebook loops one timestamp at a time; this
reads the same Raw_Data folders a month at a time and builds a day in one pass.

    day        weekday, weekend, HK holiday, hour, evening, live matches,
               board turnover last 5 / 15 min and so far today
    match      in-play, minute, minutes to kick-off, TG/SUP (goals, corners),
               goals / corners in the last 5 / 15 min, minutes since goal /
               corner / card, match turnover last 5 min and so far today
    selection  odds now / 5 / 10 min ago / at open, their changes, implied
               prob, true odds, turnover in each of the last six 5-min buckets,
               mean, std, EMA fast / slow, line minus TG or SUP, shares of the
               line / pool / match / board, lines in the pool, pool, domain

No GPU. The model is scikit-learn's HistGradientBoostingRegressor with a
Poisson loss when scikit-learn is installed, and a numpy log ridge when it is
not. Both run on CPU.

Walk-forward: day N is predicted by a fit on days before N. The first
``--warmup-days`` days write last-5-minute turnover, so they compare as a tie.
The model is blended toward last 5 min by a weight picked on the most recent
days it was not fitted on; weight 0 means it did not beat last 5 min.

Files, next to Raw_Data:

    Backtest_Data/Features/YYYY-MM-DD.parquet          features, reused on the next run
    Backtest_Data/Turnover/<name>/YYYY-MM-DD.parquet   "value", in the backtest's row order
    Backtest_Data/Turnover/<name>/_keyed/...           same forecast keyed by selection
    Backtest_Data/Turnover/<name>/_report.json         WAPE per day against last 5 min

The backtest's row order is ``Backtest_Data/index``, which Open cached writes.
If a day has no index yet, only the keyed file is written; ``align`` fills in
the rest later without retraining. Rows the model did not see keep last 5 min.

    python -m src.backtest.parquet.raw_turnover train --data-dir "S:\\Users\\Yeung\\20260520 Algo E\\Raw_Data"
    python -m src.backtest.parquet.raw_turnover align --data-dir "S:\\Users\\Yeung\\20260520 Algo E\\Raw_Data"
    python -m src.backtest.parquet.raw_turnover selftest
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import date
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from .cache import day_list
from .config import Config
from .loader import load_static
from .panel import GOAL_IN, CORNER_IN, MonthCache, _parse_line, build_day, start_odds

KEY = ["match_id", "pool_name", "line_id", "combination_id"]
STEP = pd.Timedelta(minutes=5)
ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)
EPS = 1e-8

POOLS = ("HILO", "HDC", "CHLO", "CHDC", "HAD", "FHAD", "FHILO", "FHLO", "FHDC", "SGA")

HK_HOLIDAYS = set()
for _yr, _days in [
    (2024, [(1, 1), (2, 10), (2, 11), (2, 12), (2, 13), (3, 29), (3, 30), (4, 1), (4, 4), (5, 1),
            (5, 15), (6, 10), (7, 1), (9, 18), (10, 1), (10, 11), (12, 25), (12, 26)]),
    (2025, [(1, 1), (1, 29), (1, 30), (1, 31), (4, 4), (4, 18), (4, 19), (4, 21), (5, 1), (5, 5),
            (5, 31), (6, 2), (7, 1), (10, 1), (10, 7), (10, 29), (12, 25), (12, 26)]),
    (2026, [(1, 1), (2, 17), (2, 18), (2, 19), (4, 3), (4, 4), (4, 6), (5, 1), (5, 19), (6, 19),
            (7, 1), (9, 25), (10, 1), (10, 7), (12, 25), (12, 26)]),
    (2027, [(1, 1), (2, 6), (2, 8), (2, 9), (3, 26), (3, 27), (3, 29), (4, 5), (5, 1), (5, 13),
            (6, 9), (7, 1), (9, 16), (10, 1), (10, 8), (12, 25), (12, 27)]),
]:
    for _m, _d in _days:
        HK_HOLIDAYS.add(date(_yr, _m, _d))

FEATURES = (
    # day
    "dow_sin", "dow_cos", "weekend", "holiday", "hour_sin", "hour_cos", "evening",
    "n_live_matches", "log_board_5", "log_board_15", "log_board_today", "log_board_per_match",
    # match
    "inplay", "match_minute", "mins_to_ko", "tg", "sup", "ctg", "csup",
    "goals_5", "goals_15", "corners_5", "corners_15",
    "since_goal", "since_corner", "since_yellow", "log_match_5", "log_match_today",
    # selection
    "odds", "odds_5", "odds_10", "odds_d5", "odds_d10", "odds_std", "odds_vs_open", "odds_vs_open_rel",
    "imp", "imp_d5", "true_imp",
    "log_tv1", "log_tv2", "log_tv3", "log_tv4", "log_tv5", "log_tv6",
    "log_tv_mean", "log_tv_std", "tv_d1", "log_ema_fast", "log_ema_slow", "ema_gap",
    "any_tv1", "any_tv6",
    "line_vs_theta", "near_main", "share_line", "share_pool", "share_match", "share_board",
    "n_lines", "corner", "handicap",
) + tuple("pool_" + p for p in POOLS)


def wape(y, yhat) -> float:
    y = np.asarray(y, dtype="float64")
    d = float(np.abs(y).sum())
    return float(np.abs(y - np.asarray(yhat, dtype="float64")).sum()) / d if d > 0 else float("nan")


def _int_keys(df: pd.DataFrame) -> pd.DataFrame:
    for c in ("match_id", "line_id", "combination_id", "pool_id"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(-1).astype("int64")
    if "pool_name" in df.columns:
        df["pool_name"] = df["pool_name"].astype("string").fillna("").str.upper()
    return df


def _num(f: pd.DataFrame, col: str, default: float = np.nan) -> np.ndarray:
    if col not in f.columns:
        return np.full(len(f), default, dtype="float64")
    return pd.to_numeric(f[col], errors="coerce").to_numpy(dtype="float64")


# --------------------------------------------------------------- features
def _lagged_money(f: pd.DataFrame, agg: pd.DataFrame) -> pd.DataFrame:
    """Turnover in each of the six buckets before T, per selection."""
    money = agg[["pool_id", "line_id", "combination_id", "bucket", "turnover"]].copy()
    money = _int_keys(money)
    money["bucket"] = pd.to_datetime(money["bucket"]).astype("datetime64[ns]")
    for k in range(1, 7):
        lag = money.rename(columns={"turnover": "tv{}".format(k)})
        lag = lag.assign(bucket=lag["bucket"] + k * STEP)
        f = f.merge(lag, on=["pool_id", "line_id", "combination_id", "bucket"], how="left")
        f["tv{}".format(k)] = f["tv{}".format(k)].fillna(0.0)
    return f


def _odds_back(f: pd.DataFrame, odds_bucket: pd.DataFrame) -> pd.DataFrame:
    """Posted odds 5 and 10 minutes before T, and the first odds seen."""
    ob = odds_bucket[["pool_id", "line_id", "combination_id", "bucket", "odds"]].dropna().copy()
    ob = _int_keys(ob)
    ob["bucket"] = pd.to_datetime(ob["bucket"]).astype("datetime64[ns]")
    ob = ob.sort_values("bucket")
    by = ["pool_id", "line_id", "combination_id"]
    first = ob.groupby(by, observed=True)["odds"].first().rename("odds_open").reset_index()
    f = f.merge(first, on=by, how="left")
    # bucket T-1's last price is the price at the start of T, so "5 minutes
    # before that" is the end of T-2
    for k, col in ((2, "odds_5"), (3, "odds_10")):
        left = f[by + ["bucket"]].copy()
        left["_row"] = np.arange(len(f))
        left["_at"] = left["bucket"] - k * STEP
        left = left.sort_values("_at")
        right = ob.rename(columns={"odds": col, "bucket": "_at"})
        m = pd.merge_asof(left, right, on="_at", by=by, direction="backward")
        vals = np.full(len(f), np.nan)
        vals[m["_row"].to_numpy()] = m[col].to_numpy(dtype="float64")
        f[col] = vals
    return f


def _event_counts(f: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    """Goals and corners in the last 5 and 15 minutes, per match-bucket."""
    for name in ("goals_5", "goals_15", "corners_5", "corners_15"):
        f[name] = 0.0
    if events is None or events.empty or "incident_type" not in events.columns:
        return f
    ev = events.dropna(subset=["match_id", "incident_datetime", "incident_type"]).copy()
    if "provider_id" in ev.columns and (ev["provider_id"] == 1).any():
        ev = ev[ev["provider_id"] == 1]
    ev["match_id"] = pd.to_numeric(ev["match_id"], errors="coerce").fillna(-1).astype("int64")
    ev["incident_type"] = pd.to_numeric(ev["incident_type"], errors="coerce")
    ev["incident_datetime"] = pd.to_datetime(ev["incident_datetime"])
    mb = f[["match_id", "bucket"]].drop_duplicates()
    out = []
    for code, stem in ((GOAL_IN, "goals"), (CORNER_IN, "corners")):
        times = {m: np.sort(g["incident_datetime"].to_numpy(dtype="datetime64[ns]"))
                 for m, g in ev[ev["incident_type"] == code].groupby("match_id")}
        c5 = np.zeros(len(mb))
        c15 = np.zeros(len(mb))
        for i, (m, b) in enumerate(zip(mb["match_id"].to_numpy(), mb["bucket"].to_numpy())):
            t = times.get(m)
            if t is None or not len(t):
                continue
            hi = np.searchsorted(t, b, side="right")
            c5[i] = hi - np.searchsorted(t, b - np.timedelta64(5, "m"), side="right")
            c15[i] = hi - np.searchsorted(t, b - np.timedelta64(15, "m"), side="right")
        out.append((stem, c5, c15))
    mb = mb.copy()
    for stem, c5, c15 in out:
        mb[stem + "_5"] = c5
        mb[stem + "_15"] = c15
    f = f.drop(columns=["goals_5", "goals_15", "corners_5", "corners_15"])
    return f.merge(mb, on=["match_id", "bucket"], how="left").fillna(
        {"goals_5": 0.0, "goals_15": 0.0, "corners_5": 0.0, "corners_15": 0.0})


def _line_vs_theta(f: pd.DataFrame) -> np.ndarray:
    labels = f["line_label"].astype("string") if "line_label" in f.columns else pd.Series("", index=f.index)
    parsed = {lab: _parse_line(lab) for lab in labels.dropna().unique()}
    line = labels.map(parsed).astype("float64").to_numpy()
    name = f["pool_name"].astype(str).str.upper()
    corner = name.str.startswith(("C", "FC", "ETC")).to_numpy()
    handicap = (name.str.contains("HDC") | name.str.endswith("DC")).to_numpy()
    tg = np.where(corner, _num(f, "ctg"), _num(f, "tg"))
    sup = np.where(corner, _num(f, "csup"), _num(f, "sup"))
    gap = line - np.where(handicap, sup, tg)
    return np.where(np.isfinite(gap), np.clip(gap, -8, 8), 0.0), corner, handicap


def build_features(cfg: Config, day: pd.Timestamp, mc: MonthCache,
                   pools_df: pd.DataFrame, matches_df: pd.DataFrame) -> pd.DataFrame:
    """One day of Raw_Data -> one row per selection-bucket with FEATURES, y and last5."""
    base = build_day(cfg, day, mc, pools_df, matches_df, prices=False)
    if base is None or base.empty:
        return pd.DataFrame()
    base = start_odds(cfg, base)
    f = _int_keys(base.copy())
    f["bucket"] = pd.to_datetime(f["bucket"]).astype("datetime64[ns]")
    f = f.drop_duplicates(KEY + ["bucket"]).reset_index(drop=True)
    f = _lagged_money(f, mc.agg)
    f = _odds_back(f, mc.odds_bucket)
    f = _event_counts(f, mc.events)

    y = np.clip(_num(f, "turnover", 0.0), 0, None)
    tv = np.column_stack([f["tv{}".format(k)].to_numpy(dtype="float64") for k in range(1, 7)])
    tv = np.clip(tv, 0, None)
    tv1 = tv[:, 0]

    # day
    b = f["bucket"]
    dow = b.dt.dayofweek.to_numpy()
    hour = b.dt.hour.to_numpy()
    out = pd.DataFrame(index=f.index)
    out["dow_sin"] = np.sin(2 * np.pi * dow / 7)
    out["dow_cos"] = np.cos(2 * np.pi * dow / 7)
    out["weekend"] = (dow >= 5).astype(float)
    out["holiday"] = b.dt.date.map(lambda d: 1.0 if d in HK_HOLIDAYS else 0.0).to_numpy()
    out["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    out["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    out["evening"] = ((hour >= 18) & (hour <= 23)).astype(float)
    f["_tv1"] = tv1
    f["_tv15"] = tv[:, :3].sum(axis=1)
    n_live = f.groupby("bucket", observed=True)["match_id"].transform("nunique").to_numpy(dtype="float64")
    board5 = f.groupby("bucket", observed=True)["_tv1"].transform("sum").to_numpy(dtype="float64")
    board15 = f.groupby("bucket", observed=True)["_tv15"].transform("sum").to_numpy(dtype="float64")
    per_bucket = f.groupby("bucket", observed=True)["_tv1"].sum().sort_index().cumsum()
    board_today = b.map(per_bucket).to_numpy(dtype="float64")
    out["n_live_matches"] = n_live
    out["log_board_5"] = np.log1p(board5)
    out["log_board_15"] = np.log1p(board15)
    out["log_board_today"] = np.log1p(board_today)
    out["log_board_per_match"] = np.log1p(board5 / np.maximum(n_live, 1.0))

    # match
    out["inplay"] = f["is_inplay"].fillna(False).astype(float).to_numpy() if "is_inplay" in f.columns \
        else np.zeros(len(f))
    out["match_minute"] = np.clip(np.nan_to_num(_num(f, "match_minute"), nan=0.0), 0, 130) / 90.0
    out["mins_to_ko"] = np.clip(np.nan_to_num(_num(f, "mins_to_ko"), nan=0.0), -150, 720) / 360.0
    for c in ("tg", "sup", "ctg", "csup"):
        out[c] = np.nan_to_num(_num(f, c), nan=0.0)
    for c in ("goals_5", "goals_15", "corners_5", "corners_15"):
        out[c] = f[c].to_numpy(dtype="float64")
    for src, dst in (("minutes_since_goal", "since_goal"), ("minutes_since_corner", "since_corner"),
                     ("minutes_since_yellow", "since_yellow")):
        v = _num(f, src)
        out[dst] = np.where(np.isfinite(v), np.clip(v, 0, 120), 120.0) / 120.0
    mkey = ["match_id", "bucket"]
    match5 = f.groupby(mkey, observed=True)["_tv1"].transform("sum").to_numpy(dtype="float64")
    per_match = f.groupby(mkey, observed=True)["_tv1"].sum()
    match_cum = per_match.groupby(level=0).cumsum()
    match_today = pd.MultiIndex.from_frame(f[mkey]).map(match_cum).to_numpy(dtype="float64")
    out["log_match_5"] = np.log1p(match5)
    out["log_match_today"] = np.log1p(np.nan_to_num(match_today, nan=0.0))

    # selection
    od = _num(f, "odds")
    od = np.where(np.isfinite(od) & (od > 1), od, 2.0)
    od5 = _num(f, "odds_5")
    od5 = np.where(np.isfinite(od5) & (od5 > 1), od5, od)
    od10 = _num(f, "odds_10")
    od10 = np.where(np.isfinite(od10) & (od10 > 1), od10, od5)
    od0 = _num(f, "odds_open")
    od0 = np.where(np.isfinite(od0) & (od0 > 1), od0, od)
    out["odds"] = np.log(od)
    out["odds_5"] = np.log(od5)
    out["odds_10"] = np.log(od10)
    out["odds_d5"] = od - od5
    out["odds_d10"] = od - od10
    out["odds_std"] = np.std(np.column_stack([od, od5, od10]), axis=1)
    out["odds_vs_open"] = od - od0
    out["odds_vs_open_rel"] = (od - od0) / np.maximum(od0, EPS)
    out["imp"] = 1.0 / od
    out["imp_d5"] = 1.0 / od - 1.0 / od5
    true = _num(f, "true_odds")
    out["true_imp"] = np.where(np.isfinite(true) & (true > 1), 1.0 / true, 1.0 / od)
    ltv = np.log1p(tv)
    for k in range(6):
        out["log_tv{}".format(k + 1)] = ltv[:, k]
    out["log_tv_mean"] = np.log1p(tv.mean(axis=1))
    out["log_tv_std"] = np.log1p(tv.std(axis=1))
    out["tv_d1"] = ltv[:, 0] - ltv[:, 1]
    ema_f = tv[:, 0].copy()
    ema_s = tv[:, 0].copy()
    for k in range(1, 6):
        ema_f = 0.5 * tv[:, k] + 0.5 * ema_f
        ema_s = 0.2 * tv[:, k] + 0.8 * ema_s
    out["log_ema_fast"] = np.log1p(ema_f)
    out["log_ema_slow"] = np.log1p(ema_s)
    out["ema_gap"] = out["log_ema_fast"] - out["log_ema_slow"]
    out["any_tv1"] = (tv1 > 0).astype(float)
    out["any_tv6"] = (tv.sum(axis=1) > 0).astype(float)
    lv, corner, handicap = _line_vs_theta(f)
    out["line_vs_theta"] = lv
    out["near_main"] = (np.abs(lv) < 0.5).astype(float)
    lkey = ["match_id", "pool_name", "line_id", "bucket"]
    pkey = ["match_id", "pool_name", "bucket"]
    line_sum = f.groupby(lkey, observed=True)["_tv1"].transform("sum").to_numpy(dtype="float64")
    pool_sum = f.groupby(pkey, observed=True)["_tv1"].transform("sum").to_numpy(dtype="float64")
    out["share_line"] = np.where(line_sum > 0, tv1 / np.maximum(line_sum, EPS), 0.0)
    out["share_pool"] = np.where(pool_sum > 0, tv1 / np.maximum(pool_sum, EPS), 0.0)
    out["share_match"] = np.where(match5 > 0, tv1 / np.maximum(match5, EPS), 0.0)
    out["share_board"] = np.where(board5 > 0, tv1 / np.maximum(board5, EPS), 0.0)
    out["n_lines"] = f.groupby(pkey, observed=True)["line_id"].transform("nunique").to_numpy(dtype="float64")
    out["corner"] = corner.astype(float)
    out["handicap"] = handicap.astype(float)
    pool = f["pool_name"].astype(str).to_numpy()
    for p in POOLS:
        out["pool_" + p] = (pool == p).astype(float)

    keys = f[KEY + ["bucket"]].reset_index(drop=True)
    feats = out[list(FEATURES)].astype("float32").reset_index(drop=True)
    feats = feats.replace([np.inf, -np.inf], 0.0).fillna(0.0)
    res = pd.concat([keys, feats], axis=1)
    res["y"] = y.astype("float32")
    res["last5"] = tv1.astype("float32")
    return res


# ------------------------------------------------------------------ model
class _LogRidge:
    def __init__(self, lam: float = 1.0):
        self.lam = lam
        self.beta = self.mean = self.std = None
        self.smear = 1.0

    def fit(self, x, y):
        self.mean = x.mean(axis=0)
        self.std = x.std(axis=0)
        self.std[self.std < 1e-8] = 1.0
        z = np.column_stack([np.ones(len(x)), (x - self.mean) / self.std])
        t = np.log1p(np.clip(y, 0, None))
        pen = self.lam * np.eye(z.shape[1])
        pen[0, 0] = 0.0
        self.beta = np.linalg.solve(z.T @ z + pen, z.T @ t)
        self.smear = float(np.clip(np.mean(np.exp(t - z @ self.beta)), 0.5, 5.0))

    def predict(self, x):
        z = np.column_stack([np.ones(len(x)), (x - self.mean) / self.std])
        return np.clip(np.expm1(np.clip(z @ self.beta, 0, 25)) * self.smear, 0, None)


class TurnoverModel:
    """Gradient boosting (Poisson) on CPU, or a log ridge if sklearn is missing."""

    def __init__(self, kind: str = "auto"):
        self.kind = kind
        self.model = None
        self.alpha = 0.0
        if kind in ("auto", "gbm"):
            try:
                from sklearn.ensemble import HistGradientBoostingRegressor  # noqa: F401
                self.kind = "gbm"
            except Exception:
                if kind == "gbm":
                    raise
                self.kind = "ridge"

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        if self.kind == "gbm":
            from sklearn.ensemble import HistGradientBoostingRegressor
            self.model = HistGradientBoostingRegressor(
                loss="poisson", learning_rate=0.06, max_iter=300, max_leaf_nodes=48,
                min_samples_leaf=200, l2_regularization=1.0, early_stopping=False)
            self.model.fit(x, np.clip(y, 0, None))
        else:
            self.model = _LogRidge()
            self.model.fit(x.astype("float64"), y.astype("float64"))

    def level(self, x: np.ndarray) -> np.ndarray:
        return np.clip(np.asarray(self.model.predict(x), dtype="float64"), 0, None)

    def predict(self, x: np.ndarray, last5: np.ndarray) -> np.ndarray:
        lag = np.clip(np.asarray(last5, dtype="float64"), 0, None)
        if self.model is None or self.alpha <= 0:
            return lag
        return self.alpha * self.level(x) + (1 - self.alpha) * lag

    def pick_alpha(self, x, y, last5) -> Dict[str, float]:
        lag = np.clip(np.asarray(last5, dtype="float64"), 0, None)
        lev = self.level(x)
        scores = {str(a): wape(y, a * lev + (1 - a) * lag) for a in ALPHAS}
        best = min(ALPHAS, key=lambda a: scores[str(a)] if np.isfinite(scores[str(a)]) else np.inf)
        self.alpha = float(best) if scores[str(best)] < scores["0.0"] - 1e-6 else 0.0
        return scores


# ------------------------------------------------------------------ files
def backtest_root(cfg: Config) -> Path:
    """Next to Raw_Data, unless ALGOE_BACKTEST_DATA points somewhere else."""
    import os
    env = os.environ.get("ALGOE_BACKTEST_DATA")
    if env:
        return Path(env)
    return Path(cfg.data_dir).resolve().parent / "Backtest_Data"


def _stamp(day) -> str:
    return "{:%Y-%m-%d}".format(pd.Timestamp(day))


def _write(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    frame.to_parquet(tmp, index=False)
    tmp.replace(path)


def align_day(root: Path, name: str, day: str) -> Optional[dict]:
    """Keyed forecast -> one value per row of Backtest_Data/index, in its order."""
    idx_path = root / "index" / "{}.parquet".format(day)
    keyed_path = root / "Turnover" / name / "_keyed" / "{}.parquet".format(day)
    if not idx_path.exists() or not keyed_path.exists():
        return None
    idx = pd.read_parquet(idx_path, columns=["label_key", "as_of"])
    n = len(idx)
    parts = idx["label_key"].astype(str).str.split(":", n=3, expand=True)
    left = pd.DataFrame({
        "match_id": pd.to_numeric(parts[0], errors="coerce"),
        "pool_name": parts[1].astype("string").str.upper(),
        "line_id": pd.to_numeric(parts[2], errors="coerce"),
        "combination_id": pd.to_numeric(parts[3], errors="coerce"),
        "bucket": pd.to_datetime(idx["as_of"]).astype("datetime64[ns]"),
        "_pos": np.arange(n),
    })
    left = _int_keys(left)
    keyed = _int_keys(pd.read_parquet(keyed_path))
    keyed["bucket"] = pd.to_datetime(keyed["bucket"]).astype("datetime64[ns]")
    keyed = keyed.drop_duplicates(KEY + ["bucket"])
    m = left.merge(keyed[KEY + ["bucket", "value"]], on=KEY + ["bucket"], how="left")
    m = m.sort_values("_pos")
    value = m["value"].to_numpy(dtype="float64")
    hit = np.isfinite(value)
    last5_path = root / "Turnover" / "last5min" / "{}.parquet".format(day)
    if last5_path.exists():
        last5 = pd.read_parquet(last5_path)["value"].to_numpy(dtype="float64")
        if len(last5) == n:
            value = np.where(hit, value, last5)
    value = np.nan_to_num(value, nan=0.0)
    _write(root / "Turnover" / name / "{}.parquet".format(day),
           pd.DataFrame({"value": value.astype("float32")}))
    actual_path = root / "Turnover" / "actual" / "{}.parquet".format(day)
    out = {"rows": n, "matched": int(hit.sum())}
    if actual_path.exists() and last5_path.exists():
        y = pd.read_parquet(actual_path)["value"].to_numpy(dtype="float64")
        l5 = pd.read_parquet(last5_path)["value"].to_numpy(dtype="float64")
        if len(y) == n == len(l5):
            out["wape_last5"] = wape(y, l5)
            out["wape_model"] = wape(y, value)
    return out


# -------------------------------------------------------------------- run
def _refit(store: List[dict], inner_days: int, kind: str, cap: int, rng) -> TurnoverModel:
    inner_n = min(inner_days, max(len(store) - 1, 0))
    fit = store[:len(store) - inner_n] or store
    inner = store[len(store) - inner_n:] if inner_n else []
    x = np.concatenate([d["x"] for d in fit])
    y = np.concatenate([d["y"] for d in fit])
    if len(y) > cap:
        take = rng.choice(len(y), size=cap, replace=False)
        x, y = x[take], y[take]
    m = TurnoverModel(kind)
    m.fit(x, y)
    if inner:
        scores = m.pick_alpha(np.concatenate([d["x"] for d in inner]),
                              np.concatenate([d["y"] for d in inner]),
                              np.concatenate([d["last5"] for d in inner]))
        print("[fit] {} on {:,} rows from {} day(s); alpha={} inner WAPE {}".format(
            m.kind, len(y), len(fit), m.alpha,
            {k: round(v, 4) for k, v in scores.items()}), flush=True)
    return m


def train(cfg: Config, name: str = "raw_gbm", kind: str = "auto", warmup_days: int = 14,
          inner_days: int = 7, refit_every: int = 7, per_day: int = 40000,
          fit_cap: int = 1_500_000, refresh_features: bool = False, seed: int = 7) -> dict:
    root = backtest_root(cfg)
    feat_dir = root / "Features"
    days = day_list(cfg.start_date, cfg.end_date)
    rng = np.random.default_rng(seed)
    model: Optional[TurnoverModel] = None
    store: List[dict] = []
    since = 0
    daily = []
    tot = {"y": 0.0, "p": 0.0, "m": 0.0}
    started = time.time()

    static = None
    month_cache = {}
    by_month: Dict[pd.Timestamp, List[pd.Timestamp]] = {}
    for d in days:
        by_month.setdefault(d.to_period("M").start_time, []).append(d)

    for m_start, want in by_month.items():
        mc = None
        for day in want:
            key = _stamp(day)
            fpath = feat_dir / "{}.parquet".format(key)
            if fpath.exists() and not refresh_features:
                feats = pd.read_parquet(fpath)
                src = "features"
            else:
                if static is None:
                    print("[raw] loading Pool_Details and Match_Information", flush=True)
                    static = load_static(cfg.data_dir, days[0], days[-1] + pd.Timedelta(days=1))
                if mc is None:
                    print("[raw] reading Raw_Data for {:%Y-%m}".format(m_start), flush=True)
                    mc = MonthCache(cfg, min(want), m_start + pd.offsets.MonthBegin(1))
                feats = build_features(cfg, day, mc, static[0], static[1])
                if not feats.empty:
                    _write(fpath, feats)
                src = "raw"
            if feats.empty:
                print("[skip] {} no rows".format(key), flush=True)
                continue
            x = feats[list(FEATURES)].to_numpy(dtype="float32")
            y = feats["y"].to_numpy(dtype="float64")
            last5 = feats["last5"].to_numpy(dtype="float64")

            pred = model.predict(x, last5) if model is not None else np.clip(last5, 0, None)
            keyed = feats[KEY + ["bucket"]].copy()
            keyed["value"] = pred.astype("float32")
            _write(root / "Turnover" / name / "_keyed" / "{}.parquet".format(key), keyed)
            aligned = align_day(root, name, key)

            row = {"day": key, "rows": int(len(feats)), "source": src,
                   "scored": model is not None,
                   "wape_last5": wape(y, last5), "wape_model": wape(y, pred)}
            if aligned is not None:
                row["backtest_rows"] = aligned["rows"]
                row["backtest_matched"] = aligned["matched"]
            daily.append(row)
            if model is not None:
                tot["y"] += float(np.abs(y).sum())
                tot["p"] += float(np.abs(y - last5).sum())
                tot["m"] += float(np.abs(y - pred).sum())
            print("[{}] {} rows={:,} last5={:.1%} {}={:.1%}{} ({:.0f}s)".format(
                "score" if model is not None else "warmup", key, len(feats),
                row["wape_last5"], name, row["wape_model"],
                "" if aligned is None else " -> backtest {:,}/{:,} matched".format(
                    aligned["matched"], aligned["rows"]),
                time.time() - started), flush=True)

            take = rng.choice(len(y), size=min(per_day, len(y)), replace=False)
            store.append({"x": x[take], "y": y[take].astype("float32"),
                          "last5": last5[take].astype("float32")})
            since += 1
            if len(store) >= warmup_days and (model is None or since >= refit_every):
                model = _refit(store, inner_days, kind, fit_cap, rng)
                since = 0
        mc = None

    report = {
        "name": name, "model": None if model is None else model.kind,
        "alpha": None if model is None else model.alpha,
        "days": len(daily), "warmup_days": warmup_days,
        "wape_last5": tot["p"] / tot["y"] if tot["y"] else None,
        "wape_model": tot["m"] / tot["y"] if tot["y"] else None,
        "features": list(FEATURES), "daily": daily,
        "seconds": round(time.time() - started, 1),
    }
    out = root / "Turnover" / name / "_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    if report["wape_model"] is None:
        print("[result] no day scored yet ({} day(s), warm-up {})".format(len(daily), warmup_days))
    else:
        print("[result] scored days: last 5 min WAPE {:.1%}   {} WAPE {:.1%}".format(
            report["wape_last5"], name, report["wape_model"]))
    missing = [r["day"] for r in daily if "backtest_rows" not in r]
    if missing:
        print("[note] {} day(s) have no Backtest_Data/index yet. After Open cached finishes, run:"
              .format(len(missing)))
        print('       python -m src.backtest.parquet.raw_turnover align --data-dir "{}" --name {}'
              .format(cfg.data_dir, name))
    print("[out] {}".format(out.parent))
    print("[next] Backtest -> Run -> Open cached. {} appears next to Last 5 min.".format(name))
    return report


def align(cfg: Config, name: str) -> None:
    root = backtest_root(cfg)
    folder = root / "Turnover" / name / "_keyed"
    if not folder.is_dir():
        raise SystemExit("nothing to align: {} does not exist. Run train first.".format(folder))
    done = 0
    for p in sorted(folder.glob("*.parquet")):
        res = align_day(root, name, p.stem)
        if res is None:
            print("[wait] {} has no Backtest_Data/index yet".format(p.stem))
            continue
        done += 1
        extra = ""
        if "wape_model" in res:
            extra = " last5={:.1%} {}={:.1%}".format(res["wape_last5"], name, res["wape_model"])
        print("[align] {} {:,}/{:,} matched{}".format(p.stem, res["matched"], res["rows"], extra))
    print("[done] {} day(s) aligned. Backtest -> Run -> Open cached.".format(done))


# --------------------------------------------------------------- selftest
def _fail(msg: str) -> None:
    raise SystemExit("[raw_turnover selftest] FAIL: " + msg)


def selftest() -> None:
    import shutil
    import tempfile
    from .book import load_compare
    from .cache import PanelCache
    from .selftest import make_fixture

    tmp = Path(tempfile.mkdtemp(prefix="algoe_rawtrain_"))
    try:
        raw = tmp / "Raw_Data"
        make_fixture(raw, days=5, matches_per_day=5, start="2026-07-01")
        cfg = Config(data_dir=raw, out_dir=tmp / "out", cache_dir=tmp / "cache",
                     start_date="2026-07-01", end_date="2026-07-05",
                     pools=["HILO", "HDC", "CHLO"], prematch_window_min=180)
        cache = PanelCache(cfg, tmp / "cache")
        cache.build(day_list(cfg.start_date, cfg.end_date))
        load_compare(cache, cfg.start_date, cfg.end_date, ("raw",))
        root = backtest_root(cfg)
        if not (root / "index").is_dir():
            _fail("backtest did not write Backtest_Data/index")

        rep = train(cfg, name="raw_gbm", kind="ridge", warmup_days=2, inner_days=1,
                    refit_every=2, per_day=5000)
        if rep["days"] == 0:
            _fail("no day trained")
        if rep["wape_model"] is None:
            _fail("nothing scored after warm-up")
        feats = sorted((root / "Features").glob("*.parquet"))
        if not feats:
            _fail("features were not saved")
        f0 = pd.read_parquet(feats[0])
        miss = [c for c in FEATURES if c not in f0.columns]
        if miss:
            _fail("feature file is missing {}".format(miss[:5]))
        # label must not leak into the features: change this bucket's turnover,
        # features must not move
        if np.allclose(f0["log_tv1"], np.log1p(f0["y"])) and (f0["y"] > 0).any():
            _fail("last-5 feature equals the label")

        facts, _ = load_compare(cache, cfg.start_date, cfg.end_date, ("raw",))
        col = "t_hat__raw_gbm"
        if col not in facts.columns:
            _fail("backtest did not pick up Turnover/raw_gbm")
        if not np.isfinite(pd.to_numeric(facts[col], errors="coerce")).all():
            _fail("backtest column has gaps")
        matched = [r.get("backtest_matched", 0) for r in rep["daily"]]
        if sum(matched) == 0:
            _fail("no raw row matched a backtest row")
        # second run must reuse the saved features, not reread Raw_Data
        rep2 = train(cfg, name="raw_gbm", kind="ridge", warmup_days=2, inner_days=1,
                     refit_every=2, per_day=5000)
        if any(r["source"] != "features" for r in rep2["daily"]):
            _fail("second run read Raw_Data again")
        print("[raw_turnover selftest] PASS  matched {:,} backtest rows".format(sum(matched)), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["train", "align", "selftest"])
    p.add_argument("--data-dir", default=r"S:\Users\Yeung\20260520 Algo E\Raw_Data")
    p.add_argument("--start", default="2026-07-01")
    p.add_argument("--end", default="2026-09-15")
    p.add_argument("--name", default="raw_gbm", help="folder under Backtest_Data/Turnover")
    p.add_argument("--model", default="auto", choices=["auto", "gbm", "ridge"])
    p.add_argument("--warmup-days", type=int, default=14)
    p.add_argument("--inner-days", type=int, default=7)
    p.add_argument("--refit-every", type=int, default=7)
    p.add_argument("--per-day", type=int, default=40000)
    p.add_argument("--refresh-features", action="store_true",
                   help="rebuild Backtest_Data/Features from Raw_Data even if saved")
    a = p.parse_args(argv)
    if a.command == "selftest":
        selftest()
        return
    # Same row set as the backtest page: every pool, same pre-match window.
    cfg = Config(data_dir=Path(a.data_dir), start_date=a.start, end_date=a.end, pools=[])
    if a.command == "align":
        align(cfg, a.name)
        return
    train(cfg, a.name, a.model, a.warmup_days, a.inner_days, a.refit_every, a.per_day,
          refresh_features=a.refresh_features)


if __name__ == "__main__":
    main()
