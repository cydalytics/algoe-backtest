"""
Theta Optimizer

For one match at one moment, choose the 8-dimensional theta that maximises

    E[GM](theta) = sum_i  T_i(theta) x risk_i x (1 - O_i(theta) x p_i)

    p_i       belief (ProbabilityCalibrator), fixed while theta moves
    O_i       the price we would post at theta
    T_i       money that price attracts over the horizon (TurnoverForecaster,
              nowcast-adjusted in focus mode)
    risk_i    share of a stake actually at risk (pushes / quarter-line halves)

This is project.md's four-step loop: step 1 anchors each pool's volume from
the forecast, step 2 searches theta, step 3 re-runs the demand response at the
candidate prices and renormalises inside the pool, step 4 scores E[GM].

PRICES (settings.optimizer.price_mode):

    delta     O_i(theta) = O_i(now) x p_i(theta_now) / p_i(theta)
              HKJC's posted board moved by our model's relative price change.
              At theta_now it IS the board, so the lift cannot come from a
              margin-table or rounding difference - only from theta.
    absolute  O_i(theta) = fair_i(theta) / (1 + margin_pool); needs the pricer
              to replicate HKJC's board (see the backtest's replication check).

DEMAND (settings.optimizer.demand):

    share_model   money moves between the lines and sides of a pool through
                  the price terms of the GLM selection-share model
                  (softmax with those coefficients)
    fixed         the same with one elasticity on log odds
    none          demand does not react; the solver will then only ever push
                  theta to the edge of its band, which is why it is not default

    and the pool's total money follows its price level (settings.optimizer.volume_response):
    factor exp(-e x money-weighted change in log overround). "neutral" sets e = 1 / margin, the
    elasticity at which HKJC's current margin is the volume-optimal one - without it, raising every
    price's margin would look free, because money only moved between selections.

STAGE 2 (settings.optimizer.weightings): with theta* fixed, a weighting w_i per selection,
O_i = O_i(theta*) x w_i - the desk's sell = fair / (1 + margin) x weighting. Each w within 1 +-
weighting_band (focus: within weighting_max_step of the last one); each line keeps its overround
(weighting_margin_band); no cross-line arbitrage (an over never shorter than the over of a lower
line; handicaps likewise); neighbours on the same side penalised for differing, every w for leaving
1. Solved pool by pool; MatchDecision reports both lifts. From 1 (a backtest, a match's first decision)
the weightings are kept only where they beat stage 1. Chained from the last ones (the live desk) they
move at most the step cap a refresh, part of the way, only for weighting_min_gain_bps, so a tilt the
money no longer backs unwinds step by step instead of vanishing; last weightings that break a
constraint on the new prices and that no capped move mends go back to 1 for their pool.

GUARDS: theta stays inside a band around HKJC's own theta and (in focus mode)
within ``max_step`` of the previous recommendation; TG >= |SUP|, first half
<= full match, second half coherent; main-line offers never beat the best
external price; every price inside [min_odds, max_odds] and within
``prob_band`` of HKJC's implied probability. HKJC's theta is always a
candidate, so the answer is never worse than doing nothing.

Goal and corner blocks share no parameter and no pool (demand is normalised
inside a pool), so each is solved as its own small problem.

Change Log:
-----------
2026-09-30      Initialize (replaces optimizer_v2b / backtest optimize / desk optimizer maths)
2026-10-01      Pool volume follows the price level (volume_response); stage 2 per-selection weightings
2026-11-19      W16: books for every match on sale; stage 2 chained from the last weightings (step cap,
                partial adjustment, deadband, market guard on every line, constraints before the cap); a
                held match carries its weightings; the card finishes in-process when the pool breaks
"""

from __future__ import annotations

import os
import time
import warnings
from concurrent.futures import FIRST_COMPLETED, wait
from concurrent.futures.process import BrokenProcessPool
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.logging import get_logger
from ..core.pool import process_pool
from ..core.taxonomy import ASIAN, default_taxonomy, resolve_pools
from ..features.catalog import PRICE_FEATURES
from ..pricing.pricer import (DIMS, BookPricer, BookRows, Conventions, MatchState, ladder, repair_theta,
                              theta_from_params)

logger = get_logger(__name__)

try:
    from scipy.optimize import minimize
    HAVE_SCIPY = True
except Exception:                                          # pragma: no cover
    HAVE_SCIPY = False

BLOCKS = {"goal": ("goal_tg", "goal_sup", "goal_fh_tg", "goal_fh_sup"),
          "corner": ("corner_tg", "corner_sup", "corner_fh_tg", "corner_fh_sup")}
ABS_BOUNDS = {"goal_tg": (0.02, 9.0), "goal_sup": (-5.0, 5.0), "goal_fh_tg": (0.0, 5.0),
              "goal_fh_sup": (-3.0, 3.0), "corner_tg": (0.2, 25.0), "corner_sup": (-10.0, 10.0),
              "corner_fh_tg": (0.0, 14.0), "corner_fh_sup": (-6.0, 6.0)}
PENALTY = 1e4


@contextmanager
def _quiet_bounds():
    """SLSQP can step outside its box inside a line search; SciPy clips the step back and warns every
    time. Clipping is what we want, so that one warning is silenced - every other one still shows."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Values in x were outside bounds", category=RuntimeWarning)
        yield


# =============================================================== demand
@dataclass
class DemandResponse:
    """How a selection's money responds when its price moves, holding its pool's volume."""
    mode: str = "share_model"
    coef: Dict[str, float] = field(default_factory=dict)       # per-unit coefficients on PRICE_FEATURES
    elasticity: float = 1.0                                   # fixed mode, on log odds
    cap: float = 6.0
    volume_mode: str = "neutral"                              # neutral | fixed | none
    volume_elasticity: float = 0.0                            # fixed volume mode

    @classmethod
    def from_forecaster(cls, forecaster, settings) -> "DemandResponse":
        dr = cls._from_forecaster(forecaster, settings)
        dr.volume_mode = settings.optimizer.volume_response
        dr.volume_elasticity = float(settings.optimizer.volume_elasticity)
        return dr

    def volume_factor(self, overround_now: np.ndarray, overround_new: np.ndarray) -> np.ndarray:
        """Multiplier on a pool's money when its (money-weighted) overround moves now -> new."""
        if self.volume_mode == "none":
            return np.ones_like(overround_now)
        d = np.log(np.maximum(overround_new, 1e-9)) - np.log(np.maximum(overround_now, 1e-9))
        if self.volume_mode == "fixed":
            e = np.full_like(overround_now, self.volume_elasticity)
        else:
            e = 1.0 / np.clip(overround_now - 1.0, 0.02, None)        # 1 / margin, at most 50
        return np.exp(np.clip(-e * d, -1.6, 1.6))

    @classmethod
    def _from_forecaster(cls, forecaster, settings) -> "DemandResponse":
        o = settings.optimizer
        if o.demand == "none":
            return cls(mode="none")
        if o.demand == "fixed" or forecaster is None:
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        m = forecaster.models.get(("glm", "selection_share")) if forecaster is not None else None
        if m is None:
            logger.warning("no GLM selection-share model: demand falls back to fixed elasticity %.2f",
                           o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        c = m.coefficients()
        coef = {k: float(c.get(k, 0.0)) for k in PRICE_FEATURES}
        dr = cls(mode="share_model", coef=coef, cap=o.max_elasticity)
        # Check the response the optimiser will actually apply. value_true needs HKJC's true price - in
        # serving only when the model learned with it (LiveEngine ignores live true odds otherwise) -
        # and the market terms need a market price, which many rows lack: every case that can occur
        # must take more money at a longer price.
        cov = ((getattr(forecaster, "metadata", None) or {}).get("true_odds_coverage"))
        true_on = cov is not None and np.isfinite(cov) and cov >= 0.5
        cases = {"no market price": dr.elasticity_at(1.9, 0.5 if true_on else np.nan, np.nan, np.nan),
                 "market price": dr.elasticity_at(1.9, 0.5 if true_on else np.nan, 0.5, 1.9)}
        shown = ", ".join("{} {:+.3f}".format(k, v) for k, v in cases.items())
        if min(cases.values()) < 0:
            logger.warning("share model elasticity at evens (%s; HKJC true price %s): a longer price takes LESS "
                           "money where it is negative - reverse causality (HKJC shortens a price after money "
                           "arrives), not demand. Using fixed elasticity %.2f instead",
                           shown, "used" if true_on else "not in the data", o.fixed_elasticity)
            return cls(mode="fixed", elasticity=o.fixed_elasticity, cap=o.max_elasticity)
        logger.info("demand response from the share model: price coefficients %s, elasticity at evens: %s",
                    {k: round(v, 4) for k, v in coef.items()}, shown)
        return dr

    def elasticity_at(self, odds, p_true, p_mkt, o_mkt) -> float:
        """d log(money) / d log(odds) at one price; a NaN reference price drops its term, as log_shift does."""
        if self.mode == "none":
            return 0.0
        if self.mode == "fixed":
            return self.elasticity
        c = self.coef

        def known(v):
            return 0.0 if v is None or not np.isfinite(v) else float(v)
        e = -c.get("imp", 0.0) / odds + c.get("log_odds", 0.0)
        e += c.get("value_true", 0.0) * odds * known(p_true)
        e += c.get("value_mkt", 0.0) * odds * known(p_mkt)
        if o_mkt is not None and np.isfinite(o_mkt) and o_mkt > 0:
            e += c.get("hk_vs_mkt", 0.0) * odds / o_mkt
        return float(e)

    def log_shift(self, odds_new, odds_now, p_ref, p_mkt, o_mkt) -> np.ndarray:
        """Change in log money per selection when its price moves from odds_now to odds_new."""
        if self.mode == "none":
            return np.zeros_like(odds_new)
        if self.mode == "fixed":
            d = self.elasticity * (np.log(odds_new) - np.log(odds_now))
        else:
            c = self.coef
            d = (c.get("imp", 0.0) * (1.0 / odds_new - 1.0 / odds_now)
                 + c.get("log_odds", 0.0) * (np.log(odds_new) - np.log(odds_now))
                 + c.get("value_true", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_ref)
                 + c.get("value_mkt", 0.0) * (odds_new - odds_now) * np.nan_to_num(p_mkt)
                 + c.get("hk_vs_mkt", 0.0) * np.where(np.isfinite(o_mkt), (odds_new - odds_now) / o_mkt, 0.0))
        return np.clip(d, -self.cap, self.cap)


# ================================================================= book
@dataclass
class MatchBook:
    match_id: int
    rows: BookRows
    pool: np.ndarray
    group: np.ndarray              # pool index: demand is renormalised inside it
    margin: np.ndarray
    demand: np.ndarray             # expected money at the current price, over the horizon
    p_true: np.ndarray
    p_ref: np.ndarray              # HKJC true prob (the value_true feature's reference)
    p_mkt: np.ndarray
    odds_now: np.ndarray
    odds_mkt: np.ndarray
    is_main: np.ndarray
    state: MatchState
    theta_now: Dict[str, float]
    theta_prev: Optional[Dict[str, float]] = None
    keys: Optional[pd.DataFrame] = None
    p_now: Optional[np.ndarray] = None
    risk: Optional[np.ndarray] = None
    w_prev: Optional[np.ndarray] = None           # last stage-2 weighting per row (focus refreshes)
    line_group: Optional[np.ndarray] = None       # index of (pool, line) per row, filled on first use
    draw_factor: float = 1.0                      # goals priced with it (publishing: the match's Goal90DrawFactor)
    theta_anchor: Optional[Dict[str, float]] = None   # the trust band's centre when it is not theta_now
    theta_source: Dict[str, str] = field(default_factory=dict)   # per block: hkjc, or implied from the board
    far: bool = False                             # outside the model window: demand from the far pre-match curve
    received: Optional[np.ndarray] = None         # money already in this bucket per row (struck at earlier prices)

    @property
    def implied(self) -> bool:
        return "implied" in self.theta_source.values()

    @property
    def n(self) -> int:
        return len(self.demand)

    @property
    def total_demand(self) -> float:
        return float(np.nansum(self.demand))


@dataclass
class MatchDecision:
    match_id: int
    status: str
    theta_now: Dict[str, float]
    theta_star: Dict[str, float]
    egm_board: float               # posted board, current demand
    egm_now: float                 # theta_now through the pricing mode (== board in delta mode)
    egm_star: float
    turnover: float
    seconds: float
    n_selections: int
    evaluations: int = 0
    binding: List[str] = field(default_factory=list)
    odds_star: Optional[np.ndarray] = None
    demand_star: Optional[np.ndarray] = None
    per_pool: List[dict] = field(default_factory=list)
    egm_stage1: float = float("nan")              # theta* alone, before the weightings
    weights: Optional[np.ndarray] = None          # stage-2 weighting per selection (1 = none)

    @property
    def lift(self) -> float:
        return self.egm_star - self.egm_board

    @property
    def lift_stage1(self) -> float:
        return (self.egm_stage1 if np.isfinite(self.egm_stage1) else self.egm_star) - self.egm_board

    @property
    def lift_stage2(self) -> float:
        return self.egm_star - self.egm_stage1 if np.isfinite(self.egm_stage1) else 0.0

    @property
    def lift_bps(self) -> float:
        return 1e4 * self.lift / self.turnover if self.turnover > 0 else 0.0

    def to_dict(self) -> dict:
        w = self.weights if self.weights is not None else np.ones(0)
        return {"match_id": self.match_id, "status": self.status, "theta_now": self.theta_now,
                "theta_star": self.theta_star, "egm_board": self.egm_board, "egm_now": self.egm_now,
                "egm_stage1": self.egm_stage1, "egm_star": self.egm_star, "lift": self.lift,
                "lift_stage1": self.lift_stage1, "lift_stage2": self.lift_stage2, "lift_bps": self.lift_bps,
                "turnover": self.turnover, "seconds": self.seconds, "n_selections": self.n_selections,
                "evaluations": self.evaluations, "binding": self.binding, "per_pool": self.per_pool,
                "weights_moved": int(np.sum(np.abs(w - 1.0) > 1e-6)),
                "weight_max_move": float(np.max(np.abs(w - 1.0))) if len(w) else 0.0}


@dataclass
class Quantized:
    """A decision at the precision the pricing engine takes (ThetaOptimizer.quantize)."""
    theta: Dict[str, float]        # rounded; a first-half dimension that is not free follows its full match
    weights: np.ndarray            # rounded per selection; 1.0 = none
    odds: np.ndarray
    demand: np.ndarray
    egm: float
    egm_board: float               # HKJC's own theta rounded the same way, no weightings
    chosen: str                    # "theta*" | "board"
    reset_lines: List[str] = field(default_factory=list)


# ============================================================ optimiser
class ThetaOptimizer:
    def __init__(self, settings, demand: Optional[DemandResponse] = None, free_dims: Optional[Sequence[str]] = None):
        self.settings = settings
        o = settings.optimizer
        self.o = o
        self.pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
        self._pricers: Dict[float, BookPricer] = {}
        self.demand = demand or DemandResponse(mode=o.demand if o.demand != "share_model" else "fixed",
                                               elasticity=o.fixed_elasticity, cap=o.max_elasticity,
                                               volume_mode=o.volume_response,
                                               volume_elasticity=float(o.volume_elasticity))
        self.price_mode = getattr(o, "price_mode", "delta")
        self.allowed = tuple(free_dims if free_dims is not None else getattr(o, "free_dims", DIMS))
        self.follows = tuple(d for d in DIMS if "_fh_" in d and d not in self.allowed)

    # ------------------------------------------------------------ pieces
    def pricer_for(self, book: MatchBook) -> BookPricer:
        """The pricer at the book's draw factor."""
        df = float(getattr(book, "draw_factor", 1.0) or 1.0)
        if abs(df - 1.0) < 1e-12:
            return self.pricer
        if df not in self._pricers:
            self._pricers[df] = BookPricer(replace(self.pricer.conv, draw_factor=df))
        return self._pricers[df]

    def _follow(self, theta: Dict[str, float], th_now: Dict[str, float]) -> Dict[str, float]:
        """A first-half dimension the optimiser may not move follows its full-match one by HKJC's own ratio,
        the share theta_from_params gave the first half for this bucket."""
        if not self.follows:
            return theta
        out = dict(theta)
        for tg, sup, ftg, fsup in (BLOCKS["goal"], BLOCKS["corner"]):
            base = float(th_now.get(tg, 0.0))
            share = float(th_now.get(ftg, 0.0)) / base if base > 1e-9 else 0.0
            if ftg in self.follows:
                out[ftg] = float(out[tg]) * share
            if fsup in self.follows:
                out[fsup] = float(out[sup]) * share
        return out

    def prices(self, book: MatchBook, theta: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        p, _ = self.pricer_for(book).probabilities(book.rows, theta, book.state)
        if self.price_mode == "delta":
            with np.errstate(divide="ignore", invalid="ignore"):
                odds = book.odds_now * book.p_now / p
        else:
            odds = BookPricer.sell_odds(p, book.margin)
        return odds, p

    def demand_at(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        shift = self.demand.log_shift(np.clip(odds, 1.0001, None), book.odds_now, book.p_ref, book.p_mkt,
                                      book.odds_mkt)
        w = book.demand * np.exp(shift)
        pool_now = _group_sum(book.demand, book.group)
        pool_new = _group_sum(w, book.group)
        T = np.where(pool_new > 0, w * pool_now / np.maximum(pool_new, 1e-12), book.demand)
        if self.demand.volume_mode != "none":
            T = T * self._volume(book, odds)
        return T

    def _volume(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        """Each pool's money multiplier from the change in its lines' overround (money-weighted)."""
        lg = _line_groups(book)
        inv_now = np.where(book.odds_now > 1.0, 1.0 / np.where(book.odds_now > 1.0, book.odds_now, 2.0), 0.0)
        good = np.isfinite(odds) & (odds > 1.0)
        inv_new = np.where(good, 1.0 / np.where(good, odds, 2.0), inv_now)
        sizes = np.bincount(lg, minlength=int(lg.max()) + 1)[lg]
        r_now, r_new = _group_sum(inv_now, lg), _group_sum(inv_new, lg)
        two = sizes >= 2                                  # a lone side has no overround to speak of
        d = np.where(two & (r_now > 0) & (r_new > 0), np.log(np.maximum(r_new, 1e-12) / np.maximum(r_now, 1e-12)), 0.0)
        dem = np.nan_to_num(book.demand)
        tot = np.maximum(_group_sum(dem, book.group), 1e-12)
        pool_d = _group_sum(dem * d, book.group) / tot
        pool_r = np.where(_group_sum(dem * two, book.group) > 0,
                          _group_sum(dem * np.where(two, r_now, 0.0), book.group) /
                          np.maximum(_group_sum(dem * two, book.group), 1e-12), 1.0)
        return self.demand.volume_factor(pool_r, pool_r * np.exp(pool_d))

    def expected_gm(self, book: MatchBook, odds: np.ndarray, demand: Optional[np.ndarray] = None) -> float:
        T = book.demand if demand is None else demand
        return float(np.nansum(T * book.risk * (1.0 - odds * book.p_true)))

    def payout_spread(self, book: MatchBook, odds: np.ndarray, demand: Optional[np.ndarray] = None) -> float:
        """Over the lines, the spread (standard deviation under the belief) of each line's gross margin across
        its outcomes: the money already in, struck at about HKJC's posted price, and the money ``odds`` attract.
        Stage 2's optional liability term (optimizer.liability_lambda)."""
        T = book.demand if demand is None else demand
        R = book.received if book.received is not None else np.zeros(book.n)
        stake = np.nan_to_num(R) + np.nan_to_num(T)
        paid = np.nan_to_num(R * book.odds_now) + np.nan_to_num(T * odds)
        lg = _line_groups(book)
        total = 0.0
        for g in np.unique(lg):
            j = np.flatnonzero(lg == g)
            q = book.p_true[j]
            s = float(np.nansum(q))
            if len(j) < 2 or not s > 0:
                continue
            q = np.nan_to_num(q) / s
            gm = float(stake[j].sum()) - paid[j]
            mean = float(np.dot(q, gm))
            total += float(np.sqrt(max(float(np.dot(q, (gm - mean) ** 2)), 0.0)))
        return total

    def _violation(self, book: MatchBook, odds: np.ndarray) -> float:
        o = self.o
        v = 0.0
        bad = ~np.isfinite(odds)
        v += float(bad.sum()) * 10.0
        od = np.where(bad, o.min_odds, odds)
        v += float(np.sum(np.maximum(o.min_odds - od, 0.0) ** 2 + np.maximum(od - o.max_odds, 0.0) ** 2 * 1e-4))
        if o.prob_band and o.prob_band > 0:
            gap = np.abs(1.0 / od - 1.0 / book.odds_now) - o.prob_band
            v += float(np.sum(np.maximum(gap, 0.0) ** 2) * 100.0)
        if o.market_cap:
            cap = np.where(np.isfinite(book.odds_mkt), np.maximum(book.odds_mkt, book.odds_now), np.inf)
            over = np.where(book.is_main, np.maximum(od - cap, 0.0), 0.0)
            v += float(np.sum(over ** 2) * 10.0)
        return v

    # -------------------------------------------------------------- solve
    def optimize_match(self, book: MatchBook, mode: str = "sweep") -> MatchDecision:
        started = time.time()
        o = self.o
        th_now = repair_theta(book.theta_now)
        base_odds = book.odds_now
        egm_board = self.expected_gm(book, base_odds)
        if book.total_demand < o.min_match_turnover and mode == "sweep":
            # every match on sale gets an answer; on this little money no move is worth making, so it holds the
            # board (and, like any kept board, is not published before the match has a message of ours) with the
            # weightings it carries, so the chain does not drop them
            w = np.ones(book.n)
            if getattr(o, "weightings", False) and book.w_prev is not None:
                w = self._stage2(book, base_odds, mode, [], solve=False)
            odds_h, T_h, egm_h = base_odds, book.demand, egm_board
            if np.any(np.abs(w - 1.0) > 1e-12):
                odds_h = base_odds * w
                T_h = self.demand_at(book, odds_h)
                egm_h = self.expected_gm(book, odds_h, T_h)
            return MatchDecision(book.match_id, "kept board (little money)", th_now, dict(th_now), egm_board,
                                 egm_board, egm_h, book.total_demand, round(time.time() - started, 4), book.n, 0,
                                 odds_star=odds_h, demand_star=T_h, egm_stage1=egm_board, weights=w)
        evals = [0]
        free_all = self._free_dims(book)
        theta = dict(th_now)
        odds_now_model, _ = self.prices(book, th_now)
        egm_now = self.expected_gm(book, odds_now_model, self.demand_at(book, odds_now_model))
        binding = []
        for block, dims in BLOCKS.items():
            free = [d for d in dims if d in free_all]
            if not free:
                continue
            # a block's parameters only price its own domain's pools, and demand is
            # renormalised inside a pool, so the block is scored on its rows alone
            sub = _sub_book(book, np.isin(book.rows.theta_domain, [block, block + "_fh"]))
            scale = max(sub.total_demand, 1.0)
            lo, hi = self._bounds(free, th_now, book.theta_prev if mode == "focus" else None, book.theta_anchor)
            # a dimension whose bounds have closed is held there, not handed to the solver
            movable = hi - lo > 1e-12
            if not movable.all():
                for d, v in zip([d for d, m in zip(free, movable) if not m], lo[~movable]):
                    theta[d] = float(v)
                free = [d for d, m in zip(free, movable) if m]
                lo, hi = lo[movable], hi[movable]
                if not free:
                    continue
            # a dimension the money is indifferent to (SUP when everything sits on one total) stays at HKJC's value
            anchor = np.array([th_now[d] for d in free])
            width = np.array([max(float(o.theta_band.get(d, 0.5)), 1e-6) for d in free])
            stay = float(getattr(o, "stay_cost", 0.0))

            def score(vec, free=free, sub=sub, scale=scale, anchor=anchor, width=width):
                th = dict(theta)
                th.update(zip(free, vec))
                th = repair_theta(self._follow(th, th_now))
                odds, _ = self.prices(sub, th)
                evals[0] += 1
                T = self.demand_at(sub, np.where(np.isfinite(odds), odds, sub.odds_now))
                return -self.expected_gm(sub, np.where(np.isfinite(odds), odds, 1.0), T) / scale \
                    + PENALTY * self._violation(sub, odds) + stay * float(np.sum(((vec - anchor) / width) ** 2))

            x0 = np.array([theta[d] for d in free])
            best_x, best_f = x0.copy(), score(x0)
            starts = [x0]
            n_starts = o.starts_focus if mode == "focus" else o.starts_sweep
            if book.theta_prev is not None and mode == "focus":
                starts.insert(0, np.clip([book.theta_prev.get(d, theta[d]) for d in free], lo, hi))
            rng = np.random.default_rng(book.match_id % 100000)
            while len(starts) < n_starts:
                starts.append(lo + rng.random(len(free)) * (hi - lo))
            if HAVE_SCIPY:
                cons = self._coherence(free, theta)
                # a focus refresh starts next to the answer; it must never cost a full solve
                max_iter = min(o.max_iter, 20) if mode == "focus" else o.max_iter
                for s0 in starts[:max(n_starts, 1)]:
                    try:
                        # the objective is E[GM] per $ of demand (~0.1), so 1e-7 is far below a cent per HK$1000
                        with _quiet_bounds():
                            res = minimize(score, np.clip(s0, lo, hi), method="SLSQP", bounds=list(zip(lo, hi)),
                                           constraints=cons, options={"maxiter": max_iter, "ftol": 1e-7, "eps": 1e-3})
                    except Exception as exc:                        # noqa: BLE001
                        logger.debug("match %s block %s SLSQP failed: %s", book.match_id, block, exc)
                        continue
                    if np.all(np.isfinite(res.x)) and res.fun < best_f:
                        best_x, best_f = np.clip(res.x, lo, hi), float(res.fun)
            else:
                best_x, best_f = _grid(score, x0, lo, hi)
            for d, v, l, h in zip(free, best_x, lo, hi):
                theta[d] = float(v)
                if min(v - l, h - v) < 1e-4 * max(h - l, 1e-9):
                    binding.append("{}@{}".format(d, "lo" if v - l < h - v else "hi"))
            th_b = repair_theta(self._follow(theta, th_now))
            odds_b, _ = self.prices(sub, th_b)
            if o.prob_band and np.any(np.abs(1.0 / np.where(np.isfinite(odds_b), odds_b, 1.0) - 1.0 / sub.odds_now)
                                      > o.prob_band - 1e-3):
                binding.append("{}:prob_band".format(block))
        theta = repair_theta(self._follow(theta, th_now))
        odds_star, _ = self.prices(book, theta)
        feasible = self._violation(book, odds_star) < 1e-6 and np.all(np.isfinite(odds_star))
        T_star = self.demand_at(book, np.where(np.isfinite(odds_star), odds_star, book.odds_now))
        egm_star = self.expected_gm(book, odds_star, T_star) if feasible else -np.inf
        status = "solved"
        if not feasible or egm_star < egm_board:
            # the board as posted is always available: never recommend something worse
            theta, odds_star, T_star, egm_star = dict(th_now), base_odds.copy(), book.demand.copy(), egm_board
            status = "kept board (no feasible improvement)" if feasible or not np.isfinite(egm_star) else \
                "kept board (infeasible)"
        # stage 2: per-selection weightings on top of theta*
        egm_stage1, weights = egm_star, np.ones(book.n)
        if getattr(o, "weightings", False):
            w = self._stage2(book, odds_star, mode, binding)
            chained = book.w_prev is not None and len(book.w_prev) == book.n
            if np.any(np.abs(w - 1.0) > 1e-9):
                odds_w = odds_star * w
                T_w = self.demand_at(book, odds_w)
                egm_w = self.expected_gm(book, odds_w, T_w)
                better = egm_w > egm_star + 1e-9
                tol = 1e-6 * max(len(np.unique(book.pool)), 1)          # stage 2 checks each pool to 1e-6
                # from 1 they must beat theta* alone; chained, they unwind a tilt the money no longer backs at the
                # capped pace rather than drop it, so they only have to keep every constraint
                if self._violation(book, odds_w) < tol and self._market_guard(book, odds_w, odds_star) < tol \
                        and np.all(np.isfinite(odds_w)) and (better or chained):
                    odds_star, T_star, egm_star, weights = odds_w, T_w, egm_w, w
                    if status.startswith("kept") and better:
                        status = "solved (weightings only)"
        dec = MatchDecision(book.match_id, status, th_now, theta, egm_board, egm_now, egm_star,
                            book.total_demand, round(time.time() - started, 4), book.n, evals[0], binding,
                            odds_star, T_star, self._per_pool(book, odds_star, T_star),
                            egm_stage1=egm_stage1, weights=weights)
        return dec

    def _stage2(self, book: MatchBook, odds1: np.ndarray, mode: str, binding: List[str],
                solve: bool = True) -> np.ndarray:
        """Weightings per selection on the stage-1 prices, pool by pool (demand moves inside a pool).

        A book carrying its last weightings (the live desk's chain) moves from them, refitted to each line's
        overround on these prices: at most weighting_max_step (focus) or weighting_max_step_sweep (sweep) per
        refresh, only weighting_adjust of the way to the solve's target (in implied-probability space, so each
        line keeps its overround and the ladder holds), and only when that earns weighting_min_gain_bps of the
        pool's money; otherwise the pool keeps its last weightings. Every price stays inside the market guard.
        Last weightings that break a constraint on these prices (overround, ladder, bounds, guard) and that no
        move inside the step cap mends go back to 1 for their pool: the constraints come before the cap.
        ``solve=False`` carries the last weightings, checked, without solving (a held match)."""
        o = self.o
        n = book.n
        band = float(getattr(o, "weighting_band", 0.0))
        if not HAVE_SCIPY or n < 2 or band <= 0:
            return np.ones(n)
        lo, hi = np.full(n, 1.0 - band), np.full(n, 1.0 + band)
        lg = _line_groups(book)
        sizes = np.bincount(lg, minlength=int(lg.max()) + 1)[lg]
        fixed = (sizes < 2) | ~np.isfinite(odds1)          # a lone side, or no price: left alone
        chained = book.w_prev is not None and len(book.w_prev) == n
        if not chained and not solve:
            return np.ones(n)
        start = np.ones(n)
        if chained:
            prev = np.where(np.isfinite(book.w_prev), book.w_prev, 1.0)
            start = np.clip(_refit_overround(odds1, prev, lg, fixed), lo, hi)
            step = float(o.weighting_max_step if mode == "focus" else
                         getattr(o, "weighting_max_step_sweep", o.weighting_max_step))
            if step > 0:
                lo, hi = np.maximum(lo, start - step), np.minimum(hi, start + step)
        lo[fixed] = hi[fixed] = start[fixed] = 1.0
        w = start.copy()                                   # a pool that does not move keeps its last weightings
        alpha = float(np.clip(getattr(o, "weighting_adjust", 1.0), 0.0, 1.0)) if chained else 1.0
        min_gain = float(getattr(o, "weighting_min_gain_bps", 0.0)) * 1e-4
        margin_band = float(o.weighting_margin_band)
        for pool in np.unique(book.pool):
            rows = np.flatnonzero(book.pool == pool)
            sub = _sub_book(book, book.pool == pool)
            o1, lo_p, hi_p, lgp = odds1[rows], lo[rows], hi[rows], lg[rows]
            cons = []
            for g in np.unique(lgp):
                j = np.flatnonzero(lgp == g)
                if len(j) < 2:
                    continue
                r1 = float(np.sum(1.0 / o1[j]))

                def over(x, j=j, r1=r1):
                    return float(np.sum(1.0 / (o1[j] * x[j]))) - r1
                if margin_band <= 0:
                    cons.append({"type": "eq", "fun": over})
                else:
                    cons.append({"type": "ineq", "fun": lambda x, f=over, r1=r1: f(x) + margin_band * r1})
                    cons.append({"type": "ineq", "fun": lambda x, f=over, r1=r1: margin_band * r1 - f(x)})
            ladder_pairs, neighbours = _ladder(sub, o1)
            for a, b in ladder_pairs:                      # O_a <= O_b keeps the ladder arbitrage-free
                cons.append({"type": "ineq", "fun": lambda x, a=a, b=b: o1[b] * x[b] - o1[a] * x[a]})
            scale = max(sub.total_demand, 1.0)
            lam = float(getattr(o, "liability_lambda", 0.0) or 0.0) if sub.received is not None else 0.0

            def score(x, sub=sub, o1=o1, neighbours=neighbours, lam=lam):
                odds = o1 * x
                T = self.demand_at(sub, odds)
                lx = np.log(np.maximum(x, 1e-9))
                pen = float(o.weighting_ridge) * float(np.sum(lx ** 2))
                if neighbours:
                    pen += float(o.weighting_smoothness) * float(sum((lx[a] - lx[b]) ** 2 for a, b in neighbours))
                if lam > 0:
                    pen += lam * self.payout_spread(sub, odds, T) / scale
                return -self.expected_gm(sub, odds, T) / scale + pen + \
                    PENALTY * (self._violation(sub, odds) + self._market_guard(sub, odds, o1))

            def holds(x, sub=sub, o1=o1, cons=cons):
                odds = o1 * x
                return all(abs(c["fun"](x)) <= 1e-7 if c["type"] == "eq" else c["fun"](x) >= -1e-9 for c in cons) \
                    and self._violation(sub, odds) < 1e-6 and self._market_guard(sub, odds, o1) < 1e-6

            x0 = np.clip(start[rows], lo_p, hi_p)
            ok0 = holds(x0)
            # only the weightings that can move are the solver's; the fixed ones are filled back in
            mov = np.flatnonzero(hi_p - lo_p > 1e-12)
            x, at_band = None, False
            if solve and (~fixed[rows]).sum() >= 2 and len(mov) >= 2:
                def full(z, x0=x0, mov=mov):
                    x = x0.copy()
                    x[mov] = z
                    return x
                cons_z = [{"type": c["type"], "fun": (lambda z, f=c["fun"]: f(full(z)))} for c in cons]
                try:
                    with _quiet_bounds():
                        res = minimize(lambda z: score(full(z)), x0[mov], method="SLSQP",
                                       bounds=list(zip(lo_p[mov], hi_p[mov])), constraints=cons_z,
                                       options={"maxiter": 20 if mode == "focus" else 60, "ftol": 1e-10,
                                                "eps": 1e-5})
                    if np.all(np.isfinite(res.x)):
                        x = full(np.clip(res.x, lo_p[mov], hi_p[mov]))
                except Exception as exc:                    # noqa: BLE001
                    logger.debug("match %s pool %s weightings failed: %s", book.match_id, pool, exc)
                if x is not None and not (holds(x) and score(x) < score(x0) - 1e-12):
                    x = None
                if x is not None:
                    at_band = bool(np.any((np.minimum(x - lo_p, hi_p - x) < 1e-5) & (hi_p - lo_p > 1e-9)))
                    if alpha < 1.0:
                        # part of the way from a start that breaks a constraint can still break it
                        part = _toward(o1, x0, x, alpha, lgp)
                        x = part if holds(part) else x
                    T0, T1 = self.demand_at(sub, o1 * x0), self.demand_at(sub, o1 * x)
                    gain = self.expected_gm(sub, o1 * x, T1) - self.expected_gm(sub, o1 * x0, T0)
                    if ok0 and gain < min_gain * scale:
                        x = None                           # not worth a move: the last weightings stay
            if x is None:
                if ok0 or np.allclose(x0, 1.0):
                    continue
                x, at_band = np.ones(len(rows)), False
                binding.append("{}:weighting_reset".format(pool))
            w[rows] = x
            if at_band:
                binding.append("{}:weighting_band".format(pool))
        return w

    def _market_guard(self, book: MatchBook, odds: np.ndarray, odds1: np.ndarray) -> float:
        """Stage 2's market guard (optimizer.weighting_market_lines: every line with an external price, or the
        main lines only): no price past the best of the market, HKJC's and the stage-1 price, and no implied
        probability further than weighting_market_band from the market's de-margined one (or than HKJC's or the
        stage-1 price already were). The stage-1 prices never violate it, so it only holds the weightings back."""
        o = self.o
        lines = getattr(o, "weighting_market_lines", "main")
        has = np.isfinite(book.odds_mkt) & np.isfinite(odds) & (odds > 1.0)
        rows = has if lines == "all" else has & book.is_main
        if not rows.any():
            return 0.0
        o1 = np.where(np.isfinite(odds1), odds1, book.odds_now)
        cap = np.fmax(np.fmax(book.odds_mkt, book.odds_now), o1)
        v = float(np.sum(np.where(rows, np.maximum(odds - cap, 0.0), 0.0) ** 2) * 10.0)
        band = float(getattr(o, "weighting_market_band", 0.0))
        pm = book.p_mkt
        near = rows & np.isfinite(pm)
        if band > 0 and near.any():
            safe = np.where(near, odds, 2.0)
            allow = np.fmax(band, np.fmax(np.abs(1.0 / book.odds_now - pm), np.abs(1.0 / o1 - pm)))
            gap = np.where(near, np.abs(1.0 / safe - pm) - allow, 0.0)
            v += float(np.sum(np.maximum(np.nan_to_num(gap), 0.0) ** 2) * 100.0)
        return v

    def _free_dims(self, book: MatchBook) -> List[str]:
        doms = set(book.rows.theta_domain.tolist())
        free = []
        if "goal" in doms:
            free += ["goal_tg", "goal_sup"]
        if "goal_fh" in doms and not book.state.ht_done:
            free += ["goal_fh_tg", "goal_fh_sup"]
        if "corner" in doms:
            free += ["corner_tg", "corner_sup"]
        if "corner_fh" in doms and not book.state.ht_done:
            free += ["corner_fh_tg", "corner_fh_sup"]
        return [d for d in free if d in self.allowed]

    def _bounds(self, free, th_now, th_prev, th_anchor=None) -> Tuple[np.ndarray, np.ndarray]:
        lo, hi = [], []
        for d in free:
            a, b = ABS_BOUNDS[d]
            band = float(self.o.theta_band.get(d, 0.5))
            centre = float(th_anchor[d]) if th_anchor and np.isfinite(th_anchor.get(d, np.nan)) else th_now[d]
            l, h = max(a, centre - band), min(b, centre + band)
            if th_prev is not None and d in th_prev:
                step = float(self.o.max_step.get(d, band))
                l, h = max(l, th_prev[d] - step), min(h, th_prev[d] + step)
            if l > h:
                l = h = float(np.clip(th_now[d], a, b))
            lo.append(l)
            hi.append(h)
        return np.array(lo), np.array(hi)

    @staticmethod
    def _coherence(free, theta):
        """Linear coherence constraints on the free dims (the others held at theta)."""
        idx = {d: i for i, d in enumerate(free)}

        def val(x, d):
            return x[idx[d]] if d in idx else theta[d]
        cons = []
        for tg, sup, ftg, fsup in (BLOCKS["goal"], BLOCKS["corner"]):
            if tg in idx or sup in idx:
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) - val(x, sup)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, sup=sup: val(x, tg) + val(x, sup)})
            if ftg in idx or fsup in idx:
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) - val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, f=ftg, s=fsup: val(x, f) + val(x, s)})
                cons.append({"type": "ineq", "fun": lambda x, tg=tg, f=ftg: val(x, tg) - val(x, f)})
        return cons

    def _per_pool(self, book: MatchBook, odds_star, T_star) -> List[dict]:
        out = []
        for p in np.unique(book.pool):
            m = book.pool == p
            now = float(np.nansum(book.demand[m] * book.risk[m] * (1 - book.odds_now[m] * book.p_true[m])))
            star = float(np.nansum(T_star[m] * book.risk[m] * (1 - odds_star[m] * book.p_true[m])))
            out.append({"pool": str(p), "turnover": float(np.nansum(book.demand[m])), "egm_board": now,
                        "egm_star": star, "lift": star - now})
        return sorted(out, key=lambda r: -r["lift"])

    # ------------------------------------------------------------ publish
    def quantize(self, book: MatchBook, decision: MatchDecision, theta_decimals: int = 2, weight_decimals: int = 2,
                 overround_tolerance: float = 0.005) -> Quantized:
        """theta* and the weightings at the engine's precision, every guard checked again.

        The free dimensions are rounded inside their trust band; a first-half dimension that is not free
        follows its full-match one again. A line whose rounded weightings move its overround by more than
        ``overround_tolerance`` (relative) or break the line ladder goes back to 1.0. The result is kept
        when it is feasible and scores at least HKJC's own theta rounded the same way; otherwise that is
        what is sent, without weightings."""
        th_now = repair_theta(book.theta_now)
        free = self._free_dims(book)
        lo, hi = self._bounds(free, th_now, None, book.theta_anchor)

        def rounded(theta, inside: bool) -> Dict[str, float]:
            out = {d: _round_to(theta.get(d, th_now[d]), theta_decimals) for d in DIMS}
            if inside:
                for d, l, h in zip(free, lo, hi):
                    out[d] = _round_into(theta.get(d, th_now[d]), l, h, theta_decimals)
            return repair_theta(self._follow(out, th_now))

        def scored_block(bk, theta, w):
            odds, _ = self.prices(bk, theta)
            odds = np.where(np.isfinite(odds), odds, bk.odds_now) * w
            T = self.demand_at(bk, odds)
            return odds, T, self.expected_gm(bk, odds, T)

        def scored(theta, w):
            return scored_block(book, theta, w)

        def toward_board(theta) -> Dict[str, float]:
            out = dict(theta)
            step = 10.0 ** -int(theta_decimals)
            for d in free:
                v = float(theta.get(d, th_now[d]))
                k = np.floor(v / step + 1e-9) if v >= th_now[d] else np.ceil(v / step - 1e-9)
                out[d] = _round_to(k * step, theta_decimals)
            return out

        def grid_corners(theta) -> List[Dict[str, float]]:
            """Every floor / ceil combination of the free dimensions: theta* usually sits on a guard, and the
            nearest grid point can land a hair outside it."""
            step = 10.0 ** -int(theta_decimals)
            if not free or len(free) > 5:
                return []
            out = []
            for bits in range(2 ** len(free)):
                th = dict(theta)
                for j, d in enumerate(free):
                    v = float(theta.get(d, th_now[d]))
                    k = np.ceil(v / step - 1e-9) if (bits >> j) & 1 else np.floor(v / step + 1e-9)
                    th[d] = _round_to(k * step, theta_decimals)
                out.append(th)
            return out

        board = rounded(th_now, inside=False)
        odds_b, T_b, egm_b = scored(board, np.ones(book.n))
        w0 = np.ones(book.n) if decision.weights is None else np.asarray(decision.weights, dtype="float64")
        w0 = np.round(np.where(np.isfinite(w0) & (w0 > 0), w0, 1.0), weight_decimals)
        options = [decision.theta_star, toward_board(decision.theta_star)] + grid_corners(decision.theta_star)
        theta, w, reset, moved = dict(board), np.ones(book.n), [], False

        def valid(bk, odds, floor) -> bool:
            # HKJC's own theta at the engine's precision can itself sit a hair past a guard (a main line just
            # over the best external price): a candidate may not be worse than that, not better than perfect
            return bool(np.all(np.isfinite(odds)) and self._violation(bk, odds) <= floor + 1e-6)
        # The goal and corner blocks share no dimension and no pool, so E[GM] and every guard split between
        # them: each block keeps its best valid rounding of theta*, or HKJC's own value when none is valid.
        for block, dims in BLOCKS.items():
            mask = np.isin(book.rows.theta_domain, [block, block + "_fh"])
            if not mask.any():
                continue
            sub = _sub_book(book, mask)
            wb0 = w0[mask]
            odds_k, _, keep = scored_block(sub, board, np.ones(sub.n))
            floor = self._violation(sub, odds_k)
            pick = (None, np.ones(sub.n), [], keep)
            # the nearest valid rounding: nearest first, then toward HKJC, then the other grid corners by distance
            cands, seen = [], []
            for raw in options:
                cand = rounded({**board, **{d: raw.get(d, board[d]) for d in dims}}, inside=True)
                key = tuple(cand[d] for d in dims)
                if key in seen or all(cand[d] == board[d] for d in dims):
                    continue
                seen.append(key)
                cands.append(cand)
            cands = cands[:2] + sorted(cands[2:], key=lambda c: sum(abs(c[d] - decision.theta_star.get(d, c[d]))
                                                                    for d in dims))
            for cand in cands:
                odds1, _ = self.prices(sub, cand)
                odds1 = np.where(np.isfinite(odds1), odds1, sub.odds_now)
                wb, rb = self._check_weights(sub, odds1, wb0, overround_tolerance)
                odds_a, _, egm_a = scored_block(sub, cand, wb)
                if valid(sub, odds_a, floor) and egm_a > keep + 1e-9:
                    pick = (cand, wb, rb, egm_a)
                    break
            if pick[0] is not None:
                for d in dims:
                    theta[d] = pick[0][d]
                w[mask] = pick[1]
                reset += pick[2]
                moved = True
            else:
                # HKJC's theta for this block; its weightings alone can still pay
                odds1, _ = self.prices(sub, board)
                odds1 = np.where(np.isfinite(odds1), odds1, sub.odds_now)
                wb, rb = self._check_weights(sub, odds1, wb0, overround_tolerance)
                reset += rb
                odds_a, _, egm_a = scored_block(sub, board, wb)
                if np.any(wb != 1.0) and valid(sub, odds_a, floor) and egm_a > keep + 1e-9:
                    w[mask] = wb
                    moved = True
        theta = repair_theta(self._follow(theta, th_now))
        if moved:
            odds_a, T_a, egm_a = scored(theta, w)
            if valid(book, odds_a, self._violation(book, odds_b)) and egm_a >= egm_b - 1e-9:
                return Quantized(theta, w, odds_a, T_a, egm_a, egm_b, "theta*", reset)
        return Quantized(board, np.ones(book.n), odds_b, T_b, egm_b, egm_b, "board", reset)

    def quantize_board(self, book: MatchBook, theta_decimals: int = 2,
                       hold: Optional[Dict[str, float]] = None) -> Quantized:
        """HKJC's theta at the engine's precision as it is (``hold``: the full-match values to hand back instead),
        no weightings and nothing searched: what shadow sends production and what a revert sends."""
        ref = repair_theta(book.theta_now)
        theta = repair_theta({**ref, **(hold or {})})
        board = repair_theta(self._follow({d: _round_to(theta[d], theta_decimals) for d in DIMS}, ref))
        odds, _ = self.prices(book, board)
        odds = np.where(np.isfinite(odds), odds, book.odds_now)
        T = self.demand_at(book, odds)
        egm = self.expected_gm(book, odds, T)
        return Quantized(board, np.ones(book.n), odds, T, egm, egm, "board", [])

    def _violation_rows(self, book: MatchBook, odds: np.ndarray) -> np.ndarray:
        """_violation per selection (its terms, not summed)."""
        o = self.o
        bad = ~np.isfinite(odds)
        od = np.where(bad, o.min_odds, odds)
        v = bad * 10.0 + np.maximum(o.min_odds - od, 0.0) ** 2 + np.maximum(od - o.max_odds, 0.0) ** 2 * 1e-4
        if o.prob_band and o.prob_band > 0:
            v = v + np.maximum(np.abs(1.0 / od - 1.0 / book.odds_now) - o.prob_band, 0.0) ** 2 * 100.0
        if o.market_cap:
            cap = np.where(np.isfinite(book.odds_mkt), np.maximum(book.odds_mkt, book.odds_now), np.inf)
            v = v + np.where(book.is_main, np.maximum(od - cap, 0.0), 0.0) ** 2 * 10.0
        return v

    def _check_weights(self, book: MatchBook, odds1: np.ndarray, w: np.ndarray,
                       tolerance: float) -> Tuple[np.ndarray, List[str]]:
        """Rounded weightings back to 1.0 on every line whose overround, ladder or price guards they break."""
        w = w.copy()
        lg = _line_groups(book)
        reset: List[str] = []

        def clear(i) -> bool:
            j = np.flatnonzero(lg == lg[i])
            if np.all(w[j] == 1.0):
                return False
            w[j] = 1.0
            reset.append("{} {:g}".format(book.pool[i], book.rows.line[i]) if np.isfinite(book.rows.line[i])
                         else str(book.pool[i]))
            return True
        limit = tolerance + float(getattr(self.o, "weighting_margin_band", 0.0))
        ladders = []
        for pool in np.unique(book.pool):
            rows = np.flatnonzero(book.pool == pool)
            pairs, _ = _ladder(_sub_book(book, book.pool == pool), odds1[rows])
            ladders += [(rows[a], rows[b]) for a, b in pairs]
        changed = True
        while changed:                                  # each pass clears a line or stops
            changed = False
            for g in np.unique(lg):
                j = np.flatnonzero(lg == g)
                if len(j) < 2 or np.all(w[j] == 1.0):
                    continue
                r1, rw = float(np.sum(1.0 / odds1[j])), float(np.sum(1.0 / (odds1[j] * w[j])))
                if not np.isfinite(rw) or abs(rw / r1 - 1.0) > limit:
                    changed = clear(j[0]) or changed
            for i in np.flatnonzero((self._violation_rows(book, odds1 * w) > 0) & (w != 1.0)):
                changed = clear(i) or changed
            for ia, ib in ladders:
                if odds1[ib] * w[ib] < odds1[ia] * w[ia] - 1e-12:
                    changed = clear(ia) | clear(ib) or changed
        return w, reset

    # --------------------------------------------------------------- card
    def optimize_card(self, books: Sequence[MatchBook], mode: str = "sweep",
                      budget_seconds: Optional[float] = None, workers: Optional[int] = None,
                      on_result=None, key: str = "match", executor=None,
                      first: Optional[set] = None, max_in_flight: Optional[int] = None) -> Dict[int, MatchDecision]:
        """Richest matches first (``first``: these match ids before the rest); stop starting new ones when
        the budget is spent.

        Returns {match_id: decision}, or {position in ``books``: decision} with
        key="index" (a backtest batch can hold several buckets of one match).
        ``executor``: a process pool the caller keeps (a new one per call costs seconds on Windows).
        ``max_in_flight``: at most this many matches queued on the pool at once, so another caller's solve
        (the fast lane's, on the same pool) never waits behind a whole card.
        """
        budget = self.o.budget_seconds if budget_seconds is None else budget_seconds
        early = set(first or ())
        order = sorted(range(len(books)), key=lambda i: (books[i].match_id not in early, -books[i].total_demand))
        n_workers = workers if workers is not None else (self.o.workers or min(max((os.cpu_count() or 2) - 1, 1), 8))
        if executor is not None:
            n_workers = max(n_workers, 2)
        started = time.time()
        out: Dict[int, MatchDecision] = {}

        def label(i):
            return i if key == "index" else books[i].match_id
        if n_workers <= 1 or len(order) <= 2:
            for i in order:
                if budget and time.time() - started > budget:
                    logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out), len(order))
                    break
                out[label(i)] = self.optimize_match(books[i], mode)
                if on_result:
                    on_result(books[i].match_id, out[label(i)])
            return out

        def solve(pool):
            waiting = list(order)
            cap = max(int(max_in_flight), 1) if max_in_flight else len(order)
            futures: Dict[object, int] = {}

            def top_up():
                while waiting and len(futures) < cap:
                    i = waiting.pop(0)
                    futures[pool.submit(_solve_one, self.settings, self.demand, books[i], mode, self.allowed)] = i
            try:
                top_up()
                while futures:
                    done, _ = wait(list(futures), return_when=FIRST_COMPLETED)
                    for fut in done:
                        i = futures.pop(fut)
                        try:
                            out[label(i)] = fut.result()
                        except BrokenProcessPool:
                            raise
                        except Exception as exc:                  # noqa: BLE001
                            logger.exception("match %s failed to optimise: %s", books[i].match_id, exc)
                            continue
                        if on_result:
                            on_result(books[i].match_id, out[label(i)])
                    if budget and time.time() - started > budget:
                        for f in futures:
                            f.cancel()
                        logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out),
                                       len(order))
                        break
                    top_up()
            except BrokenProcessPool as exc:
                # a worker died (out of memory, an access violation): the pool refuses every task from now on, so
                # the rest of the card is solved here; the caller replaces the pool before its next call
                logger.error("the solver pool broke (%s): solving the other %d match(es) in this process", exc,
                             len(order) - len(out))
                for f in futures:
                    f.cancel()
                for i in order:
                    if label(i) in out:
                        continue
                    if budget and time.time() - started > budget:
                        logger.warning("optimiser budget %.0fs spent after %d of %d matches", budget, len(out),
                                       len(order))
                        break
                    try:
                        out[label(i)] = self.optimize_match(books[i], mode)
                    except Exception as exc2:                     # noqa: BLE001
                        logger.exception("match %s failed to optimise: %s", books[i].match_id, exc2)
                        continue
                    if on_result:
                        on_result(books[i].match_id, out[label(i)])
        if executor is not None:
            solve(executor)
        else:
            with process_pool(n_workers) as pool:
                solve(pool)
        return out


def _solve_one(settings, demand, book, mode, free_dims=None):
    return ThetaOptimizer(settings, demand, free_dims).optimize_match(book, mode)


def _warm() -> int:
    """A first task for a new pool worker: it imports this module (and SciPy) before the first real solve."""
    return os.getpid()


def _sub_book(book: MatchBook, mask: np.ndarray) -> MatchBook:
    m = np.asarray(mask, dtype=bool)
    rows = BookRows(book.rows.theta_domain[m], book.rows.market[m], book.rows.line[m], book.rows.side[m])
    _, group = np.unique(book.group[m], return_inverse=True)

    def cut(a):
        return None if a is None else a[m]
    return MatchBook(book.match_id, rows, book.pool[m], group.astype(int), book.margin[m], book.demand[m],
                     book.p_true[m], book.p_ref[m], book.p_mkt[m], book.odds_now[m], book.odds_mkt[m],
                     book.is_main[m], book.state, book.theta_now, book.theta_prev, None, cut(book.p_now),
                     cut(book.risk), cut(book.w_prev), draw_factor=book.draw_factor, theta_anchor=book.theta_anchor,
                     theta_source=book.theta_source, far=book.far, received=cut(book.received))


def _group_sum(values: np.ndarray, group: np.ndarray) -> np.ndarray:
    s = np.bincount(group, weights=np.nan_to_num(values), minlength=int(group.max()) + 1 if len(group) else 0)
    return s[group]


def _line_groups(book: MatchBook) -> np.ndarray:
    """Index of (pool, line) per row, cached on the book."""
    if book.line_group is None or len(book.line_group) != book.n:
        lines = np.where(np.isfinite(book.rows.line), np.round(book.rows.line * 4.0) / 4.0, -999.0)
        key = np.char.add(np.char.add(book.pool.astype(str), "|"), lines.astype(str))
        book.line_group = np.unique(key, return_inverse=True)[1].astype(int).reshape(-1)
    return book.line_group


def _refit_overround(odds1: np.ndarray, w: np.ndarray, lg: np.ndarray, fixed: np.ndarray) -> np.ndarray:
    """Weightings set on the last prices, rescaled in implied-probability space so each line adds up to its
    overround on these: the tilt between a line's sides stays."""
    out = np.asarray(w, dtype="float64").copy()
    o = np.asarray(odds1, dtype="float64")
    ok = ~fixed & np.isfinite(o) & (o > 0) & np.isfinite(out) & (out > 0)
    for g in np.unique(lg[ok]):
        j = np.flatnonzero((lg == g) & ok)
        if len(j) < 2:
            continue
        r1, s = float(np.sum(1.0 / o[j])), float(np.sum(1.0 / (o[j] * out[j])))
        if r1 > 0 and s > 0:
            out[j] = out[j] * s / r1
    return out


def _toward(odds1: np.ndarray, x0: np.ndarray, x1: np.ndarray, alpha: float, lg: np.ndarray) -> np.ndarray:
    """``alpha`` of the way from weightings x0 to x1, in implied-probability space: where both add up to a line's
    overround, so does the step, and an arbitrage-free ladder both keep, it keeps."""
    o = np.asarray(odds1, dtype="float64")
    x0, x1 = np.asarray(x0, dtype="float64"), np.asarray(x1, dtype="float64")
    out = x1.copy()
    ok = np.isfinite(o) & (o > 0) & (x0 > 0) & (x1 > 0)
    u0, u1 = 1.0 / (o[ok] * x0[ok]), 1.0 / (o[ok] * x1[ok])
    out[ok] = 1.0 / (o[ok] * (u0 + float(alpha) * (u1 - u0)))
    return out


def _ladder(book: MatchBook, odds: np.ndarray) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    """For one pool's rows: pairs (a, b) that must keep O_a <= O_b for the ladder of lines to stay free of
    arbitrage - an over is never shorter than the over of a lower line, an under never longer; for a
    home handicap h the home side shortens as h grows, the away side lengthens - kept only where the
    stage-1 prices already obey them; and neighbour pairs (same side, adjacent lines)."""
    order, neighbours = [], []
    lines, sides, markets = book.rows.line, book.rows.side.astype(str), book.rows.market.astype(str)
    for side in np.unique(sides):
        idx = np.flatnonzero((sides == side) & np.isfinite(lines))
        if len(idx) < 2:
            continue
        idx = idx[np.argsort(lines[idx], kind="mergesort")]
        rising = (side == "H") if markets[idx[0]] != "handicap" else (side != "H")
        for a, b in zip(idx[:-1], idx[1:]):
            if lines[a] >= lines[b]:
                continue
            neighbours.append((int(a), int(b)))
            lo, hi = (a, b) if rising else (b, a)          # the price that must be the shorter one first
            if np.isfinite(odds[lo]) and np.isfinite(odds[hi]) and odds[lo] <= odds[hi] + 1e-12:
                order.append((int(lo), int(hi)))
    return order, neighbours


def _has_params(row) -> Dict[str, bool]:
    """Whether HKJC's TG and SUP are known for the goal and the corner block of a match row."""
    def ok(*cols):
        vals = [pd.to_numeric(row.get(c), errors="coerce") for c in cols]
        return all(v is not None and np.isfinite(v) for v in vals)
    return {"goal": ok("tg", "sup"), "corner": ok("ctg", "csup")}


def desk_weightings(book: MatchBook, decision: "MatchDecision", pricer: Optional[BookPricer] = None) -> np.ndarray:
    """The decision's prices in the desk's terms: O / (fair(theta*) / (1 + margin)) per selection."""
    if decision is None or decision.odds_star is None:
        return np.full(book.n, np.nan)
    pricer = pricer or BookPricer(Conventions(draw_factor=float(getattr(book, "draw_factor", 1.0) or 1.0)))
    p, _ = pricer.probabilities(book.rows, repair_theta(decision.theta_star), book.state)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(p > 0, decision.odds_star * p * (1.0 + book.margin), np.nan)


def _round_to(value: float, decimals: int) -> float:
    return round(float(value), int(decimals)) + 0.0


def _round_into(value: float, lo: float, hi: float, decimals: int) -> float:
    """``value`` on the engine's grid without leaving [lo, hi]; a band narrower than a step keeps the
    rounded value nearest to it."""
    step = 10.0 ** -int(decimals)
    r = _round_to(value, decimals)
    if r > hi + 1e-12:
        r = _round_to(np.floor(hi / step + 1e-9) * step, decimals)
    if r < lo - 1e-12:
        r = _round_to(np.ceil(lo / step - 1e-9) * step, decimals)
    return r


def anchor_theta(layer: str, theta_now: Dict[str, float], params: Optional[dict], first_seen: Optional[dict],
                 state: MatchState, splits: Tuple[float, float]) -> Optional[Dict[str, float]]:
    """The theta the trust band is drawn around for ``layer`` (settings.optimizer.anchor_layer), or None for
    HKJC's posted theta (theta_now).

    basis / model read that layer from the match's newest algo_param row (``params``, raw column names); a
    layer is a full-match value, so in play it is scaled to the clock ((90 - minute) / 90). first_seen is
    {"theta", "minute"} from the last refresh before Algo E's first message, scaled from its minute to now.
    The first half follows from the full match as theta_from_params derives it."""
    if layer == "current":
        return None
    m = float(state.minute or 0.0) if state.in_play else 0.0
    if layer in ("basis", "model"):
        name = "Basis" if layer == "basis" else "Model"
        vals = [pd.to_numeric((params or {}).get(c), errors="coerce") for c in
                ("Goal90{}TG".format(name), "Goal90{}SUP".format(name), "Corner90{}TG".format(name),
                 "Corner90{}SUP".format(name))]
        if not all(v is not None and np.isfinite(v) for v in vals):
            return None
        scale = max(90.0 - m, 0.0) / 90.0
    elif layer == "first_seen":
        if not first_seen or not first_seen.get("theta"):
            return None
        t = first_seen["theta"]
        vals = [t.get(d) for d in ("goal_tg", "goal_sup", "corner_tg", "corner_sup")]
        m0 = float(first_seen.get("minute") or 0.0)
        scale = max(90.0 - m, 0.0) / max(90.0 - m0, 1.0)
    else:
        raise ValueError("anchor_layer must be current | basis | model | first_seen, got {!r}".format(layer))
    tg, sup, ctg, csup = (float(v) * scale for v in vals)
    return repair_theta(theta_from_params(tg, sup, ctg, csup, splits[0], splits[1], state))


def _grid(score, x0, lo, hi, steps: int = 9):
    best, best_f = x0.copy(), score(x0)
    span = (hi - lo) / 4.0
    for _ in range(3):
        axes = [np.linspace(max(b - s, l), min(b + s, h), steps) for b, s, l, h in zip(best, span, lo, hi)]
        for pt in np.array(np.meshgrid(*axes)).T.reshape(-1, len(x0)):
            f = score(pt)
            if f < best_f:
                best, best_f = pt.copy(), f
        span /= 3.0
    return best, best_f


# ======================================================= books from rows
def build_books(sel: pd.DataFrame, match: pd.DataFrame, demand: np.ndarray, p_true: np.ndarray,
                settings, taxonomy=None, theta_prev: Optional[Dict[int, Dict[str, float]]] = None,
                weights_prev: Optional[Dict[int, Dict[tuple, float]]] = None,
                stats: Optional[Dict[str, int]] = None, draw_factors: Optional[Dict[int, float]] = None,
                anchors: Optional[Dict[int, Dict[str, float]]] = None, on_sale: bool = False,
                prematch_max_age: Optional[float] = None, implied: bool = False,
                received: Optional[np.ndarray] = None, chain_weights: bool = False,
                notes: Optional[Dict[int, str]] = None) -> List[MatchBook]:
    """MatchBooks for ONE bucket from feature-engineer rows (sel) and match rows.

    ``demand`` and ``p_true`` are aligned to ``sel``. Rows are kept when the
    pool is in scope and priceable, the price is live, and both a belief and
    a demand exist. ``draw_factors`` (publishing) prices a match's goals with its
    own draw factor; ``anchors`` centres its trust band away from theta_now.

    The live desk solves every match on sale: ``on_sale`` keeps selling rows outside the model window too
    (their match has no match row; its context comes from its own rows), ``prematch_max_age`` replaces
    optimizer.max_odds_age_prematch_min (0 = no limit: the live feed drops deleted lines itself) and
    ``implied`` prices a block without HKJC's TG/SUP at the theta implied by the board (implied_theta).
    ``received`` (aligned to ``sel``) is the money already in the bucket, for stage 2's liability term.
    ``chain_weights`` (the live desk) starts a match without last weightings from 1, so its stage 2 is damped
    from its first decision; without it (the backtests) a book with no last weightings starts from 1 unchained:
    no step cap or partial adjustment, while the deadband and the market guard still apply.
    ``notes`` collects, per match, why a block was left out (no TG/SUP row, and no implied fit).
    """
    from ..pricing.implied_theta import implied_theta
    from ..pricing.panel_pricing import hkjc_theta, state_of
    o = settings.optimizer
    s = sel.copy()
    s["_demand"] = np.asarray(demand, dtype="float64")
    s["_p"] = np.asarray(p_true, dtype="float64")
    s["_received"] = np.asarray(received, dtype="float64") if received is not None else np.nan
    inplay = s["inplay"].fillna(0).to_numpy(dtype="float64") > 0 if "inplay" in s.columns else np.zeros(len(s), bool)
    age = np.expm1(s["log_odds_age"].to_numpy(dtype="float64")) if "log_odds_age" in s.columns else np.zeros(len(s))
    pre_age = getattr(o, "max_odds_age_prematch_min", 90.0) if prematch_max_age is None else float(prematch_max_age)
    max_age = np.where(inplay, getattr(o, "max_odds_age_inplay_min", 10.0), pre_age if pre_age > 0 else np.inf)
    names = s["pool_name"].astype(str).str.upper()
    in_scope = set(resolve_pools(o.pools, names.unique(), taxonomy or default_taxonomy()))
    rows_ok = s["selling"] if on_sale and "selling" in s.columns else s["forecastable"]
    far_row = (rows_ok.fillna(False).to_numpy(dtype=bool) & ~s["forecastable"].fillna(False).to_numpy(dtype=bool)) \
        if on_sale else np.zeros(len(s), dtype=bool)
    s["_far"] = far_row
    keep = (names.isin(in_scope).to_numpy()
            & rows_ok.fillna(False).to_numpy(dtype=bool)
            & s["market"].isin(list(ASIAN)).to_numpy()
            & np.isfinite(s["odds"].to_numpy(dtype="float64")) & (s["odds"].to_numpy(dtype="float64") > 1.0)
            & np.isfinite(s["_p"].to_numpy()) & (s["_p"].to_numpy() > 0) & (s["_p"].to_numpy() < 1)
            & np.isfinite(s["line"].to_numpy(dtype="float64"))
            & (age <= max_age))
    s = s[keep]
    if s.empty:
        return []
    ctx_cols = [c for c in ("match_id", "bucket", "tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh",
                            "phase", "minute", "home_goals", "away_goals", "home_corners", "away_corners")
                if c in match.columns]
    ctx = match[ctx_cols].drop_duplicates(["match_id", "bucket"]).set_index(["match_id", "bucket"])
    pricer = BookPricer(Conventions(o.settle_total, o.settle_handicap))
    books = []
    for (mid, b), g in s.groupby(["match_id", "bucket"], sort=False):
        if (mid, b) in ctx.index:
            r = ctx.loc[(mid, b)].to_dict()
        elif on_sale and bool(g["_far"].all()):
            r = _context_from_rows(g)
        else:
            continue
        # Without HKJC's own TG / SUP for a block, theta would be a default (TG 2.6 / SUP 0, corners 9.6):
        # optimising around a theta HKJC never posted means nothing, so the block is left alone - unless the
        # caller asks for the theta the board itself implies.
        has = _has_params(r)
        st = state_of(r)
        source = {blk: "hkjc" for blk in ("goal", "corner") if has[blk]}
        dom = g["theta_domain"].astype(str)
        if implied:
            for blk, (tg_col, sup_col) in (("goal", ("tg", "sup")), ("corner", ("ctg", "csup"))):
                if has[blk] or not dom.str.startswith(blk).any():
                    continue
                rows_b = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(),
                                  g["line"].to_numpy(dtype="float64"), g["side"].to_numpy())
                fit = implied_theta(rows_b, g["odds"].to_numpy(dtype="float64"), blk, st)
                if fit is not None:
                    r[tg_col], r[sup_col] = fit[0], fit[1]
                    has[blk], source[blk] = True, "implied"
        known = np.where(dom.str.startswith("corner"), has["corner"], has["goal"])
        if not known.all():
            missing = [blk for blk in ("goal", "corner") if not has[blk] and dom.str.startswith(blk).any()]
            if stats is not None:
                for block in missing:
                    stats["no_params_" + block] = stats.get("no_params_" + block, 0) + 1
            if notes is not None:
                notes[int(mid)] = "no HKJC TG/SUP for {}{}".format(
                    " or ".join(missing), " and no implied fit from the board's prices" if implied else "")
            g = g[known]
            if g.empty:
                continue
        th = hkjc_theta(r, st)
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        df = float((draw_factors or {}).get(int(mid), 1.0) or 1.0)
        if not np.isfinite(df) or df <= 0:
            df = 1.0
        mp = pricer if df == 1.0 else BookPricer(replace(pricer.conv, draw_factor=df))
        p_now, risk = mp.probabilities(rows, repair_theta(th), st)
        ok = np.isfinite(p_now) & (p_now > 1e-6)
        if not ok.any():
            continue
        g = g[ok]
        rows = BookRows(g["theta_domain"].to_numpy(), g["market"].to_numpy(), g["line"].to_numpy(dtype="float64"),
                        g["side"].to_numpy())
        pools = g["pool_name"].astype(str).to_numpy()
        _, group = np.unique(pools, return_inverse=True)
        margin = np.array([settings.margin_for(p) for p in pools])
        wp = (weights_prev or {}).get(int(mid))
        if not wp and chain_weights:
            wp = {}
        w_prev = None if wp is None or (not wp and not chain_weights) else np.array(
            [wp.get((int(a), int(b), int(c)), 1.0) for a, b, c in zip(g["pool_id"], g["line_id"], g["combination_id"])],
            dtype="float64")
        books.append(MatchBook(
            match_id=int(mid), rows=rows, pool=pools, group=group.astype(int), margin=margin,
            demand=np.clip(g["_demand"].to_numpy(dtype="float64"), 0, None), p_true=g["_p"].to_numpy(dtype="float64"),
            p_ref=g["p_hkjc_true"].to_numpy(dtype="float64") if "p_hkjc_true" in g.columns else np.full(len(g), np.nan),
            p_mkt=g["p_market"].to_numpy(dtype="float64") if "p_market" in g.columns else np.full(len(g), np.nan),
            odds_now=g["odds"].to_numpy(dtype="float64"),
            odds_mkt=g["mkt_odds"].to_numpy(dtype="float64") if "mkt_odds" in g.columns else np.full(len(g), np.nan),
            is_main=(g["rank_0"].to_numpy(dtype="float64") > 0) if "rank_0" in g.columns else np.ones(len(g), bool),
            state=st, theta_now=th, theta_prev=(theta_prev or {}).get(int(mid)),
            keys=g[["pool_id", "line_id", "combination_id", "match_id", "pool_name", "bucket"]].reset_index(drop=True),
            p_now=p_now[ok], risk=risk[ok], w_prev=w_prev, draw_factor=df,
            theta_anchor=(anchors or {}).get(int(mid)), theta_source=source, far=bool(g["_far"].any()),
            received=np.nan_to_num(g["_received"].to_numpy(dtype="float64")) if received is not None else None))
    return books


CONTEXT_COLS = ("tg", "sup", "ctg", "csup", "goal_split_fh", "corner_split_fh")


def _context_from_rows(g: pd.DataFrame) -> dict:
    """A pre-match match outside the model window has no match row (the feature engineer builds those for
    the model's rows only); its selection rows carry the same TG/SUP and splits, and before kick-off the
    score and the clock are nil."""
    first = g.iloc[0]
    r = {c: first.get(c, np.nan) for c in CONTEXT_COLS}
    r.update(match_id=first["match_id"], bucket=first["bucket"], phase="prematch", minute=0.0,
             home_goals=0, away_goals=0, home_corners=0, away_corners=0)
    return r


def weights_by_key(keys: Optional[pd.DataFrame], weights: Optional[np.ndarray]) -> Dict[tuple, float]:
    """{(pool, line, combination): weighting} for a book's rows."""
    if keys is None or weights is None:
        return {}
    return {(int(a), int(b), int(c)): float(w) for a, b, c, w in zip(keys["pool_id"], keys["line_id"],
                                                                     keys["combination_id"], weights)}


def weight_churn(prev: Optional[Dict[tuple, float]], now: Optional[Dict[tuple, float]]) -> float:
    """The mean change of the weightings two decisions share; NaN without a previous decision."""
    common = [k for k in (now or {}) if k in (prev or {})]
    if not common:
        return float("nan")
    return float(np.mean([abs(now[k] - prev[k]) for k in common]))


def publish_odds(odds: np.ndarray) -> np.ndarray:
    """The ladder-rounded prices a trader would actually post."""
    return np.array([ladder(float(o)) if np.isfinite(o) else np.nan for o in odds])
