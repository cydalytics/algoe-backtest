"""
Model Store

Every trained bundle is written once and never edited:

    <work>/models/<kind>/<version>/bundle.pkl       estimators, encoders, blend weights
    <work>/models/<kind>/<version>/metadata.json    window, split, features, metrics, settings, sha1
    <work>/models/<kind>/CHAMPION.json              which version the live engine loads
    <work>/models/<kind>/history.jsonl              every promotion, with its reason

A version is promoted only if it beats the current champion AND the naive
baseline on the same held-out days (``promote_if_better``). Rolling back is
``promote(old_version, reason)``. The sha1 in metadata is checked on load,
so a bundle copied half-way or edited by hand is refused rather than served.

Every bundle records the feature version it was trained on. A model is only
valid with the feature code that produced its inputs, so load() refuses a
version mismatch (retrain instead), and a champion on another feature version
cannot block a promotion - its stored score was measured on different inputs.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      feature_version stamped on save, checked on load and promotion; incumbent re-scored
                on the candidate's days
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import List, Optional, Tuple

from ..core.exceptions import RegistryError
from ..core.io import file_sha1, read_json, read_pickle, write_json, write_pickle
from ..core.logging import get_logger

logger = get_logger(__name__)


class ModelStore:
    def __init__(self, root, kind: str, feature_version: Optional[int] = None):
        self.kind = kind
        self.feature_version = feature_version
        self.root = Path(root) / kind
        self.root.mkdir(parents=True, exist_ok=True)

    def new_version(self, tag: str = "") -> str:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        return "{}{}".format(stamp, "-" + tag if tag else "")

    def save(self, version: str, bundle: dict, metadata: dict) -> Path:
        folder = self.root / version
        folder.mkdir(parents=True, exist_ok=True)
        path = write_pickle(bundle, folder / "bundle.pkl")
        meta = dict(metadata)
        meta.update(version=version, kind=self.kind, saved_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
                    sha1=file_sha1(path), feature_version=self.feature_version)
        write_json(meta, folder / "metadata.json")
        logger.info("saved %s model %s (%s)", self.kind, version, folder)
        return folder

    def load(self, version: Optional[str] = None) -> Tuple[dict, dict]:
        version = version or self.champion()
        if not version:
            raise RegistryError("no {} champion yet; train one first (scripts/s04 / s05)".format(self.kind))
        folder = self.root / version
        meta = read_json(folder / "metadata.json")
        if meta is None:
            raise RegistryError("{} {} has no metadata.json".format(self.kind, version))
        path = folder / "bundle.pkl"
        if not path.exists():
            raise RegistryError("{} {} has no bundle.pkl".format(self.kind, version))
        if meta.get("sha1") and file_sha1(path) != meta["sha1"]:
            raise RegistryError("{} {} bundle.pkl does not match its checksum; refusing to load".format(
                self.kind, version))
        if self.feature_version is not None and meta.get("feature_version") != self.feature_version:
            raise RegistryError("{} {} was trained on feature version {} but the code builds version {}; "
                                "its inputs would be wrong - retrain it (scripts/s04 / s05)".format(
                                    self.kind, version, meta.get("feature_version"), self.feature_version))
        return read_pickle(path), meta

    def champion(self) -> Optional[str]:
        c = read_json(self.root / "CHAMPION.json")
        return c.get("version") if c else None

    def promote(self, version: str, reason: str, metrics: Optional[dict] = None) -> None:
        if not (self.root / version / "bundle.pkl").exists():
            raise RegistryError("cannot promote {} {}: not in the store".format(self.kind, version))
        prev = self.champion()
        entry = {"version": version, "previous": prev, "reason": reason, "metrics": metrics or {},
                 "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        write_json(entry, self.root / "CHAMPION.json")
        with (self.root / "history.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, default=str) + "\n")
        logger.info("promoted %s %s (was %s): %s", self.kind, version, prev, reason)

    def promote_if_better(self, version: str, metric: str, value: float, baseline: float,
                          lower_is_better: bool = True, versus: Optional[Tuple[float, float]] = None) -> bool:
        """Promote when ``value`` beats the baseline and the current champion.

        ``versus`` = (this version, the champion) scored on days neither was fitted on - the only
        fair comparison once the window rolls and the champion has been refitted on newer days.
        Without it the champion's stored score is used, and only if it was measured on the
        same days."""
        better = (value < baseline) if lower_is_better else (value > baseline)
        if not better:
            logger.warning("%s %s not promoted: %s %.6g does not beat the baseline %.6g",
                           self.kind, version, metric, value, baseline)
            return False
        champ = self.champion()
        if champ and versus is not None and champ != version:
            mine, theirs = versus
            if (lower_is_better and mine >= theirs) or (not lower_is_better and mine <= theirs):
                logger.warning("%s %s not promoted: %s %.6g vs champion %s %.6g on days neither was fitted on",
                               self.kind, version, metric, mine, champ, theirs)
                return False
        elif champ:
            meta = read_json(self.root / champ / "metadata.json") or {}
            mine = read_json(self.root / version / "metadata.json") or {}
            old = (meta.get("selection") or {}).get(metric)
            same_days = (meta.get("selection") or {}).get("days") == (mine.get("selection") or {}).get("days")
            same_features = meta.get("feature_version") == mine.get("feature_version")
            if not same_features:
                logger.warning("%s champion %s is on feature version %s, %s on %s: the old score is not "
                               "comparable and the old model cannot be served, so it is replaced",
                               self.kind, champ, meta.get("feature_version"), version,
                               mine.get("feature_version"))
            elif old is not None and same_days:
                if (lower_is_better and value >= old) or (not lower_is_better and value <= old):
                    logger.warning("%s %s not promoted: %s %.6g does not beat champion %s (%.6g)",
                                   self.kind, version, metric, value, champ, old)
                    return False
        self.promote(version, "{} {:.6g} vs baseline {:.6g}".format(metric, value, baseline),
                     {metric: value, "baseline": baseline})
        return True

    def list(self) -> List[dict]:
        out = []
        for folder in sorted(self.root.iterdir()) if self.root.exists() else []:
            meta = read_json(folder / "metadata.json") if folder.is_dir() else None
            if meta:
                out.append({k: meta.get(k) for k in ("version", "saved_at", "champion_pipeline",
                                                     "window", "selection")})
        return out
