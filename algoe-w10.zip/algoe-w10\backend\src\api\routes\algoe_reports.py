"""
Algo E Report Routes - the W10 backtest reports on the desk's Backtest tab

    GET /api/algoe/reports      every backtest_* folder under AlgoE_Work/reports, newest first, with the
                                sections each one holds and the models that made it
    GET /api/algoe/report       one report: the newest copy of every section across those folders, so a full
                                run and a later `--only events` run read as one; ?ids=a,b picks the folders

Both take ?work= for another AlgoE_Work folder. Without it the folder is the command line's
(ALGOE_SETTINGS / ALGOE_DATA_DIR / ALGOE_WORK_DIR): what algoe-3-backtest.bat wrote is what the tab shows.
Reports are read from disk, never recomputed here.

Change Log:
-----------
2026-10-12      Initialize
"""

import json
import math
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from fastapi import APIRouter, HTTPException, Query

router = APIRouter()

_lock = threading.Lock()
_cache: Dict[Tuple[str, float], dict] = {}            # (report.json path, mtime) -> parsed, cleaned


def _clean(obj):
    """JSON a browser can parse: NaN and inf to null, numpy scalars to Python."""
    if isinstance(obj, dict):
        return {str(k): _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        try:
            return _clean(obj.item())
        except (ValueError, AttributeError):
            return str(obj)
    return obj


def _work(work: Optional[str]) -> Path:
    if work:
        p = Path(work).expanduser()
        if not p.is_dir():
            raise HTTPException(404, "no folder {}".format(p))
        return p
    try:
        from algoe.settings import Settings
        return Path(Settings.load().paths.work)
    except Exception as exc:                                   # noqa: BLE001
        raise HTTPException(500, "cannot resolve the AlgoE_Work folder from the settings: {}".format(exc))


def _read(path: Path) -> dict:
    key = (str(path), path.stat().st_mtime)
    with _lock:
        hit = _cache.get(key)
    if hit is not None:
        return hit
    data = _clean(json.loads(path.read_text(encoding="utf-8")))
    meta = data.get("meta") or {}
    window = ((meta.get("settings") or {}).get("window")) or {}
    data["meta"] = {k: v for k, v in meta.items() if k != "settings"}
    data["meta"]["window"] = window
    with _lock:
        for k in [k for k in _cache if k[0] == str(path)]:
            _cache.pop(k, None)
        _cache[key] = data
    return data


SECTION_ORDER = ("turnover", "feature_groups", "trueprob", "gm", "optimizer", "replication", "drift", "events",
                 "elasticity", "mix")


def _sections(data: dict) -> List[str]:
    return [k for k in SECTION_ORDER if data.get(k)]


def _folders(root: Path) -> List[Path]:
    rep = root / "reports"
    if not rep.is_dir():
        return []
    out = [p for p in rep.iterdir() if p.is_dir() and p.name.startswith("backtest_") and (p / "report.json").exists()]
    return sorted(out, key=lambda p: (p / "report.json").stat().st_mtime, reverse=True)


def _row(p: Path) -> dict:
    data = _read(p / "report.json")
    meta = data.get("meta") or {}
    t = data.get("turnover") or {}
    mx = data.get("mix") or {}
    days = t.get("days") or mx.get("test_days") or []
    return {"id": p.name, "generated": meta.get("generated"), "seconds": meta.get("seconds"),
            "turnover_model": meta.get("turnover_model"), "probability_model": meta.get("probability_model"),
            "sections": _sections(data), "test_days": len(days),
            "first_day": days[0] if days else None, "last_day": days[-1] if days else None,
            "size": (p / "report.json").stat().st_size}


@router.get("/algoe/reports")
def reports(work: Optional[str] = Query(None, description="an AlgoE_Work folder; default from the settings")):
    root = _work(work)
    rows = []
    for p in _folders(root):
        try:
            rows.append(_row(p))
        except (OSError, ValueError) as exc:
            rows.append({"id": p.name, "error": str(exc), "sections": []})
    return {"work": str(root), "reports_dir": str(root / "reports"), "exists": (root / "reports").is_dir(),
            "reports": rows}


@router.get("/algoe/report")
def report(ids: Optional[str] = Query(None, description="comma-separated report folders; default every folder"),
           work: Optional[str] = Query(None)):
    root = _work(work)
    folders = _folders(root)
    if ids:
        want = [x.strip() for x in ids.split(",") if x.strip()]
        by_name = {p.name: p for p in folders}
        missing = [x for x in want if x not in by_name]
        if missing:
            raise HTTPException(404, "no report {} under {}".format(", ".join(missing), root / "reports"))
        folders = sorted((by_name[x] for x in want), key=lambda p: (p / "report.json").stat().st_mtime, reverse=True)
    if not folders:
        raise HTTPException(404, "no backtest report under {} - run algoe-3-backtest.bat".format(root / "reports"))
    merged: Dict[str, object] = {}
    source: Dict[str, str] = {}
    metas: Dict[str, dict] = {}
    for p in folders:                                           # newest first: the first copy of a section wins
        data = _read(p / "report.json")
        metas[p.name] = data.get("meta") or {}
        for k in _sections(data):
            if k not in merged:
                merged[k] = data[k]
                source[k] = p.name
    used = sorted(set(source.values()), key=lambda x: [p.name for p in folders].index(x))
    models = {x: metas[x].get("turnover_model") for x in used}
    return {"work": str(root), "ids": used, "source": source, "models": models,
            "meta": {x: metas[x] for x in used}, "sections": merged,
            "mixed_models": len({m for m in models.values() if m}) > 1}
