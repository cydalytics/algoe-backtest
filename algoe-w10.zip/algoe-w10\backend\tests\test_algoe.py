"""
Algo E unit tests - fast, no Raw_Data, no SQL, no network

    python tests/test_algoe.py              plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_algoe.py    the same checks under pytest
    set ALGOE_SLOW=1                        also run the whole selftest (about two minutes)

Each test guards one behaviour the desk depends on:

    pricer            our score-grid pricer == legacy poisson_betting; quarter lines settle half
    estimators        the GLM recovers known Poisson rates; every bundle survives save / load
    unknowns          an unseen pool key encodes at its parent; an unseen pool code is placed by rule
    pools / splits    panel pools by market rule (a new line market joins by itself); a date split
                      keeps train < val < test with no day in two roles
    validation        sentinel odds become null, negative money clips, missing names fill, duplicates count;
                      a pool closing exactly at a bucket start is off the board for that bucket
    nowcast           the rest-of-bucket forecast moves with the money already in
    settings          a typo in a key or an impossible value is refused, not silently ignored
    model store       a tampered bundle, or one built on other features, is never served
    monitor           PSI is ~0 on the training distribution even for a zero-inflated feature
    leakage           a goal after the bucket start does not change that bucket's goal pulse
    cli               every command parses

Change Log:
-----------
2026-10-01      Initialize
"""

import os
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


# ------------------------------------------------------------------- pricer
def test_pricer_matches_legacy():
    from src.backtest.parquet import poisson_betting as pb
    from algoe.pricing.pricer import marginals, score_grid, two_way
    for tg, sup in ((1.4, -0.9), (2.6, 0.0), (3.4, 0.7)):
        m = marginals(score_grid(tg, sup, 10))
        for line in (1.5, 2.25, 2.5, 2.75, 3.0):
            ours = float(two_way(m.total_values, m.total_probs, line)[0][0])
            assert abs(ours - 1.0 / pb.calculate_over_under_odds(tg, sup, line)["Over"]) < 1e-9
        for h in (-1.25, -0.5, 0.0, 0.25, 0.75):
            ours = float(two_way(m.diff_values, m.diff_probs, -h)[0][0])
            assert abs(ours - 1.0 / pb.calculate_asian_handicap_odds(tg, sup, h)["Home"]) < 1e-9


def test_quarter_lines_settle_half():
    from algoe.pricing.pricer import settle_matrix, two_way
    r = settle_matrix(np.array([2.0, 3.0]), np.array([2.25, 2.75]))
    assert r[0].tolist() == [-0.5, 1.0]       # over 2.25: two goals lose half, three win
    assert r[1].tolist() == [-1.0, 0.5]       # over 2.75: two lose, three win half
    p1, p2, at_risk = two_way(np.array([2.0, 3.0]), np.array([0.0, 1.0]), 2.25)
    assert abs(p1[0] - 1.0) < 1e-12 and abs(p2[0]) < 1e-12


# --------------------------------------------------------------- estimators
def _poisson_data(n=20000, seed=3):
    rng = np.random.default_rng(seed)
    x = rng.normal(size=n)
    y = rng.poisson(np.exp(0.5 + 0.8 * x))
    return pd.DataFrame({"x": x}), y.astype("float64")


def test_glm_recovers_poisson_rates():
    from algoe.models.estimators import GLMEstimator
    X, y = _poisson_data()
    m = GLMEstimator("poisson", ridge=1e-8).fit(X, y)
    grid = pd.DataFrame({"x": [-1.0, 0.0, 1.0]})
    truth = np.exp(0.5 + 0.8 * grid["x"].to_numpy())
    assert np.all(np.abs(m.predict(grid) / truth - 1.0) < 0.05)


def test_estimator_state_round_trip():
    from algoe.models.estimators import GAMEstimator, GLMEstimator, load_estimator
    X, y = _poisson_data(6000)
    grid = pd.DataFrame({"x": np.linspace(-2, 2, 9)})
    for est in (GLMEstimator("poisson", ridge=1e-6), GAMEstimator("poisson", n_knots=6, lambdas=(1.0,))):
        est.fit(X, y)
        again = load_estimator(est.to_state())
        assert np.allclose(est.predict(grid), again.predict(grid))


# ----------------------------------------------------------------- unknowns
def test_encoder_unknown_falls_to_parent():
    from algoe.features.encoders import LevelEncoder
    train = pd.DataFrame({"pool_key": ["A|pre"] * 50 + ["B|pre"] * 50 + ["C|live"] * 50,
                          "family_phase": ["goal|pre"] * 100 + ["goal|live"] * 50,
                          "t": [1.0] * 50 + [3.0] * 50 + [10.0] * 50})
    enc = LevelEncoder("pool_key", ("family_phase",), prior=10.0).fit(train, "t")
    test = pd.DataFrame({"pool_key": ["A|pre", "Z|pre", "Z|nowhere"],
                         "family_phase": ["goal|pre", "goal|pre", "corner|nowhere"]})
    level, known = enc.transform(test)
    parent = enc.tables["family_phase"]["goal|pre"] - enc.global_mean
    assert known.tolist() == [1.0, 0.0, 0.0]
    assert abs(level[1] - parent) < 1e-12          # unseen key: its family level
    assert abs(level[2]) < 1e-12                   # unseen everything: the global level


def test_taxonomy_places_unknown_codes():
    from algoe.core.taxonomy import PoolTaxonomy
    tax = PoolTaxonomy()
    known = tax.resolve("HILO")
    new = tax.resolve("NHILO")
    assert "HILO" not in tax.inferred_codes()
    assert "NHILO" in tax.inferred_codes()
    assert new.family == known.family and new.priceable
    odd = tax.resolve("ZZ9")                        # nonsense must not raise
    assert isinstance(odd.priceable, bool)


def test_pool_rules_select_by_market():
    from algoe.core.taxonomy import PoolTaxonomy, resolve_pools
    tax = PoolTaxonomy()
    codes = ["HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "CRS", "TTG", "AGS", "NTS3", "NHILO"]
    lines = resolve_pools(["@line_markets", "@three_way"], codes, tax)
    assert set(lines) == {"HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "NHILO"}   # a new total joins by itself
    assert set(resolve_pools(["HILO", "CRS"], codes, tax)) == {"HILO", "CRS"}
    assert resolve_pools([], codes, tax) == sorted(codes)                           # [] = every pool
    try:
        resolve_pools(["@lines"], codes, tax)
        raise AssertionError("accepted an unknown rule")
    except ValueError:
        pass


def test_team_totals_are_line_markets():
    from algoe.core.taxonomy import PoolTaxonomy, resolve_pools
    tax = PoolTaxonomy()
    h, a, c, f = tax.resolve("HILOH"), tax.resolve("HILOA"), tax.resolve("CHLOA"), tax.resolve("FHLOH")
    assert (h.market, a.market, c.market, f.market) == ("home_total", "away_total", "away_total", "home_total")
    assert c.domain == "corner" and f.theta_domain == "goal_fh" and h.priceable
    assert tax.resolve("ZHILOA").market == "away_total"            # an unseen team total is placed by rule
    codes = ["HILO", "HILOH", "HILOA", "FCHLOH", "ETHILOH", "CRS", "MSPC3"]
    assert set(resolve_pools(["@line_markets"], codes, tax)) == {"HILO", "HILOH", "HILOA", "FCHLOH", "ETHILOH"}
    assert "ETHILOH" not in resolve_pools(["@theta_lines"], codes, tax)   # no extra-time theta to move
    assert tax.resolve("MSPC3").market == "other" and "MSPC3" not in tax.inferred_codes()   # numbered, known


def test_team_totals_price_one_teams_goals():
    from math import exp
    from algoe.pricing.pricer import BookPricer, BookRows, MatchState
    rows = BookRows(["goal", "goal"], ["home_total", "away_total"], [1.5, 0.5], ["H", "H"])
    p, _ = BookPricer().probabilities(rows, {"goal_tg": 2.8, "goal_sup": 0.6})
    assert abs(p[0] - (1 - exp(-1.7) * 2.7)) < 1e-6                # home goals ~ Poisson((TG + SUP) / 2)
    assert abs(p[1] - (1 - exp(-1.1))) < 1e-6                      # away goals ~ Poisson((TG - SUP) / 2)
    # in play at 1-0 with 1.0 goals left (SUP 0.2): home over 1.5 needs one more home goal
    st = MatchState(home_goals=1, phase="second_half", minute=60, ht_home_goals=1, ht_away_goals=0)
    p, _ = BookPricer().probabilities(rows, {"goal_tg": 1.0, "goal_sup": 0.2}, st)
    assert abs(p[0] - (1 - exp(-0.6))) < 1e-6 and abs(p[1] - (1 - exp(-0.4))) < 1e-6


def test_hk_holidays_for_any_year():
    from datetime import date
    from algoe.core.hk_holidays import hk_general_holidays, lunar_date, new_moon_jde, sun_apparent_longitude
    assert abs(new_moon_jde(-283) - 2443192.65118) < 1e-4                 # Meeus example 49.a
    assert abs(sun_apparent_longitude(2448908.5) - 199.906061) < 2e-4      # Meeus example 25.b
    h26 = set(hk_general_holidays(2026))
    for d in ("2026-02-17", "2026-04-03", "2026-04-04", "2026-04-06", "2026-04-07", "2026-05-25",
              "2026-06-19", "2026-09-26", "2026-10-19", "2026-12-26"):
        assert date.fromisoformat(d) in h26, d                             # the gazetted 2026 days
    assert not {date(2026, 5, 19), date(2026, 9, 25), date(2026, 10, 7)} & h26
    assert {date(2023, 1, 25), date(2023, 10, 2)} <= set(hk_general_holidays(2023))   # 4th day of LNY; Sunday rule
    assert date(2012, 10, 2) in hk_general_holidays(2012)    # day following Mid-Autumn on National Day
    assert len(hk_general_holidays(2125)) >= 17
    try:
        import holidays
        from holidays.calendars import _ChineseLunisolar
    except ImportError:
        return
    cal = _ChineseLunisolar()
    # new moons a few seconds (2057) or minutes (2089) from midnight, and a 2025 table entry the gazette
    # does not follow (the Birthday of the Buddha was Monday 5 May)
    skip = {(2025, "buddha"), (2057, "chung_yeung"), (2089, "mid_autumn")}
    for y in range(1950, 2100):
        for name, fn, (m, d) in (("lny", cal.lunar_new_year_date, (1, 1)), ("buddha", cal.buddha_birthday_date, (4, 8)),
                                 ("tuen_ng", cal.dragon_boat_date, (5, 5)), ("mid_autumn", cal.mid_autumn_date, (8, 15)),
                                 ("chung_yeung", cal.double_ninth_date, (9, 9))):
            if (y, name) not in skip:
                assert fn(y)[0] == lunar_date(y, m, d), (y, name)
    for y in range(2009, 2046):          # python-holidays dates Ching Ming by a 4-year rule, right until 2045
        ref = holidays.HK(years=y, categories=holidays.HK.supported_categories)
        cm = min(d for d, n in ref.items() if n.startswith("Ching Ming"))
        assert cm in hk_general_holidays(y), y


def _line_move_panel(money_scale: float = 1.0) -> pd.DataFrame:
    """One HILO pool in play: 2.5 (main) and 3.5 at 20:00 and 20:05; at 20:10 the market has moved to
    1.5 (main, a new line) and 2.5."""
    rows = []
    t0 = pd.Timestamp("2026-07-01 20:00")
    books = {0: [(1, "2.5", 1.9, 1.9), (2, "3.5", 3.0, 1.35)], 1: [(1, "2.5", 1.9, 1.9), (2, "3.5", 3.0, 1.35)],
             2: [(3, "1.5", 1.9, 1.9), (1, "2.5", 3.0, 1.35)]}
    money = {(1, 1, "H"): 1000.0, (1, 1, "L"): 800.0, (1, 2, "H"): 100.0, (1, 2, "L"): 100.0}
    for k, lines in books.items():
        for line_id, label, o_h, o_l in lines:
            for comb, side, o in ((1, "H", o_h), (2, "L", o_l)):
                rows.append({"bucket": t0 + pd.Timedelta(minutes=5 * k), "pool_id": 10, "line_id": line_id,
                             "combination_id": comb, "match_id": 1, "pool_name": "HILO", "line_label": label,
                             "combination_string": side, "odds": o, "priced_before": True, "forecastable": True,
                             "turnover": money.get((k, line_id, side), 0.0) * money_scale, "tickets": 10.0 * money_scale,
                             "is_inplay": True, "match_minute": 20.0 + 5 * k, "mins_to_ko": -20.0 - 5 * k,
                             "tg": 1.5, "sup": 0.2, "league_code": "ENG", "game_state": "FirstHalf"})
    return pd.DataFrame(rows)


def test_a_new_line_inherits_its_slots_money():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        sel = FeatureEngineer(s).prepare_day(_line_move_panel(), day="2026-07-01").sel
    at = sel[sel["bucket"] == pd.Timestamp("2026-07-01 20:10")].set_index(["line_id", "combination_id"])
    new_over, old_over = at.loc[(3, 1)], at.loc[(1, 1)]
    assert new_over["rank_0"] == 1 and new_over["line_new"] == 1 and old_over["line_new"] == 0
    # the new main line took over the slot of the old main line (offset 0, over): HK$1000 of HK$2000
    assert new_over["pos_tv1"] == 1000.0 and abs(new_over["s_share_pool_l1"] - 0.5) < 1e-9
    assert new_over["s_log_l1"] > 0                                  # not the zero a line-id lag would give
    # 2.5 is now one goal above the best line: its own history stays, its slot is where 3.5 was
    assert abs(old_over["s_share_pool_l1"] - 0.5) < 1e-9 and abs(old_over["pos_share_l1"] - 0.05) < 1e-9


def test_money_features_do_not_move_with_the_market_size():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        fe = FeatureEngineer(s)
        small = fe.prepare_day(_line_move_panel(1.0), day="2026-07-01", market_index=1.0)
        big = fe.prepare_day(_line_move_panel(2.0), day="2026-07-01", market_index=2.0)
    for col in ("s_log_l1", "s_log_ewma_fast", "pos_log_l1", "s_share_pool_l1", "s_rel_stake_l1", "wom_l1"):
        assert np.allclose(small.sel[col].to_numpy(dtype=float), big.sel[col].to_numpy(dtype=float)), col
    for col in ("m_log_l1", "m_log_today", "log_board_l1"):
        assert np.allclose(small.match[col].to_numpy(dtype=float), big.match[col].to_numpy(dtype=float)), col
    assert np.allclose(big.sel["tv1"], 2 * small.sel["tv1"])         # the labels and baselines stay in HK$


def test_live_panel_keeps_the_pools_training_kept():
    from algoe.data.panel import LivePanelBuilder
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        names = ["HILO", "CRS", "AGS", "HAD", "NHILO"]
        odds = pd.DataFrame({"pool_id": range(5), "pool_name": names})
        inv = pd.DataFrame({"pool_id": range(5), "pool_name": names, "turnover": [1.0] * 5})
        o, i = LivePanelBuilder(s)._in_scope(odds, inv)
        assert sorted(o["pool_name"]) == sorted(i["pool_name"]) == ["HAD", "HILO", "NHILO"]


def test_split_by_dates_never_mixes_time():
    from algoe.core.exceptions import ConfigError
    from algoe.data.splits import DaySplit
    from algoe.settings import Settings
    days = list(pd.date_range("2024-06-01", "2026-09-15"))
    sp = DaySplit.from_dates(days, "2025-07-01", "2026-07-01")
    assert sp.train[-1] == pd.Timestamp("2025-06-30") and sp.val[0] == pd.Timestamp("2025-07-01")
    assert sp.val[-1] == pd.Timestamp("2026-06-30") and sp.test[0] == pd.Timestamp("2026-07-01")
    assert max(sp.train) < min(sp.val) and max(sp.val) < min(sp.test)
    assert len(sp.train) + len(sp.val) + len(sp.test) == len(days)
    s = Settings()
    for item in ('window.start="2024-06-01"', 'window.end="2026-09-15"', 'window.val_start="2025-07-01"',
                 'window.test_start="2026-07-01"'):
        s.set(item)
    s.check()
    assert DaySplit.for_window(days, s.window) == sp
    s.set('window.test_start="2025-01-01"')                     # test before val: refused
    try:
        s.check()
        raise AssertionError("accepted test_start before val_start")
    except ConfigError:
        pass


# --------------------------------------------------------------- validation
def test_validation_nulls_sentinels_and_fills():
    from algoe.core.validation import validate
    from algoe.data.panel import PANEL_CONTRACT
    t = pd.Timestamp("2026-07-01 20:00")
    f = pd.DataFrame({"bucket": [t, t, t], "match_id": [1, 1, 1], "pool_id": [10, 10, 10],
                      "line_id": [1, 1, 1], "combination_id": [1, 2, 2],
                      "pool_name": ["HILO", None, None], "odds": [1.9, 9999.0, 2.0],
                      "turnover": [100.0, -5.0, 50.0]})
    out, rep = validate(f, PANEL_CONTRACT)
    assert rep.duplicate_keys >= 1
    row = out[out["combination_id"] == 2].iloc[0]
    assert pd.isna(out.loc[out["odds"] > 1000, "odds"]).all() if (out["odds"] > 1000).any() else True
    assert (out["turnover"] >= 0).all()
    assert str(row["pool_name"]) == "UNKNOWN"
    assert not (pd.to_numeric(out["odds"], errors="coerce") == 9999.0).any()


def test_pool_closing_on_the_boundary_leaves_the_board():
    from algoe.data.panel import mark_forecastable
    T = pd.Timestamp("2026-07-10 21:20")
    f = pd.DataFrame({"bucket": [T] * 3, "is_inplay": [True] * 3, "mins_to_ko": [-110.0] * 3,
                      "priced_before": [True] * 3, "odds": [1.9] * 3,
                      "close_time": [T, T + pd.Timedelta(minutes=2), pd.NaT]})
    # closed at 21:20:00 exactly: no money can arrive in [21:20, 21:25); closing at 21:22: still open at T
    assert mark_forecastable(f, 360)["forecastable"].tolist() == [False, True, True]


def test_live_pool_close_times():
    from types import SimpleNamespace
    from algoe.data.panel import LivePanelBuilder
    T = pd.Timestamp("2026-07-10 21:20")
    odds = pd.DataFrame({"pool_id": [1, 2, 3, 4], "match_id": [9, 9, 9, 8],
                         "pool_name": ["HILO", "HDC", "ETHILO", "HILO"],
                         "effective_datetime": [T - pd.Timedelta(minutes=m) for m in (30, 30, 30, 3)]})
    none = pd.DataFrame(columns=["pool_id", "start_sell_time"])

    def close_of(ap, finished=None):
        out = LivePanelBuilder._pools(SimpleNamespace(active_pools=ap), odds, none, 5, T, finished)
        return dict(zip(out["pool_id"].astype(int), out["close_time"]))

    # nothing has a close time yet (every pool open) - must not raise, everything stays open
    ap = pd.DataFrame({"match_id": [9, 9, 9, 8], "pool_id": [1, 2, 3, 4], "close_time": [pd.NaT] * 4})
    assert all(pd.isna(v) for v in close_of(ap).values())
    # a close the source lists is used; a pool it no longer lists closes after its last price
    ap2 = pd.DataFrame({"match_id": [9, 9, 9], "pool_id": [1, 2, 3], "close_time": [T, pd.NaT, pd.NaT]})
    c = close_of(ap2)
    assert c[1] == T and pd.isna(c[2]) and c[4] == T - pd.Timedelta(minutes=2)
    # full-time result published: the 90-minute pools close now, extra time stays open
    c = close_of(ap, finished={9})
    assert c[1] == T and c[2] == T and pd.isna(c[3]) and pd.isna(c[4])


# ----------------------------------------------------------------- nowcast
def test_nowcast_moves_with_the_money():
    from algoe.realtime.nowcast import BucketNowcaster
    nc = BucketNowcaster(prior_minutes=2.0, bucket_minutes=5.0)
    assert abs(nc.update([100.0], [0.0], 0.0).remaining[0] - 100.0) < 1e-9    # nothing seen: the forecast
    hot = nc.update([100.0], [100.0], 1.0)            # a whole bucket's money in the first minute
    assert abs(hot.remaining[0] - (100 / 5 * 2 + 100) / 3 * 4) < 1e-9 and hot.hot[0] > 1
    cold = nc.update([100.0], [0.0], 4.0)             # four quiet minutes
    assert cold.remaining[0] < 20.0 and cold.hot[0] < 1
    whale = nc.update([100.0], [100000.0], 1.0, next_forecast=np.array([100.0]))   # one ticket, 1000 x the bucket
    assert whale.remaining[0] <= 4.0 * 100 / 5 * 4 + 1e-9 and whale.next_bucket[0] <= 100 * 4.0 ** 0.5 + 1e-9


# --------------------------------------------------------------- optimizer
def _stress_book(demand_scale=1.0, spike=1.0):
    """One pre-match book: HILO 2.25/2.5/2.75, HDC -0.25/-0.5/-0.75, HILOH 1.5, CHLO 9.5/10.5,
    priced at HKJC's theta with the posted margin; ``spike`` multiplies the money on Over 2.5."""
    from algoe.optimizer.theta_optimizer import MatchBook
    from algoe.pricing.pricer import BookPricer, BookRows, MatchState, repair_theta, theta_from_params
    spec = ([("HILO", "goal", "total", ln, s) for ln in (2.25, 2.5, 2.75) for s in "HL"]
            + [("HDC", "goal", "handicap", ln, s) for ln in (-0.25, -0.5, -0.75) for s in "HA"]
            + [("HILOH", "goal", "home_total", 1.5, s) for s in "HL"]
            + [("CHLO", "corner", "total", ln, s) for ln in (9.5, 10.5) for s in "HL"])
    pool, dom, mkt, line, side = (np.array(c) for c in zip(*spec))
    rows = BookRows(dom, mkt, line.astype("float64"), side)
    th = repair_theta(theta_from_params(2.6, 0.4, 10.0, 1.0))
    p_now, risk = BookPricer().probabilities(rows, th, MatchState())
    margin = np.where(pool == "CHLO", 0.10, 0.075)
    n = len(spec)
    demand = np.full(n, 2000.0 * demand_scale)
    demand[2] *= spike                                   # Over 2.5
    _, group = np.unique(pool, return_inverse=True)
    nan = np.full(n, np.nan)
    return MatchBook(match_id=1, rows=rows, pool=pool, group=group.astype(int), margin=margin, demand=demand,
                     p_true=p_now.copy(), p_ref=nan, p_mkt=nan, odds_now=BookPricer.sell_odds(p_now, margin),
                     odds_mkt=nan, is_main=np.ones(n, bool), state=MatchState(), theta_now=th,
                     p_now=p_now, risk=risk)


def test_optimizer_with_no_money_and_with_a_flood():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    opt = ThetaOptimizer(s)
    o = s.optimizer
    quiet = opt.optimize_match(_stress_book(demand_scale=0.0))
    assert quiet.status.startswith("skipped") and quiet.theta_star == quiet.theta_now
    for spike in (1.0, 100.0, 1e4):
        bk = _stress_book(spike=spike)
        d = opt.optimize_match(bk)
        th, th0 = d.theta_star, d.theta_now
        assert d.egm_star >= d.egm_board - 1e-9, (spike, d.status)
        for dim, band in o.theta_band.items():
            assert abs(th[dim] - th0[dim]) <= band + 1e-6, (spike, dim, th[dim], th0[dim])
        assert abs(th["goal_sup"]) <= th["goal_tg"] + 1e-9 and th["goal_fh_tg"] <= th["goal_tg"] + 1e-9
        odds = d.odds_star
        assert np.all(np.isfinite(odds)) and odds.min() >= o.min_odds and odds.max() <= o.max_odds
        assert np.max(np.abs(1 / odds - 1 / bk.odds_now)) <= o.prob_band + 1e-3, spike
        if spike >= 100:
            # a flood on Over 2.5 shortens Over (raises TG), never the other way
            assert th["goal_tg"] >= th0["goal_tg"] - 1e-6 and odds[2] <= bk.odds_now[2] + 1e-9, spike
        # stage 2: weightings inside the band, each line's overround kept, the ladder free of arbitrage
        w = d.weights
        assert w is not None and np.all(np.abs(w - 1) <= o.weighting_band + 1e-9) and d.lift_stage2 >= -1e-9
        stage1 = odds / w
        for pool, line in {(p, ln) for p, ln in zip(bk.pool, bk.rows.line)}:
            m = (bk.pool == pool) & (bk.rows.line == line)
            assert abs(np.sum(1 / odds[m]) - np.sum(1 / stage1[m])) < 1e-6, (spike, pool, line)
        over = np.array([odds[(bk.pool == "HILO") & (bk.rows.line == ln) & (bk.rows.side == "H")][0]
                         for ln in (2.25, 2.5, 2.75)])
        under = np.array([odds[(bk.pool == "HILO") & (bk.rows.line == ln) & (bk.rows.side == "L")][0]
                          for ln in (2.25, 2.5, 2.75)])
        assert np.all(np.diff(over) >= -1e-9) and np.all(np.diff(under) <= 1e-9), spike


def test_volume_response_keeps_the_boards_margin():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    bk = _stress_book()

    def gm(opt, k):
        odds = bk.odds_now * k                       # every price k x: a dearer (k < 1) or cheaper board
        return opt.expected_gm(bk, odds, opt.demand_at(bk, odds))
    neutral = ThetaOptimizer(s)
    g = {k: gm(neutral, k) for k in (0.97, 0.99, 1.0, 1.01, 1.03)}
    assert g[1.0] >= max(g.values()) - 1e-6          # HKJC's margin is the volume-optimal one
    s.optimizer.volume_response = "none"
    fixed = ThetaOptimizer(s)
    assert gm(fixed, 0.97) > gm(fixed, 1.0)          # without a volume response a dearer board looks free


# ---------------------------------------------------------------- settings
def test_settings_reject_unknown_keys():
    from algoe.core.exceptions import ConfigError
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.data_dir="C:\\\\data\\\\Raw_Data"')
    assert s.paths.data_dir.endswith("Raw_Data")
    for bad in ("optimizer.not_a_knob=1", "nosection.key=1"):
        try:
            s.set(bad)
            raise AssertionError("accepted " + bad)
        except ConfigError:
            pass
    s.set("turnover.tweedie_power=3")
    try:
        s.check()
        raise AssertionError("accepted tweedie_power=3")
    except ConfigError:
        pass


# ------------------------------------------------------------- model store
def test_model_store_guards():
    from algoe.core.exceptions import RegistryError
    from algoe.registry.model_store import ModelStore
    with tempfile.TemporaryDirectory() as tmp:
        sel = lambda v: {"selection": {"metric": "deviance", "days": ["2026-07-10"], "deviance": v}}  # noqa: E731
        v4 = ModelStore(tmp, "turnover", feature_version=4)
        v4.save("a", {"w": 1}, sel(10.0))
        v4.promote("a", "first")
        assert v4.load("a")[0] == {"w": 1}
        try:
            ModelStore(tmp, "turnover", feature_version=5).load("a")
            raise AssertionError("served a bundle built on other features")
        except RegistryError:
            pass
        v5 = ModelStore(tmp, "turnover", feature_version=5)
        v5.save("b", {"w": 2}, sel(50.0))
        assert v5.promote_if_better("b", "deviance", 50.0, 100.0)       # old champion is stale
        v5.save("c", {"w": 3}, sel(60.0))
        assert not v5.promote_if_better("c", "deviance", 60.0, 100.0)   # same features, worse
        with open(Path(tmp) / "turnover" / "b" / "bundle.pkl", "ab") as fh:
            fh.write(b"tampered")
        try:
            v5.load("b")
            raise AssertionError("served a tampered bundle")
        except RegistryError:
            pass


# ----------------------------------------------------------------- monitor
def test_psi_is_zero_on_same_distribution():
    from algoe.monitoring.monitor import Monitor
    from algoe.settings import Settings
    rng = np.random.default_rng(5)

    def sample(n, zero_share):
        v = rng.exponential(3.0, size=n)
        v[rng.random(n) < zero_share] = 0.0
        return pd.DataFrame({"money": np.log1p(v)})
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        mon = Monitor(s)
        ref = mon.feature_reference(sample(50000, 0.7))
        same = mon.drift(ref, sample(20000, 0.7))["features"][0]["psi"]
        moved = mon.drift(ref, sample(20000, 0.4))["features"][0]["psi"]
        assert same < 0.02, same
        assert moved > 0.1, moved


# ----------------------------------------------------------------- leakage
def test_goal_pulse_ignores_later_events():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        fe = FeatureEngineer(s)
        T = pd.Timestamp("2026-07-01 20:05")
        m = pd.DataFrame({"match_id": [1, 1], "bucket": [T, T + pd.Timedelta(minutes=5)]})
        # provider 1 has more goals before T, provider 2 more over the whole match: choosing a
        # provider by its whole-match count would let the goals after T change the pulse at T
        at = [pd.Timestamp("2026-07-01 " + h) for h in ("20:01", "20:03", "20:04", "20:07", "20:08")]
        ev = pd.DataFrame({"match_id": [1] * 5, "home_or_away": [1, 2, 1, 2, 1], "incident_type": [27] * 5,
                           "provider_id": [1, 1, 2, 2, 2], "incident_datetime": at})
        full = fe._group_events(m.copy(), ev)
        known_at_T = fe._group_events(m.copy(), ev[ev["incident_datetime"] < T])
        cols = ["goal_p3", "goal_p10", "goals_so_far"]
        assert np.allclose(full.loc[0, cols].to_numpy(dtype=float), known_at_T.loc[0, cols].to_numpy(dtype=float))


# --------------------------------------------------------------------- cli
def test_cli_parses_every_command():
    from algoe.cli import build_parser
    p = build_parser()
    for cmd in ("selftest", "check-data", "build-panel", "build-features", "train-turnover", "train-probability",
                "backtest", "parity", "live", "monitor", "models", "nightly"):
        assert callable(p.parse_args([cmd]).func), cmd


def test_selftest_passes():
    if os.environ.get("ALGOE_SLOW") != "1":
        return
    from algoe.selftest import run_selftest
    ck, _ = run_selftest()
    assert not ck.failed, ck.table()


# ------------------------------------------------------------------ runner
if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<48} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<48} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
