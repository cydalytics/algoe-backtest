"""
Step 02 - per-day panel cache

One row per (5-minute bucket, selection) with the price known at the start of
the bucket and the money that arrived in it, built by the W06 engine a month
of raw parquet at a time into <Algo E>/algoe_panel_cache. Days already built
are skipped, so re-running after new data arrives only builds the new days.

    python scripts/s02_build_panel.py --start 2026-07-01 --end 2026-09-15

Same as: python -m algoe build-panel
"""
from _algoe import run

if __name__ == "__main__":
    run("build-panel")
