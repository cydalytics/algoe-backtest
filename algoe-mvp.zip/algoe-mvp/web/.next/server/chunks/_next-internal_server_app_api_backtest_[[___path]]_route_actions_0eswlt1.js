module.exports=[492,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_backtest_%5B%5B___path%5D%5D_route_actions_0eswlt1.js.map