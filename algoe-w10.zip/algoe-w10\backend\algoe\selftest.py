"""
Selftest

The whole chain on a generated world whose truth is known, so "it runs" and
"it is right" are both checked before anything is packaged or deployed. No
Raw_Data, no SQL, no network:

    S1   generate      SyntheticWorld -> Raw_Data-shaped parquet. A league and a
                       pool code the models have never seen appear near the end.
    S2   data check    the W06 probe finds every table; no FAIL
    S3   panel         every day builds and passes the panel contract
    S4   features      finite inputs, unique keys, forecastable rows only
    S5   pricer        our score-grid pricer agrees with the legacy poisson_betting
    S6   turnover      the champion beats last 5 minutes on the test days
    S7   probability   the calibrated belief vs 1/true_odds on test log-loss (WARN only:
                       a few synthetic days are a noisy judge of a small gain)
    S8   parity        the serving path at a bucket start builds the same rows and the
                       same inputs as the training path - also the leak test
    S9   live          one sweep and one focus refresh on the replay source; theta* never
                       has lower E[GM] than HKJC's theta and stays inside the trust band
    S10  monitor       published forecasts are joined to what arrived; health computed
    S11  unknowns      the new league and pool code are forecast (parent level, taxonomy
                       rule) and flagged by the monitor, not dropped or crashed on

    python -m algoe selftest            exit code 0 only if nothing FAILed

Change Log:
-----------
2026-10-01      Initialize
"""

from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .core.logging import get_logger

logger = get_logger(__name__)

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"


class Checks:
    """Ordered PASS / WARN / FAIL lines; an exception inside a check is a FAIL, not a crash."""

    def __init__(self):
        self.rows: List[dict] = []

    def run(self, code: str, title: str, fn: Callable[[], Tuple[str, str]]) -> Optional[str]:
        started = time.time()
        try:
            level, detail = fn()
        except Exception as exc:                                        # noqa: BLE001
            logger.exception("%s %s raised", code, title)
            level, detail = FAIL, "{}: {}".format(type(exc).__name__, exc)
        row = {"code": code, "title": title, "level": level, "detail": detail,
               "seconds": round(time.time() - started, 1)}
        self.rows.append(row)
        log = logger.error if level == FAIL else (logger.warning if level == WARN else logger.info)
        log("[%s] %-4s %-12s %s (%.1fs)", level, code, title, detail, row["seconds"])
        return level

    @property
    def failed(self) -> bool:
        return any(r["level"] == FAIL for r in self.rows)

    def table(self) -> str:
        lines = ["", "{:<5} {:<5} {:<13} {}".format("", "code", "check", "result"), "-" * 96]
        for r in self.rows:
            lines.append("{:<5} {:<5} {:<13} {}".format(r["level"], r["code"], r["title"], r["detail"]))
        n = {k: sum(1 for r in self.rows if r["level"] == k) for k in (PASS, WARN, FAIL)}
        lines += ["-" * 96, "{} PASS, {} WARN, {} FAIL".format(n[PASS], n[WARN], n[FAIL])]
        return "\n".join(lines)


def selftest_settings(root: Path, days: int, start: str = "2026-07-01"):
    """Defaults plus the synthetic paths - never the office settings file or ALGOE_* variables."""
    from .settings import Settings
    end = (pd.Timestamp(start) + pd.Timedelta(days=days - 1)).strftime("%Y-%m-%d")
    s = Settings()
    for item in ('paths.data_dir="{}"'.format((root / "Raw_Data").as_posix()),
                 'paths.work_dir="{}"'.format((root / "work").as_posix()),
                 'window.start="{}"'.format(start), 'window.end="{}"'.format(end),
                 "window.val_days=2", "window.test_days=3", "window.min_train_days=4",
                 "turnover.fit_rows_per_day=20000", "optimizer.budget_seconds=60"):
        s.set(item)
    s.check()
    return s


def run_selftest(root=None, days: int = 10, matches_per_day: int = 5, seed: int = 7,
                 fresh: bool = False) -> Tuple[Checks, dict]:
    from .backtest.backtester import Backtester                       # noqa: F401  (import check)
    from .data.panel import HistoricalPanel
    from .data.replay import ReplaySource
    from .data.synthetic import SyntheticWorld
    from .evaluation.parity import busiest_bucket, train_serve_parity
    from .features.engineer import FeatureEngineer
    from .features.store import FeatureStore
    from .models.probability import ProbabilityCalibrator
    from .models.turnover import TurnoverForecaster
    from .monitoring.monitor import Monitor
    from .realtime.live_engine import LiveEngine

    root = Path(root) if root else Path(__file__).resolve().parents[1] / ".selftest_data"
    # --fresh regenerates the world; logs and run folders stay (this run is writing to them)
    doomed = [root / "Raw_Data", root / "algoe_panel_cache", root / "synthetic_truth.json"] if fresh else []
    # models and features always start clean, so a stale champion cannot pass for a new one
    doomed.append(root / "work")
    for p in doomed:
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
    raw = root / "Raw_Data"
    s = selftest_settings(root, days)
    ctx: Dict = {"settings": s}
    ck = Checks()

    def s1():
        if (root / "synthetic_truth.json").exists() and (raw / "Match_Information").exists():
            return PASS, "reusing {} (pass --fresh to regenerate)".format(raw)
        SyntheticWorld(days=days, matches_per_day=matches_per_day, seed=seed).write(raw)
        import json
        t = ctx["truth"] = json.loads((root / "synthetic_truth.json").read_text(encoding="utf-8"))
        return PASS, "{} days, {} matches, unseen league {} and pool code {} from day {}".format(
            t.get("days"), t.get("matches"), t.get("new_league"), t.get("new_pool"), t.get("new_league_day"))

    def s2():
        from src.backtest.parquet.probe import probe
        rep = probe(s.legacy_config())
        fails = [c for c in rep["checks"] if c["level"] == "FAIL"]
        if fails:
            return FAIL, "; ".join("{}: {}".format(c["check"], c["detail"]) for c in fails)
        return PASS, "{} tables, {} checks, no FAIL".format(len(rep["tables"]), len(rep["checks"]))

    def s3():
        hp = ctx["panel"] = HistoricalPanel(s)
        ds = ctx["days"] = hp.days()
        hp.ensure(ds)
        rows = {}
        for d in ds:
            frame = hp.load_day(d)
            rows[str(d.date())] = 0 if frame is None else len(frame)
        empty = [d for d, n in rows.items() if n == 0]
        if empty:
            return FAIL, "no panel rows for {}".format(empty)
        return PASS, "{} days, {:,} rows".format(len(ds), sum(rows.values()))

    def s4():
        fe = ctx["engineer"] = FeatureEngineer(s)
        store = ctx["store"] = FeatureStore(s, ctx["panel"], fe)
        dd = store.get(ctx["days"][len(ctx["days"]) // 2])
        problems = []
        for name, fs in (("match_total", fe.features_for_turnover_match_total(dd)),
                         ("pool_share", fe.features_for_turnover_pool_share(dd)),
                         ("selection", fe.features_for_turnover_selection(dd)),
                         ("probability", fe.features_for_probability(dd))):
            X = fs.X.to_numpy(dtype="float64")
            if not np.isfinite(X).all():
                problems.append("{}: non-finite inputs".format(name))
            if not len(fs):
                problems.append("{}: no rows".format(name))
        if dd.sel.duplicated(["pool_id", "line_id", "combination_id", "bucket"]).any():
            problems.append("duplicate selection keys")
        return (FAIL, "; ".join(problems)) if problems else (
            PASS, "{:,} selection rows, {} selection features, all finite".format(
                int(dd.sel["forecastable"].sum()), len(fe.features_for_turnover_selection(dd).feature_names)))

    def s5():
        from src.backtest.parquet import poisson_betting as pb
        from .pricing.pricer import marginals, score_grid, two_way
        worst = 0.0
        for tg in (1.4, 2.6, 3.4):
            for sup in (-0.9, 0.0, 0.7):
                m = marginals(score_grid(tg, sup, 10))
                for line in (1.5, 2.25, 2.5, 2.75, 3.0):
                    ours = float(two_way(m.total_values, m.total_probs, line)[0][0])
                    worst = max(worst, abs(ours - 1.0 / pb.calculate_over_under_odds(tg, sup, line)["Over"]))
                for h in (-1.25, -0.5, 0.0, 0.25, 0.75):
                    ours = float(two_way(m.diff_values, m.diff_probs, -h)[0][0])
                    worst = max(worst, abs(ours - 1.0 / pb.calculate_asian_handicap_odds(tg, sup, h)["Home"]))
        return (PASS if worst < 1e-9 else FAIL), "worst |p ours - p legacy| = {:.2e} over 90 lines".format(worst)

    def s6():
        tf = ctx["forecaster"] = TurnoverForecaster(s, ctx["engineer"], ctx["store"])
        meta = tf.train_all(ctx["days"])
        tf.save()
        lb = {r["pipeline"]: r for r in meta["leaderboard"]}
        champ, base = lb[tf.champion], lb["last5"]
        detail = "champion {}: test deviance {:.4g} vs last5 {:.4g}, match WAPE {:.1%} vs {:.1%}".format(
            tf.champion, champ["test_deviance"], base["test_deviance"], champ["test_match_wape"],
            base["test_match_wape"])
        if tf.champion == "last5" or champ["test_deviance"] >= base["test_deviance"]:
            return FAIL, detail + " - the models should beat persistence on a world with signal"
        return PASS, detail

    def s7():
        pc = ctx["calibrator"] = ProbabilityCalibrator(s, ctx["engineer"], ctx["store"])
        pc.train_all(ctx["days"])
        pc.save()
        rows = {r["method"]: r for r in pc.leaderboard}
        champ, base = rows[pc.champion], rows["raw:hkjc_true"]
        detail = "champion {}: test log-loss {:.5f} vs raw {:.5f}".format(
            pc.champion, champ["test_log_loss"], base["test_log_loss"])
        return (PASS if champ["test_log_loss"] <= base["test_log_loss"] else WARN), detail

    def s8():
        store, fe = ctx["store"], ctx["engineer"]
        last = store.get(ctx["days"][-1])
        moments = [busiest_bucket(last)]
        # the first bucket after midnight that has rows: lags there come from the previous day
        early = last.sel.loc[last.sel["forecastable"] & (last.sel["bucket"] < last.day + pd.Timedelta(hours=3)),
                             "bucket"]
        if len(early):
            moments.append(pd.Timestamp(early.min()))
        # where a pool closes - exactly on a bucket boundary, and inside a bucket - a closed pool must
        # leave the board in both paths, while the money it took stays in the history
        panel = ctx["panel"].load_day(ctx["days"][-1])
        if panel is not None and "close_time" in panel.columns:
            ct = pd.to_datetime(panel["close_time"], errors="coerce")
            b = pd.to_datetime(panel["bucket"])
            step = "{}min".format(s.panel.bucket_minutes)
            for cand in (b[ct.notna() & (ct == b)], b[ct.notna() & (ct.dt.floor(step) == b) & (ct != b)]):
                if len(cand):
                    moments.append(pd.Timestamp(cand.max()))
        moments = sorted({pd.Timestamp(m) for m in moments if m is not None})
        bad = []
        source = ReplaySource(s)
        for at in moments:
            rep = train_serve_parity(s, store, fe, at, source=source)
            for level, r in rep["levels"].items():
                if not r["ok"]:
                    bad.append("{} {}: {} only-train, {} only-serve, differ {}".format(
                        at, level, r["only_train"], r["only_serve"], [d["feature"] for d in r["diffs"]][:5]))
            if rep.get("note"):
                bad.append("{}: {}".format(at, rep["note"]))
        ctx["at"] = busiest_bucket(last)
        return (FAIL, "; ".join(bad)) if bad else (PASS, "identical rows and inputs at {} (5 levels)".format(
            ", ".join(m.strftime("%H:%M") for m in moments)))

    def s9():
        s.live.source = "replay"
        mon = ctx["monitor"] = Monitor(s)
        eng = ctx["engine"] = LiveEngine(s, ReplaySource(s), ctx["forecaster"], ctx["calibrator"], mon)
        at = ctx["at"]
        sw = eng.run_sweep(at)
        worse, outside = [], []
        for mid, live in eng.matches.items():
            d = live.decision
            if d is None or d.status != "solved":
                continue
            if d.lift < -1e-6:
                worse.append(mid)
            for k, band in s.optimizer.theta_band.items():
                if k in d.theta_star and k in d.theta_now and abs(d.theta_star[k] - d.theta_now[k]) > band + 1e-6:
                    outside.append((mid, k))
        if not eng.matches:
            return FAIL, "the sweep at {} produced no match".format(at)
        top = max(eng.matches.values(), key=lambda m: m.decision.turnover if m.decision else 0.0)
        live = eng.run_focus(top.match_id, at + pd.Timedelta(seconds=150))
        problems = []
        if worse:
            problems.append("theta* worse than HKJC for {}".format(worse))
        if outside:
            problems.append("outside the trust band: {}".format(outside[:5]))
        if live is None or not np.isfinite(live.remaining) or live.remaining < 0:
            problems.append("focus refresh gave no usable nowcast")
        detail = "sweep {} matches ({} solved) in {}s, lift {:.0f}; focus {}: observed {:.0f}, remaining {:.0f}".format(
            sw.get("matches"), sw.get("solved"), sw.get("seconds", {}).get("total"), sw.get("lift", 0.0),
            top.match_id, live.observed if live else float("nan"), live.remaining if live else float("nan"))
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    def s10():
        mon, day = ctx["monitor"], pd.Timestamp(ctx["at"]).normalize()
        joined = mon.join_realised(day, ctx["store"])
        if joined is None or joined.empty:
            return FAIL, "no logged forecast could be joined to what arrived"
        health = mon.health_from_frames({day: joined})
        d = health["daily"][0] if health["daily"] else {}
        return PASS, "{:,} published rows scored; WAPE {} vs last5 {}".format(
            len(joined), _pct(d.get("wape_model")), _pct(d.get("wape_last5")))

    def s11():
        fe, store, tf = ctx["engineer"], ctx["store"], ctx["forecaster"]
        inferred = fe.taxonomy.inferred_codes()
        last = store.get(ctx["days"][-1])
        known = set(fe.encoders.league.tables.get("league_code", {})) if fe.encoders.league else set()
        new_leagues = sorted(set(last.match["league_code"].astype(str)) - known)
        fc = tf.predict_selection_turnover(last)
        new_rows = fc["match_id"].isin(last.match.loc[last.match["league_code"].astype(str).isin(new_leagues),
                                                      "match_id"])
        finite = bool(np.isfinite(fc.loc[new_rows, "forecast"]).all()) and bool((fc.loc[new_rows, "forecast"] >= 0).all())
        nov = ctx["monitor"].novelty(last, fe.encoders, fe.taxonomy)
        problems = []
        if not new_leagues:
            problems.append("the test days carry no unseen league (world too short?)")
        if not finite or not new_rows.any():
            problems.append("no finite forecast for the unseen league's rows")
        if not inferred:
            problems.append("no pool code needed the taxonomy rules")
        if not nov["alerts"]:
            problems.append("the monitor raised no novelty alert")
        detail = "unseen league(s) {} forecast on {:,} rows; pool code(s) {} placed by rule; {} alert(s)".format(
            new_leagues, int(new_rows.sum()), sorted(inferred), len(nov["alerts"]))
        return (FAIL, "; ".join(problems) + " | " + detail) if problems else (PASS, detail)

    for code, title, fn in (("S1", "generate", s1), ("S2", "data check", s2), ("S3", "panel", s3),
                            ("S4", "features", s4), ("S5", "pricer", s5), ("S6", "turnover", s6),
                            ("S7", "probability", s7), ("S8", "parity", s8), ("S9", "live", s9),
                            ("S10", "monitor", s10), ("S11", "unknowns", s11)):
        needs = {"S3": ["S2"], "S4": ["S3"], "S6": ["S4"], "S7": ["S4"], "S8": ["S6"], "S9": ["S6", "S7", "S8"],
                 "S10": ["S9"], "S11": ["S6", "S9"]}.get(code, [])
        failed_before = {r["code"] for r in ck.rows if r["level"] == FAIL}
        if any(n in failed_before for n in needs):
            ck.rows.append({"code": code, "title": title, "level": FAIL, "seconds": 0.0,
                            "detail": "skipped: depends on {}".format([n for n in needs if n in failed_before])})
            continue
        ck.run(code, title, fn)
    return ck, ctx


def _pct(v) -> str:
    return "{:.1%}".format(v) if v is not None and np.isfinite(v) else "n/a"
