# Algo E W10 - architecture

## The loop

Every 5-minute bucket, for every live match: **forecast** the money each selection will take,
**believe** a win probability for each selection that does not come from HKJC's own theta,
**search** the eight TG/SUP parameters, re-running demand at every candidate price, and
**score** each candidate by expected gross margin `E[GM] = sum demand x (1 - offer x belief)`.
Between buckets, for the matches a trader has open, the same loop runs every ~15 s with the
money already in the bucket.

## Folders

```
backend/
    algoe/                      the library (this document)
        core/                   settings-free plumbing: exceptions, logging, validation, taxonomy, calendar, io
        settings.py             every tunable number, one dataclass per layer
        data/                   panels (historical, live), day splits, synthetic world, replay source
        features/               catalog (features + hypotheses), engineer, encoders, feature store
        models/                 estimators, TurnoverForecaster, ProbabilityCalibrator
        pricing/                score-grid pricer, in-play conventions, panel pricing
        optimizer/              ThetaOptimizer, demand response, books
        realtime/               LiveEngine, nowcaster
        backtest/               Backtester
        evaluation/             metrics, train/serve parity
        monitoring/             Monitor
        registry/               ModelStore
        reporting/              HTML report pieces
        cli.py, __main__.py     python -m algoe <command>
        selftest.py             the whole chain on a world with known truth
    scripts/sNN_*.py            one numbered wrapper per CLI command, in pipeline order
    src/                        the W06-W08 desk (API, SQL / capture / sim sources, parquet engine)
    tests/test_algoe.py         unit tests (pytest or plain python)
deploy/algoe-*.bat              office-box launchers
docs/                           this, RUNBOOK, FEATURES, HKJC_CODE_REVIEW
package-algoe.ps1               builds dist/algoe-w10 (selftest-gated)
```

**Layering** (an import may only point down): `realtime`, `backtest`, `cli` -> `optimizer` ->
`pricing`; `models` -> `features` -> `data` -> `core`. `algoe` wraps the W06 parquet engine
(`src/backtest/parquet`: loader, per-day panel cache); that engine never imports `algoe`, so the
workbench keeps working unchanged. The desk API (`src/api/routes/live.py`) is the one place `src`
imports `algoe`.

## Data flow

```
TRAINING                                              SERVING (live engine)
Raw_Data parquet                                      SQL / capture / sim / replay snapshot
  -> HistoricalPanel (W06 per-day cache)                -> LivePanelBuilder  (same W06 build_day,
       + contract validation                                 same start odds across midnight,
                                                            same contract, same one-hour tail)
  -> FeatureEngineer.prepare_day(panel, tail, ...)      -> FeatureEngineer.prepare_live(panel, extra)
  -> FeatureStore (per day, per feature version)            (calls prepare_day the same way)
  -> features_for_* -> estimators                       -> features_for_* -> champion models
                                                        -> build_books -> ThetaOptimizer
                                                        -> board / match view / monitor log
```

**One row** = (bucket T, pool_id, line_id, combination_id): the price known at the start of T
and the money that arrived in `[T, T+5)`. A row is `forecastable` only if it was priced before
T and inside the pre-match window or in play; rows that merely took money are labels, never
feature rows.

**Parity is tested, not assumed.** `evaluation/parity.py` builds one bucket through both
columns above - the serving path from Raw_Data replayed as of the bucket start, so it cannot
see inside the bucket - and compares every model input of all five feature sets row by row.
Identical inputs mean no train/serve skew and no leak. The selftest runs it on every build;
`python -m algoe parity --at ...` runs it on the real data. It found six real problems during
W10, all fixed: odds age measured at the end of the bucket (a leak); the event provider chosen
with later goals (a leak); first-half pools kept alive after half time; a live selling start
rounded up a bucket, so lines looked five minutes younger; start odds lost across midnight;
money-today and lags split at midnight differently from training.

## The classes and their verbs

Method names follow `verb_[algorithm]_[response or source]`, so a reader can find any piece
from its name.

**`FeatureEngineer`** (`features/engineer.py`)
`prepare_day`, `prepare_live`; `features_for_turnover_match_total`,
`features_for_turnover_pool_share`, `features_for_turnover_selection_share`,
`features_for_turnover_selection`, `features_for_probability`; `fit_encoders`.
Features are grouped (money history, events, lifecycle, calendar, concurrency, price, line
position, bet type, popularity), each with the hypothesis it tests (`features/catalog.py`,
listed in `FEATURES.md`).

**`TurnoverForecaster`** (`models/turnover.py`)
`train_{glm,gam,gbm,nn}_{match_total,pool_share,selection_share,selection_turnover}`,
`train_naive_profile`; `predict_match_total`, `predict_pool_share`, `predict_selection_share`,
`predict_selection_turnover`, `predict_remaining_bucket`; `evaluate_match_total`,
`evaluate_pool_share`, `evaluate_selection_share`, `evaluate_selection_turnover`;
`train_all`, `refit_for_serving`, `write_backtest_series`, `save`, `load`.

**`ProbabilityCalibrator`** (`models/probability.py`)
`train_{platt,beta,isotonic}_{hkjc_true,market,...}`, `train_logit_pool`, `train_contextual`;
`predict_true_prob`, `predict_for_day`; `train_all`, `refit_for_serving`, `save`, `load`.

**`ThetaOptimizer`** (`optimizer/theta_optimizer.py`)
`prices`, `demand_at`, `expected_gm`, `optimize_match`, `optimize_card`; `build_books` turns a
bucket's rows into one `MatchBook` per match.

**`Backtester`** (`backtest/backtester.py`)
`compare_turnover`, `compare_trueprob`, `compare_optimizer`, `compare_gm`,
`compare_feature_groups`, `check_replication`, `run_all`, `render`.

**`LiveEngine`** (`realtime/live_engine.py`)
`run_sweep`, `run_focus`, `check_triggers`, `step`, `start`, `stop`, `focus_on`, `focus_off`,
`trigger`, `board`, `match_view`.

**`Monitor`** (`monitoring/monitor.py`) `log_forecasts`, `join_realised`, `health_from_frames`,
`feature_reference`, `drift`, `novelty`, `write_health`.
**`ModelStore`** (`registry/model_store.py`) `save`, `load`, `champion`, `promote`,
`promote_if_better`, `list`.

## Modelling decisions

**Turnover.** The response is decomposed as
`selection money = match total x pool share x selection share` (the three-stage pipelines),
and also modelled directly (`direct:` pipelines); each piece has its own features and loss:
Tweedie / Poisson deviance with a log link for money, multinomial-style shares with exposure.
Estimators: penalised-IRLS GLM (scale-invariant ridge), GAM (P-splines), GBM (LightGBM, or
sklearn's HistGradientBoosting), NN (torch, optional). Each pipeline may be blended toward last
5 minutes, with the weight chosen on validation days. Days are split by calendar
(train | val | test, never random); the champion is the lowest validation deviance, reported
once on test with WAPE (selection, match, active selections), bias, Diebold-Mariano against
last 5 minutes and days better / worse. A bundle is promoted only if it beats last 5 minutes
and the current champion on the same validation days.

**Unknowns.** Leagues and pools are target-encoded with empirical-Bayes shrinkage to their
parent (league -> global; pool x phase -> family x phase -> global), so an unseen league or
pool code gets its parent's level, never an error or a random code. Pool codes the taxonomy
has never seen are placed by their spelling (`core/taxonomy.py`) and confirmed in
`config/pools.json`. Within a day, a match's own money updates a shrunk match effect, so a new
league learns in hours.

**Belief.** Settled selections only, with the soft outcome `(r+1)/2` for quarter lines and
pushes dropped; live prices only (a withdrawn line keeps a stale quote). Every source (HKJC
true odds, external market median, Poisson from HKJC's theta with the in-play score shift,
de-margined odds) x every method (raw, Platt, beta, isotonic, logit pool, contextual), fitted
on train days, chosen on validation log-loss, renormalised within each line.

**Pricing and in-play.** One score grid per (TG, SUP) collapsed to total / difference
marginals, one effective-probability formula for whole, half and quarter lines. In play,
HKJC's `Goal90CurrentTG` is goals still to come, so full-match lines are priced on the grid
shifted by the current score; `check_replication` confirms this convention reproduces HKJC's
own board for every pool.

**Optimizer.** `price_mode = delta`: our offer is HKJC's posted odds moved by our model's
relative price change, `O(theta) = O_now x p(theta_now) / p(theta)`, so the lift measures the
theta decision alone. Demand at a candidate price comes from the turnover model's own price
terms, renormalised within each pool. Guards: a trust band around HKJC's theta, a max step
from the previous recommendation, coherence (first half inside the full match, |SUP| <= TG),
a per-selection probability band, and the external market as a cap on main-line offers.
theta_now is always a candidate, so a recommendation is never worse than HKJC's theta under
the model. Books are split into independent blocks (goal / corner x FT / FH) so each
evaluation prices only what the moved dimensions touch.

## Real time and compute

| Loop | When | What | Cost (synthetic card of 9-12 matches) |
|------|------|------|------|
| sweep | every bucket boundary | the whole card: forecast, belief, theta* for every match with expected money above `optimizer.min_match_turnover`, richest first, inside `optimizer.budget_seconds`, in a process pool | 4.7-5.9 s |
| focus | every `live.focus_interval_seconds` (15 s) for matches open on the desk (heartbeat, 3-minute TTL) or hit by a trigger | re-fetch that match only; nowcast the rest of the bucket; re-optimise from the last answer with one start and a max step | 0.6-1.2 s per match |
| triggers | every focus interval, whole card, cheap | goal / red card; main-line price move > `live.trigger_odds_move`; one minute's money > `live.trigger_big_bet_multiple` x the forecast minute | tens of ms |

**Nowcast** (`realtime/nowcast.py`): with bucket forecast F and money x after e minutes, the
rate is `(F/5 x m0 + x) / (m0 + e)` - a Gamma-Poisson update where the forecast counts as m0
minutes of evidence - applied at match level and spread over its selections, so
`remaining = rate x (5 - e)`. The next bucket's forecast is scaled by how hot this one runs.

## Validation, logging, traceability

- **Contracts** (`core/validation.py`): every panel (historical and live) passes the same
  column rules - type coercion, sentinels (odds 9999) to null, ranges clipped or nulled, required
  fills (unknown pool name -> `UNKNOWN`), duplicate keys counted - and a report is logged.
- **Logging** (`core/logging.py`): every stage is a boxed `STEP` with a `[PASS]`/`[FAIL]` line
  and its timing, to the console, a text log and a JSON-lines log with the data behind each line.
- **Runs**: every CLI command writes `AlgoE_Work/runs/<stamp>_<command>/` with the resolved
  settings and a summary (exit code, error, headline numbers).
- **Versions**: `FEATURE_VERSION` keys the feature store and is stamped on every model;
  the store refuses a bundle whose checksum or feature version does not match, and a champion
  on older features cannot block a promotion.

## Tests

| Layer | Where | Runs |
|-------|-------|------|
| unit | `backend/tests/test_algoe.py` | pricer vs legacy, quarter-line settlement, GLM recovers rates, save / load, unseen encodings and pool codes, validation, nowcast, settings, model store guards, PSI, goal-pulse time consistency, CLI parsing |
| system | `python -m algoe selftest` | 11 checks on a generated world, including train/serve parity and a live sweep + focus |
| real data | `python -m algoe parity` | train/serve parity on Raw_Data |
| desk | `backend/tests/test_optimizer.py`, `contract.py` | the W06 desk still serves every field the UI reads |

## Extending

- **A new feature**: add it in the engineer's group method, add a `FeatureSpec` (group,
  hypothesis, fill, clip) to `features/catalog.py`, bump `FEATURE_VERSION`, run the selftest
  (parity must stay identical) and the backtest (`compare_feature_groups` says what it is worth).
- **A new estimator**: subclass `Estimator` (`fit`, `predict`, `to_state`, `from_state`), register it,
  add `train_<algo>_<response>` methods and a pipeline name; it joins the leaderboard.
- **A new response or pipeline**: a `ResponseSpec` (builder, family, exposure) and a pipeline
  string such as `three_stage:gbm+glm+gbm`.
- **A new pool code or league**: nothing to code (see RUNBOOK section 5).
