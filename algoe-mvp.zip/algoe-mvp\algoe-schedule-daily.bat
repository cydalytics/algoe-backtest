@echo off
REM Algo E - register "AlgoE daily": algoe-nightly.bat every day at 06:00 (or the time given), for this
REM Windows user. No admin rights: the task runs while you are logged on, so the S: drive is mapped.
REM algoe-nightly.bat brings Raw_Data up to date (each investment day checked), builds the new days,
REM scores them for the models that served them (the Backtest tab's walk-forward days), runs the monitor,
REM then refits and promotes. start.ps1 registers it when it is missing (start.ps1 -NoSchedule does not).
REM     algoe-schedule-daily.bat               every day at 06:00
REM     algoe-schedule-daily.bat 07:15         every day at 07:15
REM     algoe-schedule-daily.bat --dry-run     print the command, register nothing
REM It shows in Task Scheduler as "AlgoE daily" and does what "AlgoE data update" did and more; remove
REM that one with: schtasks /Delete /TN "AlgoE data update" /F
setlocal
set "AT=06:00"
set "QUIET="
set "DRY="
:args
if "%~1"=="" goto :go
if /i "%~1"=="--quiet" (set "QUIET=1") else if /i "%~1"=="--dry-run" (set "DRY=1") else (set "AT=%~1")
shift
goto :args
:go
if not defined DRY goto :register
echo schtasks /Create /F /SC DAILY /ST %AT% /TN "AlgoE daily" /TR "\"%~dp0algoe-nightly.bat\""
exit /b 0
:register
if not defined QUIET goto :loud
schtasks /Create /F /SC DAILY /ST %AT% /TN "AlgoE daily" /TR "\"%~dp0algoe-nightly.bat\"" >nul 2>&1
exit /b
:loud
schtasks /Create /F /SC DAILY /ST %AT% /TN "AlgoE daily" /TR "\"%~dp0algoe-nightly.bat\""
if errorlevel 1 (
    echo.
    echo Windows refused the task, see above. Run algoe-nightly.bat by hand instead;
    echo start.bat also starts the data update when the data is older than yesterday.
    pause
    exit /b 1
)
echo.
schtasks /Query /TN "AlgoE daily" /FO LIST
echo.
echo Registered: algoe-nightly.bat runs every day at %AT% while you are logged on.
pause
