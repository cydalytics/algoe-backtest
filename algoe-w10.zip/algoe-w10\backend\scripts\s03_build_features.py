"""
Step 03 - per-day feature cache

Runs FeatureEngineer.prepare_day on every panel day (money history, events,
lifecycle, calendar, concurrency, price, line position, bet type) and keeps the
result under AlgoE_Work/features/<key>. The key hashes FEATURE_VERSION and the
feature settings, so a code or setting change never reads a stale day.

    python scripts/s03_build_features.py --start 2026-07-01 --end 2026-09-15

Same as: python -m algoe build-features
"""
from _algoe import run

if __name__ == "__main__":
    run("build-features")
