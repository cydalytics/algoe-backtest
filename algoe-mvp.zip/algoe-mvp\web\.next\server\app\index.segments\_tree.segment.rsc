:HL["/_next/static/chunks/18krke1ekg8o5.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"scmrs8VU9QlD-4Xzx7pZX"}
