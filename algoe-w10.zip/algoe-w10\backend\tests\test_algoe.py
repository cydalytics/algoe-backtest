"""
Algo E unit tests - fast, no Raw_Data, no SQL, no network

    python tests/test_algoe.py              plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_algoe.py    the same checks under pytest
    set ALGOE_SLOW=1                        also run the whole selftest (about two minutes)

Each test guards one behaviour the desk depends on:

    pricer            our score-grid pricer == legacy poisson_betting; quarter lines settle half
    estimators        the GLM recovers known Poisson rates; every bundle survives save / load
    unknowns          an unseen pool key encodes at its parent; an unseen pool code is placed by rule
    pools / splits    panel pools by market rule (a new line market joins by itself); a date split
                      keeps train < val < test with no day in two roles
    validation        sentinel odds become null, negative money clips, missing names fill, duplicates count;
                      a pool closing exactly at a bucket start is off the board for that bucket
    nowcast           the rest-of-bucket forecast moves with the money already in
    settings          a typo in a key or an impossible value is refused, not silently ignored
    model store       a tampered bundle, or one built on other features, is never served
    monitor           PSI is ~0 on the training distribution even for a zero-inflated feature
    leakage           a goal after the bucket start does not change that bucket's goal pulse
    cli               every command parses

Change Log:
-----------
2026-10-01      Initialize
"""

import os
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


# ------------------------------------------------------------------- pricer
def test_pricer_matches_legacy():
    from src.backtest.parquet import poisson_betting as pb
    from algoe.pricing.pricer import marginals, score_grid, two_way
    for tg, sup in ((1.4, -0.9), (2.6, 0.0), (3.4, 0.7)):
        m = marginals(score_grid(tg, sup, 10))
        for line in (1.5, 2.25, 2.5, 2.75, 3.0):
            ours = float(two_way(m.total_values, m.total_probs, line)[0][0])
            assert abs(ours - 1.0 / pb.calculate_over_under_odds(tg, sup, line)["Over"]) < 1e-9
        for h in (-1.25, -0.5, 0.0, 0.25, 0.75):
            ours = float(two_way(m.diff_values, m.diff_probs, -h)[0][0])
            assert abs(ours - 1.0 / pb.calculate_asian_handicap_odds(tg, sup, h)["Home"]) < 1e-9


def test_quarter_lines_settle_half():
    from algoe.pricing.pricer import settle_matrix, two_way
    r = settle_matrix(np.array([2.0, 3.0]), np.array([2.25, 2.75]))
    assert r[0].tolist() == [-0.5, 1.0]       # over 2.25: two goals lose half, three win
    assert r[1].tolist() == [-1.0, 0.5]       # over 2.75: two lose, three win half
    p1, p2, at_risk = two_way(np.array([2.0, 3.0]), np.array([0.0, 1.0]), 2.25)
    assert abs(p1[0] - 1.0) < 1e-12 and abs(p2[0]) < 1e-12


# --------------------------------------------------------------- estimators
def _poisson_data(n=20000, seed=3):
    rng = np.random.default_rng(seed)
    x = rng.normal(size=n)
    y = rng.poisson(np.exp(0.5 + 0.8 * x))
    return pd.DataFrame({"x": x}), y.astype("float64")


def test_glm_recovers_poisson_rates():
    from algoe.models.estimators import GLMEstimator
    X, y = _poisson_data()
    m = GLMEstimator("poisson", ridge=1e-8).fit(X, y)
    grid = pd.DataFrame({"x": [-1.0, 0.0, 1.0]})
    truth = np.exp(0.5 + 0.8 * grid["x"].to_numpy())
    assert np.all(np.abs(m.predict(grid) / truth - 1.0) < 0.05)


def test_estimator_state_round_trip():
    from algoe.models.estimators import GAMEstimator, GLMEstimator, load_estimator
    X, y = _poisson_data(6000)
    grid = pd.DataFrame({"x": np.linspace(-2, 2, 9)})
    for est in (GLMEstimator("poisson", ridge=1e-6), GAMEstimator("poisson", n_knots=6, lambdas=(1.0,))):
        est.fit(X, y)
        again = load_estimator(est.to_state())
        assert np.allclose(est.predict(grid), again.predict(grid))


# ----------------------------------------------------------------- unknowns
def test_encoder_unknown_falls_to_parent():
    from algoe.features.encoders import LevelEncoder
    train = pd.DataFrame({"pool_key": ["A|pre"] * 50 + ["B|pre"] * 50 + ["C|live"] * 50,
                          "family_phase": ["goal|pre"] * 100 + ["goal|live"] * 50,
                          "t": [1.0] * 50 + [3.0] * 50 + [10.0] * 50})
    enc = LevelEncoder("pool_key", ("family_phase",), prior=10.0).fit(train, "t")
    test = pd.DataFrame({"pool_key": ["A|pre", "Z|pre", "Z|nowhere"],
                         "family_phase": ["goal|pre", "goal|pre", "corner|nowhere"]})
    level, known = enc.transform(test)
    parent = enc.tables["family_phase"]["goal|pre"] - enc.global_mean
    assert known.tolist() == [1.0, 0.0, 0.0]
    assert abs(level[1] - parent) < 1e-12          # unseen key: its family level
    assert abs(level[2]) < 1e-12                   # unseen everything: the global level


def test_taxonomy_places_unknown_codes():
    from algoe.core.taxonomy import PoolTaxonomy
    tax = PoolTaxonomy()
    known = tax.resolve("HILO")
    new = tax.resolve("NHILO")
    assert "HILO" not in tax.inferred_codes()
    assert "NHILO" in tax.inferred_codes()
    assert new.family == known.family and new.priceable
    odd = tax.resolve("ZZ9")                        # nonsense must not raise
    assert isinstance(odd.priceable, bool)


def test_pool_rules_select_by_market():
    from algoe.core.taxonomy import PoolTaxonomy, resolve_pools
    tax = PoolTaxonomy()
    codes = ["HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "CRS", "TTG", "AGS", "NTS3", "NHILO"]
    lines = resolve_pools(["@line_markets", "@three_way"], codes, tax)
    assert set(lines) == {"HILO", "HDC", "CHLO", "FHDC", "HAD", "FHAD", "NHILO"}   # a new total joins by itself
    assert set(resolve_pools(["HILO", "CRS"], codes, tax)) == {"HILO", "CRS"}
    assert resolve_pools([], codes, tax) == sorted(codes)                           # [] = every pool
    try:
        resolve_pools(["@lines"], codes, tax)
        raise AssertionError("accepted an unknown rule")
    except ValueError:
        pass


def test_live_panel_keeps_the_pools_training_kept():
    from algoe.data.panel import LivePanelBuilder
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        names = ["HILO", "CRS", "AGS", "HAD", "NHILO"]
        odds = pd.DataFrame({"pool_id": range(5), "pool_name": names})
        inv = pd.DataFrame({"pool_id": range(5), "pool_name": names, "turnover": [1.0] * 5})
        o, i = LivePanelBuilder(s)._in_scope(odds, inv)
        assert sorted(o["pool_name"]) == sorted(i["pool_name"]) == ["HAD", "HILO", "NHILO"]


def test_split_by_dates_never_mixes_time():
    from algoe.core.exceptions import ConfigError
    from algoe.data.splits import DaySplit
    from algoe.settings import Settings
    days = list(pd.date_range("2024-06-01", "2026-09-15"))
    sp = DaySplit.from_dates(days, "2025-07-01", "2026-07-01")
    assert sp.train[-1] == pd.Timestamp("2025-06-30") and sp.val[0] == pd.Timestamp("2025-07-01")
    assert sp.val[-1] == pd.Timestamp("2026-06-30") and sp.test[0] == pd.Timestamp("2026-07-01")
    assert max(sp.train) < min(sp.val) and max(sp.val) < min(sp.test)
    assert len(sp.train) + len(sp.val) + len(sp.test) == len(days)
    s = Settings()
    for item in ('window.start="2024-06-01"', 'window.end="2026-09-15"', 'window.val_start="2025-07-01"',
                 'window.test_start="2026-07-01"'):
        s.set(item)
    s.check()
    assert DaySplit.for_window(days, s.window) == sp
    s.set('window.test_start="2025-01-01"')                     # test before val: refused
    try:
        s.check()
        raise AssertionError("accepted test_start before val_start")
    except ConfigError:
        pass


# --------------------------------------------------------------- validation
def test_validation_nulls_sentinels_and_fills():
    from algoe.core.validation import validate
    from algoe.data.panel import PANEL_CONTRACT
    t = pd.Timestamp("2026-07-01 20:00")
    f = pd.DataFrame({"bucket": [t, t, t], "match_id": [1, 1, 1], "pool_id": [10, 10, 10],
                      "line_id": [1, 1, 1], "combination_id": [1, 2, 2],
                      "pool_name": ["HILO", None, None], "odds": [1.9, 9999.0, 2.0],
                      "turnover": [100.0, -5.0, 50.0]})
    out, rep = validate(f, PANEL_CONTRACT)
    assert rep.duplicate_keys >= 1
    row = out[out["combination_id"] == 2].iloc[0]
    assert pd.isna(out.loc[out["odds"] > 1000, "odds"]).all() if (out["odds"] > 1000).any() else True
    assert (out["turnover"] >= 0).all()
    assert str(row["pool_name"]) == "UNKNOWN"
    assert not (pd.to_numeric(out["odds"], errors="coerce") == 9999.0).any()


def test_pool_closing_on_the_boundary_leaves_the_board():
    from algoe.data.panel import mark_forecastable
    T = pd.Timestamp("2026-07-10 21:20")
    f = pd.DataFrame({"bucket": [T] * 3, "is_inplay": [True] * 3, "mins_to_ko": [-110.0] * 3,
                      "priced_before": [True] * 3, "odds": [1.9] * 3,
                      "close_time": [T, T + pd.Timedelta(minutes=2), pd.NaT]})
    # closed at 21:20:00 exactly: no money can arrive in [21:20, 21:25); closing at 21:22: still open at T
    assert mark_forecastable(f, 360)["forecastable"].tolist() == [False, True, True]


def test_live_pool_close_times():
    from types import SimpleNamespace
    from algoe.data.panel import LivePanelBuilder
    T = pd.Timestamp("2026-07-10 21:20")
    odds = pd.DataFrame({"pool_id": [1, 2, 3, 4], "match_id": [9, 9, 9, 8],
                         "pool_name": ["HILO", "HDC", "ETHILO", "HILO"],
                         "effective_datetime": [T - pd.Timedelta(minutes=m) for m in (30, 30, 30, 3)]})
    none = pd.DataFrame(columns=["pool_id", "start_sell_time"])

    def close_of(ap, finished=None):
        out = LivePanelBuilder._pools(SimpleNamespace(active_pools=ap), odds, none, 5, T, finished)
        return dict(zip(out["pool_id"].astype(int), out["close_time"]))

    # nothing has a close time yet (every pool open) - must not raise, everything stays open
    ap = pd.DataFrame({"match_id": [9, 9, 9, 8], "pool_id": [1, 2, 3, 4], "close_time": [pd.NaT] * 4})
    assert all(pd.isna(v) for v in close_of(ap).values())
    # a close the source lists is used; a pool it no longer lists closes after its last price
    ap2 = pd.DataFrame({"match_id": [9, 9, 9], "pool_id": [1, 2, 3], "close_time": [T, pd.NaT, pd.NaT]})
    c = close_of(ap2)
    assert c[1] == T and pd.isna(c[2]) and c[4] == T - pd.Timedelta(minutes=2)
    # full-time result published: the 90-minute pools close now, extra time stays open
    c = close_of(ap, finished={9})
    assert c[1] == T and c[2] == T and pd.isna(c[3]) and pd.isna(c[4])


# ----------------------------------------------------------------- nowcast
def test_nowcast_moves_with_the_money():
    from algoe.realtime.nowcast import BucketNowcaster
    nc = BucketNowcaster(prior_minutes=2.0, bucket_minutes=5.0)
    assert abs(nc.update([100.0], [0.0], 0.0).remaining[0] - 100.0) < 1e-9    # nothing seen: the forecast
    hot = nc.update([100.0], [100.0], 1.0)            # a whole bucket's money in the first minute
    assert abs(hot.remaining[0] - (100 / 5 * 2 + 100) / 3 * 4) < 1e-9 and hot.hot[0] > 1
    cold = nc.update([100.0], [0.0], 4.0)             # four quiet minutes
    assert cold.remaining[0] < 20.0 and cold.hot[0] < 1


# ---------------------------------------------------------------- settings
def test_settings_reject_unknown_keys():
    from algoe.core.exceptions import ConfigError
    from algoe.settings import Settings
    s = Settings()
    s.set('paths.data_dir="C:\\\\data\\\\Raw_Data"')
    assert s.paths.data_dir.endswith("Raw_Data")
    for bad in ("optimizer.not_a_knob=1", "nosection.key=1"):
        try:
            s.set(bad)
            raise AssertionError("accepted " + bad)
        except ConfigError:
            pass
    s.set("turnover.tweedie_power=3")
    try:
        s.check()
        raise AssertionError("accepted tweedie_power=3")
    except ConfigError:
        pass


# ------------------------------------------------------------- model store
def test_model_store_guards():
    from algoe.core.exceptions import RegistryError
    from algoe.registry.model_store import ModelStore
    with tempfile.TemporaryDirectory() as tmp:
        sel = lambda v: {"selection": {"metric": "deviance", "days": ["2026-07-10"], "deviance": v}}  # noqa: E731
        v4 = ModelStore(tmp, "turnover", feature_version=4)
        v4.save("a", {"w": 1}, sel(10.0))
        v4.promote("a", "first")
        assert v4.load("a")[0] == {"w": 1}
        try:
            ModelStore(tmp, "turnover", feature_version=5).load("a")
            raise AssertionError("served a bundle built on other features")
        except RegistryError:
            pass
        v5 = ModelStore(tmp, "turnover", feature_version=5)
        v5.save("b", {"w": 2}, sel(50.0))
        assert v5.promote_if_better("b", "deviance", 50.0, 100.0)       # old champion is stale
        v5.save("c", {"w": 3}, sel(60.0))
        assert not v5.promote_if_better("c", "deviance", 60.0, 100.0)   # same features, worse
        with open(Path(tmp) / "turnover" / "b" / "bundle.pkl", "ab") as fh:
            fh.write(b"tampered")
        try:
            v5.load("b")
            raise AssertionError("served a tampered bundle")
        except RegistryError:
            pass


# ----------------------------------------------------------------- monitor
def test_psi_is_zero_on_same_distribution():
    from algoe.monitoring.monitor import Monitor
    from algoe.settings import Settings
    rng = np.random.default_rng(5)

    def sample(n, zero_share):
        v = rng.exponential(3.0, size=n)
        v[rng.random(n) < zero_share] = 0.0
        return pd.DataFrame({"money": np.log1p(v)})
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        mon = Monitor(s)
        ref = mon.feature_reference(sample(50000, 0.7))
        same = mon.drift(ref, sample(20000, 0.7))["features"][0]["psi"]
        moved = mon.drift(ref, sample(20000, 0.4))["features"][0]["psi"]
        assert same < 0.02, same
        assert moved > 0.1, moved


# ----------------------------------------------------------------- leakage
def test_goal_pulse_ignores_later_events():
    from algoe.features.engineer import FeatureEngineer
    from algoe.settings import Settings
    with tempfile.TemporaryDirectory() as tmp:
        s = Settings()
        s.set('paths.work_dir="{}"'.format(Path(tmp).as_posix()))
        fe = FeatureEngineer(s)
        T = pd.Timestamp("2026-07-01 20:05")
        m = pd.DataFrame({"match_id": [1, 1], "bucket": [T, T + pd.Timedelta(minutes=5)]})
        # provider 1 has more goals before T, provider 2 more over the whole match: choosing a
        # provider by its whole-match count would let the goals after T change the pulse at T
        at = [pd.Timestamp("2026-07-01 " + h) for h in ("20:01", "20:03", "20:04", "20:07", "20:08")]
        ev = pd.DataFrame({"match_id": [1] * 5, "home_or_away": [1, 2, 1, 2, 1], "incident_type": [27] * 5,
                           "provider_id": [1, 1, 2, 2, 2], "incident_datetime": at})
        full = fe._group_events(m.copy(), ev)
        known_at_T = fe._group_events(m.copy(), ev[ev["incident_datetime"] < T])
        cols = ["goal_p3", "goal_p10", "goals_so_far"]
        assert np.allclose(full.loc[0, cols].to_numpy(dtype=float), known_at_T.loc[0, cols].to_numpy(dtype=float))


# --------------------------------------------------------------------- cli
def test_cli_parses_every_command():
    from algoe.cli import build_parser
    p = build_parser()
    for cmd in ("selftest", "check-data", "build-panel", "build-features", "train-turnover", "train-probability",
                "backtest", "parity", "live", "monitor", "models", "nightly"):
        assert callable(p.parse_args([cmd]).func), cmd


def test_selftest_passes():
    if os.environ.get("ALGOE_SLOW") != "1":
        return
    from algoe.selftest import run_selftest
    ck, _ = run_selftest()
    assert not ck.failed, ck.table()


# ------------------------------------------------------------------ runner
if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<48} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<48} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
