"""
Data Validation

Every frame that crosses a layer boundary is checked against a Contract:
which columns must exist, what type they are, what range is plausible, and
what to do when a value is not. The answer is always explicit and always
counted, so "the model got worse" can be traced to "30% of true_odds went
missing on 14 Sep" instead of being guessed at.

    ColumnRule(name, kind, required, nullable, lo, hi, allowed, sentinels, on_bad, fill)

``on_bad`` is what happens to a value that fails its rule:

    "null"    set it to NA (the default; downstream fill policy decides)
    "clip"    clip into [lo, hi]
    "fill"    replace with ``fill``
    "drop"    drop the whole row
    "error"   raise DataError

``sentinels`` are feed values that mean "unknown" rather than a number -
HKJC writes -1 for a score it does not have and 9999 for a suspended price.
They are converted to NA before any range check so a -1 is never mistaken
for a real (if impossible) value.

Unknown categories (a pool code or a league never seen before) are not
errors. They are counted and reported so the taxonomy can learn them; the
row itself flows on and is handled by the hierarchical fallbacks in
features/encoders.py.

Change Log:
-----------
2026-09-30      Initialize
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .exceptions import DataError
from .logging import get_logger

logger = get_logger(__name__)

KINDS = ("int", "float", "str", "datetime", "bool")


@dataclass(frozen=True)
class ColumnRule:
    name: str
    kind: str = "float"
    required: bool = True
    nullable: bool = True
    lo: Optional[float] = None
    hi: Optional[float] = None
    allowed: Optional[Tuple[str, ...]] = None
    sentinels: Tuple = ()
    on_bad: str = "null"
    fill: object = None
    max_null_ratio: float = 1.0         # above this the report raises a WARN


@dataclass
class Contract:
    name: str
    rules: Sequence[ColumnRule]
    key: Sequence[str] = ()
    unique_key: bool = False

    def rule(self, column: str) -> Optional[ColumnRule]:
        for r in self.rules:
            if r.name == column:
                return r
        return None


@dataclass
class ColumnReport:
    column: str
    present: bool
    null_before: int = 0
    sentinel: int = 0
    out_of_range: int = 0
    unknown: int = 0
    action: str = ""
    null_after: int = 0

    def to_dict(self) -> dict:
        return dict(self.__dict__)


@dataclass
class QualityReport:
    contract: str
    rows_in: int
    rows_out: int = 0
    columns: List[ColumnReport] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    unknown_values: Dict[str, List[str]] = field(default_factory=dict)
    duplicate_keys: int = 0

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict:
        return {
            "contract": self.contract, "rows_in": self.rows_in, "rows_out": self.rows_out,
            "ok": self.ok, "errors": self.errors, "warnings": self.warnings,
            "duplicate_keys": self.duplicate_keys, "unknown_values": self.unknown_values,
            "columns": [c.to_dict() for c in self.columns],
        }

    def log(self, level_ok: str = "info") -> None:
        head = "[{}] {} rows in -> {} out".format(self.contract, f"{self.rows_in:,}", f"{self.rows_out:,}")
        bad = [c for c in self.columns if c.sentinel or c.out_of_range or c.unknown or not c.present]
        detail = "; ".join(
            "{}{}{}{}{}".format(
                c.column,
                " MISSING" if not c.present else "",
                " sentinel={}".format(c.sentinel) if c.sentinel else "",
                " out_of_range={}".format(c.out_of_range) if c.out_of_range else "",
                " unknown={}".format(c.unknown) if c.unknown else "",
            ) for c in bad[:12])
        getattr(logger, level_ok)("%s%s", head, (" | " + detail) if detail else "",
                                  extra={"data": self.to_dict()})
        for w in self.warnings:
            logger.warning("[%s] %s", self.contract, w)
        for e in self.errors:
            logger.error("[%s] %s", self.contract, e)


def _coerce(series: pd.Series, kind: str) -> pd.Series:
    if kind == "int":
        return pd.to_numeric(series, errors="coerce").astype("Float64").round().astype("Int64")
    if kind == "float":
        if pd.api.types.is_datetime64_any_dtype(series):
            # A seconds counter the extraction wrote as nanoseconds since the
            # epoch (HKJC_Parameters.TimeInSecond) - the integer is the value.
            return series.astype("int64").astype("float64").where(series.notna())
        return pd.to_numeric(series, errors="coerce").astype("float64")
    if kind == "str":
        return series.astype("string").str.strip()
    if kind == "datetime":
        return pd.to_datetime(series, errors="coerce")
    if kind == "bool":
        if series.dtype == bool:
            return series
        low = series.astype("string").str.strip().str.lower()
        return low.map({"true": True, "1": True, "false": False, "0": False}).astype("boolean")
    raise ValueError("unknown column kind {!r}".format(kind))


def validate(frame: pd.DataFrame, contract: Contract,
             known: Optional[Dict[str, Iterable[str]]] = None,
             raise_on_error: bool = False) -> Tuple[pd.DataFrame, QualityReport]:
    """Check and clean ``frame`` against ``contract``. Returns (clean, report).

    ``known`` maps a categorical column to the values seen before; anything
    else is reported under ``unknown_values`` (and kept).
    """
    report = QualityReport(contract=contract.name, rows_in=0 if frame is None else len(frame))
    if frame is None:
        report.errors.append("frame is None")
        if raise_on_error:
            raise DataError("{}: frame is None".format(contract.name))
        return pd.DataFrame(), report

    out = frame.copy()
    drop_mask = np.zeros(len(out), dtype=bool)
    for rule in contract.rules:
        cr = ColumnReport(column=rule.name, present=rule.name in out.columns)
        report.columns.append(cr)
        if not cr.present:
            if rule.required:
                report.errors.append("required column {!r} is missing".format(rule.name))
            else:
                out[rule.name] = pd.NA if rule.fill is None else rule.fill
                cr.action = "added (optional, absent)"
            continue

        col = _coerce(out[rule.name], rule.kind)
        cr.null_before = int(col.isna().sum())

        if rule.sentinels:
            is_sent = col.isin(list(rule.sentinels)) & col.notna()
            cr.sentinel = int(is_sent.sum())
            if cr.sentinel:
                col = col.mask(is_sent)

        if rule.kind in ("int", "float") and (rule.lo is not None or rule.hi is not None):
            num = col.astype("float64")
            bad = pd.Series(False, index=col.index)
            if rule.lo is not None:
                bad |= num < rule.lo
            if rule.hi is not None:
                bad |= num > rule.hi
            bad &= col.notna()
            cr.out_of_range = int(bad.sum())
            if cr.out_of_range:
                if rule.on_bad == "clip":
                    col = col.clip(lower=rule.lo, upper=rule.hi)
                    cr.action = "clipped"
                elif rule.on_bad == "fill":
                    col = col.mask(bad, rule.fill)
                    cr.action = "filled"
                elif rule.on_bad == "drop":
                    drop_mask |= bad.to_numpy()
                    cr.action = "dropped rows"
                elif rule.on_bad == "error":
                    report.errors.append("{}: {} value(s) outside [{}, {}]".format(
                        rule.name, cr.out_of_range, rule.lo, rule.hi))
                else:
                    col = col.mask(bad)
                    cr.action = "nulled"

        if rule.kind == "str":
            if rule.allowed is not None:
                unk = col.notna() & ~col.isin(list(rule.allowed))
                cr.unknown = int(unk.sum())
            if known and rule.name in known:
                seen = set(str(v) for v in known[rule.name])
                vals = col.dropna().unique()
                new = sorted(str(v) for v in vals if str(v) not in seen)
                if new:
                    report.unknown_values[rule.name] = new[:50]
                    cr.unknown = max(cr.unknown, int(col.isin(new).sum()))

        if not rule.nullable:
            miss = col.isna()
            if miss.any():
                if rule.fill is not None:
                    col = col.fillna(rule.fill)
                    cr.action = (cr.action + ", " if cr.action else "") + "filled nulls"
                else:
                    drop_mask |= miss.to_numpy()
                    cr.action = (cr.action + ", " if cr.action else "") + "dropped null rows"

        cr.null_after = int(col.isna().sum())
        ratio = cr.null_after / max(len(col), 1)
        if ratio > rule.max_null_ratio:
            report.warnings.append("{} is {:.1%} missing (threshold {:.0%})".format(
                rule.name, ratio, rule.max_null_ratio))
        out[rule.name] = col

    if drop_mask.any():
        out = out.loc[~drop_mask]

    if contract.key and all(k in out.columns for k in contract.key):
        dup = out.duplicated(list(contract.key), keep="last")
        report.duplicate_keys = int(dup.sum())
        if report.duplicate_keys:
            if contract.unique_key:
                out = out.loc[~dup]
                report.warnings.append("{} duplicate key row(s) on {} removed (kept last)".format(
                    report.duplicate_keys, list(contract.key)))
            else:
                report.warnings.append("{} duplicate key row(s) on {}".format(
                    report.duplicate_keys, list(contract.key)))

    report.rows_out = len(out)
    if raise_on_error and report.errors:
        raise DataError("{}: {}".format(contract.name, "; ".join(report.errors)))
    return out.reset_index(drop=True), report


def fill_numeric(frame: pd.DataFrame, fills: Dict[str, float],
                 clips: Optional[Dict[str, Tuple[Optional[float], Optional[float]]]] = None) -> pd.DataFrame:
    """Apply a per-column NA fill and clip, in place. Returns the frame."""
    for col, value in fills.items():
        if col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce").fillna(value)
    for col, (lo, hi) in (clips or {}).items():
        if col in frame.columns:
            frame[col] = frame[col].clip(lower=lo, upper=hi)
    return frame


def finite_or(values, default: float) -> np.ndarray:
    """Replace NaN / inf with ``default``."""
    arr = np.asarray(values, dtype="float64")
    return np.where(np.isfinite(arr), arr, default)
