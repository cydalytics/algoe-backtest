"""
Probability Calibrator

What the desk believes each selection is worth - the p in
E[GM] = sum T x (1 - O x p) - and whether that belief means what it says.

SOURCES (each renormalised so a line's sides sum to one):

    hkjc_true   1 / HKJC true odds                        the MVP rule
    market      median bookmaker price, de-margined       the outside view
    poisson     HKJC's TG/SUP through our pricer,         their parameters,
                in-play score applied                     our maths
    demargin    HKJC's public odds, margin removed        the offer itself

METHODS (all fitted on train days, chosen on validation days, reported on
test days; all but ``raw`` map in logit space):

    raw:<s>          p = source                          the baseline to beat
    platt:<s>        logit p' = a + b logit p            b < 1 fixes over-confidence
    beta:<s>         logit p' = a + b ln p - c ln(1-p)   asymmetric (favourite-longshot)
    isotonic:<s>     monotone map (PAV)                  no shape assumed
    logit_pool       logit p' = w0 + sum_s w_s logit p_s  the roadmap's
                                                          p = b0 p_HKJC + b1 p_Market,
                                                          done where probabilities add
    contextual       logit_pool + phase / family / odds-band / clock interactions

    stack:<layers>   three layers, each fitted on top of the one before (its logit is the next
                     layer's offset), so what each insight adds is measured on its own:
        trader       HKJC's own view - true odds, its TG/SUP through our pricer, its de-margined
                     prices - calibrated by phase, bet type and price (favourite-longshot)
        market       how far to move from that toward the bookmakers' consensus:
                     a * (logit p_market - logit p_trader), a by phase, bet type, quote age
        customer     what the money says beyond both: weight of money (a side's share of its
                     line's money against its price), ticket size against the pool's, how much
                     money it is, and how the price has been moving
                     stack:trader, stack:trader+market and stack:trader+market+customer each get a
                     leaderboard row; metadata["layers"] reports each layer's gain.

Interactions use the best HKJC source a row has - true odds, else Poisson, else de-margined - so a
history without true odds still gets them.

After mapping, the sides of every line are renormalised so the belief the
optimiser prices against is coherent.

OUTCOMES are read from the money actually paid (engineer._outcome): soft
label (r + 1) / 2 for full / half win or loss; pushes carry no information
and are dropped. Every settled selection counts once however long it
traded (settings.probability.weight = "selection"), so a pre-match line that
sat on the board for six hours does not outvote an in-play one.

Change Log:
-----------
2026-09-30      Initialize
2026-10-01      Feature version on every bundle; refit_for_serving; stacked trader / market / customer
                layers; interactions on the best HKJC source (they were empty without true odds)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from ..core.exceptions import ModelError
from ..core.io import write_parquet
from ..core.logging import get_logger, log_step
from ..data.panel import KEY
from ..data.splits import DaySplit
from ..evaluation.metrics import calibration_bins, probability_scores
from ..features.engineer import FeatureEngineer, FeatureSet
from ..features.store import FEATURE_VERSION, FeatureStore
from ..pricing.panel_pricing import price_rows_at_hkjc
from ..pricing.pricer import Conventions
from ..registry.model_store import ModelStore
from .estimators import GLMEstimator

logger = get_logger(__name__)

SOURCES = ("hkjc_true", "market", "poisson", "demargin")
HKJC_SOURCES = ("hkjc_true", "poisson", "demargin")          # best first
SINGLE = ("platt", "beta", "isotonic")
STACK = ("trader", "market", "customer")
STACK_NAMES = tuple("stack:" + "+".join(STACK[:k]) for k in range(1, len(STACK) + 1))
STACK_MONEY = "stack_money:" + "+".join(STACK)
FAMILY_SLOPES = ("goal_total", "goal_hdc", "corner_total", "corner_hdc", "goal_1x2")
EPS = 1e-4


def _logit(p):
    p = np.clip(np.asarray(p, dtype="float64"), EPS, 1 - EPS)
    return np.log(p / (1 - p))


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def _pav(x, y, w):
    order = np.argsort(x, kind="mergesort")
    xs, ys, ws = x[order], y[order], w[order]
    blocks = []                          # [sum_wy, sum_w, x_hi]
    for xv, yv, wv in zip(xs, ys, ws):
        blocks.append([yv * wv, wv, xv])
        while len(blocks) > 1 and blocks[-2][0] / blocks[-2][1] >= blocks[-1][0] / blocks[-1][1]:
            b = blocks.pop()
            blocks[-1][0] += b[0]
            blocks[-1][1] += b[1]
            blocks[-1][2] = b[2]
    xk = np.array([b[2] for b in blocks])
    yk = np.array([b[0] / b[1] for b in blocks])
    return xk, yk


class ProbabilityCalibrator:
    def __init__(self, settings, engineer: Optional[FeatureEngineer] = None, store: Optional[FeatureStore] = None,
                 model_store: Optional[ModelStore] = None):
        self.settings = settings
        self.engineer = engineer or FeatureEngineer(settings)
        self.store = store
        self.model_store = model_store or ModelStore(settings.paths.models, "probability", FEATURE_VERSION)
        o = settings.optimizer
        self.conventions = Conventions(o.settle_total, o.settle_handicap)
        self.fitted: Dict[str, dict] = {}
        self.champion = "raw:hkjc_true"
        self.leaderboard: List[dict] = []
        self.metadata: dict = {}
        self.version: Optional[str] = None

    # ============================================================ data
    def features_for_day(self, day, require_outcome: bool = True) -> FeatureSet:
        """Probability rows for one day (a date, or a DayData) with the in-play-correct poisson source."""
        cached_day = not hasattr(day, "sel")
        dd = self.store.get(day) if cached_day else day
        if dd.empty:
            return self.engineer.features_for_probability(dd, require_outcome)
        dd2 = type(dd)(dd.day, dd.sel.assign(p_poisson=self._poisson(dd, cache=cached_day)), dd.match, dd.pool)
        return self.engineer.features_for_probability(dd2, require_outcome)

    def _poisson(self, dd, cache: bool) -> np.ndarray:
        """HKJC's TG / SUP through our pricer for every forecastable row - in-play score applied, each line
        renormalised. Extra-time pools are left out: they settle on extra-time goals (the replication check)
        and the parameters are the 90 minutes'. Kept beside the day's features, because pricing every row
        is most of the time it takes to collect a year of settled selections."""
        sel = dd.sel
        keys = KEY + ["bucket"]
        path = self._poisson_path(dd.day) if cache else None
        if path is not None and path.exists():
            try:
                got = sel[keys].merge(pd.read_parquet(path), on=keys, how="left")["p_poisson"]
                if len(got) == len(sel):
                    return got.to_numpy(dtype="float64")
            except Exception as exc:                                    # noqa: BLE001
                logger.warning("poisson cache %s unreadable (%s); pricing again", path.name, exc)
        p = _renorm(sel, price_rows_at_hkjc(sel, dd.match, self.conventions, sel["forecastable"].to_numpy(dtype=bool)))
        if "segment" in sel.columns:
            p = np.where(sel["segment"].astype(str).to_numpy() == "ET", np.nan, p)
        if path is not None:
            out = sel.loc[np.isfinite(p), keys].assign(p_poisson=p[np.isfinite(p)])
            write_parquet(out.reset_index(drop=True), path)
        return p

    def _poisson_path(self, day):
        if self.store is None or not getattr(self.store, "enabled", True):
            return None
        c = self.conventions
        return self.store.root / "belief" / "{:%Y-%m-%d}.poisson.{}-{}.parquet".format(
            pd.Timestamp(day), c.settle_total, c.settle_handicap)

    def predict_for_day(self, day, method: Optional[str] = None) -> np.ndarray:
        """Belief for every row of day.sel (NaN where the price is not live or not priceable)."""
        dd = day if hasattr(day, "sel") else self.store.get(day)
        out = np.full(len(dd.sel), np.nan)
        if dd.empty:
            return out
        fs = self.features_for_day(dd, require_outcome=False)
        if len(fs):
            out[fs.keys["_row"].to_numpy()] = self.predict_true_prob(fs, method)
        return out

    def _day_cap(self, n_days: int) -> int:
        """Settled selections to keep from one day, so n_days fit in probability.max_fit_rows."""
        return int(max(500, min(60000, self.settings.probability.max_fit_rows // max(n_days, 1))))

    def _collect(self, days: Sequence, cap_per_day: int = 60000, seed: int = 7) -> Optional[FeatureSet]:
        rng = np.random.default_rng(seed)
        parts = []
        for d in days:
            fs = self.features_for_day(d)
            if not len(fs):
                continue
            if len(fs) > cap_per_day:
                fs = fs.subset(rng.random(len(fs)) < cap_per_day / len(fs))
            parts.append(fs)
        return FeatureSet.concat(parts) if parts else None

    # =================================================== train (systematic)
    def train_platt_hkjc_true(self, fs): return self._train_single("platt", "hkjc_true", fs)
    def train_platt_market(self, fs): return self._train_single("platt", "market", fs)
    def train_platt_poisson(self, fs): return self._train_single("platt", "poisson", fs)
    def train_platt_demargin(self, fs): return self._train_single("platt", "demargin", fs)
    def train_beta_hkjc_true(self, fs): return self._train_single("beta", "hkjc_true", fs)
    def train_beta_market(self, fs): return self._train_single("beta", "market", fs)
    def train_isotonic_hkjc_true(self, fs): return self._train_single("isotonic", "hkjc_true", fs)
    def train_isotonic_market(self, fs): return self._train_single("isotonic", "market", fs)

    def train_logit_pool(self, fs: FeatureSet) -> dict:
        X = self._pool_design(fs.keys)
        m = GLMEstimator("binomial", ridge=self.settings.probability.ridge * 1e-3).fit(X, fs.y, weight=fs.weight)
        self.fitted["logit_pool"] = {"kind": "glm", "model": m.to_state(), "design": "pool"}
        logger.info("logit_pool weights: %s", {k: round(v, 3) for k, v in m.coefficients().items()})
        return self.fitted["logit_pool"]

    def train_contextual(self, fs: FeatureSet) -> dict:
        X = self._context_design(fs)
        m = GLMEstimator("binomial", ridge=self.settings.probability.ridge * 1e-2).fit(X, fs.y, weight=fs.weight)
        self.fitted["contextual"] = {"kind": "glm", "model": m.to_state(), "design": "context"}
        return self.fitted["contextual"]

    def _train_single(self, method: str, source: str, fs: FeatureSet) -> Optional[dict]:
        p = fs.keys["p_" + source].to_numpy(dtype="float64")
        ok = np.isfinite(p)
        name = "{}:{}".format(method, source)
        if ok.sum() < self.settings.probability.min_fit_rows:
            logger.warning("%s skipped: %d rows with the source (need %d)", name, int(ok.sum()),
                           self.settings.probability.min_fit_rows)
            return None
        y, w = fs.y[ok], fs.weight[ok]
        if method == "isotonic":
            xk, yk = _pav(p[ok], y, w)
            self.fitted[name] = {"kind": "isotonic", "x": xk, "y": np.clip(yk, EPS, 1 - EPS)}
        else:
            lp = _logit(p[ok])
            X = pd.DataFrame({"lp": lp}) if method == "platt" else \
                pd.DataFrame({"lnp": np.log(np.clip(p[ok], EPS, 1)), "ln1p": np.log(np.clip(1 - p[ok], EPS, 1))})
            m = GLMEstimator("binomial", ridge=1e-6).fit(X, y, weight=w)
            self.fitted[name] = {"kind": "glm", "model": m.to_state(), "design": method}
            logger.info("%s: %s", name, {k: round(v, 4) for k, v in m.coefficients().items()})
        return self.fitted[name]

    # ======================================================== design
    @staticmethod
    def _pool_design(keys: pd.DataFrame) -> pd.DataFrame:
        X = {}
        for s in SOURCES:
            p = keys["p_" + s].to_numpy(dtype="float64")
            has = np.isfinite(p)
            X["logit_" + s] = np.where(has, _logit(np.where(has, p, 0.5)), 0.0)
            X["has_" + s] = has.astype("float64")
        return pd.DataFrame(X)

    @staticmethod
    def _best_hkjc(keys: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """The best HKJC belief each row has, as a logit: true odds, else Poisson on its TG/SUP, else its
        de-margined price. (logit, has any)."""
        z = np.zeros(len(keys))
        has = np.zeros(len(keys), dtype=bool)
        for s in HKJC_SOURCES[::-1]:                      # later (better) sources overwrite
            p = keys["p_" + s].to_numpy(dtype="float64")
            ok = np.isfinite(p)
            z = np.where(ok, _logit(np.where(ok, p, 0.5)), z)
            has |= ok
        return z, has

    @staticmethod
    def _col(c: pd.DataFrame, name: str) -> np.ndarray:
        return c[name].to_numpy(dtype="float64") if name in c.columns else np.zeros(len(c))

    def _context_design(self, fs: FeatureSet) -> pd.DataFrame:
        X = self._pool_design(fs.keys)
        c = fs.X
        lh, _ = self._best_hkjc(fs.keys)
        lm = X["logit_market"].to_numpy()
        for col in ("inplay", "minute", "pre_ko", "rank_0", "log_odds", "book_margin", "side_home_over",
                    "log_odds_age"):
            if col in c.columns:
                X[col] = c[col].to_numpy(dtype="float64")
        ip = self._col(c, "inplay")
        X["lh_x_inplay"] = lh * ip
        X["lm_x_inplay"] = lm * ip
        X["lh_x_abs"] = lh * np.abs(lh)                   # favourite-longshot curvature
        for f in FAMILY_SLOPES:
            col = "fam_" + f
            if col in c.columns:
                X[col] = c[col].to_numpy(dtype="float64")
                X["lh_x_" + f] = lh * c[col].to_numpy(dtype="float64")
        return X

    # --------------------------------------------------------- stacked layers
    def _trader_design(self, fs: FeatureSet) -> pd.DataFrame:
        """HKJC's own view, calibrated: its sources, and its best logit's slope by phase, bet type and
        price level (curvature = favourite-longshot)."""
        keys, c = fs.keys, fs.X
        X = {}
        for s in HKJC_SOURCES:
            p = keys["p_" + s].to_numpy(dtype="float64")
            has = np.isfinite(p)
            X["logit_" + s] = np.where(has, _logit(np.where(has, p, 0.5)), 0.0)
            X["has_" + s] = has.astype("float64")
        z, _ = self._best_hkjc(keys)
        for col in ("inplay", "minute", "pre_ko", "rank_0", "log_odds_age", "book_margin", "side_home_over"):
            X[col] = self._col(c, col)
        X["z_x_inplay"] = z * X["inplay"]
        X["z_x_abs"] = z * np.abs(z)
        for f in FAMILY_SLOPES:
            fam = self._col(c, "fam_" + f)
            X["fam_" + f] = fam
            X["z_x_" + f] = z * fam
        return pd.DataFrame(X)

    def _market_design(self, fs: FeatureSet, eta_trader: np.ndarray) -> pd.DataFrame:
        """How far to move from the trader layer toward the market's consensus, and when."""
        c = fs.X
        p = fs.keys["p_market"].to_numpy(dtype="float64")
        has = np.isfinite(p)
        gap = np.where(has, _logit(np.where(has, p, 0.5)) - eta_trader, 0.0)
        X = {"gap": gap, "has_market": has.astype("float64"),
             "gap_x_inplay": gap * self._col(c, "inplay"), "gap_x_age": gap * self._col(c, "log_odds_age"),
             "gap_x_pre_ko": gap * self._col(c, "pre_ko")}
        for f in FAMILY_SLOPES:
            X["gap_x_" + f] = gap * self._col(c, "fam_" + f)
        return pd.DataFrame(X)

    def _customer_design(self, fs: FeatureSet) -> pd.DataFrame:
        """What the money says beyond HKJC and the market."""
        c = fs.X
        wom1, wom6 = self._col(c, "wom_l1"), self._col(c, "wom_l6")
        liq = self._col(c, "line_money_l6") / 10.0
        ip = self._col(c, "inplay")
        return pd.DataFrame({"wom_l1": wom1, "wom_l6": wom6, "rel_stake": self._col(c, "s_rel_stake_l1"),
                             "liquidity": liq, "odds_move_5": self._col(c, "odds_move_5"),
                             "odds_move_15": self._col(c, "odds_move_15"), "wom6_x_liquidity": wom6 * liq,
                             "wom6_x_inplay": wom6 * ip, "wom1_x_inplay": wom1 * ip})

    def train_stack(self, fs: FeatureSet, by_money: bool = False) -> dict:
        """Fit trader, then market on top of it, then customer on top of both; register each depth.

        ``by_money`` weights every settled row by the money it took (stack_money:..., the full stack
        only): calibrated where the money is, which is what the optimiser's E[GM] sums over."""
        ridge = self.settings.probability.ridge * 1e-2
        weight = fs.keys["stake"].to_numpy(dtype="float64") if by_money else fs.weight
        layers = []
        offset = np.zeros(len(fs))
        for name, design in zip(STACK, (lambda: self._trader_design(fs), lambda: self._market_design(fs, offset),
                                        lambda: self._customer_design(fs))):
            X = design()
            m = GLMEstimator("binomial", ridge=ridge).fit(X, fs.y, weight=weight, offset=offset)
            layers.append({"name": name, "model": m.to_state()})
            offset = offset + m.eta(X)
            coef = m.coefficients()
            show = {k: round(v, 3) for k, v in coef.items() if k in ("intercept", "gap", "has_market", "wom_l1",
                                                                       "wom_l6", "rel_stake", "logit_hkjc_true",
                                                                       "logit_poisson", "logit_demargin")}
            logger.info("stack%s layer %s: %s", " (money-weighted)" if by_money else "", name, show)
        if by_money:
            self.fitted[STACK_MONEY] = {"kind": "stack", "layers": layers}
            return self.fitted[STACK_MONEY]
        for k, nm in enumerate(STACK_NAMES, start=1):
            self.fitted[nm] = {"kind": "stack", "layers": layers[:k]}
        return self.fitted[STACK_NAMES[-1]]

    def _stack_eta(self, fs: FeatureSet, fit: dict) -> np.ndarray:
        eta = np.zeros(len(fs))
        for layer in fit["layers"]:
            m = GLMEstimator.from_state(layer["model"])
            X = {"trader": lambda: self._trader_design(fs), "market": lambda: self._market_design(fs, eta),
                 "customer": lambda: self._customer_design(fs)}[layer["name"]]()
            eta = eta + m.eta(X)
        return eta

    # ======================================================= predict
    def predict_true_prob(self, fs: FeatureSet, method: Optional[str] = None) -> np.ndarray:
        """Calibrated, line-coherent probability per row; falls back to the raw source where needed."""
        method = method or self.champion
        keys = fs.keys
        base = keys["p_hkjc_true"].to_numpy(dtype="float64")
        fallback = np.where(np.isfinite(base), base, keys["p_demargin"].to_numpy(dtype="float64"))
        if method.startswith("raw:"):
            p = keys["p_" + method.split(":", 1)[1]].to_numpy(dtype="float64")
            return np.where(np.isfinite(p), p, fallback)
        fit = self.fitted.get(method)
        if fit is None:
            raise ModelError("calibration {!r} is not trained".format(method))
        if fit.get("kind") == "stack":
            p = _sigmoid(self._stack_eta(fs, fit))
            return _renorm_keys(keys, np.clip(p, EPS, 1 - EPS))
        if method in ("logit_pool", "contextual"):
            X = self._pool_design(keys) if method == "logit_pool" else self._context_design(fs)
            p = GLMEstimator.from_state(fit["model"]).predict(X)
        else:
            src = method.split(":", 1)[1]
            raw = keys["p_" + src].to_numpy(dtype="float64")
            ok = np.isfinite(raw)
            p = np.full(len(raw), np.nan)
            if fit["kind"] == "isotonic":
                p[ok] = np.interp(raw[ok], fit["x"], fit["y"])
            else:
                m = GLMEstimator.from_state(fit["model"])
                X = pd.DataFrame({"lp": _logit(raw[ok])}) if fit["design"] == "platt" else \
                    pd.DataFrame({"lnp": np.log(np.clip(raw[ok], EPS, 1)), "ln1p": np.log(np.clip(1 - raw[ok], EPS, 1))})
                p[ok] = m.predict(X)
            p = np.where(np.isfinite(p), p, fallback)
        return _renorm_keys(keys, np.clip(p, EPS, 1 - EPS))

    # ======================================================= train all
    def candidates(self) -> List[str]:
        out = ["raw:" + s for s in SOURCES]
        methods = self.settings.probability.methods
        for m in SINGLE:
            if m in methods:
                out += ["{}:{}".format(m, s) for s in ("hkjc_true", "market")]
        for m in ("logit_pool", "contextual"):
            if m in methods:
                out.append(m)
        if "stack" in methods:
            out += list(STACK_NAMES)
        if "stack_money" in methods:
            out.append(STACK_MONEY)
        return out

    def train_all(self, days: Sequence, store: Optional[FeatureStore] = None) -> dict:
        self.store = store or self.store
        if self.store is None:
            raise ModelError("train_all needs a FeatureStore")
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        split = DaySplit.for_window(usable, self.settings.window)
        with log_step(logger, "P1", "collect settled selections", split.describe()) as step:
            train = self._collect(split.train, self._day_cap(len(split.train)))
            val = self._collect(split.val, self._day_cap(len(split.val)))
            test = self._collect(split.test, self._day_cap(len(split.test)))
            if train is None or val is None or test is None:
                raise ModelError("not enough settled selections in one of train / val / test")
            step["result"] = "train {:,} val {:,} test {:,} rows; sources available (train): {}".format(
                len(train), len(val), len(test),
                {s: round(float(np.isfinite(train.keys["p_" + s]).mean()), 3) for s in SOURCES})
        market_cov = self._market_coverage(train)
        if market_cov:
            logger.info("market price coverage on train rows (bet type / phase / line: share of rows): %s",
                        "; ".join("{} {} {} {:.0%} of {:,}".format(r["family"], r["phase"], r["line"], r["share"],
                                                                     r["rows"]) for r in market_cov[:8]))
        with log_step(logger, "P2", "fit calibrators on train days") as step:
            for name in self.candidates():
                if name.startswith("raw:") or (name.startswith("stack:") and name != STACK_NAMES[0]):
                    continue                                   # one train_stack fits every depth
                try:
                    if name in ("logit_pool", "contextual"):
                        getattr(self, "train_" + name)(train)
                    elif name.startswith("stack:"):
                        self.train_stack(train)
                    elif name == STACK_MONEY:
                        self.train_stack(train, by_money=True)
                    else:
                        method, src = name.split(":")
                        getattr(self, "train_{}_{}".format(method, src))(train)
                except (ModelError, np.linalg.LinAlgError, ValueError, AttributeError) as exc:
                    logger.warning("%s skipped: %s", name, exc)
            step["result"] = "{} fitted".format(len(self.fitted))
        with log_step(logger, "P3", "choose on validation, report on test") as step:
            rows = []
            for name in self.candidates():
                if not name.startswith("raw:") and name not in self.fitted:
                    continue
                rv, rt = self._score(val, name), self._score(test, name)
                rows.append({"method": name, **{"val_" + k: v for k, v in rv.items()},
                             **{"test_" + k: v for k, v in rt.items()}})
            base = next(r for r in rows if r["method"] == "raw:hkjc_true")
            metric = "val_" + self.settings.probability.champion_metric
            best = min((r for r in rows if r.get(metric) is not None), key=lambda r: r[metric])
            self.champion = best["method"] if best[metric] < (base.get(metric) or np.inf) else "raw:hkjc_true"
            for r in rows:
                r["champion"] = r["method"] == self.champion
            rows.sort(key=lambda r: (r.get("test_log_loss") is None, r.get("test_log_loss") or 0))
            self.leaderboard = rows
            champ = next(r for r in rows if r["champion"])
            step["result"] = "champion {}: test log-loss {:.5f} vs raw {:.5f}, ECE {:.4f} vs {:.4f}".format(
                self.champion, champ["test_log_loss"], base["test_log_loss"],
                champ["test_ece"] or 0, base["test_ece"] or 0)
        layers = self._layer_gains()
        self.metadata = {"split": split.to_dict(), "champion": self.champion, "leaderboard": self.leaderboard,
                         "layers": layers, "market_coverage": market_cov,
                         "selection": {"metric": metric, "days": split.to_dict()["val"],
                                       metric: next(r[metric] for r in rows if r["champion"])},
                         "calibration_test": {m: calibration_bins(self.predict_true_prob(test, m), test.y,
                                                                  test.weight, 10)
                                              for m in ("raw:hkjc_true", self.champion)},
                         "cuts_test": self._cuts(test), "settings": self.settings.to_dict()["probability"]}
        return self.metadata

    @staticmethod
    def _market_coverage(fs: Optional[FeatureSet]) -> List[dict]:
        """Where the bookmakers' consensus exists: share of settled rows with a market price by bet type,
        phase and line (best line or other), biggest groups first - the market layer can only act there."""
        if fs is None or not len(fs):
            return []
        has = np.isfinite(fs.keys["p_market"].to_numpy(dtype="float64"))
        main = fs.X["rank_0"].to_numpy(dtype="float64") > 0 if "rank_0" in fs.X.columns else np.ones(len(fs), bool)
        df = pd.DataFrame({"family": fs.cuts["family"].astype(str).to_numpy(),
                           "phase": np.where(fs.cuts["phase"].astype(str).to_numpy() == "prematch", "pre-match",
                                             "in-play"),
                           "line": np.where(main, "best line", "other lines"), "has": has})
        g = df.groupby(["family", "phase", "line"], observed=True)["has"].agg(["mean", "size"]).reset_index()
        g = g.sort_values("size", ascending=False)
        return [{"family": r.family, "phase": r.phase, "line": r.line, "share": float(r["mean"]),
                 "rows": int(r["size"])} for _, r in g.iterrows()]

    def _layer_gains(self) -> List[dict]:
        """What each stacked layer adds: log-loss of the layer below minus its own (the trader layer
        against 1 / HKJC's price), on validation and test days."""
        lb = {r["method"]: r for r in self.leaderboard}
        prev = lb.get("raw:hkjc_true")
        out = []
        for name in STACK_NAMES:
            r = lb.get(name)
            if r is None or prev is None:
                continue

            def gain(k, a=prev, b=r):
                return None if a.get(k) is None or b.get(k) is None else float(a[k] - b[k])
            out.append({"layer": name.rsplit("+", 1)[-1].replace("stack:", ""), "method": name,
                        "val_log_loss": r.get("val_log_loss"), "test_log_loss": r.get("test_log_loss"),
                        "gain_val": gain("val_log_loss"), "gain_test": gain("test_log_loss")})
            prev = r
        if out:
            logger.info("belief layers (test log-loss gained): %s", ", ".join(
                "{} {:+.5f}".format(x["layer"], x["gain_test"] or 0.0) for x in out))
        return out

    def _score(self, fs: FeatureSet, method: str) -> dict:
        p = self.predict_true_prob(fs, method)
        out = probability_scores(p, fs.y, fs.weight)
        stake = fs.keys["stake"].to_numpy(dtype="float64")
        odds = fs.keys["odds"].to_numpy(dtype="float64")
        r = fs.keys["outcome"].to_numpy(dtype="float64")
        pay = np.select([r >= 0.99, r >= 0.49, r <= -0.99, r <= -0.49], [odds, 0.5 * odds + 0.5, 0.0, 0.5], 1.0)
        m = stake > 0
        if m.any():
            out["expected_margin"] = float(np.sum(stake[m] * (1 - odds[m] * p[m])) / np.sum(stake[m]))
            out["realised_margin"] = float(np.sum(stake[m] * (1 - pay[m])) / np.sum(stake[m]))
            # the optimiser's E[GM] is a sum over money: how good the belief is where the money is
            mw = probability_scores(p[m], fs.y[m], stake[m])
            out["money_log_loss"] = mw.get("log_loss")
            out["money_ece"] = mw.get("ece")
            out["margin_gap"] = out["expected_margin"] - out["realised_margin"]
        return out

    def _cuts(self, fs: FeatureSet) -> Dict[str, dict]:
        out = {}
        for dim in ("phase", "family"):
            vals = fs.cuts[dim].astype(str).to_numpy()
            for v in np.unique(vals):
                m = vals == v
                if m.sum() < 200:
                    continue
                sub = fs.subset(m)
                out["{}={}".format(dim, v)] = {meth: self._score(sub, meth)
                                               for meth in ("raw:hkjc_true", self.champion)}
        return out

    def refit_for_serving(self, days: Sequence) -> dict:
        """Refit the champion calibration on every day, test block included (see TurnoverForecaster)."""
        if self.champion.startswith("raw:"):
            return {"refit": False, "reason": "{} needs no fit".format(self.champion)}
        usable = [pd.Timestamp(d).normalize() for d in days if self.store.has(d) or not self.store.get(d).empty]
        with log_step(logger, "R", "refit {} for serving".format(self.champion),
                      "{}..{} ({} days)".format(usable[0].date(), usable[-1].date(), len(usable))) as step:
            fs = self._collect(usable, self._day_cap(len(usable)))
            if fs is None:
                raise ModelError("no settled selections to refit on")
            if self.champion in ("logit_pool", "contextual"):
                getattr(self, "train_" + self.champion)(fs)
            elif self.champion.startswith("stack:"):
                self.train_stack(fs)
            elif self.champion == STACK_MONEY:
                self.train_stack(fs, by_money=True)
            else:
                method, src = self.champion.split(":")
                getattr(self, "train_{}_{}".format(method, src))(fs)
            self.fitted = {self.champion: self.fitted[self.champion]}
            info = {"refit": True, "days": [str(usable[0].date()), str(usable[-1].date()), len(usable)],
                    "rows": int(len(fs))}
            self.metadata["serving_fit"] = info
            step["result"] = "{:,} settled selections".format(len(fs))
        return info

    # ===================================================== persistence
    def save(self, promote: bool = True) -> str:
        version = self.model_store.new_version(self.champion.replace(":", "-"))
        self.model_store.save(version, {"fitted": self.fitted, "champion": self.champion}, self.metadata)
        self.version = version
        if promote:
            rows = {r["method"]: r for r in self.leaderboard}
            metric = self.metadata["selection"]["metric"]
            if self.champion == "raw:hkjc_true":
                if self.model_store.champion() is None:
                    self.model_store.promote(version, "no calibration beat 1/true_odds; serving the raw source")
            else:
                self.model_store.promote_if_better(version, metric, rows[self.champion][metric],
                                                   rows["raw:hkjc_true"][metric])
        return version

    @classmethod
    def load(cls, settings, version: Optional[str] = None, engineer=None, store=None) -> "ProbabilityCalibrator":
        ms = ModelStore(settings.paths.models, "probability", FEATURE_VERSION)
        bundle, meta = ms.load(version)
        c = cls(settings, engineer, store, ms)
        c.fitted, c.champion = bundle["fitted"], bundle["champion"]
        c.metadata, c.version, c.leaderboard = meta, meta.get("version"), meta.get("leaderboard") or []
        logger.info("loaded probability %s: champion %s", c.version, c.champion)
        return c


def _renorm(sel: pd.DataFrame, p: np.ndarray) -> np.ndarray:
    keys = ["match_id", "pool_name", "line_id", "bucket"]
    s = pd.Series(np.where(np.isfinite(p), p, np.nan))
    tot = s.groupby([sel[k].to_numpy() for k in keys]).transform("sum").to_numpy()
    cnt = s.groupby([sel[k].to_numpy() for k in keys]).transform("count").to_numpy()
    size = s.groupby([sel[k].to_numpy() for k in keys]).transform("size").to_numpy()
    return np.where((cnt == size) & (tot > 0), p / np.where(tot > 0, tot, 1.0), np.nan)


def _renorm_keys(keys: pd.DataFrame, p: np.ndarray) -> np.ndarray:
    cols = [c for c in ("match_id", "pool_name", "line_id", "bucket") if c in keys.columns]
    if not cols:
        return p
    s = pd.Series(p)
    tot = s.groupby([keys[c].to_numpy() for c in cols]).transform("sum").to_numpy()
    size = s.groupby([keys[c].to_numpy() for c in cols]).transform("size").to_numpy()
    # a line with only one settled side in the sample keeps its own number
    return np.where((size >= 2) & (tot > 0), p / np.where(tot > 0, tot, 1.0), p)
