"""
Optimiser tests for publishing - the four dimensions the engine takes, the first half following the full
match, the draw factor, the engine's precision, the anchor of the trust band

    python tests/test_publish_optimizer.py     plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_publish_optimizer.py

Change Log:
-----------
2026-10-29      Initialize
"""

import math
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

FT = ["goal_tg", "goal_sup", "corner_tg", "corner_sup"]


def _book(spike=50.0, draw_factor=1.0, theta=None, anchor=None):
    """A pre-match book with full-match and first-half goal lines and corners; ``spike`` multiplies the money
    on Over 2.5 and on first-half Over 1.5 so the optimiser has a reason to move."""
    from algoe.optimizer.theta_optimizer import MatchBook
    from algoe.pricing.pricer import BookPricer, BookRows, Conventions, MatchState, repair_theta, theta_from_params
    spec = ([("HILO", "goal", "total", ln, s) for ln in (2.25, 2.5, 2.75) for s in "HA"]
            + [("HDC", "goal", "handicap", ln, s) for ln in (-0.25, -0.5) for s in "HA"]
            + [("FHLO", "goal_fh", "total", ln, s) for ln in (1.0, 1.5) for s in "HA"]
            + [("CHLO", "corner", "total", ln, s) for ln in (9.5, 10.5) for s in "HA"])
    pool, dom, mkt, line, side = (np.array(c) for c in zip(*spec))
    rows = BookRows(dom, mkt, line.astype("float64"), side)
    th = repair_theta(theta or theta_from_params(2.6, 0.4, 10.0, 1.0, 0.45, 0.46))
    p_now, risk = BookPricer(Conventions(draw_factor=draw_factor)).probabilities(rows, th, MatchState())
    margin = np.where(pool == "CHLO", 0.10, 0.075)
    n = len(spec)
    demand = np.full(n, 3000.0)
    demand[2] *= spike                                            # Over 2.5
    demand[(pool == "FHLO") & (line == 1.5) & (side == "H")] *= spike
    _, group = np.unique(pool, return_inverse=True)
    nan = np.full(n, np.nan)
    keys = pd.DataFrame({"pool_id": pd.factorize(pool)[0] + 100, "line_id": 0, "combination_id": 0,
                         "match_id": 1, "pool_name": pool, "bucket": pd.Timestamp("2026-10-29 19:00")})
    keys["line_id"] = keys.groupby("pool_id").cumcount() // 2 + 1
    keys["combination_id"] = keys.groupby(["pool_id", "line_id"]).cumcount() + 1
    return MatchBook(match_id=1, rows=rows, pool=pool, group=group.astype(int), margin=margin, demand=demand,
                     p_true=p_now.copy(), p_ref=nan, p_mkt=nan, odds_now=BookPricer.sell_odds(p_now, margin),
                     odds_mkt=nan, is_main=np.ones(n, bool), state=MatchState(), theta_now=th, keys=keys,
                     p_now=p_now, risk=risk, draw_factor=draw_factor, theta_anchor=anchor)


def _belief_shift(bk, by=0.04):
    """Our belief: more goals than HKJC prices (overs likelier), so theta* has a gain to chase."""
    over = (bk.rows.side == "H") & (bk.rows.market == "total") & np.isin(bk.rows.theta_domain, ["goal", "goal_fh"])
    bk.p_true = np.clip(np.where(over, bk.p_now + by, np.where(bk.rows.market == "total", bk.p_now - by, bk.p_now)),
                        0.01, 0.99)
    return bk


def test_all_eight_dimensions_is_the_w12_optimiser():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.pricing.pricer import DIMS
    from algoe.settings import Settings
    s = Settings()
    assert list(s.optimizer.free_dims) == list(DIMS)
    a = ThetaOptimizer(s).optimize_match(_belief_shift(_book()))
    b = ThetaOptimizer(s, free_dims=list(DIMS)).optimize_match(_belief_shift(_book()))
    assert a.theta_star == b.theta_star and a.egm_star == b.egm_star
    assert a.theta_star["goal_fh_tg"] != a.theta_now["goal_fh_tg"]          # the first half moved on its own


def test_four_dimensions_move_and_the_first_half_follows_by_hkjcs_ratio():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    d = ThetaOptimizer(Settings(), free_dims=FT).optimize_match(_belief_shift(_book()))
    th, th0 = d.theta_star, d.theta_now
    assert d.status.startswith("solved") and d.egm_star > d.egm_board
    assert th["goal_tg"] > th0["goal_tg"]                                   # more goals believed
    share = th0["goal_fh_tg"] / th0["goal_tg"]
    assert math.isclose(th["goal_fh_tg"], th["goal_tg"] * share, rel_tol=1e-9)
    assert math.isclose(th["goal_fh_sup"], th["goal_sup"] * share, rel_tol=1e-9, abs_tol=1e-12)
    c = th0["corner_fh_tg"] / th0["corner_tg"]
    assert math.isclose(th["corner_fh_tg"], th["corner_tg"] * c, rel_tol=1e-9)


def test_the_draw_factor_prices_the_book_and_the_board_stays_the_board():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    opt = ThetaOptimizer(Settings(), free_dims=FT)
    plain, drawn = _book(), _book(draw_factor=1.07)
    hdc = plain.pool == "HDC"
    assert not np.allclose(plain.p_now[hdc], drawn.p_now[hdc])              # more draws move the handicaps
    odds, _ = opt.prices(drawn, drawn.theta_now)
    assert np.allclose(odds, drawn.odds_now)                                # delta mode: at theta_now the board


def test_quantize_rounds_to_the_engines_precision_and_checks_again():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    opt = ThetaOptimizer(s, free_dims=FT)
    bk = _belief_shift(_book())
    d = opt.optimize_match(bk)
    q = opt.quantize(bk, d, theta_decimals=2, weight_decimals=2)
    for dim in FT:
        assert q.theta[dim] == round(q.theta[dim], 2)
        assert abs(q.theta[dim] - d.theta_now[dim]) <= s.optimizer.theta_band[dim] + 1e-9
    assert math.isclose(q.theta["goal_fh_tg"], q.theta["goal_tg"] * d.theta_now["goal_fh_tg"] / d.theta_now["goal_tg"])
    assert np.all(q.weights == np.round(q.weights, 2)) and np.all(np.abs(q.weights - 1) <= s.optimizer.weighting_band + 1e-9)
    assert q.chosen == "theta*" and q.egm >= q.egm_board - 1e-9
    assert np.isfinite(q.odds).all() and abs(q.egm - opt.expected_gm(bk, q.odds, opt.demand_at(bk, q.odds))) < 1e-6


def test_quantize_resets_a_line_whose_rounded_weights_break_the_ladder():
    from algoe.optimizer.theta_optimizer import MatchDecision, ThetaOptimizer
    from algoe.settings import Settings
    opt = ThetaOptimizer(Settings(), free_dims=FT)
    bk = _book()
    w = np.ones(bk.n)
    h = (bk.pool == "HILO") & (bk.rows.side == "H")
    bk.odds_now[h & (bk.rows.line == 2.25)] = 1.85          # two overs close together on the board
    bk.odds_now[h & (bk.rows.line == 2.5)] = 1.87
    w[h & (bk.rows.line == 2.25)] = 1.03                    # Over 2.25 longer than Over 2.5: an arbitrage
    w[h & (bk.rows.line == 2.5)] = 0.97
    w[(bk.pool == "HILO") & (bk.rows.side == "A") & (bk.rows.line == 2.25)] = 0.97
    w[(bk.pool == "HILO") & (bk.rows.side == "A") & (bk.rows.line == 2.5)] = 1.03
    th = dict(bk.theta_now)
    d = MatchDecision(1, "solved", th, th, 0.0, 0.0, 0.0, bk.total_demand, 0.0, bk.n, weights=w,
                      odds_star=bk.odds_now * w, demand_star=bk.demand)
    q = opt.quantize(bk, d)
    hilo = bk.pool == "HILO"
    assert np.all(q.weights[hilo & np.isin(bk.rows.line, [2.25, 2.5])] == 1.0) and q.reset_lines
    assert np.all(np.diff([q.odds[h & (bk.rows.line == ln)][0] for ln in (2.25, 2.5, 2.75)]) >= -1e-9)


def test_quantize_sends_hkjcs_theta_when_rounding_loses_the_gain():
    from algoe.optimizer.theta_optimizer import MatchDecision, ThetaOptimizer
    from algoe.settings import Settings
    opt = ThetaOptimizer(Settings(), free_dims=FT)
    bk = _book()                                            # belief = HKJC's own prices: nothing to gain
    th = dict(bk.theta_now, goal_tg=bk.theta_now["goal_tg"] + 0.3)
    d = MatchDecision(1, "solved", dict(bk.theta_now), th, 0.0, 0.0, 0.0, bk.total_demand, 0.0, bk.n,
                      weights=np.ones(bk.n))
    q = opt.quantize(bk, d)
    assert q.chosen == "board" and q.theta["goal_tg"] == round(bk.theta_now["goal_tg"], 2)
    assert np.all(q.weights == 1.0)


def test_quantize_board_is_hkjcs_theta_rounded_and_nothing_else():
    """What shadow sends production and a revert sends: HKJC's theta at the engine's precision as it is, or the
    theta handed back; quantize on a board decision searches the grid for a better corner, this does not."""
    from algoe.optimizer.theta_optimizer import MatchDecision, ThetaOptimizer
    from algoe.settings import Settings
    opt = ThetaOptimizer(Settings(), free_dims=FT)
    th = dict(_book().theta_now, goal_tg=2.604)
    bk = _belief_shift(_book(theta=th))
    q = opt.quantize_board(bk, 2)
    assert q.chosen == "board" and np.all(q.weights == 1.0) and q.egm == q.egm_board and q.reset_lines == []
    assert [q.theta[d] for d in FT] == [round(bk.theta_now[d], 2) for d in FT] and q.theta["goal_tg"] == 2.6
    assert np.isfinite(q.odds).all() and abs(q.egm - opt.expected_gm(bk, q.odds, opt.demand_at(bk, q.odds))) < 1e-6
    keep = MatchDecision(1, "kept", dict(bk.theta_now), dict(bk.theta_now), 0.0, 0.0, 0.0, bk.total_demand, 0.0, bk.n)
    assert opt.quantize(bk, keep).theta["goal_tg"] == 2.61                  # why the board has its own path
    back = opt.quantize_board(bk, 2, hold={"goal_tg": 2.483, "goal_sup": 0.35})
    assert (back.theta["goal_tg"], back.theta["goal_sup"]) == (2.48, 0.35)
    assert math.isclose(back.theta["goal_fh_tg"], 2.48 * bk.theta_now["goal_fh_tg"] / bk.theta_now["goal_tg"])


def test_the_trust_band_is_drawn_around_the_anchor():
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.settings import Settings
    s = Settings()
    band = s.optimizer.theta_band["goal_tg"]
    walked = dict(_book().theta_now)
    anchor = dict(walked, goal_tg=walked["goal_tg"] - 0.5)  # our own echo has walked 0.5 above the trader's
    d = ThetaOptimizer(s, free_dims=FT).optimize_match(_belief_shift(_book(anchor=anchor)))
    assert d.theta_star["goal_tg"] <= anchor["goal_tg"] + band + 1e-6
    free = ThetaOptimizer(s, free_dims=FT).optimize_match(_belief_shift(_book()))
    assert free.theta_star["goal_tg"] > d.theta_star["goal_tg"] + 1e-3     # without it the band moves on


def test_anchor_layers():
    from algoe.optimizer.theta_optimizer import anchor_theta
    from algoe.pricing.pricer import MatchState
    now = {"goal_tg": 2.0, "goal_sup": 0.2, "goal_fh_tg": 0.9, "goal_fh_sup": 0.09, "corner_tg": 7.0,
           "corner_sup": 0.5, "corner_fh_tg": 3.2, "corner_fh_sup": 0.2}
    params = {"Goal90BasisTG": 2.8, "Goal90BasisSUP": 0.4, "Corner90BasisTG": 10.0, "Corner90BasisSUP": 1.0,
              "Goal90ModelTG": 2.7, "Goal90ModelSUP": 0.3, "Corner90ModelTG": 9.5, "Corner90ModelSUP": 0.8}
    pre, live = MatchState(), MatchState(minute=30.0, phase="first_half")
    assert anchor_theta("current", now, params, None, pre, (0.45, 0.46)) is None
    b = anchor_theta("basis", now, params, None, pre, (0.45, 0.46))
    assert math.isclose(b["goal_tg"], 2.8) and math.isclose(b["goal_fh_tg"], 2.8 * 0.45)
    b30 = anchor_theta("basis", now, params, None, live, (0.45, 0.46))
    assert math.isclose(b30["goal_tg"], 2.8 * 60 / 90) and math.isclose(b30["corner_sup"], 1.0 * 60 / 90)
    seen = {"theta": dict(now, goal_tg=2.4), "minute": 0.0}
    f = anchor_theta("first_seen", now, params, seen, live, (0.45, 0.46))
    assert math.isclose(f["goal_tg"], 2.4 * 60 / 90)
    assert anchor_theta("model", now, {}, None, pre, (0.45, 0.46)) is None              # no Model layer: none


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
