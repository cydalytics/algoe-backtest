:HL["/_next/static/chunks/262czk0r1woy-.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"UnMC9j7lJQL-4oDJY5OFX"}
