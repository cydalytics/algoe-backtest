# Algo E snapshot message

One JSON message per match per refresh. Algo E publishes it. Two readers:

- **Data engineering** reads `parameters` and each combination's `Weight`, and runs the HKJC model. True odds come from the model at these parameters. Sell odds are that model's sell price multiplied by `Weight` when `Weight` is not null. Neither odds figure is in this message.
- **The vendor** reads the whole message for the UI.

A later message for the same match replaces the earlier one. It is a full snapshot, not a patch. The five-minute sweep and the 15-second fast lane (in play, and the last 90 minutes before kick-off) use the same schema. Readers ignore a field they do not know.

A new bet type needs no schema change. It is one more pool, named by HKJC's pool code.

## Envelope

| Field | Meaning |
|---|---|
| `schema` | `algoe.snapshot`. |
| `schema_version` | `1`. A new field does not change it. Renaming or removing a field moves to `2`. |
| `msg_id` | A JSON number: the Hong Kong date and that day's sequence, `yyyymmdd` then six digits. `20261103001042` is the 1,042nd message on 3 Nov 2026. |
| `event_id` | HKJC event id. |
| `created_at` | When this JSON was built. ISO-8601, Hong Kong offset, milliseconds. |
| `snapshot_at` | When the board was read. The newer `snapshot_at` for an `event_id` is the one to keep. `created_at` is not the order. |
| `bucket_start`, `bucket_end` | The five minutes the turnover belongs to. `bucket_end` is five minutes after `bucket_start`. |
| `update` | `sweep` (every match, a new bucket), `inplay` (about every 15 seconds, the same bucket, matches in play) or `refresh` (about every 15 seconds, the same bucket, matches within 90 minutes of kick-off). A reader that only knows `sweep` and `inplay` can treat `refresh` as `inplay`. |
| `models` | Turnover and probability model names. A name is omitted when that model is not loaded. |
| `match` | `league`, `home`, `away`, `phase`, `seconds`, `score`, `corners`. `score` and `corners` are `[home, away]`. `phase` is `prematch`, `first_half`, `half_time`, `second_half` or `finished`. `seconds` is the match clock as a whole number of seconds, not minutes. |

`msg_id` uses the Hong Kong date of `created_at`. The sequence starts at `000001` each midnight and is remembered on the box, so a restart continues and never repeats one. One box publishes. Six digits is 999,999 messages a day: a Saturday of in-play matches every 15 seconds is of the order of 20,000, and five digits (99,999) leaves little room on a day the cadence gets shorter. Fourteen digits stays inside a 53-bit integer, so JavaScript keeps it exact. It is a number, not text.

Turnover is Hong Kong dollars. There is no currency field.

## Part 1 — parameters and weights

TG and SUP appear only in `parameters`. Supremacy is home minus away.

| Field | Meaning |
|---|---|
| `goal`, `corner` | Full-match total (`tg`) and supremacy (`sup`). `source` is `optimized`. |
| `goal_first_half`, `corner_first_half` | The first half. `source` is `derived`: it follows the full match by HKJC's own ratio. The data team may re-derive it and ignore the number. It is here so the vendor can show the figure Algo E used. |
| `draw_factor` | The feed's Goal90DrawFactor on the feed's own scale (a multiplier, about 1.05, not the old engine's 0.05). `source` is `feed`. The field is omitted when the feed has none. |

Sent at Algo E's precision, up to four decimal places, not rounded to the old engine's two.

`Weight` is the other half of part 1, on the combination. The HKJC model prices the selection first. `Weight` then multiplies that sell price: `1.02` is 2% longer, `0.98` is 2% shorter. It does not go into the true odds. `null` means Algo E does not weight this selection, which is not the same as `1.0` (a side we did weight, and the weight landed on 1).

## Part 2 — turnover

Hong Kong dollars in the bucket `[bucket_start, bucket_end)`, up to two decimal places.

| Field | Meaning |
|---|---|
| `actual` | Received from `bucket_start` to `snapshot_at`. |
| `remaining` | Still expected before `bucket_end`. |
| `predicted` | The live estimate of the whole five minutes: `actual + remaining`, within one cent. |

`predicted` is not a forecast of the next 15 seconds. A 15-second refresh moves `actual` up and `remaining` down, and `predicted` moves with them. At the start of a bucket `actual` is 0, so `predicted` equals `remaining`.

`actual` can be filled from the feed when we have no model. `predicted` and `remaining` are then `null`, and the sum rule does not apply.

## Part 3 — calibrated probability

`probability` is Algo E's calibrated probability that this selection wins, from 0 to 1, up to six decimal places. Not a percentage, not an odds, not HKJC's true price. The two sides of a line are not required to sum to 1. `null` when we have none. The data team does not need it to run the model.

## Pools

The same nesting as the sample: `PoolType`, then `Lines`, then `Selections`. A pool with no line (HAD, CRS) still has one line, with `LineValues` and `LineLabel` null. `0` is not used to mean "no line".

Order is `PoolId`, then `LineId`, then `SelectionId`.

| Field | Where | Meaning |
|---|---|---|
| `PoolId` | pool | HKJC's pool id. |
| `PoolType` | pool | HKJC's pool code, text: `HAD`, `HILO`, or a code never listed here. Not the old numeric PoolType. |
| `InstanceNo` | pool | HKJC's instance. `0` when the pool is not split. |
| `segment` | pool | `FT`, `FH`, `ET`, or `null` when a new pool could not be classified. |
| `domain` | pool | `goal`, `corner`, or `null`. |
| `market` | pool | `three_way`, `handicap_3w`, `handicap`, `total`, `home_total`, `away_total`, `correct_score`, or `null`. A display hint. `PoolType` is the identity. |
| `Lines` | pool | The lines. |
| `LineId` | line | HKJC's line id. |
| `LineLabel` | line | Display text, such as `2.5/3`. `null` when there is no line. |
| `LineValues` | line | The line as a number, sign included. `null` when there is no line. |
| `Selections` | line | The selections on that line. |
| `SelectionId` | selection | HKJC's id for this selection on this line. With `PoolId` and `LineId`, the join key. |
| `CombinationLabel` | selection | `H`, `A`, `D`, `L`, `1-0`, or whatever label a new pool uses. |
| `Weight` | selection | Part 1. |
| `turnover` | selection | Part 2. |
| `probability` | selection | Part 3. |

`TrueOdds`, `CalcCurrentPrice` and `Margin` from the sample are not here. The data team computes those. Every selection the feed has is present. A pool we do not model still appears; the fields we cannot fill are `null`.

## Example

First half, 2 minutes 10 seconds into the 20:45 bucket. Home leads 1-0. The full message on a real match has every combination on the board, nested as in the sample. This one keeps every side of a line and one line of each shape.

HAD is a three-way with no line and no weights. HHAD is a three-way handicap. HILO 2.5 is the line we weight (over 1.02, under 0.98); HILO 2.5/3 is the next line, unweighted, and its label is not the same as the number. HDC is a two-way handicap. FHLO is a first-half total, priced off the derived first-half parameters. CHLO and CHDC are corners. CRS shows a label that is a score, one row of a pool that has many. NHILO is a pool we have not modelled: the feed's money is there, and everything we would have to invent is `null`.

```json
{
  "schema": "algoe.snapshot",
  "schema_version": 1,
  "msg_id": 20261103001042,
  "event_id": 50075870,
  "created_at": "2026-11-03T20:47:12.400+08:00",
  "snapshot_at": "2026-11-03T20:47:10.000+08:00",
  "bucket_start": "2026-11-03T20:45:00.000+08:00",
  "bucket_end": "2026-11-03T20:50:00.000+08:00",
  "update": "inplay",
  "models": {"turnover": "three_stage:xgb+xgb+xgb", "probability": "stack:trader+market"},
  "match": {
    "league": "EPL", "home": "Arsenal", "away": "Chelsea",
    "phase": "first_half", "seconds": 1410, "score": [1, 0], "corners": [3, 1]
  },
  "parameters": {
    "goal": {"tg": 2.6142, "sup": 0.3418, "source": "optimized"},
    "corner": {"tg": 9.8021, "sup": 0.7964, "source": "optimized"},
    "goal_first_half": {"tg": 1.1764, "sup": 0.1538, "source": "derived"},
    "corner_first_half": {"tg": 4.5090, "sup": 0.3663, "source": "derived"},
    "draw_factor": {"value": 1.05, "source": "feed"}
  },
  "Pools": [
    {"PoolId": 11, "PoolType": "HAD", "InstanceNo": 0, "segment": "FT", "domain": "goal", "market": "three_way", "Lines": [
      {"LineId": 1, "LineLabel": null, "LineValues": null, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 250000, "actual": 40000, "remaining": 210000}, "probability": 0.4612},
        {"SelectionId": 2, "CombinationLabel": "A", "Weight": null, "turnover": {"predicted": 140000, "actual": 22000, "remaining": 118000}, "probability": 0.2740},
        {"SelectionId": 3, "CombinationLabel": "D", "Weight": null, "turnover": {"predicted": 90000, "actual": 15000, "remaining": 75000}, "probability": 0.2648}
      ]}
    ]},
    {"PoolId": 15, "PoolType": "HHAD", "InstanceNo": 0, "segment": "FT", "domain": "goal", "market": "handicap_3w", "Lines": [
      {"LineId": 1, "LineLabel": "-1", "LineValues": -1, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 80000, "actual": 12000, "remaining": 68000}, "probability": 0.3011},
        {"SelectionId": 2, "CombinationLabel": "A", "Weight": null, "turnover": {"predicted": 36000, "actual": 5000, "remaining": 31000}, "probability": 0.4120},
        {"SelectionId": 3, "CombinationLabel": "D", "Weight": null, "turnover": {"predicted": 28000, "actual": 4000, "remaining": 24000}, "probability": 0.2869}
      ]}
    ]},
    {"PoolId": 21, "PoolType": "HILO", "InstanceNo": 0, "segment": "FT", "domain": "goal", "market": "total", "Lines": [
      {"LineId": 1, "LineLabel": "2.5", "LineValues": 2.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": 1.02, "turnover": {"predicted": 180000, "actual": 42000, "remaining": 138000}, "probability": 0.5410},
        {"SelectionId": 2, "CombinationLabel": "L", "Weight": 0.98, "turnover": {"predicted": 150000, "actual": 31000, "remaining": 119000}, "probability": 0.4590}
      ]},
      {"LineId": 2, "LineLabel": "2.5/3", "LineValues": 2.75, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 70000, "actual": 9000, "remaining": 61000}, "probability": 0.4722},
        {"SelectionId": 2, "CombinationLabel": "L", "Weight": null, "turnover": {"predicted": 64000, "actual": 8000, "remaining": 56000}, "probability": 0.5278}
      ]}
    ]},
    {"PoolId": 31, "PoolType": "HDC", "InstanceNo": 0, "segment": "FT", "domain": "goal", "market": "handicap", "Lines": [
      {"LineId": 1, "LineLabel": "-0.5", "LineValues": -0.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": 1.01, "turnover": {"predicted": 120000, "actual": 26000, "remaining": 94000}, "probability": 0.5830},
        {"SelectionId": 2, "CombinationLabel": "A", "Weight": 0.99, "turnover": {"predicted": 95000, "actual": 18000, "remaining": 77000}, "probability": 0.4170}
      ]}
    ]},
    {"PoolId": 41, "PoolType": "FHLO", "InstanceNo": 0, "segment": "FH", "domain": "goal", "market": "total", "Lines": [
      {"LineId": 1, "LineLabel": "1.5", "LineValues": 1.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 60000, "actual": 14000, "remaining": 46000}, "probability": 0.3904},
        {"SelectionId": 2, "CombinationLabel": "L", "Weight": null, "turnover": {"predicted": 55000, "actual": 11000, "remaining": 44000}, "probability": 0.6096}
      ]}
    ]},
    {"PoolId": 51, "PoolType": "CHLO", "InstanceNo": 0, "segment": "FT", "domain": "corner", "market": "total", "Lines": [
      {"LineId": 1, "LineLabel": "9.5", "LineValues": 9.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 40000, "actual": 6000, "remaining": 34000}, "probability": 0.5127},
        {"SelectionId": 2, "CombinationLabel": "L", "Weight": null, "turnover": {"predicted": 38000, "actual": 5500, "remaining": 32500}, "probability": 0.4873}
      ]}
    ]},
    {"PoolId": 61, "PoolType": "CHDC", "InstanceNo": 0, "segment": "FT", "domain": "corner", "market": "handicap", "Lines": [
      {"LineId": 1, "LineLabel": "-1.5", "LineValues": -1.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": 22000, "actual": 3000, "remaining": 19000}, "probability": 0.5488},
        {"SelectionId": 2, "CombinationLabel": "A", "Weight": null, "turnover": {"predicted": 18000, "actual": 2500, "remaining": 15500}, "probability": 0.4512}
      ]}
    ]},
    {"PoolId": 71, "PoolType": "CRS", "InstanceNo": 0, "segment": "FT", "domain": "goal", "market": "correct_score", "Lines": [
      {"LineId": 1, "LineLabel": null, "LineValues": null, "Selections": [
        {"SelectionId": 4, "CombinationLabel": "1-0", "Weight": null, "turnover": {"predicted": 15000, "actual": 4000, "remaining": 11000}, "probability": 0.1215}
      ]}
    ]},
    {"PoolId": 88, "PoolType": "NHILO", "InstanceNo": 0, "segment": null, "domain": null, "market": null, "Lines": [
      {"LineId": 1, "LineLabel": "1.5", "LineValues": 1.5, "Selections": [
        {"SelectionId": 1, "CombinationLabel": "H", "Weight": null, "turnover": {"predicted": null, "actual": 3500, "remaining": null}, "probability": null},
        {"SelectionId": 2, "CombinationLabel": "L", "Weight": null, "turnover": {"predicted": null, "actual": 1200, "remaining": null}, "probability": null}
      ]}
    ]}
  ]
}
```

## Not in this message

True odds and sell odds. The data team computes them from part 1. The old engine sample (`TrueOdds`, `CalcCurrentPrice`) is their output.

## Still open

The topic name, and whether one topic carries every match. That is the data team's.
