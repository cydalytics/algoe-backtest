"""
Algo E library

The systematic, deployable core of Algo E. One package, one responsibility
per sub-package, one main class per responsibility:

    algoe.settings                 Settings            every knob, one file
    algoe.core                     logging, validation, pool taxonomy, calendar
    algoe.data                     HistoricalPanel, LivePanelBuilder, SyntheticWorld, DaySplit
    algoe.features                 FeatureEngineer     features_for_turnover_* / features_for_probability
    algoe.models.estimators        GLM / GAM / GBM / NN / Naive, one interface
    algoe.models.turnover          TurnoverForecaster  train_<algo>_<response> / predict_* / evaluate_*
    algoe.models.probability       ProbabilityCalibrator
    algoe.pricing                  BookPricer          theta -> sell odds, in-play aware
    algoe.optimizer                ThetaOptimizer      E[GM] search with price-elastic demand
    algoe.backtest                 Backtester          compare_turnover / compare_trueprob / ...
    algoe.realtime                 LiveEngine          5-min sweep + focus-match loop
    algoe.monitoring               Monitor             forecast log, drift, alerts
    algoe.registry                 ModelStore          versioned artifacts, champion / challenger

Layering (imports only point downwards):

    realtime / backtest
        -> optimizer -> pricing
        -> models    -> features -> data -> core

The W06 parquet engine under ``src/backtest/parquet`` stays the single
implementation of raw-parquet loading and panel building; ``algoe.data``
wraps it and never re-implements it. Nothing under ``src/backtest/parquet``
may import ``algoe``, so the standalone backtest bundle keeps building.

Change Log:
-----------
2026-09-30      Initialize (W10 turnover close)
"""

__version__ = "1.0.0"
