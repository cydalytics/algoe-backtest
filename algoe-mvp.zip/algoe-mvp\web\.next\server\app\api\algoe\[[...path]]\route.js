var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/algoe/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0xj08f6._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_algoe_[[___path]]_route_actions_0-hhilq.js")
R.m(85635)
module.exports=R.m(85635).exports
