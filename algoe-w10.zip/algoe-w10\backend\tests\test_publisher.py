"""
Publisher tests - modes and the production gate, MsgIds, the kill switch, scope, what is sent, shadow,
the audit, replies and timeouts; all on a memory transport answered by the mock engine

    python tests/test_publisher.py             plain runner: one line per check, exit 1 on failure
    python -m pytest tests/test_publisher.py

Change Log:
-----------
2026-10-29      Initialize
"""

import gzip
import json
import os
import sys
import tempfile
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

T0 = pd.Timestamp("2026-10-29 19:30:00")
FT = ["goal_tg", "goal_sup", "corner_tg", "corner_sup"]
SPEC = [  # pool_id, line_id, pool, label, side, domain, market, line_label, line
    (11, 1, "HAD", "H", "H", "goal", "three_way", None, np.nan), (11, 1, "HAD", "A", "A", "goal", "three_way", None, np.nan),
    (11, 1, "HAD", "D", "D", "goal", "three_way", None, np.nan),
    (12, 1, "HILO", "H", "H", "goal", "total", "2.5", 2.5), (12, 1, "HILO", "L", "A", "goal", "total", "2.5", 2.5),
    (12, 2, "HILO", "H", "H", "goal", "total", "2.5/3", 2.75), (12, 2, "HILO", "L", "A", "goal", "total", "2.5/3", 2.75),
    (13, 1, "HDC", "H", "H", "goal", "handicap", "0/-0.5", -0.25), (13, 1, "HDC", "A", "A", "goal", "handicap", "0/-0.5", -0.25),
    (14, 1, "FHLO", "H", "H", "goal_fh", "total", "1.5", 1.5), (14, 1, "FHLO", "L", "A", "goal_fh", "total", "1.5", 1.5),
    (15, 1, "CHLO", "H", "H", "corner", "total", "9.5", 9.5), (15, 1, "CHLO", "L", "A", "corner", "total", "9.5", 9.5),
]


def _settings(**publish):
    from algoe.settings import Settings
    s = Settings()
    for k, v in publish.items():
        setattr(s.publish, k, v)
    return s


def _candidate(mid=777, as_of=T0, shift=0.05, league="EPL", phase="prematch", board_age=5.0, demand=4000.0,
               weights=("HILO", "HDC")):
    """One match the way the live engine hands it over: its book solved on the four published dimensions;
    ``weights`` pools get weightings 1.02 / 0.98 (home-over / away-under), so they are always in the message.
    ``demand`` below min_match_turnover / 13 makes a decision that keeps the board."""
    from algoe.optimizer.theta_optimizer import ThetaOptimizer, build_books
    from algoe.pricing.panel_pricing import price_rows_at_hkjc
    from algoe.pricing.pricer import Conventions
    from algoe.realtime.publisher import Candidate
    s = _settings()
    rows = pd.DataFrame(SPEC, columns=["pool_id", "line_id", "pool_name", "combination_string", "side", "theta_domain",
                                       "market", "line_label", "line"])
    rows["combination_id"] = rows.groupby(["pool_id", "line_id"]).cumcount() + 1
    rows["match_id"], rows["bucket"] = mid, as_of.floor("5min")
    match = pd.DataFrame({"match_id": [mid], "bucket": [as_of.floor("5min")], "tg": [2.6], "sup": [0.35],
                          "ctg": [9.8], "csup": [0.8], "goal_split_fh": [0.45], "corner_split_fh": [0.46],
                          "phase": [phase], "minute": [0.0 if phase == "prematch" else 30.0], "home_goals": [0],
                          "away_goals": [0], "home_corners": [0], "away_corners": [0]})
    p = price_rows_at_hkjc(rows, match, Conventions())
    margin = np.where(rows["pool_name"] == "CHLO", 0.10, 0.075)
    sel = rows.assign(odds=1.0 / p / (1.0 + margin), forecastable=True, rank_0=1.0)
    over = (rows["side"] == "H") & (rows["market"] == "total") & rows["theta_domain"].str.startswith("goal")
    under = (rows["side"] == "A") & (rows["market"] == "total") & rows["theta_domain"].str.startswith("goal")
    belief = np.clip(p + np.where(over, shift, np.where(under, -shift, 0.0)), 0.02, 0.98)
    books = build_books(sel, match, np.full(len(sel), demand), belief, s)
    book = books[0]
    decision = ThetaOptimizer(s, free_dims=FT).optimize_match(book)
    if demand >= 100 and weights:
        w = np.ones(book.n) if decision.weights is None else decision.weights.copy()
        pick = np.isin(book.pool, list(weights))
        w[pick] = np.where(book.rows.side[pick] == "H", 1.02, 0.98)
        decision.weights = w
    header = {"league_code": league, "phase": phase, "minute": 0.0 if phase == "prematch" else 30.0,
              "in_play": phase != "prematch", "game_state": "Prematch" if phase == "prematch" else "FirstHalf",
              "score": [0, 0], "corners": [0, 0], "splits": {"goal": 0.45, "corner": 0.46}}
    return Candidate(match_id=mid, decision=decision, book=book, rows=rows, header=header,
                     board_at=as_of - pd.Timedelta(seconds=board_age), draw_factor=1.05, as_of=as_of)


def _publisher(tmp, mode="dry_run", clock=None, env=None, mapping=None, transport=None, **publish):
    from algoe.optimizer.theta_optimizer import ThetaOptimizer
    from algoe.realtime.mock_engine import MockEngine
    from algoe.realtime.publisher import Publisher
    from src.hkjc.kafka_messages import load_mapping
    from src.hkjc.kafka_transport import MemoryTransport
    s = _settings(mode=mode, **publish)
    s.paths.work_dir = str(tmp)
    m = mapping or load_mapping()
    c = _candidate()
    mock = MockEngine(s, m, lambda mid: (c.rows, c.header))
    t = transport or MemoryTransport(responder=mock.reply)
    topics = {"file": ("params", "prices"), "test": ("t.params", "t.prices"), "production": ("p.params", "p.prices")}
    return Publisher(s, m, t, ThetaOptimizer(s, free_dims=FT), topics=topics, clock=clock or (lambda: T0),
                     env=env if env is not None else {})


def _confirmed():
    from src.hkjc.kafka_messages import load_mapping
    m = load_mapping()
    for entry in list(m.pool_types.values()) + list(m.game_states.values()):
        entry["confirmed"] = True
    m.draw_factor["confirmed"] = m.tg_in_play["confirmed"] = True
    return m


# ------------------------------------------------------------------ modes
def test_production_modes_need_the_env_and_the_confirmation_file():
    with tempfile.TemporaryDirectory() as tmp:
        assert _publisher(tmp, "dry_run").mode == "dry_run"
        live = _publisher(tmp, "live")
        assert live.mode == "off" and "ALGOE_PUBLISH=live" in live.refused
        live = _publisher(tmp, "live", env={"ALGOE_PUBLISH": "live"})
        assert live.mode == "off" and "CONFIRM-PRODUCTION.txt" in live.refused
        (Path(tmp) / "publish").mkdir(exist_ok=True)
        (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: shadow\n", encoding="utf-8")
        assert _publisher(tmp, "live", env={"ALGOE_PUBLISH": "live"}).mode == "off"
        assert _publisher(tmp, "shadow", env={"ALGOE_PUBLISH": "shadow"}).mode == "shadow"
        (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: live\nallow: shadow\n", encoding="utf-8")
        assert _publisher(tmp, "live", env={"ALGOE_PUBLISH": "live"}).mode == "live"


def test_msg_ids_never_repeat_after_a_restart():
    with tempfile.TemporaryDirectory() as tmp:
        a = _publisher(tmp)
        first = []
        for i in range(3):
            t = T0 + pd.Timedelta(seconds=30 * i)
            a.clock = lambda t=t: t
            first.append(a.consider(_candidate(as_of=t), "sweep")["msg_ids"][0])
        b = _publisher(tmp, clock=lambda: T0 + pd.Timedelta(minutes=5))
        later = b.consider(_candidate(as_of=T0 + pd.Timedelta(minutes=5)), "sweep")["msg_ids"][0]
        nums = [int(x.split("_")[-1]) for x in first + [later]]
        assert first[0] == "ALGOE_1" and len(set(nums)) == 4 and nums[-1] > max(nums[:3])


def test_the_kill_switch_survives_a_restart_and_resume_only_goes_back():
    with tempfile.TemporaryDirectory() as tmp:
        a = _publisher(tmp)
        a.stop("desk", "trader asked")
        b = _publisher(tmp)
        rec = b.consider(_candidate(), "sweep")
        assert rec["action"] == "skipped" and "stopped" in rec["why"] and b.transport.sent == []
        assert b.status()["stopped"]["by"] == "desk"
        b.resume()
        assert b.mode == "dry_run" and b.consider(_candidate(), "sweep")["action"] == "sent"


def test_scope_allowlists_and_a_stable_share():
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp, scope_leagues=["ESP"])
        assert p.consider(_candidate(league="EPL"), "sweep")["why"] == "out of scope"
        p = _publisher(tmp, scope_matches=[777])
        assert p.consider(_candidate(league="EPL"), "sweep")["action"] == "sent"
        p = _publisher(tmp, scope_percent=50.0)
        picks = [p.policy.in_scope(mid, "EPL") for mid in range(10000, 11000)]
        assert 420 <= sum(picks) <= 580 and picks == [p.policy.in_scope(mid, "EPL") for mid in range(10000, 11000)]


# -------------------------------------------------------------- the message
def test_the_message_carries_rounded_theta_star_and_the_mapped_weights_only():
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp)
        c = _candidate()
        rec = p.consider(c, "sweep")
        assert rec["action"] == "sent" and rec["chosen"] == "theta*", rec
        topic, key, value = p.transport.sent[0]
        msg = json.loads(value)
        assert (topic, key, msg["EventId"], msg["MsgId"]) == ("params", "777", 777, "ALGOE_1")
        assert msg["Timestamp"] == "2026-10-29T19:30:00" and msg["GameState"] == 1
        tg = msg["TgsupParameters"]
        assert tg["GoalTg"] == round(rec["theta_sent"]["goal_tg"], 2) and tg["GoalTg"] > 2.6
        assert tg["DrawFactor"] == 0.05
        assert {pw["PoolType"] for pw in msg["PoolWeightings"]} <= {1}         # HILO only: the rest unmapped
        assert any("HDC" in n for n in rec["notes"])


def test_what_is_sent_before_and_after_the_first_message():
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp)
        quiet = _candidate(demand=1.0)
        assert quiet.decision.status.startswith(("kept", "skipped")), quiet.decision.status
        rec = p.consider(quiet, "sweep")
        assert rec["action"] == "skipped" and "kept board" in rec["why"] and p.transport.sent == []
        p.consider(_candidate(), "sweep")
        later = _candidate(demand=1.0, as_of=T0 + pd.Timedelta(seconds=20))
        p.clock = lambda: T0 + pd.Timedelta(seconds=20)
        rec = p.consider(later, "inplay")
        msg = json.loads(p.transport.sent[-1][2])
        assert rec["action"] == "sent" and rec["chosen"] == "board"
        assert msg["TgsupParameters"]["GoalTg"] == 2.6                          # HKJC's own, so the engine knows
        weighted = [s["Weight"] for pw in msg["PoolWeightings"] for s in pw["Selections"]]
        assert weighted and all(w == 1.0 for w in weighted)                    # lines once weighted go back to 1


def test_nothing_starts_when_rounding_loses_the_gain():
    """Before the first message the alternative is the trader's exact theta: a theta* that only beats HKJC's theta
    at the engine's precision is not sent. After it, HKJC's rounded theta is the alternative."""
    from algoe.optimizer.theta_optimizer import Quantized
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp)
        c = _candidate()
        real = p.optimizer.quantize

        def worse(bk, d, *a, **k):
            q = real(bk, d, *a, **k)
            if d.theta_star == d.theta_now:
                return q
            return Quantized(q.theta, q.weights, q.odds, q.demand, d.egm_board - 5.0, d.egm_board - 20.0, "theta*",
                             q.reset_lines)
        p.optimizer.quantize = worse
        rec = p.consider(c, "sweep")
        assert rec["action"] == "skipped" and "loses the gain" in rec["why"] and p.transport.sent == []
        p.optimizer.quantize = real
        assert p.consider(c, "sweep")["action"] == "sent"
        p.optimizer.quantize = worse
        p.clock = lambda: T0 + pd.Timedelta(seconds=30)
        later = p.consider(_candidate(as_of=T0 + pd.Timedelta(seconds=30)), "inplay")
        assert later["action"] == "sent" and later["chosen"] == "theta*"          # better than HKJC's rounded theta
        assert p.matches[777].sent["targets"]["file"]["egm_board"] == later["gm_board_sent"]


def test_the_guards_on_time_and_age():
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp)
        assert p.consider(_candidate(), "sweep")["action"] == "sent"
        p.clock = lambda: T0 + pd.Timedelta(seconds=4)
        assert p.consider(_candidate(as_of=T0 + pd.Timedelta(seconds=4)), "trigger")["why"] == "too soon"
        p.clock = lambda: T0 + pd.Timedelta(seconds=40)
        old = _candidate(as_of=T0 + pd.Timedelta(seconds=40), board_age=60.0)
        assert "older board" in p.consider(old, "inplay")["why"]
        stale = _candidate(as_of=T0 + pd.Timedelta(seconds=40), board_age=700.0)       # pre-match limit 600 s
        assert "stale" in p.consider(stale, "inplay")["why"]
        done = _candidate(as_of=T0 + pd.Timedelta(seconds=40))
        done.header["phase"] = "finished"
        assert p.consider(done, "inplay")["why"] == "match finished"
        nodf = _candidate(as_of=T0 + pd.Timedelta(seconds=40))
        nodf.draw_factor = float("nan")
        assert "DrawFactor" in p.consider(nodf, "inplay")["why"]


def test_shadow_sends_hkjcs_theta_to_production_and_theta_star_to_test():
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "publish").mkdir()
        (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: shadow\n", encoding="utf-8")
        p = _publisher(tmp, "shadow", env={"ALGOE_PUBLISH": "shadow"}, mapping=_confirmed())
        rec = p.consider(_candidate(), "sweep")
        assert rec["action"] == "sent" and len(rec["msg_ids"]) == 2
        prod = [json.loads(v) for t, _, v in p.transport.sent if t == "p.params"]
        test = [json.loads(v) for t, _, v in p.transport.sent if t == "t.params"]
        assert prod[0]["TgsupParameters"]["GoalTg"] == 2.6 and prod[0]["PoolWeightings"] == []
        assert test[0]["TgsupParameters"]["GoalTg"] > 2.6


def _shadow(tmp, **kw):
    (Path(tmp) / "publish").mkdir(exist_ok=True)
    (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: shadow\n", encoding="utf-8")
    return _publisher(tmp, "shadow", env={"ALGOE_PUBLISH": "shadow"}, mapping=_confirmed(), **kw)


def _off_grid(c, goal_tg=2.604):
    """HKJC's theta a hair off the engine's two-decimal grid, as the feed can carry it."""
    c.book.theta_now["goal_tg"] = c.decision.theta_now["goal_tg"] = goal_tg
    return c


def test_shadow_sends_production_hkjcs_theta_as_read_and_never_weightings():
    with tempfile.TemporaryDirectory() as tmp:
        p = _shadow(tmp)
        for i in range(3):
            t = T0 + pd.Timedelta(seconds=30 * i)
            p.clock = lambda t=t: t
            rec = p.consider(_off_grid(_candidate(as_of=t)), "inplay")
            assert rec["action"] == "sent" and rec["targets"] == ["production", "test"], rec
        prod = [json.loads(v) for t, _, v in p.transport.sent if t == "p.params"]
        test = [json.loads(v) for t, _, v in p.transport.sent if t == "t.params"]
        assert len(prod) == 3 and all(m["PoolWeightings"] == [] for m in prod)     # not even 1.0 on lines weighted on test
        assert all(m["TgsupParameters"]["GoalTg"] == 2.6 for m in prod)            # 2.604 rounded, no grid search
        assert test[0]["PoolWeightings"] and test[0]["TgsupParameters"]["GoalTg"] > 2.6


def test_shadow_keeps_an_old_board_off_production():
    with tempfile.TemporaryDirectory() as tmp:
        p = _shadow(tmp)
        rec = p.consider(_candidate(board_age=30.0), "sweep")                      # read 30 s ago, limit 20 s
        assert rec["action"] == "sent" and rec["targets"] == ["test"], rec
        assert [t for t, _, _ in p.transport.sent] == ["t.params"]
        assert any("shadow_max_board_age_seconds" in n for n in rec["notes"])
        alone = _shadow(tmp, shadow_test_copy=False)
        rec = alone.consider(_candidate(mid=778, board_age=30.0), "sweep")
        assert rec["action"] == "skipped" and "shadow_max_board_age_seconds" in rec["why"] and alone.transport.sent == []


def test_a_reply_computed_before_our_newest_message_answers_the_one_before():
    """The reply has no MsgId; its EventTime says when it was computed, on the engine's clock. That clock is read
    against ours by the shortest delay of the replies so far, so a box some seconds off still matches; until five
    replies have come the newest message takes the reply."""
    from algoe.realtime.mock_engine import MockEngine
    from src.hkjc.kafka_transport import MemoryTransport
    c = _candidate()
    behind = pd.Timedelta(seconds=7)                                     # the engine's clock runs 7 s behind ours

    def answer(p, value, at):
        return MockEngine(p.settings, p.mapping, lambda mid: (c.rows, c.header), clock=lambda: at - behind).reply(value)

    def calibrate(p, at):
        for i in range(5):
            p.consider(_candidate(mid=900 + i, as_of=at), "sweep")
            p.transport.push(answer(p, p.transport.sent[-1][2], at))
        assert all(i["ours"] for _, i in p.poll())
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp, transport=MemoryTransport())
        calibrate(p, T0)
        p.consider(c, "sweep")
        p.clock = lambda: T0 + pd.Timedelta(seconds=20)
        p.consider(_candidate(as_of=T0 + pd.Timedelta(seconds=20)), "inplay")
        first, second = (v for _, _, v in p.transport.sent[-2:])
        p.transport.push(answer(p, first, T0 + pd.Timedelta(seconds=1)))          # computed before the second went
        (_, info), = p.poll()
        assert info["ours"] and info["late"] and info["msg_id"] == info["sent"]["msg_id"] == "ALGOE_6", info
        mp = p.matches[777]
        assert mp.pending["file"]["msg_id"] == "ALGOE_7" and mp.state == "awaiting"
        p.transport.push(answer(p, second, T0 + pd.Timedelta(seconds=21)))       # on its clock 14 s past the first
        (_, info), = p.poll()
        assert info["msg_id"] == "ALGOE_7" and not info["late"] and mp.state == "received", info
        restarted = _publisher(tmp, transport=MemoryTransport(), clock=lambda: T0 + pd.Timedelta(minutes=10))
        calibrate(restarted, T0 + pd.Timedelta(minutes=10))
        restarted.consider(_candidate(as_of=T0 + pd.Timedelta(minutes=10)), "sweep")
        restarted.transport.push(answer(restarted, first, T0 + pd.Timedelta(seconds=1)))   # from before the restart
        (_, info), = restarted.poll()
        assert not info["ours"] and restarted.matches[777].pending and restarted.matches[777].state == "awaiting"


def test_production_replies_from_another_server_are_dropped():
    from algoe.realtime.mock_engine import MockEngine
    from src.hkjc.kafka_transport import MemoryTransport
    c = _candidate()
    with tempfile.TemporaryDirectory() as tmp:
        p = _shadow(tmp, transport=MemoryTransport())
        p.consider(c, "sweep")
        sent = {t: v for t, _, v in p.transport.sent}
        for server, target in (("E-HV99-07", "p"), ("E-HV11-01", "p"), ("E-HV99-07", "t")):
            mock = MockEngine(p.settings, p.mapping, lambda mid: (c.rows, c.header), server_app_id=server,
                              clock=lambda: T0 + pd.Timedelta(seconds=1))
            p.transport.push(mock.reply(sent[target + ".params"]), topic=target + ".prices")
        got = [(r.server_app_id, i["target"]) for r, i in p.poll()]
        assert got == [("E-HV11-01", "production"), ("E-HV99-07", "test")], got     # the test engine may be any
        assert p.counts["other_server"] == 1


def test_shadow_keeps_each_targets_reply_state():
    from algoe.realtime.mock_engine import MockEngine
    from src.hkjc.kafka_transport import MemoryTransport
    c = _candidate()
    with tempfile.TemporaryDirectory() as tmp:
        p = _shadow(tmp, transport=MemoryTransport())
        p.consider(c, "sweep")
        prod = next(v for t, _, v in p.transport.sent if t == "p.params")
        mock = MockEngine(p.settings, p.mapping, lambda mid: (c.rows, c.header), server_app_id="E-HV11-01",
                          clock=lambda: T0 + pd.Timedelta(seconds=1))
        p.transport.push(mock.reply(prod), topic="p.prices")
        p.clock = lambda: T0 + pd.Timedelta(seconds=2)
        p.poll()
        mp = p.matches[777]
        assert mp.states == {"production": "received", "test": "awaiting"} and mp.state == "awaiting", mp.states
        p.clock = lambda: T0 + pd.Timedelta(seconds=30)
        p.poll()
        assert mp.states == {"production": "received", "test": "no response"} and mp.state == "no response"
        assert p.match_view(777)["states"] == mp.states


def test_current_following_our_message_is_counted_and_hkjcs_theta_is_handed_back():
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "publish").mkdir()
        (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: live\n", encoding="utf-8")
        p = _publisher(tmp, "live", env={"ALGOE_PUBLISH": "live"}, mapping=_confirmed())
        rec = p.consider(_candidate(), "sweep")
        assert rec["chosen"] == "theta*" and not rec["current_follows"]
        ours = rec["theta_sent"]

        def echo(c):                                       # Current shows our theta*: the engine took the message
            for k in FT:
                c.book.theta_now[k] = c.decision.theta_now[k] = ours[k]
            if str(c.decision.status).startswith("kept"):
                c.decision.theta_star = dict(c.decision.theta_now)
            return c
        p.flag_revert(777, 5.0, "test")
        p.clock = lambda: T0 + pd.Timedelta(seconds=30)
        rec = p.consider(echo(_candidate(as_of=T0 + pd.Timedelta(seconds=30))), "inplay")
        msg = json.loads(p.transport.sent[-1][2])
        assert rec["action"] == "sent" and rec["chosen"] == "revert" and rec["current_follows"], rec
        assert msg["TgsupParameters"]["GoalTg"] == 2.6 and p.counts["current_follows"] == 1
        p.matches[777].revert_until = None
        p.clock = lambda: T0 + pd.Timedelta(seconds=60)
        rec = p.consider(echo(_candidate(demand=1.0, as_of=T0 + pd.Timedelta(seconds=60))), "inplay")
        msg = json.loads(p.transport.sent[-1][2])
        assert rec["chosen"] == "board" and rec["current_follows"] and msg["TgsupParameters"]["GoalTg"] == 2.6


def test_first_half_weights_stop_at_half_time():
    import dataclasses
    from types import SimpleNamespace
    from algoe.realtime.publisher import MatchPublish
    from src.hkjc.kafka_messages import load_mapping
    m = load_mapping()
    m.pool_types["FHLO"] = {"code": 9, "confirmed": False}
    m.selections["FHLO"] = {"H": 0, "L": 1}
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp, mapping=m)
        c = _candidate()
        w = np.where(np.isin(c.book.pool, ["HILO", "FHLO"]), np.where(c.book.rows.side == "H", 1.02, 0.98), 1.0)
        q = SimpleNamespace(weights=w)
        assert {"HILO", "FHLO"} <= {r[0] for r in p._weight_rows(c, q, MatchPublish(), board_only=False)}
        c.book.state = dataclasses.replace(c.book.state, phase="second_half", minute=50.0)
        mp = MatchPublish(weighted={("FHLO", 1.5), ("HILO", 2.5)})
        for board_only in (False, True):
            pools = {r[0] for r in p._weight_rows(c, q, mp, board_only=board_only)}
            assert "FHLO" not in pools and "HILO" in pools, (board_only, pools)


def test_production_refuses_unconfirmed_mapping_entries():
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "publish").mkdir()
        (Path(tmp) / "publish" / "CONFIRM-PRODUCTION.txt").write_text("allow: live\n", encoding="utf-8")
        p = _publisher(tmp, "live", env={"ALGOE_PUBLISH": "live"})
        rec = p.consider(_candidate(), "sweep")
        assert rec["action"] == "refused" and "not confirmed" in rec["why"] and p.transport.sent == []


# ------------------------------------------------------------- the audit
def test_the_audit_keeps_every_message_and_drops_old_files():
    with tempfile.TemporaryDirectory() as tmp:
        audit = Path(tmp) / "publish" / "audit"
        audit.mkdir(parents=True)
        old = audit / "20260901-10.jsonl.gz"
        with gzip.open(old, "wt", encoding="utf-8") as fh:
            fh.write("{}\n")
        p = _publisher(tmp, audit_days=14)
        assert not old.exists()
        p.consider(_candidate(), "sweep")
        p.consider(_candidate(demand=1.0, mid=778), "sweep")
        rows = []
        for f in audit.glob("*.jsonl.gz"):
            with gzip.open(f, "rt", encoding="utf-8") as fh:
                rows += [json.loads(line) for line in fh]
        kinds = [(r["kind"], r.get("action")) for r in rows]
        assert ("out", None) in kinds and ("decision", "sent") in kinds and ("decision", "skipped") in kinds
        out = next(r for r in rows if r["kind"] == "out")
        assert out["msg_id"] == "ALGOE_1" and "message" in out and out["theta_sent"]["goal_tg"] > 2.6


# -------------------------------------------------------------- replies
def test_replies_are_matched_to_our_message_and_timeouts_are_counted():
    with tempfile.TemporaryDirectory() as tmp:
        p = _publisher(tmp)
        p.consider(_candidate(), "sweep")
        got = p.poll()
        assert len(got) == 1
        reply, info = got[0]
        assert reply.event_id == 777 and info["ours"] and info["msg_id"] == "ALGOE_1" and info["target"] == "file"
        p.transport.push(p.transport.sent[0][2].replace('"MsgId"', '"Other"'))      # not a reply at all
        assert p.poll() == [] and p.counts["bad_replies"] == 1
        silent = _publisher(tmp, transport=__import__("src.hkjc.kafka_transport", fromlist=["x"]).MemoryTransport())
        silent.consider(_candidate(mid=779), "sweep")
        silent.clock = lambda: T0 + pd.Timedelta(seconds=30)
        silent.poll()
        assert silent.matches[779].state == "no response" and silent.counts["no_response"] == 1
        assert silent.status()["counts"]["no_response"] == 1


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = []
    for name, fn in tests:
        try:
            fn()
            print("  {:<64} ok".format(name))
        except Exception:                                               # noqa: BLE001
            failed.append(name)
            print("  {:<64} FAIL".format(name))
            traceback.print_exc()
    print("\n{} - {} of {} passed".format("OK" if not failed else "FAILED", len(tests) - len(failed), len(tests)))
    sys.exit(1 if failed else 0)
