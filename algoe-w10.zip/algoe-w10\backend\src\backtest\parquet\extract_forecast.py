"""Turnover forecast from the tensors the feature notebooks already wrote.

``2 Features Extract Part 1.ipynb`` saves one npz per 5-minute timestamp.
Nothing here rebuilds those features from raw parquet.

Selection vector ``i2`` (35 columns):

    0     HKJC odds at T
    10    turnover in (T-5min, T]     last 5 minutes

``labels`` is turnover in (T, T+5min], the actual.

``5 Data Extraction - Real Time.ipynb`` adds ``i3``:

    0     market odds
    1     HKJC true odds at T

If ``i3`` is absent the same formula uses the HKJC odds already in ``i2[..., 0]``.

The model is a ridge of log1p(actual) on log1p(last 5 min) and log(true odds),
shrunk toward "next 5 minutes = last 5 minutes". A blend weight is kept only
when it beats that baseline on days the coefficients did not see. Day N is
scored before its rows are added to the fit.

    python -m src.backtest.parquet.extract_forecast selftest
    python -m src.backtest.parquet.extract_forecast fit --dir "S:\\Users\\Yeung\\20260520 Algo E\\Training_Data\\Temp"
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

# Column positions in the notebook, not guesses.
LAST5_IX = 10
OFFER_ODDS_IX = 0
TRUE_ODDS_IX = 1

# Blend of the ridge toward pure last-5-minute persistence.
ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)


def wape(y, yhat) -> float:
    y = np.asarray(y, dtype="float64")
    yhat = np.asarray(yhat, dtype="float64")
    denom = float(np.abs(y).sum())
    if denom <= 0 or not np.isfinite(denom):
        return float("nan")
    return float(np.abs(y - yhat).sum()) / denom


def design(last5, true_odds) -> np.ndarray:
    """[1, log1p(last 5 min), log(true odds)]."""
    last5 = np.clip(np.asarray(last5, dtype="float64"), 0, None)
    odds = np.clip(np.asarray(true_odds, dtype="float64"), 1.01, None)
    return np.column_stack([
        np.ones(len(last5)),
        np.log1p(last5),
        np.log(odds),
    ])


class TurnoverRidge:
    """log1p(next 5 min) on last-5 turnover and true odds.

    Coefficients shrink toward persistence: intercept 0, slope 1 on
    log1p(last 5 min), slope 0 on log(true odds). ``alpha`` is the weight
    on this fit against pure last-5 turnover. 0 means the forecast is the
    last 5 minutes.
    """

    def __init__(self, prior: float = 0.05):
        self.prior = float(prior)
        self.beta = np.array([0.0, 1.0, 0.0], dtype="float64")
        self.alpha = 0.0
        self.ready = False

    def fit(self, last5, actual, true_odds) -> dict:
        last5 = np.clip(np.asarray(last5, dtype="float64"), 0, None)
        actual = np.clip(np.asarray(actual, dtype="float64"), 0, None)
        if len(actual) < 20:
            raise ValueError("need at least 20 rows to fit")
        x = design(last5, true_odds)
        y = np.log1p(actual)
        # Big markets dominate WAPE, and last-5 turnover is known at T.
        w = np.maximum(last5, 1.0)
        sw = np.sqrt(w)
        a = x * sw[:, None]
        xtx = a.T @ a
        xty = a.T @ (y * sw)
        lam = self.prior * float(w.sum())
        xtx[1, 1] += lam
        xtx[2, 2] += lam
        xty[1] += lam * 1.0
        self.beta = np.linalg.solve(xtx, xty)
        self.ready = True
        return {"rows": int(len(actual)), "beta": self.beta.tolist()}

    def level(self, last5, true_odds) -> np.ndarray:
        raw = design(last5, true_odds) @ self.beta
        return np.clip(np.expm1(raw), 0, None)

    def predict(self, last5, true_odds, alpha: Optional[float] = None) -> np.ndarray:
        lag = np.clip(np.asarray(last5, dtype="float64"), 0, None)
        if not self.ready:
            return lag
        a = self.alpha if alpha is None else float(alpha)
        if a <= 0:
            return lag
        return a * self.level(last5, true_odds) + (1.0 - a) * lag

    def pick_alpha(self, last5, actual, true_odds) -> dict:
        """Keep a blend only when it beats last-5 turnover on these rows."""
        actual = np.asarray(actual, dtype="float64")
        lag = np.clip(np.asarray(last5, dtype="float64"), 0, None)
        if len(actual) == 0 or not self.ready:
            self.alpha = 0.0
            return {"alpha": 0.0, "scores": {}}
        level = self.level(last5, true_odds)
        scores = {}
        best_a, best = 0.0, wape(actual, lag)
        for a in ALPHAS:
            s = wape(actual, a * level + (1.0 - a) * lag)
            scores[str(a)] = s
            if np.isfinite(s) and s < best - 1e-6:
                best, best_a = s, a
        self.alpha = float(best_a)
        return {"alpha": self.alpha, "scores": scores}


def _day_from_name(path: Path) -> str:
    m = re.match(r"(\d{4})(\d{2})(\d{2})", path.stem)
    if m:
        return "{}-{}-{}".format(*m.groups())
    return path.stem


def _as_days(timestamp, n: int) -> Optional[np.ndarray]:
    if timestamp is None:
        return None
    ts = np.asarray(timestamp).reshape(-1)
    if len(ts) != n:
        return None
    try:
        import pandas as pd
        days = pd.to_datetime(ts).strftime("%Y-%m-%d").to_numpy()
    except Exception:
        return None
    return days


def read_snapshot(path: Path) -> List[Tuple[str, np.ndarray, np.ndarray, np.ndarray, str]]:
    """One npz -> (day, last5, actual, true_odds, odds_source) for masked selections.

    A stacked file (part 2) is split by its ``timestamp`` array. A per-bucket
    file (part 1) is one day-bucket, dated from the filename.
    """
    with np.load(path, allow_pickle=True) as z:
        names = set(z.files)
        if "i2" not in names:
            raise ValueError(
                "{} has {} ; expected i2, labels, sel_mask from "
                "2 Features Extract Part 1.ipynb".format(path.name, sorted(names)))
        # Copy before the file closes. A memmap would dangle afterwards.
        i2 = np.array(z["i2"])
        labels = np.array(z["labels"] if "labels" in names else z["lab"])
        mask = np.array(z["sel_mask"] if "sel_mask" in names else z["sm"])
        i3 = np.array(z["i3"]) if "i3" in names else None
        timestamp = np.array(z["timestamp"]) if "timestamp" in names else None

    if i2.shape[-1] <= LAST5_IX:
        raise ValueError("{} i2 has {} columns, need index {}".format(
            path.name, i2.shape[-1], LAST5_IX))
    out = []
    n_time = i2.shape[0] if i2.ndim == 5 else 1
    days = _as_days(timestamp, n_time) if i2.ndim == 5 and n_time > 1 else None
    if days is None:
        chunks = [( _day_from_name(path), i2, labels, mask, i3 )]
    else:
        chunks = []
        for day in dict.fromkeys(days.tolist()):
            sl = days == day
            chunks.append((
                day, i2[sl], labels[sl], mask[sl],
                None if i3 is None else i3[sl],
            ))
    for day, a2, lab, msk, a3 in chunks:
        last5, actual, odds, source = _masked(a2, lab, msk, a3)
        if len(actual):
            out.append((day, last5, actual, odds, source))
    return out


def _masked(i2, labels, mask, i3):
    last5 = np.nan_to_num(np.asarray(i2[..., LAST5_IX], dtype="float64"), nan=0.0)
    actual = np.nan_to_num(np.asarray(labels, dtype="float64"), nan=0.0)
    m = np.asarray(mask, dtype=bool)
    if i3 is not None:
        odds = np.nan_to_num(np.asarray(i3[..., TRUE_ODDS_IX], dtype="float64"), nan=0.0)
        source = "true_odds"
    else:
        odds = np.nan_to_num(np.asarray(i2[..., OFFER_ODDS_IX], dtype="float64"), nan=0.0)
        source = "offer_odds"
    if last5.shape != m.shape or actual.shape != m.shape or odds.shape != m.shape:
        raise ValueError(
            "shape mismatch last5 {} actual {} odds {} mask {}".format(
                last5.shape, actual.shape, odds.shape, m.shape))
    return last5[m], actual[m], odds[m], source


def _files(directory: Path) -> List[Path]:
    if directory.is_file():
        return [directory]
    files = sorted(p for p in directory.glob("*.npz") if p.is_file())
    if not files:
        raise SystemExit("no npz files in {}".format(directory))
    return files


def _sample(last5, actual, odds, cap: int, rng: np.random.Generator):
    n = len(actual)
    if n <= cap:
        return last5.astype("float32"), actual.astype("float32"), odds.astype("float32")
    take = rng.choice(n, size=cap, replace=False)
    return last5[take].astype("float32"), actual[take].astype("float32"), odds[take].astype("float32")


def run(directory: Path, out_dir: Path, warmup_days: int = 14, inner_days: int = 7,
        refit_every: int = 7, per_day: int = 20000, seed: int = 7) -> dict:
    """Walk-forward over notebook npz files. Writes report.json."""
    files = _files(directory)
    grouped: Dict[str, List[Path]] = {}
    skipped = []
    # Date from the filename when the notebook used %Y%m%d%H%M. Otherwise the
    # file is opened once below and split on its timestamp array.
    dated = []
    undated = []
    for path in files:
        if re.match(r"\d{8}", path.stem):
            dated.append(path)
        else:
            undated.append(path)
    for path in dated:
        grouped.setdefault(_day_from_name(path), []).append(path)

    days_payload: List[Tuple[str, List[Tuple[np.ndarray, np.ndarray, np.ndarray, str]]]] = []
    for day in sorted(grouped):
        chunks = []
        for path in grouped[day]:
            try:
                for d, last5, actual, odds, source in read_snapshot(path):
                    chunks.append((last5, actual, odds, source))
            except ValueError as exc:
                skipped.append(str(exc))
        if chunks:
            days_payload.append((day, chunks))
    for path in undated:
        try:
            by_day: Dict[str, List] = {}
            for d, last5, actual, odds, source in read_snapshot(path):
                by_day.setdefault(d, []).append((last5, actual, odds, source))
            for d in sorted(by_day):
                days_payload.append((d, by_day[d]))
        except ValueError as exc:
            skipped.append(str(exc))
    days_payload.sort(key=lambda item: item[0])
    if not days_payload:
        raise SystemExit("no notebook tensors found. {}".format("; ".join(skipped[:3])))

    rng = np.random.default_rng(seed)
    model: Optional[TurnoverRidge] = None
    stored: List[dict] = []
    since_fit = 0
    daily = []
    tot = {"sp": 0.0, "sm": 0.0, "y": 0.0, "n": 0}
    sources = set()

    for day, chunks in days_payload:
        last5 = np.concatenate([c[0] for c in chunks])
        actual = np.concatenate([c[1] for c in chunks])
        odds = np.concatenate([c[2] for c in chunks])
        for c in chunks:
            sources.add(c[3])
        if model is not None and model.ready and len(stored) >= warmup_days:
            pred = model.predict(last5, odds)
            persist = np.clip(last5, 0, None)
            sae_p = float(np.abs(actual - persist).sum())
            sae_m = float(np.abs(actual - pred).sum())
            turnover = float(np.abs(actual).sum())
            row = {
                "day": day, "rows": int(len(actual)), "turnover": turnover,
                "wape_persist": sae_p / turnover if turnover else None,
                "wape_model": sae_m / turnover if turnover else None,
            }
            daily.append(row)
            tot["sp"] += sae_p
            tot["sm"] += sae_m
            tot["y"] += turnover
            tot["n"] += len(actual)
            print("[hold] {} persist={:.1%} model={:.1%} rows={:,}".format(
                day,
                row["wape_persist"] if row["wape_persist"] is not None else float("nan"),
                row["wape_model"] if row["wape_model"] is not None else float("nan"),
                len(actual)), flush=True)
        s_last, s_y, s_odds = _sample(last5, actual, odds, per_day, rng)
        stored.append({"day": day, "last5": s_last, "y": s_y, "odds": s_odds})
        since_fit += 1
        if len(stored) >= warmup_days and (model is None or since_fit >= refit_every):
            model = _refit(stored, inner_days)
            since_fit = 0

    hold = {
        "rows": int(tot["n"]), "turnover": tot["y"],
        "wape_persist": tot["sp"] / tot["y"] if tot["y"] else None,
        "wape_model": tot["sm"] / tot["y"] if tot["y"] else None,
    }
    ok = hold["wape_persist"] is not None and hold["wape_model"] is not None
    hold["beats_persist"] = bool(ok and hold["wape_model"] < hold["wape_persist"] - 1e-4)
    report = {
        "source": str(directory),
        "odds": "true_odds" if sources == {"true_odds"} else (
            "offer_odds" if "true_odds" not in sources else "mixed"),
        "columns": {
            "last_5min": "i2[..., {}]".format(LAST5_IX),
            "actual": "labels",
            "true_odds": "i3[..., {}]".format(TRUE_ODDS_IX),
        },
        "days": len(days_payload),
        "warmup_days": warmup_days,
        "skipped": skipped[:20],
        "holdout": hold,
        "daily": daily,
        "beta": None if model is None else model.beta.tolist(),
        "alpha": None if model is None else model.alpha,
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "extract_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8")
    print("[out] {}".format(out_dir / "extract_report.json"), flush=True)
    if hold["wape_persist"] is None:
        print("[result] nothing scored. Warm-up is {} days and this folder has {}.".format(
            warmup_days, len(days_payload)), flush=True)
    else:
        print("[result] persist={:.1%} model={:.1%}".format(
            hold["wape_persist"], hold["wape_model"]), flush=True)
    return report


def _refit(stored: List[dict], inner_days: int) -> TurnoverRidge:
    inner_n = min(int(inner_days), max(len(stored) - 1, 0))
    fit_days = stored[:len(stored) - inner_n]
    inner = stored[len(stored) - inner_n:]
    model = TurnoverRidge()
    model.fit(
        np.concatenate([d["last5"] for d in fit_days]),
        np.concatenate([d["y"] for d in fit_days]),
        np.concatenate([d["odds"] for d in fit_days]),
    )
    if inner:
        info = model.pick_alpha(
            np.concatenate([d["last5"] for d in inner]),
            np.concatenate([d["y"] for d in inner]),
            np.concatenate([d["odds"] for d in inner]),
        )
        print("[fit] days={} alpha={} beta={}".format(
            len(fit_days), info["alpha"],
            np.array2string(model.beta, precision=3)), flush=True)
    else:
        model.alpha = 0.0
    return model


def _fail(msg: str) -> None:
    raise SystemExit("[extract selftest] FAIL: " + msg)


def selftest() -> None:
    import tempfile

    rng = np.random.default_rng(1)
    # actual = 0.4 * last 5 min, so persistence is badly high and the ridge
    # has something real to learn. true odds vary but do not drive the label.
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        for d in range(24):
            last5 = rng.uniform(100, 5000, size=(1, 2, 3, 2)).astype("float32")
            true = rng.uniform(1.5, 4.0, size=last5.shape).astype("float32")
            actual = (0.4 * last5).astype("float32")
            i2 = np.zeros(last5.shape + (35,), dtype="float32")
            i2[..., LAST5_IX] = last5
            i2[..., OFFER_ODDS_IX] = 9.0  # must not be used when i3 is present
            i3 = np.zeros(last5.shape + (2,), dtype="float32")
            i3[..., TRUE_ODDS_IX] = true
            mask = np.ones(last5.shape, dtype=bool)
            mask[..., 1] = False  # one side closed
            stamp = "2024-06-{:02d} 12:00:00".format(d + 1)
            np.savez_compressed(
                root / "202406{:02d}1200.npz".format(d + 1),
                i2=i2, i3=i3, labels=actual, sel_mask=mask,
                timestamp=np.array(stamp),
            )
        # A closed side must not enter the score, and offer odds must not
        # replace true odds.
        got = read_snapshot(root / "202406011200.npz")
        if len(got) != 1 or got[0][0] != "2024-06-01":
            _fail("day key {}".format(got[0][0] if got else None))
        _, last5, actual, odds, source = got[0]
        if source != "true_odds":
            _fail("ignored i3 true odds")
        if len(actual) != 6:  # 1*2*3*2 with one side masked off -> half of 12
            _fail("mask kept {} rows".format(len(actual)))
        if np.any(odds > 8):
            _fail("true odds fell back to the offer")
        if not np.allclose(actual, 0.4 * last5):
            _fail("actual is not the label")

        report = run(root, root / "out", warmup_days=8, inner_days=4,
                     refit_every=4, per_day=5000)
        hold = report["holdout"]
        if hold["wape_persist"] is None or hold["wape_persist"] < 1.0:
            _fail("persistence should be far from a 0.4x series, got {}".format(
                hold["wape_persist"]))
        if not hold["beats_persist"]:
            _fail("ridge did not beat last-5: persist={} model={}".format(
                hold["wape_persist"], hold["wape_model"]))
        # The first scored day must not have been fit on itself: with
        # warmup 8, scoring starts at day index 8 (the 9th day).
        if report["daily"][0]["day"] != "2024-06-09":
            _fail("first scored day {}".format(report["daily"][0]["day"]))
    print("[extract selftest] PASS", flush=True)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["selftest", "fit"])
    p.add_argument("--dir", default=r"S:\Users\Yeung\20260520 Algo E\Training_Data\Temp",
                   help="Temp folder of per-bucket npz, or all_data.npz")
    p.add_argument("--out-dir", default="turnover_out")
    p.add_argument("--warmup-days", type=int, default=14)
    p.add_argument("--inner-days", type=int, default=7)
    p.add_argument("--refit-every", type=int, default=7)
    p.add_argument("--per-day", type=int, default=20000)
    return p


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = build_parser().parse_args(argv)
    if args.command == "selftest":
        selftest()
        return
    run(Path(args.dir), Path(args.out_dir), args.warmup_days, args.inner_days,
        args.refit_every, args.per_day)


if __name__ == "__main__":
    main()
