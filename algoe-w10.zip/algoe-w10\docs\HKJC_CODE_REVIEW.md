# Review of `hkjc_code` - what each step does, why, and what W10 does with it

Reviewed read-only: `AlgoE/hkjc_code` (notebooks 1, 2, 3, 5; `4 Model.py`, `train_ddp_v3.py`,
`inverse_poisson.py`, `poisson_betting.py`, `optimizer_v2.py`, `optimizer_v2b.py`).
Line numbers refer to the files as they are on 2026-09-30.

## The loop you were building

Every 5 minutes, for every live match:

1. **Anchor volume** - forecast how much money each selection will take in the next bucket
   (`2 Features Extract`, `4 Model.py`).
2. **Belief** - the probability each selection wins, independent of HKJC's offer
   (`odds_df_true` / `inverse_poisson.py`).
3. **Search theta** - the eight TG/SUP parameters (goal/corner x total/supremacy x FT/FH) that
   drive every price (`optimizer_v2b.py`, pricing through `poisson_betting.py`).
4. **Score** - expected gross margin `E[GM] = sum turnover x (1 - offer x belief)` at the
   candidate theta, with demand re-run at the candidate prices, and keep the best.

That is the right decomposition, and W10 keeps it exactly. Most of the problems below are in
how the data reaches the model, not in the idea.

## Step by step

### `1 Data Extraction.ipynb` - SQL to monthly parquet (Raw_Data)

**What:** month-by-month queries against `qfm_outbound_db` / `bis*_fbuser_db` for odds, market
odds, investments, pools, matches, parameters and events, each written to its own folder.
**Why:** the SQL servers cannot be queried for months of history inside a training loop; parquet
on the S:\ drive is the reproducible snapshot.
**Status:** kept as is. W10 reads these folders through the W06 loader, whose alias table
(`src/backtest/parquet/loader.py`) maps each raw column to one canonical name and repairs the
swapped bookmaker / bet-type columns of the market extraction (`resolve_market_swap`).
One gap remains: the historical odds query joins `pool_odds_change_c` but not
`pool_odds_true_change_h`, so historical true odds exist only where the real-time extraction
(notebook 5) was used. `python -m algoe check-data` reports which case a folder is.

### `2 Features Extract Part 1.ipynb` - one tensor per 5-minute timestamp

**What:** for each timestamp T, the active matches (Pool_Details `start <= T < close`), their
theta, score, events, odds history and investment windows, packed into dense tensors:
`i0` (12 day features), `i1` (350 matches x 42), `i2` (350 x 150 lines x 2 sides x 35), `labels`
(money in the next 5 minutes), masks and `theta` (350 x 8).
**Why it is the right instinct:** everything is cut at T (params, events and odds use `<= T`),
active pools come from the selling window, several event providers are reconciled by taking the
largest count, and the model sees theta, so demand can respond to price.

**What is wrong** - in order of how much it changes the numbers:

| # | Problem | Effect |
|---|---------|--------|
| 1 | **Labels are written to the wrong side.** `label_lookup[(pn, ll, sj)]` is keyed by the tensor slot `sidx` (0 / 1), but looked up with `key = (pn, ll, comb_id)`, and HKJC combination ids are 1 / 2 (`POOLS[...]["selections"]` says so, and the odds lookup correctly uses `si`). | The money of combination 1 (Over / Home) lands in slot 1 (Under / Away); combination 2's money is dropped. Every label is wrong. |
| 2 | **Lag windows are one minute into the future.** Investments are stamped with the minute they start (`IntervalTimeStart`); the "last 5 minutes" window is `(T-5, T]`, which includes the minute starting at T. | At a live tick at T that minute is still in progress. The model trains on data it will never have when serving. |
| 3 | **`hash()` for league and pool codes.** `abs(hash(league)) % 16` and `abs(hash(pn2)) % 8`: Python randomises string hashes per process. | The multiprocessing workers, and every later run, encode the same league differently; the feature is noise, and training and serving disagree. |
| 4 | **The score never reaches the features.** Goals are computed into `home_goals` / `away_goals`, but the features read `home_score` / `away_score`, which are only set to 0 when there are no events. | Score, score difference and total goals are 0 (or a stale value from another match); if the first match of a timestamp has goals, the timestamp raises. |
| 5 | **Silent loss of whole timestamps.** `process_and_save` wraps everything in a bare `except: return None`; the empty-odds branch assigns `slot_map = {}` but does not `continue`. | Any failure anywhere drops the whole 5-minute snapshot with no log line, so the training set has holes nobody can see. |
| 6 | **Unpriced selections get odds 2.0.** `get_latest_odds` returns 2.0 when nothing was posted before T. | Rows that were not on the board look like even-money selections. |
| 7 | **Fixed shape: 350 matches x 150 lines x 2 sides.** | A three-way pool (HAD, HHAD), correct score, or any new bet type with more than two outcomes cannot be represented, which works against "new bet types must just work". |
| 8 | **Cost.** Each timestamp filters the full in-memory tables again: O(timestamps x rows). | Days of CPU for a season; one snapshot is ~15 MB before compression. |

**W10 instead** (`backend/algoe/features/engineer.py`): long format - one row per (bucket,
selection), so any pool with any number of outcomes fits; buckets are `[T, T+5)` on minute
starts, lags are whole previous buckets; leagues and pools are target-encoded with
empirical-Bayes shrinkage to their parent (league -> global, pool -> family x phase -> global),
stable across processes and falling back safely for anything unseen; a selection enters only
once it was priced before T (`forecastable`); per-day vectorised joins; every failure is
logged with its day. Most importantly, the **parity check** (`python -m algoe parity`) rebuilds
a bucket the way the live engine serves it and compares every input: it is how W10 found and
fixed the same class of leak in its own pipeline (odds age measured at the end of the bucket,
event provider chosen with later goals, closed first-half pools kept alive).

### `3 Features Extract Part 2.ipynb` - concatenate the snapshots

**What:** loads every per-timestamp `.npz` and saves one `all_data.npz`.
**Issue:** the whole season has to fit in memory at once, and the training scripts stream the
per-timestamp files anyway, so the combined file is not used.
**W10:** `FeatureStore` keeps one parquet per day and feature version; nothing ever holds more
than the days being fitted.

### `4 Model.py` - cross-match attention turnover model

**What:** day, match (+ theta) and selection encoders; optional attention across matches (they
compete for the same punters); a decoder per selection; masked MSE.
**Why:** a joint model of the card can learn that a big match takes money from the rest.

**What is wrong:**

| # | Lines | Problem |
|---|-------|---------|
| 1 | 99-123, 127, 303 | `sel_enc` and `decoder` are created lazily inside `forward`, but the Adam optimizer is built from `model.parameters()` before the first forward. Those layers are never registered with the optimizer and **never train**. `model.to(device)` also runs before they exist (CUDA inputs, CPU layers), and resuming fails because the checkpoint has keys the fresh model does not. |
| 2 | 155-161, 152 | MSE on raw money: a handful of huge selections dominate the loss, and the output (called logits, used as money) can be negative. Turnover wants a log link and a Poisson / Tweedie deviance. |
| 3 | 308 | `HAS_TB` and `SummaryWriter` are never defined, so `--log_dir` raises NameError. |
| 4 | - | The selection's own price enters only through theta; the demand response the optimizer needs is a response to each selection's offer, so the offer should be a direct input. |

### `train_ddp_v3.py` - multi-GPU version

Fixes the lazy-init bug (encoders built in `__init__`, Xavier init), but:

| # | Lines | Problem |
|---|-------|---------|
| 1 | 306 vs 367-370 | `get_loaders` takes neither `world_size` nor `rank` and returns 3 values; `main` passes both and unpacks 6: TypeError at start-up. There is no `DistributedSampler`, so every rank would train on all the data. |
| 2 | 398-405 | Only rank 0 loads the checkpoint, after DDP has already synchronised weights: the other ranks resume from their own random weights. |
| 3 | 60-71 | Normalisation statistics come from `self.files[0]` alone - one 5-minute snapshot - and include the padded zeros. |
| 4 | 97-98 | The target is z-scored and fitted with MSE, and never transformed back for inference. |

**W10 instead** (`backend/algoe/models/turnover.py`): four responses (match total, pool share,
selection share, direct selection turnover) x four estimators (GLM with Tweedie/Poisson
deviance, GAM with P-splines, GBM, NN when torch is present), trained on calendar-day splits,
the champion chosen on validation days, reported once on test days, and promoted only if it
beats last-5-minutes. On the synthetic world the three-stage GBM halves last-5's deviance.
The NN is a challenger in the same leaderboard - it has to earn its place, CPU-only.

### `inverse_poisson.py` - market prices to theta

**What:** least squares between de-margined market probabilities (1X2, main AH, main O/U) and
the Poisson model's, over (TG, SUP) with L-BFGS-B.
**Why:** reading the market's theta gives an initial guess and a view of where HKJC stands.
**Issues:** the objective assumes a draw factor of 1.067 when it is not fitted (line 38) while
every pricer call downstream uses `poisson_betting`'s default of 1.0, so the fitted theta is
slightly off the model that uses it; de-margined odds are normalised twice (harmless).
**W10:** HKJC's own theta arrives in `HKJC_Parameters`, so it is the anchor; this remains useful
for the external market's theta.

### `poisson_betting.py` - the pricing library

The reference. W10's vectorised pricer (`backend/algoe/pricing/pricer.py`) reproduces its
Over/Under and Asian handicap prices to 7e-16 on 90 lines including quarter lines (checked in
every selftest), and adds what in-play pricing needs: HKJC's in-play `Goal90CurrentTG` is goals
still to come, so full-match lines are priced on the score grid shifted by the current score -
the backtest's replication check confirms that convention reproduces HKJC's board.

### `optimizer_v2.py` / `optimizer_v2b.py` - search theta

**What:** per match, minimise expected payout `sum turnover x offer(theta) x p_true` subject to
offer <= external market price (HDC / HILO), offer >= 1.001 and |SUP| <= TG; multi-start SLSQP
from the inverse-Poisson guess plus four fixed starts, in threads; trust-constr fallback.
**Why:** exactly step 3-4 of the loop.

`optimizer_v2b.py` is mid-refactor from the DataFrame input of v2 to the model's tensors and
does not run:

| # | Lines | Problem |
|---|-------|---------|
| 1 | 271, 278 | `optimize_bucket(x, y, z, ...)` iterates `group`, which no longer exists: NameError. |
| 2 | 359 | `initial_guess` is never defined (the inverse-Poisson block was removed). |
| 3 | 388 | `for guess_clamped in guesses_to_try: executor.submit(run_single_start, guess)` submits the same `guess` every time: the multi-start is one start five times. |
| 4 | 261-269 | `a1 == 0 & a2 == 1 & ...` - `&` binds tighter than `==`, so this is a chained comparison of different things; the pool type is wrong or None. |
| 5 | 313 | `get_fair_prob(r, r['TG'], r['SUP'])`: rows have no `TG` / `SUP` keys, KeyError whenever true odds are missing. |
| 6 | 507 vs 440 | `run_optimization(df_main)` is called with one argument; it takes `(batch, turnover)`. |

**Design issues in both versions** (these matter more than the crashes):

- **Demand is fixed.** Turnover is the observed number whatever theta does, so lowering every
  offer always looks better; only the market cap stops it. The loop's step 4 - re-run demand at
  the candidate prices - is missing.
- **The belief is HKJC's own.** `p_true = 1 / odds_df_true` is HKJC's theta, so the optimizer is
  asked to beat HKJC using HKJC's probabilities; with fixed demand the answer is degenerate.
- **No trust region.** Nothing limits how far theta moves from HKJC's in one bucket, or from the
  previous answer, so recommendations can jump.
- **Hard-coded constants**: margins per pool (lines 88-100), first-half share 0.54
  (lines 105-106) although the feed carries `Goal90SecondHalfSplitFH`.
- **Cost**: every objective evaluation loops over rows and builds a fresh score grid per row.

**W10 instead** (`backend/algoe/optimizer/theta_optimizer.py`): demand from the turnover model's
own price terms, renormalised within each pool (elasticity 2.0 at evens on the synthetic
world); belief from the calibrated probability model, not from HKJC's theta; a trust band
around HKJC's theta, a max step from the previous answer, coherence (FH within FT, |SUP| <=
TG), a per-selection probability band and the market cap; prices moved from HKJC's posted odds
by our relative change (`price_mode = delta`), so the lift measures the theta decision, not a
margin-table disagreement; one grid per block per evaluation, vectorised; the whole card inside
a time budget, richest match first, in a process pool. In the backtest the recommendation is
never worse than HKJC's theta by construction (theta_now is always a candidate) and gains
+1.8% E[GM] over 167 synthetic test buckets, better on 4 of 4 days, with the probability band
the guard that binds most often.

### `5 Data Extraction - Real Time.ipynb` - the live feed

**What:** the seven real-time queries (active pools, match info, parameters, events, odds with
true odds, market odds, investments by minute).
**Status:** the desk already runs these (`backend/src/hkjc/queries.py`, `sql_source.py`); W10's
`LivePanelBuilder` turns one such snapshot into exactly the rows training used, and the live
engine re-reads it every 5 minutes for the card and every ~15 s for the matches in focus.

## Summary

| Area | Keep | Replace |
|------|------|---------|
| Extraction | notebook 1, notebook 5 | - |
| Features | as-of-T discipline, provider max rule, selling-window activity | dense tensors, lag windows, `hash()` encodings, label mapping, bare except |
| Turnover model | the idea of a card-level model with theta as input | MSE on raw money; lazy layers; DDP start-up |
| Belief | - | HKJC's own true odds as the belief |
| Pricer | `poisson_betting.py` as the reference | per-row grids (vectorised, in-play score shift) |
| Optimizer | objective, market cap, multi-start | fixed demand, no trust region, hard-coded margins |
